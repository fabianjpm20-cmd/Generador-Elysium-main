const fs = require('fs');

let data = fs.readFileSync('src/data.ts', 'utf8');

const replacement = `
export function getWardrobeOptions(categoryId: string, itemId: string = '', itemName: string = '') {
  const isTop = ['B0', 'B1', 'B12-A', 'B3-D'].includes(categoryId);
  const isBottom = ['B2', 'B3-B'].includes(categoryId);
  const isShoes = categoryId === 'B4';
  const isAcc = categoryId === 'B5';
  const isBra = categoryId === 'B3-A';
  const isSocks = categoryId === 'B3-C';
  const isDress = categoryId === 'B0';
  
  const nameLow = itemName.toLowerCase();

  const isSkirt = nameLow.includes('falda') || nameLow.includes('kilt');
  const isPants = nameLow.includes('pantalón') || nameLow.includes('jeans') || nameLow.includes('leggings') || nameLow.includes('sweatpants');
  const isShorts = nameLow.includes('shorts') || nameLow.includes('bermuda') || nameLow.includes('hot pants');
  
  const isSleeveless = nameLow.includes('strapless') || nameLow.includes('halter') || nameLow.includes('bustier') || nameLow.includes('slip') || nameLow.includes('camisola') || nameLow.includes('chaleco');
  
  const isJacket = nameLow.includes('chaqueta') || nameLow.includes('abrigo') || nameLow.includes('blazer') || nameLow.includes('cardigan') || nameLow.includes('gabardina') || nameLow.includes('parka');
  
  const isBoots = nameLow.includes('bota') || nameLow.includes('botín');
  const isSandals = nameLow.includes('sandalia') || nameLow.includes('ojotas') || nameLow.includes('alpargatas');
  const isSneakers = nameLow.includes('zapatilla') || nameLow.includes('sneaker');

  // CUT
  let cut = ['Ajustado', 'Holgado', 'Recto', 'Entallado', 'Oversize', 'Slim'];
  if (isShoes) {
    if (isSandals) cut = ['Abierto', 'Tiras', 'Plataforma', 'Minimalista'];
    else if (isSneakers) cut = ['Chunky', 'Deportivo', 'Minimalista', 'High-Top', 'Low-Top'];
    else cut = ['Punta Redonda', 'Punta Cuadrada', 'Punta Afilada', 'Plataforma'];
  }
  if (isAcc) cut = ['Fino', 'Grueso', 'Minimalista', 'Chunky', 'Estructurado'];
  if (isBra || isBottom || isSocks) cut = ['Compresión Alta', 'Compresión Media', 'Relajado', 'Sin Costuras'];
  if (isDress) cut = ['Ajustado (Bodycon)', 'Holgado / Recto', 'Entallado en Cintura', 'Corte Imperio', 'Línea A'];

  // LENGTH
  let length = ['Cortísimo', 'Corto', 'Medio', 'Largo', 'Máximo', 'Asimétrico'];
  if (isShoes) {
    if (isBoots) length = ['Tobillo', 'Media Pierna', 'Rodilla', 'Muslo'];
    else length = ['Bajo (Estándar)', 'Plataforma', 'Tacón Medio', 'Tacón Alto'];
  }
  if (isBottom) {
    if (isSkirt) length = ['Micro', 'Mini', 'Rodilla', 'Midi', 'Maxi', 'Con Cola'];
    else if (isPants) length = ['Capri', 'Tobillo', 'Regular (Suelo)', 'Arrastre'];
    else if (isShorts) length = ['Micro', 'Corto', 'Ciclista', 'Bermuda (Rodilla)'];
    else length = ['Micro', 'Muslo', 'Rodilla', 'Tobillo', 'Suelo', 'Con Cola'];
  }
  if (isDress) length = ['Micro', 'Mini', 'Rodilla', 'Midi', 'Maxi', 'Con Cola'];
  if (isAcc) length = ['Corto/Ajustado', 'Medio', 'Largo/Colgante'];
  if (isBra) length = ['Estándar', 'Longline', 'Micro'];
  if (isTop && !isDress) length = ['Crop Top', 'Ombligo', 'Cadera', 'Largo (Túnica)', 'Asimétrico'];

  // SLEEVE
  let sleeve = ['Sin mangas', 'Corta', '3/4', 'Larga', 'Abullonada', 'Kimono', 'Raglán', 'Campana'];
  if (!isTop) sleeve = [];
  if (isSleeveless) sleeve = ['Sin mangas', 'Tirantes Finos', 'Tirantes Gruesos', 'Hombros Descubiertos'];
  if (isJacket) sleeve = ['Larga Estándar', 'Extra Larga', 'Remangada', '3/4', 'Acampanada'];

  // MATERIAL
  let material = ['Algodón', 'Lino', 'Lana', 'Seda', 'Terciopelo', 'Denim', 'Cuero', 'Encaje', 'Sintético'];
  if (isShoes || isAcc) material = ['Cuero', 'Gamuza', 'Sintético', 'Metal', 'Madera', 'Goma', 'Lona', 'Charol'];
  if (isBra || isSocks || categoryId === 'B3-B') material = ['Algodón', 'Encaje', 'Malla/Tul', 'Microfibra', 'Seda', 'Látex'];
  if (isJacket) material = ['Cuero', 'Denim', 'Lana Pesada', 'Nylon / Sintético', 'Terciopelo', 'Tweed', 'Pana'];

  // FINISH
  let finish = ['Mate', 'Satinado', 'Brillante', 'Espejado', 'Pulido', 'Desgastado', 'Metalizado', 'Craquelado'];
  
  // DETAILS
  let details = ['Bordados', 'Hebillas', 'Costuras', 'Encajes', 'Parches', 'Cinturones', 'Pliegues', 'Minimalista'];
  if (isShoes || isAcc) details = ['Tachuelas', 'Hebillas', 'Cadenas', 'Grabados', 'Lazos', 'Minimalista'];
  if (isBra || categoryId === 'B3-B') details = ['Lazos', 'Transparencias', 'Volantes', 'Bordados', 'Cintas', 'Minimalista'];

  // VARIATION
  let variation = ['Simétrica', 'Asimétrica', 'Desgastada', 'Desmechada', 'Degradada', 'Drapeada', 'Plisada'];
  if (isShoes) variation = ['Estándar', 'Deportivo', 'Urbano', 'Formal', 'Fantasía/Cosplay'];
  
  // LAYER
  let layer = ['Interior', 'Base', 'Intermedia', 'Exterior', 'Accesorio sobrepuesto'];
  if (isShoes) layer = ['Calzado Base', 'Calzado Exterior'];
  if (isAcc) layer = ['Accesorio Pequeño', 'Accesorio Mediano', 'Accesorio Grande', 'Armadura/Protección'];
  if (isBra || categoryId === 'B3-B' || isSocks || categoryId === 'B3-D') layer = ['Interior Íntima', 'Base Ligera'];
  if (isJacket) layer = ['Exterior Ligera', 'Exterior Pesada', 'Armadura Ligera'];
  if (isDress) layer = ['Base', 'Intermedia', 'Única'];

  return { cut, length, sleeve, material, finish, details, variation, layer };
}
`;

data = data.replace(/export function getWardrobeOptions\(categoryId: string\) \{[\s\S]*?return \{[\s\S]*?\};\n\}/, replacement.trim());

fs.writeFileSync('src/data.ts', data);
