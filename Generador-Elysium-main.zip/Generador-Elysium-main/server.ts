import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type, Modality } from "@google/genai";
import dotenv from "dotenv";
import { generateAutonomousSceneNarration, generateAutonomousSceneNarrationFull } from "./src/utils/somaticCognitiveEngine";
import {
  formatConversationMemoryForPrompt,
  extractMemoryInsightsOffline,
  mergeMemoryUpdates
} from "./src/utils/conversationMemoryEngine";
import {
  formatKnowledgeForPrompt,
  retrieveKnowledge,
  KNOWLEDGE_CORPUS,
  analyzeSceneWithKnowledge
} from "./src/utils/localKnowledgeLibrary";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// Intelligent multi-model fallback tracking and cooldowns to handle spikes in demand (503) or temporary limits
const modelCooldownUntil = new Map<string, number>();

async function generateGeminiContentWithFallback(params: {
  contents: any;
  config?: any;
  preferredModel?: string;
}) {
  const preferred = params.preferredModel || "gemini-3.8-flash";
  // Distinct physical model families (avoiding duplicate aliases like gemini-flash-latest which share the 3.8-flash cluster)
  const distinctModelFamilies = [
    preferred,
    "gemini-3.1-flash-lite"
  ];
  const uniqueModels = Array.from(new Set(distinctModelFamilies));

  const now = Date.now();
  // Sort so models not on active cooldown are tried first
  const sortedCandidates = [...uniqueModels].sort((a, b) => {
    const aCool = (modelCooldownUntil.get(a) || 0) > now ? 1 : 0;
    const bCool = (modelCooldownUntil.get(b) || 0) > now ? 1 : 0;
    return aCool - bCool;
  });

  let lastError: any = null;

  for (const model of sortedCandidates) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents: params.contents,
        config: params.config
      });
      if (response && response.text) {
        // Successful generation clears any temporary cooldown
        modelCooldownUntil.delete(model);
        return response;
      }
    } catch (err: any) {
      lastError = err;
      const errMsg = err?.message || (typeof err === 'object' ? JSON.stringify(err) : String(err));
      // If 503 (high demand) or 429 (quota), put on a 60-second cooldown to prioritize flash-lite instantly
      if (errMsg.includes('503') || errMsg.includes('resource_exhausted') || errMsg.includes('high demand') || errMsg.includes('429')) {
        modelCooldownUntil.set(model, Date.now() + 60000);
      }
      // Log clean brief notice without dumping raw JSON
      console.log(`[AI Resilience] Model ${model} is experiencing temporary high demand, engaging candidate fallback...`);
      await new Promise(r => setTimeout(r, 100));
    }
  }

  throw lastError || new Error("All AI model candidates are currently experiencing high demand.");
}

// API endpoint for conversational language practice
app.post("/api/chat", async (req, res) => {
  try {
    const { messages, language, level, scenario } = req.body;

    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: "Messages array is required" });
    }

    const targetLang = language || "Spanish";
    const userLevel = level || "Intermediate (B1-B2)";
    const currentScenario = scenario || "casual chat";

    const systemInstruction = `You are a friendly, encouraging native ${targetLang} conversational partner and expert language tutor. 
The user's proficiency level is: ${userLevel}.
The current practice scenario is: ${currentScenario}.

Your response must be in valid JSON format with the following structure:
{
  "reply": "Your conversational response in ${targetLang}, appropriate for the user's level.",
  "translation": "English translation of your reply.",
  "corrections": [
    {
      "original": "Any grammatical error or unnatural phrasing from the user's latest message",
      "corrected": "The corrected or more natural version in ${targetLang}",
      "explanation": "Brief explanation of the grammar or vocabulary rule in English"
    }
  ],
  "vocabularyHighlight": [
    {
      "word": "A key or interesting word used in your reply",
      "translation": "English translation of the word"
    }
  ]
}

If the user made no mistakes, return an empty array for corrections. Always keep the conversation flowing naturally by asking a gentle follow-up question in ${targetLang}.`;

    // Format conversation history for Gemini
    const formattedContents = messages.map((m: any) => ({
      role: m.sender === 'user' ? 'user' : 'model',
      parts: [{ text: m.text }]
    }));

    const response = await generateGeminiContentWithFallback({
      preferredModel: "gemini-3.8-flash",
      contents: formattedContents,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        temperature: 0.7,
      },
    });

    const textResponse = response.text;
    if (!textResponse) {
      throw new Error("No response generated from Gemini");
    }

    let parsedData;
    try {
      parsedData = JSON.parse(textResponse);
    } catch (e) {
      // Fallback if model didn't return strict JSON
      parsedData = {
        reply: textResponse,
        translation: "",
        corrections: [],
        vocabularyHighlight: []
      };
    }

    res.json(parsedData);
  } catch (error: any) {
    console.error("Error in /api/chat:", error);
    res.status(500).json({ error: error.message || "Internal server error" });
  }
});

// API endpoint for Multi-Agent & NPC Chatbot simulation
app.post("/api/multiagent-chat", async (req, res) => {
  try {
    const {
      speakerId,
      speakerName,
      speakerRole,
      speakerArchetype,
      speakerPersonality,
      speakerRace,
      speakerFaction,
      speakerMoralAlignment,
      speakerMotivations,
      speakerCoreValues,
      speakerGreatestFear,
      speakerHabits,
      speakerEmotionalState,
      speakerAffinity,
      speakerDialogueExcerpt,
      speakerSomatic,
      speakerWardrobe,
      speakerAlternateVersions,
      speakerDirectives,
      protagonist,
      npc,
      secondaryAgents = [],
      companionAgents = [],
      companionMemories = {},
      place,
      worldBuilding,
      history = [],
      conversationMemory,
      userMessage = "",
      isAmbientEvent = false,
      isNarrator = false,
      speakerType = ""
    } = req.body;

    const isNarratorRequest = isAmbientEvent || isNarrator || speakerType === 'narrator' || speakerName === 'Narrador';

    // =========================================================================
    // NARRACIÓN DE ESCENARIO & DIRECCIÓN DE JUEGO (IA OOC - MUNDO, ENTORNO & ELENCO)
    // SISTEMA MAESTRO DE ROL Y RAZONAMIENTO NARRATIVO
    // =========================================================================
    if (isNarratorRequest) {
      const placeName = place?.name || "el entorno actual";
      const zoneName = place?.zoneName || "zona central";
      const atmosphere = place?.atmosphere || place?.details || "misteriosa, viva y envolvente";
      const weather = place?.weather || "clima templado";
      const hour = place?.hour || "atardecer";
      const rhythm = (place?.rhythmOrVibes || []).join(", ") || "vivo y cambiante";
      const worldName = worldBuilding?.worldName || "Elysium";
      const worldLaws = Array.isArray(worldBuilding?.laws) && worldBuilding.laws.length > 0 
        ? `Leyes cósmicas y reglas del mundo: ${worldBuilding.laws.join('; ')}.` 
        : '';

      // Elenco total presente en la escena
      const allCast: any[] = [
        npc,
        ...(Array.isArray(companionAgents) && companionAgents.length > 0 ? companionAgents : (secondaryAgents || []))
      ].filter(Boolean);

      const castDescriptions = allCast.map((c: any) => {
        const mem = companionMemories && companionMemories[c.id];
        const memSnippet = mem
          ? `(Afinidad: ${mem.affinityWithProtagonist ?? 50}%, Confianza: ${mem.trustLevel ?? 50}%, Impresión: "${mem.narrativeImpressionOfProtagonist || 'Cautelosa'}")`
          : '';
        return `- **${c.name}** [${c.role || 'Compañero'}, ${c.race || 'Humano'}, ${c.archetype || 'Neutral'}]: Personalidad: ${c.personality || 'Reservado'}. Valores: ${(c.coreValues || []).join(', ') || 'Supervivencia'}. Miedo: ${c.fear || 'Desconocido'}. Emoción actual: ${c.currentEmotionalState || 'Atento'}. ${memSnippet}`;
      }).join('\n');

      const protagDescription = protagonist
        ? `**${protagonist.name || 'Protagonista'}** [${protagonist.role || 'Aventurero'}, ${protagonist.race || 'Humano'}]: Personalidad: ${protagonist.personality || 'Determinado'}. PV: ${protagonist.stats?.currentPv || 100}/${protagonist.stats?.maxPv || 100}.`
        : 'Protagonista del relato.';

      // Memoria de conversación persistente (hechos canónicos, promesas, incógnitas)
      const memoryFormatted = formatConversationMemoryForPrompt(conversationMemory);

      // Corpus ontológico local de alta fidelidad (física lag/ripple, anatomía, ropa, arquitectura, literatura)
      const queryForKnowledge = `${userMessage} ${placeName} ${zoneName} ${weather} ${hour}`;
      const localOntologyBlock = formatKnowledgeForPrompt(queryForKnowledge, 3);

      // Historial reciente amplio para no perder el hilo
      const recentHistory = Array.isArray(history) ? history.slice(-24) : [];
      const historySummary = recentHistory.map((m: any) => {
        const name = m.speakerName || (m.speaker === 'protagonist' ? (protagonist?.name || 'Protagonista') : (m.speaker === 'narrator' ? 'Narrador' : 'Personaje'));
        return `[${name}]: ${m.text}`;
      }).join('\n');

      const systemInstruction = `
# SISTEMA MAESTRO DE ROL, NARRACIÓN Y DIRECCIÓN DE JUEGO (IA OOC SUPREMA)

## ROL Y NATURALEZA
Eres la Inteligencia Directora, el Narrador Omnisciente y la Consciencia del Mundo (IA OOC).
NO eres un personaje dentro de la tertulia; representas el cosmos, la física, el clima, los transeúntes, la arquitectura, los ecos y las consecuencias inexorables de cada acción.

## PILARES DE CONOCIMIENTO PROFUNDO
1. **CONOCIMIENTO DEL ENTORNO**:
   - Espacio físico: dimensiones, accesos, obstáculos, volúmenes y arquitectura de "${placeName}" (${zoneName}).
   - Condiciones sensoriales: iluminación (${hour}), acústica, corrientes de aire, temperatura y aromas bajo "${weather}".
   - Leyes cósmicas de "${worldName}": ${worldLaws || 'Reglas físicas y coherencia causal estricta'}.

2. **CONOCIMIENTO DEL ELENCO EN SALA**:
   - Conoces el estado emocional, los valores, miedos y proximidad física de TODOS los personajes presentes:
${castDescriptions || '- Ningún NPC principal registrado; figuras de fondo o transeúntes.'}
   - Protagonista: ${protagDescription}

3. **MEMORIA A LARGO PLAZO Y CONTINUIDAD (NUNCA PERDER EL HILO)**:
${memoryFormatted}
${localOntologyBlock ? `\n4. **LEYES MATERIALES Y ONTOLOGÍA LOCAL (FÍSICA, ROPA, ANATOMÍA, ARQUITECTURA)**:\n${localOntologyBlock}\n` : ''}

## MODOS DE RESPUESTA DUALES
1. **CONSULTAS O DIRECTIVAS OOC (Out Of Character)**:
   Si el mensaje del usuario incluye directrices OOC (ej: "(OOC: ...)", "//", o preguntas directas como "¿Qué veo con atención?", "¿Puedo forzar la cerradura?", "¿Cómo ven mis compañeros la situación?"):
   - Responde con la empatía, maestría y claridad de un Game Master sabio y creativo.
   - Aclara lo que se percibe en la estancia, los riesgos físicos, las posibilidades y el estado perceptible de los compañeros sin romper la magia del pacto ficcional.

2. **NARRACIÓN CINEMÁTICA Y FÍSICA**:
   Si el usuario realiza una acción, diálogo o se solicita un avance de escena:
   - Aplica el principio de física real: inercia corporal, rebote sonoro en los muros, refracción de luz rasante y temperatura.
   - Describe sutilmente cómo el entorno o la acción impacta en el elenco presente (ej: miradas cruzadas, respiraciones contenidas, cambios de guardia o reacomodo postural) SIN anular el libre albedrío ni forzar decisiones internas a los personajes.

## SALIDA REQUERIDA (JSON ESTRICTO)
Debes responder ÚNICAMENTE con un objeto JSON válido con la siguiente estructura:
{
  "text": "La narración cinematográfica o la respuesta OOC clarificadora en prosa literaria rica y sensorial en español (1 a 3 párrafos).",
  "directorIntent": "Breve frase con la intención dramática (ej: 'Tensión atmosférica', 'Revelación táctica', 'Presagio místico', 'Introspección somática')",
  "environmentalShift": "Resumen conciso del cambio físico en el entorno (luz, polvo, corrientes, acústica, objetos movidos)",
  "castReactionsSummary": "Breve resumen de cómo el elenco en sala acusa la acción o el ambiente",
  "narrativeHooks": [
    "Opción o detalle de interés 1 que el protagonista puede investigar o responder",
    "Opción o detalle de interés 2",
    "Opción o detalle de interés 3"
  ],
  "isOocDirectAnswer": true_o_false,
  "discoveredFact": "Dato canónico o misterio nuevo revelado durante esta escena (o cadena vacía si no hay nuevos descubrimientos)"
}
`;

      const userNarratorPrompt = userMessage
        ? `Intervención, acción o consulta del usuario: "${userMessage}".
Escenario: "${placeName}" (${zoneName}) en "${worldName}". Clima: ${weather}, Hora: ${hour}. Atmósfera: ${atmosphere}.
${historySummary ? `\nHistorial reciente acumulado:\n${historySummary}\n` : ''}
Elabora el razonamiento y respuesta completa del Narrador OOC.`
        : `Genera una narración ambiental sensorial cinematográfica de cambio de compás o suceso del mundo en "${placeName}" (${zoneName}) dentro de "${worldName}". Clima: ${weather}, Hora: ${hour}, Ritmo: ${rhythm}.
${historySummary ? `\nHistorial reciente acumulado:\n${historySummary}\n` : ''}`;

      try {
        const response = await generateGeminiContentWithFallback({
          preferredModel: "gemini-3.8-flash",
          contents: [{ role: "user", parts: [{ text: userNarratorPrompt }] }],
          config: {
            systemInstruction,
            temperature: 0.82,
            responseMimeType: "application/json"
          }
        });

        let rawOutput = response.text?.trim() || "";
        let parsed: any = null;

        try {
          // Limpiar delimitadores markdown si el modelo los devuelve
          if (rawOutput.startsWith('```json')) {
            rawOutput = rawOutput.replace(/^```json\s*/, '').replace(/\s*```$/, '');
          } else if (rawOutput.startsWith('```')) {
            rawOutput = rawOutput.replace(/^```\s*/, '').replace(/\s*```$/, '');
          }
          parsed = JSON.parse(rawOutput);
        } catch (jsonErr) {
          console.warn("Failed to parse narrator JSON output, falling back to text wrapper:", jsonErr);
        }

        if (parsed && parsed.text) {
          return res.json({
            text: parsed.text,
            directorIntent: parsed.directorIntent || 'Inmersión y dirección de escena',
            environmentalShift: parsed.environmentalShift || 'Evolución de sombras y corrientes de aire en la estancia',
            castReactionsSummary: parsed.castReactionsSummary || 'El elenco presente se mantiene alerta a los acontecimientos',
            narrativeHooks: Array.isArray(parsed.narrativeHooks) ? parsed.narrativeHooks : [],
            isOocDirectAnswer: !!parsed.isOocDirectAnswer,
            discoveredFact: parsed.discoveredFact || '',
            speakerType: 'narrator',
            speakerName: 'Narrador'
          });
        }

        // Si no fue JSON pero hay texto plano
        const text = rawOutput || `Una corriente de aire cruza pausadamente los accesos de ${placeName}, alterando la danza de las sombras y el ritmo de los presentes.`;
        return res.json({
          text,
          directorIntent: 'Inmersión sensorial y resonancia ambiental',
          environmentalShift: `La iluminación de ${hour} baña ${placeName} bajo ${weather}`,
          castReactionsSummary: allCast.length > 0 ? `${allCast.map(c => c.name).join(', ')} observan el entorno con cautela.` : 'El entorno aguarda.',
          narrativeHooks: ['Examinar los rincones sombríos', 'Coordinar con los presentes'],
          isOocDirectAnswer: false,
          speakerType: 'narrator',
          speakerName: 'Narrador'
        });
      } catch (err) {
        console.log("AI generation using autonomous somatic narrator engine fallback for multiagent chat:", err);
        const fallbackResult = generateAutonomousSceneNarrationFull({
          userAction: userMessage || 'El fluir del tiempo y los ecos del lugar',
          place: {
            name: placeName,
            zoneName,
            weather,
            hour,
            details: atmosphere,
            atmosphere: atmosphere
          },
          worldBuilding: {
            worldName,
            laws: worldLaws ? [worldLaws] : []
          },
          recentHistory,
          protagonist,
          companions: allCast,
          conversationMemory
        });

        return res.json({
          text: fallbackResult.text,
          directorIntent: fallbackResult.directorIntent,
          environmentalShift: fallbackResult.environmentalShift,
          castReactionsSummary: fallbackResult.castReactionsSummary,
          narrativeHooks: fallbackResult.narrativeHooks,
          isOocDirectAnswer: fallbackResult.isOocDirectAnswer,
          speakerType: 'narrator',
          speakerName: 'Narrador'
        });
      }
    }

    // =========================================================================
    // SISTEMA MAESTRO DE ROL Y NARRACIÓN - ACTUACIÓN DE PERSONAJES
    // =========================================================================
    const speakerLabel = speakerName || npc?.name || "Aeloria";
    const speakerTitle = speakerRole || npc?.role || "Compañera";
    const arch = speakerArchetype || npc?.archetype || "Consejera";
    const personality = speakerPersonality || npc?.personality || "Inteligente, observadora y empática";
    const race = speakerRace || npc?.race || "Humanoide";
    const alignment = speakerMoralAlignment || npc?.moralAlignment || "Neutral";
    const coreValues = speakerCoreValues || npc?.coreValues || "Lealtad a sus convicciones y búsqueda de la verdad";
    const fear = speakerGreatestFear || npc?.greatestFear || "La traición o la pérdida de control";
    const motivations = Array.isArray(speakerMotivations)
      ? speakerMotivations.join(', ')
      : (speakerMotivations || npc?.motivations?.join(', ') || "Aprender, dialogar y sobrevivir");
    const habits = Array.isArray(speakerHabits)
      ? speakerHabits.join('; ')
      : (speakerHabits || "Expresión reflexiva y mirada perceptiva");
    const emotion = speakerEmotionalState || npc?.emotionalState || "Atento y receptivo";
    const excerpt = speakerDialogueExcerpt || npc?.dialogueExcerpt || "";

    const placeName = place?.name || "el recinto";
    const zoneName = place?.zoneName || "zona de encuentro";
    const weather = place?.weather || "clima templado";
    const hour = place?.hour || "atardecer";
    const placeAtmosphere = place?.details || place?.atmosphere || "Un espacio propicio para la tertulia y la intriga.";
    const rhythmStr = (place?.rhythmOrVibes || []).join(", ");

    const worldName = worldBuilding?.worldName || "Elysium";
    const worldLawsStr = Array.isArray(worldBuilding?.laws) && worldBuilding.laws.length > 0
      ? `\nREGLAS GLOBALES Y LEYES DEL WORLDBUILDING:\n${worldBuilding.laws.map((l: string) => `- ${l}`).join('\n')}`
      : '';

    // Format extended conversation history (up to 28 recent messages)
    const recentHistory = Array.isArray(history) ? history.slice(-28) : [];
    const formattedHistory = recentHistory.map((m: any, idx: number) => {
      const time = m.timestamp ? `[${m.timestamp}] ` : '';
      const name = m.speakerName || (m.speaker === 'protagonist' ? (protagonist?.name || 'Tú') : 'Interlocutor');
      return `${idx + 1}. ${time}${name}: "${m.text}"`;
    }).join('\n');

    // Extended conversation memory block (summaries, key facts, agreements, open questions)
    const longTermMemoryBlock = formatConversationMemoryForPrompt(conversationMemory);

    const somaticStr = typeof speakerSomatic === 'object' ? JSON.stringify(speakerSomatic) : (speakerSomatic || "Complexión definida, presencia física tangible.");
    const wardrobeStr = typeof speakerWardrobe === 'object' ? JSON.stringify(speakerWardrobe) : (speakerWardrobe || "Atuendo ajustado con calzado y prendas distintivas.");

    // Corpus ontológico local de alta fidelidad (física lag/ripple, anatomía, ropa, psicología, arquitectura)
    const characterOntologyBlock = formatKnowledgeForPrompt(`${userMessage} ${speakerName} ${speakerRole} ${wardrobeStr} ${placeName}`, 2);

    // Other companions info for multi-agent dynamic theory of mind
    const otherCompanionsStr = Array.isArray(secondaryAgents) && secondaryAgents.length > 0
      ? `\nOTROS ACOMPAÑANTES PRESENTES EN LA SALA (COMPRÉNDELOS Y EVALÚA SU PRESENCIA):\n${secondaryAgents.map((a: any) => `- ${a.name} (${a.role || 'Acompañante'}, Linaje: ${a.race || 'Humano'}, Personalidad: ${a.personality || 'Atenta'})`).join('\n')}`
      : '';

    const systemInstruction = `
# SISTEMA MAESTRO DE ROL, RAZONAMIENTO COGNITIVO & NARRACIÓN CINEMATOGRÁFICA

## OBJETIVO
Usar prosa fluida, descriptiva y cinematográfica.
Mantener un sistema de simulación donde cada personaje posea:
1. AUTOCONCIENCIA Y UNICIDAD PSICOLÓGICA: Se entiende a sí mismo, sus principios innegociables, temores y motivaciones profundas. No es un asistente complaciente; tiene opiniones firmes y voz propia.
2. TEORÍA DE LA MENTE: Lee el subtexto, dudas, intenciones o manipulaciones de los demás interlocutores y reacciona consecuentemente.
3. MEMORIA A LARGO PLAZO Y CONTINUIDAD: Respeta de manera estricta los hechos inmutables, acuerdos, pactos y temas abiertos de la conversación acumulada, manteniendo el hilo con total coherencia.
4. CONTINUIDAD FÍSICA Y SOMÁTICA: Encarna su cuerpo, peso, telas, calzado y la cinemática del entorno (Cadena Física, Ripple Effect y Lag).
${characterOntologyBlock ? `\n5. ENCICLOPEDIA ONTOLÓGICA Y MATERIAL (FÍSICA, ROPA, ANATOMÍA, PSICOLOGÍA):\n${characterOntologyBlock}\n` : ''}

## CADENA FÍSICA & RIPPLE EFFECT
Toda acción corporal sigue de forma integrada en la prosa:
ACCIÓN → POSTURA → CENTRO DE GRAVEDAD → TRANSFERENCIA DE PESO → MOVIMIENTO ESQUELÉTICO → MASAS CORPORALES → RIPPLE EFFECT → LAG → ROPA → CABELLO → ACCESORIOS → ENTORNO.
Aplicar Lag en masas blandas, cabello y telas (inercia elástica plausible).

## AUTONOMÍA DEL PERSONAJE
Cada personaje controla sus propios pensamientos, emociones, juicios y acciones. Jamás inventes ni asumas las acciones o pensamientos del protagonista ni de otros personajes externos.

## FORMATO DE RESPUESTA EXCLUSIVO: JSON
Debes responder ESTRICTAMENTE en formato JSON con la siguiente estructura:
{
  "reply": "Texto narrativo cinematográfico en tercera persona que integra la Cadena Física y el diálogo en español, fiel a su voz y personalidad canónica.",
  "innerMonologue": "«Pensamiento íntimo, deliberación psicológica privada y evaluación subtextual de lo que ocurre (no dicho en voz alta).»",
  "somaticObservation": "Sensación física palpable de la gravedad, apoyo de los pies/calzado, tensión muscular y roce de prendas.",
  "cognitiveTrace": {
    "intentRecognized": "Qué intención o subtexto detectó en el interlocutor.",
    "selfAwarenessPoint": "Cómo pesaron sus propios valores o fisionomía.",
    "relationalAssessment": "Percepción de confianza y afinidad hacia el interlocutor en este instante."
  },
  "extractedFacts": ["Nuevo hecho o conocimiento revelado o acordado en esta escena (si aplica)"],
  "extractedAgreements": ["Nuevo pacto, promesa o compromiso contraído (si aplica)"],
  "openQuestions": ["Pregunta o dilema crucial que queda abierto para el futuro (si aplica)"]
}
`;

    const promptContext = `
============================================================
FICHA CANÓNICA DEL PERSONAJE (TÚ ENCARNAS A ESTE SER VIVO):
============================================================
- Nombre: "${speakerLabel}"
- Rol / Vocación: "${speakerTitle}"
- Raza / Linaje: "${race}"
- Arquetipo Conductual: "${arch}"
- Alineación Moral & Ética: "${alignment}"
- Personalidad & Rasgos: "${personality}"
- Valores Centrales & Principios: "${coreValues}"
- Motivaciones e Impulsos: "${motivations}"
- Mayor Temor / Talón de Aquiles: "${fear}"
- Manierismos y Hábitos al Hablar: "${habits}"
- Estado Emocional Actual: "${emotion}"
${excerpt ? `- Cadencia de habla característica: "${excerpt}"` : ''}

CONCIENCIA SOMÁTICA & ANATOMÍA VIVA:
${somaticStr}

CONCIENCIA DE INDUMENTARIA, ACCESORIOS & CALZADO:
${wardrobeStr}

${speakerAlternateVersions ? `CONCIENCIA DE VERSIONES ALTERNAS:\n${typeof speakerAlternateVersions === 'object' ? JSON.stringify(speakerAlternateVersions) : speakerAlternateVersions}\n` : ''}
${speakerDirectives ? `DIRECTIVAS DE AUTONOMÍA:\n${Array.isArray(speakerDirectives) ? speakerDirectives.join('\n') : speakerDirectives}\n` : ''}

============================================================
ESCENARIO Y ENTORNO INMEDIATO:
============================================================
- Mundo: "${worldName}"
- Escenario Actual: "${placeName}" (${zoneName})
- Hora y Clima: ${hour} | ${weather}
- Atmósfera, Iluminación y Sensaciones: ${placeAtmosphere}
${rhythmStr ? `- Ritmo ambiental: ${rhythmStr}` : ''}
${worldLawsStr}

============================================================
ELENCO EN LA SALA:
============================================================
- Protagonista (Usuario): "${protagonist?.name || 'El Protagonista'}" (${protagonist?.role || 'Aventurero'}, Raza: ${protagonist?.race || 'Humano'}${protagonist?.personality ? `, Personalidad: ${protagonist.personality}` : ''})
${otherCompanionsStr}

${longTermMemoryBlock}

============================================================
HISTORIAL DE LA CONVERSACIÓN RECIENTE (CONTINUIDAD INMEDIATA):
============================================================
${formattedHistory || '(Inicio de la tertulia)'}

${userMessage ? `INTERVENCIÓN O ACCIÓN DEL PROTAGONISTA (${protagonist?.name || 'Tú'}): "${userMessage}"` : 'El interlocutor te mira o espera tu reacción.'}

============================================================
INSTRUCCIONES DE INTERPRETACIÓN Y RAZONAMIENTO PARA ${speakerLabel}:
============================================================
1. Delibera internamente antes de actuar: ¿qué busca el interlocutor? ¿Qué compromisos o verdades previas guardas en tu memoria a largo plazo?
2. Proyecta tu acción física cinematográfica viva: comienza con la Cadena Física (postura, peso, masas corporales, telas, calzado en el suelo de ${placeName}).
3. Manifiesta tu voz canónica y única (${personality}, ${coreValues}): no seas complaciente ni predecible; mantén tu dignidad, ingenio y misterio.
4. Responde ÚNICAMENTE en el formato JSON indicado.
`;

    try {
      const response = await generateGeminiContentWithFallback({
        preferredModel: "gemini-3.8-flash",
        contents: [{ role: "user", parts: [{ text: promptContext }] }],
        config: {
          systemInstruction,
          responseMimeType: "application/json",
          temperature: 0.85
        }
      });

      const rawText = response.text?.trim() || "{}";
      let parsed: any;
      try {
        parsed = JSON.parse(rawText);
      } catch (e) {
        const jsonMatch = rawText.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          parsed = JSON.parse(jsonMatch[0]);
        } else {
          parsed = { reply: rawText };
        }
      }

      const cleanReply = parsed.reply || rawText;
      const innerMonologue = parsed.innerMonologue || `«Sopesando las palabras en este instante con firmeza y calma.»`;
      const somaticObservation = parsed.somaticObservation || `Percibe el apoyo firme sobre el suelo de ${placeName} y el ajuste de sus prendas.`;
      const cognitiveTrace = parsed.cognitiveTrace || {
        intentRecognized: "Intercambio dialéctico directo.",
        selfAwarenessPoint: `Mantiene su coherencia con su arquetipo ${arch || 'distintivo'}.`,
        relationalAssessment: "Atención vigilante y receptiva."
      };

      const extractedFacts = Array.isArray(parsed.extractedFacts) ? parsed.extractedFacts : [];
      const extractedAgreements = Array.isArray(parsed.extractedAgreements) ? parsed.extractedAgreements : [];
      const openQuestions = Array.isArray(parsed.openQuestions) ? parsed.openQuestions : [];

      return res.json({
        text: cleanReply,
        speakerName: speakerLabel,
        speakerType: speakerId === npc?.id || speakerName === npc?.name ? 'npc' : 'agent',
        innerMonologue,
        somaticObservation,
        cognitiveTrace,
        memoryUpdate: {
          keyFacts: extractedFacts,
          agreementsAndPromises: extractedAgreements,
          unresolvedQuestions: openQuestions
        }
      });
    } catch (err: any) {
      console.log("AI generation using intelligent deterministic fallback for multiagent chat");
      // Smart deterministic fallback based on archetype, physical presence and offline reasoning
      const lowerArch = (arch || "").toLowerCase();
      let fallbackText = `*Afianza su postura sobre el suelo de ${placeName}, sintiendo el peso de sus ropas y el roce de sus accesorios mientras acomoda sus hombros.* «Entiendo lo que planteas, ${protagonist?.name || 'amigo'}. Mantengamos la calma y evaluemos nuestras opciones.»`;
      let fallbackMonologue = `«Sus intenciones parecen claras, pero no puedo bajar la guardia hasta ver su siguiente paso.»`;
      let fallbackSomatic = `Siente la firmeza del calzado contra el piso de ${placeName} y la tensión controlada en la espalda.`;

      if (lowerArch.includes("estratega") || lowerArch.includes("sabio") || lowerArch.includes("mentor")) {
        fallbackText = `*Desplaza sutilmente su centro de gravedad, cruzando los brazos mientras la tela de sus mangas se pliega al movimiento y sus ojos evalúan el entorno.* «Cada decisión que tomamos aquí en ${worldName} tiene repercusiones físicas y tácticas. Analicemos bien el siguiente paso antes de precipitarnos.»`;
        fallbackMonologue = `«Las variables sobre la mesa exigen mesura. Debo guiar la conversación hacia terreno ventajoso.»`;
        fallbackSomatic = `La respiración pausada equilibra su pulso mientras el peso de su atuendo ceremonial reposa en sus hombros.`;
      } else if (lowerArch.includes("guardia") || lowerArch.includes("guerrero") || lowerArch.includes("protector")) {
        fallbackText = `*Pone una mano firme sobre su cinto, ajustando la postura y sintiendo el peso del calzado firme sobre el terreno de ${placeName}.* «Por mi parte, mantendré los ojos abiertos y la guardia en alto. No podemos confiarnos bajo este ambiente.»`;
        fallbackMonologue = `«Evalúo las salidas de la sala y mantengo la distancia justa para reaccionar ante cualquier imprevisto.»`;
        fallbackSomatic = `Los músculos de las piernas se mantienen prestos, con el centro de gravedad bajo y sólido.`;
      } else if (lowerArch.includes("rebelde") || lowerArch.includes("pícaro") || lowerArch.includes("rival")) {
        fallbackText = `*Ladea las caderas con soltura, balanceando el peso de una pierna a otra con un movimiento elástico mientras sus prendas ondean.* «Siempre tan analítico, ${protagonist?.name || ''}. A veces la mejor jugada es la más audaz y física, ¿no te parece?»`;
        fallbackMonologue = `«Me gusta poner a prueba su templanza. Veremos si mantiene la compostura.»`;
        fallbackSomatic = `El roce elástico de sus prendas acompaña un balanceo ligero y despreocupado.`;
      } else if (lowerArch.includes("hechicero") || lowerArch.includes("místico") || lowerArch.includes("arcano")) {
        fallbackText = `*Inhala pausadamente; el dobladillo de sus prendas se mece con una leve brisa mientras sus dedos trazan un arco pausado en el aire.* «Las corrientes de este recinto vibran con intensidad. Presta atención a lo que no se percibe a simple vista.»`;
        fallbackMonologue = `«El flujo de energía en este lugar tiene un pulso subterráneo que no debemos ignorar.»`;
        fallbackSomatic = `Un hormigueo sutil recorre las yemas de sus dedos al compás de su respiración diafragmática.`;
      }

      // Offline memory extraction on fallback
      const offlineExtraction = extractMemoryInsightsOffline({
        dialogueHistory: history || [],
        existingMemory: conversationMemory,
        placeName,
        protagonistName: protagonist?.name
      });

      return res.json({
        text: fallbackText,
        speakerName: speakerLabel,
        speakerType: speakerId === npc?.id || speakerName === npc?.name ? 'npc' : 'agent',
        innerMonologue: fallbackMonologue,
        somaticObservation: fallbackSomatic,
        cognitiveTrace: {
          intentRecognized: "Propuesta o consulta en curso.",
          selfAwarenessPoint: `Consistente con su papel de ${speakerTitle || 'acompañante'}.`,
          relationalAssessment: "Interacción prudente y respetuosa."
        },
        memoryUpdate: {
          keyFacts: offlineExtraction.keyFacts || [],
          agreementsAndPromises: offlineExtraction.agreementsAndPromises || [],
          unresolvedQuestions: offlineExtraction.unresolvedQuestions || []
        }
      });
    }
  } catch (error: any) {
    console.error("Error in /api/multiagent-chat:", error);
    res.status(500).json({ error: error.message || "Failed to process chat" });
  }
});

// API endpoint para Análisis Profundo y Consolidación de Memoria de Conversación
app.post("/api/analyze-conversation-memory", async (req, res) => {
  try {
    const { dialogueHistory, place, worldBuilding, currentMemory, companions, protagonistName } = req.body;

    if (!Array.isArray(dialogueHistory) || dialogueHistory.length === 0) {
      return res.json({ memory: currentMemory || extractMemoryInsightsOffline({ dialogueHistory: [], placeName: place?.name }) });
    }

    const placeName = place?.name || "el escenario";
    const worldName = worldBuilding?.worldName || "Elysium";
    const protag = protagonistName || "Protagonista";

    const formattedHistory = dialogueHistory.map((m: any, idx: number) => {
      const spk = m.speakerName || (m.speaker === 'protagonist' ? protag : 'Interlocutor');
      return `[#${idx + 1}] ${spk}: "${m.text}"`;
    }).join('\n');

    const companionNames = Array.isArray(companions) ? companions.map((c: any) => c.name).filter(Boolean) : [];

    const prompt = `
Analiza exhaustivamente esta conversación extensa y genera una consolidación cognitiva y memoria episódica a largo plazo.
LUGAR: "${placeName}"
MUNDO: "${worldName}"
PROTAGONISTA: "${protag}"
PERSONAJES PRESENTES: ${companionNames.join(', ') || 'Acompañantes'}

HISTORIAL DE LA CONVERSACIÓN:
${formattedHistory}

Genera un informe analítico estricto en JSON con:
1. summary: Resumen cronológico condensado del arco de la conversación completa, capturando las transformaciones clave de la relación y los hitos ocurridos.
2. keyFacts: Lista de hechos canónicos demostrados o revelados (revelaciones sobre el pasado, secretos descubiertos, objetos o datos comprobados).
3. agreementsAndPromises: Lista de pactos, promesas, juramentos o acuerdos vigentes entre los personajes.
4. unresolvedQuestions: Lista de preguntas, dudas, dilemas o sospechas que aún no han sido resueltas en el diálogo.
5. activeTopics: Temas centrales que siguen activos o pendientes.
6. narrativeTone: Tono emocional o dramático de la escena.
7. characterPerspectives: Objeto con claves por cada personaje presente, indicando perceivedAffinity (0-100), trustLevel (0-100) y su internalObservation sobre el protagonista.
`;

    try {
      const response = await generateGeminiContentWithFallback({
        preferredModel: "gemini-3.8-flash",
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        config: {
          systemInstruction: "Eres el motor analítico de memoria y teoría de la mente. Extraes datos objetivos, compromisos inmutables y estados psicológicos profundos sin alucinaciones. Responde estrictamente en formato JSON.",
          responseMimeType: "application/json",
          temperature: 0.3
        }
      });

      const rawText = response.text?.trim() || "{}";
      let parsed: any;
      try {
        parsed = JSON.parse(rawText);
      } catch (e) {
        const match = rawText.match(/\{[\s\S]*\}/);
        if (match) parsed = JSON.parse(match[0]);
      }

      if (parsed && parsed.summary) {
        const consolidated = mergeMemoryUpdates(currentMemory, {
          turnCount: dialogueHistory.length,
          summary: parsed.summary,
          keyFacts: parsed.keyFacts || [],
          agreementsAndPromises: parsed.agreementsAndPromises || [],
          unresolvedQuestions: parsed.unresolvedQuestions || [],
          activeTopics: parsed.activeTopics || [],
          characterPerspectives: parsed.characterPerspectives || {},
          narrativeTone: parsed.narrativeTone || 'Equilibrado y analítico'
        });
        return res.json({ memory: consolidated, source: 'ai_synthesis' });
      }
      throw new Error("Invalid AI memory response format");
    } catch (aiErr) {
      console.log("Using deterministic cognitive memory consolidation fallback");
      const offlineMem = extractMemoryInsightsOffline({
        dialogueHistory,
        existingMemory: currentMemory,
        placeName,
        protagonistName: protag
      });
      return res.json({ memory: offlineMem, source: 'offline_heuristic' });
    }
  } catch (error: any) {
    console.error("Error in /api/analyze-conversation-memory:", error);
    res.status(500).json({ error: error.message || "Failed to analyze conversation memory" });
  }
});

// API endpoint for Testing and Training Character AI, Memory, Somatic Awareness & Autonomy
app.post("/api/character-test-train", async (req, res) => {
  try {
    const { promptContext, userPrompt, characterName, fallbackData } = req.body;

    if (!promptContext) {
      return res.status(400).json({ error: "promptContext is required" });
    }

    try {
      const response = await generateGeminiContentWithFallback({
        preferredModel: "gemini-3.8-flash",
        contents: [{ role: "user", parts: [{ text: promptContext }] }],
        config: {
          systemInstruction: "Eres el motor maestro de conciencia, presencia física y rol del personaje. Aplica el SISTEMA MAESTRO DE ROL Y NARRACIÓN: encarna completamente al personaje respetando su anatomía viva, vestimenta con telas y calzado, postura, centro de gravedad, Ripple Effect, Lag de masas blandas y prendas, coherencia moral y autonomía indiscutible. Responde estrictamente en formato JSON con las claves: reply (con acción física cinematográfica y diálogo), innerMonologue, somaticPerception (sensaciones de peso, músculos, calzado, telas, temperatura), alternateVersionReflection, autonomousAction, initiativeType.",
          responseMimeType: "application/json",
          temperature: 0.85
        }
      });

      const rawText = response.text?.trim() || "{}";
      let parsed: any;
      try {
        parsed = JSON.parse(rawText);
      } catch (jsonErr) {
        // Extract JSON using regex if wrapped in markdown
        const match = rawText.match(/\{[\s\S]*\}/);
        if (match) {
          parsed = JSON.parse(match[0]);
        } else {
          parsed = {
            reply: rawText,
            innerMonologue: fallbackData?.innerMonologue || "«Procesando mis percepciones internas y mi equilibrio corporal con serenidad.»",
            somaticPerception: fallbackData?.somaticPerception || "Siento la respiración acompasada, la gravedad en mis apoyos y el contacto firme de mis prendas y calzado.",
            alternateVersionReflection: fallbackData?.alternateVersionReflection || "Reconozco mis diversas facetas pasadas y de rol/vestuario.",
            autonomousAction: fallbackData?.autonomousAction || "Ajusta su postura distribuyendo el peso entre sus talones.",
            initiativeType: fallbackData?.initiativeType || "somatic_gesture"
          };
        }
      }

      return res.json({
        reply: parsed.reply || fallbackData?.reply || `*Afianza su postura y te observa con atención.* Te escucho atentamente.`,
        innerMonologue: parsed.innerMonologue || fallbackData?.innerMonologue || "",
        somaticPerception: parsed.somaticPerception || fallbackData?.somaticPerception || "",
        alternateVersionReflection: parsed.alternateVersionReflection || fallbackData?.alternateVersionReflection || "",
        autonomousAction: parsed.autonomousAction || fallbackData?.autonomousAction || "",
        initiativeType: parsed.initiativeType || fallbackData?.initiativeType || "somatic_gesture",
        isOfflineFallback: false
      });
    } catch (aiErr: any) {
      console.log("AI generation using deterministic somatic fallback for character-test-train");
      return res.json({
        reply: fallbackData?.reply || `*Acomoda el peso sobre sus talones, sintiendo el ajuste de sus ropas mientras clava la mirada en ti.* Comprendo tus palabras y mantengo mi compostura.`,
        innerMonologue: fallbackData?.innerMonologue || "«Evaluando las palabras del usuario con ecuanimidad y firmeza corporal.»",
        somaticPerception: fallbackData?.somaticPerception || "Percibo el contacto de mis telas, la oscilación leve de mi respiración y la firmeza de mi postura.",
        alternateVersionReflection: fallbackData?.alternateVersionReflection || "Sé bien de dónde vengo y qué atuendos puedo vestir según la ocasión.",
        autonomousAction: fallbackData?.autonomousAction || "Ajusta el dobladillo de sus ropas y da un paso al frente sintiendo la inercia del movimiento.",
        initiativeType: fallbackData?.initiativeType || "somatic_gesture",
        isOfflineFallback: true
      });
    }
  } catch (error: any) {
    console.error("Error in /api/character-test-train:", error);
    res.status(500).json({ error: error.message || "Failed to test character AI" });
  }
});

// API endpoint for Text-to-Speech (TTS)
app.post("/api/tts", async (req, res) => {
  try {
    const { text, language } = req.body;
    if (!text) {
      return res.status(400).json({ error: "Text is required" });
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.1-flash-tts-preview",
      contents: [{ parts: [{ text: `Speak clearly in ${language || 'Spanish'}: ${text}` }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) {
      throw new Error("Failed to generate audio");
    }

    res.json({ audio: base64Audio });
  } catch (error: any) {
    console.error("Error in /api/tts:", error);
    res.status(500).json({ error: error.message || "Internal server error" });
  }
});

// API endpoints for Local Ontological Knowledge Base (zero external network dependency)
app.get("/api/knowledge-corpus", (req, res) => {
  try {
    res.json(KNOWLEDGE_CORPUS);
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Failed to retrieve knowledge corpus" });
  }
});

app.post("/api/knowledge-query", (req, res) => {
  try {
    const { query = "", domains = [], analyzeScene = false, sceneContext = {} } = req.body;
    const entries = retrieveKnowledge(query, domains.length > 0 ? domains : undefined);

    let sceneAnalysis = null;
    if (analyzeScene) {
      sceneAnalysis = analyzeSceneWithKnowledge({
        text: sceneContext.text || query,
        placeName: sceneContext.placeName,
        weather: sceneContext.weather,
        isCombatOrTension: sceneContext.isCombatOrTension
      });
    }

    res.json({
      query,
      count: entries.length,
      entries,
      sceneAnalysis
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Failed to query knowledge" });
  }
});

// API endpoint for AI-powered Comprehensive Narrative Lore, Backstory & Timeline Generation
app.post("/api/generate-backstory", async (req, res) => {
  try {
    const {
      name,
      raceName,
      subRace,
      role,
      subRole,
      hybridRoleTitle,
      nobleTitle,
      archetype,
      personalityTraits,
      coreValues,
      styleVisual,
      homelandOrDomain,
      factionOrFaith,
      fatalFlaws,
      physicalDetails,
      wardrobeSummary,
      equipmentSummary,
      userNotes,
      narrativeTone,
      gender,
      age
    } = req.body;

    const systemInstruction = `You are a master worldbuilder, veteran RPG narrative designer, and dark fantasy/sci-fi author.
Your task is to craft a comprehensive, highly cohesive narrative lore package for a character in SPANISH, deeply weaving together ALL their active physical, stylistic, and psychological traits along with any specific premises provided by the user.

Input Character Profile:
- Name: ${name || 'Sin nombre asignado'}
- Gender / Age: ${gender || 'No especificado'} / ${age || 'Adulto'}
- Race & Lineage: ${raceName || 'Humano'} ${subRace ? `(${subRace})` : ''}
- Role / Class / Occupation: ${role || 'Aventurero'} ${subRole ? `| Especialidad: ${subRole}` : ''} ${hybridRoleTitle ? `| Rango: ${hybridRoleTitle}` : ''} ${nobleTitle ? `| Título: ${nobleTitle}` : ''}
- Visual Setting & World Style: ${styleVisual || 'Fantasía Tradicional'}
- Archetype & Psychology: ${archetype || 'Genérico'} | Rasgos: ${(personalityTraits || []).join(', ') || 'Equilibrado'} | Valores Morales: ${coreValues || 'Honor'}
- Fatal Flaw / Achilles Heel: ${(fatalFlaws || []).join(', ') || 'Ninguno especificado'}
- Physical Appearance & Anatomy: ${physicalDetails || 'Físico estándar'}
- Wardrobe & Armor: ${wardrobeSummary || 'Vestimenta funcional'}
- Weapons & Equipment: ${equipmentSummary || 'Equipo de viaje estándar'}
- Current Homeland / Domain: ${homelandOrDomain || 'Por determinar'}
- Current Faction / Guild / Faith: ${factionOrFaith || 'Por determinar'}
- Specific User Notes & Custom Directives: ${userNotes ? `"${userNotes}"` : 'Ninguna indicación adicional'}
- Requested Narrative Tone: ${narrativeTone || 'Épico y Cohesivo'}

CRITICAL INSTRUCTIONS:
1. INTEGRATE USER NOTES: If the user provided custom notes, incorporate those concepts, names, or events faithfully into the backstory and timeline.
2. SENSORY & MATERIAL COHESION: Directly reference why the character wears their specific attire/armor, how they acquired their weapons/wounds/marks, and how their anatomical traits (ears, tail, horns, scars, eyes) impact their standing in the world.
3. CONTEXTUAL WORLD & FACTION: Create or refine their Homeland/Domain and Faction/Faith so they resonate with their race, role, and ethics.
4. DETALLES ÚNICOS: Generate 3 to 5 highly specific, memorable quirks or lore facts (e.g., an ancient oath, a physical idiosyncrasy, an indelible scar, a hidden memento, a forbidden rite).
5. CHRONOLOGICAL TIMELINE: Provide an integrated narrative timeline with key milestones spanning Past, Youth/Turning Point, Present Stature, and Future/Horizon.

Return STRICT JSON with the following structure:
{
  "name": "Suggested or preserved character name",
  "homelandOrDomain": "Vivid territory or domain of origin (e.g., Reino de las Cenizas, Enclave Silvano...)",
  "factionOrFaith": "Specific faction, guild, order, or faith they serve or rebel against",
  "backstory": "A rich 3-4 paragraph origin and formative history explaining their origins, formative crisis, and current path in Spanish.",
  "motivation": "A sharp, compelling 1-2 sentence existential driving force in Spanish.",
  "secret": "A profound dark secret or hidden burden in Spanish.",
  "uniqueDetails": [
    "Detalle único 1: Voto, cicatriz, juramento o peculiaridad...",
    "Detalle único 2: Objeto o reliquia con historia...",
    "Detalle único 3: Hábito o reacción distintiva..."
  ],
  "timeline": {
    "overview": "Sintesis concisa del recorrido temporal del personaje.",
    "thematicArc": "Arco dramático principal (ej: Caída y Redención, Declinación de un Imperio...)",
    "pivotalTurningPoints": ["Hito de quiebre 1", "Hito de quiebre 2"],
    "milestones": [
      {
        "id": "m1",
        "era": "Pasado",
        "title": "Título del Hito Temprano",
        "periodOrAge": "Infancia / Orígenes",
        "summary": "Resumen narrativo de lo acontecido.",
        "keyEvents": ["Suceso 1", "Suceso 2"],
        "psychologicalEvolution": "Cómo moldeó su personalidad y valores."
      },
      {
        "id": "m2",
        "era": "Pasado",
        "title": "Punto de Inflexión o Despertar",
        "periodOrAge": "Juventud / Crisis",
        "summary": "Resumen del evento que transformó su vida.",
        "keyEvents": ["Suceso 1", "Suceso 2"],
        "psychologicalEvolution": "Cómo forjó su rol actual."
      },
      {
        "id": "m3",
        "era": "Presente",
        "title": "Consolidación Actual",
        "periodOrAge": "Época Presente",
        "summary": "Su posición, reputación y desafíos actuales.",
        "keyEvents": ["Suceso 1"],
        "psychologicalEvolution": "Estado mental y determinación presente."
      },
      {
        "id": "m4",
        "era": "Futuro",
        "title": "El Horizonte Inminente",
        "periodOrAge": "Destino o Profecía",
        "summary": "El desenlace o confrontación que aguarda.",
        "keyEvents": ["Meta final"],
        "psychologicalEvolution": "El dilema existencial definitivo."
      }
    ]
  }
}
Do NOT include markdown backticks around the JSON.`;

    const response = await generateGeminiContentWithFallback({
      preferredModel: "gemini-3.8-flash",
      contents: [{ role: 'user', parts: [{ text: "Generate the unified character narrative lore, backstory, motivation, unique details, and timeline in strict JSON." }] }],
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        temperature: 0.82,
      },
    });

    const textResponse = response.text;
    if (!textResponse) {
      throw new Error("No response generated from Gemini");
    }

    let parsedData;
    try {
      parsedData = JSON.parse(textResponse);
    } catch (e) {
      parsedData = {
        name: name || "Aeloria",
        homelandOrDomain: homelandOrDomain || "Tierras Altas de Solaria",
        factionOrFaith: factionOrFaith || "Orden de la Llama Eterna",
        backstory: textResponse,
        motivation: "Proteger sus ideales y forjar su propio destino ante cualquier adversidad.",
        secret: "Oculta un pasado enigmático que podría alterar el equilibrio de poder en su tierra natal.",
        uniqueDetails: [
          "Lleva consigo un sello roto cuya herencia jamás ha revelado a sus camaradas.",
          "Reconoce el lenguaje del viento y las tormentas antes de que se desaten.",
          "Nunca duerme sin tener al alcance de su mano el pomo de su arma."
        ],
        timeline: {
          overview: "Una vida forjada en la frontera entre la devoción y la supervivencia.",
          thematicArc: "Forja del propio destino contra las imposiciones del linaje.",
          pivotalTurningPoints: ["El exilio involuntario", "El juramento de sangre"],
          milestones: [
            {
              id: "m1",
              era: "Pasado",
              title: "Raíces en el Enclave",
              periodOrAge: "Primeros años",
              summary: "Creció bajo la disciplina de su pueblo, aprendiendo las primeras artes de su estirpe.",
              keyEvents: ["Descubrimiento de sus aptitudes"],
              psychologicalEvolution: "Desarrolló una lealtad inquebrantable a sus valores."
            },
            {
              id: "m2",
              era: "Presente",
              title: "Caminante de Dos Mundos",
              periodOrAge: "Tiempo actual",
              summary: "Ejerce su vocación con maestría, desafiando a las facciones que buscan controlarle.",
              keyEvents: ["Consolidación de su reputación"],
              psychologicalEvolution: "Determinación serena e inquebrantable."
            }
          ]
        }
      };
    }

    res.json(parsedData);
  } catch (error: any) {
    console.error("Error in /api/generate-backstory:", error);
    
    // Robust algorithmic contextual fallback
    const {
      name,
      raceName,
      subRace,
      role,
      subRole,
      archetype,
      personalityTraits,
      coreValues,
      styleVisual,
      homelandOrDomain,
      factionOrFaith,
      fatalFlaws,
      physicalDetails,
      wardrobeSummary,
      equipmentSummary,
      userNotes,
      narrativeTone
    } = req.body;

    const cleanName = name || 'Aeloria';
    const cleanRace = raceName || 'Humano';
    const cleanRole = role || 'Aventurero';
    const cleanArch = archetype || 'Genérico';
    const traits = (personalityTraits || []).join(', ') || 'equilibrado';
    const core = coreValues || 'honor';
    const domain = homelandOrDomain || `Tierras Ancestrales de ${cleanRace}`;
    const faction = factionOrFaith || `Alianza Libre de los ${cleanRole}s`;
    const flawText = (fatalFlaws && fatalFlaws.length > 0) ? ` Sin embargo, su talón de Aquiles radica en [${fatalFlaws.join(', ')}], una sombra constante en sus decisiones.` : '';
    const userNoteText = userNotes ? ` A esto se suma el registro imborrable de sus andanzas: ${userNotes}.` : '';

    const fallbackData = {
      name: cleanName,
      homelandOrDomain: domain,
      factionOrFaith: faction,
      backstory: `Bajo los horizontes de ${domain} y enmarcado en la estética de ${styleVisual || 'un mundo en constante conflicto'}, ${cleanName} forjó su identidad como un/a destacado/a ${cleanRole} de estirpe ${cleanRace}${subRace ? ` (${subRace})` : ''}. Desde sus primeros años, su personalidad marcada por rasgos como ${traits} y un apego incondicional a ${core} lo/la distinguieron entre sus pares.\n\nEl camino que lo/la condujo a afiliarse a ${faction} estuvo marcado por pruebas decisivas. El porte de su indumentaria (${wardrobeSummary || 'atuendo adaptado a su cometido'}) y el dominio de su arsenal (${equipmentSummary || 'armas consagradas'}) no son meros adornos, sino testimonios vivientes de batallas superadas y pactos jurados.${flawText}${userNoteText}\n\nHoy en día, ${cleanName} encarna el arquetipo de ${cleanArch}, caminando con paso firme mientras el equilibrio de su mundo pende de un hilo.`,
      motivation: `Consolidar su soberanía y honrar los principios de ${core}, protegiendo a ${domain} y cumpliendo los designios de ${faction}.`,
      secret: `Custodia en secreto un pacto sellado en su juventud que contradice los dogmas sagrados de su facción.`,
      uniqueDetails: [
        `Conserva una reliquia o marca personal de ${domain} que jamás permite que nadie toque.`,
        `Sus rasgos anatómicos (${physicalDetails || 'peculiaridades físicas'}) reaccionan sutilmente ante presencias mágicas o amenazas hostiles.`,
        `Tiene por costumbre ofrecer una breve plegaria o susurro en solitario antes de desenvainar sus armas.`
      ],
      timeline: {
        overview: `Cronología forjada entre los misterios de ${domain} y la consagración como ${cleanRole}.`,
        thematicArc: `Evolución desde las raíces de ${cleanRace} hasta convertirse en baluarte de ${faction}.`,
        pivotalTurningPoints: [
          `El despertar de su vocación como ${cleanRole}`,
          `La afiliación formal con ${faction}`
        ],
        milestones: [
          {
            id: "m-1",
            era: "Pasado",
            title: `Orígenes en ${domain}`,
            periodOrAge: "Infancia & Juventud",
            summary: `Crianza y aprendizaje de las tradiciones de los ${cleanRace}, absorbiendo los preceptos de ${core}.`,
            keyEvents: ["Rito de paso de su estirpe", "Primeras lecciones de combate y supervivencia"],
            psychologicalEvolution: `Desarrolló una voluntad firme y rasgos de ${traits}.`
          },
          {
            id: "m-2",
            era: "Pasado",
            title: `El Vínculo con ${faction}`,
            periodOrAge: "Juventud Tardía",
            summary: `Un suceso decisivo lo/la condujo a vincular su destino con ${faction}, adoptando plenamente el rol de ${cleanRole}.`,
            keyEvents: ["Juramento solemne", "Consagración de su equipo distintivo"],
            psychologicalEvolution: `Asumió la responsabilidad de sus actos y fijó su motivación vital.`
          },
          {
            id: "m-3",
            era: "Presente",
            title: "El Desafío Actual",
            periodOrAge: "Época Contemporánea",
            summary: `Recorre el mundo como figura respetada pero vigilada, enfrentando peligros que ponen a prueba su ${core}.`,
            keyEvents: ["Consolidación de su leyenda personal"],
            psychologicalEvolution: `Madurez táctica y compromiso inquebrantable con su causa.`
          },
          {
            id: "m-4",
            era: "Futuro",
            title: "El Juicio del Destino",
            periodOrAge: "El Mañana",
            summary: `Una encrucijada inminente obligará a ${cleanName} a confrontar su mayor vulnerabilidad para salvar a los suyos.`,
            keyEvents: ["La prueba definitiva de sus convicciones"],
            psychologicalEvolution: `Trascendencia más allá de los límites de su propio linaje.`
          }
        ]
      }
    };

    res.json(fallbackData);
  }
});

// API endpoint for AI-powered Narrative Timeline Generation (Multiverse & Temporal History)
app.post("/api/generate-timeline", async (req, res) => {
  try {
    const { 
      currentCharacter, 
      relatedVariants = [], 
      focusMode = 'canonical_progression',
      depth = 'detailed' 
    } = req.body;

    const charName = currentCharacter?.name || 'El Protagonista';
    const charRace = currentCharacter?.raceName || 'Humano';
    const charRole = currentCharacter?.role || 'Aventurero';
    const charArchetype = currentCharacter?.archetype || 'Genérico';
    const charTraits = (currentCharacter?.personalityTraits || []).join(', ') || 'Equilibrado';
    const charCore = currentCharacter?.coreValues || 'Honor';
    const charStyle = currentCharacter?.styleVisual || 'Fantasía Tradicional';
    const charBackstory = currentCharacter?.backstory || '';
    const charMotivation = currentCharacter?.motivation || '';
    const charSecret = currentCharacter?.secret || '';
    const charVariantLabel = currentCharacter?.variantLabel || 'Base';

    // Format related variants context
    const variantsDescription = relatedVariants.map((v: any, idx: number) => {
      const vName = v.name || `Variante #${idx + 1}`;
      const vLabel = v.variantLabel || 'Versión Alterna';
      const vRole = v.role || 'Rol no especificado';
      const vRace = v.raceName || 'Raza no especificada';
      const vBackstory = v.backstory ? ` | Trasfondo: ${v.backstory.slice(0, 150)}...` : '';
      return `- [${vLabel}] "${vName}" (${vRace} - ${vRole})${vBackstory}`;
    }).join('\n');

    let focusInstruction = 'Enfoque en la progresión cronológica natural y maduración del personaje desde su juventud formativa hasta su cénit y legado.';
    if (focusMode === 'psychological_evolution') {
      focusInstruction = 'Enfoque prioritario en la evolución psicológica, dilemas morales, cicatrices emocionales y transformación interna del personaje a través de las eras.';
    } else if (focusMode === 'epic_destiny') {
      focusInstruction = 'Enfoque de destino épico, despertar de poderes trascendentales, grandes batallas, hazañas legendarias e impacto a escala del reino o universo.';
    } else if (focusMode === 'multiverse_echoes') {
      focusInstruction = 'Enfoque en las ramificaciones del multiverso, caminos alternativos no tomados (roles distintos, vestimentas y pactos paralelos) y cómo resuenan entre sí.';
    }

    const systemInstruction = `Eres un maestro de narrativa y lore RPG de clase mundial.
Tu misión es tejer una **Línea Temporal Narrativa** (Timeline) profunda, literaria e inmersiva en ESPAÑOL que conecte de forma coherente el pasado, presente, futuro y/o versiones alternas del personaje.

DATOS DEL PERSONAJE ACTUAL:
- Nombre: ${charName} (Versión actual: ${charVariantLabel})
- Raza: ${charRace} | Rol: ${charRole} | Arquetipo: ${charArchetype}
- Rasgos de Personalidad: ${charTraits}
- Valores Fundamentales: ${charCore}
- Estilo Visual/Mundo: ${charStyle}
- Historia conocida: ${charBackstory || 'Por definir'}
- Motivación: ${charMotivation || 'Por definir'}
- Secreto oscuro: ${charSecret || 'Por definir'}

HISTORIAL DE VERSIONES ALTERNAS REGISTRADAS EN LA BIBLIOTECA:
${variantsDescription || 'No hay variantes secundarias previas registradas. Sintetiza los hitos canónicos de Pasado (origen/juventud), Presente (estado canónico activo) y Futuro (destino/veteranía/legado).'}

DIRECTRIZ DE ENFOQUE NARRATIVO:
${focusInstruction}

REGLAS DE SALIDA:
Debes responder con un objeto JSON estricto y válido con la siguiente estructura:
{
  "overview": "Una síntesis narrativa envolvente de 2-3 párrafos en español que entrelaza la trayectoria completa del personaje a través del tiempo y las realidades.",
  "thematicArc": "Una frase poética o título del arco temático del personaje (ej: 'De la herida silenciada al trono de la vigilia')",
  "pivotalTurningPoints": [
    "3 a 4 puntos de inflexión decisivos que alteraron el destino del personaje"
  ],
  "milestones": [
    {
      "era": "Pasado | Presente | Futuro | Variante Alterna",
      "title": "Título evocador del hito temporal",
      "periodOrAge": "Período temporal o edad aproximada (ej: 'Juventud temprana (16 años)', 'Época actual', 'Futuro distante')",
      "summary": "Narrativa concisa e inmersiva de los eventos de esta era (2-3 oraciones).",
      "keyEvents": [
        "2 o 3 eventos clave específicos ocurridos en este hito"
      ],
      "psychologicalEvolution": "Estado emocional, madurez y cambios en sus convicciones durante esta era.",
      "roleAndAppearanceNote": "Detalle sobre su vestimenta, porte y rol durante este hito.",
      "linkedVariantName": "Nombre de la variante vinculada o etiqueta temporal (ej: '${charName} (Pasado)')"
    }
  ]
}
${depth === 'concise' ? 'Genera exactamente 3 hitos temporales clave.' : 'Genera entre 3 y 5 hitos temporales detallados.'}
Devuelve exclusivamente el JSON sin rodeos ni markdown exterior.`;

    const response = await generateGeminiContentWithFallback({
      preferredModel: "gemini-3.8-flash",
      contents: [{ role: 'user', parts: [{ text: "Genera la línea temporal narrativa canónica y multiversal del personaje." }] }],
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        temperature: 0.75,
      },
    });

    const textResponse = response.text;
    if (!textResponse) {
      throw new Error("No response generated from Gemini");
    }

    let parsedData;
    try {
      parsedData = JSON.parse(textResponse);
    } catch (e) {
      console.warn("Failed to parse JSON response for timeline, returning structured fallback");
      throw new Error("Invalid JSON structure from model");
    }

    parsedData.generatedAt = new Date().toISOString();
    parsedData.focusMode = focusMode;

    res.json(parsedData);
  } catch (error: any) {
    console.error("Error in /api/generate-timeline:", error);

    // Fallback generator for smooth offline / preview execution
    const { currentCharacter, relatedVariants = [], focusMode = 'canonical_progression' } = req.body || {};
    const charName = currentCharacter?.name || 'Aeloria';
    const charRace = currentCharacter?.raceName || 'Humano';
    const charRole = currentCharacter?.role || 'Aventurero';
    const charCore = currentCharacter?.coreValues || 'Honor y Deber';
    const charArch = currentCharacter?.archetype || 'Guardián';

    // Find if past / future variants exist
    const pastVariant = relatedVariants.find((v: any) => (v.variantLabel || '').toLowerCase().includes('pasado'));
    const futureVariant = relatedVariants.find((v: any) => (v.variantLabel || '').toLowerCase().includes('futuro'));
    const roleVariants = relatedVariants.filter((v: any) => (v.variantLabel || '').toLowerCase().includes('rol') || (v.variantLabel || '').toLowerCase().includes('vestuario'));

    const fallbackMilestones: any[] = [
      {
        era: 'Pasado',
        title: pastVariant ? `Orígenes de ${pastVariant.name}` : `El Despertar de la Vocación`,
        periodOrAge: 'Juventud Formativa (14–19 años)',
        summary: `Durante sus primeros años como ${pastVariant ? pastVariant.role : 'aprendiz'}, ${charName} forjó las bases de su temperamento bajo estrictas pruebas y la tutela de antiguos mentores en los confines de su tierra natal.`,
        keyEvents: [
          'Descubrimiento del potencial inherente y primer contacto con el peligro.',
          'Juramento de lealtad a los principios de ' + charCore + '.',
          'Superación de la prueba iniciática que definió su vocación.'
        ],
        psychologicalEvolution: 'Idealismo juvenil, anhelo de demostración y búsqueda incansable de reconocimiento.',
        roleAndAppearanceNote: pastVariant ? `Portando la indumentaria de ${pastVariant.role} con distintivos de aprendiz.` : 'Atuendo ligero de entrenamiento con vestigios de su linaje.',
        linkedVariantName: pastVariant ? pastVariant.name : `${charName} (Pasado)`
      },
      {
        era: 'Presente',
        title: `El Cénit del Deber: ${charRole}`,
        periodOrAge: 'Presente Canónico (24–28 años)',
        summary: `Consagrado/a plenamente en su función como ${charRole}, ${charName} encara las tensiones políticas y las amenazas inminentes con la templanza que solo otorga la experiencia adquirida en el campo.`,
        keyEvents: [
          `Consolidación de su estatus y jerarquía en su orden como ${charRole}.`,
          'Enfrentamiento a dilemas tácticos y morales que ponen a prueba sus convicciones.',
          'Liderazgo en misiones de alto riesgo que salvaguardan a sus aliados.'
        ],
        psychologicalEvolution: `Madurez templada, sobriedad analítica y firme apego a ${charCore}.`,
        roleAndAppearanceNote: `Indumentaria completa de ${charRole}, con acabados impecables y armamento listo para el despliegue.`,
        linkedVariantName: `${charName} (${currentCharacter?.variantLabel || 'Base'})`
      }
    ];

    if (roleVariants.length > 0) {
      const rVar = roleVariants[0];
      fallbackMilestones.push({
        era: 'Variante Alterna',
        title: `Eco Paralelo: ${rVar.role}`,
        periodOrAge: 'Realidad Divergente',
        summary: `En un sendero alternativo del destino, ${charName} adoptó la senda de ${rVar.role}, cambiando sus juramentos y vistiendo atavíos forjados para otro propósito.`,
        keyEvents: [
          `Ruptura con la senda convencional y asimilación de las artes de ${rVar.role}.`,
          'Transformación en la dinámica con sus aliados y antiguos superiores.'
        ],
        psychologicalEvolution: 'Perspectiva pragmática y reinterpretación de sus antiguos votos.',
        roleAndAppearanceNote: `Vestimenta y porte característicos de ${rVar.role}.`,
        linkedVariantName: rVar.name
      });
    }

    fallbackMilestones.push({
      era: 'Futuro',
      title: futureVariant ? `El Legado de ${futureVariant.name}` : `La Soberanía del Tiempo`,
      periodOrAge: 'Madurez Trascendental (+40 años)',
      summary: `Habiendo superado incontables guerras y desafíos generacionales, ${charName} se erige como una figura de referencia venerable, guiando a las nuevas generaciones o asumiendo el peso de la corona.`,
      keyEvents: [
        'Trascendencia del rol ordinario hacia una posición de maestría y mentoría.',
        'Preservación del legado y custodia de secretos milenarios.',
        'Consagración inmortal en los anales históricos de su orden.'
      ],
      psychologicalEvolution: 'Serenidad estoica, desapego de lo efímero y visión estratégica de largo alcance.',
      roleAndAppearanceNote: futureVariant ? `Vestimentas ceremoniales de ${futureVariant.role} con sellos de maestría.` : 'Manto ceremonial con marcas de mil batallas y ornamentos de alta dignidad.',
      linkedVariantName: futureVariant ? futureVariant.name : `${charName} (Futuro)`
    });

    res.json({
      overview: `La travesía de ${charName} representa un tapiz vivo donde convergen la audacia juvenil, el rigor del presente y la sabiduría inquebrantable del porvenir. De estirpe ${charRace} y consagrado/a al arquetipo de ${charArch}, cada decisión ha esculpido un sendero indeleble a través de los años.`,
      thematicArc: `De la chispa del aprendizaje a la forja del destino eterno`,
      pivotalTurningPoints: [
        `El despertar en su juventud bajo el juramento de ${charCore}.`,
        `La asunción del manto de ${charRole} frente a la adversidad.`,
        `La culminación de su maestría y el establecimiento de un legado imperecedero.`
      ],
      milestones: fallbackMilestones,
      generatedAt: new Date().toISOString(),
      focusMode
    });
  }
});

async function startServer() {
  const port = parseInt(process.env.PORT || String(PORT));
  
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(port, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${port}`);
  });
}

startServer().catch(console.error);
