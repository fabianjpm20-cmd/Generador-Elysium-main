const fs = require('fs');
let data = fs.readFileSync('src/data.ts', 'utf8');

// Replace getWardrobeOptions return with the new attributes
const newReturn = `
  // LOCATION
  let location = ['Cuerpo Completo', 'Mitad Superior', 'Mitad Inferior', 'Asimétrico'];
  if (isShoes) location = ['Pies', 'Tobillos', 'Piernas'];
  if (isAcc) location = ['Cabeza', 'Cuello', 'Pecho', 'Brazos', 'Muñecas', 'Manos', 'Cintura', 'Piernas', 'Tobillos'];
  if (isBra || isTop) location = ['Torso', 'Pecho', 'Hombros'];
  if (isBottom) location = ['Cintura', 'Cadera', 'Piernas', 'Rodillas'];

  // PATTERN
  let pattern = ['Liso / Sólido', 'Rayas', 'Cuadros / Tartán', 'Lunares', 'Floral', 'Geométrico', 'Animal Print', 'Logotipo / Texto', 'Camuflaje', 'Degradado / Ombré'];

  return { cut, length, sleeve, material, finish, details, variation, layer, location, pattern };
}
`;

data = data.replace(
  /  return \{ cut, length, sleeve, material, finish, details, variation, layer \};\n\}/,
  newReturn
);

fs.writeFileSync('src/data.ts', data);
