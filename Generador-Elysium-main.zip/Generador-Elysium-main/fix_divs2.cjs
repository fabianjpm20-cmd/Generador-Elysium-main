const fs = require('fs');
let data = fs.readFileSync('src/components/State2Anatomy.tsx', 'utf8');

data = data.replace(/<\/div>\n\s*<\/div>\n\s*<\/div>\n\s*<\/div>\n\s*\)\}\n\n\s*\{\/\* Navigation buttons \*\/\}/, 
  "              </div>\n            </div>\n          </div>\n        </div>\n      </div>\n      )}\n\n      {/* Navigation buttons */}");

fs.writeFileSync('src/components/State2Anatomy.tsx', data);
