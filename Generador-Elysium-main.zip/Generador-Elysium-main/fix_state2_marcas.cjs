const fs = require('fs');
let data = fs.readFileSync('src/components/State2Anatomy.tsx', 'utf8');

const replacement = `
              <div className="space-y-4 pt-6">
                <h3 className="text-lg font-serif italic text-[#C9A050] mb-2 border-b border-[#222222] pb-2">A.2.4.5 Marcas y Rasgos Singulares</h3>
                
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Tipo de Marca <InfoTooltip text="Tatuajes, cicatrices, sellos, runas o características singulares del personaje." /></label>
                  <select value={state.appendices.markType} onChange={(e) => updateApp('markType', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {MARK_TYPES.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>

                {state.appendices.markType !== 'Ninguna' && (
                  <>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs text-[#888888] mb-1">Forma / Motivo</label>
                        <select value={state.appendices.markShape} onChange={(e) => updateApp('markShape', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                          {MARK_SHAPES.map(o => <option key={o} value={o}>{o}</option>)}
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs text-[#888888] mb-1">Ubicación</label>
                        <select value={state.appendices.skinMarksLocation} onChange={(e) => updateApp('skinMarksLocation', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                          {MARK_LOCATIONS.map(o => <option key={o} value={o}>{o}</option>)}
                        </select>
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs text-[#888888] mb-1">Color / Apariencia Visual</label>
                      <select value={state.appendices.skinMarksColor} onChange={(e) => updateApp('skinMarksColor', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                        {MARK_COLORS.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                    </div>
                  </>
                )}
              </div>
`;

data = data.replace(
  /\<div className="space-y-4 pt-6"\>\n\s*\<h3 className="text-lg font-serif italic text-\[\#C9A050\] mb-2 border-b border-\[\#222222\] pb-2"\>A\.2\.4\.5 Marcas\<\/h3\>[\s\S]*?\<\/div\>\n\s*\<\/div\>\n\s*\<\/div\>/,
  replacement.trim() + "\n            </div>\n          </div>"
);

fs.writeFileSync('src/components/State2Anatomy.tsx', data);
