#!/bin/bash
# =========================================================================
# SCRIPT PARA EJECUTAR ELYSIUM NEURAL (VERSIÓN WEB)
# =========================================================================
# Este script abre el archivo elysium-simple.html en el navegador por defecto
# No requiere Node.js, npm ni conocimientos de programación
# 
# Uso: ./ejecutar-elysium.sh
# =========================================================================

# Obtener la ruta del script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HTML_FILE="$SCRIPT_DIR/public/elysium-simple.html"

# Verificar si el archivo existe
if [ ! -f "$HTML_FILE" ]; then
    echo "========================================================================="
    echo "  ERROR: No se encontró el archivo elysium-simple.html"
    echo "========================================================================="
    echo ""
    echo "Asegúrate de que el archivo esté en la ubicación correcta:"
    echo "  $HTML_FILE"
    echo ""
    exit 1
fi

# Intentar abrir con xdg-open (Linux)
if command -v xdg-open &> /dev/null; then
    xdg-open "$HTML_FILE" &
    NAVEGADOR="xdg-open"
# Intentar con open (macOS)
elif command -v open &> /dev/null; then
    open "$HTML_FILE" &
    NAVEGADOR="open"
# Intentar con start (Windows/WSL)
elif command -v start &> /dev/null; then
    start "$HTML_FILE"
    NAVEGADOR="start"
else
    echo "========================================================================="
    echo "  ERROR: No se encontró un comando para abrir el navegador"
    echo "========================================================================="
    echo ""
    echo "Intenta abrir manualmente el archivo:"
    echo "  $HTML_FILE"
    echo ""
    exit 1
fi

# Mostrar mensaje de confirmación
echo ""
echo "========================================================================="
echo "  Elysium Neural - Aplicación de Chat de Rolplay"
echo "========================================================================="
echo ""
echo "Se ha abierto Elysium Neural en tu navegador por defecto usando: $NAVEGADOR"
echo ""
echo "Si el navegador no se abre automáticamente, abre manualmente:"
echo "  $HTML_FILE"
echo ""
echo "========================================================================="
echo "  Controles:"
echo "========================================================================="
echo ""
echo "  - Selecciona un personaje de la lista para empezar a chatear"
echo "  - Escribe tu mensaje en el campo de texto y presiona Enter"
echo "  - Usa los botones de acciones rápidas para enviar mensajes predefinidos"
echo "  - Crea nuevos personajes y lugares con el botón 'Nuevo'"
echo "  - Todos los datos se guardan automáticamente en tu navegador"
echo ""
echo "========================================================================="
echo ""
