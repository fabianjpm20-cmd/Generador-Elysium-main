const fs = require('fs');
let data = fs.readFileSync('src/components/State6Compilation.tsx', 'utf8');

const regex = /\(w\.details && w\.details\.length > 0\) \? \`Details: \$\{\(Array\.isArray\(w\.details\) \? w\.details\.map\(cleanVal\)\.join\(', '\) : cleanVal\(w\.details\)\)\}\$\{\(w\.location && w\.location\.length > 0\) \? ' \(' \+ \(Array\.isArray\(w\.location\) \? w\.location\.map\(cleanVal\)\.join\(', '\) : cleanVal\(w\.location\)\) \+ '\)' : ''\}\` : '',/;

const newLogic = `(w.details && w.details.length > 0) ? \`Details: \${w.details.map(d => {
          const locs = w.detailLocations && w.detailLocations[d];
          if (locs && locs.length > 0) {
            return \`\${cleanVal(d)} (\${locs.map(cleanVal).join(', ')})\`;
          }
          return cleanVal(d);
        }).join(', ')}\` : '',`;

data = data.replace(regex, newLogic);
fs.writeFileSync('src/components/State6Compilation.tsx', data);
