const fs = require('fs');
let content = fs.readFileSync('src/components/State6Compilation.tsx', 'utf8');

const replacement = `      const parts = [
        w.cut ? \`Cut: \${cleanVal(w.cut)}\` : '',
        w.length ? \`Length: \${cleanVal(w.length)}\` : '',
        w.sleeve ? \`Sleeve: \${cleanVal(w.sleeve)}\` : '',
        w.material ? \`Material: \${cleanVal(w.material)}\` : '',
        w.color ? \`Color: \${w.color}\` : '',
        w.finish ? \`Finish: \${cleanVal(w.finish)}\` : '',
        w.details ? \`Details: \${cleanVal(w.details)}\` : '',
        w.variation ? \`Variation: \${cleanVal(w.variation)}\` : '',
        w.layer ? \`Layer: \${cleanVal(w.layer)}\` : ''
      ].filter(Boolean).join(', ');
      
      return \`\${w.name} \${desc ? \`(\${desc})\` : ''} [\${parts}]\`;`;

content = content.replace(
  /return \`\$\{w\.name\}.*?replace\(\/Sleeve: , \/g, ''\);/,
  replacement
);

fs.writeFileSync('src/components/State6Compilation.tsx', content);
