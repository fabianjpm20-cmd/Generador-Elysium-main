const fs = require('fs');
let data = fs.readFileSync('src/components/State3Wardrobe.tsx', 'utf8');

data = data.replace(
  /layer: opts\.layer\[0\] \|\| '',\n    \}\);/,
  "layer: opts.layer[0] || '',\n      location: opts.location ? opts.location[0] || '' : '',\n      pattern: opts.pattern ? opts.pattern[0] || '' : '',\n      patternDetail: '',\n      emblem: opts.emblem ? opts.emblem[0] || 'Ninguno' : 'Ninguno',\n      vfx: opts.vfx ? opts.vfx[0] || 'Ninguno' : 'Ninguno'\n    });"
);

data = data.replace(
  /pattern: newOpts\.pattern\.includes\(prev\.pattern\) \? prev\.pattern : \(newOpts\.pattern\[0\] \|\| ''\),/,
  "pattern: newOpts.pattern.includes(prev.pattern) ? prev.pattern : (newOpts.pattern[0] || ''),\n                        patternDetail: '',"
);

fs.writeFileSync('src/components/State3Wardrobe.tsx', data);
