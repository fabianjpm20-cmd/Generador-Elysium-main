const fs = require('fs');
let data = fs.readFileSync('src/components/State6Compilation.tsx', 'utf8');

data = data.replace(
  /cleanVal\(state\.anatomy\.sexBase\) \? \`sex base \$\{cleanVal\(state\.anatomy\.sexBase\)\} \(\$\{ANATOMY_DESCRIPTIONS\[state\.anatomy\.sexBase\] \|\| ''\}\)\` : '',/,
  "cleanVal(state.anatomy.sexBase) ? `sex base ${cleanVal(state.anatomy.sexBase)} (${ANATOMY_DESCRIPTIONS[state.anatomy.sexBase] || ''})` : '',\n      cleanVal(state.anatomy.age) ? `age ${cleanVal(state.anatomy.age)} (${ANATOMY_DESCRIPTIONS[state.anatomy.age] || ''})` : '',"
);

data = data.replace(
  /\{cleanVal\(state\.anatomy\.sexBase\)\}, \{cleanVal\(state\.anatomy\.complexion\)\},/,
  "{cleanVal(state.anatomy.sexBase)}, {cleanVal(state.anatomy.age)}, {cleanVal(state.anatomy.complexion)},"
);

fs.writeFileSync('src/components/State6Compilation.tsx', data);
