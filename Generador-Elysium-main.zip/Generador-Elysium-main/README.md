# Generador Elysium

Plataforma integral de creaci\u00f3n de personajes, simulaci\u00f3n narrativa determinista y agentes aut\u00f3nomos offline.

## Caracter\u00edsticas

- Creaci\u00f3n de personajes complejos con sistema de razas, anatom\u00eda, vestuario y roles
- Simulaci\u00f3n narrativa con agentes aut\u00f3nomos
- Motor de memoria de conversaci\u00f3n para interacciones coherentes
- Biblioteca de conocimiento local para an\u00e1lisis de escenas
- Soporta m\u00faltiples modelos de IA con fallback inteligente
- PWA (Progressive Web App) para instalaci\u00f3n offline

## Requisitos

- Node.js >= 18.0.0
- npm >= 9.0.0
- API Key de Google Gemini (opcional, para funcionalidades de IA)

## Instalaci\u00f3n

```bash
# Clonar el repositorio
git clone https://github.com/fabianjpm20-cmd/Generador-Elysium.git
cd Generador-Elysium

# Instalar dependencias
npm install

# Configurar variables de entorno
cp .env.example .env
# Editar .env con tu API Key de Gemini
```

## Uso

### Desarrollo

```bash
# Iniciar servidor de desarrollo
npm run dev

# Acceder a http://localhost:3000
```

### Producci\u00f3n

```bash
# Construir la aplicaci\u00f3n
npm run build

# Iniciar servidor de producci\u00f3n
npm start

# O usar el script de inicio
./run.sh [puerto]
```

### Builds separados

```bash
# Construir solo el cliente
npm run build:client

# Construir solo el servidor
npm run build:server
```

## Variables de Entorno

| Variable | Descripci\u00f3n | Valor por defecto |
|----------|------------------|-------------------|
| GEMINI_API_KEY | API Key de Google Gemini | (requerido para IA) |
| APP_URL | URL de la aplicaci\u00f3n | http://localhost:3000 |
| NODE_ENV | Entorno de ejecuci\u00f3n | development |
| PORT | Puerto del servidor | 3000 |

## Estructura del Proyecto

```
generador-elysium/
├── src/
│   ├── components/       # Componentes React
│   ├── data/            # Datos est\u00e1ticos y presets
│   ├── hooks/           # Custom hooks
│   ├── services/        # Servicios y l\u00f3gica de negocio
│   ├── utils/           # Utilidades y motores
│   ├── App.tsx          # Componente principal
│   └── main.tsx         # Punto de entrada
├── server.ts            # Servidor Express + Vite
├── vite.config.ts       # Configuraci\u00f3n de Vite
├── package.json         # Dependencias y scripts
└── dist/               # Build de producci\u00f3n (generado)
```

## Scripts Disponibles

| Script | Descripci\u00f3n |
|--------|------------------|
| `npm run dev` | Inicia servidor de desarrollo |
| `npm run build` | Construye cliente y servidor |
| `npm run build:client` | Construye solo el cliente |
| `npm run build:server` | Construye solo el servidor |
| `npm start` | Inicia servidor de producci\u00f3n |
| `npm run preview` | Vista previa del build |
| `npm run clean` | Elimina carpeta dist |
| `npm run lint` | Verifica tipos TypeScript |

## Tecnolog\u00edas

- **Frontend**: React 19, TypeScript, Tailwind CSS v4
- **Backend**: Express, Vite
- **IA**: Google GenAI (Gemini)
- **PWA**: Vite Plugin PWA
- **Bundler**: Vite + esbuild

## Optimizaciones

- Chunking manual para reducir tama\u00f1o de bundles
- Compresi\u00f3n Gzip integrada
- Cache de Service Worker para PWA
- Fallback inteligente entre modelos de IA
- Minificaci\u00f3n con esbuild

## Contribuir

1. Hacer fork del repositorio
2. Crear una rama con la nueva funcionalidad
3. Hacer commit de los cambios
4. Push a la rama
5. Abrir un Pull Request

## Licencia

MIT
