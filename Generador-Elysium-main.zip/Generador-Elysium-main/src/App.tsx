import React, { useState } from 'react';
import {
  CharacterState,
  MainScreen,
  WorldPlace,
  WorldBuildingConfig
} from './types';
import { Header } from './components/Header';
import { HomeScreen } from './components/HomeScreen';
import { UnifiedLibraryScreen } from './components/UnifiedLibraryScreen';
import { CreationHubScreen } from './components/CreationHubScreen';
import { UnifiedInteractionScreen } from './components/UnifiedInteractionScreen';

// Detailed Step Wizard Components for Creation
import { State1Raza } from './components/State1Raza';
import { State2Anatomy } from './components/State2Anatomy';
import { State3Wardrobe } from './components/State3Wardrobe';
import { State4RoleArmor } from './components/State4RoleArmor';
import { State5Background } from './components/State5Background';
import { State7Compilation } from './components/State7Compilation';

// Modals
import { QuickCreationModal } from './components/QuickCreationModal';
import { NsfwModal } from './components/NsfwModal';
import { PWAInstallModal } from './components/PWAInstallModal';
import { OfflineIndicator } from './components/OfflineIndicator';

// Synchronization hook and utilities
import { useModuloSync } from './hooks/useModuloSync';
import { createDefaultCharacterState } from './utils/libraryStorage';
import { createEmptyPlace, createEmptyWorldBuilding } from './utils/worldStorage';

export default function App() {
  // Screen 1: 'home', Screen 2: 'library', Screen 3: 'creation', Screen 4: 'interaction'
  const [currentScreen, setCurrentScreen] = useState<MainScreen>('home');

  // Context-aware Creation target ('character' | 'places' | 'worldbuilding')
  const [creationTarget, setCreationTarget] = useState<'character' | 'places' | 'worldbuilding'>('character');
  const [editingPlace, setEditingPlace] = useState<WorldPlace | null>(null);
  const [editingWorldConfig, setEditingWorldConfig] = useState<WorldBuildingConfig | null>(null);

  // Unified reactive sync hook across all modules
  const {
    characterState,
    updateCharacterState: setCharacterState,
    protagonistCharacter,
    updateProtagonist: setProtagonistCharacter,
    savedCharacters,
    activePlace,
    updateActivePlace: setActivePlace,
    savedPlaces,
    worldConfig,
    updateWorldConfig: setWorldConfig,
    saveToLibrary,
    triggerGlobalSync
  } = useModuloSync({ source: 'creation' });

  // Creation wizard step (when using full wizard in Screen 3)
  const [creationStep, setCreationStep] = useState<number>(1);

  // Modals
  const [isQuickCreationOpen, setIsQuickCreationOpen] = useState<boolean>(false);
  const [isNsfwModalOpen, setIsNsfwModalOpen] = useState<boolean>(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState<boolean>(false);

  const handleApplyQuickCharacter = (generatedState: CharacterState) => {
    saveToLibrary(generatedState);
    setCurrentScreen('interaction');
  };

  const handleSelectCharacterForInteraction = (char: CharacterState) => {
    if (char) {
      setCharacterState(char);
      setCurrentScreen('interaction');
    }
  };

  const handleCreateNewCharacter = () => {
    setCharacterState(createDefaultCharacterState());
    setCreationStep(1);
    setCreationTarget('character');
    setCurrentScreen('creation');
  };

  const handleSelectCharacterForEdit = (char: CharacterState, step: number = 1) => {
    if (char) {
      setCharacterState(char);
      setCreationStep(step);
      setCreationTarget('character');
      setCurrentScreen('creation');
    }
  };

  const handleCreateNewPlace = () => {
    const newPlace = createEmptyPlace();
    setEditingPlace(newPlace);
    setCreationTarget('places');
    setCurrentScreen('creation');
  };

  const handleSelectPlaceForEdit = (place: WorldPlace) => {
    setEditingPlace(place);
    setCreationTarget('places');
    setCurrentScreen('creation');
  };

  const handleCreateNewWorldBuilding = () => {
    const newWorld = createEmptyWorldBuilding();
    setEditingWorldConfig(newWorld);
    setCreationTarget('worldbuilding');
    setCurrentScreen('creation');
  };

  const handleSelectWorldForEdit = (config: WorldBuildingConfig) => {
    setEditingWorldConfig(config);
    setCreationTarget('worldbuilding');
    setCurrentScreen('creation');
  };

  const handleSelectProtagonist = (char: CharacterState) => {
    setProtagonistCharacter(char);
  };

  const handleToggleNsfw = () => {
    setCharacterState(prev => {
      const cur = prev || createDefaultCharacterState();
      const currentNsfw = cur.nsfw || {
        isNsfwEnabled: false,
        ageConfirmed: false,
        areolaColor: 'Rosado Pálido Sakura',
        areolaSize: 'Media',
        nippleType: 'Túrgido Firme',
        pubicHairStyle: 'Depilación Total',
        bodySensitivities: ['BS1'],
        genitalType: 'Vulva Carnosa Delicada (Labios Recogidos)',
        genitalSize: 'Mediano Clásico (Armónico)',
        genitalDetails: ['Natural Puro (Rosado / Tono Carnal Suave)'],
        intimatePersonality: 'Sumisa Devota & Complaciente',
        explicitLingerie: []
      };
      const nextVal = !currentNsfw.isNsfwEnabled;
      const updatedNsfw = {
        ...currentNsfw,
        isNsfwEnabled: nextVal,
        ageConfirmed: nextVal ? true : currentNsfw.ageConfirmed
      };
      const newChar = {
        ...cur,
        nsfw: updatedNsfw
      };
      saveToLibrary(newChar);
      return newChar;
    });
  };

  const safeCharacterState = characterState || createDefaultCharacterState();

  return (
    <div className="min-h-screen bg-[#0A0B0E] text-[#E0E0E0] font-sans selection:bg-[#C9A050] selection:text-[#0A0B0E] flex flex-col overflow-x-hidden">
      {/* 4-Screen Global Header */}
      <Header
        currentScreen={currentScreen}
        onNavigate={setCurrentScreen}
        onOpenQuickCreation={() => setIsQuickCreationOpen(true)}
        isNsfwEnabled={safeCharacterState?.nsfw?.isNsfwEnabled ?? false}
        onToggleNsfw={handleToggleNsfw}
        onOpenInstallModal={() => setIsInstallModalOpen(true)}
      />

      <div className="flex-1 flex flex-col relative">
        <main className="flex-1 pb-16">
          {/* PANTALLA 1: INICIO (HUB) */}
          {currentScreen === 'home' && (
            <HomeScreen
              onNavigate={setCurrentScreen}
              activeCharacter={safeCharacterState}
              activePlace={activePlace}
              worldConfig={worldConfig}
              savedCharactersCount={savedCharacters.length}
              savedPlacesCount={savedPlaces.length}
              isNsfwEnabled={safeCharacterState?.nsfw?.isNsfwEnabled ?? false}
              onToggleNsfw={handleToggleNsfw}
              onOpenQuickCreation={() => setIsQuickCreationOpen(true)}
              onOpenInstallModal={() => setIsInstallModalOpen(true)}
            />
          )}

          {/* PANTALLA 2: BIBLIOTECA */}
          {currentScreen === 'library' && (
            <UnifiedLibraryScreen
              onNavigate={setCurrentScreen}
              onSelectCharacterForInteraction={handleSelectCharacterForInteraction}
              onSelectCharacterForEdit={handleSelectCharacterForEdit}
              onCreateNewCharacter={handleCreateNewCharacter}
              onSelectProtagonist={handleSelectProtagonist}
              activePlaceId={activePlace?.id}
              onSetActivePlace={setActivePlace}
              onSelectPlaceForEdit={handleSelectPlaceForEdit}
              onCreateNewPlace={handleCreateNewPlace}
              onSetActiveWorld={setWorldConfig}
              onSelectWorldForEdit={handleSelectWorldForEdit}
              onCreateNewWorldBuilding={handleCreateNewWorldBuilding}
              onReloadCounts={triggerGlobalSync}
            />
          )}

          {/* PANTALLA 3: CREACIÓN (3 EJES: PERSONAJE/LITE AGENT, LUGARES, WORLDBUILDING) */}
          {currentScreen === 'creation' && (
            <CreationHubScreen
              onNavigate={setCurrentScreen}
              creationTarget={creationTarget}
              onSetCreationTarget={setCreationTarget}
              characterState={characterState}
              onUpdateCharacter={setCharacterState}
              editingPlace={editingPlace}
              onPlaceSaved={(place) => {
                setActivePlace(place);
                triggerGlobalSync();
              }}
              editingWorldConfig={editingWorldConfig}
              onWorldConfigSaved={(config) => {
                setWorldConfig(config);
                triggerGlobalSync();
              }}
              renderGuidedCharacterWizard={() => (
                <div className="space-y-6">
                  {/* Step sub-nav */}
                  <div className="flex flex-wrap gap-2 border-b border-[#232630] pb-4">
                    {[
                      { step: 1, label: '1. Raza' },
                      { step: 2, label: '2. Anatomía' },
                      { step: 3, label: '3. Vestuario' },
                      { step: 4, label: '4. Rol & Armadura' },
                      { step: 5, label: '5. Historia' },
                      { step: 6, label: '6. Ficha Maestra & Guardado' }
                    ].map(s => (
                      <button
                        key={s.step}
                        type="button"
                        onClick={() => setCreationStep(s.step)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                          creationStep === s.step
                            ? 'bg-[#D4AF37] text-black shadow-sm'
                            : 'bg-[#181A22] text-[#8A8F9E] hover:text-[#E5E7EB]'
                        }`}
                      >
                        {s.label}
                      </button>
                    ))}
                  </div>

                  {/* Step Component rendering */}
                  {creationStep === 1 && (
                    <State1Raza
                      state={characterState}
                      setState={setCharacterState}
                      onNext={() => setCreationStep(2)}
                    />
                  )}
                  {creationStep === 2 && (
                    <State2Anatomy
                      state={characterState}
                      setState={setCharacterState}
                      onNext={() => setCreationStep(3)}
                      onBack={() => setCreationStep(1)}
                    />
                  )}
                  {creationStep === 3 && (
                    <State3Wardrobe
                      state={characterState}
                      setState={setCharacterState}
                      onNext={() => setCreationStep(4)}
                      onBack={() => setCreationStep(2)}
                    />
                  )}
                  {creationStep === 4 && (
                    <State4RoleArmor
                      state={characterState}
                      setState={setCharacterState}
                      onNext={() => setCreationStep(5)}
                      onBack={() => setCreationStep(3)}
                    />
                  )}
                  {creationStep === 5 && (
                    <State5Background
                      state={characterState}
                      setState={setCharacterState}
                      onNext={() => setCreationStep(6)}
                      onBack={() => setCreationStep(4)}
                    />
                  )}
                  {creationStep === 6 && (
                    <State7Compilation
                      state={characterState}
                      setState={setCharacterState}
                      onBack={() => setCreationStep(5)}
                      onFinish={() => setCurrentScreen('interaction')}
                      onNavigateToState={(s) => setCreationStep(s)}
                      onResetCharacter={() => setCharacterState(createDefaultCharacterState())}
                    />
                  )}
                </div>
              )}
            />
          )}

          {/* PANTALLA 4: INTERACCIÓN (SISTEMA DE CHAT MULTIAGENTE) */}
          {currentScreen === 'interaction' && (
            <UnifiedInteractionScreen
              onNavigate={setCurrentScreen}
              characterState={characterState}
              onUpdateCharacter={setCharacterState}
              activePlace={activePlace}
              onSetActivePlace={setActivePlace}
              worldConfig={worldConfig}
            />
          )}
        </main>
      </div>

      {/* Quick Creation Express Modal */}
      <QuickCreationModal
        isOpen={isQuickCreationOpen}
        onClose={() => setIsQuickCreationOpen(false)}
        onApplyCharacter={handleApplyQuickCharacter}
      />

      {/* NSFW Mode Configuration & Age Verification Modal */}
      <NsfwModal
        isOpen={isNsfwModalOpen}
        onClose={() => setIsNsfwModalOpen(false)}
        state={safeCharacterState}
        characterState={safeCharacterState}
        setState={setCharacterState}
        onUpdateNsfwConfig={(updatedNsfw) => {
          setCharacterState(prev => ({
            ...prev,
            nsfw: updatedNsfw
          }));
        }}
      />

      {/* PWA Multiplatform Install / Download Modal (PC & Mobile, 100% Offline) */}
      <PWAInstallModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
      />

      {/* Discreet Offline Network Status Indicator */}
      <OfflineIndicator />
    </div>
  );
}
