export const PERSONALITIES = [
  'Alegre', 'Tímido', 'Carismático', 'Agresivo', 'Rebelde', 'Serio', 'Melancólico', 'Enérgico', 'Estoico', 'Apático'
];

export const CHARACTER_ARCHETYPES = [
  'Genérico',
  // Arquetipos de Anime, Dinámicas & Tropes Simples
  'Kouhai',
  'Senpai',
  'Tsundere',
  'Yandere',
  'Kuudere',
  'Dandere',
  'Deredere',
  'Kamidere',
  'Himedere',
  'Ojou-sama',
  'Mesugaki',
  'Gyaru',
  'Chuunibyou',
  'Bakadere',
  'Sadodere',
  'Yangire',
  'Genki',
  'Tomboy',
  'Femboy',
  // Arquetipos Narrativos, Heroicos & Antagónicos
  'Héroe',
  'Antihéroe',
  'Villano',
  'Rival',
  'Vengador',
  'Elegido',
  'Prodigio',
  'Campeón',
  'Líder',
  'Comandante',
  'Guardián',
  'Protector',
  'Defensor',
  'Justiciero',
  'Vigilante',
  'Pacificador',
  'Mártir',
  'Superviviente',
  'Rebelde',
  'Renegado',
  'Anarquista',
  'Conquistador',
  'Traidor',
  'Depredador',
  'Lobo Solitario',
  'Cómplice',
  // Tutoría, Sabiduría & Aprendizaje
  'Mentor',
  'Maestro',
  'Aprendiz',
  'Discípulo',
  'Escudero',
  'Consejero',
  'Guía',
  'Ermitaño',
  'Estratega',
  'Mente Maestra',
  'Erudito',
  'Sabio',
  'Científico',
  'Investigador',
  // Vínculos Dinámicos & Familiares
  'Hermano Mayor',
  'Hermana Mayor',
  'Hermano Menor',
  'Hermana Menor',
  'Figura Materna',
  'Figura Paterna',
  // Arquetipos Marciales & Combate
  'Caballero',
  'Paladín',
  'Guerrero',
  'Berserker',
  'Bárbaro',
  'Gladiador',
  'Soldado',
  'Veterano',
  'Mercenario',
  'Centinela',
  'Guardia',
  'Inquisidor',
  'Verdugo',
  'Segador',
  // Arquetipos Pícaros, Sombríos, Furtivos & Exploración
  'Pícaro',
  'Ladrón',
  'Asesino',
  'Sicario',
  'Cazador',
  'Cazarrecompensas',
  'Explorador',
  'Rastreador',
  'Espía',
  'Infiltrado',
  'Agente Secreto',
  'Embaucador',
  'Contrabandista',
  'Forajido',
  'Fugitivo',
  'Exiliado',
  'Vagabundo',
  'Nómada',
  'Errante',
  'Aventurero',
  // Arquetipos Arcanos, Espirituales & Religiosos
  'Mago',
  'Hechicero',
  'Brujo',
  'Bruja',
  'Nigromante',
  'Invocador',
  'Alquimista',
  'Artífice',
  'Clérigo',
  'Sacerdote',
  'Sacerdotisa',
  'Monje',
  'Druida',
  'Chamán',
  'Oráculo',
  'Profeta',
  'Devoto',
  'Cultista',
  'Fanático',
  // Arquetipos Soberanos, Nobiliarios & Cortesanos
  'Monarca',
  'Rey',
  'Reina',
  'Emperador',
  'Emperatriz',
  'Príncipe',
  'Princesa',
  'Tirano',
  'Déspota',
  'Aristócrata',
  'Noble',
  'Diplomático',
  'Magistrado',
  'Juez',
  'Cortesano',
  'Cortesana',
  'Maid',
  'Mayordomo',
  'Ama de Llaves',
  'Sirviente',
  // Arquetipos Artísticos, Sociales & Entretenimiento
  'Bardo',
  'Juglar',
  'Bufón',
  'Idol',
  'Diva',
  'Streamer',
  'Hedonista',
  'Soñador',
  'Romántico',
  // Arquetipos Seductores & Provocativos
  'Femme Fatale',
  'Dominatriz',
  'Seductor',
  'Seductora',
  // Arquetipos Modernos, Urbanos & Cyberpunk
  'Hacker',
  'Netrunner',
  'Fixer',
  'Detective',
  'Cíborg',
  'Androide',
  'Piloto',
  'Navegante',
  'Pirata',
  // Arquetipos Sobrenaturales & Mitológicos
  'Vampiro',
  'Licántropo',
  'Hombre Lobo',
  'Demonio',
  'Ángel',
  'Ángel Caído',
  'Súcubo',
  'Íncubo',
  'Deidad'
];

import { CharacterState } from './types';

export const SCLERA_COLORS = [
  'SCL01 Blanca Estándar (Humana Clásica)',
  'SCL02 Negra Azabache / Abisal (Vantablack)',
  'SCL03 Rojo Carmesí / Sangrienta',
  'SCL04 Dorada Solar / Luminiscente',
  'SCL05 Azul Eléctrico / Cian Emisivo',
  'SCL06 Púrpura / Amatista Mística',
  'SCL07 Gris Ceniza / Necrótica',
  'SCL08 Lechosa / Nublada Ciega (No-muertos)',
  'SCL09 Translúcida / Plasma Luminoso',
  'SCL10 Inexistente / Rostro sin Ojos'
];

export const FACIAL_MORPHOLOGIES = [
  'MORF01 Estándar Humanoide',
  'MORF02 Cabeza y Hocico Felino Completo (Pantheris)',
  'MORF03 Hocico Canino Sutil (Inujin)',
  'MORF04 Mandíbula Cuadrada con Prognatismo y Colmillos Inferiores (Orco)',
  'MORF05 Pico Afilado con Plumaje Facial (Arpía)',
  'MORF06 Rostro Liso Translúcido sin Ojos ni Boca con Órgano Sensorial (Demiurgo)',
  'MORF07 Nariz Aguilada Pronunciada (Goblin XY)',
  'MORF08 Nariz Chata Juvenil (Goblin XX/XXY)',
  'MORF09 Mandíbula Serrada Abisal con Dentición Predadora (Carnicero)'
];

export const FACIAL_HAIR_OPTIONS = [
  'Ninguno (Afeitado / Rostro Limpio)',
  'Barba Incipiente / Sombra de 3 Días (Stubble)',
  'Barba Corta Perfilada y Recortada',
  'Barba Completa Espesa / Leñador',
  'Barba Larga Patriarcal / Sabio / Enano',
  'Barba de Chivo / Perilla Clásica (Goatee)',
  'Perilla con Bigote Conectado (Circle Beard)',
  'Perilla con Bigote Separado (Van Dyke)',
  'Bigote Fino / Lápiz Elegante',
  'Bigote Clásico / Chevron',
  'Bigote Dalí / Curvado hacia Arriba con Cera',
  'Bigote Imperial / Herradura (Horseshoe)',
  'Bigote Morsa / Espeso Vintage (Walrus)',
  'Patillas Largas / Mutton Chops',
  'Patillas Conectadas sin Bigote (Friendly Mutton Chops)',
  'Barba Trenzada de Guerrero Nórdico / Enano con Anillos',
  'Barba Bífida / Dividida en Dos Puntas',
  'Barba Esculpida Geométrica / Cyberpunk'
];

export const FACIAL_HAIR_COLORS = [
  'Mismo que el cabello',
  'Negro',
  'Castaño oscuro',
  'Castaño claro',
  'Rubio dorado',
  'Rubio platino',
  'Pelirrojo',
  'Gris',
  'Blanco',
  'Azul',
  'Rojo',
  'Verde',
  'Morado'
];

export const LOWER_BODY_STRUCTURES = [
  'SIL01 Bípedo Humanoide Estándar (Piernas)',
  'SIL02 Parte Inferior de Araña (Aracne / Drider: Abdomen Gigante y 8 Patas Quilíferas Articuladas)',
  'SIL03 Parte Inferior de Pulpo (Cecaelia: 8 Tentáculos Cefalópodos Musculares con Ventosas)',
  'SIL04 Cola Serpentina 2.0–3.0 m en lugar de Piernas (Lamia / Naga)',
  'SIL05 Cola Pisciforme / Aletas de Sirena-Tritón (Transformación Acuática)',
  'SIL06 Cuerpo Taurino Equino de 4 Patas y Cascos (Centauro)',
  'SIL07 Cuerpo Cuadrúpedo Felino de Tigre / León (Felitaur)',
  'SIL08 Cuerpo Cuadrúpedo Dracónico Escamoso de 4 Patas y Cola Blindada (Dracotaur)',
  'SIL09 Parte Inferior de Escorpión con 8 Patas y Cola Aguijón Arqueada (Scorpiontaur / Girtablilu)',
  'SIL10 Brazos-Alas de Arpía con Plumaje y Garras en Extremidades',
  'SIL11 Matriz Amorfa Gelatinosa / Slime Replicante que babea / escurre gel (Plasmoide)',
  'SIL12 Matriz Ectoplásmica Flotante / Espectral (Elemental)',
  'SIL13 Pie Muscular Molusco / Babosa Reptante con Rastro Mucoso (Gastrópodo-taur)',
  'SIL14 Chasis Flotante Gravitacional / Plataforma Cibernética Biónica (Cyborg)'
];

export const CHEST_CORES = [
  'COR00 Ninguno (Torso Orgánico Estándar)',
  'COR01 Núcleo de Energía Resplandeciente en el Pecho (Plasmoide / Demiurgo)',
  'COR02 Nodos de Biomasa Coloidal Visibles (Homúnculo)',
  'COR03 Sello de Servidumbre Demoníaco en el Vientre (Incubus Sucuboforme)',
  'COR04 Runas Dérmicas Pulsantes en el Pecho (Demonio Noble)',
  'COR05 Puertos de Datos y Núcleo Sintético (Androide)'
];

export const NECK_FEATURES = [
  'NCK00 Ninguno (Cuello Estándar)',
  'NCK01 Pelaje de Lana Suave y Esponjosa alrededor del Cuello y Hombros (Bestfolk Caprinae)',
  'NCK02 Branquias Ocultas en el Cuello y Membranas Interdigitales (Sirena/Tritón)',
  'NCK03 Collarín de Plumas Naturales (Arpía)',
  'NCK04 Placas de Blindaje y Puertos Cibernéticos en el Cuello (Androide)',
  'NCK05 Vientre y Garganta con Escamas Gruesas Dracónicas'
];

export const HAIR_ELEMENTALS = [
  'Cabello Orgánico Natural',
  'Cabello de Tentáculos de Cefalópodo / Tentáculos con Ventosas (Medusa / Cecaelia)',
  'Cabello de Serpientes Vivas (Gorgona / Medusa Mítica)',
  'Cabello de Fuego y Llamas Ardientes (Elemental Fuego)',
  'Cabello de Agua Fluida Líquida Cristalina (Elemental Agua)',
  'Cabello de Vórtice de Aire y Brisa Etérea (Elemental Aire)',
  'Cabello de Lianas, Espinas y Hojas Vivas (Elemental Tierra / Dríada)',
  'Cabello de Plumas de Ave / Plumaje de Halcón / Cuervo (Arpía)',
  'Cabello de Slime / Matriz Gelatinosa Translúcida con Gotas (Plasmoide)',
  'Cabello de Cables Cibernéticos y Fibras Ópticas Iluminadas (Cyborg / Androide)',
  'Cabello de Cristales de Cuarzo y Filamentos de Gema',
  'Cabello de Sombras / Humo Espectral y Niebla Umbral',
  'Cabello de Rayos y Electricidad Estática Chispeante',
  'Melena de Pelaje Salvaje de León / Lobo / Bestia',
  'Filamentos de Plasma Energético (Ninfa / Plasmoide)',
  'Polvo de Hadas y Partículas Luminiscentes (Hada)',
  'Sin Cabello / Corona de Plumas (Arpía)',
  'Sin Cabello / Superficie Lisa Luminiscente (Demiurgo / Androide)'
];

// ==========================================
// APÉNDICES SOBRENATURALES, ANIMALES Y PROSTÉTICOS
// ==========================================

export const ANTENNAE_TYPES = [
  'Ninguna',
  'Antenas Plumosas de Polilla (Sedosas y Ramificadas)',
  'Antenas Filiformes de Mariposa con Punta Esférica',
  'Antenas Articuladas de Hormiga / Avispa (Geniculadas)',
  'Antenas Bioluminiscentes de Luciérnaga / Abisal (Con Lámpara Emisiva)',
  'Antenas Lameladas de Escarabajo Rinoceronte / Ciervo',
  'Tentáculos Sensoriales / Antenas Cefálicas de Caracol / Babosa',
  'Antenas Sensoras Tecnológicas / Transmisores y Receptores Cibernéticos',
  'Antenas Alienígenas con Ocelo / Receptor de Ondas Psíquicas'
];

export const ANTENNAE_LENGTHS = [
  'Cortas (5–10 cm)',
  'Medias (10–25 cm)',
  'Largas (25–50 cm)',
  'Extra Largas (>50 cm)'
];

export const ANTENNAE_POSITIONS = [
  'Frontales (Frente)',
  'Coronales (Cima de la Cabeza)',
  'Laterales / Sienes',
  'Detrás de las Orejas'
];

export const EXTRA_EYES_OPTIONS = [
  'Ninguno (2 Ojos Estándar)',
  'Tercer Ojo Frontal en la Frente (Místico / Psíquico)',
  '4 Ojos (2 Pares Alineados Verticalmente)',
  '4 Ojos (2 Pares en Disposición Diagonal / Exótica)',
  '6 Ojos Aracnoides (Ocelos de Araña en Frente y Sienes)',
  '8 Ojos Aracnoides Completos (Cluster Ocular de Araña Cazadora)',
  'Ojos Facetados Compuestos de Insecto',
  'Ojos Adicionales en las Palmas de las Manos',
  'Ojos Múltiples Dispersos en el Cuerpo y Brazos (Entidad Abisal / Alucard)',
  'Ojos Múltiples Flotantes Orbitando la Cabeza'
];

export const EXTRA_ARMS_OPTIONS = [
  'Ninguno (2 Brazos Estándar)',
  '4 Brazos Orgánicos (2 Pares de Brazos Humanoides)',
  '6 Brazos Deidad Asura / Dios Marcial (3 Pares de Brazos)',
  '8 Brazos Múltiples Hemicuerpo Superior',
  '4 Brazos Cibernéticos / Exo-Brazos Mecánicos de Apoyo',
  'Brazos Monstruosos Adicionales de Bestia con Garras',
  'Brazos de Energía Astral / Ectoplasma Mágico Transparente',
  'Tentáculos Dorsales / Brazos Tentaculares Traseros (4 a 6 Tentáculos)'
];

export const SPECIAL_LIMBS_OPTIONS = [
  'Ninguna (Extremidades Orgánicas Estándar)',
  'Brazos y Piernas Ciborg Biónicas de Cromo y Titanio con Circuitos de Neón',
  'Brazos Ciborg / Prótesis Mecánicas Avanzadas (Piernas Orgánicas)',
  'Piernas Ciborg / Prótesis de Alta Velocidad con Pistones Hidráulicos (Brazos Orgánicos)',
  'Brazos y Piernas de Muñeca Articulada (Ball-Jointed Doll / BJD de Porcelana con Junturas Esféricas)',
  'Cuerpo Entero de Marioneta / Muñeca BJD con Articulaciones Esféricas de Madera Esmaltada',
  'Brazos y Piernas de Bestia / Patas Digitígradas con Garras y Almohadillas',
  'Piernas Digitígradas con Pezuñas Hendidas de Sátiro / Demonio',
  'Brazos con Garras Dracónicas Escamosas y Piernas Saurias',
  'Brazos y Piernas Cristalinas / Cuarzo Translúcido Refractario',
  'Extremidades de Madera y Raíces Vivas de Autómata Silvano'
];

export interface RacePresetTraitDefinition {
  sexBase?: string;
  height?: string;
  complexion?: string;
  breastDevelopment?: string;
  skinColor?: string;
  scleraColor?: string;
  facialMorphology?: string;
  lowerBodyStructure?: string;
  chestCore?: string;
  neckFeature?: string;
  hairElemental?: string;
  hairColor?: string;
  earsBase?: string;
  earsLength?: string;
  kemonoEars?: string;
  eyesCategory?: string;
  eyesSubtype?: string;
  iris?: string;
  eyeColor?: string;
  teeth?: string;
  nose?: string;
  hornsForm?: string;
  hornsLength?: string;
  hornsThickness?: string;
  hornsPosition?: string;
  wingsType?: string;
  wingsSize?: string;
  wingsPosition?: string;
  tailsType?: string;
  tailsLength?: string;
  skinAndMarks?: string;
  scaleLocations?: string[];
  markTypes?: string[];
  antennaeType?: string;
  antennaeLength?: string;
  antennaePosition?: string;
  extraEyes?: string;
  extraArms?: string;
  specialLimbs?: string;
  subtypes?: { id: string; name: string; description: string; traits: Partial<RacePresetTraitDefinition> }[];
  summary: string;
  highlights: string[];
}

export const RACE_PRESET_TRAITS: Record<string, RacePresetTraitDefinition> = {
  '1.1': {
    height: 'C Normal / Estándar (1.60 m – 1.80 m)',
    complexion: '2 Esbelto / Estandar',
    skinColor: 'Piel Caucásica Clara',
    scleraColor: 'SCL01 Blanca Estándar (Humana Clásica)',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E01 Normales',
    kemonoEars: 'Ninguno',
    iris: '1 Humano',
    teeth: 'B1 Normales',
    hornsForm: 'Ninguno',
    wingsType: 'Ninguno',
    tailsType: 'Ninguno',
    skinAndMarks: 'T1 Piel Lisa',
    subtypes: [
      {
        id: '1.1.1',
        name: '1.1.1 Humano Estándar / Cosmopolita',
        description: 'Morfología humana balanceada, amplia adaptabilidad y diversidad genética.',
        traits: {
          complexion: '2 Esbelto / Estandar',
          skinColor: 'Piel Caucásica Clara',
          eyeColor: 'Marrón Oscuro',
          hairColor: 'Castaño Oscuro'
        }
      },
      {
        id: '1.1.2',
        name: '1.1.2 Humano Nórdico / Boreal',
        description: 'Estatura alta, tez clara o pálida, ojos claros y resistencia al frío.',
        traits: {
          height: 'D Alto (1.80 m – 2.00 m)',
          complexion: '3 Atlético / Fibroso',
          skinColor: 'Piel Caucásica Pálida',
          eyeColor: 'Azul Claro',
          hairColor: 'Rubio Dorado'
        }
      },
      {
        id: '1.1.3',
        name: '1.1.3 Humano Mediterráneo / Solar',
        description: 'Tez cálida oliva/bronceada, cabello ondulado y ojos color miel o avellana.',
        traits: {
          skinColor: 'Bronceada / Oliva',
          eyeColor: 'Castaño / Avellana',
          hairColor: 'Castaño Oscuro'
        }
      },
      {
        id: '1.1.4',
        name: '1.1.4 Humano Nómada del Desierto',
        description: 'Complexión enjuta y fibrosa, piel morena y alta resistencia a ambientes hostiles.',
        traits: {
          complexion: '3 Atlético / Fibroso',
          skinColor: 'Bronceada / Oliva',
          eyeColor: 'Ámbar / Miel',
          hairColor: 'Negro Azabache'
        }
      },
      {
        id: '1.1.5',
        name: '1.1.5 Humano Oriental / Imperial',
        description: 'Ojos almendrados rasgados, cabello liso negro lustroso y facciones finas.',
        traits: {
          eyesCategory: 'A Filosos / Afilados',
          eyesSubtype: 'A1 Almendrado Clásico',
          skinColor: 'Piel Caucásica Clara',
          eyeColor: 'Marrón Oscuro',
          hairColor: 'Negro Azabache'
        }
      }
    ],
    summary: 'Proporciones balanceadas, esclerótica blanca estándar y máxima diversidad fenotípica.',
    highlights: ['Esclerótica blanca estándar', 'Bípedo estándar', 'Sin apéndices obligatorios']
  },
  '1.2': {
    height: 'D Alto (1.80 m – 2.00 m)',
    complexion: '2 Esbelto / Estandar',
    skinColor: 'Piel Caucásica Pálida',
    scleraColor: 'SCL01 Blanca Estándar (Humana Clásica)',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E03 Puntiagudas marcadas',
    earsLength: 'EL3 10–15 cm',
    kemonoEars: 'Ninguno',
    iris: '2 Felino',
    eyesCategory: 'A Filosos / Afilados',
    eyesSubtype: 'A1 Almendrado Clásico',
    nose: '11 Elfa / Puntiaguda',
    teeth: 'B1 Normales',
    hornsForm: 'Ninguno',
    wingsType: 'Ninguno',
    tailsType: 'Ninguno',
    skinAndMarks: 'T1 Piel Lisa',
    subtypes: [
      {
        id: '1.2.1',
        name: '1.2.1 Alto Elfo (Aelthar Solar / Noble)',
        description: 'Piel perlada noble, ojos dorados/ámbar luminiscentes, afinidad con la magia arcana.',
        traits: {
          skinColor: 'Piel Caucásica Pálida',
          eyeColor: 'Dorado / Amarillo Brillante',
          hairColor: 'Rubio Dorado',
          earsLength: 'EL3 10–15 cm'
        }
      },
      {
        id: '1.2.2',
        name: '1.2.2 Elfo Silvano (Aelthar de los Bosques)',
        description: 'Piel bronceada suave, ojos esmeralda/avellana y gran agilidad natural.',
        traits: {
          skinColor: 'Bronceada / Oliva',
          eyeColor: 'Verde Esmeralda',
          hairColor: 'Castaño Claro',
          earsLength: 'EL2 5–10 cm'
        }
      },
      {
        id: '1.2.3',
        name: '1.2.3 Elfo Oscuro / Drow (Aelthar Umbrío)',
        description: 'Piel de tono ceniza o gris obsidiana, ojos violeta/carmesí y cabello blanco platino.',
        traits: {
          skinColor: 'Gris / Ceniza',
          scleraColor: 'SCL03 Rojo Carmesí / Sangrienta',
          eyeColor: 'Violeta / Púrpura',
          hairColor: 'Platino / Blanco',
          earsLength: 'EL3 10–15 cm'
        }
      },
      {
        id: '1.2.4',
        name: '1.2.4 Elfo Lunar / Astral',
        description: 'Piel nívea pura, ojos plateados/cristalinos y cabello con destellos azulados.',
        traits: {
          skinColor: 'Blanca Pura',
          eyeColor: 'Plateado / Gris Claro',
          hairColor: 'Azul Claro',
          earsLength: 'EL3 10–15 cm'
        }
      }
    ],
    summary: 'Cuerpo estilizado y alargado, orejas puntiagudas (10–15 cm), ojos almendrados y cabello sedoso.',
    highlights: ['Orejas puntiagudas 10-15 cm', 'Ojos almendrados con pupila vertical', 'Piel perlada estilizada']
  },
  '1.3': {
    height: 'A Muy Pequeño (1.20 m – 1.40 m)',
    complexion: '5 Voluminoso / Robusto',
    skinColor: 'Bronceada / Oliva',
    scleraColor: 'SCL01 Blanca Estándar (Humana Clásica)',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E01 Normales',
    kemonoEars: 'Ninguno',
    iris: '1 Humano',
    nose: '3 Recta Ancha',
    teeth: 'B1 Normales',
    hornsForm: 'Ninguno',
    wingsType: 'Ninguno',
    tailsType: 'Ninguno',
    skinAndMarks: 'T1 Piel Lisa',
    markTypes: ['M1 Tatuaje Tradicional / Tribal'],
    subtypes: [
      {
        id: '1.3.1',
        name: '1.3.1 Enano de las Montañas (Forjador Imperial)',
        description: 'Constitución masiva, piel curtida y marcas de runas forjadas.',
        traits: {
          complexion: '5 Voluminoso / Robusto',
          skinColor: 'Bronceada / Oliva',
          eyeColor: 'Ámbar / Miel'
        }
      },
      {
        id: '1.3.2',
        name: '1.3.2 Enano de las Colinas (Explorador / Cervecero)',
        description: 'Estatura ligeramente superior, rostro jovial y gran resistencia.',
        traits: {
          complexion: '3 Atlético / Fibroso',
          skinColor: 'Piel Caucásica Clara',
          eyeColor: 'Verde Esmeralda'
        }
      },
      {
        id: '1.3.3',
        name: '1.3.3 Enano del Abismo / Duergar',
        description: 'Piel gris ceniza, ojos carmesí sin pupila y maestría en metalurgia oscura.',
        traits: {
          skinColor: 'Gris / Ceniza',
          scleraColor: 'SCL07 Gris Ceniza / Necrótica',
          eyeColor: 'Rojo Carmesí'
        }
      }
    ],
    summary: 'Estatura compacta (1.35–1.60 m), huesos densos, piel gruesa tipo cuero y mandíbula cuadrada.',
    highlights: ['Cuerpo compacto y robusto', 'Mandíbula ancha', 'Tatuajes tribales rúnicos']
  },
  '2.1': {
    height: 'E Enorme (2.00 m – 2.20 m)',
    complexion: '6 Hipertrofiado / Musculatura Extrema',
    skinColor: 'Roja / Carmesí',
    scleraColor: 'SCL03 Rojo Carmesí / Sangrienta',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E02 Puntiagudas suaves',
    kemonoEars: 'Ninguno',
    iris: '2 Felino',
    teeth: 'B3 Colmillos Prominentes',
    hornsForm: 'H2 Curvos',
    hornsLength: 'HL2 10-30 cm',
    hornsThickness: 'G4 Grueso',
    hornsPosition: 'P1 Frontales',
    wingsType: 'Ninguno',
    tailsType: 'Ninguno',
    skinAndMarks: 'T1 Piel Lisa',
    subtypes: [
      {
        id: '2.1.1',
        name: '2.1.1 Aka-Oni (Oni Rojo / Furia & Guerra)',
        description: 'Piel carmesí intensa, cuernos dobles frontales y fuerza bruta demoledora.',
        traits: {
          skinColor: 'Roja / Carmesí',
          eyeColor: 'Rojo Carmesí',
          hornsForm: 'H2 Curvos',
          hornsPosition: 'P1 Frontales'
        }
      },
      {
        id: '2.1.2',
        name: '2.1.2 Ao-Oni (Oni Azul / Místico & Escarcha)',
        description: 'Piel azul/cian con cuerno único central o frontal, mirada gélida y gran disciplina.',
        traits: {
          skinColor: 'Azul / Cian',
          eyeColor: 'Azul Claro',
          hornsForm: 'H1 Rectos',
          hornsPosition: 'P1 Frontales'
        }
      },
      {
        id: '2.1.3',
        name: '2.1.3 Kuro-Oni (Oni Negro / Abisal & Sombras)',
        description: 'Piel ébano oscuro, esclerótica abisal negra y cuernos gruesos oscuros.',
        traits: {
          skinColor: 'Negra / Ébano',
          scleraColor: 'SCL02 Negra Azabache / Abisal (Vantablack)',
          eyeColor: 'Dorado / Amarillo Brillante',
          hornsForm: 'H3 Retorcidos / Espiral'
        }
      }
    ],
    summary: 'Presencia imponente (1.80–2.40 m), cuernos curvados obligatorios, piel roja/índigo y ojos rasgados.',
    highlights: ['Cuernos curvados frontales', 'Piel roja/índigo/gris', 'Colmillos prominentes', 'Esclerótica rojiza']
  },
  '2.2': {
    height: 'E Enorme (2.00 m – 2.20 m)',
    complexion: '6 Hipertrofiado / Musculatura Extrema',
    skinColor: 'Verde',
    scleraColor: 'SCL04 Dorada Solar / Luminiscente',
    facialMorphology: 'MORF04 Mandíbula Cuadrada con Prognatismo y Colmillos Inferiores (Orco)',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E03 Puntiagudas marcadas',
    kemonoEars: 'Ninguno',
    iris: '1 Humano',
    teeth: 'B3 Colmillos Prominentes',
    hornsForm: 'Ninguno',
    wingsType: 'Ninguno',
    tailsType: 'Ninguno',
    skinAndMarks: 'T1 Piel Lisa',
    markTypes: ['M5 Cicatriz de Batalla / Quemadura'],
    subtypes: [
      {
        id: '2.2.1',
        name: '2.2.1 Orco de las Planicies (Krag-Ork)',
        description: 'Piel verde olivo, colmillos inferiores sobresalientes y cicatrices ceremoniales.',
        traits: {
          skinColor: 'Verde',
          eyeColor: 'Ámbar / Miel'
        }
      },
      {
        id: '2.2.2',
        name: '2.2.2 Orco de las Cavernas (Sangre Negra)',
        description: 'Piel gris ceniza, gran visión en la penumbra y colmillos curvos afilados.',
        traits: {
          skinColor: 'Gris / Ceniza',
          eyeColor: 'Rojo Carmesí'
        }
      }
    ],
    summary: 'Cuerpo grande y densamente musculado, piel verde, mandíbula con prognatismo y colmillos inferiores visibles.',
    highlights: ['Piel verde intensa', 'Prognatismo y colmillos inferiores', 'Cicatrices rituales']
  },
  '2.3': {
    height: 'A Muy Pequeño (1.20 m – 1.40 m)',
    complexion: '1 Escuálido / Muy Delgado',
    skinColor: 'Verde',
    scleraColor: 'SCL04 Dorada Solar / Luminiscente',
    facialMorphology: 'MORF07 Nariz Aguilada Pronunciada (Goblin XY)',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E06 Grandes',
    earsLength: 'EL3 10–15 cm',
    kemonoEars: 'Ninguno',
    iris: '2 Felino',
    teeth: 'B2 Afilados / Colmillos Múltiples',
    hornsForm: 'Ninguno',
    wingsType: 'Ninguno',
    tailsType: 'Ninguno',
    skinAndMarks: 'T1 Piel Lisa',
    summary: 'Estatura diminuta (1.00–1.30 m), piel rugosa verde, orejas grandes puntiagudas y manos ágiles.',
    highlights: ['Orejas grandes puntiagudas', 'Nariz aguilada/chata', 'Piel verde rugosa', 'Manos ágiles']
  },
  '2.4': {
    height: 'E Enorme (2.00 m – 2.20 m)',
    complexion: '6 Hipertrofiado / Musculatura Extrema',
    skinColor: 'Gris / Ceniza',
    scleraColor: 'SCL07 Gris Ceniza / Necrótica',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E01 Normales',
    kemonoEars: 'Ninguno',
    iris: '1 Humano',
    teeth: 'B4 Irregulares',
    hornsForm: 'Ninguno',
    wingsType: 'Ninguno',
    tailsType: 'Ninguno',
    skinAndMarks: 'T13 Piel Gruesa Similar a Piedra con Verrugas Naturales (Troll)',
    summary: 'Cuerpo colosal (2.20–2.50 m), piel gruesa similar a piedra con verrugas naturales y fuerza extrema.',
    highlights: ['Piel gruesa de piedra', 'Verrugas naturales', 'Musculatura masiva', 'Regeneración veloz']
  },
  '3.1': {
    height: 'E Enorme (2.00 m – 2.20 m)',
    complexion: '5 Voluminoso / Robusto',
    skinColor: 'Roja / Carmesí',
    scleraColor: 'SCL04 Dorada Solar / Luminiscente',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK05 Vientre y Garganta con Escamas Gruesas Dracónicas',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E03 Puntiagudas marcadas',
    kemonoEars: 'Ninguno',
    iris: '2 Felino',
    teeth: 'B2 Afilados / Colmillos Múltiples',
    hornsForm: 'H3 Retorcidos / Espiral',
    hornsLength: 'HL3 30-60 cm',
    hornsThickness: 'G4 Grueso',
    hornsPosition: 'P2 Laterales / Sienes',
    wingsType: 'A3 Dracónicas Membrana',
    wingsSize: 'S3 Grande',
    wingsPosition: 'P1 Espalda Alta',
    tailsType: 'C14 Dracónida Musculosa 1.2–1.5m con Crestas',
    tailsLength: 'L5 Muy Larga (120-200 cm)',
    skinAndMarks: 'T2 Piel Escamosa Dracónica Pura',
    scaleLocations: ['Espalda / Dorsal', 'Pecho / Pectorales', 'Hombros / Clavículas', 'Brazos / Antebrazos', 'Piernas / Muslos'],
    subtypes: [
      {
        id: '3.1.1',
        name: '3.1.1 Drakónido de Fuego Carmesí',
        description: 'Escamas carmesí brillante, aliento ígneo y crestas dorsales afiladas.',
        traits: {
          skinColor: 'Roja / Carmesí',
          eyeColor: 'Rojo Carmesí',
          hairColor: 'Rojo Fuego'
        }
      },
      {
        id: '3.1.2',
        name: '3.1.2 Drakónido de Hielo Glacial',
        description: 'Escamas azul cian gélidas, esclerótica azul luminiscente y cuernos escarchados.',
        traits: {
          skinColor: 'Azul / Cian',
          scleraColor: 'SCL05 Azul Eléctrico / Cian Emisivo',
          eyeColor: 'Azul Claro',
          hairColor: 'Platino / Blanco'
        }
      },
      {
        id: '3.1.3',
        name: '3.1.3 Drakónido de Tormenta / Relámpago',
        description: 'Escamas doradas metálicas, destellos electromagnéticos y garras fulgurantes.',
        traits: {
          skinColor: 'Dorada / Metálica',
          eyeColor: 'Dorado / Amarillo Brillante'
        }
      },
      {
        id: '3.1.4',
        name: '3.1.4 Drakónido Abisal de Sombra',
        description: 'Escamas negro ébano mate, esclerótica abisal y mirada violeta penetrante.',
        traits: {
          skinColor: 'Negra / Ébano',
          scleraColor: 'SCL02 Negra Azabache / Abisal (Vantablack)',
          eyeColor: 'Violeta / Púrpura'
        }
      }
    ],
    summary: 'Escamas gruesas completas, cola musculosa (1.2–1.5 m), pupilas verticales, cuernos y garras.',
    highlights: ['Escamas dracónicas puras', 'Cola musculosa con crestas', 'Pupila vertical dracónica', 'Cuernos y alas de membrana']
  },
  '3.2': {
    height: 'D Alto (1.80 m – 2.00 m)',
    complexion: '2 Esbelto / Estandar',
    skinColor: 'Azul / Cian',
    scleraColor: 'SCL05 Azul Eléctrico / Cian Emisivo',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL04 Cola Pisciforme / Aletas de Sirena-Tritón (Transformación Acuática)',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK02 Branquias Ocultas en el Cuello y Membranas Interdigitales (Sirena/Tritón)',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E02 Puntiagudas suaves',
    kemonoEars: 'KEMO-C7 Serpiente/Aletas',
    iris: '6 Cristalino',
    teeth: 'B2 Afilados / Colmillos Múltiples',
    hornsForm: 'Ninguno',
    wingsType: 'A11 Acuáticas Alas de Manta',
    tailsType: 'C19 Cola Pisciforme / Aleta Caudal (Sirena/Tritón)',
    tailsLength: 'L5 Muy Larga (120-200 cm)',
    skinAndMarks: 'T2-Impuro Escamas Suaves Localizadas (Hombros, Espalda, Extremidades)',
    scaleLocations: ['Espalda / Dorsal', 'Hombros / Clavículas', 'Brazos / Antebrazos', 'Piernas / Muslos'],
    subtypes: [
      {
        id: '3.2.1',
        name: '3.2.1 Sirena / Tritón de Arrecife Tropical',
        description: 'Escamas iridiscentes multicolor, cabello vibrante y voz melodiosa.',
        traits: {
          skinColor: 'Piel Caucásica Clara',
          eyeColor: 'Verde Esmeralda'
        }
      },
      {
        id: '3.2.2',
        name: '3.2.2 Sirena / Tritón Abisal de Fosas Marinas',
        description: 'Piel cian bioluminiscente con órganos emisores de luz y ojos cristalinos.',
        traits: {
          skinColor: 'Azul / Cian',
          scleraColor: 'SCL05 Azul Eléctrico / Cian Emisivo',
          eyeColor: 'Cian Hielo / Eléctrico'
        }
      },
      {
        id: '3.2.3',
        name: '3.2.3 Sirena / Tritón Ártico Glacial',
        description: 'Piel nívea resistente a temperaturas extremas y aletas translúcidas.',
        traits: {
          skinColor: 'Blanca Pura',
          eyeColor: 'Azul Claro',
          hairColor: 'Platino / Blanco'
        }
      }
    ],
    summary: 'Piel lisa hidrófila azul/plateada, escamas localizadas, branquias en cuello y cola pisciforme.',
    highlights: ['Cola pisciforme de sirena/tritón', 'Branquias ocultas en cuello', 'Membranas interdigitales', 'Escamas iridiscentes']
  },
  '3.3': {
    height: 'C Normal / Estándar (1.60 m – 1.80 m)',
    complexion: '2 Esbelto / Estandar',
    skinColor: 'Piel Caucásica Clara',
    scleraColor: 'SCL04 Dorada Solar / Luminiscente',
    facialMorphology: 'MORF05 Pico Afilado con Plumaje Facial (Arpía)',
    lowerBodyStructure: 'SIL05 Brazos-Alas de Arpía con Plumaje y Garras en Extremidades',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK03 Collarín de Plumas Naturales (Arpía)',
    hairElemental: 'Sin Cabello / Corona de Plumas (Arpía)',
    earsBase: 'E01 Normales',
    kemonoEars: 'KEMO-C2 Halcón/Águila',
    iris: '2 Felino',
    teeth: 'B10 No Visibles',
    hornsForm: 'Ninguno',
    wingsType: 'A16 Brazos-Alas con Plumaje de Arpía',
    wingsSize: 'S3 Grande',
    wingsPosition: 'P1 Espalda Alta',
    tailsType: 'Ninguno',
    skinAndMarks: 'T5 Plumaje Natural en Extremidades y Hombros',
    summary: 'Brazos fusionados en alas plumadas, cabeza con corona de plumas, pico afilado y garras prensiles.',
    highlights: ['Alas como brazos con plumaje', 'Pico afilado aviar', 'Corona de plumas en cabeza', 'Garras en extremidades']
  },
  '3.4': {
    height: 'E Enorme (2.00 m – 2.20 m)',
    complexion: '2 Esbelto / Estandar',
    skinColor: 'Bronceada / Oliva',
    scleraColor: 'SCL04 Dorada Solar / Luminiscente',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL03 Cola Serpentina 2.0–3.0 m en lugar de Piernas (Lamia)',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E02 Puntiagudas suaves',
    kemonoEars: 'Ninguno',
    iris: '2 Felino',
    teeth: 'B2 Afilados / Colmillos Múltiples',
    hornsForm: 'Ninguno',
    wingsType: 'Ninguno',
    tailsType: 'C18 Cola Serpentina 2.0–3.0m (Lamia)',
    tailsLength: 'L6 Extra Larga (>200 cm)',
    skinAndMarks: 'T2-Impuro Escamas Suaves Localizadas (Hombros, Espalda, Extremidades)',
    scaleLocations: ['Espalda / Dorsal', 'Piernas / Muslos'],
    summary: 'Torso humanoide fusionado con una imponente cola serpentina (2.0–3.0 m), pupila vertical y lengua bífida.',
    highlights: ['Cola/cuerpo serpentino inferior (2-3 m)', 'Pupilas verticales y lengua bífida', 'Escamas en espalda']
  },
  '3.5': {
    height: 'F Especial Racial',
    complexion: '5 Voluminoso / Robusto',
    skinColor: 'Bronceada / Oliva',
    scleraColor: 'SCL01 Blanca Estándar (Humana Clásica)',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL02 Cuerpo Taurino Equino de 4 Patas y Cascos (Centauro)',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E01 Normales',
    kemonoEars: 'KEMO-B6 Caballo',
    iris: '1 Humano',
    teeth: 'B1 Normales',
    hornsForm: 'Ninguno',
    wingsType: 'Ninguno',
    tailsType: 'C4 Equídea de Crin Larga (Centauro)',
    tailsLength: 'L4 Larga (60-120 cm)',
    skinAndMarks: 'T3 Pelo Corto',
    summary: 'Transición humano-equino en la cintura con cuerpo de 4 patas y cascos, orejas equinas y cola de crin.',
    highlights: ['Parte de abajo de caballo con 4 patas y cascos', 'Orejas equinas', 'Cola equina de crin larga', 'Estatura colosal (3.15–3.30 m)']
  },
  '3.6': {
    height: 'D Alto (1.80 m – 2.00 m)',
    complexion: '3 Atlético / Fibroso',
    skinColor: 'Bronceada / Oliva',
    scleraColor: 'SCL04 Dorada Solar / Luminiscente',
    facialMorphology: 'MORF02 Cabeza y Hocico Felino Completo (Pantheris)',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E01 Normales',
    kemonoEars: 'KEMO-A8 Pantera',
    iris: '2 Felino',
    teeth: 'B3 Colmillos Prominentes',
    hornsForm: 'Ninguno',
    wingsType: 'Ninguno',
    tailsType: 'C2-Pantheris Cola Prensil Felina 60-90cm (Pantheris)',
    tailsLength: 'L4 Larga (60-120 cm)',
    skinAndMarks: 'T3 Pelo Corto',
    summary: 'Cuerpo humanoide felino con pelaje corto, cabeza y hocico felino completo, orejas móviles y cola prensil.',
    highlights: ['Hocico y cabeza felina completa', 'Pelaje corto corporal', 'Cola prensil felina 60-90cm', 'Garras retráctiles']
  },
  '4.1': {
    height: 'C Normal / Estándar (1.60 m – 1.80 m)',
    complexion: '2 Esbelto / Estandar',
    skinColor: 'Piel Caucásica Clara',
    scleraColor: 'SCL01 Blanca Estándar (Humana Clásica)',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E01 Normales',
    kemonoEars: 'KEMO-A3 Zorro',
    iris: '2 Felino',
    eyeColor: 'Dorado / Amarillo Brillante',
    teeth: 'B1 Normales',
    hornsForm: 'Ninguno',
    wingsType: 'Ninguno',
    tailsType: 'C10-Kitsune Zorrina Kitsune Múltiple (1 a 9 Colas)',
    tailsLength: 'L4 Larga (60-120 cm)',
    skinAndMarks: 'T1 Piel Lisa',
    subtypes: [
      {
        id: '4.1.1',
        name: '4.1.1 Kitsune Zenko (Zorro Blanco Celestial / Sagrado)',
        description: 'Pelaje albino sagrado, afinidad con magia de luz pura y ojos dorados radiantes.',
        traits: {
          hairColor: 'Platino / Blanco',
          eyeColor: 'Dorado / Amarillo Brillante',
          kemonoEars: 'KEMO-A3 Zorro',
          tailsType: 'C10-Kitsune Zorrina Kitsune Múltiple (1 a 9 Colas)'
        }
      },
      {
        id: '4.1.2',
        name: '4.1.2 Kitsune Yako (Zorro Rojo Feral / Fuego Fatuo)',
        description: 'Pelaje rojizo/cobre ardiente, naturaleza pícara y orbes de fuego espiritual (Kitsunebi).',
        traits: {
          hairColor: 'Rojo Fuego',
          eyeColor: 'Ámbar / Miel',
          kemonoEars: 'KEMO-A3 Zorro',
          tailsType: 'C10-Kitsune Zorrina Kitsune Múltiple (1 a 9 Colas)'
        }
      },
      {
        id: '4.1.3',
        name: '4.1.3 Kitsune Nogitsune (Zorro Sombrío del Vacío)',
        description: 'Pelaje negro azabache, pupilas místicas violetas y dominio de ilusiones oscuras.',
        traits: {
          hairColor: 'Negro Azabache',
          eyeColor: 'Violeta / Púrpura',
          kemonoEars: 'KEMO-A3 Zorro',
          tailsType: 'C10-Kitsune Zorrina Kitsune Múltiple (1 a 9 Colas)'
        }
      },
      {
        id: '4.1.4',
        name: '4.1.4 Kitsune Kiko (Zorro Espiritual de Viento / Plata)',
        description: 'Pelaje plateado brillante, gran velocidad y comunión con espíritus elementales.',
        traits: {
          hairColor: 'Plateado / Gris Claro',
          eyeColor: 'Azul Claro',
          kemonoEars: 'KEMO-A3 Zorro',
          tailsType: 'C10-Kitsune Zorrina Kitsune Múltiple (1 a 9 Colas)'
        }
      }
    ],
    summary: 'Cuerpo 100% humanoide con orejas de zorro y de 1 a 9 colas esponjosas. Sin pelaje corporal ni hocico.',
    highlights: ['Orejas kemono de zorro', '1 a 9 colas de zorro esponjosas', 'Ojos dorados/ámbar pupila vertical', 'Piel lisa sin vello animal']
  },
  '4.2': {
    height: 'C Normal / Estándar (1.60 m – 1.80 m)',
    complexion: '2 Esbelto / Estandar',
    skinColor: 'Piel Caucásica Clara',
    scleraColor: 'SCL01 Blanca Estándar (Humana Clásica)',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E01 Normales',
    kemonoEars: 'KEMO-A1 Gato/Felino',
    iris: '2 Felino',
    teeth: 'B3 Colmillos Prominentes',
    hornsForm: 'Ninguno',
    wingsType: 'Ninguno',
    tailsType: 'C2 Felina',
    tailsLength: 'L4 Larga (60-120 cm)',
    skinAndMarks: 'T1 Piel Lisa',
    subtypes: [
      {
        id: '4.2.1',
        name: '4.2.1 Nekojin Felino Doméstico / Ágil',
        description: 'Orejas felinas expresivas, cola suave flexible y reflejos sobrenaturales.',
        traits: {
          kemonoEars: 'KEMO-A1 Gato/Felino',
          tailsType: 'C2 Felina'
        }
      },
      {
        id: '4.2.2',
        name: '4.2.2 Nekojin Leopardo de las Nieves',
        description: 'Pelaje níveo moteado, cola gruesa y esponjosa y ojos azul hielo.',
        traits: {
          skinColor: 'Piel Caucásica Pálida',
          hairColor: 'Platino / Blanco',
          eyeColor: 'Azul Claro',
          kemonoEars: 'KEMO-A8 Pantera',
          tailsType: 'C2 Felina'
        }
      },
      {
        id: '4.2.3',
        name: '4.2.3 Nekojin Pantera Sombría',
        description: 'Orejas y cola de pantera negra, ojos dorados luminosos y sigilo absoluto.',
        traits: {
          hairColor: 'Negro Azabache',
          eyeColor: 'Dorado / Amarillo Brillante',
          kemonoEars: 'KEMO-A8 Pantera',
          tailsType: 'C2 Felina'
        }
      }
    ],
    summary: 'Cuerpo humanoide con orejas felinas móviles, cola prensil, caninos visibles y pupilas verticales.',
    highlights: ['Orejas kemono felinas móviles', 'Cola felina prensil', 'Caninos pequeños visibles', 'Uñas retráctiles']
  },
  '4.3': {
    height: 'C Normal / Estándar (1.60 m – 1.80 m)',
    complexion: '2 Esbelto / Estandar',
    skinColor: 'Piel Caucásica Clara',
    scleraColor: 'SCL01 Blanca Estándar (Humana Clásica)',
    facialMorphology: 'MORF03 Hocico Canino Sutil (Inujin)',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E01 Normales',
    kemonoEars: 'KEMO-A2 Lobo',
    iris: '1 Humano',
    teeth: 'B3 Colmillos Prominentes',
    hornsForm: 'Ninguno',
    wingsType: 'Ninguno',
    tailsType: 'C3 Canina',
    tailsLength: 'L3 Media (30-60 cm)',
    skinAndMarks: 'T1 Piel Lisa',
    subtypes: [
      {
        id: '4.3.1',
        name: '4.3.1 Inujin Lobo Gris (Lupino Solitario)',
        description: 'Orejas erguidas lupinas, cola tupida y gran resistencia de carrera.',
        traits: {
          kemonoEars: 'KEMO-A2 Lobo',
          tailsType: 'C3 Canina',
          hairColor: 'Plateado / Gris Claro'
        }
      },
      {
        id: '4.3.2',
        name: '4.3.2 Inujin Zorro Ártico / Husky Boreal',
        description: 'Pelaje grueso bicolor o blanco, ojos azules penetrantes y adaptabilidad gélida.',
        traits: {
          kemonoEars: 'KEMO-A2 Lobo',
          tailsType: 'C3 Canina',
          eyeColor: 'Azul Claro'
        }
      },
      {
        id: '4.3.3',
        name: '4.3.3 Inujin Sabueso Guardián',
        description: 'Sentidos olfativos hiperdesarrollados, mirada leal y musculatura compacta.',
        traits: {
          kemonoEars: 'KEMO-A2 Lobo',
          tailsType: 'C3 Canina',
          eyeColor: 'Ámbar / Miel'
        }
      }
    ],
    summary: 'Cuerpo humanoide con orejas caninas, cola canina, nariz sutilmente canina y caninos desarrollados.',
    highlights: ['Orejas kemono caninas', 'Cola canina', 'Hocico canino sutil', 'Fidelidad innata']
  },
  '4.4': {
    height: 'E Enorme (2.00 m – 2.20 m)',
    complexion: '5 Voluminoso / Robusto',
    skinColor: 'Bronceada / Oliva',
    scleraColor: 'SCL01 Blanca Estándar (Humana Clásica)',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E01 Normales',
    kemonoEars: 'KEMO-B5 Vaca/Toro',
    iris: '1 Humano',
    teeth: 'B1 Normales',
    hornsForm: 'H2 Curvos',
    hornsLength: 'HL2 10-30 cm',
    hornsThickness: 'G4 Grueso',
    hornsPosition: 'P2 Laterales / Sienes',
    wingsType: 'Ninguno',
    tailsType: 'C7 Bovina con Mechón',
    tailsLength: 'L4 Larga (60-120 cm)',
    skinAndMarks: 'T1 Piel Lisa',
    summary: 'Cuerpo humanoide robusto, cuernos bovinos laterales, orejas y cola bovina con mechón.',
    highlights: ['Cuernos bovinos prominentes', 'Orejas y cola bovinas con mechón', 'Complexión robusta']
  },
  '4.5': {
    height: 'C Normal / Estándar (1.60 m – 1.80 m)',
    complexion: '2 Esbelto / Estandar',
    skinColor: 'Piel Caucásica Clara',
    scleraColor: 'SCL04 Dorada Solar / Luminiscente',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK01 Pelaje de Lana Suave y Esponjosa alrededor del Cuello y Hombros (Bestfolk Caprinae)',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E03 Puntiagudas marcadas',
    earsLength: 'EL2 5–10 cm',
    kemonoEars: 'KEMO-B3 Cabra',
    iris: '3 Cabra',
    teeth: 'B1 Normales',
    hornsForm: 'H3 Retorcidos / Espiral',
    hornsLength: 'HL2 10-30 cm',
    hornsThickness: 'G3 Medio',
    hornsPosition: 'P2 Laterales / Sienes',
    wingsType: 'Ninguno',
    tailsType: 'C8 Caprina Corta y Tupida',
    tailsLength: 'L2 Corta (10-30 cm)',
    skinAndMarks: 'T1 Piel Lisa',
    summary: 'Pelaje de lana suave y esponjosa alrededor del cuello, cuernos retorcidos, pupilas horizontales de cabra y cola tupida.',
    highlights: ['Pelaje de lana esponjoso en cuello y hombros', 'Pupilas horizontales caprinas', 'Cuernos retorcidos en espiral', 'Cola corta y tupida']
  },
  '4.6': {
    height: 'D Alto (1.80 m – 2.00 m)',
    complexion: '3 Atlético / Fibroso',
    skinColor: 'Piel Caucásica Clara',
    scleraColor: 'SCL04 Dorada Solar / Luminiscente',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E02 Puntiagudas suaves',
    kemonoEars: 'Ninguno',
    iris: '2 Felino',
    teeth: 'B3 Colmillos Prominentes',
    hornsForm: 'H2 Curvos',
    hornsLength: 'HL1 0-10 cm',
    hornsThickness: 'G2 Delgado',
    hornsPosition: 'P2 Laterales / Sienes',
    wingsType: 'A3 Dracónicas Membrana',
    wingsSize: 'S2 Medio',
    wingsPosition: 'P1 Espalda Alta',
    tailsType: 'C14 Dracónida Musculosa 1.2–1.5m con Crestas',
    tailsLength: 'L4 Larga (60-120 cm)',
    skinAndMarks: 'T2-Impuro Escamas Suaves Localizadas (Hombros, Espalda, Extremidades)',
    scaleLocations: ['Espalda / Dorsal', 'Hombros / Clavículas', 'Brazos / Antebrazos', 'Piernas / Muslos'],
    summary: 'Híbrido humano-dracónico con escamas suaves localizadas, cola de 50-120cm, pupilas verticales y alas medianas.',
    highlights: ['Escamas localizadas en hombros/extremidades', 'Cola dracónica flexible', 'Pupila vertical', 'Alas semi-funcionales']
  },
  '5.1': {
    height: 'E Enorme (2.00 m – 2.20 m)',
    complexion: '3 Atlético / Fibroso',
    skinColor: 'Negra / Ébano',
    scleraColor: 'SCL02 Negra Azabache / Abisal (Vantablack)',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR04 Runas Dérmicas Pulsantes en el Pecho (Demonio Noble)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E03 Puntiagudas marcadas',
    kemonoEars: 'Ninguno',
    iris: '2 Felino',
    eyeColor: 'Rojo Carmesí',
    teeth: 'B3 Colmillos Prominentes',
    hornsForm: 'H3 Retorcidos / Espiral',
    hornsLength: 'HL3 30-60 cm',
    hornsThickness: 'G4 Grueso',
    hornsPosition: 'P2 Laterales / Sienes',
    wingsType: 'A6 Murciélago Membranosas (Demonio Noble)',
    wingsSize: 'S3 Grande',
    wingsPosition: 'P1 Espalda Alta',
    tailsType: 'C1-Noble Demoníaca Clásica con Púas',
    tailsLength: 'L4 Larga (60-120 cm)',
    skinAndMarks: 'T1 Piel Lisa',
    markTypes: ['M7 Sello Mágico / Runa Maldita'],
    summary: 'Piel oscura con brillo metálico y runas dérmicas, cuernos elegantes, alas membranosas y esclerótica negra.',
    highlights: ['Esclerótica negra abisal', 'Runas dérmicas en pecho', 'Cuernos elegantes en espiral', 'Alas membranosas oscuras']
  },
  '5.2': {
    height: 'C Normal / Estándar (1.60 m – 1.80 m)',
    complexion: '2 Esbelto / Estandar',
    skinColor: 'Piel Caucásica Pálida',
    scleraColor: 'SCL06 Púrpura / Amatista Mística',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR03 Sello de Servidumbre Demoníaco en el Vientre (Incubus Sucuboforme)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E03 Puntiagudas marcadas',
    kemonoEars: 'Ninguno',
    iris: '2 Felino',
    eyeColor: 'Violeta / Púrpura',
    teeth: 'B3 Colmillos Prominentes',
    hornsForm: 'H2 Curvos',
    hornsLength: 'HL2 10-30 cm',
    hornsThickness: 'G2 Delgado',
    hornsPosition: 'P2 Laterales / Sienes',
    wingsType: 'A6 Murciélago Membranosas (Demonio Noble)',
    wingsSize: 'S2 Medio',
    wingsPosition: 'P1 Espalda Alta',
    tailsType: 'C1 Demoníaca con Punta de Corazón (Incubus/Succubus)',
    tailsLength: 'L4 Larga (60-120 cm)',
    skinAndMarks: 'T2-Impuro Escamas Suaves Localizadas (Hombros, Espalda, Extremidades)',
    scaleLocations: ['Espalda / Dorsal', 'Piernas / Muslos'],
    subtypes: [
      {
        id: '5.2.1',
        name: '5.2.1 Incubus',
        description: 'Esbelto (1.65–1.80 m), cuernos de fauno, escamas localizadas, cola con punta de corazón, lengua bífida.',
        traits: {
          complexion: '2 Esbelto / Estandar',
          height: 'C Normal / Estándar (1.60 m – 1.80 m)',
          chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)'
        }
      },
      {
        id: '5.2.2',
        name: '5.2.2 Succubus',
        description: 'Curvilínea/rellena (1.50–1.80 m), desarrollo mamario pronunciado, cola punta de corazón y alas membranosas.',
        traits: {
          complexion: '8 Relleno',
          height: 'C Normal / Estándar (1.60 m – 1.80 m)',
          breastDevelopment: 'E Senos Abundantes / Pechos Enormes / Copa DD-E'
        }
      },
      {
        id: '5.2.3',
        name: '5.2.3 Incubus Sucuboforme',
        description: 'Silueta parcialmente feminizada, sello de servidumbre en el vientre, cola con punta de corazón.',
        traits: {
          complexion: '2 Esbelto / Estandar',
          chestCore: 'COR03 Sello de Servidumbre Demoníaco en el Vientre (Incubus Sucuboforme)',
          breastDevelopment: 'B Senos Pequeños / Pechos Discretos / Copa A'
        }
      }
    ],
    summary: 'Cuernos de fauno/demonio, cola con punta de corazón, escamas suaves localizadas y sello de servidumbre.',
    highlights: ['Cola con punta de corazón', 'Cuernos demoníacos estilizados', 'Sello de servidumbre en vientre', 'Alas de murciélago']
  },
  '5.3': {
    height: 'D Alto (1.80 m – 2.00 m)',
    complexion: '2 Esbelto / Estandar',
    skinColor: 'Piel Caucásica Pálida',
    scleraColor: 'SCL03 Rojo Carmesí / Sangrienta',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E02 Puntiagudas suaves',
    kemonoEars: 'Ninguno',
    iris: '2 Felino',
    eyeColor: 'Rojo Carmesí',
    teeth: 'B3 Colmillos Prominentes',
    hornsForm: 'Ninguno',
    wingsType: 'Ninguno',
    tailsType: 'Ninguno',
    skinAndMarks: 'T12 Piel Marmórea Pálida con Venas Azules Visibles (Vampiro)',
    summary: 'Piel pálida marmórea con venas azules visibles, colmillos retráctiles y ojos rojos luminiscentes.',
    highlights: ['Piel marmórea con venas azules visibles', 'Colmillos afilados retráctiles', 'Esclerótica roja carmesí', 'Sin alas ni cuernos']
  },
  '5.4': {
    height: 'E Enorme (2.00 m – 2.20 m)',
    complexion: '6 Hipertrofiado / Musculatura Extrema',
    skinColor: 'Negra / Ébano',
    scleraColor: 'SCL02 Negra Azabache / Abisal (Vantablack)',
    facialMorphology: 'MORF09 Mandíbula Serrada Abisal con Dentición Predadora (Carnicero)',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK05 Vientre y Garganta con Escamas Gruesas Dracónicas',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E03 Puntiagudas marcadas',
    kemonoEars: 'Ninguno',
    iris: '2 Felino',
    eyeColor: 'Rojo Carmesí',
    teeth: 'B8 Serrados',
    hornsForm: 'H3 Retorcidos / Espiral',
    hornsLength: 'HL3 30-60 cm',
    hornsThickness: 'G5 Muy Grueso',
    hornsPosition: 'P2 Laterales / Sienes',
    wingsType: 'Ninguno',
    tailsType: 'C14 Dracónida Musculosa 1.2–1.5m con Crestas',
    tailsLength: 'L3 Media (30-60 cm)',
    skinAndMarks: 'T2 Piel Escamosa Dracónica Pura',
    markTypes: ['M5 Cicatriz de Batalla / Quemadura'],
    summary: 'Musculatura masiva, escamas de armadura, cuernos retorcidos, ojos con esclerótica negra azabache y mandíbula serrada.',
    highlights: ['Esclerótica negra azabache (ojos abisales)', 'Mandíbula serrada con dientes predadores', 'Escamas blindadas pesadas', 'Cuernos gruesos retorcidos']
  },
  '6.1': {
    height: 'E Enorme (2.00 m – 2.20 m)',
    complexion: '2 Esbelto / Estandar',
    skinColor: 'Dorada / Metálica',
    scleraColor: 'SCL10 Inexistente / Rostro sin Ojos',
    facialMorphology: 'MORF06 Rostro Liso Translúcido sin Ojos ni Boca con Órgano Sensorial (Demiurgo)',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR01 Núcleo de Energía Resplandeciente en el Pecho (Plasmoide / Demiurgo)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Sin Cabello / Superficie Lisa Luminiscente (Demiurgo / Androide)',
    earsBase: 'E01 Normales',
    kemonoEars: 'Ninguno',
    iris: '9 Vacío',
    teeth: 'B10 No Visibles',
    nose: '15 No Humana / Hendiduras',
    hornsForm: 'Ninguno',
    wingsType: 'A14 Energéticas / Etéreas',
    wingsSize: 'S3 Grande',
    wingsPosition: 'P1 Espalda Alta',
    tailsType: 'Ninguno',
    skinAndMarks: 'T17 Superficie Translúcida Bioluminiscente (Celestial/Ángel)',
    summary: 'Asexual absoluto, superficie translúcida luminiscente sin ojos ni boca, con órgano sensorial central y núcleo en el pecho.',
    highlights: ['Rostro liso translúcido sin ojos ni boca', 'Núcleo de energía en el pecho', 'Superficie bioluminiscente dorada/azul', 'Proyecciones energéticas']
  },
  '6.2': {
    height: 'D Alto (1.80 m – 2.00 m)',
    complexion: '2 Esbelto / Estandar',
    skinColor: 'Blanca Pura',
    scleraColor: 'SCL04 Dorada Solar / Luminiscente',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E02 Puntiagudas suaves',
    kemonoEars: 'Ninguno',
    iris: '6 Cristalino',
    eyeColor: 'Dorado / Amarillo Brillante',
    teeth: 'B1 Normales',
    hornsForm: 'Ninguno',
    wingsType: 'A2 Angélicas Celestiales (1 Par)',
    wingsSize: 'S3 Grande',
    wingsPosition: 'P1 Espalda Alta',
    tailsType: 'Ninguno',
    skinAndMarks: 'T17 Superficie Translúcida Bioluminiscente (Celestial/Ángel)',
    summary: 'Cuerpo esbelto, piel blanca bioluminiscente, alas nacidas de omóplatos (1 a 3 pares) y ojos dorados/plateados.',
    highlights: ['Alas angélicas celestiales (1 a 3 pares)', 'Piel blanca translúcida bioluminiscente', 'Marcas escapulares en omóplatos', 'Ojos dorados emisivos']
  },
  '6.3': {
    height: 'D Alto (1.80 m – 2.00 m)',
    complexion: '2 Esbelto / Estandar',
    skinColor: 'Blanca Pura',
    scleraColor: 'SCL04 Dorada Solar / Luminiscente',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E02 Puntiagudas suaves',
    kemonoEars: 'Ninguno',
    iris: '6 Cristalino',
    eyeColor: 'Azul Claro',
    teeth: 'B1 Normales',
    hornsForm: 'Ninguno',
    wingsType: 'A2-Nefelim Una Sola Ala Asimétrica Única (Nefelim)',
    wingsSize: 'S3 Grande',
    wingsPosition: 'P1 Espalda Alta',
    tailsType: 'Ninguno',
    skinAndMarks: 'T17 Superficie Translúcida Bioluminiscente (Celestial/Ángel)',
    subtypes: [
      {
        id: '6.3.1',
        name: '6.3.1 XXY (Morfología Base Masculina con Rasgos Femeninos)',
        description: 'Base anatómica masculina con facciones suaves, una sola ala asimétrica y marcas escapulares.',
        traits: {
          sexBase: '3 Andrógino',
          wingsType: 'A2-Nefelim Una Sola Ala Asimétrica Única (Nefelim)'
        }
      },
      {
        id: '6.3.2',
        name: '6.3.2 Hermafrodita Secuencial',
        description: 'Capacidad de alternancia biológica, piel luminiscente y una sola ala celestial.',
        traits: {
          sexBase: '3 Andrógino',
          wingsType: 'A2-Nefelim Una Sola Ala Asimétrica Única (Nefelim)'
        }
      },
      {
        id: '6.3.3',
        name: '6.3.3 Intermedio-Dual (Futanari / Ginándrico)',
        description: 'Fusión anatómica completa de rasgos con una sola ala asimétrica funcional.',
        traits: {
          sexBase: '3 Andrógino',
          wingsType: 'A2-Nefelim Una Sola Ala Asimétrica Única (Nefelim)'
        }
      }
    ],
    summary: 'Híbrido humano-celestial con una sola ala única asimétrica, piel luminiscente y marcas escapulares.',
    highlights: ['Una sola ala asimétrica única (Nefelim)', 'Piel pálida luminiscente', 'Marcas escapulares en omóplatos', 'Subtipos andróginos / duales']
  },
  '7.1': {
    height: 'C Normal / Estándar (1.60 m – 1.80 m)',
    complexion: '2 Esbelto / Estandar',
    skinColor: 'Roja / Carmesí',
    scleraColor: 'SCL09 Translúcida / Plasma Luminoso',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL07 Matriz Ectoplásmica Flotante / Espectral (Elemental)',
    chestCore: 'COR01 Núcleo de Energía Resplandeciente en el Pecho (Plasmoide / Demiurgo)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Fuego y Llamas Ardientes (Elemental Fuego)',
    earsBase: 'E02 Puntiagudas suaves',
    kemonoEars: 'Ninguno',
    iris: '7 Fantástico',
    teeth: 'B1 Normales',
    hornsForm: 'Ninguno',
    wingsType: 'A14 Energéticas / Etéreas',
    wingsSize: 'S2 Medio',
    wingsPosition: 'P1 Espalda Alta',
    tailsType: 'Ninguno',
    skinAndMarks: 'T9 Cristalina',
    subtypes: [
      {
        id: '7.1.1',
        name: 'Elemental de Fuego (Ígneo)',
        description: 'Cabello de fuego y llamas ardientes, piel carmesí brillante y ojos de plasma solar.',
        traits: {
          hairElemental: 'Fuego y Llamas Ardientes (Elemental Fuego)',
          skinColor: 'Roja / Carmesí',
          eyeColor: 'Rojo Carmesí',
          hairColor: 'Rojo Fuego'
        }
      },
      {
        id: '7.1.2',
        name: 'Elemental de Agua (Acuático)',
        description: 'Cabello de agua fluida cristalina líquida, piel azul translúcida y ojos de zafiro.',
        traits: {
          hairElemental: 'Agua Fluida Líquida Cristalina (Elemental Agua)',
          skinColor: 'Azul / Cian',
          eyeColor: 'Azul Claro',
          hairColor: 'Azul Oscuro'
        }
      },
      {
        id: '7.1.3',
        name: 'Elemental de Aire (Etéreo)',
        description: 'Cabello de vórtice de aire y brisa etérea, cuerpo translúcido flotante.',
        traits: {
          hairElemental: 'Vórtice de Aire y Brisa Etérea (Elemental Aire)',
          skinColor: 'Blanca Pura',
          eyeColor: 'Blanco Ciego / Vacío',
          hairColor: 'Platino / Blanco'
        }
      },
      {
        id: '7.1.4',
        name: 'Elemental de Tierra (Geomante / Silvano)',
        description: 'Cabello de lianas, espinas y hojas vivas, piel queratinizada y ojos de esmeralda.',
        traits: {
          hairElemental: 'Lianas, Espinas y Hojas Vivas (Elemental Tierra)',
          skinColor: 'Bronceada / Oliva',
          eyeColor: 'Verde Esmeralda',
          hairColor: 'Verde Bosque'
        }
      }
    ],
    summary: 'Matriz coloidal elemental pura sin órganos convencionales, con cabellos de elementos vivos (fuego, agua, aire, tierra).',
    highlights: ['Cabello de elementos (fuego, agua, aire o tierra)', 'Ojos de plasma luminoso', 'Núcleo de energía en el pecho', 'Matriz elemental translúcida']
  },
  '7.2': {
    height: 'F Especial Racial',
    complexion: '1 Escuálido / Muy Delgado',
    skinColor: 'Piel Caucásica Pálida',
    scleraColor: 'SCL04 Dorada Solar / Luminiscente',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Polvo de Hadas y Partículas Luminiscentes (Hada)',
    earsBase: 'E03 Puntiagudas marcadas',
    earsLength: 'EL2 5–10 cm',
    kemonoEars: 'Ninguno',
    iris: '6 Cristalino',
    eyeColor: 'Rosa',
    teeth: 'B1 Normales',
    hornsForm: 'Ninguno',
    wingsType: 'A8 Hada / Fae Membranosas de Energía',
    wingsSize: 'S2 Medio',
    wingsPosition: 'P1 Espalda Alta',
    tailsType: 'Ninguno',
    skinAndMarks: 'T17 Superficie Translúcida Bioluminiscente (Celestial/Ángel)',
    summary: 'Escala diminuta (10–25 cm), exoesqueleto translúcido luminiscente, alas de hada de energía y cabello de polvo de estrellas.',
    highlights: ['Estatura diminuta Fae (10–25 cm)', 'Alas de hada de energía resplandeciente', 'Cabello de polvo de hadas luminoso', 'Orejas puntiagudas translúcidas']
  },
  '7.3': {
    height: 'C Normal / Estándar (1.60 m – 1.80 m)',
    complexion: '2 Esbelto / Estandar',
    skinColor: 'Piel Caucásica Clara',
    scleraColor: 'SCL05 Azul Eléctrico / Cian Emisivo',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Filamentos de Plasma Energético (Ninfa / Plasmoide)',
    earsBase: 'E03 Puntiagudas marcadas',
    kemonoEars: 'Ninguno',
    iris: '6 Cristalino',
    eyeColor: 'Verde Esmeralda',
    teeth: 'B1 Normales',
    hornsForm: 'H4 Ramificados',
    hornsLength: 'HL2 10-30 cm',
    hornsThickness: 'G2 Delgado',
    hornsPosition: 'P2 Laterales / Sienes',
    wingsType: 'A8 Hada / Fae Membranosas de Energía',
    wingsSize: 'S2 Medio',
    wingsPosition: 'P1 Espalda Alta',
    tailsType: 'Ninguno',
    skinAndMarks: 'T17 Superficie Translúcida Bioluminiscente (Celestial/Ángel)',
    summary: 'Cuerpo etéreo semitranslúcido con cabello de filamentos energéticos, cuernos ramificados / alas translúcidas.',
    highlights: ['Cabello de filamentos energéticos', 'Cuernos ramificados en machos / alas translúcidas en hembras', 'Piel con brillo perlado']
  },
  '8.1': {
    height: 'D Alto (1.80 m – 2.00 m)',
    complexion: '2 Esbelto / Estandar',
    skinColor: 'Azul / Cian',
    scleraColor: 'SCL09 Translúcida / Plasma Luminoso',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL06 Matriz Amorfa Gelatinosa / Slime Replicante que babea / escurre gel (Plasmoide)',
    chestCore: 'COR01 Núcleo de Energía Resplandeciente en el Pecho (Plasmoide / Demiurgo)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Filamentos de Plasma Energético (Ninfa / Plasmoide)',
    earsBase: 'E02 Puntiagudas suaves',
    kemonoEars: 'Ninguno',
    iris: '7 Fantástico',
    eyeColor: 'Cian Hielo / Eléctrico',
    teeth: 'B10 No Visibles',
    hornsForm: 'Ninguno',
    wingsType: 'Ninguno',
    tailsType: 'Ninguno',
    skinAndMarks: 'T11 Piel de Slime / Matriz Gelatinosa Translúcida (Plasmoide)',
    subtypes: [
      {
        id: '8.1.1',
        name: 'Forma Androide (Masculina / 1.80 m)',
        description: 'Matriz fluida polimérica translúcida con silueta androide y núcleo en el pecho.',
        traits: {
          sexBase: '1 Hombre',
          height: 'D Alto (1.80 m – 2.00 m)'
        }
      },
      {
        id: '8.1.2',
        name: 'Forma Ginoide (Femenina / 1.70 m)',
        description: 'Matriz fluida polimérica translúcida con silueta ginoide y núcleo en el pecho.',
        traits: {
          sexBase: '2 Mujer',
          height: 'C Normal / Estándar (1.60 m – 1.80 m)'
        }
      }
    ],
    summary: 'Piel de slime gelatinosa translúcida, núcleo de energía resplandeciente en el pecho y ojos de plasma sin pupila.',
    highlights: ['Piel de slime / gelatina translúcida', 'Núcleo de energía resplandeciente en el pecho', 'Ojos de plasma luminoso', 'Capacidad de licuefacción']
  },
  '8.2': {
    height: 'C Normal / Estándar (1.60 m – 1.80 m)',
    complexion: '2 Esbelto / Estandar',
    skinColor: 'Morada / Púrpura',
    scleraColor: 'SCL06 Púrpura / Amatista Mística',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL06 Matriz Amorfa Gelatinosa / Slime Replicante que babea / escurre gel (Plasmoide)',
    chestCore: 'COR01 Núcleo de Energía Resplandeciente en el Pecho (Plasmoide / Demiurgo)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Filamentos de Plasma Energético (Ninfa / Plasmoide)',
    earsBase: 'E03 Puntiagudas marcadas',
    kemonoEars: 'Ninguno',
    iris: '7 Fantástico',
    eyeColor: 'Violeta / Púrpura',
    teeth: 'B2 Afilados / Colmillos Múltiples',
    hornsForm: 'Ninguno',
    wingsType: 'Ninguno',
    tailsType: 'Ninguno',
    skinAndMarks: 'T11 Piel de Slime / Matriz Gelatinosa Translúcida (Plasmoide)',
    summary: 'Matriz amorfa gelatinosa oscura, piel negra/morada fosforescente, núcleo en el pecho y alta capacidad metamórfica.',
    highlights: ['Matriz gelatinosa fosforescente', 'Núcleo en el pecho', 'Boca expandible con colmillos', 'Ojos de plasma onírico']
  },
  '9.1': {
    height: 'D Alto (1.80 m – 2.00 m)',
    complexion: '3 Atlético / Fibroso',
    skinColor: 'Piel Caucásica Pálida',
    scleraColor: 'SCL05 Azul Eléctrico / Cian Emisivo',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR05 Puertos de Datos y Núcleo Sintético (Androide)',
    neckFeature: 'NCK04 Placas de Blindaje y Puertos Cibernéticos en el Cuello (Androide)',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E01 Normales',
    kemonoEars: 'Ninguno',
    iris: '8 Artificial',
    eyeColor: 'Azul Claro',
    teeth: 'B1 Normales',
    hornsForm: 'Ninguno',
    wingsType: 'A13 Mecánicas / Artificiales',
    wingsSize: 'S2 Medio',
    wingsPosition: 'P1 Espalda Alta',
    tailsType: 'Ninguno',
    skinAndMarks: 'T14 Epidermis Sintética con Blindaje y Puertos (Androide)',
    markTypes: ['M9 Circuitos / Líneas Cibernéticas'],
    summary: 'Chasis humanoide con epidermis sintética, placas de blindaje, puertos de datos y ojos con iris artificial.',
    highlights: ['Epidermis sintética y placas de blindaje', 'Puertos de datos y núcleo sintético', 'Ojos con iris cibernético artificial', 'Circuitos luminosos']
  },
  '9.2': {
    height: 'C Normal / Estándar (1.60 m – 1.80 m)',
    complexion: '2 Esbelto / Estandar',
    skinColor: 'Pálida Enfermiza',
    scleraColor: 'SCL08 Lechosa / Nublada Ciega (No-muertos)',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR02 Nodos de Biomasa Coloidal Visibles (Homúnculo)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E01 Normales',
    kemonoEars: 'Ninguno',
    iris: '9 Vacío',
    eyeColor: 'Blanco Ciego / Vacío',
    teeth: 'B1 Normales',
    hornsForm: 'Ninguno',
    wingsType: 'Ninguno',
    tailsType: 'Ninguno',
    skinAndMarks: 'T16 Biomasa Coloidal con Nodos (Homúnculo)',
    subtypes: [
      {
        id: '9.2.1',
        name: '9.2.1 Modelo Básico (Andrógino / Gelatinoso)',
        description: 'Delgado/esbelto (1.00–1.60 m), piel clara translúcida, iris vacío y nodos de biomasa.',
        traits: {
          height: 'B Petite (1.40 m – 1.60 m)',
          complexion: '1 Escuálido / Muy Delgado',
          sexBase: '3 Andrógino'
        }
      },
      {
        id: '9.2.2',
        name: '9.2.2 Modelo Avanzado (Queratinizado / Robusto)',
        description: 'Atlético/musculoso (1.50–1.90 m), piel queratinizada opaca resistente y regeneración acelerada.',
        traits: {
          height: 'C Normal / Estándar (1.60 m – 1.80 m)',
          complexion: '3 Atlético / Fibroso'
        }
      },
      {
        id: '9.2.3',
        name: '9.2.3 Modelo Experimental (Variable)',
        description: 'Biomasa coloidal con ADN recombinante y nodos visibles en torso.',
        traits: {
          complexion: '2 Esbelto / Estandar'
        }
      }
    ],
    summary: 'Biomasa coloidal con nodos visibles, ojos con iris vacíos y regeneración acelerada.',
    highlights: ['Nodos de biomasa coloidal visibles', 'Iris y pupilas vacías', 'Biomasa en constante regeneración']
  },
  '9.3': {
    height: 'D Alto (1.80 m – 2.00 m)',
    complexion: '2 Esbelto / Estandar',
    skinColor: 'Piel Caucásica Pálida',
    scleraColor: 'SCL03 Rojo Carmesí / Sangrienta',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E02 Puntiagudas suaves',
    kemonoEars: 'Ninguno',
    iris: '2 Felino',
    eyeColor: 'Rojo Carmesí',
    teeth: 'B3 Colmillos Prominentes',
    hornsForm: 'Ninguno',
    wingsType: 'Ninguno',
    tailsType: 'Ninguno',
    skinAndMarks: 'T12 Piel Marmórea Pálida con Venas Azules Visibles (Vampiro)',
    summary: 'Condición mutacional sobre base humanoide: piel pálida marmórea con venas azules, colmillos retráctiles y ojos rojos.',
    highlights: ['Venas azules visibles bajo piel pálida', 'Colmillos retráctiles', 'Esclerótica rojiza', 'Intolerancia solar']
  },
  '9.4': {
    height: 'C Normal / Estándar (1.60 m – 1.80 m)',
    complexion: '1 Escuálido / Muy Delgado',
    skinColor: 'Gris / Ceniza',
    scleraColor: 'SCL08 Lechosa / Nublada Ciega (No-muertos)',
    facialMorphology: 'MORF01 Estándar Humanoide',
    lowerBodyStructure: 'SIL01 Bípedo Humanoide Estándar (Piernas)',
    chestCore: 'COR00 Ninguno (Torso Orgánico Estándar)',
    neckFeature: 'NCK00 Ninguno (Cuello Estándar)',
    hairElemental: 'Cabello Orgánico Natural',
    earsBase: 'E01 Normales',
    kemonoEars: 'Ninguno',
    iris: '9 Vacío',
    eyeColor: 'Blanco Ciego / Vacío',
    teeth: 'B4 Irregulares',
    hornsForm: 'Ninguno',
    wingsType: 'Ninguno',
    tailsType: 'Ninguno',
    skinAndMarks: 'T15 Piel Cadavérica Degradada Verdosa (Zombi)',
    markTypes: ['M5 Cicatriz de Batalla / Quemadura'],
    summary: 'Cuerpo cadavérico degradado, piel grisácea/verdosa, ojos nublados con esclerótica lechosa y sin pulso vital.',
    highlights: ['Esclerótica lechosa / nublada ciega', 'Piel cadavérica verdosa degradada', 'Ojos vacíos sin expresión']
  }
};

export const applyRaceSuggestedTraits = (
  raceId: string,
  subtypeId?: string,
  currentState?: CharacterState
): Partial<CharacterState> => {
  const preset = RACE_PRESET_TRAITS[raceId];
  if (!preset) return {};

  let specificTraits: Partial<RacePresetTraitDefinition> = {};
  if (subtypeId && preset.subtypes) {
    const sub = preset.subtypes.find(s => s.id === subtypeId);
    if (sub && sub.traits) {
      specificTraits = sub.traits;
    }
  }

  const merged = { ...preset, ...specificTraits };

  const anatomyUpdate = {
    ...(currentState?.anatomy || {}),
    ...(merged.height ? { height: merged.height } : {}),
    ...(merged.complexion ? { complexion: merged.complexion } : {}),
    ...(merged.skinColor ? { skinColor: merged.skinColor } : {}),
    ...(merged.lowerBodyStructure ? { lowerBodyStructure: merged.lowerBodyStructure } : {}),
    ...(merged.chestCore ? { chestCore: merged.chestCore } : {}),
    ...(merged.neckFeature ? { neckFeature: merged.neckFeature } : {}),
    ...(merged.sexBase ? { sexBase: merged.sexBase } : {}),
    ...(merged.breastDevelopment ? { breastDevelopment: merged.breastDevelopment } : {})
  };

  const facialUpdate = {
    ...(currentState?.facial || {}),
    ...(merged.scleraColor ? { scleraColor: merged.scleraColor } : {}),
    ...(merged.facialMorphology ? { facialMorphology: merged.facialMorphology } : {}),
    ...(merged.earsBase ? { earsBase: merged.earsBase } : {}),
    ...(merged.earsLength ? { earsLength: merged.earsLength } : {}),
    ...(merged.kemonoEars ? { kemonoEars: merged.kemonoEars } : {}),
    ...(merged.iris ? { iris: merged.iris } : {}),
    ...(merged.eyesCategory ? { eyesCategory: merged.eyesCategory } : {}),
    ...(merged.eyesSubtype ? { eyesSubtype: merged.eyesSubtype } : {}),
    ...(merged.eyeColor ? { eyeColor: merged.eyeColor } : {}),
    ...(merged.teeth ? { teeth: merged.teeth } : {}),
    ...(merged.nose ? { nose: merged.nose } : {})
  };

  const hairUpdate = {
    ...(currentState?.hair || {}),
    ...(merged.hairElemental ? { hairElemental: merged.hairElemental } : {}),
    ...(merged.hairColor ? { hairColor: merged.hairColor } : {})
  };

  const appendicesUpdate = {
    ...(currentState?.appendices || {}),
    ...(merged.hornsForm ? { hornsForm: merged.hornsForm } : {}),
    ...(merged.hornsLength ? { hornsLength: merged.hornsLength } : {}),
    ...(merged.hornsThickness ? { hornsThickness: merged.hornsThickness } : {}),
    ...(merged.hornsPosition ? { hornsPosition: merged.hornsPosition } : {}),
    ...(merged.wingsType ? { wingsType: merged.wingsType } : {}),
    ...(merged.wingsSize ? { wingsSize: merged.wingsSize } : {}),
    ...(merged.wingsPosition ? { wingsPosition: merged.wingsPosition } : {}),
    ...(merged.tailsType ? { tailsType: merged.tailsType } : {}),
    ...(merged.tailsLength ? { tailsLength: merged.tailsLength } : {}),
    ...(merged.skinAndMarks ? { skinAndMarks: merged.skinAndMarks } : {}),
    ...(merged.scaleLocations ? { scaleLocations: merged.scaleLocations } : {}),
    ...(merged.markTypes ? { markTypes: merged.markTypes } : {}),
    ...(merged.antennaeType ? { antennaeType: merged.antennaeType } : {}),
    ...(merged.antennaeLength ? { antennaeLength: merged.antennaeLength } : {}),
    ...(merged.antennaePosition ? { antennaePosition: merged.antennaePosition } : {}),
    ...(merged.extraEyes ? { extraEyes: merged.extraEyes } : {}),
    ...(merged.extraArms ? { extraArms: merged.extraArms } : {}),
    ...(merged.specialLimbs ? { specialLimbs: merged.specialLimbs } : {}),
    ...(merged.lowerBodyStructure ? { lowerBodyStructure: merged.lowerBodyStructure } : {})
  };

  return {
    anatomy: anatomyUpdate as any,
    facial: facialUpdate as any,
    hair: hairUpdate as any,
    appendices: appendicesUpdate as any
  };
};

export const isEligibleForHybridPrimary = (raceId: string): boolean => {
  return raceId === '1.1' || raceId === '5.2';
};

export interface HybridInheritanceOptions {
  inheritAppendices?: boolean; // Horns, wings, tails, kemono ears
  inheritFacialAndEyes?: boolean; // Sclera, iris, teeth, earsBase, morphology
  inheritSkinAndStructure?: boolean; // Skin color/marks, neck, chest core, lower body
  inheritHairElemental?: boolean; // Hair elemental/magical effects
}

export const applyHybridRaceMixing = (
  primaryRaceId: string,
  secondaryRaceId: string,
  options: HybridInheritanceOptions,
  currentState: any,
  secondarySubtypeId?: string,
  primarySubtypeId?: string,
  dominanceRatio?: string
) => {
  const primaryPreset: Record<string, any> = (RACE_PRESET_TRAITS as Record<string, any>)[primaryRaceId] || {};
  const secondaryPreset: Record<string, any> = (RACE_PRESET_TRAITS as Record<string, any>)[secondaryRaceId] || {};

  let primarySubTraits: Record<string, any> = {};
  if (primarySubtypeId && primaryPreset.subtypes) {
    const pSub = primaryPreset.subtypes.find((s: any) => s.id === primarySubtypeId);
    if (pSub && pSub.traits) primarySubTraits = pSub.traits;
  }

  let secondarySubTraits: Record<string, any> = {};
  if (secondarySubtypeId && secondaryPreset.subtypes) {
    const sSub = secondaryPreset.subtypes.find((s: any) => s.id === secondarySubtypeId);
    if (sSub && sSub.traits) secondarySubTraits = sSub.traits;
  }

  const primaryTraits = { ...primaryPreset, ...primarySubTraits };
  const secondaryTraits = { ...secondaryPreset, ...secondarySubTraits };

  const anatomyUpdate = { ...(currentState?.anatomy || {}) };
  const facialUpdate = { ...(currentState?.facial || {}) };
  const hairUpdate = { ...(currentState?.hair || {}) };
  const appendicesUpdate = { ...(currentState?.appendices || {}) };

  // Appendices from secondary race
  if (options.inheritAppendices) {
    if (secondaryTraits.hornsForm && secondaryTraits.hornsForm !== 'Ninguno') {
      appendicesUpdate.hornsForm = secondaryTraits.hornsForm;
      appendicesUpdate.hornsLength = secondaryTraits.hornsLength || 'HL2 10-30 cm';
      appendicesUpdate.hornsThickness = secondaryTraits.hornsThickness || 'G3 Medio';
      appendicesUpdate.hornsPosition = secondaryTraits.hornsPosition || 'P1 Frontales';
    }
    if (secondaryTraits.wingsType && secondaryTraits.wingsType !== 'Ninguno') {
      appendicesUpdate.wingsType = secondaryTraits.wingsType;
      appendicesUpdate.wingsSize = secondaryTraits.wingsSize || 'S2 Medio';
      appendicesUpdate.wingsPosition = secondaryTraits.wingsPosition || 'P1 Espalda Alta';
    }
    if (secondaryTraits.tailsType && secondaryTraits.tailsType !== 'Ninguno') {
      appendicesUpdate.tailsType = secondaryTraits.tailsType;
      appendicesUpdate.tailsLength = secondaryTraits.tailsLength || 'L3 Media (30-60 cm)';
    }
    if (secondaryTraits.kemonoEars && secondaryTraits.kemonoEars !== 'Ninguno') {
      facialUpdate.kemonoEars = secondaryTraits.kemonoEars;
    }
    if (secondaryTraits.antennaeType && secondaryTraits.antennaeType !== 'Ninguno') {
      appendicesUpdate.antennaeType = secondaryTraits.antennaeType;
      appendicesUpdate.antennaeLength = secondaryTraits.antennaeLength;
      appendicesUpdate.antennaePosition = secondaryTraits.antennaePosition;
    }
    if (secondaryTraits.extraArms) appendicesUpdate.extraArms = secondaryTraits.extraArms;
    if (secondaryTraits.extraEyes) appendicesUpdate.extraEyes = secondaryTraits.extraEyes;
    if (secondaryTraits.specialLimbs) appendicesUpdate.specialLimbs = secondaryTraits.specialLimbs;
  }

  // Facial & Eyes from secondary race
  if (options.inheritFacialAndEyes) {
    if (secondaryTraits.scleraColor) facialUpdate.scleraColor = secondaryTraits.scleraColor;
    if (secondaryTraits.iris) facialUpdate.iris = secondaryTraits.iris;
    if (secondaryTraits.eyeColor) facialUpdate.eyeColor = secondaryTraits.eyeColor;
    if (secondaryTraits.teeth && secondaryTraits.teeth !== 'B1 Normales') facialUpdate.teeth = secondaryTraits.teeth;
    if (secondaryTraits.earsBase && secondaryTraits.earsBase !== 'E01 Normales') {
      facialUpdate.earsBase = secondaryTraits.earsBase;
      if (secondaryTraits.earsLength) facialUpdate.earsLength = secondaryTraits.earsLength;
    }
    if (secondaryTraits.facialMorphology && secondaryTraits.facialMorphology !== 'MORF01 Estándar Humanoide') {
      facialUpdate.facialMorphology = secondaryTraits.facialMorphology;
    }
    if (secondaryTraits.eyesCategory) facialUpdate.eyesCategory = secondaryTraits.eyesCategory;
    if (secondaryTraits.eyesSubtype) facialUpdate.eyesSubtype = secondaryTraits.eyesSubtype;
    if (secondaryTraits.nose) facialUpdate.nose = secondaryTraits.nose;
  }

  // Skin & Anatomy structure
  if (options.inheritSkinAndStructure) {
    if (secondaryTraits.skinColor) anatomyUpdate.skinColor = secondaryTraits.skinColor;
    if (secondaryTraits.skinAndMarks && secondaryTraits.skinAndMarks !== 'T1 Piel Lisa') {
      appendicesUpdate.skinAndMarks = secondaryTraits.skinAndMarks;
    }
    if (secondaryTraits.scaleLocations && secondaryTraits.scaleLocations.length > 0) {
      appendicesUpdate.scaleLocations = secondaryTraits.scaleLocations;
    }
    if (secondaryTraits.markTypes && secondaryTraits.markTypes.length > 0) {
      appendicesUpdate.markTypes = secondaryTraits.markTypes;
    }
    if (secondaryTraits.chestCore && secondaryTraits.chestCore !== 'COR00 Ninguno (Torso Orgánico Estándar)') {
      anatomyUpdate.chestCore = secondaryTraits.chestCore;
    }
    if (secondaryTraits.neckFeature && secondaryTraits.neckFeature !== 'NCK00 Ninguno (Cuello Estándar)') {
      anatomyUpdate.neckFeature = secondaryTraits.neckFeature;
    }
    if (secondaryTraits.lowerBodyStructure && secondaryTraits.lowerBodyStructure !== 'SIL01 Bípedo Humanoide Estándar (Piernas)') {
      anatomyUpdate.lowerBodyStructure = secondaryTraits.lowerBodyStructure;
      appendicesUpdate.lowerBodyStructure = secondaryTraits.lowerBodyStructure;
    }
    if (dominanceRatio === '25/75 Dominancia Secundaria') {
      if (secondaryTraits.height) anatomyUpdate.height = secondaryTraits.height;
      if (secondaryTraits.complexion) anatomyUpdate.complexion = secondaryTraits.complexion;
    }
  }

  // Hair Elemental
  if (options.inheritHairElemental) {
    if (secondaryTraits.hairElemental && secondaryTraits.hairElemental !== 'Cabello Orgánico Natural') {
      hairUpdate.hairElemental = secondaryTraits.hairElemental;
    }
    if (secondaryTraits.hairColor) hairUpdate.hairColor = secondaryTraits.hairColor;
  }

  return {
    anatomy: anatomyUpdate,
    facial: facialUpdate,
    hair: hairUpdate,
    appendices: appendicesUpdate
  };
};

export const RACE_GROUPS = [
  {
    id: 'group-1',
    title: 'GRUPO 1: HUMANODES SABIOS',
    description: 'Humanos, Elfos y Enanos con alta versatilidad y proporciones clásicas.',
    races: [
      { id: '1.1', name: 'Humanos (Homo sapiens)', description: 'Altura: 1.60–1.80 m (variable). Complexión: Estándar. Silueta versátil. Piel beige a negra. Ojos frontales con esclerótica blanca. Sin apéndices obligatorios. Máxima diversidad fenotípica.' },
      { id: '1.2', name: 'Elfos (Homo aelthar)', description: 'Altura: 1.70–1.90 m. Complexión: Delgado/Esbelto. Cuerpo estilizado y alargado. Orejas puntiagudas (10–15 cm). Ojos almendrados con pupila vertical. Piel pálida/dorada/verde clara con brillo perlado. Cabello largo y sedoso.' },
      { id: '1.3', name: 'Enanos (Homo dvergar)', description: 'Altura: 1.35–1.60 m. Complexión: Musculoso / Rellenito / Extra Grande. Cuerpo compacto y robusto. Huesos densos. Piel gruesa tipo cuero (gris acero, bronce, marrón). Rostro ancho, mandíbula cuadrada. Tatuajes tribales.' }
    ]
  },
  {
    id: 'group-2',
    title: 'GRUPO 2: HUMANODES BRUTOS',
    description: 'Seres de gran musculatura, presencia imponente y alta resistencia.',
    races: [
      { id: '2.1', name: 'Onis (Homo onis)', description: 'Altura: 1.80–2.40 m. Complexión: Atlético → Musculoso/Hiper-musculoso. Silueta imponente y estilizada. Cuernos cortos y curvados (obligatorios). Piel roja, índigo, verde oscuro o gris. Ojos rasgados (rojo/ámbar/dorado). Fuerza y regeneración elevadas.' },
      { id: '2.2', name: 'Orcos (Homo orcus)', description: 'Altura: 1.80–2.20 m. Complexión: Atlético a Hiper-musculoso / Rellenito. Cuerpo grande y densamente musculado. Piel verde (más clara en hembras). Colmillos inferiores visibles. Mandíbula cuadrada y prognatismo. Cicatrices rituales.' },
      { id: '2.3', name: 'Goblins (Homo goblinus)', description: 'Altura: 1.00–1.30 m. Complexión: Delgado / Esbelto / Petite. Piel rugosa (verde oscuro en XY, más claro en XX/XXY). Orejas grandes y puntiagudas. Nariz aguilada en machos XY, chata en hembras y macho XXY. Manos ágiles con dedos largos. Metabolismo acelerado.' },
      { id: '2.4', name: 'Trolls (Homo trollus)', description: 'Altura: 2.20–2.50 m. Complexión: Hiper-musculoso / Rellenito / Extra Grande. Cuerpo masivo (músculo + grasa). Piel gruesa similar a piedra. Verrugas naturales. Regeneración rápida y fuerza extrema.' }
    ]
  },
  {
    id: 'group-3',
    title: 'GRUPO 3: BESTFOLK’S PRIMITIVOS',
    description: 'Híbridos bestiales con rasgos dracónicos, acuáticos, aviares o felinos.',
    races: [
      { id: '3.1', name: 'Drakónidos de Linaje Puro', description: 'Altura: 1.80–2.15 m. Cuerpo robusto con escamas gruesas. Cola musculosa (1.2–1.5 m). Pupila vertical. Lengua bífida. Garras retráctiles. Crestas/astas óseas. Sin vello. Partenogénesis funcional en hembras.' },
      { id: '3.2', name: 'Sirenas / Tritones', description: 'Altura: 1.70–1.85 m. Piel lisa e hidrófila (azul/verde/plateado). Escamas en zonas específicas (espalda, cuello, hombros, antebrazos, piernas, muslos). Branquias ocultas en el cuello. Membranas interdigitales. Transformación a cola pisciforme en agua.' },
      { id: '3.3', name: 'Harpias', description: 'Altura: 1.50–1.69 m. Cuerpo ligero. Plumaje en hombros, brazos y piernas. Cabeza con plumas (sin cabello). Pico afilado. Ojos grandes con pupila vertical. Garras. Planeo y vuelos cortos.' },
      { id: '3.4', name: 'Lamias', description: 'Altura (torso): 1.70–1.90 m. Torso humanoide + cola serpentina (2.0–3.0 m). Escamas en espalda y extremidades. Pupila vertical. Lengua bífida. Veneno y percepción química.' },
      { id: '3.5', name: 'Centauros', description: 'Altura total: 3.15–3.30 m. Transición humano-equino en la cintura. Orejas equinas. Patas y cascos equinos. Pelaje y crin. Cola equina.' },
      { id: '3.6', name: 'Pantheris', description: 'Altura: 1.65–1.85 m. Cuerpo humanoide felino. Pelaje corto. Cabeza claramente felina. Orejas móviles. Garras retráctiles. Cola prensil (60–90 cm).' }
    ]
  },
  {
    id: 'group-4',
    title: 'GRUPO 4: BESTFOLK’S SAPIENS (KEMONOMIMIS)',
    description: 'Humanoides refinados con orejas y colas animales sin vello corporal excesivo.',
    races: [
      { id: '4.1', name: 'Kitsunes', description: 'Altura: 1.60–1.75 m. Cuerpo 100 % humanoide. Solo orejas de zorro + 1 a 9 colas esponjosas. Ojos dorados/ámbar con pupila vertical. Sin pelaje corporal ni hocico.' },
      { id: '4.2', name: 'Nekojin', description: 'Altura: 1.60–1.80 m. Cuerpo humanoide. Orejas felinas móviles + cola prensil. Pupilas verticales. Caninos pequeños visibles. Uñas retráctiles. Sin pelaje corporal.' },
      { id: '4.3', name: 'Inujin', description: 'Altura: 1.60–1.80 m. Cuerpo humanoide. Orejas caninas (caídas o semi-erectas) + cola canina. Nariz canina sutil. Caninos ligeramente desarrollados. Sin pelaje corporal.' },
      { id: '4.4', name: 'Bestfolk Bovinae', description: 'Altura: 1.70–2.10 m. Cuerpo humanoide robusto. Cuernos bovinos (obligatorios en machos no castrados). Orejas y cola bovinas. Dimorfismo extremo.' },
      { id: '4.5', name: 'Bestfolk Caprinae', description: 'Altura: 1.60–1.75 m. Cuerpo humanoide. Orejas largas puntiagudas caprinas. Cuernos retorcidos. Pupilas horizontales caprinas. Cola corta y tupida. Pelaje de lana suave alrededor del cuello.' },
      { id: '4.6', name: 'Drakónidos de Linaje Impuro', description: 'Altura: 1.75–2.00 m. Híbrido humano-dracónico. Escamas suaves localizadas. Cola (50–120 cm). Pupilas verticales. Alas semi-funcionales en algunos casos.' }
    ]
  },
  {
    id: 'group-5',
    title: 'GRUPO 5: CACODEMONIA (ENERGETICA-VITALIS)',
    description: 'Demonios, incubiformia, vampiros y carniceros del abismo.',
    races: [
      { id: '5.1', name: 'Demonios Nobles (Daemon nobilis)', description: 'Altura: Machos 2.00–2.20 m / Hembras 1.90–2.10 m. Dimorfismo extremo. Cuernos elegantes. Alas membranosas. Piel oscura con brillo metálico y vetas. Colmillos. Garras. Runas dérmicas.' },
      { id: '5.2', name: 'Incubiformia', description: '5.2.1 Incubus: Esbelto, Cuernos de fauno, escamas localizadas. 5.2.2 Succubus: Curvilínea, desarrollo mamario. 5.2.3 Incubus Sucuboforme: Silueta parcialmente feminizada, sello de servidumbre en el vientre.' },
      { id: '5.3', name: 'Vampiros Nosferatu (Vampirus nosferatu)', description: 'Altura: 1.65–1.90 m. Piel pálida marmórea con venas azules visibles. Colmillos retráctiles. Ojos rojo/dorado luminiscentes. Complexión esbelta.' },
      { id: '5.4', name: 'Carniceros de Abismo (Abyssal Butcherus)', description: 'Altura: 1.90–2.10 m. Musculatura densa. Escamas de armadura. Cuernos grandes retorcidos. Cola corta escamada. Ojos completamente rojos/negros con esclerótica negra. Dentición serrada.' }
    ]
  },
  {
    id: 'group-6',
    title: 'GRUPO 6: CELESTIALIS / ANGLOMORPHA',
    description: 'Demiurgos, ángeles y nefelins de origen celestial.',
    races: [
      { id: '6.1', name: 'Demiurgos (Demiurgus aeternus)', description: 'Altura: 1.90–2.30 m. Asexuales absolutos. Sin ojos, nariz, boca ni orejas. Superficie translúcida luminiscente. Órgano sensorial central y núcleo en el pecho.' },
      { id: '6.2', name: 'Ángeles (Angelus coelestis)', description: 'Altura: 1.80–2.00 m. Cuerpo esbelto y alargado. Piel blanca translúcida con bioluminiscencia. Alas nacidas de cicatrices en omóplatos (1 a 3 pares). Ojos dorados/plateados.' },
      { id: '6.3', name: 'Nefelins (Homo-Angelus nefilim)', description: 'Híbridos humano-celestiales. Alas (una sola ala única asimétrica o atrofiada a funcional). Piel pálida/luminiscente. Subtipos: XXY, Hermafrodita secuencial, Intermedio-dual (futanari).' }
    ]
  },
  {
    id: 'group-7',
    title: 'GRUPO 7: NYMPHIFORMIA (SYMBIOTICA)',
    description: 'Elementales, hadas y ninfas etéreas.',
    races: [
      { id: '7.1', name: 'Elementales (Elementalis quantica)', description: 'Subtipos: Tierra / Agua / Fuego / Aire. Matriz coloidal sin huesos ni órganos. Ojos, cabello de elementos (fuego, agua, aire, vegetación) y apéndices energéticos/elementales.' },
      { id: '7.2', name: 'Hadas (Micro-Nymphae quantica)', description: 'Altura: 10–25 cm. Exoesqueleto translúcido luminiscente. Alas membranosas de energía. Sin cabello orgánico / polvo de hadas.' },
      { id: '7.3', name: 'Ninfas (Nympha quantica)', description: 'Altura: 1.60–1.90 m. Cuerpo etéreo semitranslúcido. Cabello de filamentos energéticos. Machos con cuernos ramificados; hembras con alas translúcidas.' }
    ]
  },
  {
    id: 'group-8',
    title: 'GRUPO 8: NYMPHIFORMIA (SYNCYTIALIA)',
    description: 'Plasmoides fluidos y devoradores oníricos.',
    races: [
      { id: '8.1', name: 'Plasmoides (Plasmoidea Sapiens)', description: 'Formas adoptivas: Androide (1.80 m) / Ginoide (1.70 m). Matriz coloidal fluida. Núcleo en el pecho. Piel de slime o polimérica translúcida. Ojos de plasma luminoso.' },
      { id: '8.2', name: 'Devoradores Oníricos (Phobetor devorator)', description: 'Altura: 1.60–1.80 m. Matriz amorfa gelatinosa. Piel negra/morada con brillo fosforescente. Núcleo en el pecho. Ojos de plasma. Alta capacidad metamórfica.' }
    ]
  },
  {
    id: 'group-9',
    title: 'GRUPO 9: SINTÉTICOS Y MUTACIONALES',
    description: 'Androides, homúnculos, vampiros y zombis.',
    races: [
      { id: '9.1', name: 'Androides (Synthetica hominis)', description: 'Altura: 1.60–2.00 m. Chasis humanoide + epidermis sintética. Ojos con implantes ópticos. Placas de blindaje. Puertos de datos.' },
      { id: '9.2', name: 'Homúnculos (Homunculus artificialis)', description: 'Biomasa coloidal. Nodos visibles. Modelos: Básico (afeminado, translúcido), Avanzado (robusto, queratinizado), Experimental.' },
      { id: '9.3', name: 'Vampiros (condición mutacional)', description: 'Heredan la anatomía base. Piel pálida con venas azules. Colmillos retráctiles. Ojos rojo/dorado luminiscentes con esclerótica roja. Intolerancia a UV.' },
      { id: '9.4', name: 'Zombis (condición mutacional)', description: 'Cuerpo cadavérico y degradado. Piel grisácea/verdosa. Ojos vacíos e inexpresivos (esclerótica lechosa o turbia). Sin función sexual. Regeneración limitada.' }
    ]
  }
];

export const SEX_BASES = ['1 Hombre', '2 Mujer', '3 Andrógino', '4 Hombre (mujer trans-sexual)'];
export const AGES = ['1 Infancia (0-12 años)', '2 Adolescencia (13-17 años)', '3 Juventud (18-25 años)', '4 Adultez Joven (26-35 años)', '5 Adultez Media (36-50 años)', '6 Adultez Mayor (51-65 años)', '7 Ancianidad (66+ años)', '8 Desconocida / Inmortal'];

export const COMPLEXIONS = [
  '1 Escuálido / Muy Delgado', '2 Esbelto / Estandar', '3 Atlético / Fibroso', '4 Musculoso', '5 Voluminoso / Robusto', '6 Hipertrofiado / Musculatura Extrema', '7 Suave / Blando', '8 Relleno', '9 Gordo / Obeso / Extra Grande',
  '10 Complexión Bárbara / Musculatura Femenina Esculpida (Abdomen Hiper-Definido)',
  '11 Efebo Delicado / Andrógino Esbelto (Clavículas Marcadas)'
];

export const HEIGHTS = [
  'A Muy Pequeño (1.20 m – 1.40 m)', 'B Petite (1.40 m – 1.60 m)', 'C Normal / Estándar (1.60 m – 1.80 m)', 'D Alto (1.80 m – 2.00 m)', 'E Enorme (2.00 m – 2.20 m)', 'F Especial Racial'
];

export const BREAST_DEV = [
  'A Senos Planos / Pechos Incipientes / Copa AA',
  'B Senos Pequeños / Pechos Discretos / Copa A',
  'C Senos Medianos / Pechos Equilibrados / Copa B-C',
  'D Senos Prominentes / Pechos Voluminosos / Copa D',
  'E Senos Abundantes / Pechos Enormes / Copa DD-E',
  'F Senos Colosales / Pechos Hipertróficos / Copa F+'
];

export const WAISTS = ['1 Muy Estrecha', '2 Estrecha', '3 Media / Equilibrada', '4 Ancha', '5 Muy Ancha', '6 Definida / Angular', '7 Suave / Redondeada'];
export const GLUTES = ['1 Planos', '2 Pequeños', '3 Moderados', '4 Redondeados', '5 Voluminosos', '6 Altos / Firmes', '7 Suaves / Blandos', '8 Muy Voluminosos'];
export const THIGHS = ['1 Muy Delgados', '2 Delgados', '3 Medios / Equilibrados', '4 Gruesos', '5 Musculosos', '6 Voluminosos / Suaves', '7 Muy Voluminosos', '8 Alargados / Estilizados'];


export const SKIN_COLORS = [
  'Pálida', 'Clara', 'Bronceada', 'Morena clara', 'Morena oscura', 'Negra', 'Gris', 'Pálida ceniza', 'Roja', 'Azul', 'Verde', 'Morada', 'Dorada', 'Blanca', 'Negra carbón'
];

// Facials
export const HEAD_SHAPES = ['Ovalada', 'Redonda', 'Alargada', 'Cuadrada', 'Rectangular', 'Triangular', 'Triángulo Invertido', 'Diamante', 'Corazón'];
export const HEAD_WIDTHS = ['Muy Estrecha', 'Estrecha', 'Media / Equilibrada', 'Ancha', 'Muy Ancha'];
export const BONE_STRUCTURES = ['Ligera / Grácil', 'Media / Normal', 'Pesada / Robusta'];

export const EYE_COLORS = [
  'Marrón', 'Avellana', 'Ámbar', 'Verde esmeralda', 'Verde oliva', 'Azul claro', 'Azul profundo', 'Gris', 'Violeta', 'Rojo carmesí', 'Rosa', 'Dorado', 'Negro', 'Blanco', 'Heterocromía',
  'Púrpura Amatista Luminoso', 'Azul Cian Hielo / Glacial Brillante', 'Azul Celeste Cristalino / Aguamarina'
];

export interface ColorSwatchOption {
  id: string;
  name: string;
  hex: string;
}

export const BASIC_COLOR_SWATCHES: ColorSwatchOption[] = [
  { id: 'negro', name: 'Negro', hex: '#111317' },
  { id: 'blanco', name: 'Blanco', hex: '#FFFFFF' },
  { id: 'platino', name: 'Plata / Platino', hex: '#E2E8F0' },
  { id: 'azul_profundo', name: 'Azul marino', hex: '#1E3A8A' },
  { id: 'azul_cielo', name: 'Azul cielo', hex: '#3B82F6' },
  { id: 'cian_hielo', name: 'Cian', hex: '#06B6D4' },
  { id: 'rojo_rubi', name: 'Rojo carmesí', hex: '#DC2626' },
  { id: 'rojo_fuego', name: 'Rojo', hex: '#EF4444' },
  { id: 'dorado', name: 'Dorado', hex: '#F59E0B' },
  { id: 'amarillo', name: 'Amarillo', hex: '#FBBF24' },
  { id: 'verde_esmeralda', name: 'Verde esmeralda', hex: '#059669' },
  { id: 'verde_menta', name: 'Verde menta', hex: '#10B981' },
  { id: 'purpura', name: 'Púrpura', hex: '#7C3AED' },
  { id: 'violeta', name: 'Violeta', hex: '#8B5CF6' },
  { id: 'rosa_fucsia', name: 'Fucsia', hex: '#EC4899' },
  { id: 'rosa_pastel', name: 'Rosa pastel', hex: '#F472B6' },
  { id: 'castano_oscuro', name: 'Castaño oscuro', hex: '#451A03' },
  { id: 'castano_claro', name: 'Castaño claro', hex: '#92400E' },
  { id: 'rubio_dorado', name: 'Rubio dorado', hex: '#FDE047' },
  { id: 'gris_humo', name: 'Gris', hex: '#64748B' }
];

export const EYE_COLOR_MODES = [
  { id: 'single', name: 'Color Sólido (Monocromático)', category: 'sólido', desc: 'Ambos ojos del mismo color uniforme' },
  { id: 'heterochromia_full', name: 'Heterocromía Completa (Izq / Der)', category: 'heterocromía', desc: 'Ojo izquierdo de un color y ojo derecho de otro' },
  { id: 'gradient_vertical', name: 'Degradado / Mezcla de Iris (Vertical)', category: 'mezcla', desc: 'Transición fluida de dos tonos en el iris (ej. Azul arriba a Blanco abajo)' },
  { id: 'gradient_radial', name: 'Mezcla Radial (Centro a Borde)', category: 'mezcla', desc: 'Núcleo interior de un color fundiéndose hacia el borde exterior' },
  { id: 'heterochromia_central', name: 'Heterocromía Central (Raíz de Iris / Anillo)', category: 'raíz', desc: 'Anillo iris principal con corona/halo contrastante en la pupila (raíz del iris)' },
  { id: 'heterochromia_sectoral', name: 'Heterocromía Sectorial (Sector/Mancha)', category: 'heterocromía', desc: 'Iris base con un cuarto o sector de otro color exótico' }
];

export const EYE_COLOR_PRESETS = [
  {
    name: '🌌 Degradado Azul a Blanco Celestial',
    mode: 'gradient_vertical',
    distribution: 'mezcla',
    c1: 'Azul Zafiro / Noche',
    c2: 'Blanco',
    hex1: '#1E3A8A',
    hex2: '#FFFFFF',
    desc: 'Degradado vertical de iris de azul profundo a blanco resplandeciente'
  },
  {
    name: '🌓 Heterocromía Sol y Luna (Dorado & Azul)',
    mode: 'heterochromia_full',
    distribution: 'heterocromía',
    c1: 'Dorado Solar / Ámbar',
    c2: 'Azul Zafiro / Noche',
    hex1: '#F59E0B',
    hex2: '#1E3A8A',
    desc: 'Ojo izquierdo dorado solar brillante y ojo derecho azul profundo zafiro'
  },
  {
    name: '🔮 Degradado Violeta Cósmico a Rosa Pastel',
    mode: 'gradient_vertical',
    distribution: 'mezcla',
    c1: 'Púrpura / Amatista',
    c2: 'Rosa Pastel / Sakura',
    hex1: '#7C3AED',
    hex2: '#F472B6',
    desc: 'Degradado suave de amatista a rosa pastel con destellos cósmicos'
  },
  {
    name: '🔥 Heterocromía Rubí Carmesí y Violeta',
    mode: 'heterochromia_full',
    distribution: 'heterocromía',
    c1: 'Rojo Rubí / Carmesí',
    c2: 'Púrpura / Amatista',
    hex1: '#DC2626',
    hex2: '#7C3AED',
    desc: 'Ojo izquierdo rojo carmesí predador y ojo derecho púrpura místico'
  },
  {
    name: '🌿 Heterocromía Esmeralda y Miel Ámbar',
    mode: 'heterochromia_full',
    distribution: 'heterocromía',
    c1: 'Verde Esmeralda',
    c2: 'Dorado Solar / Ámbar',
    hex1: '#059669',
    hex2: '#F59E0B',
    desc: 'Ojo izquierdo verde esmeralda y ojo derecho miel dorado'
  },
  {
    name: '❄️ Degradado Cian Hielo a Blanco Puro',
    mode: 'gradient_vertical',
    distribution: 'mezcla',
    c1: 'Cian Hielo / Eléctrico',
    c2: 'Blanco',
    hex1: '#06B6D4',
    hex2: '#FFFFFF',
    desc: 'Degradado cristalino de cian eléctrico a blanco luminiscente'
  },
  {
    name: '👁️ Anillo Central Zafiro con Halo Dorado (Raíz Pupilar)',
    mode: 'heterochromia_central',
    distribution: 'raíz',
    c1: 'Azul Zafiro / Noche',
    c2: 'Dorado Solar / Ámbar',
    hex1: '#1E3A8A',
    hex2: '#F59E0B',
    desc: 'Heterocromía central: anillo exterior azul zafiro con corona interior dorada'
  },
  {
    name: '🩸 Esclerótica Oscura con Iris Rojo Rubí',
    mode: 'single',
    distribution: 'sólido',
    c1: 'Rojo Rubí / Carmesí',
    c2: 'Negro Azabache / Ébano',
    hex1: '#DC2626',
    hex2: '#111317',
    desc: 'Esclerótica oscura abisal con iris rojo carmesí brillante'
  }
];

export const HAIR_COLOR_MODES = [
  { id: 'single', name: 'Color Sólido (Monocromático)', category: 'sólido', desc: 'Cabello completo de un solo tono parejo' },
  { id: 'dip_dye', name: 'Puntas Teñidas (Dip-Dye en Puntas)', category: 'punta', desc: 'Color base principal con puntas teñidas en contraste vibrante' },
  { id: 'ombre_tips', name: 'Degradado Ombré (Mezcla Raíz a Puntas)', category: 'mezcla', desc: 'Transición continua y suave de un tono en la raíz hasta las puntas' },
  { id: 'shadow_roots', name: 'Raíz Contrastada (Shadow Root)', category: 'raíz', desc: 'Raíces oscuras o de color con el resto del cuerpo capilar en otro tono' },
  { id: 'split', name: 'Bicolor Split (Mezcla Mitad y Mitad)', category: 'mezcla', desc: 'División lateral vertical: mitad izquierda de un color y mitad derecha de otro' },
  { id: 'underdye', name: 'Capa Interior Oculta (Under-dye / Capas)', category: 'mezcla', desc: 'Capa superior de un tono con capa inferior interna revelable de otro color' },
  { id: 'highlights', name: 'Mechas & Mechones Frontales (Money Piece)', category: 'mezcla', desc: 'Color base con mechas gruesas frontales o reflejos contrastantes' }
];

export const HAIR_COLOR_PRESETS = [
  {
    name: '🖤⚡ Negro con puntas Azul Cian Eléctrico',
    mode: 'dip_dye',
    distribution: 'punta',
    c1: 'Negro Azabache / Ébano',
    c2: 'Cian Hielo / Eléctrico',
    hex1: '#111317',
    hex2: '#06B6D4',
    desc: 'Cabello negro azabache con puntas teñidas en degradado azul cian eléctrico'
  },
  {
    name: '🖤🔥 Negro con puntas Rojo Carmesí / Fuego',
    mode: 'dip_dye',
    distribution: 'punta',
    c1: 'Negro Azabache / Ébano',
    c2: 'Rojo Fuego / Escarlata',
    hex1: '#111317',
    hex2: '#EF4444',
    desc: 'Cabello negro azabache con puntas teñidas en degradado rojo fuego escarlata'
  },
  {
    name: '🖤❄️ Negro con puntas Blanco Platino',
    mode: 'dip_dye',
    distribution: 'punta',
    c1: 'Negro Azabache / Ébano',
    c2: 'Blanco Platino / Plata',
    hex1: '#111317',
    hex2: '#E2E8F0',
    desc: 'Cabello negro azabache con puntas en degradado blanco platino'
  },
  {
    name: '🖤💜 Negro con capa interior Púrpura Neón (Under-dye)',
    mode: 'underdye',
    distribution: 'mezcla',
    c1: 'Negro Azabache / Ébano',
    c2: 'Violeta Neón / Índigo',
    hex1: '#111317',
    hex2: '#8B5CF6',
    desc: 'Capa exterior negra azabache con capa inferior oculta teñida en púrpura neón vibrante'
  },
  {
    name: '🤍💙 Blanco Platino a puntas Azul Océano (Ombré)',
    mode: 'ombre_tips',
    distribution: 'mezcla',
    c1: 'Blanco Platino / Plata',
    c2: 'Azul Zafiro / Noche',
    hex1: '#E2E8F0',
    hex2: '#1E3A8A',
    desc: 'Degradado ombré suave desde raíz blanco platino hasta puntas azul zafiro profundo'
  },
  {
    name: '☯️ Split Bicolor: Mitad Blanco / Mitad Negro',
    mode: 'split',
    distribution: 'mezcla',
    c1: 'Blanco',
    c2: 'Negro Azabache / Ébano',
    hex1: '#FFFFFF',
    hex2: '#111317',
    desc: 'Estilo split bicolor dividido al centro: mitad izquierda blanco platino y mitad derecha negro azabache'
  },
  {
    name: '🖤💖 Split Bicolor: Mitad Rosa Fucsia / Mitad Negro',
    mode: 'split',
    distribution: 'mezcla',
    c1: 'Rosa Fucsia / Neón',
    c2: 'Negro Azabache / Ébano',
    hex1: '#EC4899',
    hex2: '#111317',
    desc: 'Estilo split bicolor: mitad izquierda rosa fucsia neón y mitad derecha negro ébano'
  },
  {
    name: '🤎✨ Castaño Oscuro con mechas Doradas',
    mode: 'highlights',
    distribution: 'mezcla',
    c1: 'Castaño Chocolate Oscuro',
    c2: 'Dorado Solar / Ámbar',
    hex1: '#451A03',
    hex2: '#F59E0B',
    desc: 'Cabello castaño chocolate profundo con mechas frontales y reflejos dorados cálidos'
  },
  {
    name: '🖤🤍 Rubio Platino con Raíz Sombreada Negra (Shadow Root)',
    mode: 'shadow_roots',
    distribution: 'raíz',
    c1: 'Negro Azabache / Ébano',
    c2: 'Blanco Platino / Plata',
    hex1: '#111317',
    hex2: '#E2E8F0',
    desc: 'Raíces oscuras sombreadas en negro ébano difuminadas en cabello rubio platino'
  },
  {
    name: '🌸🤍 Rosa Pastel a Blanco (Degradado)',
    mode: 'ombre_tips',
    distribution: 'mezcla',
    c1: 'Rosa Pastel / Sakura',
    c2: 'Blanco',
    hex1: '#F472B6',
    hex2: '#FFFFFF',
    desc: 'Degradado de ensueño desde raíz rosa sakura pastel hasta puntas blanco'
  },
  {
    name: 'STREAK-BLACK: 💛🖤 Rubio Salvaje con Mechón Frontal Negro Azabache',
    mode: 'highlights',
    distribution: 'frontal',
    c1: 'Rubio Dorado / Miel',
    c2: 'Negro Azabache / Ébano',
    hex1: '#FBBF24',
    hex2: '#111317',
    desc: 'Cabello rubio dorado salvaje con mechón frontal negro azabache (STREAK-BLACK) en marcado contraste visual'
  }
];

export const FABRIC_COLOR_MODES = [
  { id: 'single', name: 'Color Sólido Uniforme', category: 'sólido', desc: 'Prenda teñida completamente de un solo color monocromático' },
  { id: 'mezcla_degradado', name: 'Degradado Ombré de Tela (Mezcla)', category: 'mezcla', desc: 'Transición fluida y continua entre dos colores a lo largo de la tela' },
  { id: 'punta_dobladillo', name: 'Dobladillos & Remates (Puntas)', category: 'punta', desc: 'Color base con bordes, remates, dobladillos y puntas en color secundario' },
  { id: 'raiz_cuello', name: 'Cuello & Canesú Superior (Raíz)', category: 'raíz', desc: 'Parte superior/cuello de un color contrastante y el resto de la prenda en otro' },
  { id: 'forro_interior', name: 'Forro Interior Contrastante', category: 'mezcla', desc: 'Exterior en color principal con forro interior sedoso en color secundario' },
  { id: 'patron_bitono', name: 'Brocado / Patrón Bitono', category: 'mezcla', desc: 'Tela base de un color con filigranas, bordados o estampados en el segundo color' },
  { id: 'split_vertical', name: 'Bicolor Dividido (Split)', category: 'mezcla', desc: 'Corte asimétrico o simétrico dividiendo la prenda en dos bloques de color' }
];

export const FABRIC_COLOR_PRESETS = [
  {
    name: '🖤✨ Negro Ébano con Remates y Puntas en Oro Solar',
    mode: 'punta_dobladillo',
    distribution: 'punta',
    c1: 'Negro Azabache / Ébano',
    c2: 'Dorado Solar / Ámbar',
    hex1: '#111317',
    hex2: '#F59E0B',
    desc: 'Tela negra azabache con bordes, ribetes y dobladillos en bordado dorado solar'
  },
  {
    name: '🤍🌊 Blanco con Degradado a Azul Zafiro (Ombré)',
    mode: 'mezcla_degradado',
    distribution: 'mezcla',
    c1: 'Blanco',
    c2: 'Azul Zafiro / Noche',
    hex1: '#FFFFFF',
    hex2: '#1E3A8A',
    desc: 'Degradado ombré etéreo desde blanco en la parte superior hasta azul zafiro en la falda/mangas'
  },
  {
    name: '🖤🩸 Negro Ébano con Forro Interior Rojo Carmesí',
    mode: 'forro_interior',
    distribution: 'mezcla',
    c1: 'Negro Azabache / Ébano',
    c2: 'Rojo Rubí / Carmesí',
    hex1: '#111317',
    hex2: '#DC2626',
    desc: 'Capa exterior negra ébano mate con forro interior de satén rojo carmesí vampírico'
  },
  {
    name: '💜✨ Púrpura Imperial con Brocados en Oro',
    mode: 'patron_bitono',
    distribution: 'mezcla',
    c1: 'Púrpura / Amatista',
    c2: 'Dorado Solar / Ámbar',
    hex1: '#7C3AED',
    hex2: '#F59E0B',
    desc: 'Tela de terciopelo púrpura imperial con bordados y filigranas en hilo de oro fino'
  },
  {
    name: '🖤❄️ Negro con Degradado en Puntas a Cian Hielo',
    mode: 'punta_dobladillo',
    distribution: 'punta',
    c1: 'Negro Azabache / Ébano',
    c2: 'Cian Hielo / Eléctrico',
    hex1: '#111317',
    hex2: '#06B6D4',
    desc: 'Tejido técnico negro con degradado cian luminiscente en puntas y dobladillos'
  },
  {
    name: '🤍🖤 Blanco Platino con Cuello & Raíz Negra (Raíz)',
    mode: 'raiz_cuello',
    distribution: 'raíz',
    c1: 'Blanco Platino / Plata',
    c2: 'Negro Azabache / Ébano',
    hex1: '#E2E8F0',
    hex2: '#111317',
    desc: 'Prenda blanco platino con cuello alto, hombreras y canesú superior en cuero negro azabache'
  },
  {
    name: '🔥🖤 Degradado Fuego Carmesí a Negro Ceniza',
    mode: 'mezcla_degradado',
    distribution: 'mezcla',
    c1: 'Rojo Fuego / Escarlata',
    c2: 'Negro Azabache / Ébano',
    hex1: '#EF4444',
    hex2: '#111317',
    desc: 'Degradado ombré continuo de rojo fuego ardiente fundiéndose hacia negro ceniza'
  },
  {
    name: '🌸🤍 Rosa Pastel con Remates en Encaje Blanco',
    mode: 'punta_dobladillo',
    distribution: 'punta',
    c1: 'Rosa Pastel / Sakura',
    c2: 'Blanco',
    hex1: '#F472B6',
    hex2: '#FFFFFF',
    desc: 'Tela rosa sakura con dobladillos festoneados y puntas de encaje blanco'
  }
];

export const EYES_CATEGORIES = [
  'A Filosos / Afilados', 'B Caídos / Melancólicos', 'C Redondos / Expresivos', 'D Rasgados / Felinos', 'E Inexpresivos / Semi-cerrados', 'F Grandes / Ídolo', 'G Exóticos / Únicos'
];

export const EYES_SUBTYPES = [
  'A1 Almendrado Clásico', 'A2 Almendrado Estrecho', 'A3 Almendrado Alargado', 'A4 Almendrado Ascendente', 'A5 Almendrado Descendente', 'A6 Párpado Doble Filoso', 'A7 Filoso Suave', 'A8 Filoso Predador', 'A9 Filoso Fino', 'A10 Filoso Angular',
  'B1 Caído Suave', 'B2 Caído Marcado', 'B3 Caído Extremo', 'B4 Caído Párpado Pesado', 'B5 Caído Triste', 'B6 Caído Melancólico', 'B7 Caído Relajado', 'B8 Caído Cansado', 'B9 Caído Dormido', 'B10 Caído Lagrimal Bajo',
  'C1 Redondo Clásico', 'C2 Redondo Grande', 'C3 Redondo Muy Grande', 'C4 Redondo Infantil', 'C5 Redondo Suave', 'C6 Redondo Brillante', 'C7 Redondo Curioso', 'C8 Redondo Asombrado', 'C9 Redondo Inocente', 'C10 Redondo Alegre',
  'D1 Rasgado Clásico', 'D2 Rasgado Felino', 'D3 Rasgado Ascendente', 'D4 Rasgado Descendente', 'D5 Rasgado Extremo', 'D6 Rasgado Agresivo', 'D7 Rasgado Elegante', 'D8 Rasgado Suave', 'D9 Rasgado Fino', 'D10 Rasgado Con Pliegue',
  'E1 Semi-cerrado Clásico', 'E2 Semi-cerrado Relajado', 'E3 Semi-cerrado Indiferente', 'E4 Semi-cerrado Frío', 'E5 Semi-cerrado Cansado', 'E6 Semi-cerrado Desanimado', 'E7 Semi-cerrado Dormido', 'E8 Semi-cerrado Con Pliegue', 'E9 Semi-cerrado Estrecho', 'E10 Semi-cerrado Hostil',
  'F1 Grande Brillante', 'F2 Grande Espectacular', 'F3 Grande Encantador', 'F4 Grande Pestañas Largas', 'F5 Grande Múltiples Reflejos', 'F6 Grande Dulce', 'F7 Grande Ídolo Clásico', 'F8 Grande Emocionado', 'F9 Grande Soñador', 'F10 Grande Mágico',
  'G1 Pupila Vertical Reptil', 'G2 Pupila Ranurada Horizontal', 'G3 Pupila Estrella', 'G4 Pupila Cruzada', 'G5 Pupila Espiral', 'G6 Pupila Diamante', 'G7 Esclerótica Oscura/Negra', 'G8 Esclerótica Parcial Emisiva', 'G9 Con Marcas Mágicas', 'G10 Asimétrico Único/Heterocromía'
];

export const EYELINERS = ['DEL1 Delgado', 'DEL2 Medio', 'DEL3 Grueso', 'DEL4 Con Pestañas Marcadas', 'DEL5 Estilo Pictórico/Difuminado'];
export const SHADOWS = ['SOM1 Sombra Suave', 'SOM2 Sombra Media', 'SOM3 Sombra Profunda', 'SOM4 Contraste Alto', 'SOM5 Contraste Extremo', 'SOM6 Ojeras / Ojeras Profundas de Fatiga'];
export const EXPRESSIONS = [
  'EXP1 Neutral', 'EXP2 Feliz / Sonriente', 'EXP3 Triste / Afligido', 'EXP4 Enojado / Hostil', 'EXP5 Sorprendido / Impactado',
  'EXP6 Mirada Intensa y Desafiante (Predador en Combate)'
];

export const IRIS_TYPES = [
  '1 Humano', '2 Felino', '3 Cabra', '4 Anillado', '5 Radiado', '6 Cristalino', '7 Fantástico', '8 Artificial', '9 Vacío'
];

export const PUPIL_SHAPES = [
  'Redonda humana estándar',
  'Hendidura vertical felina / reptiliana',
  'Hendidura horizontal caprina / fauno',
  'Estrella mística de cuatro puntas',
  'Pupila Estrella-Flor Animé (Flower / Blossom Sparkle)',
  'Anillos concéntricos concéntricos / hipnóticos',
  'Cruciforme / Cruz sagrada',
  'Sin pupila / Vacía luminosa (ciega mística)',
  'Polioria (pupilas dobles arcanas)'
];

export const NOSES = [
  '1 Recta / Clásica', '2 Recta Estrecha', '3 Recta Ancha', '4 Respingada', '5 Chata / Baja', '6 Aguileña', '7 Acúlea', '8 Romana', '9 Griega', '10 Botón', '11 Elfa / Puntiaguda', '12 Angular', '13 Achatada', '14 Rota / Con Cicatriz', '15 No Humana / Hendiduras'
];

export const LIPS = ['A1 Básico', 'A2 Delgados', 'A3 Medios', 'A4 Gruesos / Carnosos'];
export const MOUTH_EXPS = [
  'E1 Sonriente', 'E2 Sonrisa Amplia', 'E3 Seria / Recta', 'E4 Sensual / Burlona', 'E5 Entreabierta', 'E6 Hablando', 'E7 Gritando',
  'EXP-FANGS-GRIN Sonrisa Feroz de Combate (Feral Battle Grin con Colmillos)',
  'E8 Sonrisa Feroz de Combate con Colmillos Afilados (Battle Feral Grin)',
  'E9 Sonrisa Tímida Suave con Mirada Baja'
];
export const MOUTH_SPECIALS = ['Ninguna', 'AB1 Con Cicatriz', 'AB2 Piercings', 'AB3 Labio Partidario', 'AB4 Boca Neko', 'AB5 Sin Labios Definidos'];

export const TONGUE_TYPES = [
  'Humana estándar rosada',
  'Bífida de serpiente / reptiliana',
  'Bifurcada demoníaca puntiaguda',
  'Tatuada con sigilo arcano',
  'Oscura azabache / abisal con tinte azul',
  'Bioluminiscente con destellos de maná',
  'Piercing con barra de plata / orbe'
];
export const TEETHS = ['B1 Normales', 'B2 Afilados / Colmillos Múltiples', 'B3 Colmillos Prominentes', 'B4 Irregulares', 'B5 Pequeños', 'B6 Grandes', 'B7 Separados', 'B8 Serrados', 'B9 Filas Múltiples', 'B10 No Visibles'];
export const MOUTH_CORNERS = ['COM1 Elevadas (Alegre)', 'COM2 Neutras', 'COM3 Caídas (Serio/Severo)'];
export const MOUTH_TEXTURES = ['TEX1 Mate', 'TEX2 Hidratado / Brillo Suave', 'TEX3 Glossy / Muy Brillante', 'TEX4 Agrietado / Seco', 'TEX5 Cicatrizado'];

export const EARS_BASES = [
  'E01 Normales', 'E02 Puntiagudas suaves', 'E03 Puntiagudas marcadas', 'E04 Altas', 'E05 Bajas', 'E06 Grandes', 'E07 Pequeñas', 'E08 Anchas', 'E09 Estrechas', 'E10 Con pliegues', 'E11 Puntas curvas', 'E12 Puntas curvas hacia abajo', 'E13 Con muescas', 'E14 Lóbulo alargado',
  'E15 Orejas Élficas con Rubor Rosáceo en Puntas'
];
export const EARS_LENGTHS = ['EL1 0–5 cm', 'EL2 5–10 cm', 'EL3 10–15 cm', 'EL4 15–20 cm', 'EL5 >20 cm'];
export const KEMONO_EARS = [
  'Ninguno',
  'KEMO-A1 Gato/Felino', 'KEMO-A2 Lobo', 'KEMO-A3 Zorro / Fénec (Orejas Grandes y Amplias con Mechones/Penachos Internos)', 'KEMO-A3.1 Zorro Fénec (Orejas Gigantes del Desierto con Penachos Internos)', 'KEMO-A4 León', 'KEMO-A5 Tigre', 'KEMO-A6 Leopardo', 'KEMO-A7 Oso', 'KEMO-A8 Pantera',
  'KEMO-B1 Conejo', 'KEMO-B2 Venado/Ciervo', 'KEMO-B3 Cabra', 'KEMO-B4 Oveja', 'KEMO-B5 Vaca/Toro', 'KEMO-B6 Caballo', 'KEMO-B7 Burro', 'KEMO-B8 Alce',
  'KEMO-C1 Zorro Ártico', 'KEMO-C2 Halcón/Águila', 'KEMO-C3 Búho', 'KEMO-C4 Dragón/Reptil', 'KEMO-C5 Murciélago', 'KEMO-C6 Lynx', 'KEMO-C7 Serpiente/Aletas', 'KEMO-C8 Fantástico/Plumas'
];

export const HAIR_TEXTURES = ['1 Liso / Lacio', '2 Ondulado', '3 Rizado / Bucles', '4 Crespo / Afro', '5 Rastrudo / Dreads', '6 Áspero / Grueso', '7 Fino / Sedoso', '8 Etéreo / Mágico / Emisivo'];
export const HAIR_LENGTHS = ['1 Rapado / Muy Corto', '2 Corto (Nuca)', '3 Medio (Hombros)', '4 Largo (Espalda)', '5 Muy Largo (Cintura)', '6 Extra Largo (Piso)', '7 Asimétrico / Variable'];
export const HAIR_CUTS = ['1 Bob', '2 Pixie', '3 Capas', '4 Recto', '5 Desfilado', '6 Hime Cut', '7 Mullet', '8 Undercut', '9 Mohicano', '10 Shag', '11 Bowl / Tazón', '12 Lob', '13 Asimétrico', '14 Desmechado', '15 Afro', '16 Trenzado Completo', '17 Salvaje / Despeinado', '18 Militar / Flattop', '19 Coleta Integrada', '20 Fantasía Geométrico'];
export const HAIR_PARTS = ['1 Al Centro', '2 Lateral Izquierdo', '3 Lateral Derecho', '4 En Zig-Zag', '5 Sin Partido / Peinado Atrás', '6 Desordenado / Natural'];
export const HAIR_BANGS = [
  '1 Sin Flequillo', '2 Flequillo Recto', '3 Flequillo de Lado / Asimétrico', '4 Flequillo Cortina (Curtain)', '5 Flequillo Desfilado / Transparente', '6 Flequillo Rebelde', '7 Micro Flequillo',
  '8 Flequillo Asimétrico Ocular con Mechón Teñido en Contraste',
  '9 Mechón Curvado Flotante en Coronilla (Ahoge Clásico)',
  'STREAK-BLACK: Mechón Negro Azabache Frontal en Mechones Rubios Salvajes'
];
export const HAIR_STYLES = ['HST00 Sin peinado / suelto', '1 Suelto', '2 Coleta Alta', '3 Coleta Baja', '4 Dos Coletas (Twin Tails)', '5 Moño / Chongo', '6 Dos Moños', '7 Trenza Única', '8 Dos Trenzas', '9 Semirrecogido', '10 Recogido Elegante'];

export const HAIR_COLORS = [
  'Negro', 'Castaño oscuro', 'Castaño claro', 'Rubio ceniza', 'Rubio dorado', 'Platino', 'Gris', 'Pelirrojo', 'Rojo', 'Azul oscuro', 'Azul cielo', 'Verde bosque', 'Verde menta', 'Rosa pastel', 'Púrpura', 'Dorado', 'Bicolor'
];

export const HORNS_FORMS = ['Ninguno', 'H1 Rectos', 'H2 Curvos', 'H3 Retorcidos / Espiral', 'H4 Ramificados', 'H5 Espinados', 'H6 Anillados', 'H7 Planos', 'H8 Especiales'];
export const HORNS_LENGTHS = ['HL1 0-10 cm', 'HL2 10-30 cm', 'HL3 30-60 cm', 'HL4 60-120 cm', 'HL5 >120 cm'];
export const HORNS_THICKNESSES = ['G1 Muy Delgado', 'G2 Delgado', 'G3 Medio', 'G4 Grueso', 'G5 Muy Grueso'];
export const HORNS_POSITIONS = ['P1 Frontales', 'P2 Laterales / Sienes', 'P3 Parietales', 'P4 Occipitales', 'P5 Múltiples niveles'];

export const WINGS_SIZES = ['S1 Pequeño', 'S2 Medio', 'S3 Grande', 'S4 Masivo', 'S5 Colosal'];
export const WINGS_POSITIONS = ['P1 Espalda Alta', 'P2 Espalda Baja', 'P3 Cabeza / Sienes'];
export const WINGS_TYPES = [
  'Ninguno',
  'A1 Aviares',
  'A2 Angélicas Celestiales (1 Par)',
  'A2-Serafin Angélicas Celestiales (3 Pares de Alas)',
  'A2-Nefelim Una Sola Ala Asimétrica Única (Nefelim)',
  'A2-Atrofiada 1 Par Asimétrico / Atrofiado (Nefelim)',
  'A3 Dracónicas Membrana',
  'A4 Dracónicas Plumadas',
  'A5 Demoníacas Óseas',
  'A6 Murciélago Membranosas (Demonio Noble)',
  'A7 Insectoide',
  'A8 Hada / Fae Membranosas de Energía',
  'A9 Mariposa',
  'A10 Polilla',
  'A11 Acuáticas Alas de Manta',
  'A12 Pterosauria',
  'A13 Mecánicas / Artificiales',
  'A14 Energéticas / Etéreas',
  'A15 Cristalinas',
  'A16 Brazos-Alas con Plumaje de Arpía'
];

export const TAILS_TYPES = [
  'Ninguno',
  'C1 Demoníaca con Punta de Corazón (Incubus/Succubus)',
  'C1-Noble Demoníaca Clásica con Púas',
  'C2 Felina',
  'C2-Pantheris Cola Prensil Felina 60-90cm (Pantheris)',
  'C3 Canina',
  'C4 Equídea de Crin Larga (Centauro)',
  'C7 Bovina con Mechón',
  'C8 Caprina Corta y Tupida',
  'C9 Ovina Suave',
  'C10 Zorrina / Fénec Esponjosa (Gran Volumen y Puntas Suaves)',
  'C10-Kitsune Zorrina Kitsune Múltiple (1 a 9 Colas con Degradados Místicos y Cascabeles)',
  'C11 Lupina Lobo',
  'C12 Osina',
  'C13 Reptiliana',
  'C14 Dracónida Musculosa 1.2–1.5m con Crestas',
  'C15 Espinosa',
  'C16 Escorpiónida',
  'C17 Cefalópoda / Tentáculos',
  'C18 Cola Serpentina 2.0–3.0m (Lamia)',
  'C19 Cola Pisciforme / Aleta Caudal (Sirena/Tritón)',
  'C20 Mecánica / Cibernética Biónica con Cable Segmentado',
  'C21 Matriz de Slime / Tentáculo Gelatinoso Translúcido',
  'C22 Vegetal de Lianas y Espinas Florales Vivas'
];
export const TAILS_LENGTHS = ['L1 Muy Corta (0-10 cm)', 'L2 Corta (10-30 cm)', 'L3 Media (30-60 cm)', 'L4 Larga (60-120 cm)', 'L5 Muy Larga (120-200 cm)', 'L6 Extra Larga (>200 cm)'];

export const TAILS_FINISHES = [
  'Color Sólido Natural',
  'Puntas Teñidas en Contraste',
  'Degradado Bicolor Suave',
  'Degradado Pastel Multicolor con Escarcha / Polvo Estelar',
  'Bioluminiscente en las Puntas',
  'Patrón Rayado / Atigrado',
  'Pelaje de Seda Mate'
];

export const TAILS_COLORS = [
  'Color del Cabello (A juego)',
  'Crema / Vainilla',
  'Rubio Platino',
  'Naranja Zorro Cálido',
  'Lila Pastel',
  'Celeste Cielo',
  'Rosa Pastel',
  'Dorado Ocre',
  'Blanco Nieve',
  'Negro Ceniza',
  'Castaño Cálido',
  'Degradado Pastel Cósmico (Crema / Lila / Celeste)'
];

export const SKIN_AND_MARKS = [
  'T1 Piel Lisa',
  'T2 Piel Escamosa Dracónica Pura',
  'T2-Impuro Escamas Suaves Localizadas (Hombros, Espalda, Extremidades)',
  'T3 Pelo Corto',
  'T4 Pelo Largo',
  'T5 Plumaje Natural en Extremidades y Hombros',
  'T6 Queratina Cuernos/Placas',
  'T7 Cartílago Óseo',
  'T8 Membrana',
  'T9 Cristalina',
  'T10 Metálica',
  'T11 Piel de Slime / Matriz Gelatinosa Translúcida (Plasmoide)',
  'T12 Piel Marmórea Pálida con Venas Azules Visibles (Vampiro)',
  'T13 Piel Gruesa Similar a Piedra con Verrugas Naturales (Troll)',
  'T14 Epidermis Sintética con Blindaje y Puertos (Androide)',
  'T15 Piel Cadavérica Degradada Verdosa (Zombi)',
  'T16 Biomasa Coloidal con Nodos (Homúnculo)',
  'T17 Superficie Translúcida Bioluminiscente (Celestial/Ángel)'
];

export const MARK_TYPES = [
  'Ninguna',
  'M1 Tatuaje Tradicional / Tribal',
  'M2 Tatuaje Yakuza / Irezumi',
  'M3 Tatuaje Minimalista / Geométrico',
  'M4 Marca de Nacimiento / Lunares',
  'M5 Cicatriz de Batalla / Quemadura',
  'M6 Cicatriz Quirúrgica / Implante',
  'M7 Sello Mágico / Runa Maldita',
  'M8 Pintura Corporal / Maquillaje de Guerra',
  'M9 Circuitos / Líneas Cibernéticas',
  'M10 Patrón Natural (Vitíligo / Manchas)',
  'M11 Cristales / Escamas Incrustadas',
  'M12 Venas Corruptas / Infección Mágica'
];

export const MARK_FINISHES = [
  'Tinta plana mate tradicional',
  'Runa bioluminiscente brillante pulsante',
  'Cicatriz en relieve hipertrófico (queloide)',
  'Quemadura cicatrizada y endurecida',
  'Tatuaje ritual grabado a fuego',
  'Marca etérea flotante bajo la epidermis',
  'Pintura ritual mate pigmentada al polvo'
];

export const CLAWS_TYPES = [
  'Uñas naturales estándar',
  'Uñas alargadas afiladas (estilete)',
  'Garras retráctiles felinas',
  'Garras biológicas de quitina endurecida',
  'Garras óseas demoníacas ennegrecidas',
  'Garras metálicas / cibernéticas reforzadas'
];

export const PAW_PADS_OPTIONS = [
  'Ninguna / Sin almohadillas (Piel lisa estándar)',
  'Almohadillas Carnosas Rosadas Suaves (Nikukyu Clásico en Manos y Pies)',
  'Almohadillas Dérmicas Negras / Azabache Mate en Manos y Pies',
  'Almohadillas Pigmentadas Carmesí / Sangre',
  'Almohadillas Bicolor (Rosa pastel y Marrón claro)',
  'Almohadillas Suaves Solo en Palmas de las Manos',
  'Almohadillas Dérmicas Solo en Plantas de los Pies',
  'Almohadillas Bioluminiscentes con Brillo Tenue'
];

export const MARK_SHAPES = [
  // Geométricos
  'Geometría: Líneas Rectas Paralelas',
  'Geometría: Círculos Concéntricos',
  'Geometría: Triángulos Entrelazados',
  'Geometría: Hexágonos (Panal)',
  'Geometría: Espiral',
  'Geometría: Mandala',
  // Bestias Míticas
  'Mítico: Dragón Oriental',
  'Mítico: Dragón Occidental',
  'Mítico: Fénix',
  'Mítico: Zorro de Nueve Colas (Kitsune)',
  'Mítico: Demonio (Oni)',
  // Animales
  'Animal: Lobo',
  'Animal: Serpiente',
  'Animal: León',
  'Animal: Tigre',
  'Animal: Gato',
  'Animal: Cuervo',
  'Animal: Águila',
  'Animal: Búho',
  'Animal: Pez Koi',
  // Insectos / Arácnidos
  'Insecto: Mariposa',
  'Insecto: Polilla',
  'Arácnido: Araña',
  'Arácnido: Escorpión',
  // Naturaleza y Elementos
  'Botánico: Rosa (Flor)',
  'Botánico: Flor de Loto',
  'Botánico: Flor de Cerezo (Sakura)',
  'Botánico: Enredadera de Espinas',
  'Botánico: Árbol Seco',
  'Botánico: Hojas de Arce',
  'Elemento: Llamas de Fuego',
  'Elemento: Humo Ondulante',
  'Elemento: Gotas de Agua',
  'Elemento: Olas de Mar',
  'Elemento: Lágrima (Bajo el ojo)',
  // Celestial
  'Celestial: Sol Radiante',
  'Celestial: Luna Creciente',
  'Celestial: Fases Lunares',
  'Celestial: Estrella de 5 Puntas',
  'Celestial: Estrella de 4 Puntas',
  'Celestial: Constelación Específica',
  // Símbolos Oscuros
  'Símbolo: Cráneo Humano',
  'Símbolo: Ojo Abierto / Ojo que todo lo ve',
  'Símbolo: Telaraña',
  'Símbolo: Murciélago',
  'Símbolo: Pentagrama',
  'Símbolo: Cruz',
  // Armas y Objetos
  'Objeto: Espada Cruzada',
  'Objeto: Daga',
  'Objeto: Corona',
  'Objeto: Cadenas',
  'Objeto: Ancla',
  'Objeto: Reloj de Arena',
  // Alas (Como tatuaje o marca gráfica)
  'Alas: Alas de Ángel (Plumas)',
  'Alas: Alas de Demonio (Murciélago)',
  // Textos y Patrones
  'Texto: Runas Nórdicas',
  'Texto: Caracteres Kanji',
  'Texto: Escritura Élfica',
  'Texto: Números Romanos',
  'Texto: Código de Barras',
  'Tecnología: Placa de Circuitos / PCB',
  'Tecnología: Código Binario',
  // Daños Físicos (Para cicatrices, etc.)
  'Daño: Rasguños de Garras (3-4 líneas)',
  'Daño: Grietas (como porcelana rota)',
  'Daño: Salpicadura / Mancha Irregular',
  'Daño: Quemadura Extensa',
  // Pintura Chamánica, Huellas y Símbolos de Tótem
  'Pintura: Huella de Palma de Mano Completa (Handprint Chamánica / Tribal)',
  'Pintura: Huella de Palma de Mano Completa (Pintura de Guerra Tribal / Chamánica)',
  'Pintura: Franjas y Barras Tribales Paralelas en Extremidades / Brazos',
  'Pintura: Franjas Tribales / Barras Paralelas de Guerrero',
  'Pintura: Runa Chamánica de Bestia / Tótem Sagrado',
  'Pintura: Runa Chamánica de Bestia / Garra Marcada',
  'TAT-NORDIC-01: Tatuajes Tribales Nórdicos / Trazos Rúnicos Negros en Hombros, Brazos y Flancos Oblicuos',
  'Marca Frontal: Trazos Atigrados Felinos / Sello del Rey (王)'
];

export const MARK_LOCATIONS = [
  'Rostro: Ojo Derecho',
  'Rostro: Ojo Izquierdo',
  'Rostro: Mejilla Derecha',
  'Rostro: Mejilla Izquierda',
  'Rostro: Frente (Centro)',
  'Rostro: Frente (Lado Derecho)',
  'Rostro: Frente (Lado Izquierdo)',
  'Rostro: Mentón',
  'Rostro: Mandíbula Derecha',
  'Rostro: Mandíbula Izquierda',
  'Cuello: Lado Derecho',
  'Cuello: Lado Izquierdo',
  'Cuello: Frente (Garganta)',
  'Cuello: Nuca',
  'Torso: Clavícula Derecha',
  'Torso: Clavícula Izquierda',
  'Torso: Pecho (Centro)',
  'Torso: Pecho (Sobre el Corazón)',
  'Torso: Costado Derecho (Costillas)',
  'Torso: Costado Izquierdo (Costillas)',
  'Torso: Abdomen (Centro)',
  'Torso: Ombligo / Vientre Bajo',
  'Pelvis & Cadera: Cadera Derecha / Flanco Pélvico',
  'Pelvis & Cadera: Cadera Izquierda / Flanco Pélvico',
  'Pelvis: Cadera Lateral / Flanco Pélvico Derecho',
  'Pelvis: Cadera Lateral / Flanco Pélvico Izquierdo',
  'Pelvis & Cadera: Vientre Bajo / Zona Pélvica',
  'Glúteos: Glúteo Derecho (Nalga / Cadera Posterior)',
  'Glúteos: Glúteo Izquierdo (Nalga / Cadera Posterior)',
  'Glúteos: Ambos Glúteos (Zona Posterior)',
  'Espalda: Hombro Derecho',
  'Espalda: Hombro Izquierdo',
  'Espalda: Omóplato Derecho',
  'Espalda: Omóplato Izquierdo',
  'Espalda: Espalda Baja',
  'Espalda: Espalda Completa',
  'Brazos: Brazo Derecho Completo',
  'Brazos: Brazo Izquierdo Completo',
  'Brazos: Antebrazo Derecho',
  'Brazos: Antebrazo Izquierdo',
  'Brazos: Dorso Mano Derecha',
  'Brazos: Dorso Mano Izquierda',
  'Brazos: Dedos y Nudillos',
  'Piernas: Muslo Derecho',
  'Piernas: Muslo Izquierdo',
  'Piernas: Pantorrilla Derecha',
  'Piernas: Pantorrilla Izquierda',
  'Piernas: Tobillo/Pie Derecho',
  'Piernas: Tobillo/Pie Izquierdo',
  'Accesorio: Tocado / Máscara Ósea (Sobre Hueso o Cuerno)',
  'Accesorio: Tocado / Máscara Facial (Sobre Hueso o Cuerno)',
  'General: Mitad Derecha del Cuerpo',
  'General: Mitad Izquierda del Cuerpo',
  'General: Cuerpo Completo'
];

export const MARK_COLORS = [
  'Negro',
  'Rojo carmesí',
  'Dorado',
  'Azul cian',
  'Blanco',
  'Plata',
  'Magenta',
  'Verde',
  'Tono de piel oscuro',
  'Rosa cicatriz',
  'Piel oscurecida',
  'Naranja fuego',
  'Negro carbón'
];

export interface MarkTypeConfig {
  defaultShape: string;
  shapes: string[];
  defaultColor: string;
  colors: string[];
}

export const MARK_TYPE_CONFIGS: Record<string, MarkTypeConfig> = {
  'M1 Tatuaje Tradicional / Tribal': {
    defaultShape: 'Tribal: Curvas Espinosas Polinesias / Marquesanas',
    shapes: [
      'Tribal: Curvas Espinosas Polinesias / Marquesanas',
      'Tribal: Patrón Ta Moko Maorí',
      'Tribal: Nudos Celtas Entrelazados',
      'TAT-NORDIC-01: Tatuajes Tribales Nórdicos / Trazos Rúnicos Negros en Hombros, Brazos y Flancos Oblicuos',
      'Tribal Nórdico: Trazos Rúnicos Ondulantes en Hombros, Brazos y Flancos Oblicuos',
      'Marca Frontal: Trazos Atigrados Felinos / Sello del Rey (王)',
      'Tradicional: Lobo / Bestia Feroz',
      'Tradicional: Dragón / Serpiente',
      'Tradicional: Águila / Fénix con Alas Desplegadas',
      'Tradicional: Espada / Daga con Enredadera',
      'Tradicional: Calavera / Cráneo con Flores',
      'Tradicional: Sol / Luna Celestial',
      'Tradicional: Llamas / Olas Estilizadas'
    ],
    defaultColor: 'Negro',
    colors: [
      'Negro',
      'Rojo carmesí',
      'Azul marino',
      'Dorado',
      'Verde oscuro',
      'Gris'
    ]
  },
  'M2 Tatuaje Yakuza / Irezumi': {
    defaultShape: 'Irezumi: Dragón Oriental (Ryu) con Olas',
    shapes: [
      'Irezumi: Dragón Oriental (Ryu) con Olas',
      'Irezumi: Pez Koi Nadando Contracorriente',
      'Irezumi: Tigre Agazapado entre Bambú',
      'Irezumi: Máscara Oni / Hannya con Cuernos',
      'Irezumi: Fénix Japonés (Hou-ou)',
      'Irezumi: Flores de Cerezo (Sakura) con Viento',
      'Irezumi: Flor de Loto sobre Remolinos de Agua',
      'Irezumi: Serpiente Blanca (Hebi)',
      'Irezumi: Calavera entre Crisantemos'
    ],
    defaultColor: 'Negro',
    colors: [
      'Negro',
      'Rojo carmesí',
      'Multicolor',
      'Azul',
      'Dorado'
    ]
  },
  'M3 Tatuaje Minimalista / Geométrico': {
    defaultShape: 'Minimalista: Líneas Finas Paralelas / Brazalete',
    shapes: [
      'Minimalista: Líneas Finas Paralelas / Brazalete',
      'Minimalista: Círculos Concéntricos / Mandala Sutil',
      'Minimalista: Triángulos / Polígonos Sagrados',
      'Minimalista: Pequeña Luna Creciente / Estrella de 4 Puntas',
      'Minimalista: Constelación / Coordenadas Astrales',
      'Minimalista: Silueta de Rosa / Flor de Una Línea',
      'Minimalista: Caracteres Kanji / Glifo Sencillo',
      'Minimalista: Pequeño Punto o Cruz Bajo el Ojo',
      'Minimalista: Flecha / Brújula Geométrica',
      'Gótico: Cruces de Filigrana y Motivos de Murciélago'
    ],
    defaultColor: 'Negro',
    colors: [
      'Negro',
      'Rojo carmesí',
      'Blanco',
      'Azul cobalto',
      'Dorado'
    ]
  },
  'M4 Marca de Nacimiento / Lunares': {
    defaultShape: 'Lunar: Punto Simple',
    shapes: [
      'Lunar: Punto Simple',
      'Lunar: Lunar Sexy (Cerca de labios/ojo)',
      'Lunar: Pequeño Punto Sutil',
      'Lunares: Puntos Múltiples',
      'Lunares: Constelación de Puntos',
      'Marca: Mancha Café con Leche (Irregular)',
      'Marca: Mancha de Vino de Oporto (Vascular)',
      'Marca: Mancha Mongólica / Pigmentada',
      'Marca: Forma de Corazón / Estrella Sutil',
      'Marca Frontal: Trazos Atigrados Felinos / Sello del Rey (王)',
      'Marca: Salpicadura / Mancha Dérmica'
    ],
    defaultColor: 'Marrón oscuro',
    colors: [
      'Marrón oscuro',
      'Marrón claro',
      'Negro',
      'Rojo vino',
      'Gris azulado',
      'Piel oscura'
    ]
  },
  'M5 Cicatriz de Batalla / Quemadura': {
    defaultShape: 'Cicatriz: Corte Diagonal sobre Rostro/Ojo',
    shapes: [
      'Cicatriz: Corte Diagonal sobre Rostro/Ojo',
      'Cicatriz: Corte Lineal Limpio',
      'Cicatriz: Rasguños de Garras (3-4 líneas)',
      'Cicatriz: Herida Punzante / Estocada',
      'Cicatriz: Queloide Gruesa en Relieve',
      'Cicatriz: Mordedura / Desgarro',
      'Quemadura: Quemadura Extensa Texturizada',
      'Quemadura: Salpicadura de Ácido',
      'Quemadura: Por Rayo (Patrón de Lichtenberg)'
    ],
    defaultColor: 'Rosa pálido',
    colors: [
      'Rosa pálido',
      'Blanco',
      'Rojo carmesí',
      'Marrón oscuro',
      'Piel clara',
      'Negro'
    ]
  },
  'M6 Cicatriz Quirúrgica / Implante': {
    defaultShape: 'Quirúrgico: Sutura con Puntos Visibles',
    shapes: [
      'Quirúrgico: Sutura con Puntos Visibles',
      'Quirúrgico: Incisión Médica Recta',
      'Quirúrgico: Placa Metálica con Tornillos / Grapas',
      'Implante: Puerto Subcutáneo / Conector',
      'Implante: Ranura Cibernética / Enchufe Neural',
      'Quirúrgico: Unión Protésica / Amputación'
    ],
    defaultColor: 'Plata',
    colors: [
      'Plata',
      'Gris acero',
      'Rosa pálido',
      'Blanco',
      'Dorado',
      'Negro'
    ]
  },
  'M7 Sello Mágico / Runa Maldita': {
    defaultShape: 'Mágico: Sello Arcano / Círculo de Invocación',
    shapes: [
      'Mágico: Sello Arcano / Círculo de Invocación',
      'Mágico: Runa Nórdica / Eldritch',
      'Mágico: Sello de Maldición (Curse Mark estilo Shonen)',
      'Mágico: Pentagrama / Ocultista',
      'Mágico: Ojo Arcano / Místico',
      'Mágico: Glifos Antiguos / Escritura Élfica',
      'Mágico: Cadena Rúnica Encadenada',
      'Mágico: Simetría Sagrada / Mandala Místico'
    ],
    defaultColor: 'Azul cian',
    colors: [
      'Azul cian',
      'Rojo carmesí',
      'Púrpura',
      'Dorado',
      'Verde esmeralda',
      'Negro',
      'Blanco'
    ]
  },
  'M8 Pintura Corporal / Maquillaje de Guerra': {
    defaultShape: 'Pintura: Franjas Horizontales en Pómulos / Ojos',
    shapes: [
      'Marca Frontal: Trazos Atigrados Felinos / Sello del Rey (王)',
      'Pintura: Huella de Palma de Mano Completa (Handprint Chamánica / Tribal)',
      'Pintura: Franjas y Barras Tribales Paralelas en Extremidades / Brazos',
      'Pintura: Runa Chamánica de Bestia / Tótem Sagrado',
      'Pintura: Franjas Horizontales en Pómulos / Ojos',
      'Pintura: Línea Vertical que Cruza Labios y Mentón',
      'Pintura: Antifaz / Máscara Facial Pintada',
      'Pintura: Manos Marcadas / Salpicaduras Rituales',
      'Pintura: Símbolos Sagrados de Clan / Tribu',
      'Pintura: Huellas Digitales de Ceniza o Arcilla',
      'Pintura: Alas / Lágrimas Estilizadas en Ojos'
    ],
    defaultColor: 'Rojo ocre',
    colors: [
      'Azul cian / Turquesa',
      'Magenta / Fucsia',
      'Púrpura astral',
      'Rojo ocre',
      'Blanco',
      'Negro',
      'Azul índigo',
      'Dorado',
      'Verde neón'
    ]
  },
  'M9 Circuitos / Líneas Cibernéticas': {
    defaultShape: 'Cibernético: Pistas de Circuito Impreso (PCB)',
    shapes: [
      'Cibernético: Pistas de Circuito Impreso (PCB)',
      'Cibernético: Líneas de Datos Paralelas / Tron',
      'Cibernético: Código de Barras / QR / Serial',
      'Cibernético: Hexágonos de Nanotecnología',
      'Cibernético: Matriz de Código Binario',
      'Cibernético: Núcleo Emisor con Líneas Radiales'
    ],
    defaultColor: 'Azul cian',
    colors: [
      'Azul cian',
      'Verde',
      'Rojo',
      'Naranja',
      'Magenta',
      'Blanco',
      'Dorado'
    ]
  },
  'M10 Patrón Natural (Vitíligo / Manchas)': {
    defaultShape: 'Vitíligo: Parches Suaves y Orgánicos',
    shapes: [
      'Vitíligo: Parches Suaves y Orgánicos',
      'Vitíligo: Manchas Asimétricas Alrededor de Ojos/Boca',
      'Vitíligo: Despigmentación en Manos/Extremidades',
      'Pecas: Salpicadura Facial Densa',
      'Pecas: Salpicadura en Hombros y Clavículas',
      'Manchas: Patrón Moteado Tipo Felino/Leopardo',
      'Manchas: Rayas Tipo Tigre Naturales'
    ],
    defaultColor: 'Blanco marfil',
    colors: [
      'Blanco marfil',
      'Piel clara',
      'Marrón dorado',
      'Piel oscura',
      'Rosa'
    ]
  },
  'M11 Cristales / Escamas Incrustadas': {
    defaultShape: 'Cristal: Racimo de Gemas Geodas que Brotan',
    shapes: [
      'Cristal: Racimo de Gemas Geodas que Brotan',
      'Cristal: Picos Cristalinos / Agujas Minerales',
      'Escamas: Parches de Escamas Dracónicas Rígidas',
      'Escamas: Gradiente de Escamas de Pez / Sirena',
      'Placas: Queratina / Corazas Óseas Integradas',
      'Cristal: Facetas Geométricas Pulidas'
    ],
    defaultColor: 'Azul zafiro',
    colors: [
      'Azul zafiro',
      'Rojo rubí',
      'Verde esmeralda',
      'Púrpura amatista',
      'Dorado ámbar',
      'Negro obsidiana',
      'Blanco diamante',
      'Iridiscente'
    ]
  },
  'M12 Venas Corruptas / Infección Mágica': {
    defaultShape: 'Venas: Ramificaciones Reticulares (Dendríticas)',
    shapes: [
      'Venas: Ramificaciones Reticulares (Dendríticas)',
      'Venas: Patrón Raíz de Árbol que se Expande',
      'Venas: Telaraña Vascular Bajo la Piel',
      'Infección: Pústulas / Zarcillos de Parásito',
      'Infección: Grietas de Porcelana Rota con Brillo Interno',
      'Venas: Líneas Pulsantes que Nacen del Corazón/Ojos'
    ],
    defaultColor: 'Negro',
    colors: [
      'Negro',
      'Púrpura oscuro',
      'Rojo carmesí',
      'Verde tóxico',
      'Azul glacial',
      'Dorado'
    ]
  }
};

export const getMarkTypeConfig = (markType: string): MarkTypeConfig => {
  if (MARK_TYPE_CONFIGS[markType]) {
    return MARK_TYPE_CONFIGS[markType];
  }
  const clean = markType.toLowerCase();
  const foundKey = Object.keys(MARK_TYPE_CONFIGS).find(k => {
    const kClean = k.toLowerCase();
    return clean.includes(kClean) || kClean.includes(clean);
  });
  if (foundKey) {
    return MARK_TYPE_CONFIGS[foundKey];
  }
  return {
    defaultShape: MARK_SHAPES[0],
    shapes: MARK_SHAPES,
    defaultColor: MARK_COLORS[0],
    colors: MARK_COLORS
  };
};

// ==========================================
// SISTEMA DE ESTAMPADOS Y DISEÑOS GRÁFICOS TEXTILES (PRENDAS / ROPA)
// ==========================================

export const GARMENT_PRINT_TYPES = [
  'E1 Bordado Clásico / Heráldico',
  'E2 Serigrafía Gráfica / Arte Urbano',
  'E3 Sello Mágico / Runa Arcana',
  'E4 Patrón Geométrico / Damero / Étnico',
  'E5 Estampado Floral / Botánico',
  'E6 Foil Metálico / Holográfico',
  'E7 Tipografía / Kanjis / Caligrafía',
  'E8 Estampado Celestial / Cosmos',
  'E9 Parches Militares / Tácticos / Pins',
  'E10 Degradado Ombré / Tie-Dye / Batik',
  'E11 Estampado Animal Print Textil',
  'E12 Gotas / Salpicaduras de Pintura Artística',
  'E13 Huellitas Felinas / Gráficos de Tigre'
];

export const GARMENT_PRINT_LOCATIONS = [
  'Pecho Central',
  'Pecho Izquierdo (Sobre el Corazón)',
  'Pecho Derecho',
  'Espalda Completa (Gran Formato)',
  'Espalda Superior (Entre Omóplatos)',
  'Manga Izquierda (Hombro / Brazo)',
  'Manga Derecha (Hombro / Brazo)',
  'Ambas Mangas (Largo Completo)',
  'Cuello / Solapas / Borde Escote',
  'Dobladillo Inferior / Faldón',
  'Costados / Paneles Laterales',
  'Pernera Izquierda (Muslo / Pantorrilla)',
  'Pernera Derecha (Muslo / Pantorrilla)',
  'Ambas Perneras (Largo Completo)',
  'Bolsillos Delanteros',
  'Estampado Total All-Over (Toda la Prenda)'
];

export interface GarmentPrintTypeConfig {
  defaultShape: string;
  shapes: string[];
  defaultColor: string;
  colors: string[];
}

export const GARMENT_PRINT_CONFIGS: Record<string, GarmentPrintTypeConfig> = {
  'E1 Bordado Clásico / Heráldico': {
    defaultShape: 'Bordado: Escudo de Armas y Filigranas Reales',
    shapes: [
      'Bordado: Escudo de Armas y Filigranas Reales',
      'Bordado: Corona Imperial con Ramas de Laurel',
      'Bordado: Dragón Heráldico Rampante',
      'Bordado: Águila Bicéfala con Acentos Dorados',
      'Bordado: Flores de Lis Reales Entrelazadas',
      'Bordado: Filigrana Barroca en Espirales Finas',
      'Bordado: Nudos Celtas en Relieve con Hilo Metálico',
      'Bordado: Blasón de Familia Noble / Linaje'
    ],
    defaultColor: 'Dorado',
    colors: [
      'Dorado',
      'Plateado',
      'Rojo carmesí',
      'Negro',
      'Azul cobalto',
      'Blanco marfil',
      'Bronce'
    ]
  },
  'E2 Serigrafía Gráfica / Arte Urbano': {
    defaultShape: 'Gráfico: Ilustración Cyberpunk con Personaje / Mecha',
    shapes: [
      'Gráfico: Ilustración Cyberpunk con Personaje / Mecha',
      'Gráfico: Calavera Estilizada con Rosas y Humo',
      'Gráfico: Arte Anime / Manga de Alto Contraste',
      'Gráfico: Graffiti Tag / Firma Callejera con Goteo',
      'Gráfico: Logo de Banda de Rock / Metal Grunge',
      'Gráfico: Ilustración Dark Synthwave / Glitch Retro',
      'Gráfico: Tigre Feroz / Bestia con Estilo Neo-Tattoo',
      'Gráfico: Cintas de Precaución y Códigos Industriales',
      'Huellitas de Gato / Patitas Felinas (Paw Prints) en Blanco',
      'Franjas de Tigre Urbanas en Pierna / Manga (Tiger Stripes Graphic)'
    ],
    defaultColor: 'Blanco y negro',
    colors: [
      'Blanco y negro',
      'Multicolor neón',
      'Rojo carmesí',
      'Blanco',
      'Amarillo',
      'Gris',
      'Verde neón'
    ]
  },
  'E3 Sello Mágico / Runa Arcana': {
    defaultShape: 'Runa: Círculo de Transmutación Alquímica',
    shapes: [
      'Runa: Círculo de Transmutación Alquímica',
      'Runa: Sello de Invocación con Caracteres Arcanos',
      'Runa: Pentagrama Sagrado con Glifos Celestiales',
      'Runa: Glifos Nórdicos Antiguos en Cadena',
      'Runa: Ojo de la Providencia / Ojo Arcano Vigilante',
      'Runa: Mandalas Místicos de Meditación y Poder',
      'Runa: Runas Élficas Luminosas en Círculo Sagrado',
      'Runa: Sello Maldito de Oscuridad Humeante'
    ],
    defaultColor: 'Azul cian',
    colors: [
      'Azul cian',
      'Dorado',
      'Púrpura',
      'Rojo carmesí',
      'Verde esmeralda',
      'Blanco',
      'Negro'
    ]
  },
  'E4 Patrón Geométrico / Damero / Étnico': {
    defaultShape: 'Geométrico: Damero Cuadriculado Bicromático',
    shapes: [
      'Geométrico: Damero Cuadriculado Bicromático',
      'Geométrico: Grecas Griegas Clásicas (Meandros)',
      'Geométrico: Patrón de Espina de Pescado / Chevron',
      'Geométrico: Malla Hexagonal de Panal Futurista',
      'Geométrico: Rayas Ópticas / Arte Cinético Op-Art',
      'Geométrico: Patrón Étnico Navajó / Azteca Tradicional',
      'Geométrico: Líneas Concéntricas y Romboédricas',
      'Geométrico: Cuadros Tartán Escocés en Contraste'
    ],
    defaultColor: 'Blanco y negro',
    colors: [
      'Blanco y negro',
      'Dorado',
      'Rojo y negro',
      'Azul marino y blanco',
      'Tonos tierra',
      'Plata y gris'
    ]
  },
  'E5 Estampado Floral / Botánico': {
    defaultShape: 'Floral: Flores de Cerezo (Sakura) Flotando en el Viento',
    shapes: [
      'Floral: Flores de Cerezo (Sakura) Flotando en el Viento',
      'Floral: Rosas Rojas Victorianas con Tallos Espinosos',
      'Floral: Flores de Loto sobre Ondas de Agua Japonesas',
      'Floral: Enredadera de Hiedra y Zarzas Silvestres',
      'Floral: Follaje Tropical / Hojas de Costilla de Adán y Palmera',
      'Floral: Crisantemos Imperiales Japoneses',
      'Floral: Peonías Gigantes con Degradados de Pétalos',
      'Floral: Flores Silvestres / Campo Primaveral Delicado'
    ],
    defaultColor: 'Multicolor',
    colors: [
      'Multicolor',
      'Rosa pastel y blanco',
      'Rojo carmesí y verde',
      'Dorado y negro',
      'Gris y negro',
      'Azul índigo',
      'Lavanda y violeta'
    ]
  },
  'E6 Foil Metálico / Holográfico': {
    defaultShape: 'Foil: Lámina de Oro Espejado con Formas de Rayos / Soles',
    shapes: [
      'Foil: Lámina de Oro Espejado con Formas de Rayos / Soles',
      'Foil: Plata Holográfica con Reflejos Prisma Multicolor',
      'Foil: Manchas de Oro Craquelado / Kintsugi en Tejido',
      'Foil: Líneas de Neón Metálico Iridiscente',
      'Foil: Estrellas y Chispas en Oro Rosa Metálico',
      'Foil: Efecto Aceite Tornasolado / Gasolina Iridiscente',
      'Foil: Escamas Metálicas Reflectantes'
    ],
    defaultColor: 'Dorado',
    colors: [
      'Dorado',
      'Plateado',
      'Oro rosa',
      'Cobre',
      'Azul eléctrico',
      'Púrpura tornasol'
    ]
  },
  'E7 Tipografía / Kanjis / Caligrafía': {
    defaultShape: 'Texto: Kanjis Japoneses Verticales con Pincelada Sumi',
    shapes: [
      'Texto: Kanjis Japoneses Verticales con Pincelada Sumi',
      'Texto: Caligrafía Gótica Clásica (Blackletter)',
      'Texto: Tipografía Ciberpunk / Fuentes Tecnológicas Futuristas',
      'Texto: Versos en Latín Antiguo con Letras Capitulares',
      'Texto: Cita Poética / Frase Filosófica Minimalista',
      'Texto: Caracteres Alfanuméricos Tácticos / Serial Numbers',
      'Texto: Caligrafía Árabe / Oriental Fluidos y Continuos'
    ],
    defaultColor: 'Negro',
    colors: [
      'Negro',
      'Rojo bermellón',
      'Blanco',
      'Dorado',
      'Amarillo neón',
      'Plateado'
    ]
  },
  'E8 Estampado Celestial / Cosmos': {
    defaultShape: 'Celestial: Fases Lunares Alineadas (De Nueva a Llena)',
    shapes: [
      'Celestial: Fases Lunares Alineadas (De Nueva a Llena)',
      'Celestial: Carta Astral con Mapa de Constelaciones y Líneas',
      'Celestial: Galaxia Espiral con Polvo Estelar y Nebulosas',
      'Celestial: Sol Radiante con Rostro Alquímico Antiguo',
      'Celestial: Eclipse Solar con Corona Resplandeciente',
      'Celestial: Estrellas Fugaces y Cometas Celestiales',
      'Celestial: Signos del Zodíaco en Círculo Astral'
    ],
    defaultColor: 'Plata y azul',
    colors: [
      'Plata y azul',
      'Dorado',
      'Púrpura y magenta',
      'Blanco',
      'Oro y plata',
      'Azul profundo'
    ]
  },
  'E9 Parches Militares / Tácticos / Pins': {
    defaultShape: 'Parche: Insignia de Escuadrón Especial Bordada',
    shapes: [
      'Parche: Insignia de Escuadrón Especial Bordada',
      'Parche: Calavera Táctica con Casco y Gafas de Visión Nocturna',
      'Parche: Bandera Táctica en Relieve / Velcro',
      'Parche: Barras de Rango Militar y Chevrons de Capitán',
      'Parche: Símbolo de Riesgo Biológico (Biohazard) / Radiación',
      'Parche: Alas de Aviador / Paracaidista Metálicas',
      'Parche: Grupo Sanguíneo y Código de Operador',
      'Parche: Set de Pins Metálicos Esmaltados Coleccionables'
    ],
    defaultColor: 'Verde militar y negro',
    colors: [
      'Verde militar y negro',
      'Beige',
      'Negro',
      'Gris',
      'Multicolor',
      'Rojo y blanco'
    ]
  },
  'E10 Degradado Ombré / Tie-Dye / Batik': {
    defaultShape: 'Degradado: Transición Suave Ombré (De Oscuro a Claro)',
    shapes: [
      'Degradado: Transición Suave Ombré (De Oscuro a Claro)',
      'Degradado: Espiral Psicodélica Tie-Dye Multicolor',
      'Degradado: Efecto Desteñido al Ácido (Acid Wash / Bleach)',
      'Degradado: Batik Tradicional con Grietas de Cera de Reserva',
      'Degradado: Efecto Olas de Humo / Marmolado Líquido',
      'Degradado: Puesta de Sol / Tonos Crepusculares Fluidos'
    ],
    defaultColor: 'Negro a rojo',
    colors: [
      'Negro a rojo',
      'Azul marino a cian',
      'Púrpura a rosa',
      'Multicolor pastel',
      'Blanco sobre negro',
      'Verde a lima'
    ]
  },
  'E11 Estampado Animal Print Textil': {
    defaultShape: 'Animal Print: Moteado de Leopardo / Guepardo Clásico',
    shapes: [
      'Animal Print: Moteado de Leopardo / Guepardo Clásico',
      'Animal Print: Rayas de Tigre de Bengala Orgánicas',
      'Animal Print: Rayas de Cebra Bicolor',
      'Animal Print: Escamas de Serpiente Pitón / Piel de Reptil',
      'Animal Print: Textura de Piel de Cocodrilo Estampada',
      'Animal Print: Manchas de Piel de Vaca / Dálmata',
      'Huellitas de Gato / Patitas Felinas (Paw Prints) en Blanco',
      'Franjas de Tigre Urbanas en Pierna / Manga (Tiger Stripes Graphic)'
    ],
    defaultColor: 'Tonos tierra',
    colors: [
      'Tonos tierra',
      'Blanco y negro',
      'Gris y carbón',
      'Rosa neón y negro',
      'Dorado y negro',
      'Rojo y negro'
    ]
  },
  'E12 Gotas / Salpicaduras de Pintura Artística': {
    defaultShape: 'Arte: Salpicaduras Estilo Action Painting (Pollock)',
    shapes: [
      'Arte: Salpicaduras Estilo Action Painting (Pollock)',
      'Arte: Chorreones Verticales de Tinta y Acuarela',
      'Arte: Explosión Radial de Pintura / Spray Callejero',
      'Arte: Pinceladas Gruesas al Óleo con Textura Visible',
      'Arte: Manchas de Acuarela Translúcida Difusa',
      'Arte: Salpicadura de Sangre / Tinta Roja Dramática'
    ],
    defaultColor: 'Multicolor',
    colors: [
      'Multicolor',
      'Rojo carmesí',
      'Blanco',
      'Negro',
      'Dorado',
      'Verde neón'
    ]
  },
  'E13 Huellitas Felinas / Gráficos de Tigre': {
    defaultShape: 'Huellitas de Gato / Patitas Felinas (Paw Prints) en Blanco',
    shapes: [
      'Huellitas de Gato / Patitas Felinas (Paw Prints) en Blanco',
      'Franjas de Tigre Urbanas en Pierna / Manga (Tiger Stripes Graphic)',
      'Huellita Individual en Pecho / Bolsillo',
      'Rastro de Patitas Felinas en Diagonal',
      'Patrón All-Over de Huellitas Felinas en Contraste'
    ],
    defaultColor: 'Blanco',
    colors: [
      'Blanco',
      'Negro',
      'Rosa pastel',
      'Dorado',
      'Rojo carmesí',
      'Amarillo neón'
    ]
  }
};

export const getGarmentPrintConfig = (printType: string): GarmentPrintTypeConfig => {
  if (GARMENT_PRINT_CONFIGS[printType]) {
    return GARMENT_PRINT_CONFIGS[printType];
  }
  const clean = printType.toLowerCase();
  const foundKey = Object.keys(GARMENT_PRINT_CONFIGS).find(k => {
    const kClean = k.toLowerCase();
    return clean.includes(kClean) || kClean.includes(clean);
  });
  if (foundKey) {
    return GARMENT_PRINT_CONFIGS[foundKey];
  }
  return {
    defaultShape: 'Estampado Personalizado',
    shapes: ['Estampado Personalizado', 'Patrón Frontal', 'Bordado Exclusivo'],
    defaultColor: 'Multicolor',
    colors: ['Multicolor', 'Negro', 'Blanco', 'Dorado', 'Plateado']
  };
};


export const CUT_OPTIONS = ['B.x.1.01 - Ajustado', 'B.x.1.02 - Holgado', 'B.x.1.03 - Recto', 'B.x.1.04 - Entallado', 'B.x.1.05 - Oversize', 'B.x.1.06 - Slim'];
export const LENGTH_OPTIONS = ['B.x.2.L1 - Cortísimo', 'B.x.2.L2 - Corto', 'B.x.2.L3 - Medio', 'B.x.2.L4 - Largo', 'B.x.2.L5 - Máximo', 'B.x.2.L6 - Asimétrico'];
export const SLEEVE_OPTIONS = ['B.x.3.01 - Sin mangas', 'B.x.3.02 - Corta', 'B.x.3.03 - 3/4', 'B.x.3.04 - Larga', 'B.x.3.05 - Abullonada', 'B.x.3.06 - Kimono', 'B.x.3.07 - Raglán'];
export const MATERIAL_OPTIONS = ['Algodón', 'Lino', 'Lana', 'Seda', 'Terciopelo', 'Denim', 'Cuero', 'Encaje', 'Metal', 'PVC', 'Látex'];
export const FINISH_OPTIONS = ['FIN01 - Mate', 'FIN02 - Satinado', 'FIN03 - Brillante', 'FIN04 - Espejado', 'FIN05 - Pulido', 'FIN06 - Desgastado', 'FIN07 - Metalizado', 'FIN08 - Craquelado'];
export const DETAIL_OPTIONS = ['DET01 - Bordados', 'DET02 - Hebillas', 'DET03 - Costuras', 'DET04 - Encajes', 'DET05 - Parches', 'DET06 - Cinturones', 'DET07 - Pliegues'];
export const VARIATION_OPTIONS = ['VAR01 - Simétrica', 'VAR02 - Asimétrica', 'VAR03 - Desgastada', 'VAR04 - Desmechada', 'VAR05 - Degradada'];
export const LAYER_OPTIONS = ['CAP01 - Interior', 'CAP02 - Base', 'CAP03 - Intermedia', 'CAP04 - Exterior', 'CAP05 - Accesorio sobrepuesto'];

export interface WardrobeItem {
  id: string;
  name: string;
  desc: string;
  subcategory?: string;
}

export interface WardrobeCategory {
  id: string;
  name: string;
  items: WardrobeItem[];
}

export const WARDROBE_CATEGORIES: WardrobeCategory[] = [
  { id: 'B0', name: 'B.0 Una Pieza / Capa Base', items: [
    { id: 'B0-01', name: 'Bodycon / Micro Vestido Entallado', desc: "Ajustado al cuerpo, resalta la figura. Silueta ceñida de tejido elástico o cuero con aberturas opcionales." },
    { id: 'B0-02', name: 'Qipao / Cheongsam (Micro, Tradicional o Erótico)', desc: "Corte oriental entallado tradicional, moderno mini o erótico con aberturas laterales pronunciadas y escote gota." },
    { id: 'B0-03', name: 'Pegged', desc: "Volumen en muslos que se estrecha en tobillos. Silueta de trapecio invertido, corte carrot." },
    { id: 'B0-04', name: 'Puff Sleeve', desc: "Mangas voluminosas en los hombros, cintura definida. Contraste entre volumen superior y silueta ajustada inferior." },
    { id: 'B0-05', name: 'Peplum', desc: "Volante en la cintura que realza la cadera. Superposición de tela en la espalda baja con caída estructurada." },
    { id: 'B0-06', name: 'Mermaid Trumpet', desc: "Ajustado hasta rodillas, se abre en campana desde la rodilla. Silueta de sirena con expansión inferior marcada." },
    { id: 'B0-07', name: 'Flapper', desc: "Silueta recta, flecos, estilo años veinte. Caída tubular con movimiento en los bordes, cintura baja." },
    { id: 'B0-08', name: 'Sheath', desc: "Recto y elegante, hasta la rodilla. Corte tubular que no marca cintura excesivamente, línea limpia." },
    { id: 'B0-09', name: 'Vestido Polo', desc: "Cuello polo con botones cortos. Estilo casual-vestir, manga corta, caída recta o ligeramente entallada." },
    { id: 'B0-10', name: 'Slip', desc: "Tirantes finos, estilo lencería. Tejido suave y fluido, escote en V o cuadrado, caída natural del cuerpo." },
    { id: 'B0-11', name: 'Strapless', desc: "Sin tirantes, sujeción interna. Expone hombros y clavículas, silueta definida por el corsé interno o elástico." },
    { id: 'B0-12', name: 'Shift', desc: "Recto y suelto, sin marcar cintura. Silueta de tubo recto desde hombros a muslos, comodidad y movimiento." },
    { id: 'B0-13', name: 'Tunic', desc: "Holgado y alargado, estilo túnica. Caída por encima de la rodilla o media pierna, corte amplio." },
    { id: 'B0-14', name: 'Tent', desc: "Se expande en A desde los hombros. Silueta triangular invertida, amplio en la base sin definición de cintura." },
    { id: 'B0-15', name: 'Drop Waisted', desc: "Cintura baja a la altura de la cadera. El punto de unión entre bodice y falda cae sobre la pelvis." },
    { id: 'B0-16', name: 'Wrap-Surplice', desc: "Surplice — Envolvente con lazo, escote en V. Cruzado frontal que se cierra con nudo lateral o cinturón." },
    { id: 'B0-17', name: 'Kimono', desc: "Mangas anchas, cierre envolvente. Corte tradicional oriental, caída recta, cintura con obi o cinturón ancho." },
    { id: 'B0-18', name: 'Dolman', desc: "Mangas murciélago, caída fluida. Hombros caídos sin costura definida, silueta amplia en la parte superior." },
    { id: 'B0-19', name: 'Bubble-Balloon', desc: "Balloon — Dobladillo recogido, efecto globo. Volumen artificial en la falda por medio de recogidos internos." },
    { id: 'B0-20', name: 'Shirtwaist', desc: "Estilo camisa arriba, falda completa. Cierre de botones frontal, cuello camisero, cintura definida." },
    { id: 'B0-21', name: 'Halter', desc: "Se sujeta en la nuca, espalda descubierta. Tirantes que se cruzan o anudan en el cuello, escote profundo." },
    { id: 'B0-22', name: 'Bustier / Corsé Enterizo', desc: "Cuerpo estructurado tipo corsé con varillas internas, copas moldeadas y silueta muy definida." },
    { id: 'B0-23', name: 'Maxi', desc: "Larga hasta el tobillo. Sofisticada. Caída continua que oculta la pierna completamente." },
    { id: 'B0-24', name: 'Bouffant-Pouf', desc: "Pouf — Falda muy voluminosa, forma de campana. Estructura interna o crinolina que sostiene el volumen." },
    { id: 'B0-25', name: 'One Shoulder', desc: "Un solo tirante, hombro descubierto. Asimetría en el escote, sujeción en un solo lado." },
    { id: 'B0-26', name: 'Mulet', desc: "Más corto adelante, largo atrás. Cola posterior visible desde la rodilla hacia abajo, frente corta." },
    { id: 'B0-27', name: 'Handkerchief', desc: "Dobladillo con picos irregulares. Caída asimétrica en puntas que imita el pañuelo." },
    { id: 'B0-28', name: 'Jacket Dress', desc: "Estilo blazer con longitud de vestido. Solapas, botones frontales, corte entallado de chaqueta extendida." },
    { id: 'B0-29', name: 'Babydoll / Negligé Romántico', desc: "Corte empire corto y fluido bajo el busto, con transparencias de tul, encaje o satén." },
    { id: 'B0-30', name: 'Apron / Jumper', desc: "Estilo pichi o peto, tirantes anchos. Se usa sobre blusa, abertura frontal o lateral." },
    { id: 'B0-31', name: 'Sundress', desc: "Ligero y fresco, tirantes finos. Tejido veraniego, escote redondo o cuadrado, falda fluida." },
    { id: 'B0-32', name: 'Empire', desc: "Cintura bajo el busto, falda fluida. Unión alta que alarga la silueta inferior, caída libre." },
    { id: 'B0-33', name: 'Pleat', desc: "Tela plisada en todo el vestido. Pliegues estructurados verticales que aportan rigidez y movimiento." },
    { id: 'B0-34', name: 'Princess', desc: "Costuras verticales que estilizan. Ajuste mediante paneles sin cintura definida, silueta alargada." },
    { id: 'B0-35', name: 'Petal', desc: "Capas que imitan pétalos de flor. Volantes superpuestos en forma de pétalo, textura tridimensional." },
    { id: 'B0-36', name: 'Virgin Killer Sweater', desc: "Suéter de punto con espalda y costados completamente descubiertos. Clásico sensual y erótico de alto impacto." },
    { id: 'B0-39', name: 'Bodysuit / Catsuit (Látex o Cuero)', desc: "Prenda enteriza anatómica de segunda piel con paneles elásticos, transparencias o acabado brillante." },
    { id: 'B0-40', name: 'Bunny Suit Erótico de Satén', desc: "Corsé ceñido de corte cónico con copas corazón, cuello con pajarita y espalda descubierta." },
    { id: 'B0-42', name: 'Vestido de Novia Erótico / Bridal', desc: "Corsé semitransparente con varillas vistas, falda de tul abierta al frente y velo a juego." },
    { id: 'B0-43', name: 'Monokini Táctico con Cinchas', desc: "Corte asimétrico con cintas elásticas cruzadas y hebillas metálicas." }
  ]},
  { id: 'B1', name: 'B.1 Superiores', items: [
    { id: 'B1-A01', name: 'Top Básico / Tirantes Finos', desc: "Top simple de tirantes delgados, ligero y minimalista." },
    { id: 'B1-A02', name: 'Camiseta', desc: "Corte recto mangas cortas cuello redondo." },
    { id: 'B1-A03', name: 'Camiseta Oversize', desc: "Corte amplio y relajado." },
    { id: 'B1-A04', name: 'Sudadera / Hoodie', desc: "Prenda de algodón o felpa con capucha o cuello redondo, silueta clásica u oversize." },
    { id: 'B1-A05', name: 'Crop Top / Micro Top', desc: "Top corto por encima de la cintura, silueta minimalista y moderna." },
    { id: 'B1-A06', name: 'Tank Top / Musculosa', desc: "Sin mangas, hombros descubiertos y aberturas amplias en la sisa." },
    { id: 'B1-A07', name: 'Suéter de Punto / Pullover', desc: "Prenda clásica de punto cerrado o acanalado con mangas largas." },
    { id: 'B1-A08', name: 'Top Escote Corazón', desc: "Escote corazón realza busto." },
    { id: 'B1-A09', name: 'Top Cruzado / Strappy', desc: "Tiras o tela cruzada al frente sobre el abdomen con anillas decorativas." },
    { id: 'B1-A10', name: 'Halter Top', desc: "Se sujeta en la nuca, espalda descubierta. Tirantes que se cruzan o anudan en el cuello." },
    { id: 'B1-A11', name: 'Bustier / Top Corsé de Encaje', desc: "Cuerpo estructurado con varillas, copas moldeadas balconette y transparencias de encaje." },
    { id: 'B1-A12', name: 'Blusa / Blusa Romántica de Gasa', desc: "Camisa fluida de tela liviana o gasa translúcida con mangas abullonadas." },
    { id: 'B1-A13', name: 'Camisa Estructurada / Clásica', desc: "Prenda abotonada con cuello camisero estructurado y puños." },
    { id: 'B1-A14', name: 'Camisa Corta / Desabotonada de Seda', desc: "Cortada sobre la cintura o llevada holgada y abierta sobre los hombros." },
    { id: 'B1-A15', name: 'Chaleco', desc: "Sin mangas con abotonadura frontal." },
    { id: 'B1-A17', name: 'Top Táctico / Pechera con Hebillas', desc: "Corte asimétrico de cuero, vinilo o tiras técnicas con hombro descubierto y cremallera frontal." },
    { id: 'B1-A20', name: 'Suéter Open-Chest / Pecho Abierto', desc: "Punto suave con abertura ovalada o circular en el escote que expone el pecho." },
    { id: 'B1-A21', name: 'Top Bandeau / Sin Tirantes', desc: "Banda ceñida al busto recta y minimalista, sin mangas ni tirantes." },
    { id: 'B1-A22', name: 'Blusa de Sastrería Romántica / Blusa Aristócrata', desc: "Cuello victoriano estructurado, botonadura frontal y mangas poeta con caída elegante." },
    { id: 'B1-A23', name: 'Bata de Dormir Corta / Peignoir de Descanso', desc: "Corte vaporoso y fluido de mangas acampanadas, ideal para descanso y loungewear." },
    { id: 'B1-33', name: 'Top Halter Drapeado (Draped Halter Top)', desc: "Tejido cruzado en el pecho, cuello alto de seda fina, espalda descubierta sujeta por cadenas doradas y chales de gasa flotantes en brazos." }
  ]},
  { id: 'B12', name: 'B.1.2 Capas Externas / Abrigos', items: [
    { id: 'B12-A01', name: 'Topcoat', desc: "Clásico y elegante. Corte recto hasta media pierna con solapas definidas y estructura de sastrería." },
    { id: 'B12-A02', name: 'Tailcoat / Frac (Clásico o Sin Mangas)', desc: "Frac formal con faldones posteriores largos y abertura frontal, disponible en versión con o sin mangas." },
    { id: 'B12-A03', name: 'Bolero', desc: "Muy corta, cubre solo hombros y parte alta de la espalda. Manga corta o tres cuartos." },
    { id: 'B12-A04', name: 'Cardigan', desc: "Abierta al frente con botones o cierre. Tejido suave y versátil." },
    { id: 'B12-A05', name: 'Chaqueta Bomber / Micro Bomber', desc: "Corte bomber urbano clásico o torera cropped sobre el busto con puños elásticos y cintas tácticas." },
    { id: 'B12-A06', name: 'Biker / Motera', desc: "Cierre diagonal y solapas con broches. Cuero o sintético, ajuste entallado." },
    { id: 'B12-A07', name: 'Trench Coat', desc: "Cruzada, con cinturón y solapas anchas. Tejido resistente al agua, doble botonadura." },
    { id: 'B12-A08', name: 'Parka', desc: "Larga y funcional, con capucha y bolsillos amplios." },
    { id: 'B12-A09', name: 'Capa Larga / Manto de Tul Translúcido', desc: "Manto sin mangas largo en lana, terciopelo o tul bordado con transparencias." },
    { id: 'B12-A10', name: 'Capa Corta / Pelerina', desc: "Manto corto sobre hombros." },
    { id: 'B12-A11', name: 'Chaqueta Militar', desc: "Rígida cuello alto galones." },
    { id: 'B12-A12', name: 'Sobretodo de Piel', desc: "Pesado de pelaje denso." },
    { id: 'B12-A13', name: 'Abrigo Imperial', desc: "Se ensancha hacia el bajo desde la cintura con silueta triangular equilibrada." },
    { id: 'B12-A14', name: 'Capota de Cazador', desc: "Capa con capucha integrada." },
    { id: 'B12-A15', name: 'Túnica Exterior', desc: "Túnica ceremonial de mangas anchas." },
    { id: 'B12-A16', name: 'Kimono / Haori Erótico de Seda Translúcida', desc: "Gasa de seda transparente con estampados orientales y ribetes dorados." },
    { id: 'B12-A17', name: 'Peignoir / Robe de Satén y Encaje con Plumas', desc: "Bata de noche larga y fluida con ribetes de marabú, tul transparente y lazada en el pecho." },
    { id: 'B12-A18', name: 'Chaleco de Vestir', desc: "Chaleco formal entallado de sastrería sin mangas con botonadura frontal, bolsillos de vivo y trabilla trasera de ajuste." },
    { id: 'B12-A19', name: 'Sudadera con Capucha / Hoodie Exterior', desc: "Chaqueta o sudadera amplia con capucha para llevar como capa exterior relajada." }
  ]},
  { id: 'B2', name: 'B.2 Inferiores', items: [
    { id: 'B2-A01', name: 'Pantalón Straight', desc: "Corte recto. Ancho uniforme desde la cadera hasta el bajo. Silueta limpia y vertical sin estrechamiento." },
    { id: 'B2-A02', name: 'Pantalón Cargo', desc: "Múltiples bolsillos laterales." },
    { id: 'B2-A03', name: 'Pantalón Palazzo', desc: "Pierna muy ancha desde la cadera. Caída fluida y amplia que genera silueta de falda en movimiento." },
    { id: 'B2-A04', name: 'Pantalón Skinny', desc: "Ajuste ceñido total desde la cintura hasta el tobillo. Silueta que sigue la anatomía de la pierna sin holgura." },
    { id: 'B2-A05', name: 'Pantalón Boot-Cut', desc: "Cut Flared — Ajustado en muslos y se abre desde la rodilla hacia abajo. Expansión inferior que permite cubrir el calzado." },
    { id: 'B2-A06', name: 'Hakama', desc: "Pantalón tradicional amplio plisado." },
    { id: 'B2-A07', name: 'Minifalda / Falda Tableada', desc: "Falda corta sobre el muslo de tablas uniformes, plisada o de corte recto." },
    { id: 'B2-A08', name: 'Falda Lápiz / Falda con Abertura a la Cadera', desc: "Corte ceñido que sigue la curva de la cadera o falda con abertura lateral pronunciada." },
    { id: 'B2-A09', name: 'Falda Midi', desc: "Largo a media pantorrilla. Clásica y versátil. Terminación entre la rodilla y el gemelo." },
    { id: 'B2-A10', name: 'Falda Plisada Midi / Larga', desc: "Pliegues y tablas verticales uniformes estructuradas con movimiento fluido." },
    { id: 'B2-A11', name: 'Falda Maxi', desc: "Larga hasta el tobillo. Sofisticada. Caída continua que oculta la pierna completamente." },
    { id: 'B2-A12', name: 'Falda Sirena', desc: "Ajustada en caderas y se abre en el bajo. Efecto elegante. Silueta de cola de pez que se ensancha desde la rodilla." },
    { id: 'B2-A13', name: 'Falda Globo', desc: "Bajo abullonado. Volumen y originalidad. Expansión artificial en el borde inferior mediante recogido o estructura." },
    { id: 'B2-A14', name: 'Shorts Tácticos / Hot Pants de Cuero con Argollas', desc: "Corte corto resistente con bolsillos modulares, cinchas y herrajes metálicos." },
    { id: 'B2-A15', name: 'Shorts de Mezclilla / Denim con Ligas', desc: "Pantalón corto de mezclilla casual o deshilachado con ligas de sujeción al muslo." },
    { id: 'B2-A16', name: 'Pantalón Holgado Sartorial', desc: "Vestir amplio con pinzas." },
    { id: 'B2-A17', name: 'Faldón de Combate', desc: "Tiras de protecciones tela/cuero." },
    { id: 'B2-A18', name: 'Grebas / Calzones', desc: "Prenda inferior ajustada antigua." },
    { id: 'B2-A19', name: 'Falda de Tul / Encaje Romántico Translúcido', desc: "Capas de tul vaporoso o encaje floral translúcido con caída suave." },
    { id: 'B2-A20', name: 'Faldellín / Taparrabos Tribal', desc: "Prenda inferior ligera y asimétrica de tiras pélvicas y caída libre." },
    { id: 'B2-A21', name: 'Shorts de Sastre de Tiro Alto (Ouji Shorts)', desc: "Shorts de vestir con pinzas de sastrería, dobladillo vuelto y corte a medio muslo." },
    { id: 'B2-A22', name: 'Shorts de Pijama Rizados / Bloomers de Descanso', desc: "Pantalón corto elástico de descanso con borde ondulado rizado y caída ligera." },
    { id: 'B2-A23', name: 'Joggers Baggy Streetwear con Aberturas Pélvicas (Hip Cut-Outs) y Cordón', desc: "Pantalón holgado estilo urbano japonés con aberturas pélvicas en caderas, cordón blanco en lazo y puños elásticos." },
    { id: 'B2-A24', name: 'Faldón Envolvente', desc: "Falda larga asimétrica envolvente con pliegues fluidos, tiro bajo y abertura frontal/lateral." }
  ]},
  { id: 'B3-A', name: 'B.3.A Sostenes', items: [
    { id: 'B3-A1', name: 'Long-Sleeved Bra', desc: "Brazos cubiertos con soporte." },
    { id: 'B3-A2', name: 'Bralette Romántico de Encaje con Tirantes Dobles', desc: "Sin aros rígidos, con encaje floral bordado, lazos de satén y tirantes dobles." },
    { id: 'B3-A3', name: 'Longline Bra', desc: "Banda inferior extendida hasta la cintura." },
    { id: 'B3-A4', name: 'Bandeau / Top Strapless Translúcido con Perlas', desc: "Banda elástica recta sin tirantes, en tejido suave o tul decorado con pedrería." },
    { id: 'B3-A5', name: 'V-Neck Sleeveless Bralette', desc: "Escote profundo en V." },
    { id: 'B3-A6', name: 'Balconette Bra', desc: "Copa baja que realza la parte superior." },
    { id: 'B3-A7', name: 'Stick-On / Backless Bra Adhesivo', desc: "Copas adhesivas sin tirantes ni bandas para espalda totalmente descubierta." },
    { id: 'B3-A10', name: 'Sujetador Halter con O-Ring (Látex o Tela)', desc: "Sujeción en la nuca con anilla metálica central y espalda descubierta." },
    { id: 'B3-A11', name: 'Sujetador Open-Cup / Sin Copas Strappy', desc: "Estructura de aros y tiras cruzadas sin cobertura en el busto para máxima audacia." },
    { id: 'B3-A13', name: 'Sujetador Bra Top / Copas Metálicas Joya', desc: "Top estructurado con copas reforzadas o placas metálicas doradas con cadenas." },
    { id: 'B3-A14', name: 'Super Push-Up Bra', desc: "Relleno denso para elevar el busto." },
    { id: 'B3-A15', name: 'Sujetador Triangular / Micro Bikini Minimalista', desc: "Copas triangulares mínimas con cordones finos ajustables." },
    { id: 'B3-A22', name: 'Pezoneras / Pasties de Corazón o Cruz', desc: "Adhesivos decorativos satinados o metálicos para cobertura mínima del pezón." }
  ]},
  { id: 'B3-B', name: 'B.3.B Panties', items: [
    { id: 'B3-B1', name: 'Tap Pants', desc: "Short relajado y suelto. Ligero." },
    { id: 'B3-B2', name: 'French Cut', desc: "Corte alto en la cadera." },
    { id: 'B3-B3', name: 'Tanga Clásica / Strappy con Hebillas', desc: "Cobertura frontal con tiras dobles ajustables o hebillas en las caderas." },
    { id: 'B3-B4', name: 'G-String / Micro C-String Invisible', desc: "Tiras ultra delgadas laterales o estructura rígida sin bandas para máxima discreción." },
    { id: 'B3-B5', name: 'Control Briefs', desc: "Tiro alto y compresivo." },
    { id: 'B3-B6', name: 'Bikini Clásico / Tie-Side con Lazos', desc: "Braguita de cobertura moderada con lazadas ajustables en ambos costados." },
    { id: 'B3-B7', name: 'Adhesive Panty', desc: "Braguita adhesiva sin costuras ni bandas laterales." },
    { id: 'B3-B8', name: 'Panty Open Crotch / Encaje con Abertura', desc: "Encaje bordado floral con abertura íntima y detalles de lazos laterales." },
    { id: 'B3-B9', name: 'Panty de Tiro Alto / Keyhole Hips', desc: "Tiro alto sobre el ombligo con aberturas geométricas decorativas en las caderas." },
    { id: 'B3-B10', name: 'Garter Panty', desc: "Con tirantes para sujetar medias." },
    { id: 'B3-B11', name: 'Caged Bikini', desc: "Tiras entrelazadas sobre las caderas." },
    { id: 'B3-B17', name: 'Tanga Joya con Cadenas de Cristal y Perlas', desc: "Tiras reemplazadas por hilos de gemas y colgantes brillantes." },
    { id: 'B3-B18', name: 'Tanga de Látex / Vinilo con Cremallera', desc: "Acabado charol brillante con cremallera frontal funcional." }
  ]},
  { id: 'B3-C', name: 'B.3.C Medias / Pantimedias', items: [
    { id: 'B3-C01', name: 'Medias Altas sobre la Rodilla / Bucaneras', desc: "Medias largas que ascienden por encima de la rodilla hasta el muslo." },
    { id: 'B3-C02', name: 'Calzas / Leggings', desc: "Malla ceñida de cintura a tobillos." },
    { id: 'B3-C03', name: 'Medias de Red / Fishnet con Cristales Strass', desc: "Trama de malla fina o abierta salpicada de cristales que reflejan la luz." },
    { id: 'B3-C04', name: 'Liguero / Medias de Liga con Banda de Encaje', desc: "Medias de seda con banda superior de encaje floral siliconada o cinturón liguero." },
    { id: 'B3-C05', name: 'Calcetas Cortas', desc: "Calcetines estándar sobre tobillo." },
    { id: 'B3-C06', name: 'Medias Translúcidas con Costura Trasera / Motivos', desc: "Medias transparentes con línea vertical trasera y detalles sutiles." },
    { id: 'B3-C07', name: 'Calcetines Tácticos', desc: "Calcetines gruesos reforzados." },
    { id: 'B3-C08', name: 'Vendajes de Combate', desc: "Tiras de tela envueltas en piernas." },
    { id: 'B3-C10', name: 'Pantimedias Rasgadas / Battle Damaged', desc: "Medias oscuras semitransparentes con desgarros y rasgaduras de combate." },
    { id: 'B3-C11', name: 'Medias Asimétricas con Ligas Cruzadas al Muslo', desc: "Una media larga y otra corta con correas y hebillas." },
    { id: 'B3-C15', name: 'Liguero Táctico con Arneses Dobles', desc: "Cinturón de cuero con tiras cuádruples y mosquetones metálicos." },
    { id: 'B3-C16', name: 'Medias Estribo / Stirrup (Talón Abierto)', desc: "Medias largas con abertura en talón y dedos que se sujetan bajo el empeine." }
  ]},
  { id: 'B3-D', name: 'B.3.D Tops / Camisetas Interiores', items: [
    { id: 'B3-D1', name: 'Tank Top / Camiseta Interior de Tirantes', desc: "Tirantes anchos, cuello redondo y ajuste elástico." },
    { id: 'B3-D2', name: 'Camisole / Camisola Ligera de Satén', desc: "Tirantes delgados, tejido ligero y caída suave." },
    { id: 'B3-D3', name: 'Babydoll Nupcial / Negligé Romántico de Tul y Encaje', desc: "Prenda interior corta y transparente con volantes, copas armadas y lazos." },
    { id: 'B3-D4', name: 'Chemise / Camisón de Seda con Espalda Abierta', desc: "Satén suave con tirantes finos o cruzados y escote posterior profundo." },
    { id: 'B3-D5', name: 'Teddy / Body Ceñido (Satén, Encaje o Vinilo)', desc: "Prenda de una pieza que cubre el torso con copas armadas o varillas estructuradas." },
    { id: 'B3-D6', name: 'Bodysuit Básico / Cierre Inferior', desc: "Corte ergonómico elástico de cuello redondo o escote en V con broches en la base." },
    { id: 'B3-D7', name: 'Top Corsé / Bustier Interior Estructurado', desc: "Estructura interna con ballenas y copas moldeadas que esculpe el torso." },
    { id: 'B3-D8', name: 'Crop Top Lingerie de Encaje', desc: "Top corto de encaje calado." },
    { id: 'B3-D9', name: 'Top de Malla / Mesh Translúcido con Ribetes', desc: "Tejido de red transparente que revela la silueta con ribetes de satén reforzados." },
    { id: 'B3-D10', name: 'Bodystocking / Malla Corporal Enteriza Translúcida', desc: "Malla sin costuras que cubre desde el cuello hasta los pies con transparencias." },
    { id: 'B3-D11', name: 'Vendas de Compresión / Sarashi de Pecho', desc: "Tiras de tela de lino o algodón compresivo envueltas firmemente en bandas cruzadas diagonales alrededor del busto y torso con soporte en hombros." }
  ]},
  { id: 'B4', name: 'B.4 Calzado', items: [
    { id: 'B4-01', name: 'Botas Altas sobre Rodilla / Tacón de Aguja', desc: "Llegan hasta medio muslo con tacón stiletto metálico o plataforma estructurada." },
    { id: 'B4-02', name: 'Botines Tácticos / Tacón Alto y Plataforma', desc: "Cuero resistente con suela track, hebillas metálicas y tacón imponente." },
    { id: 'B4-03', name: 'Zapatos Formales / Tacones Clásicos de Salón', desc: "Calzado elegante de tacón fino o medio con acabado en piel o charol." },
    { id: 'B4-04', name: 'Sandalias / Geta', desc: "Abierto con tiras o plataforma de madera tradicional." },
    { id: 'B4-05', name: 'Zapatillas Deportivas', desc: "Casual urbano goma." },
    { id: 'B4-06', name: 'Descalzo', desc: "Pies sin calzado." },
    { id: 'B4-07', name: 'Grebas / Botas Armadas', desc: "Botas blindadas reforzadas con placas metálicas o grebas articuladas." },
    { id: 'B4-08', name: 'Mocasines', desc: "Bajo sin cordones cuero suave." },
    { id: 'B4-09', name: 'Botas Cuero Montaña', desc: "Robustas terreno difícil." },
    { id: 'B4-10', name: 'Zuecos / Clogs', desc: "De madera o imitación, robustos y únicos. Suela rígida, tacón grueso." },
    { id: 'B4-12', name: 'Sandalias de Tiras / Lace-up', desc: "Sandalias de tacón o planas con tiras cruzadas que se anudan a la pierna." },
    { id: 'B4-15', name: 'Zapatillas de Ballet', desc: "Calzado plano o de punta de ballet tradicional con cintas al tobillo." },
    { id: 'B4-16', name: 'Sandalias Geta / Zuecos Tradicionales', desc: "Plataforma de madera tradicional con tiras anudadas de sujeción." },
    { id: 'B4-17', name: 'Botas de Plataforma / Chunky Boots', desc: "Botas de suela gruesa y plataforma dentada track de estilo urbano o alternativo." }
  ]},
  { id: 'B5', name: 'B.5 Accesorios', items: [
    // 1. Cabeza & Sombreros
    { id: 'B5-H01', name: 'Sombrero Fedora', subcategory: 'Cabeza & Sombreros', desc: "Ala media, copa abollada, cinta de seda. Detective / Elegante vintage." },
    { id: 'B5-H02', name: 'Boina Francesa', subcategory: 'Cabeza & Sombreros', desc: "Tejido de lana suave, caída ladeada. Clásico artístico / bohemio." },
    { id: 'B5-H03', name: 'Sombrero de Copa Victoriano', subcategory: 'Cabeza & Sombreros', desc: "Copa cilíndrica alta y rígida, banda de satén. Distinción aristocrática." },
    { id: 'B5-H04', name: 'Gorra Urbana con Visera', subcategory: 'Cabeza & Sombreros', desc: "Visera curva rígida, ajuste trasero. Deportivo / Casual contemporáneo." },
    { id: 'B5-H05', name: 'Gorro Beanie / Lana', subcategory: 'Cabeza & Sombreros', desc: "Tejido acanalado suave, ceñido a la cabeza. Informal urbano." },
    { id: 'B5-H06', name: 'Capucha de Tela Oscura', subcategory: 'Cabeza & Sombreros', desc: "Cobertura profunda de cabeza y sombra sobre el rostro. Sigilo y misterio." },
    { id: 'B5-H07', name: 'Diadema Metálica / Tiara', subcategory: 'Cabeza & Sombreros', desc: "Arco fino de metal noble, adorno frontal con gemas o filigrana." },
    { id: 'B5-H08', name: 'Tocado Floral / Corona de Flores', subcategory: 'Cabeza & Sombreros', desc: "Flores artificiales o naturales entrelazadas con follaje. Bohemio / Fantasía." },
    { id: 'B5-H09', name: 'Corona Real / Tiara Imperial', subcategory: 'Cabeza & Sombreros', desc: "Estructura regia con puntas enjoyadas y grabados dorados de alto rango." },
    { id: 'B5-H10', name: 'Velo Ceremonial / Velo Nupcial con Corona de Flores', subcategory: 'Cabeza & Sombreros', desc: "Caída fluida de tul o encaje translúcido sobre el cabello con diadema de flores o perlas." },
    { id: 'B5-H11', name: 'Pasador / Horquilla Oriental (Kanzashi)', subcategory: 'Cabeza & Sombreros', desc: "Varilla decorativa con borlas colgantes y flores de seda plegada." },
    { id: 'B5-H12', name: 'Cinta para el Pelo / Lazo', subcategory: 'Cabeza & Sombreros', desc: "Cinta suave de satén o terciopelo anudada en lazo." },
    { id: 'B5-H13', name: 'Casco Táctico / Headset Cyber', subcategory: 'Cabeza & Sombreros', desc: "Auriculares envolventes con micrófono o visor HUD integrado." },
    { id: 'B5-H14', name: 'Orejeras Acolchadas de Pelaje', subcategory: 'Cabeza & Sombreros', desc: "Banda superior con almohadillas afelpadas de protección térmica." },
    { id: 'B5-H15', name: 'Cuernos Decorativos / Diadema', subcategory: 'Cabeza & Sombreros', desc: "Diadema con cuernos ornamentales de estilo fantástico o demoníaco." },
    { id: 'B5-H17', name: 'Diadema con Orejitas (Animal / Kemono)', subcategory: 'Cabeza & Sombreros', desc: "Diadema con orejas suaves de conejo, gato o zorro." },
    { id: 'B5-H18', name: 'Tocado / Máscara Chamánica de Cráneo Animal con Cuernos y Amuletos', subcategory: 'Cabeza & Sombreros', desc: "Cráneo óseo estilizado de bestia con cuernos curvados oscuros, cuerdas rituales con borlas, cascabeles y pintura facial de huella de mano." },
    { id: 'B5-H19', name: 'Horquillas / Clips de Pelo (Clips & Barrettes)', subcategory: 'Cabeza & Sombreros', desc: "Pasadores y horquillas decorativas para flequillo o laterales de la cabeza." },
    { id: 'B5-H20', name: 'Tiara / Diadema de Filigrana Gótica', subcategory: 'Cabeza & Sombreros', desc: "Ornamento metálico de encaje de plata oscura con piedras engastadas." },
    { id: 'B5-H21', name: 'Horquillas Asimétricas Pop (Rayo Eléctrico / Flores Gemelas)', subcategory: 'Cabeza & Sombreros', desc: "Pasadores asimétricos estilo anime pop con diseño de rayo estilizado y flor doble en el lateral del flequillo." },
    { id: 'B5-H22', name: 'Tocado de Cadenas con Cabujón y Velo de Gasa Facial', subcategory: 'Cabeza & Sombreros', desc: "Cadenas finas entrelazadas sobre la coronilla, piedras preciosas en lágrima sobre la frente y velo translúcido que cubre nariz y boca dejando los ojos a la vista." },

    // 2. Rostro, Ojos & Piercings
    { id: 'B5-F01', name: 'Gafas Redondas Intelectuales', subcategory: 'Rostro, Ojos & Piercings', desc: "Montura fina circular metálica o de carey. Intelectual clásico." },
    { id: 'B5-F02', name: 'Gafas Rectangulares / Clásicas', subcategory: 'Rostro, Ojos & Piercings', desc: "Líneas limpias, montura de pasta oscura o metal pulido." },
    { id: 'B5-F03', name: 'Gafas de Sol Oscuras / Aviador', subcategory: 'Rostro, Ojos & Piercings', desc: "Lentes polarizadas o espejadas con puente metálico doble." },
    { id: 'B5-F04', name: 'Gafas Estilo Cat-Eye', subcategory: 'Rostro, Ojos & Piercings', desc: "Puntas superiores elevadas, estética retro vintage estilizada." },
    { id: 'B5-F05', name: 'Monóculo Noble con Cadena', subcategory: 'Rostro, Ojos & Piercings', desc: "Lente circular individual con fina cadenilla sujeta a la solapa." },
    { id: 'B5-F06', name: 'Parche Ocular de Cuero', subcategory: 'Rostro, Ojos & Piercings', desc: "Cubierta anatómica de cuero con correa de sujeción ajustable." },
    { id: 'B5-F07', name: 'Máscara Quirúrgica / Techwear', subcategory: 'Rostro, Ojos & Piercings', desc: "Cubrebocas de tela técnica o neopreno negro con filtro." },
    { id: 'B5-F08', name: 'Antifaz Veneciano de Baile', subcategory: 'Rostro, Ojos & Piercings', desc: "Antifaz rígido con bordes dorados, filigrana o plumas." },
    { id: 'B5-F09', name: 'Velo Facial Translúcido', subcategory: 'Rostro, Ojos & Piercings', desc: "Malla fina o seda suspendida desde la nariz o sienes." },
    { id: 'B5-F10', name: 'Piercing Septum / Aro Nasal', subcategory: 'Rostro, Ojos & Piercings', desc: "Aro metálico pulido en el tabique nasal, liso o con gemas." },
    { id: 'B5-F11', name: 'Piercing Nostril / Stud Nasal', subcategory: 'Rostro, Ojos & Piercings', desc: "Pequeño brillo o aro discreto en el ala de la nariz." },
    { id: 'B5-F12', name: 'Piercing en la Ceja', subcategory: 'Rostro, Ojos & Piercings', desc: "Barra curva de titanio o bolitas en el arco superciliar." },
    { id: 'B5-F13', name: 'Piercing Labret / Labio', subcategory: 'Rostro, Ojos & Piercings', desc: "Stud central o lateral bajo el labio inferior." },
    { id: 'B5-F14', name: 'Piercing en la Lengua', subcategory: 'Rostro, Ojos & Piercings', desc: "Barra recta con esferas metálicas en ambos extremos." },
    { id: 'B5-F15', name: 'Visor Holográfico Cyber', subcategory: 'Rostro, Ojos & Piercings', desc: "Monóculo digital translúcido con interfaz óptica proyectada." },

    // 3. Orejas & Pendientes
    { id: 'B5-E01', name: 'Arete Largo Colgante', subcategory: 'Orejas & Pendientes', desc: "Gota o cadena fina que oscila con el movimiento." },
    { id: 'B5-E02', name: 'Aros Clásicos de Oro / Plata', subcategory: 'Orejas & Pendientes', desc: "Aros circulares continuos de grosor fino o medio." },
    { id: 'B5-E03', name: 'Ear Cuff Metálico sin Perforación', subcategory: 'Orejas & Pendientes', desc: "Abrazadera para el cartílago superior de la oreja con grabados." },
    { id: 'B5-E04', name: 'Cadena Oreja-Cartílago', subcategory: 'Orejas & Pendientes', desc: "Cadena que conecta la perforación del lóbulo con un manguito superior." },
    { id: 'B5-E05', name: 'Pendiente de Cruz / Espada Gótica', subcategory: 'Orejas & Pendientes', desc: "Dije colgante con motivo de cruz latina, espada o daga." },
    { id: 'B5-E06', name: 'Aretes de Perla Natural', subcategory: 'Orejas & Pendientes', desc: "Perlas esféricas pulidas con montura clásica discreta." },
    { id: 'B5-E07', name: 'Pendientes de Borla Oriental', subcategory: 'Orejas & Pendientes', desc: "Hilos de seda fina en cascada con sujeción esmaltada." },
    { id: 'B5-E08', name: 'Piercing Industrial / Hélix', subcategory: 'Orejas & Pendientes', desc: "Barra recta de titanio que atraviesa dos puntos del cartílago superior." },
    { id: 'B5-E09', name: 'Aretes Élficos de Filigrana', subcategory: 'Orejas & Pendientes', desc: "Estructura que bordea la oreja terminando en punta alada de filigrana." },

    // 4. Cuello, Gargantillas & Corbatas
    { id: 'B5-N01', name: 'Collar de Cadena Simple', subcategory: 'Cuello, Gargantillas & Corbatas', desc: "Eslabones finos o medianos de metal noble." },
    { id: 'B5-N02', name: 'Gargantilla / Choker de Terciopelo', subcategory: 'Cuello, Gargantillas & Corbatas', desc: "Banda textil suave y ceñida con dije central colgante." },
    { id: 'B5-N03', name: 'Choker de Cuero con Argolla O-Ring y Correa Desmontable', subcategory: 'Cuello, Gargantillas & Corbatas', desc: "Banda de cuero negro con anilla metálica pulida y cadena desmontable con asa." },
    { id: 'B5-N04', name: 'Collar de Perlas / Gargantilla Nupcial con Dije', subcategory: 'Cuello, Gargantillas & Corbatas', desc: "Vueltas de perlas de lustre brillante con dije de oro o campanilla que tintinea." },
    { id: 'B5-N05', name: 'Colgante / Medallón Arcano con Gema', subcategory: 'Cuello, Gargantillas & Corbatas', desc: "Montura elaborada con piedra preciosa central engastada." },
    { id: 'B5-N06', name: 'Cadena Multicapa con Dijes', subcategory: 'Cuello, Gargantillas & Corbatas', desc: "Múltiples niveles de cadenas finas escalonadas sobre el pecho." },
    { id: 'B5-N07', name: 'Corbata Clásica de Seda', subcategory: 'Cuello, Gargantillas & Corbatas', desc: "Ancho estándar con nudo Windsor, acabado satinado formal." },
    { id: 'B5-N08', name: 'Corbata Delgada / Skinny Tie', subcategory: 'Cuello, Gargantillas & Corbatas', desc: "Corte angosto y recto contemporáneo, estética juvenil." },
    { id: 'B5-N09', name: 'Pajarita / Moño de Cuello', subcategory: 'Cuello, Gargantillas & Corbatas', desc: "Lazo simétrico estructurado preanudado o ajustable." },
    { id: 'B5-N10', name: 'Moño Victoriano / Lazo de Cuello', subcategory: 'Cuello, Gargantillas & Corbatas', desc: "Cinta ancha de seda o terciopelo anudada con caídas libres." },
    { id: 'B5-N11', name: 'Pañuelo de Seda / Ascot', subcategory: 'Cuello, Gargantillas & Corbatas', desc: "Drapeado al cuello dentro de la camisa o solapa." },
    { id: 'B5-N12', name: 'Bufanda de Lana Gruesa', subcategory: 'Cuello, Gargantillas & Corbatas', desc: "Tejido cálido de punto grueso envuelto alrededor del cuello." },
    { id: 'B5-N13', name: 'Gorguera con Volantes / Ruff', subcategory: 'Cuello, Gargantillas & Corbatas', desc: "Cuello plisado de estilo renacentista con almidonado circular." },
    { id: 'B5-N14', name: 'Gargantilla / Choker de Encaje con Corazón de Rubí', subcategory: 'Cuello, Gargantillas & Corbatas', desc: "Banda de encaje floral calado con dije de corazón, perla colgante o micro-gotas." },
    { id: 'B5-N15', name: 'Gargantilla de Terciopelo con Lazos Colgantes', subcategory: 'Cuello, Gargantillas & Corbatas', desc: "Cinta de terciopelo ceñida con lazada trasera y caídas de satén elegantes." },
    { id: 'B5-N16', name: 'Choker de Cuero con Cascabel / Medallón Felino', subcategory: 'Cuello, Gargantillas & Corbatas', desc: "Gargantilla ajustada de cuero suave con cascabel dorado sonoro o medallón con silueta felina." },
    { id: 'B5-N17', name: 'Pectoral Rígido de Regalia', subcategory: 'Cuello, Gargantillas & Corbatas', desc: "Gargantilla ancha de placas de metal articuladas con incrustaciones de cabujones de piedras preciosas y lágrimas de metal colgantes sobre las clavículas." },

    // 5. Torso, Pecho & Arneses
    { id: 'B5-T01', name: 'Arnés de Pecho / Bondage de Cuero con Anillas O-Ring', subcategory: 'Torso, Pecho & Arneses', desc: "Correas cruzadas sobre pecho y cintura con herrajes metálicos pulidos." },
    { id: 'B5-T02', name: 'Arnés Underboob de Cintas Elásticas Cruzadas', subcategory: 'Torso, Pecho & Arneses', desc: "Tiras elásticas con tensión anatómica que enmarcan y sujetan la base del busto." },
    { id: 'B5-T03', name: 'Cadena de Cuerpo / Body Chain de Oro con Perlas', subcategory: 'Torso, Pecho & Arneses', desc: "Finas cadenas doradas que cruzan el pecho, hombros y cintura con perlas y lazos de satén." },
    { id: 'B5-T04', name: 'Broche / Prendedor de Solapa', subcategory: 'Torso, Pecho & Arneses', desc: "Prendedor metálico con gema o blasón para chaquetas y capas." },
    { id: 'B5-T05', name: 'Charreteras Militares con Flecos', subcategory: 'Torso, Pecho & Arneses', desc: "Hombreras rígidas decorativas con galones y flecos dorados." },
    { id: 'B5-T06', name: 'Cordón Ceremonial / Aiguillette', subcategory: 'Torso, Pecho & Arneses', desc: "Cordón trenzado dorado que cuelga del hombro al pecho." },
    { id: 'B5-T07', name: 'Bandolera de Munición / Cartuchera', subcategory: 'Torso, Pecho & Arneses', desc: "Correa cruzada al pecho con compartimentos y trabillas." },

    // 6. Manos, Muñecas & Brazos
    { id: 'B5-M01', name: 'Guantes Largos de Ópera (Satén, Terciopelo o Látex)', subcategory: 'Manos, Muñecas & Brazos', desc: "Llegan sobre el codo, en satén sedoso, terciopelo o látex líquido brillante." },
    { id: 'B5-M02', name: 'Guantes Cortos de Cuero Biker', subcategory: 'Manos, Muñecas & Brazos', desc: "Hasta la muñeca con cierre de broche y nudillos ventilados." },
    { id: 'B5-M03', name: 'Guantes Sin Dedos / Tácticos', subcategory: 'Manos, Muñecas & Brazos', desc: "Palma reforzada con dedos descubiertos para destreza." },
    { id: 'B5-M04', name: 'Guantes / Mitones de Encaje Translúcido con Volantes', subcategory: 'Manos, Muñecas & Brazos', desc: "Guantes de encaje calado floral con volantes en la muñeca o corte sin dedos." },
    { id: 'B5-M05', name: 'Brazalete de Bíceps / Mangas Flotantes Desmontables (Detached Sleeves)', subcategory: 'Manos, Muñecas & Brazos', desc: "Aro ceñido al bíceps o mangas amplias flotantes desmontables estilo kimono/tribal con borlas, cascabeles y tiras trenzadas que ondean libres." },
    { id: 'B5-M06', name: 'Pulsera de Eslabones / Cadena', subcategory: 'Manos, Muñecas & Brazos', desc: "Cadena para la muñeca con cierre de mosquetón o ancla." },
    { id: 'B5-M07', name: 'Muñequeras de Cuero con Tachuelas', subcategory: 'Manos, Muñecas & Brazos', desc: "Banda ancha con pinchos cónicos o remaches metálicos." },
    { id: 'B5-M08', name: 'Anillo Delgado Minimalista', subcategory: 'Manos, Muñecas & Brazos', desc: "Banda simple lisa de oro, plata o titanio pulido." },
    { id: 'B5-M09', name: 'Anillo de Sello / Signet Ring', subcategory: 'Manos, Muñecas & Brazos', desc: "Superficie plana superior con escudo, sello heráldico o runa." },
    { id: 'B5-M10', name: 'Set de Anillos Múltiples / Falange', subcategory: 'Manos, Muñecas & Brazos', desc: "Colección de anillos finos distribuidos en varios nudillos." },
    { id: 'B5-M11', name: 'Anillo con Piedra Preciosa Solitaria', subcategory: 'Manos, Muñecas & Brazos', desc: "Gema facetada central engastada en garras o bisel." },
    { id: 'B5-M12', name: 'Garras Articuladas para Dedos', subcategory: 'Manos, Muñecas & Brazos', desc: "Estructuras de armadura metálica que cubren el dedo completo." },
    { id: 'B5-M13', name: 'Esposas / Manillas Suaves de Cuero con Cadena', subcategory: 'Manos, Muñecas & Brazos', desc: "Muñequeras forradas con cadena desmontable de eslabones pulidos." },
    { id: 'B5-M14', name: 'Mangas Flotantes Desmontables (Detached Sleeves) de Seda con Borlas', subcategory: 'Manos, Muñecas & Brazos', desc: "Mangas amplias acampanadas estilo kimono separadas del torso, unidas por lazos en los bíceps con cascabeles y tiras trenzadas que ondean al bailar." },
    { id: 'B5-M15', name: 'Manguitos de Tul con Lazos y Ribete de Peluche', subcategory: 'Manos, Muñecas & Brazos', desc: "Puños translúcidos con lazadas ajustables y ribete afelpado suave." },
    { id: 'B5-A11', name: 'Manguitos Grabados de Antebrazo y Brazalete de Bíceps con Piedras preciosas', subcategory: 'Manos, Muñecas & Brazos', desc: "Conjunto de brazaletes tubulares de metal bruñido con grabados y anillos interconectados." },

    // 7. Cintura, Caderas & Muslos
    { id: 'B5-W01', name: 'Cinturón Clásico de Cuero', subcategory: 'Cintura, Caderas & Muslos', desc: "Correa de cuero curtido con hebilla metálica rectangular." },
    { id: 'B5-W02', name: 'Cinturón Doble con Argollas O-Ring', subcategory: 'Cintura, Caderas & Muslos', desc: "Dos correas paralelas con argollas, ojales y remaches." },
    { id: 'B5-W03', name: 'Cadena para Pantalón / Bolsillo', subcategory: 'Cintura, Caderas & Muslos', desc: "Cadena metálica que cuelga desde la presilla al bolsillo." },
    { id: 'B5-W04', name: 'Faja / Obi Tradicional', subcategory: 'Cintura, Caderas & Muslos', desc: "Banda de satén o tela ancha anudada alrededor de la cintura." },
    { id: 'B5-W05', name: 'Ligas para Muslos / Garters', subcategory: 'Cintura, Caderas & Muslos', desc: "Bandas elásticas o de cuero con hebillas y clips de sujeción para medias." },
    { id: 'B5-W06', name: 'Arnés de Pierna Táctico', subcategory: 'Cintura, Caderas & Muslos', desc: "Correas con hebillas de liberación rápida y bolsillo portaobjetos." },
    { id: 'B5-W07', name: 'Cadena de Cadera / Belly Chain con Cascabeles de Oro', subcategory: 'Cintura, Caderas & Muslos', desc: "Cadena fina alrededor de la pelvis y el ombligo con dijes o cascabeles dorados." },
    { id: 'B5-W08', name: 'Tahalí Porta-Herramientas / Cinto Utilitario', subcategory: 'Cintura, Caderas & Muslos', desc: "Cinturón con múltiples enganches, ganchos y mosquetones." },
    { id: 'B5-W11', name: 'Cinturón de Lencería con Tirantes Desmontables', subcategory: 'Cintura, Caderas & Muslos', desc: "Cinturilla de satén y encaje con cuatro tirantes elásticos ajustables." },
    { id: 'B5-W16', name: 'Cinto de Cadenas de Cintura con Dijes de Corazón / Murciélago', subcategory: 'Cintura, Caderas & Muslos', desc: "Cadena metálica escalonada sobre las caderas con dijes colgantes." },
    { id: 'B5-W17', name: 'Tobillera Asimétrica: Cadena de Oro con Campanilla', subcategory: 'Cintura, Caderas & Muslos', desc: "Cadena de oro fina en un solo tobillo con pequeña campanilla o cascabel de tintineo ligero." },
    { id: 'B5-W18', name: 'Tobillera Asimétrica: Tiras de Cuero con Herrajes', subcategory: 'Cintura, Caderas & Muslos', desc: "Bandas de cuero negro cruzadas en un solo tobillo con micro-hebilla y tachuelas plateadas." },
    { id: 'B5-W19', name: 'Cinturón Ceremonial de Cadenas Escalonadas con Broche', subcategory: 'Cintura, Caderas & Muslos', desc: "Banda pélvica de orfebrería con medallón central de piedras preciosas y múltiples hileras de cadenas colgantes con dijes de hojas de metal." },

    // 8. Bolsos, Mochilas & Portables
    { id: 'B5-B01', name: 'Mochila Urbana / Escolar', subcategory: 'Bolsos, Mochilas & Portables', desc: "Compartimentos múltiples con cremalleras y tirantes acolchados." },
    { id: 'B5-B02', name: 'Bandolera de Cuero / Crossbody', subcategory: 'Bolsos, Mochilas & Portables', desc: "Bolso mediano con correa larga cruzada sobre el torso." },
    { id: 'B5-B03', name: 'Bolso de Mano Elegante', subcategory: 'Bolsos, Mochilas & Portables', desc: "Estructura rígida con asas cortas y detalles metálicos dorados." },
    { id: 'B5-B04', name: 'Bolso Clutch de Noche', subcategory: 'Bolsos, Mochilas & Portables', desc: "Cartera pequeña rectangular sin asas para sujetar con la mano." },
    { id: 'B5-B05', name: 'Bolso Táctico Molle / Militar', subcategory: 'Bolsos, Mochilas & Portables', desc: "Tejido cordura resistente al agua con cinchas modulares." },
    { id: 'B5-B06', name: 'Riñonera / Pouch de Cintura', subcategory: 'Bolsos, Mochilas & Portables', desc: "Bolsa compacta asegurada a la cintura o al pecho." },
    { id: 'B5-B07', name: 'Alforja de Explorador / Mensajero', subcategory: 'Bolsos, Mochilas & Portables', desc: "Bolso amplio con solapa frontal y hebillas de bronce." },
    { id: 'B5-B08', name: 'Abanico Plegable de Seda / Madera', subcategory: 'Bolsos, Mochilas & Portables', desc: "Varillas de bambú o sándalo con tela pintada." },
    { id: 'B5-B09', name: 'Paraguas / Sombrilla Victoriana', subcategory: 'Bolsos, Mochilas & Portables', desc: "Mango curvo de madera con tela impermeable y borde de encaje." },
    { id: 'B5-B10', name: 'Reloj de Bolsillo con Cadena', subcategory: 'Bolsos, Mochilas & Portables', desc: "Caja metálica grabada con tapa de resorte y esfera analógica." },
    { id: 'B5-B11', name: 'Frascos de Poción / Viales Colgantes', subcategory: 'Bolsos, Mochilas & Portables', desc: "Botellitas de vidrio con tapón de corcho en cinto de cuero." },
    { id: 'B5-B12', name: 'Peluche Portado / Muñeco de Compañía', subcategory: 'Bolsos, Mochilas & Portables', desc: "Peluche de tela o felpa llevado en brazos o colgado como accesorio." },
    { id: 'B5-B13', name: 'Bastón de Paseo Aristocrático con Empuñadura Labrada', subcategory: 'Bolsos, Mochilas & Portables', desc: "Vara de madera noble oscura rematada con empuñadura plateada o dorada." },

    // 9. Especiales & Místicos
    { id: 'B5-S01', name: 'Amuleto / Talismán Flotante', subcategory: 'Especiales & Místicos', desc: "Objeto mágico o reliquia suspendido con resplandor sutil." },
    { id: 'B5-S02', name: 'Grilletes / Cadenas de Brazos', subcategory: 'Especiales & Místicos', desc: "Aros metálicos pulidos con eslabones rotos colgantes." },
    { id: 'B5-S03', name: 'Rosario / Cuentas de Oración', subcategory: 'Especiales & Místicos', desc: "Cadena con crucifijo o símbolo sagrado colgante." },
    { id: 'B5-S04', name: 'Máscara Kitsune / Antifaz Ritual', subcategory: 'Especiales & Místicos', desc: "Máscara ritual con decorados tradicionales llevada al rostro o ladeada en la cabeza." },
    { id: 'B5-S05', name: 'Gafas Steampunk con Lentes Múltiples', subcategory: 'Especiales & Místicos', desc: "Lentes abatibles con engranajes de latón sobre la frente." },
    { id: 'B5-S06', name: 'Cola de Succubus / Diablesa Erótica con Lazo', subcategory: 'Especiales & Místicos', desc: "Cola delgada y flexible con punta de corazón o espada y cinta de satén." },
    { id: 'B5-S07', name: 'Cuerdas Shibari Místicas Luminosas', subcategory: 'Especiales & Místicos', desc: "Ataduras tradicionales de cuerda de cáñamo o seda con brillo mágico sutil." },
    { id: 'B5-S08', name: 'Sello de Posesión Arcano / Marca de Amor Carmesí', subcategory: 'Especiales & Místicos', desc: "Tatuaje o marca mágica luminiscente en el vientre o clavícula." },

    // 10. Accesorios Culturales & Étnicos
    { id: 'B5-C01', name: 'Talismán Omamori Japonés de Seda', subcategory: 'Accesorios Culturales & Étnicos', desc: "Bolsa protectora de seda bordada con hilos de oro y cordón sagrado trenzado." },
    { id: 'B5-C02', name: 'Horquilla Kanzashi de Flores de Seda (Tsumami)', subcategory: 'Accesorios Culturales & Étnicos', desc: "Varilla de laca noble con flores plegadas de seda y cascada de campanillas." },
    { id: 'B5-C03', name: 'Abanico Marcial de Guerra (Tessen de Acero)', subcategory: 'Accesorios Culturales & Étnicos', desc: "Varillas de acero pulido y tela reforzada para defensa y elegancia marcial." },
    { id: 'B5-C04', name: 'Cordón Kumihimo con Borlas de Seda y Jade', subcategory: 'Accesorios Culturales & Étnicos', desc: "Trenzado artesanal oriental multicolor con remates en borlas colgantes y cuentas." },
    { id: 'B5-C05', name: 'Joya de Frente Bindi / Maang Tikka con Rubí', subcategory: 'Accesorios Culturales & Étnicos', desc: "Colgante frontal sobre el nacimiento del cabello que desciende al entrecejo con filigrana." },
    { id: 'B5-C06', name: 'Velo Facial Yashmak Translúcido de Seda', subcategory: 'Accesorios Culturales & Étnicos', desc: "Velo ligero que cubre nariz y boca dejando únicamente la mirada al descubierto." },
    { id: 'B5-C07', name: 'Collar y Tobilleras Tribales de Huesos Tallados, Garras y Colmillos', subcategory: 'Accesorios Culturales & Étnicos', desc: "Cuentas de marfil fosilizado, madera oscura, tobilleras rituales con garras y colmillos de bestia que tintinean al danzar." },
    { id: 'B5-C08', name: 'Brazalete Rúnico de Bronce Nórdico', subcategory: 'Accesorios Culturales & Étnicos', desc: "Aro abierto de bronce batido con cabezas de lobo en los extremos y runas protectoras." },
    { id: 'B5-C09', name: 'Cadena Leontina con Relicario Esmaltado', subcategory: 'Accesorios Culturales & Étnicos', desc: "Cadena de oro noble para el chaleco con medallón porta-retrato guardapelo." },
    { id: 'B5-C10', name: 'Talismán Taoísta de Papel Amarillo (Fu)', subcategory: 'Accesorios Culturales & Étnicos', desc: "Tira de papel de arroz consagrado con encantamientos caligrafiados en cinabrio rojo." },
    { id: 'B5-A01', name: 'Tobilleras Rituales de Cuero con Garras y Dientes de Bestia', subcategory: 'Accesorios Culturales & Étnicos', desc: "Bandas de cuero alrededor de los tobillos con cuentas de hueso tallado y colmillos rituales." }
  ]}
];

export const ACCESSORY_SUBCATEGORIES = [
  'Todos',
  'Cabeza & Sombreros',
  'Rostro, Ojos & Piercings',
  'Orejas & Pendientes',
  'Cuello, Gargantillas & Corbatas',
  'Torso, Pecho & Arneses',
  'Manos, Muñecas & Brazos',
  'Cintura, Caderas & Muslos',
  'Bolsos, Mochilas & Portables',
  'Especiales & Místicos',
  'Accesorios Culturales & Étnicos'
];

export const WEAR_CONDITIONS = [
  'Impecable de sastrería / Nueva',
  'Desgastada por el viaje y caminos',
  'Desgarrada y marcada por combate',
  'Envejecida / Deshilachada vintage',
  'Manchada de polvo, hollín y barro',
  'Intacta ceremonial con almidonado regio'
];

export const WEAR_STYLES = [
  'Porte estándar ceñido y cerrado',
  'Abierto y desabrochado fluido al viento',
  'Mangas arremangadas / recogidas',
  'Caído sobre los hombros estilo capa',
  'Porte Caído de Hombros (Off-the-Shoulder / Drop-Shoulder)',
  'Ajuste asimétrico desenfadado',
  'Ceñido con cintas / ajustado a la silueta'
];

export const SHOE_SOLES = [
  'Suela Plana Minimalista / Sin Realce',
  'Suela Fina de Cuero (Elegante Sastorial / Clásica)',
  'Suela de Goma Antideslizante (Urbana / Deportiva)',
  'Suela Track Dentada / Lug Sole (Chunky Militar)',
  'Suela de Plataforma Elevada Gruesa (4-8cm)',
  'Suela de Cuña / Wedge Continua',
  'Suela de Madera Artesanal (Geta / Zueco Tradicional)',
  'Suela Flexible de Tela / Cuerda (Kung-Fu / Marcial)',
  'Suela Blindada con Refuerzos / Puntera de Acero',
  'Suela Ergonómica con Cámara de Aire / Running'
];

export const SHOE_HEELS = [
  'Plano / Sin Tacón (0-1.5cm)',
  'Tacón Bajo de Bloque (2-4cm)',
  'Tacón Cubano / Militar Firme (4-5cm)',
  'Tacón Medio Clásico (5-7cm)',
  'Tacón Alto Grueso / Bloque (8-10cm)',
  'Tacón Stiletto / De Aguja Afilado (9-12cm)',
  'Tacón Extremo con Plataforma (12-16cm)',
  'Tacón Escultural / Geométrico Metálico',
  'Tacón Francés / Luis XV Curvado (Barroco)',
  'Tacón Dientes de Madera Geta (Ashida Tradicional)',
  'Tacón de Cuña / Wedge Elevado'
];

export const CULTURAL_ACCESSORY_TRADITIONS = [
  'Todas las tradiciones',
  'Oriental / Wuxia & Folclore Asiático',
  'Nórdica / Rúnica Tribal',
  'Cortesana / Aristocracia Europea',
  'Mítica / Chamánica Primitiva',
  'Arábiga / Seda del Desierto'
];

export const SUGGESTED_LANGUAGES = [
  'Lengua Común Imperial',
  'Élfico Arcaico / Lengua de las Estrellas',
  'Rúnico Enano Forjado',
  'Dialecto de los Bajos Fondos / Callejero',
  'Dialecto Abisal / Lengua de los Demonios',
  'Silvano de las Hadas y Espíritus',
  'Dracónico Celestial Ancestral',
  'Lenguaje de Signos de Exploradores',
  'Común Antiguo / Lengua Muerta de los Sabios',
  // Oscuras / Ocultismo
  'Lengua Vampírica Carmesí de Sangre',
  'Latín Corrupto de Grimorios Oscuros',
  'Canto Prohibido del Vacío Primordial',
  'Siseo Espectral de los Sin Alma',
  'Pacto Nigromántico de Tumba',
  // Modernas & Cyberpunk
  'Código Binario Puro / Lenguaje de Red Cyberpunk',
  'Jerga Callejera de Megaciudades / Neo-Tokyo Slang',
  'Protocolo Cifrado Militar Spec-Ops',
  'Subcódigo Darknet Encriptado Cuánticamente',
  'Sintaxis de IA Sintética / Machine-Talk',
  // Provocativas / Seducción
  'Canto Hipnótico de Súcubos / Lengua de la Seducción',
  'Dialecto Cortesano de Boudoir & Dobles Sentidos',
  'Susurros Íntimos de Alcoba & Placer',
  'Lenguaje Táctil de Feromonas & Caricias',
  // Anime & Gachas
  'Lenguaje Secreto de Invocación SSR',
  'Dialecto Celestial de Diosas de Gacha',
  'Runas Mágicas de Grimorio Isekai',
  'Gritos de Batalla Shonen / Kiai Mágico',
  'Onomatopeyas y Argot Gyaru / Kawaii Slang'
];

export const SUGGESTED_FATAL_FLAWS = [
  'Arrogancia ciega ante rivales aparentemente inferiores',
  'Deuda de honor o juramento sagrado inquebrantable',
  'Terror paralizante al fuego o tormentas de rayos',
  'Desconfianza crónica que sabotea alianzas cercanas',
  'Compasión imprudente incluso hacia enemigos traicioneros',
  'Vulnerabilidad física debilitante a la luz solar directa',
  'Adicción a la adrenalina o al poder del maná prohibido',
  'Culpa de superviviente que le empuja a sacrificios innecesarios',
  'Fragilidad ante encantamientos mentales o ilusiones hipnóticas',
  // Oscuras / Dark & Edgy
  'Sed insaciable de sangre o energía vital que nubla el raciocinio (Vampiro / Súcubo)',
  'Obsesión posesiva y celos desmedidos hacia una sola persona (Yandere / Yangire)',
  'Fascinación morbosa por el dolor propio o ajeno (Masoquismo / Sadismo latente)',
  'Maldición de alma corrupta que se activa con emociones intensas',
  'Sufre dolor físico si no presencia tormento o caos periódicamente',
  'Vínculo maldito que absorbe la vitalidad de quienes le rodean',
  // Modernas & Cyberpunk
  'Sobrecalentamiento o cortocircuito de implantes cibernéticos bajo estrés extremo',
  'Paranoia severa a la vigilancia satelital y hackeos neuronales',
  'Dependencia crónica de estimulantes sintéticos y neuro-bloqueadores',
  'Ciberpsicosis latente: riesgo de sobrecarga violenta ante estrés neuronal',
  'Rastro digital imborrable perseguido por drones corporativos',
  // Provocativas & Sensuales
  'Sensibilidad corporal extrema y vulnerabilidad irresistible al tacto íntimo',
  'Incapacidad de resistir tentaciones carnales o lujos decadentistas',
  'Pérdida del autocontrol ante elogios ardientes y provocaciones seductoras',
  'Vulnerable a perder la compostura ante caricias inesperadas en zonas erógenas',
  'Necesidad compulsiva de seducir y tener la atención romántica de todos',
  // Anime & Gachas
  'Complejo de superioridad burlón que subestima al rival (Mesugaki / Insolencia)',
  'Incapacidad de ser sincero/a con sus sentimientos (Tsunderismo autodestructivo)',
  'Doble personalidad inestable desencadenada por traumas del pasado',
  'Grave hipersensibilidad en orejas kemono / cuernos / cola ante caricias',
  'Adicción compulsiva a apuestas de vida o muerte y tiradas de destino',
  'Incapaz de resistirse a una tirada de gacha o una comida deliciosa',
  'Entra en pánico y se cubre la cara si alguien le mira fijamente a los ojos con ternura'
];

export const FATAL_FLAW_CATEGORIES: Record<string, string[]> = {
  'Todos': SUGGESTED_FATAL_FLAWS,
  'Clásicos & Heroicos': [
    'Arrogancia ciega ante rivales aparentemente inferiores',
    'Deuda de honor o juramento sagrado inquebrantable',
    'Terror paralizante al fuego o tormentas de rayos',
    'Desconfianza crónica que sabotea alianzas cercanas',
    'Compasión imprudente incluso hacia enemigos traicioneros',
    'Vulnerabilidad física debilitante a la luz solar directa',
    'Adicción a la adrenalina o al poder del maná prohibido',
    'Culpa de superviviente que le empuja a sacrificios innecesarios',
    'Fragilidad ante encantamientos mentales o ilusiones hipnóticas'
  ],
  'Oscuros & Siniestros': [
    'Sed insaciable de sangre o energía vital que nubla el raciocinio (Vampiro / Súcubo)',
    'Obsesión posesiva y celos desmedidos hacia una sola persona (Yandere / Yangire)',
    'Fascinación morbosa por el dolor propio o ajeno (Masoquismo / Sadismo latente)',
    'Maldición de alma corrupta que se activa con emociones intensas',
    'Sufre dolor físico si no presencia tormento o caos periódicamente',
    'Vínculo maldito que absorbe la vitalidad de quienes le rodean'
  ],
  'Cyberpunk & Sci-Fi': [
    'Sobrecalentamiento o cortocircuito de implantes cibernéticos bajo estrés extremo',
    'Paranoia severa a la vigilancia satelital y hackeos neuronales',
    'Dependencia crónica de estimulantes sintéticos y neuro-bloqueadores',
    'Ciberpsicosis latente: riesgo de sobrecarga violenta ante estrés neuronal',
    'Rastro digital imborrable perseguido por drones corporativos'
  ],
  'Sensuales & Tentación': [
    'Sensibilidad corporal extrema y vulnerabilidad irresistible al tacto íntimo',
    'Incapacidad de resistir tentaciones carnales o lujos decadentistas',
    'Pérdida del autocontrol ante elogios ardientes y provocaciones seductoras',
    'Vulnerable a perder la compostura ante caricias inesperadas en zonas erógenas',
    'Necesidad compulsiva de seducir y tener la atención romántica de todos'
  ],
  'Anime & Tropos': [
    'Complejo de superioridad burlón que subestima al rival (Mesugaki / Insolencia)',
    'Incapacidad de ser sincero/a con sus sentimientos (Tsunderismo autodestructivo)',
    'Doble personalidad inestable desencadenada por traumas del pasado',
    'Grave hipersensibilidad en orejas kemono / cuernos / cola ante caricias',
    'Adicción compulsiva a apuestas de vida o muerte y tiradas de destino',
    'Incapaz de resistirse a una tirada de gacha o una comida deliciosa',
    'Entra en pánico y se cubre la cara si alguien le mira fijamente a los ojos con ternura'
  ]
};

export const ACCESSORY_MATERIALS = [
  'Oro',
  'Oro blanco',
  'Oro rosa',
  'Plata',
  'Platino',
  'Bronce',
  'Latón',
  'Cobre',
  'Titanio',
  'Acero',
  'Cuero',
  'Cuero marrón',
  'Terciopelo',
  'Seda',
  'Encaje',
  'Satén',
  'Algodón',
  'Jade',
  'Obsidiana',
  'Nácar',
  'Madera de ébano',
  'Madera de cerezo',
  'Cristal',
  'Resina'
];

export const ACCESSORY_GEM_TYPES = [
  'Sin gema',
  'Diamante',
  'Rubí',
  'Zafiro',
  'Esmeralda',
  'Amatista',
  'Ópalo',
  'Perla',
  'Piedra lunar',
  'Topacio',
  'Aguamarina',
  'Ojo de tigre',
  'Granate',
  'Obsidiana',
  'Jade'
];

export const ACCESSORY_ENGRAVINGS = [
  'Sin Grabado / Liso Pulido',
  'Filigrana Floral / Barroca',
  'Runas Nórdicas / Arcanas',
  'Glifos Cyberpunk / Circuitos',
  'Grabado Celta de Nudos',
  'Relieve Heráldico / Blasón Real',
  'Patrón Geométrico Art Déco',
  'Inscripciones Antiguas en Latín',
  'Motivo de Dragón / Bestia Mítica',
  'Greca Griega / Borde Ornamental'
];

export const ACCESSORY_SIZE_SCALES = [
  'Mini / Discreto (Sutil)',
  'Fino / Elegante',
  'Estándar Equilibrado',
  'Mediano / Destacado',
  'Grande / Statement',
  'Extra Grande / Escultórico'
];

export const ACCESSORY_FIT_STYLES = [
  'Ceñido / Pegado a la piel',
  'Con holgura natural',
  'Colgante / Fluido',
  'Escalonado en cascada',
  'Envolvente múltiple (Vueltas)',
  'Asimétrico ladeado'
];

export const ACCESSORY_STYLES = [
  'Fino & Delicado',
  'Grueso & Chunky',
  'Multicapa / Doble',
  'Rígido / Estructurado',
  'Fluido / Colgante',
  'Minimalista Moderno',
  'Vintage / Victoriano',
  'Gótico / Oscuro',
  'Cyberpunk / Táctico',
  'Ornamental / Barroco'
];

export const ACCESSORY_FINISHES = [
  'Pulido Espejo (Brillante)',
  'Cepillado Mate',
  'Satinado Suave',
  'Martillado Artesanal',
  'Envejecido con Pátina',
  'Forjado Rústico',
  'Cromado Iridiscente',
  'Esmaltado Brillante',
  'Desgastado / Dañado en Batalla'
];

export const ROLES_CATALOG = [
  { cat: 'Civiles', roles: ['Civil Genérico', 'Aldeano', 'Ciudadano', 'Comerciante', 'Artesano'] },
  { cat: 'Servicio y Academia', roles: ['A1 Maid de Mansión', 'A2 Mayordomo Principal', 'A3 Artificiero', 'A4 Bibliotecario Arcano', 'A5 Sirviente / Esclavo', 'A6 Aprendiz', 'A7 Erudito'] },
  { cat: 'Entretenimiento y Arte', roles: ['Ent1 Bailarín/a Exótico/a', 'Ent2 Músico Callejero', 'Ent3 Cortesano/a', 'Ent4 Bufón / Arlequín', 'Ent5 Ídolo / Cantante', 'Ent6 Actor / Actriz'] },
  { cat: 'Marcial y Combate Pesado', roles: ['B1 Berserker', 'B2 Caballero de Placas', 'B3 Duelista', 'B4 Gladiador', 'B5 Samurái Pesado', 'B6 Guardián de Escudo', 'B7 Mercenario', 'B8 Campeón de Arena'] },
  { cat: 'Arcano y Magia', roles: ['C1 Hechicero Clásico', 'C2 Elementalista', 'C3 Nigromante', 'C4 Mago de Batalla', 'C5 Alquimista', 'C6 Invocador', 'C8 Hechicero de Cristal'] },
  { cat: 'Sigilo y Agilidad', roles: ['D1 Pícaro Urbano', 'D2 Cazador de Recompensas', 'D3 Rastreador', 'D4 Bardo Itinerante', 'D5 Tirador de Élite', 'D6 Explorador de Ruinas', 'D7 Contrabandista'] },
  { cat: 'Fe y Naturaleza', roles: ['E1 Clérigo de Guerra', 'E2 Monje Asceta', 'E3 Paladín', 'E4 Sacerdotisa Oracular', 'E5 Inquisidor', 'E6 Druida Chamán', 'E7 Curandero de Campo'] },
  { cat: 'Nobleza y Política', roles: ['Noble', 'F1 Aristócrata de Corte', 'F2 Diplomático', 'F3 Señor de la Guerra', 'F4 Cortesano/a de la Corte', 'F5 Consejero Real', 'F6 Caballero Errante', 'F7 Magnate Mercantil', 'F8 Princesa / Príncipe', 'F9 Rey / Emperador'] },
  { cat: 'Operativos Sombríos', roles: ['G1 Sicario de Gremio', 'G2 Venenista', 'G3 Duelista Mortal', 'G4 Cazador de Brujas', 'G5 Sombra', 'G6 Ejecutor', 'G7 Infiltrador', 'G8 Asesino de Alquiler'] }
];

export const VISUAL_STYLES = ['Casual', 'Elegante', 'Gótico', 'Cyberpunk', 'Steampunk', 'Militar', 'Fantasía Tradicional', 'Fantasía Oriental', 'Kawaii / Lindo', 'Sexy / Provocativo', 'Romántico / Boudoir', 'Deportivo', 'Urbano Moderno', 'Bohemio / Boho', 'Minimalista', 'Vanguardista / Haute Couture', 'Rústico / Superviviente', 'Techwear'];

export {
  ROLE_SPECIFIC_CATALOG,
  getRoleAttireConfig,
  getPieceLengthOptions,
  getDefaultPieceLength,
  DETAIL_LOCATIONS,
  GENERAL_ROLE_MATERIALS,
  GENERAL_ROLE_FINISHES
} from './data/roleAttireData';
export type { RoleAttireConfig, RoleAttirePieceSlot } from './data/roleAttireData';
export {
  ORIENTAL_TRADITIONS,
  ORIENTAL_ARMOR_PIECES,
  ORIENTAL_CULTURAL_ACCESSORIES,
  ORIENTAL_SPIRITUAL_MOTIFS,
  ORIENTAL_SILK_PATTERNS,
  ORIENTAL_JADE_COLORS,
  ORIENTAL_WEAPONS,
  ORIENTAL_AURAS
} from './data/orientalFantasyData';
export type { OrientalTradition, OrientalPieceOption } from './data/orientalFantasyData';

export {
  ALL_STYLE_THEMATIC_DATA,
  getStyleThematicPackage
} from './data/styleArmorAccessoriesData';
export type {
  StyleThematicDataPackage,
  StyleThematicTradition,
  StyleThematicPieceOption,
  StyleAccentMineral,
  StyleWeaponOption
} from './data/styleArmorAccessoriesData';

export {
  CANONICAL_ROLE_BACKGROUND_DATA,
  getRoleBackgroundData
} from './data/roleBackgroundData';
export type {
  RoleBackgroundProfile,
  RoleRelationshipSuggestion,
  RoleBehaviorByRank
} from './data/roleBackgroundData';

export const ROLE_OUTFIT_TYPES = [
  { id: 'Ninguna', name: 'Ninguna' },
  { id: 'O1', name: 'O1 Ligera / Civil (Telas finas, seda, algodón)' },
  { id: 'O2', name: 'O2 Media / Aventurero (Cuero, lana gruesa, lino endurecido)' },
  { id: 'O3', name: 'O3 Pesada / Combate (Cota de malla, placas, brigandina)' },
  { id: 'O4', name: 'O4 Ceremonial / Nobleza (Terciopelo, encajes, oro)' },
  { id: 'O5', name: 'O5 Reveladora / Escasa (Telas transparentes, arneses, tiras)' },
  { id: 'O6', name: 'O6 Uniforme Estricto (Cortes rectos, lana rígida, medallas)' }
];

export const ARMOR_TYPES = [
  { id: 'Ninguna', name: 'Ninguna' },
  { id: 'AR1', name: 'AR1 Ligera (Cuero endurecido, pieles, gambesones)' },
  { id: 'AR2', name: 'AR2 Media (Cota de malla, brigandina)' },
  { id: 'AR3', name: 'AR3 Pesada (Placas de acero completas)' },
  { id: 'AR4', name: 'AR4 Mágica (Runas y campo energético)' },
  { id: 'AR5', name: 'AR5 Tecnológica (Materiales sintéticos, blindaje)' },
  { id: 'AR6', name: 'AR6 Orgánica / Viviente (Quitina, hueso)' }
];

export const ROLE_OUTFIT_PIECES = [
  'P1.1 Capucha de Infiltrador / Sigilo', 'P1.2 Corona Imperial / Tiara Nobiliaria', 'P1.3 Yelmo Abierto / Celada de Caballero', 'P1.4 Velo Sagrado / Tocado de Sacerdotisa', 'P1.5 Máscara Táctica / Respirador Cyberpunk', 'P1.6 Diadema Arcana con Gema Focal', 'P1.7 Monóculo de Artificiero / Escáner Óptico', 'P1.8 Tocado Chamánico de Plumas y Hueso',
  'P2.1 Hábito / Túnica Arcana Rúnica', 'P2.2 Coraza de Placas / Peto de Acero', 'P2.3 Tabardo Heráldico de Batalla', 'P2.4 Jubón de Duelista Acolchado', 'P2.5 Toga Ceremonial de la Alta Corte', 'P2.6 Casaca Militar de Gala / Oficial', 'P2.7 Mandil Reforzado de Herrero / Alquimista', 'P2.8 Gambesón Táctico Reforzado', 'P2.9 Loriga de Cota de Malla', 'P2.10 Arnés Táctico de Asalto y Munición',
  'P3.1 Manto Mágico Bordado de Seda Arcana', 'P3.2 Capa Corta de Duelista al Hombro', 'P3.3 Espaldares Blindados con Hombreras de Rango', 'P3.4 Manto Pesado de Pieles Nórdico', 'P3.5 Pañuelo Táctico / Bufanda de Viento', 'P3.6 Capa con Cola de Ceremonia Imperial',
  'P4.1 Guanteletes de Placas Articulados', 'P4.2 Brazales de Cuero Tachonado', 'P4.3 Vambraces Rúnicos Arcanos', 'P4.4 Manoplas de Combate Pesadas', 'P4.5 Mangas Desprendibles de Ceremonia', 'P4.6 Muñequeras de Esgrima Reforzadas',
  'P5.1 Fajín Marcial de Seda de Combate', 'P5.2 Cinturón de Armas con Fundas Tácticas', 'P5.3 Tasset / Escarcelas Blindadas de Placas', 'P5.4 Faldón de Cota de Malla Defensivo', 'P5.5 Cinturón Alquímico con Frascos y Viales', 'P5.6 Faldón Táctico Blindado / Jinbaori',
  'P6.1 Quijotes y Grebas Articuladas de Placas', 'P6.2 Perneras Reforzadas de Cuero Endurecido', 'P6.3 Hakama Tradicional de Combate', 'P6.4 Pantalón Táctico Antidesgarro', 'P6.5 Medias Blindadas de Mithril / Malla Ligera', 'P6.6 Faldón Acorazado de Batalla',
  'P7.1 Escarpines Blindados de Placas', 'P7.2 Botas Tácticas con Puntera y Espinilleras de Acero', 'P7.3 Botas de Campaña Acorazadas', 'P7.4 Sandalias de Peregrino Reforzadas', 'P7.5 Botas de Montar de Oficial con Espuelas de Oro', 'P7.6 Grebas Integradas de Asalto Tecnológico'
];

export interface RoleStyleTheme {
  primaryMaterial: string;
  materials: string[];
  primaryFinish: string;
  finishes: string[];
  suggestedDetails: string[];
  suggestedColors: { id: string; name: string; hex: string }[];
  styleNote: string;
}

export const ROLE_THEME_CONFIG: Record<string, RoleStyleTheme> = {
  'Arcano y Magia': {
    primaryMaterial: 'MAT04 - Seda',
    materials: ['MAT04 - Seda', 'MAT05 - Terciopelo', 'MAT08 - Encaje', 'MAT01 - Algodón'],
    primaryFinish: 'FIN02 - Satinado',
    finishes: ['FIN02 - Satinado', 'FIN07 - Metalizado', 'FIN01 - Mate'],
    suggestedDetails: ['DET01 - Bordados', 'DET04 - Encajes', 'DET07 - Pliegues'],
    suggestedColors: [
      { id: 'purpura', name: 'Púrpura / Amatista', hex: '#7C3AED' },
      { id: 'azul_profundo', name: 'Azul Zafiro / Noche', hex: '#1E3A8A' },
      { id: 'dorado', name: 'Dorado Solar / Ámbar', hex: '#F59E0B' },
      { id: 'blanco', name: 'Blanco', hex: '#FFFFFF' }
    ],
    styleNote: 'Telas fluidas, bordados místicos, sedas arcanas y acabados sutilmente satinados.'
  },
  'Marcial y Combate Pesado': {
    primaryMaterial: 'MAT07 - Cuero',
    materials: ['MAT07 - Cuero', 'MAT09 - Metal', 'MAT06 - Denim', 'MAT01 - Algodón'],
    primaryFinish: 'FIN06 - Desgastado',
    finishes: ['FIN06 - Desgastado', 'FIN01 - Mate', 'FIN05 - Pulido'],
    suggestedDetails: ['DET02 - Hebillas', 'DET03 - Costuras', 'DET06 - Cinturones'],
    suggestedColors: [
      { id: 'negro', name: 'Negro Azabache / Ébano', hex: '#111317' },
      { id: 'rojo_rubi', name: 'Rojo Rubí / Carmesí', hex: '#DC2626' },
      { id: 'gris_humo', name: 'Gris Humo / Ceniza', hex: '#64748B' },
      { id: 'castano_oscuro', name: 'Castaño Chocolate Oscuro', hex: '#451A03' }
    ],
    styleNote: 'Cueros reforzados, herrajes de combate, costuras dobles y acabados curtidos en batalla.'
  },
  'Sigilo y Agilidad': {
    primaryMaterial: 'MAT07 - Cuero',
    materials: ['MAT07 - Cuero', 'MAT01 - Algodón', 'MAT06 - Denim', 'MAT10 - PVC'],
    primaryFinish: 'FIN01 - Mate',
    finishes: ['FIN01 - Mate', 'FIN02 - Satinado'],
    suggestedDetails: ['DET02 - Hebillas', 'DET06 - Cinturones', 'DET03 - Costuras'],
    suggestedColors: [
      { id: 'negro', name: 'Negro Azabache / Ébano', hex: '#111317' },
      { id: 'gris_humo', name: 'Gris Humo / Ceniza', hex: '#64748B' },
      { id: 'azul_profundo', name: 'Azul Zafiro / Noche', hex: '#1E3A8A' }
    ],
    styleNote: 'Telas silenciosas no reflectivas, cueros flexibles oscuros y cinturones ajustados al cuerpo.'
  },
  'Fe y Naturaleza': {
    primaryMaterial: 'MAT02 - Lino',
    materials: ['MAT02 - Lino', 'MAT01 - Algodón', 'MAT04 - Seda', 'MAT07 - Cuero'],
    primaryFinish: 'FIN01 - Mate',
    finishes: ['FIN01 - Mate', 'FIN02 - Satinado'],
    suggestedDetails: ['DET01 - Bordados', 'DET07 - Pliegues', 'DET04 - Encajes'],
    suggestedColors: [
      { id: 'blanco', name: 'Blanco', hex: '#FFFFFF' },
      { id: 'dorado', name: 'Dorado Solar / Ámbar', hex: '#F59E0B' },
      { id: 'verde_esmeralda', name: 'Verde Esmeralda', hex: '#059669' },
      { id: 'castano_claro', name: 'Castaño Claro / Caramelo', hex: '#92400E' }
    ],
    styleNote: 'Fibras naturales puras, linos orgánicos, bordados sagrados y tonos armónicos de tierra y luz.'
  },
  'Nobleza y Política': {
    primaryMaterial: 'MAT05 - Terciopelo',
    materials: ['MAT05 - Terciopelo', 'MAT04 - Seda', 'MAT08 - Encaje', 'MAT01 - Algodón'],
    primaryFinish: 'FIN02 - Satinado',
    finishes: ['FIN02 - Satinado', 'FIN05 - Pulido', 'FIN07 - Metalizado'],
    suggestedDetails: ['DET01 - Bordados', 'DET04 - Encajes', 'DET07 - Pliegues', 'DET06 - Cinturones'],
    suggestedColors: [
      { id: 'rojo_rubi', name: 'Rojo Rubí / Carmesí', hex: '#DC2626' },
      { id: 'dorado', name: 'Dorado Solar / Ámbar', hex: '#F59E0B' },
      { id: 'azul_profundo', name: 'Azul Zafiro / Noche', hex: '#1E3A8A' },
      { id: 'blanco', name: 'Blanco', hex: '#FFFFFF' }
    ],
    styleNote: 'Terciopelos de alta alcurnia, encajes calados, filigrana bordada en oro y caídas elegantes.'
  },
  'Operativos Sombríos': {
    primaryMaterial: 'MAT07 - Cuero',
    materials: ['MAT07 - Cuero', 'MAT10 - PVC', 'MAT01 - Algodón', 'MAT06 - Denim'],
    primaryFinish: 'FIN01 - Mate',
    finishes: ['FIN01 - Mate', 'FIN06 - Desgastado'],
    suggestedDetails: ['DET02 - Hebillas', 'DET06 - Cinturones', 'DET05 - Parches'],
    suggestedColors: [
      { id: 'negro', name: 'Negro Azabache / Ébano', hex: '#111317' },
      { id: 'rojo_fuego', name: 'Rojo Fuego / Escarlata', hex: '#EF4444' },
      { id: 'gris_humo', name: 'Gris Humo / Ceniza', hex: '#64748B' }
    ],
    styleNote: 'Cueros tratados mate, arneses de sujeción táctica y tonos negros o carbón no detectables.'
  },
  'Servicio y Academia': {
    primaryMaterial: 'MAT01 - Algodón',
    materials: ['MAT01 - Algodón', 'MAT02 - Lino', 'MAT04 - Seda', 'MAT08 - Encaje'],
    primaryFinish: 'FIN01 - Mate',
    finishes: ['FIN01 - Mate', 'FIN02 - Satinado'],
    suggestedDetails: ['DET07 - Pliegues', 'DET04 - Encajes', 'DET03 - Costuras'],
    suggestedColors: [
      { id: 'blanco', name: 'Blanco', hex: '#FFFFFF' },
      { id: 'negro', name: 'Negro Azabache / Ébano', hex: '#111317' },
      { id: 'azul_profundo', name: 'Azul Zafiro / Noche', hex: '#1E3A8A' }
    ],
    styleNote: 'Cortes pulcros e impecables, cuellos estructurados, pliegues formales y contrastes monocromos.'
  },
  'Entretenimiento y Arte': {
    primaryMaterial: 'MAT04 - Seda',
    materials: ['MAT04 - Seda', 'MAT08 - Encaje', 'MAT05 - Terciopelo', 'MAT10 - PVC'],
    primaryFinish: 'FIN03 - Brillante',
    finishes: ['FIN03 - Brillante', 'FIN02 - Satinado', 'FIN07 - Metalizado'],
    suggestedDetails: ['DET04 - Encajes', 'DET01 - Bordados', 'DET07 - Pliegues'],
    suggestedColors: [
      { id: 'rosa_fucsia', name: 'Rosa Fucsia / Neón', hex: '#EC4899' },
      { id: 'violeta', name: 'Violeta Neón / Índigo', hex: '#8B5CF6' },
      { id: 'dorado', name: 'Dorado Solar / Ámbar', hex: '#F59E0B' },
      { id: 'cian_hielo', name: 'Cian Hielo / Eléctrico', hex: '#06B6D4' }
    ],
    styleNote: 'Sedas llamativas, cortes con vuelo expresivo, detalles relucientes y colores vibrantes.'
  },
  'Civiles': {
    primaryMaterial: 'MAT01 - Algodón',
    materials: ['MAT01 - Algodón', 'MAT02 - Lino', 'MAT06 - Denim', 'MAT03 - Lana'],
    primaryFinish: 'FIN01 - Mate',
    finishes: ['FIN01 - Mate'],
    suggestedDetails: ['DET03 - Costuras', 'DET05 - Parches', 'DET07 - Pliegues'],
    suggestedColors: [
      { id: 'castano_claro', name: 'Castaño Claro / Caramelo', hex: '#92400E' },
      { id: 'azul_cielo', name: 'Azul Cielo / Cobalto', hex: '#3B82F6' },
      { id: 'blanco', name: 'Blanco', hex: '#FFFFFF' }
    ],
    styleNote: 'Tejidos cómodos de uso diario, texturas suaves y confección práctica sin adornos excesivos.'
  }
};

export const STYLE_THEME_CONFIG: Record<string, {
  primaryMaterial: string;
  materials: string[];
  primaryFinish: string;
  finishes: string[];
  detailOverrides: string[];
  colorPalette: { id: string; name: string; hex: string }[];
  styleNote: string;
}> = {
  'Cyberpunk': {
    primaryMaterial: 'MAT10 - PVC',
    materials: ['MAT10 - PVC', 'MAT07 - Cuero', 'MAT06 - Denim'],
    primaryFinish: 'FIN07 - Metalizado',
    finishes: ['FIN07 - Metalizado', 'FIN03 - Brillante', 'FIN01 - Mate'],
    detailOverrides: ['DET02 - Hebillas', 'DET03 - Costuras', 'DET05 - Parches'],
    colorPalette: [
      { id: 'cian_hielo', name: 'Cian Hielo / Eléctrico', hex: '#06B6D4' },
      { id: 'rosa_fucsia', name: 'Rosa Fucsia / Neón', hex: '#EC4899' },
      { id: 'violeta', name: 'Violeta Neón / Índigo', hex: '#8B5CF6' },
      { id: 'negro', name: 'Negro Azabache / Ébano', hex: '#111317' }
    ],
    styleNote: 'Fibras sintéticas, reflectividad cromada, ribetes de neón y herrajes cibernéticos.'
  },
  'Gótico': {
    primaryMaterial: 'MAT05 - Terciopelo',
    materials: ['MAT05 - Terciopelo', 'MAT08 - Encaje', 'MAT07 - Cuero', 'MAT04 - Seda'],
    primaryFinish: 'FIN01 - Mate',
    finishes: ['FIN01 - Mate', 'FIN02 - Satinado'],
    detailOverrides: ['DET04 - Encajes', 'DET01 - Bordados', 'DET07 - Pliegues'],
    colorPalette: [
      { id: 'negro', name: 'Negro Azabache / Ébano', hex: '#111317' },
      { id: 'rojo_rubi', name: 'Rojo Rubí / Carmesí', hex: '#DC2626' },
      { id: 'purpura', name: 'Púrpura / Amatista', hex: '#7C3AED' }
    ],
    styleNote: 'Texturas aterciopeladas oscuras, encajes barrocos, filigrana siniestra y negro dominante.'
  },
  'Steampunk': {
    primaryMaterial: 'MAT07 - Cuero',
    materials: ['MAT07 - Cuero', 'MAT01 - Algodón', 'MAT09 - Metal', 'MAT06 - Denim'],
    primaryFinish: 'FIN06 - Desgastado',
    finishes: ['FIN06 - Desgastado', 'FIN05 - Pulido', 'FIN08 - Craquelado'],
    detailOverrides: ['DET02 - Hebillas', 'DET06 - Cinturones', 'DET03 - Costuras'],
    colorPalette: [
      { id: 'castano_oscuro', name: 'Castaño Chocolate Oscuro', hex: '#451A03' },
      { id: 'castano_claro', name: 'Castaño Claro / Caramelo', hex: '#92400E' },
      { id: 'dorado', name: 'Dorado Solar / Ámbar', hex: '#F59E0B' }
    ],
    styleNote: 'Cuero curtido, hebillas de latón o bronce, costuras expuestas y acabados victorianos industriales.'
  },
  'Militar': {
    primaryMaterial: 'MAT06 - Denim',
    materials: ['MAT06 - Denim', 'MAT01 - Algodón', 'MAT07 - Cuero'],
    primaryFinish: 'FIN01 - Mate',
    finishes: ['FIN01 - Mate', 'FIN06 - Desgastado'],
    detailOverrides: ['DET05 - Parches', 'DET02 - Hebillas', 'DET03 - Costuras'],
    colorPalette: [
      { id: 'verde_esmeralda', name: 'Verde Oliva / Militar', hex: '#059669' },
      { id: 'gris_humo', name: 'Gris Humo / Ceniza', hex: '#64748B' },
      { id: 'negro', name: 'Negro Azabache / Ébano', hex: '#111317' }
    ],
    styleNote: 'Cortes utilitarios rígidos, parches tácticos, bolsillos modulares y colores de camuflaje sobrios.'
  },
  'Fantasía Tradicional': {
    primaryMaterial: 'MAT04 - Seda',
    materials: ['MAT04 - Seda', 'MAT02 - Lino', 'MAT05 - Terciopelo', 'MAT07 - Cuero'],
    primaryFinish: 'FIN02 - Satinado',
    finishes: ['FIN02 - Satinado', 'FIN05 - Pulido', 'FIN07 - Metalizado'],
    detailOverrides: ['DET01 - Bordados', 'DET07 - Pliegues'],
    colorPalette: [
      { id: 'dorado', name: 'Dorado Solar / Ámbar', hex: '#F59E0B' },
      { id: 'azul_profundo', name: 'Azul Zafiro / Noche', hex: '#1E3A8A' },
      { id: 'verde_menta', name: 'Verde Menta / Jade', hex: '#10B981' },
      { id: 'platino', name: 'Blanco Platino / Plata', hex: '#E2E8F0' }
    ],
    styleNote: 'Líneas elegantes clásicas, filigrana dorada, capas fluidas y motivos inspirados en el lore épico.'
  },
  'Fantasía Oriental': {
    primaryMaterial: 'MAT04 - Seda',
    materials: ['MAT04 - Seda', 'MAT02 - Lino', 'MAT07 - Cuero', 'MAT09 - Metal'],
    primaryFinish: 'FIN02 - Satinado',
    finishes: ['FIN02 - Satinado', 'FIN05 - Pulido', 'FIN07 - Metalizado'],
    detailOverrides: ['DET01 - Bordados', 'DET07 - Pliegues', 'DET06 - Cinturones'],
    colorPalette: [
      { id: 'rojo_rubi', name: 'Rojo Carmesí / Laca', hex: '#DC2626' },
      { id: 'dorado', name: 'Oro Dragón / Ámbar', hex: '#F59E0B' },
      { id: 'negro', name: 'Negro Ébano / Seda', hex: '#111317' },
      { id: 'jade', name: 'Verde Jade / Esmeralda', hex: '#059669' }
    ],
    styleNote: 'Telas de seda con motivos florales o dragones, túnicas cruzadas, fajas obi, armaduras laminadas tradicionales y detalles de laca y oro.'
  },
  'Techwear': {
    primaryMaterial: 'MAT10 - PVC',
    materials: ['MAT10 - PVC', 'MAT01 - Algodón', 'MAT07 - Cuero'],
    primaryFinish: 'FIN01 - Mate',
    finishes: ['FIN01 - Mate', 'FIN07 - Metalizado'],
    detailOverrides: ['DET02 - Hebillas', 'DET06 - Cinturones'],
    colorPalette: [
      { id: 'negro', name: 'Negro Azabache / Ébano', hex: '#111317' },
      { id: 'gris_humo', name: 'Gris Humo / Ceniza', hex: '#64748B' }
    ],
    styleNote: 'Membranas hidrófugas mate, cintas con hebillas magnéticas de liberación rápida y silueta táctica urbana.'
  },
  'Elegante': {
    primaryMaterial: 'MAT04 - Seda',
    materials: ['MAT04 - Seda', 'MAT05 - Terciopelo', 'MAT08 - Encaje', 'MAT01 - Algodón'],
    primaryFinish: 'FIN02 - Satinado',
    finishes: ['FIN02 - Satinado', 'FIN05 - Pulido'],
    detailOverrides: ['DET01 - Bordados', 'DET07 - Pliegues'],
    colorPalette: [
      { id: 'blanco', name: 'Blanco', hex: '#FFFFFF' },
      { id: 'negro', name: 'Negro Azabache / Ébano', hex: '#111317' },
      { id: 'dorado', name: 'Dorado Solar / Ámbar', hex: '#F59E0B' }
    ],
    styleNote: 'Cortes limpios de sastrería fina, caída fluida, proporciones áureas y sutileza aristocrática.'
  },
  'Sexy / Provocativo': {
    primaryMaterial: 'MAT08 - Encaje',
    materials: ['MAT08 - Encaje', 'MAT04 - Seda', 'MAT10 - PVC', 'MAT05 - Terciopelo'],
    primaryFinish: 'FIN03 - Brillante',
    finishes: ['FIN03 - Brillante', 'FIN02 - Satinado', 'FIN07 - Metalizado'],
    detailOverrides: ['DET04 - Encajes', 'DET06 - Cinturones'],
    colorPalette: [
      { id: 'rojo_rubi', name: 'Rojo Rubí / Carmesí', hex: '#DC2626' },
      { id: 'negro', name: 'Negro Azabache / Ébano', hex: '#111317' },
      { id: 'rosa_fucsia', name: 'Rosa Fucsia / Neón', hex: '#EC4899' }
    ],
    styleNote: 'Transparencias estratégicas, encajes sugerentes, recortes ceñidos y acabados relucientes.'
  },
  'Kawaii / Lindo': {
    primaryMaterial: 'MAT01 - Algodón',
    materials: ['MAT01 - Algodón', 'MAT08 - Encaje', 'MAT04 - Seda'],
    primaryFinish: 'FIN02 - Satinado',
    finishes: ['FIN02 - Satinado', 'FIN01 - Mate'],
    detailOverrides: ['DET07 - Pliegues', 'DET04 - Encajes'],
    colorPalette: [
      { id: 'rosa_pastel', name: 'Rosa Pastel / Sakura', hex: '#F472B6' },
      { id: 'blanco', name: 'Blanco', hex: '#FFFFFF' },
      { id: 'amarillo', name: 'Amarillo Brillante', hex: '#FBBF24' }
    ],
    styleNote: 'Volantes suaves, lazos decorativos, tonos pastel dulces y siluetas tiernas acampanadas.'
  }
};

export const ARMOR_PIECES = [
  'P1.1 Barbute', 'P1.2 Bascinet con visera', 'P1.3 Sallet', 'P1.4 Cabeza de bestia', 'P1.5 Corona blindada', 'P1.6 Capucha acolchada', 'P1.7 Casco cerrado total', 'P1.8 Integrado tecnológico',
  'P2.1 Placas pectorales', 'P2.2 Coraza completa', 'P2.3 Brigandina', 'P2.4 Cota de malla', 'P2.5 Peto musculado', 'P2.6 Peto cuero',
  'P3.1 Espaldares simples', 'P3.2 Guardaespaldas', 'P3.3 Manto blindado', 'P3.4 Alas blindadas',
  'P4.1 Guanteletes placas', 'P4.2 Brazales cuero', 'P4.3 Vambraces simples', 'P4.4 Manoplas', 'P4.5 Guantes malla', 'P4.6 Guanteletes tecnológicos',
  'P5.1 Faldón de cuero', 'P5.2 Camail de malla', 'P5.3 Cinturón de armas', 'P5.4 Tasset de placas', 'P5.5 Faldón de placas',
  'P6.1 Grebas de placas', 'P6.2 Pantalones malla', 'P6.3 Perneras cuero', 'P6.4 Rodilleras articuladas', 'P6.5 Grebas completas acero',
  'P7.1 Botas cuero acorazado', 'P7.2 Grebas pie integradas', 'P7.3 Botas malla', 'P7.4 Botas con espinilleras'
];

export const ARMOR_MATERIALS = [
  'Acero', 'Acero templado', 'Hierro negro', 'Mithril', 'Adamantio', 'Obsidiana', 'Hueso / Cuerno', 'Madera encantada', 'Cuero de dragón', 'Tejido balístico', 'Energía', 'Quitina'
];

export const ARMOR_FINISHES = [
  'F1 Pulido', 'F2 Mate', 'F3 Forjado a mano', 'F4 Grabado', 'F5 Desgastado / Batalla', 'F6 Enmohecido', 'F7 Reluciente mágico', 'F8 Camuflado'
];

export const WEAPONS_LIST = [
  'W1 Espada recta', 'W2 Espada curva', 'W3 Espada larga / Mandoble', 'W4 Espada corta', 'W5 Katana', 'W6 Daga', 'W7 Hacha mano', 'W8 Hacha guerra', 'W9 Lanza', 'W10 Alabarda', 'W11 Maza / Martillo', 'W12 Estoque / Ropera', 'W13 Látigo', 'W14 Arco corto', 'W15 Arco largo', 'W16 Ballesta', 'W17 Pistola arco', 'W18 Arma fuego antigua', 'W19 Arma fuego moderna', 'W20 Bastón / Catalizador', 'W21 Guantelete armado', 'W22 Arma arrojadiza',
  'W23 Mandoble Descomunal / Espada Magna Colosal de Acero Forjado'
];

export const WEAPONS_GRIPS = [
  'H1 Una mano', 'H2 Una mano y media', 'H3 Dos manos', 'H4 Empuñadura lujo', 'H5 Empuñadura funcional', 'H6 Empuñadura mágica'
];

export const BAGS_LIST = [
  'BG1 Bandolera', 'BG2 Mochila estándar', 'BG3 Mochila táctica', 'BG4 Riñonera', 'BG5 Bolso mano', 'BG6 Bolso hombro', 'BG7 Bolso cadena', 'BG8 Alforjas', 'BG9 Bolsa cinturón', 'BG10 Carcaj', 'BG11 Vaina doble/triple', 'BG12 Maletín', 'BG13 Cofre', 'BG14 Bolsa componentes'
];
export const BAGS_SIZES = ['Z1 Mini', 'Z2 Pequeño', 'Z3 Mediano', 'Z4 Grande', 'Z5 Muy grande'];
export const BAGS_CLOSURES = ['C1 Cordón', 'C2 Hebilla', 'C3 Cremallera', 'C4 Broche magnético', 'C5 Candado', 'C6 Solapa con botón'];

export const ITEMS_LIST = [
  'I1.1 Amuleto protección', 'I1.2 Amuleto almacenamiento', 'I1.3 Amuleto comunicación', 'I1.4 Amuleto encubrimiento',
  'I2.1 Pergamino simple', 'I2.2 Grimorio encadenado', 'I2.3 Tablilla cristal', 'I2.4 Libro viviente',
  'I3.1 Kit cerrajería', 'I3.2 Kit medicina', 'I3.3 Herramientas forja', 'I3.4 Instrumento musical',
  'I4.1 Frascos pociones', 'I4.2 Bolsa mágicos', 'I4.3 Raciones', 'I4.4 Caja munición',
  'I5.1 Sello autoridad', 'I5.2 Llaves maestras', 'I5.3 Insignia rango', 'I5.4 Collar propiedad',
  'I6.1 Gafas análisis', 'I6.2 Brazalete datos', 'I6.3 Dron flotante', 'I6.4 Prótesis visible'
];

export const ANATOMY_DESCRIPTIONS: Record<string, string> = {
  "1 Escuálido / Muy Delgado": "Estructura osea visible. Minima grasa subcutanea. Musculos atrofiados o ausentes. Clavicula, costillas y caderas prominentes.",
  "2 Esbelto / Estandar": "Proporciones armonicas. Grasa y musculo en equilibrio. Sin excesos ni deficits.",
  "3 Atlético / Fibroso": "Músculos definidos sin hipertrofia, postura erguida.",
  "4 Musculoso": "Masa muscular desarrollada, hombros y espalda anchos.",
  "5 Voluminoso / Robusto": "Estructura corpulenta con mezcla de músculo y densidad física.",
  "6 Hipertrofiado / Musculatura Extrema": "Volumen muscular masivo, estiramiento extremo en vestuario.",
  "7 Suave / Blando": "Grasa subcutanea uniforme. Sin definicion muscular visible. Piel lisa, sin sombras de musculo.",
  "8 Relleno": "Formas redondeadas y suaves, contornos corporales continuos.",
  "9 Gordo / Obeso / Extra Grande": "Silueta muy redondeada, volumen corporal global muy elevado.",
  "A Muy Pequeño (1.20 m – 1.40 m)": "Cánon de proporciones reducidas, apariencia compacta.",
  "B Petite (1.40 m – 1.60 m)": "Cánon bajo, figura compacta y estilizada.",
  "C Normal / Estándar (1.60 m – 1.80 m)": "Cánon proporcional estándar, equilibrio neutro.",
  "D Alto (1.80 m – 2.00 m)": "Cánon alto y esbelto, extremidades alargadas.",
  "E Enorme (2.00 m – 2.20 m)": "Cánon gigante, presencia dominante sobre la escena.",
  "F Especial Racial": "Definido directamente por la MRR de la raza (ej. Oni: 1.80–2.40m, Troll: 2.20–2.50m, Centauro: 3.15–3.30m).",
  "A Senos Planos / Pechos Incipientes / Copa AA": "Torso plano sin relieve pectoral acentuado; pectoral liso y caída recta de prendas y armaduras.",
  "B Senos Pequeños / Pechos Discretos / Copa A": "Relieve suave y discreto; silueta ágil y estilizada con mínima alteración del drapeado superior.",
  "C Senos Medianos / Pechos Equilibrados / Copa B-C": "Curvatura proporcionada y armónica; volumen natural con ajuste estándar en corsés, escotes y tops.",
  "D Senos Prominentes / Pechos Voluminosos / Copa D": "Volumen marcado y firme; proyecta la tela frontalmente creando curvatura notoria y sombras inferiores.",
  "E Senos Abundantes / Pechos Enormes / Copa DD-E": "Volumen grande y generoso; tensión acentuada en botones, escotes profundos y prendas ceñidas al cuerpo.",
  "E Senos Abundante / Pechos Enormes / Copa DD-E": "Volumen grande y generoso; tensión acentuada en botones, escotes profundos y prendas ceñidas al cuerpo.",
  "F Senos Colosales / Pechos Hipertróficos / Copa F+": "Masa pectoral colosal y exuberante; volumen extremo que domina la silueta superior y altera fuertemente el drapeado.",
  "A Incipiente / Plano": "Torso plano sin relieve pectoral acentuado; caída recta de prendas.",
  "B Pequeño / Copa A": "Relieve suave y ligero; mínima alteración del drapeado superior.",
  "C Medio / Copa B-C": "Curvatura natural equilibrada; tensión estándar en corsés y tops.",
  "D Prominente / Copa D": "Volumen marcado; proyecta la tela frontalmente creando sombras inferiores.",
  "E Abundante / Copa DD-E": "Volumen grande; tensión acentuada en botones, escotes y prendas ajustadas.",
  "F Enorme / Hipertrófico": "Masa pectoral masiva; modifica fuertemente el centro de gravedad visual del torso.",
  "1 Muy Estrecha": "Cintura visualmente muy reducida respecto al tórax y las caderas; intensifica la silueta de reloj de arena y concentra las sombras en los laterales del abdomen.",
  "2 Estrecha": "Reducción clara del perímetro de cintura; crea una transición marcada entre caja torácica, abdomen y cadera.",
  "3 Media / Equilibrada": "Perímetro proporcional al resto del cuerpo; mantiene una silueta neutra y una distribución regular de sombras.",
  "4 Ancha": "Cintura con mayor perímetro; suaviza la transición entre torso y cadera y reduce el contraste de curvas.",
  "5 Muy Ancha": "Zona abdominal y lumbar de gran amplitud; genera una silueta robusta y transiciones laterales suaves.",
  "6 Definida / Angular": "Cintura estrecha con bordes anatómicos claramente marcados; enfatiza la estructura ósea y las sombras de separación.",
  "7 Suave / Redondeada": "Contorno continuo sin cambios bruscos; favorece una lectura corporal blanda y uniforme.",
  "1 Planos": "Proyección posterior mínima; la línea de pelvis a muslo es relativamente recta.",
  "2 Pequeños": "Proyección posterior leve; volumen contenido y transición corta hacia los muslos.",
  "3 Moderados": "Proyección equilibrada; aporta volumen natural sin dominar la silueta.",
  "4 Redondeados": "Proyección posterior continua y curva; genera una transición suave hacia la cintura y los muslos.",
  "5 Voluminosos": "Mayor masa posterior; modifica el equilibrio visual de la pelvis y produce sombras más profundas bajo la curva.",
  "6 Altos / Firmes": "Proyección moderada con inserción visual elevada; contorno compacto y definido.",
  "7 Suaves / Blandos": "Volumen redondeado con caída visual ligera; transición difusa hacia muslos y pelvis.",
  "8 Muy Voluminosos": "Proyección posterior dominante; aumenta considerablemente el ancho y profundidad visual de la pelvis.",
  "1 Muy Delgados": "Poco volumen muscular o adiposo; extremidades visualmente estrechas.",
  "2 Delgados": "Volumen reducido pero proporcional; líneas limpias y poca sombra interna.",
  "3 Medios / Equilibrados": "Masa proporcional al resto de la pierna; transición anatómica neutra.",
  "4 Gruesos": "Mayor volumen en aductores y cuádriceps; sombras internas más presentes.",
  "5 Musculosos": "Masa muscular definida; separación visible de grupos musculares y contorno firme.",
  "6 Voluminosos / Suaves": "Mayor masa blanda; contorno redondeado y sombras difusas.",
  "7 Muy Voluminosos": "Gran masa de muslo que domina la lectura de la pierna y modifica el ancho de la silueta inferior.",
  "8 Alargados / Estilizados": "Muslos largos con volumen moderado; enfatizan la verticalidad de la figura.",
  "1 Hombre": "Lienzo corporal masculino. Establece la base biológica, estructura ósea, patrón de vello y rasgos sexuales primarios/secundarios característicos del hombre.",
  "2 Mujer": "Lienzo corporal femenino. Establece la base biológica, estructura ósea, contornos y rasgos sexuales primarios/secundarios característicos de la mujer.",
  "3 Andrógino": "Lienzo corporal andrógino o intermedio. Proporciones y rasgos físicos neutros o combinados con ambigüedad estética y balance armónico de líneas corporales.",
  "4 Hombre (mujer trans-sexual)": "Lienzo corporal masculino con identidad o fisonomía de mujer trans-sexual. Permite articular estructura corporal, rasgos estéticos y desarrollo mamario o íntimo conforme a la transición deseada.",
  "Hombre (mujer trans-sexual)": "Lienzo corporal masculino con identidad o fisonomía de mujer trans-sexual. Permite articular estructura corporal, rasgos estéticos y desarrollo mamario o íntimo conforme a la transición deseada.",
  "1 Infancia (0-12 años)": "Rasgos faciales redondeados, proporciones corporales infantiles, ausencia de desarrollo sexual secundario maduro.",
  "2 Adolescencia (13-17 años)": "Desarrollo en proceso, rasgos juveniles, piel tersa, transición entre proporciones infantiles y adultas.",
  "3 Juventud (18-25 años)": "Madurez física plena, frescura juvenil, máximo vigor y definición muscular o de curvas naturales.",
  "4 Adultez Joven (26-35 años)": "Rasgos completamente definidos, pérdida de grasa facial juvenil, madurez y presencia corporal estable.",
  "5 Adultez Media (36-50 años)": "Líneas de expresión incipientes, textura de piel más curtida, densidad corporal consolidada.",
  "6 Adultez Mayor (51-65 años)": "Signos claros de madurez, arrugas visibles, posibles canas, cambios marcados en la distribución de masa.",
  "7 Ancianidad (66+ años)": "Envejecimiento avanzado, textura de piel fina, arrugas profundas, estructura ósea facial más prominente.",
  "8 Desconocida / Inmortal": "Edad ambigua o congelada en el tiempo. Puede mezclar madurez en la mirada con apariencia física de otra etapa.",
  "SIL01 Bípedo Humanoide Estándar (Piernas)": "Extremidades inferiores bípedas estándar con dos piernas y pies proporcionados.",
  "SIL02 Parte Inferior de Araña (Aracne / Drider: Abdomen Gigante y 8 Patas Quilíferas Articuladas)": "Torso humanoide fusionado sobre el cefalotórax y abdomen masivo de una araña gigante con 8 patas articuladas quilíferas y hileras de seda.",
  "SIL03 Parte Inferior de Pulpo (Cecaelia: 8 Tentáculos Cefalópodos Musculares con Ventosas)": "Torso humanoide sobre una base cefalópoda de 8 tentáculos musculares gigantes con doble fila de ventosas táctiles.",
  "SIL04 Cola Serpentina 2.0–3.0 m en lugar de Piernas (Lamia / Naga)": "Torso humanoide sobre una extensa cola serpentina muscular de 2.0 a 3.0 metros con escamas ventrales reptantes.",
  "SIL05 Cola Pisciforme / Aletas de Sirena-Tritón (Transformación Acuática)": "Cola pisciforme con aleta caudal y membranas natatorias acuáticas.",
  "SIL06 Cuerpo Taurino Equino de 4 Patas y Cascos (Centauro)": "Torso humanoide sobre cuerpo cuadrúpedo de caballo con 4 patas, cascos y crin larga.",
  "SIL07 Cuerpo Cuadrúpedo Felino de Tigre / León (Felitaur)": "Torso humanoide sobre cuerpo cuadrúpedo felino de gran tamaño con garras retráctiles y cola felina.",
  "SIL08 Cuerpo Cuadrúpedo Dracónico Escamoso de 4 Patas y Cola Blindada (Dracotaur)": "Torso humanoide sobre cuerpo de dragón cuadrúpedo con cuatro patas escamosas, garras y cola acorazada con crestas.",
  "SIL09 Parte Inferior de Escorpión con 8 Patas y Cola Aguijón Arqueada (Scorpiontaur / Girtablilu)": "Torso humanoide sobre cuerpo acorazado de escorpión gigante con 8 patas y cola con aguijón ponzoñoso elevado.",
  "SIL10 Brazos-Alas de Arpía con Plumaje y Garras en Extremidades": "Brazos-alas plumados integrados y extremidades inferiores con garras aviares de queratina.",
  "SIL11 Matriz Amorfa Gelatinosa / Slime Replicante que babea / escurre gel (Plasmoide)": "Matriz corporal inferior amorfa y gelatinosa de slime replicante que gotea, babea y escurre gel translúcido continuo en contacto con superficies.",
  "SIL12 Matriz Ectoplásmica Flotante / Espectral (Elemental)": "Masa etérea flotante espectral sin soporte de piernas físicas.",
  "SIL13 Pie Muscular Molusco / Babosa Reptante con Rastro Mucoso (Gastrópodo-taur)": "Cuerpo inferior de caracol o babosa con pie muscular ancho y mucosidad brillante.",
  "SIL14 Chasis Flotante Gravitacional / Plataforma Cibernética Biónica (Cyborg)": "Unidad de locomoción repulsora gravitacional o plataforma biónica con propulsores iónicos y cables."
};

export const WARDROBE_DESCRIPTIONS_MAP: Record<string, string> = {
  "Bodycon": "Ajustado al cuerpo, resalta la figura. Silueta ceñida de pecho a rodilla, sin volumen añadido. Tejido elástico y adherente.",
  "Qi Pao": "Cuello mandarín, apertura lateral desde el muslo. Silueta ajustada con corte tradicional, mangas cortas o tres cuartos.",
  "Pegged": "Volumen en muslos que se estrecha en tobillos. Silueta de trapecio invertido, corte carrot.",
  "Puff Sleeve": "Mangas voluminosas en los hombros, cintura definida. Contraste entre volumen superior y silueta ajustada inferior.",
  "Peplum": "Volante en la cintura que realza la cadera. Superposición de tela en la espalda baja con caída estructurada.",
  "Mermaid Trumpet": "Ajustado hasta rodillas, se abre en campana desde la rodilla. Silueta de sirena con expansión inferior marcada.",
  "Flapper": "Silueta recta, flecos, estilo años veinte. Caída tubular con movimiento en los bordes, cintura baja.",
  "Sheath": "Recto y elegante, hasta la rodilla. Corte tubular que no marca cintura excesivamente, línea limpia.",
  "Vestido Polo": "Cuello polo con botones cortos. Estilo casual-vestir, manga corta, caída recta o ligeramente entallada.",
  "Slip": "Tirantes finos, estilo lencería. Tejido suave y fluido, escote en V o cuadrado, caída natural del cuerpo.",
  "Strapless": "Sin tirantes, sujeción interna. Expone hombros y clavículas, silueta definida por el corsé interno o elástico.",
  "Shift": "Recto y suelto, sin marcar cintura. Silueta de tubo recto desde hombros a muslos, comodidad y movimiento.",
  "Tunic": "Holgado y alargado, estilo túnica. Caída por encima de la rodilla o media pierna, corte amplio.",
  "Tent": "Se expande en A desde los hombros. Silueta triangular invertida, amplio en la base sin definición de cintura.",
  "Drop Waisted": "Cintura baja a la altura de la cadera. El punto de unión entre bodice y falda cae sobre la pelvis.",
  "Wrap": "Surplice — Envolvente con lazo, escote en V. Cruzado frontal que se cierra con nudo lateral o cinturón.",
  "Kimono": "Mangas anchas, cierre envolvente. Corte tradicional japonés, caída recta, cintura con obi o cinturón ancho.",
  "Dolman": "Mangas murciélago, caída fluida. Hombros caídos sin costura definida, silueta amplia en la parte superior.",
  "Bubble": "Balloon — Dobladillo recogido, efecto globo. Volumen artificial en la falda por medio de recogidos internos.",
  "Shirtwaist": "Estilo camisa arriba, falda completa. Cierre de botones frontal, cuello camisero, cintura definida.",
  "Halter": "Se sujeta en la nuca, espalda descubierta. Tirantes que se cruzan o anudan en el cuello, escote profundo.",
  "Bustier": "Cuerpo estructurado tipo corsé. Varillas internas, escote pronunciado, cintura muy definida.",
  "Maxi": "Larga hasta el tobillo. Sofisticada. Caída continua que oculta la pierna completamente.",
  "Bouffant": "Pouf — Falda muy voluminosa, forma de campana. Estructura interna o crinolina que sostiene el volumen.",
  "One Shoulder": "Un solo tirante, hombro descubierto. Asimetría en el escote, sujeción en un solo lado.",
  "Mulet": "Más corto adelante, largo atrás. Cola posterior visible desde la rodilla hacia abajo, frente corta.",
  "Handkerchief": "Dobladillo con picos irregulares. Caída asimétrica en puntas que imita el pañuelo.",
  "Jacket Dress": "Estilo blazer con longitud de vestido. Solapas, botones frontales, corte entallado de chaqueta extendida.",
  "Babydoll": "Corto bajo el busto, caída holgada. Corte empire con falda suelta y corta, aire juvenil.",
  "Apron / Jumper": "Estilo pichi o peto, tirantes anchos. Se usa sobre blusa, abertura frontal o lateral.",
  "Sundress": "Ligero y fresco, tirantes finos. Tejido veraniego, escote redondo o cuadrado, falda fluida.",
  "Empire": "Cintura bajo el busto, falda fluida. Unión alta que alarga la silueta inferior, caída libre.",
  "Pleat": "Tela plisada en todo el vestido. Pliegues estructurados verticales que aportan rigidez y movimiento.",
  "Princess": "Costuras verticales que estilizan. Ajuste mediante paneles sin cintura definida, silueta alargada.",
  "Petal": "Capas que imitan pétalos de flor. Volantes superpuestos en forma de pétalo, textura tridimensional.",
  "Body Clásico": "De tirantes finos, cobertura de torso y entrepierna. Base para combinar con otras prendas.",
  "Body Manga Larga": "Cobertura total de brazos. Manga larga ajustada, escote variable.",
  "Body Escote Profundo": "Escote pronunciado en V o cuadrado. Exposición marcada de pecho o espalda.",
  "Body Off": "Shoulder — Hombros descubiertos. Borde superior que cae por debajo de la línea del hombro.",
  "Body Halter": "Se sujeta en la nuca. Espalda descubierta, tirantes que se unen en el cuello.",
  "Body Espalda Abierta": "Espalda descubierta total o parcialmente. Apertura posterior que puede llegar a la cintura.",
  "Leotardo": "Estilo deportivo o danza. Cobertura de torso, piernas libres, tejido elástico opaco.",
  "Unitardo": "Cobertura completa de piernas. Prenda de una pieza que cubre desde el cuello hasta los tobillos.",
  "Body Malla": "Transparente o semitransparente. Tejido de red o tul, cobertura ilusoria.",
  "Jumpsuit Casual": "Cómodo y funcional. Pantalón y camisa o top unidos, corte relajado, cintura con cordón o elástico.",
  "Jumpsuit Elegante": "Corte alto, formal. Silueta entallada, escote definido, tela de calidad, aire de vestir.",
  "Jumpsuit Halter": "Escote halter, espalda descubierta. Tirantes en nuca, silueta de pierna ancha o recta.",
  "Topcoat": "Clásico y elegante. Corte recto hasta media pierna o más. Silueta formal con solapas definidas y estructura de sastrería.",
  "Raglan": "Mangas raglan para mayor comodidad y movilidad. La costura de hombro se desplaza hacia el cuello, permitiendo amplitud en la parte superior del brazo.",
  "Princess Swing": "Faldón amplio y fluido que da volumen y movimiento. Corte princesa con paneles que se ensanchan desde la cintura hacia el bajo.",
  "Recto Silueta Limpia": "Corte recto y minimalista, línea impecable desde el hombro hasta el borde inferior. Sin adornos estructurales superfluos.",
  "Tailcoat": "Falda trasera larga y abertura frontal. Formal y sofisticado. Silueta de frac con cola posterior visible.",
  "Tailcoat / Frac Sin Mangas": "Frac o tailcoat formal sin mangas con faldones posteriores largos y abertura frontal. Luce el chaleco o camisa interior manteniendo la silueta de gala clásica.",
  "Chaleco de Vestir / Sastrería": "Chaleco formal entallado sin mangas con botonadura frontal, bolsillos de vivo y trabilla trasera de ajuste para superponer en capas sobre camisas o prendas superiores.",
  "Chaleco de Vestir": "Chaleco formal entallado sin mangas con botonadura frontal, bolsillos de vivo y trabilla trasera de ajuste para superponer en capas sobre camisas o prendas superiores.",
  "Carrera de Botones": "Describe la disposición y la línea en la que se colocan los botones a lo largo de la tapeta. Esta línea determina la cantidad y la distribución de botones en el cuello, pechera y cierre frontal.",
  "Transparencias / Tela Translúcida": "Inserciones de gasa, tul, organza o seda translúcida que revelan con sutileza y elegancia la piel o capas textiles inferiores.",
  "Transparencias": "Paneles e inserciones de tejidos semitransparentes que aportan ligereza y sugerencia visual.",
  "Tela Translúcida": "Tejido etéreo y vaporoso que deja pasar la luz y expone contornos con refinamiento.",
  "Loden Coat": "Clásico europeo, largo y resistente al clima frío. Tejido pesado de origen alpino, corte amplio para capas internas.",
  "Balmacaán": "Cuello amplio y cierre cubierto. Estilo sobrio y refinado. Origen en la confección escocesa, corte recto con hombros caídos sutiles.",
  "Chanel": "Corte recto y corto, acabados estructurados y detallados. Bordes en cadena o vivo, solapas simétricas, aire de alta costura.",
  "Cropped Chanel": "Versión corta y elegante. Ideal para looks pulidos. Terminación por encima de la línea de cintura.",
  "Bolero": "Muy corta, cubre solo hombros y parte alta de la espalda. Manga corta o tres cuartos, corte circular.",
  "Cardigan": "Abierta al frente con botones o cierre. Tejido suave y versátil. Silueta relajada, posible uso como capa intermedia.",
  "Bomber": "Corte con puños y cintura elástica. Estilo deportivo. Origen militar, ahora urbano, con volumen controlado en el torso.",
  "Biker / Motera": "Cierre diagonal y solapas con broches. Estilo rebelde. Cuero o sintético, ajuste entallado, protección visual.",
  "Denim Jacket": "Clásica de mezclilla. Corte slim y ajustado, resistente y casual. Costuras contrastantes, botones metálicos.",
  "Lean Jacket": "Corte slim y ajustado, moderna y urbana. Silueta ceñida que sigue la línea del torso sin exceso de tejido.",
  "Parka": "Larga y funcional, con capucha y bolsillos amplios. Diseño de origen ártico, corte amplio para aislamiento.",
  "Trench Coat": "Cruzada, con cinturón y solapas anchas. Icónica y atemporal. Tejido de gabardina resistente al agua, doble botonadura.",
  "Puffer / Acolchada": "Relleno térmico acolchado. Ligera, cálida y volumétrica. Compartimentos cosidos que contienen plumón o fibra sintética.",
  "Abrigo de Piel / Faux Fur": "Textura esponjosa y lujosa. Aporta volumen y calidez. Pelaje denso, corte amplio, sensación táctil prominente.",
  "Straight": "Corte recto. Ancho uniforme desde la cadera hasta el bajo. Silueta limpia y vertical sin estrechamiento.",
  "Pintucks": "Costuras verticales al frente. Pliegues cosidos que alargan visualmente la pierna y aportan rigidez formal.",
  "Sailor": "Botones decorativos en los laterales de la cintura. Corte amplio con origen náutico, caída estructurada y plana.",
  "Palazzo": "Pierna muy ancha desde la cadera. Caída fluida y amplia que genera silueta de falda en movimiento.",
  "Wide Leg": "Pierna ancha con caída recta y estructurada. Ancho moderado, línea vertical continua desde la cadera sin contacto con la pierna.",
  "Falda Pantalón": "Apariencia de falda larga con la comodidad de un pantalón. Volumen exterior que oculta la separación de piernas.",
  "Pocket Cargo": "Bolsillos laterales con solapas. Estilo utilitario y práctico, tejido resistente, aire de campo o trabajo.",
  "Bush": "Bolsillos frontales profundos. Resistente y rudo. Corte recto amplio con alforzas o pliegues funcionales.",
  "Skinny": "Ajuste ceñido total desde la cintura hasta el tobillo. Silueta que sigue la anatomía de la pierna sin holgura.",
  "Boot": "Cut Flared — Ajustado en muslos y se abre desde la rodilla hacia abajo. Expansión inferior que permite cubrir el calzado.",
  "Stirrup": "Con estribo bajo el pie para mantener la prenda en su lugar. Ajuste ceñido con sujeción inferior activa.",
  "Cuffed": "Bajo con puño o vuelta. Remate estructurado en el tobillo, estilo casual y relajado.",
  "Balloon Harem": "Volumen amplio con puños en tobillos. Cómodo y dramático. Silueta de globo que se concentra en la cadera y se cierra abajo.",
  "Zouave": "Tiro muy bajo y volumen amplio. Máxima libertad de movimiento. Corte histórico-militar con acumulación de tejido en el muslo.",
  "Jodhpurs": "Amplio en muslos y ceñido desde la rodilla hasta el tobillo. Diseño ecuestre, curva pronunciada en la zona superior de la pierna.",
  "Overall": "Peto con tirantes. Práctico y versátil para trabajo. Cobertura de torso y piernas con unión superior de peto.",
  "Mini": "Corta, por encima del muslo. Exposición máxima de pierna, silueta juvenil.",
  "Mini Plisada": "Pliegues pequeños. Estilo escolar o juvenil. Estructura de acordeón en longitud corta.",
  "Lápiz": "Ajustada al cuerpo. Elegante y formal. Silueta ceñida que sigue la curva de la cadera y muslo.",
  "Midi": "Largo a media pantorrilla. Clásica y versátil. Terminación entre la rodilla y el gemelo.",
  "Midi Plisada": "Pliegues verticales. Movimiento y elegancia. Estructura de acordeón en longitud media.",
  "A": "Line — En forma de A. Se ensancha hacia el bajo desde la cintura. Silueta triangular equilibrada.",
  "Círculo": "Muy amplia. Vuelo completo y femenino. Corte circular que maximiza el volumen al girar.",
  "Envolvente": "Cruzada al frente y ajustable. Abertura variable. Paneles superpuestos que se ciñen con lazo o botón.",
  "Pareo": "Anudada en la cintura. Ligera y fresca. Rectángulo de tela que se envuelve y sujeta lateralmente.",
  "Tul": "Capas de tul. Volumen y textura etérea. Superposición de velos transparentes que generan densidad visual.",
  "Maxi con Abertura": "Abertura alta lateral o frontal. Efecto elegante con exposición estratégica al caminar.",
  "Sirena": "Ajustada en caderas y se abre en el bajo. Efecto elegante. Silueta de cola de pez que se ensancha desde la rodilla.",
  "Plisada Larga": "Pliegues largos. Fluida y clásica. Estructura vertical que alarga la silueta en longitud completa.",
  "Godet": "Paneles triangulares que dan vuelo al caer. Inserciones que expanden el borde inferior sin aumentar el volumen en la cadera.",
  "Tul Capas": "Varias capas de tul. Volumen suave y romántico. Estratos de transparencia que crean profundidad.",
  "Cargo Skirt": "Bolsillos laterales. Estilo utilitario y moderno. Aplicaciones funcionales en longitud variable.",
  "Denim Skirt": "De mezclilla. Casual, resistente y atemporal. Tejido de sarga con costuras contrastantes.",
  "Asimétrica": "Largos irregulares. Diseño moderno y dinámico. Borde diagonal que rompe la horizontalidad.",
  "Globo": "Bajo abullonado. Volumen y originalidad. Expansión artificial en el borde inferior mediante recogido o estructura.",
  "Wedge Booties": "Tacón de cuña cómodo y estable. Plataforma continua desde el talón a la punta.",
  "Bondage Boots": "Hebillas y correas con actitud atrevida. Arnés de sujeción múltiple en el eje del pie.",
  "Gladiator Boots": "Tiras múltiples que suben por la pierna. Sujeción de cinturón segmentado.",
  "Timberland Boots": "Resistentes, casuales y funcionales. Suela gruesa de tractor, construcción robusta.",
  "Ugg Boots": "Suaves, cálidas y acolchadas. Interior de borrego, exterior de ante.",
  "Cowboy Boots": "Punta afilada y tacón inclinado clásico. Bordados, caña media-alta.",
  "Wellington Boots": "Impermeables, ideales para lluvia. Caucho, caña alta, sin tacón.",
  "Knee High Boots": "Hasta la rodilla, elegantes y alargadas. Tacón medio-alto, ajuste en la pantorrilla.",
  "Thigh High Boots": "Por encima de la rodilla, seductoras. Ajuste en el muslo, tacón variable.",
  "Ankle Boots": "Llegan al tobillo, versátiles y chic. Caña corta, cierre lateral o trasero.",
  "Slingbacks": "Tira trasera que sujeta el talón. Puntera descubierta o cerrada.",
  "Mules": "Sin talón ni sujeción trasera. Calzado de enfiler, tacón variable.",
  "Clogs": "De madera o imitación, robustos y únicos. Suela rígida, tacón grueso.",
  "Gladiators": "Sandalias de tiras frescas y abiertas. Sujeción hasta la pantorrilla o tobillo.",
  "Lita": "Plataforma gruesa con cordones. Estilo gótico o alternativo, tacón bloque.",
  "Crocs": "Cómodos, ligeros y ventilados. Material sintético foam, orificios superiores.",
  "Chelsea Boots": "Elásticos laterales, sin cordones. Caña media, tacón bajo, punta redondeada.",
  "Dr. Martens": "Icónicos, resistentes y duraderos. Suela de aire amarilla, 8 ojetes.",
  "Platform Sandal": "Plataforma alta para estilar. Suela gruesa, tiras mínimas.",
  "Strappy Heel": "Tiras finas que delicadamente sujetan. Tacón aguja o bloque, múltiples correas.",
  "Cadena simple": "Clásico y versátil. Eslabones finos o medianos, cierre posterior discreto.",
  "Colgante": "Piedra central o símbolo que destaca. Cadena soporte con elemento focal suspendido.",
  "Multicapa": "Varias capas de cadena a diferentes alturas. Efecto escalonado en el pecho.",
  "Gargantilla negra": "Encaje o terciopelo. Estética gótica y elegante. Ajuste ceñido al cuello.",
  "Choker con anillo": "Aro central metálico. Estilo alternativo o punk. Sujeción con hebilla o cordón.",
  "Perlas": "Elegante y sofisticado. Clásico y refinado. Esferas uniformes en hilo continuo.",
  "Corazón": "Colgante romántico y dulce. Forma cardíaca, aire juvenil o sentimental.",
  "Cadena gruesa": "Llamativo y urbano. Eslabones grandes de peso visual, estilo rudo y moderno.",
  "Cuero con dije": "Natural y masculino. Cordón o banda de cuero con elemento colgante.",
  "Amuleto": "Protección o poder. Toque místico. Símbolo grabado o figura en relieve.",
  "Delgado": "Minimalista y sutil. Banda fina sin adornos o con detalle mínimo.",
  "Signet": "Sello o inicial. Clásico y elegante. Superficie plana grabada, heráldico.",
  "Piedra preciosa": "Piedra central. Elegante y llamativo. Engaste elevado, solitario.",
  "Múltiple": "Varias piezas apiladas. Estilo moderno. Combinación de finos en diferentes alturas.",
  "Cadena": "Decorativo y urbano. Toque punk. Eslabones que funcionan como banda.",
  "Gótico": "Intrincado y oscuro. Estética dramática. Filigrana negra, motivos barrocos sombríos.",
  "Nudillo": "Cubre varios falanges. Impacto y actitud. Armadura segmentada para los dedos.",
  "Abiertos": "Ajustable y creativo. Diseño personalizado. Extremos que no se cierran, formas orgánicas.",
  "Lazo": "Femenino y dulce. Estilo romántico. Cinta anudada, colgante o ceñida.",
  "Cuero con pinchos": "Rebelde y punk. Apariencia agresiva. Tachuelas o púas metálicas sobre banda.",
  "Cadena con cruz": "Religioso o gótico. Simbólico y sobrio. Crucifijo colgante o integrado.",
  "Encaje victoriano": "Elegante y vintage. Detalles delicados. Patrón floral calado, cierre trasero.",
  "Metálica": "Futurista o armadura. Estilo imponente. Bandas rígidas de metal, posiblemente con tornillos.",
  "Cortos": "Formales o clásicos. Elegantes y discretos. Cobertura hasta la muñeca.",
  "Largos": "Hasta el codo o más. Elegancia y dramatismo. Cobertura extendida del antebrazo.",
  "De cuero": "Rudos y resistentes. Estilo masculino. Textura granulada, costuras expuestas.",
  "Sin dedos": "Prácticos y casuales. Estilo rebelde. Palma cubierta, falanges expuestas.",
  "Encaje": "Delicados y femeninos. Estética romántica. Transparencia en el dorso, ajuste fino.",
  "Armadura": "Protección y poder. Fantasía o medieval. Placas metálicas articuladas sobre mano.",
  "Mitones": "Cálidos y cómodos. Casuales o lindos. Sin separación de pulgar o dedos, borde cerrado.",
  "Deportivos": "Agarre y protección. Funcional. Refuerzos en palma, cierre de velcro en muñeca.",
  "Clásico": "Simple y funcional. Uso diario. Hebilla metálica estándar, banda uniforme.",
  "Doble hebilla": "Más ajuste y estilo. Detalles llamativos. Dos puntos de cierre frontales.",
  "Arnés de pecho": "Estilo alternativo. Resalta la silueta. Tiras cruzadas sobre torso.",
  "Táctico": "Funcional y militar. Utilitario. Bolsillos pequeños, hebilla de liberación rápida.",
  "Faja / Cintura": "Fluido y elegante. Inspiración oriental. Anudado, sin hebilla rígida.",
  "Con argollas": "Industrial y edgy. Estilo colgante. Aros metálicos para sujeción o decoración.",
  "Cadena múltiple": "Impactante y punk. Decorativo. Varias cadenas paralelas que caen desde la cintura.",
  "Corbata clásica": "Formal y refinada. Negocios y etiqueta. Nudo estándar, caída larga.",
  "Corbata delgada": "Moderna y estilizada. Elegante casual. Ancho reducido, aire contemporáneo.",
  "Corbata mono": "Vintage y elegante. Estilo victoriano. Nudo amplio en cinta ancha.",
  "Corbata lazo": "Suave y decorativo. Estética dulce. Cinta anudada en lazo, caída libre.",
  "Moño grande": "Impacto y dramatismo. Estilo lolita. Volumen amplio, proporción dominante.",
  "Moño pequeño": "Discreto y delicado. Tierno y sutil. Proporción reducida, detalle fino.",
  "Moño escolar": "Uniforme y juvenil. Estética académica. Línea recta, nudo simétrico.",
  "Moño de cuello": "Inspiración clásica. Formal. Preanudado con banda ajustable.",
  "Gorra": "Casual y urbano. Deportivo. Visera rígida, ajuste trasero.",
  "Boina": "Artístico y retro. Europeo clásico. Tejido plano, inclinación lateral.",
  "Sombrero Fedora": "Elegante y misterioso. Estilo detective. Ala media, copa abollada.",
  "Sombrero de copa": "Formal y antiguo. Época victoriana. Copa alta y cilíndrica, rigidez estructural.",
  "Capucha": "Práctico y misterioso. Aire misterioso. Tejido flexible, cobertura completa de cabeza.",
  "Diadema": "Femenino y delicado. Detalles refinados. Arco rígido o flexible, adorno frontal.",
  "Tocado floral": "Romántico y natural. Estilo bohemio. Flores artificiales o naturales integradas.",
  "Casco / Headset": "Tecnológico y moderno. Estilo futurista. Protector rígido o auriculares integrados.",
  "Gafas redondas": "Intelectual y vintage. Estilo clásico. Aros circulares, montura metálica o pasta.",
  "Gafas": "Serio y profesional. Moderno. Montura rectangular o cuadrada, líneas limpias.",
  "Gafas de sol": "Cool y reservado. Protección y estilo. Lentes oscuras, montura variable.",
  "Monóculo": "Noble y antiguo. Distinción. Lente única con sujeción facial o cadenilla.",
  "Parche ocular": "Discreto y rebelde. Toque moderno. Cubierta de cuero o tela sobre un ojo.",
  "Arete largo": "Elegante y llamativo. Aporta movimiento. Colgante que oscila con la cabeza.",
  "Aro": "Clásico y versátil. Masculino o femenino. Círculo continuo o con cierre.",
  "Ear cuff": "Sin perforación. Moderno y estético. Clip que se ajusta al borde auricular.",
  "Cadena para oreja": "Una o dos perforaciones. Estilo punk o gótico. Cadena que une lóbulo a cartílago superior.",
  "Ceja": "Discreto y rebelde. Toque moderno. Barra horizontal sobre el arco superciliar.",
  "Labio": "Sensual y decorativo. Estética urbana. Labret en el centro o Monroe lateral.",
  "Nariz": "Sutil y romántico. Aro o stud. Septum o ala nasal, pequeño y discreto.",
  "Lengua": "Audaz y enigmático. Estilo extremo. Barra con bolas en los extremos, oculta al hablar.",
  "Cadena para pantalón": "Urbano y punk. Funcional y estético. Sujeción de bolsillo a cinturón.",
  "Cadena para bolsillo": "Delicado y decorativo. Toque elegante. Cadena fina con adorno.",
  "Broche / Alfiler": "Decorativo y funcional. Detalles únicos. Prendedor con cierre de seguridad.",
  "Charms / Dijes": "Personalización. Simbólico y único. Colgantes para pulseras o cadenas.",
  "Ligas para piernas": "Estética alternativa o sexy. Banda elástica en el muslo, con o sin adorno.",
  "Pulseras / Brazaletes": "Variedad de estilos. Metal, cuero, tela. Muñequera rígida o flexible.",
  "Bandolera": "Práctico y casual. Uso diario. Correa larga cruzada, tamaño mediano.",
  "Mochila": "Funcional y cómoda. Escolar o urbana. Correas dobles, compartimentos múltiples.",
  "Bolso de mano": "Elegante y formal. Eventos y salidas. Asas cortas, estructura rígida.",
  "Clutch": "Pequeño y sofisticado. Minimalista. Sin asas, sujeción manual.",
  "Bolso táctico": "Resistente y útil. Estilo militar. Materiales sintéticos, múltiples bolsillos.",
  "Bolso de cadena": "Práctico y urbano. Elegante y moderno. Asa de cadena metálica.",
  "Medias transparentes": "Jóvenes y finas. Estilo escolar. Denier bajo, cobertura parcial.",
  "Medias de encaje": "Elegantes y femeninas. Básicas y sensuales. Patrón calado en pierna o borde.",
  "Medias de red": "Atrevidas y arriesgadas. Estilo alternativo. Malla de diamantes o cuadrícula.",
  "Medias altas": "Clásicas y elegantes. Estilo clásico. Caña larga, sujeción por elástico o liguero.",
  "Calcetines cortos": "Uso diario. Casuales. Tobilleros, cobertura mínima.",
  "Calcetines largos": "Deportivos y decorativos. Funcionales. Caña que llega a la pantorrilla.",
  "Ligas": "Sensuales y decorativas. Sujeción de medias. Banda elástica con broche metálico.",
  "Portaligas": "Vintage y seductor. Estilo clásico. Cinturón con tirantes que sujetan las medias.",
  "Choker de cuero": "Minimalista y punk. Aro o hebilla. Banda rígida o flexible con cierre.",
  "Brazalete de brazo": "Decorativo y tribal. Estilo guerrero. Armband rígido o flexible en el bíceps.",
  "Cinta para el pelo": "Tierno y femenino. Estilo casual. Lazo o diadema suave.",
  "Pasador": "Elegante y delicado. Inspiración oriental. Horquilla decorativa, sujeción parcial.",
  "Abanico": "Protección y estilo. Toque teatral. Varillas plegables, tela o papel.",
  "Paraguas / Sombrilla": "Elegante y vintage. Funcional y estético. Estructura radial, mango curvo.",
  "Reloj de bolsillo": "Antiguo y distinguido. Funcional y estético. Cadena de chaleco, tapa con bisagra.",
  "Pañuelo / Bufanda": "Aporta color y estilo. Versátil. Tejido ligero o pesado, anudado o suelto."
};

export { getWardrobeOptions } from './data/wardrobeOptionEngine';
export type { WardrobeOptionsSuite } from './data/wardrobeOptionEngine';

// ==========================================
// MAQUILLAJE & ESTÉTICA (MAKEUP CONFIGURATION)
// ==========================================

export const LIPSTICK_STYLES = [
  'Ninguno / Labios Naturales',
  'L1 Tinte Ligero Natural (Lip Tint)',
  'L2 Labial Mate Clásico',
  'L3 Labial Satinado / Cremoso',
  'L4 Gloss Hidratado / Brillo de Labios Espejo',
  'L5 Degradado Coreano (Ombré Lips)',
  'L6 Delineado Oscuro con Centro Claro (Gothic / 90s)',
  'L7 Labial Metalizado / Cromado',
  'L8 Glitter / Escarcha Brillante',
  'L9 Bicolor Dividido (Split Lips)'
];

export const LIPSTICK_COLORS = [
  'Nude',
  'Rojo carmesí',
  'Borgoña',
  'Rosa pastel',
  'Fucsia',
  'Coral',
  'Ciruela',
  'Marrón',
  'Negro',
  'Dorado',
  'Azul',
  'Púrpura'
];

export const LIPSTICK_FINISHES = [
  'Mate',
  'Satinado',
  'Glossy / Brillo',
  'Perlado',
  'Metálico'
];

export const BLUSH_STYLES = [
  'Ninguno',
  'B1 Suave en Manzanas de las Mejillas (Clásico)',
  'B2 Estilo Igari / Resaca Tierna (Bajo los Ojos)',
  'B3 Sun-Kissed (Puente de la Nariz y Mejillas)',
  'B4 Pómulos Esculpidos / Contorno Alto (Editorial)',
  'B5 Draping hacia las Sienes (Editorial / Fantasía)',
  'B6 Rayitas Anime / Chibi Blush',
  'B7 Degradado Mágico / Galáctico'
];

export const BLUSH_COLORS = [
  'Rosa pastel',
  'Melocotón',
  'Frambuesa',
  'Albaricoque',
  'Malva',
  'Dorado',
  'Carmesí',
  'Púrpura'
];

export const NAIL_STYLES = [
  'Ninguno / Uñas Naturales',
  'N1 Cortas Cuadradas Limpias',
  'N2 Almendradas / Clásicas Elegantes',
  'N3 Stiletto / Largas y Afiladas',
  'N4 Coffin / Ballerina Esculpidas',
  'N5 Garras Afiladas de Fantasía',
  'N6 Manicura Francesa (Punta Contrastante)',
  'N7 Degradado Ombré (Baby Boomer)',
  'N8 Nail Art con Gemas / Pedrería',
  'N9 Con Diseños Rúnicos / Telarañas / Líneas'
];

export const NAIL_COLORS = [
  'Negro',
  'Rojo carmesí',
  'Blanco',
  'Rosa nude',
  'Borgoña',
  'Azul marino',
  'Dorado',
  'Plata',
  'Verde esmeralda',
  'Púrpura',
  'Neón',
  'Holográfico',
  'Bicolor'
];

export const NAIL_FINISHES = [
  'Gel Brillante / Ultra Glossy',
  'Mate Aterciopelado',
  'Purpurina / Glitter Sparkle',
  'Cromado Espejo',
  'Iridiscente / Ojo de Gato (Cat Eye)'
];

export const EYESHADOW_STYLES = [
  'Ninguno / Natural',
  'E1 Sombra Suave Monocromática',
  'E2 Smokey Eye Negro / Ahumado Dramático',
  'E3 Degradado Atardecer / Sunset Glow',
  'E4 Cut Crease Definido',
  'E5 Halo Eyes (Centro Luminoso)',
  'E6 Fox Eye / Alargado Felino',
  'E7 Purpurina / Glitter en Párpados',
  'E8 Sombra Gráfica Editorial',
  'E9 Ojeras Marcadas / Dark Circles (Estilo Cansado / Ojeras Góticas)',
  'E10 Ojeras Suaves / Sombra de Fatiga Seductora'
];

export const EYESHADOW_COLORS = [
  'Nude',
  'Negro',
  'Rojo carmesí',
  'Rosa pastel',
  'Dorado',
  'Púrpura',
  'Azul',
  'Verde esmeralda',
  'Plata',
  'Neón'
];

export const EYELINER_MAKEUP_STYLES = [
  'Ninguno',
  'D1 Delineado Fino Clásico',
  'D2 Cat-Eye Alado Pronunciado',
  'D3 Delineado Gráfico Doble',
  'D4 Delineado Gótico Grueso',
  'D5 Delineado Blanco / Fantasía',
  'D6 Con Pestañas Anime Spiky Definidas',
  'D7 Delineado Egipcio / Lagrimal Marcado',
  'D8 Delineado con Ojeras Difuminadas / Estilo Grunge'
];

export const FACE_ACCENTS = [
  'Ninguno',
  'A1 Iluminador Glass Skin (Punta de la Nariz y Pómulos)',
  'A2 Brillo Astral / Purpurina en Sienes y Pómulos',
  'A3 Lágrimas de Purpurina / Cristales Bajo los Ojos',
  'A4 Pecas Falsas Doradas / Brillantes',
  'A5 Perlas y Gemas Faciales Adhesivas',
  'A6 Estrellitas / Corazones Estampados en Mejillas'
];

export interface MakeupPreset {
  id: string;
  name: string;
  emoji: string;
  description: string;
  config: {
    lipstickStyle: string;
    lipstickColor: string;
    lipstickFinish: string;
    blushStyle: string;
    blushColor: string;
    nailStyle: string;
    nailColor: string;
    nailFinish: string;
    eyeshadowStyle: string;
    eyeshadowColor: string;
    eyelinerStyle: string;
    faceAccent: string;
  };
}

export const MAKEUP_PRESETS: MakeupPreset[] = [
  {
    id: 'clean_natural',
    name: 'Natural / Sin Maquillaje',
    emoji: '🌿',
    description: 'Rostro limpio al natural sin cosméticos aplicados',
    config: {
      lipstickStyle: 'Ninguno / Labios Naturales',
      lipstickColor: 'Natural / Nude Rosado',
      lipstickFinish: 'Satinado / Suave',
      blushStyle: 'Ninguno',
      blushColor: 'Rosa Suave / Pastel',
      nailStyle: 'Ninguno / Uñas Naturales',
      nailColor: 'Rosa Nude / Cuarzo Translúcido',
      nailFinish: 'Gel Brillante / Ultra Glossy',
      eyeshadowStyle: 'Ninguno / Natural',
      eyeshadowColor: 'Tonos Tierra / Nude Neutro',
      eyelinerStyle: 'Ninguno',
      faceAccent: 'Ninguno'
    }
  },
  {
    id: 'kpop_idol',
    name: 'Idol Glow / K-Pop',
    emoji: '🌸',
    description: 'Labios degradados, mejillas tiernas estilo Igari e iluminador glass skin',
    config: {
      lipstickStyle: 'L5 Degradado Coreano (Ombré Lips)',
      lipstickColor: 'Rosa Pastel / Sakura',
      lipstickFinish: 'Glossy / Efecto Espejo',
      blushStyle: 'B2 Estilo Igari / Resaca Tierna (Bajo los Ojos)',
      blushColor: 'Melocotón / Coral Dulce',
      nailStyle: 'N2 Almendradas / Clásicas Elegantes',
      nailColor: 'Rosa Nude / Cuarzo Translúcido',
      nailFinish: 'Gel Brillante / Ultra Glossy',
      eyeshadowStyle: 'E1 Sombra Suave Monocromática',
      eyeshadowColor: 'Rosa Pastel / Sakura',
      eyelinerStyle: 'D1 Delineado Fino Clásico',
      faceAccent: 'A1 Iluminador Glass Skin (Punta de la Nariz y Pómulos)'
    }
  },
  {
    id: 'gothic_vamp',
    name: 'Gótico / Vamp Dark',
    emoji: '🖤',
    description: 'Labial mate negro azabache, smokey eye profundo y uñas stiletto oscuras',
    config: {
      lipstickStyle: 'L2 Labial Mate Clásico',
      lipstickColor: 'Negro Gótico / Azabache',
      lipstickFinish: 'Mate Aterciopelado (Velvet)',
      blushStyle: 'B4 Pómulos Esculpidos / Contorno Alto (Editorial)',
      blushColor: 'Malva / Lavanda Romántico',
      nailStyle: 'N3 Stiletto / Largas y Afiladas',
      nailColor: 'Negro Azabache Esmaltado',
      nailFinish: 'Gel Brillante / Ultra Glossy',
      eyeshadowStyle: 'E2 Smokey Eye Negro / Ahumado Dramático',
      eyeshadowColor: 'Negro Carbón / Ahumado',
      eyelinerStyle: 'D4 Delineado Gótico Grueso',
      faceAccent: 'Ninguno'
    }
  },
  {
    id: 'femme_fatale',
    name: 'Femme Fatale / Carmesí',
    emoji: '💋',
    description: 'Labial carmesí de alta costura, cat-eye alado y manicura clásica roja',
    config: {
      lipstickStyle: 'L3 Labial Satinado / Cremoso',
      lipstickColor: 'Rojo Carmesí Clásico',
      lipstickFinish: 'Satinado / Suave',
      blushStyle: 'B4 Pómulos Esculpidos / Contorno Alto (Editorial)',
      blushColor: 'Carmesí Intenso / Teatral',
      nailStyle: 'N2 Almendradas / Clásicas Elegantes',
      nailColor: 'Rojo Carmesí / Pasión',
      nailFinish: 'Gel Brillante / Ultra Glossy',
      eyeshadowStyle: 'E6 Fox Eye / Alargado Felino',
      eyeshadowColor: 'Tonos Tierra / Nude Neutro',
      eyelinerStyle: 'D2 Cat-Eye Alado Pronunciado',
      faceAccent: 'A1 Iluminador Glass Skin (Punta de la Nariz y Pómulos)'
    }
  },
  {
    id: 'cyberpunk_neon',
    name: 'Cyberpunk / Neón Glow',
    emoji: '⚡',
    description: 'Labial metalizado fucsia, delineado gráfico doble y uñas cromadas neón',
    config: {
      lipstickStyle: 'L7 Labial Metalizado / Cromado',
      lipstickColor: 'Rosa Fucsia / Neón',
      lipstickFinish: 'Metálico Cromado',
      blushStyle: 'B5 Draping hacia las Sienes (Editorial / Fantasía)',
      blushColor: 'Púrpura Místico / Fantasía',
      nailStyle: 'N4 Coffin / Ballerina Esculpidas',
      nailColor: 'Neón Cyberpunk / Lima Neón',
      nailFinish: 'Cromado Espejo',
      eyeshadowStyle: 'E8 Sombra Gráfica Editorial',
      eyeshadowColor: 'Neón Cyberpunk Bicolor',
      eyelinerStyle: 'D3 Delineado Gráfico Doble',
      faceAccent: 'A2 Brillo Astral / Purpurina en Sienes y Pómulos'
    }
  },
  {
    id: 'fantasy_astral',
    name: 'Fantasía Astral / Élfico',
    emoji: '✨',
    description: 'Glitter dorado, halo eyes centelleantes, pecas de oro y garras doradas',
    config: {
      lipstickStyle: 'L8 Glitter / Escarcha Brillante',
      lipstickColor: 'Dorado Metálico',
      lipstickFinish: 'Brillo Perlado (Shimmer)',
      blushStyle: 'B7 Degradado Mágico / Galáctico',
      blushColor: 'Dorado Luminoso / Bronce',
      nailStyle: 'N5 Garras Afiladas de Fantasía',
      nailColor: 'Dorado Espejo / Oro Metálico',
      nailFinish: 'Iridiscente / Ojo de Gato (Cat Eye)',
      eyeshadowStyle: 'E5 Halo Eyes (Centro Luminoso)',
      eyeshadowColor: 'Dorado Solar / Cobre Brillante',
      eyelinerStyle: 'D5 Delineado Blanco / Fantasía',
      faceAccent: 'A4 Pecas Falsas Doradas / Brillantes'
    }
  },
  {
    id: 'anime_chibi',
    name: 'Anime Sweet / Chibi',
    emoji: '🎀',
    description: 'Rayitas de rubor anime en mejillas, gloss jugoso y pestañas de muñeca',
    config: {
      lipstickStyle: 'L4 Gloss Hidratado / Brillo de Labios Espejo',
      lipstickColor: 'Coral / Melocotón Cálido',
      lipstickFinish: 'Glossy / Efecto Espejo',
      blushStyle: 'B6 Rayitas Anime / Chibi Blush',
      blushColor: 'Rosa Suave / Pastel',
      nailStyle: 'N1 Cortas Cuadradas Limpias',
      nailColor: 'Rosa Nude / Cuarzo Translúcido',
      nailFinish: 'Gel Brillante / Ultra Glossy',
      eyeshadowStyle: 'E1 Sombra Suave Monocromática',
      eyeshadowColor: 'Rosa Pastel / Sakura',
      eyelinerStyle: 'D6 Con Pestañas Anime Spiky Definidas',
      faceAccent: 'A6 Estrellitas / Corazones Estampados en Mejillas'
    }
  }
];

export const DEFAULT_MAKEUP_CONFIG = {
  lipstickStyle: 'Ninguno / Labios Naturales',
  lipstickColor: 'Natural / Nude Rosado',
  lipstickFinish: 'Satinado / Suave',
  blushStyle: 'Ninguno',
  blushColor: 'Rosa Suave / Pastel',
  nailStyle: 'Ninguno / Uñas Naturales',
  nailColor: 'Rosa Nude / Cuarzo Translúcido',
  nailFinish: 'Gel Brillante / Ultra Glossy',
  eyeshadowStyle: 'Ninguno / Natural',
  eyeshadowColor: 'Tonos Tierra / Nude Neutro',
  eyelinerStyle: 'Ninguno',
  faceAccent: 'Ninguno'
};

// ==========================================
// 5.1 RELACIONES & 5.4 PERSONALIZACIÓN AVANZADA
// ==========================================

export const RELATIONSHIP_TYPES = [
  'Versión Alterna: Rol/Vestuario',
  'Versión Alterna: Futuro',
  'Versión Alterna: Pasado',
  'Sirviente → Maestro (El objetivo es mi Amo / Maestro / Señor)',
  'Maestro → Sirviente (El objetivo es mi Sirviente / Mayordomo / Lacayo)',
  'Mentor/a → Aprendiz (El objetivo es mi Alumno / Pupilo)',
  'Aprendiz → Mentor/a (El objetivo es mi Maestro / Mentor)',
  'Compañero/a de Armas / Igual Rango',
  'Amigo/a Íntimo/a & Aliado/a de Confianza',
  'Rival Jurado / Competidor Directo',
  'Superior / Comandante Oficial',
  'Subordinado/a / Bajo Mi Mando',
  'Protector/a Devoto/a → Protegido/a',
  'Interés Romántico / Vínculo Afectivo',
  'Némesis / Enemigo Mortal',
  'Hermano/a / Pariente de Sangre',
  'Pacto Oscuro / Vínculo de Almas',
  'Deudor/a por Deuda de Vida',
  'Amigo/a de la Infancia',
  'Antiguo/a Amigo/a Distanciado/a',
  'Colega de Gremio / Negocios',
  // Oscuras / Dark & Edgy
  'Amo/a Dominante ↔ Mascota / Juguete Consentido/a',
  'Obsesión Yandere (Posesión Absoluta: jamás permitiré que nadie te toque)',
  'Pacto de Sangre / Vínculo Demoníaco Indisoluble',
  'Relación Tóxica & Codependencia Destructiva',
  'Verdugo / Torturador ↔ Prisionero/a de Guerra Fascinante',
  // Modernas & Cyberpunk
  'Netrunner Hacker ↔ Operador Táctico de Enlace en Vivo',
  'Socio/a de Contrabando Urbano / Cómplice de Fixer Callejero',
  'Creador/a Cibernético ↔ Androide de Combate / Guardaespaldas Biónico',
  // Provocativas & Sensuales
  'Vínculo de Placer y Seducción / Súcubo o Íncubo Tentador/a',
  'Rival Frenemies con Alta Tensión Sexual y Deseo Prohibido',
  'Cortesana / Concubina de Confianza ↔ Protector Aristócrata',
  // Anime & Gachas
  'Invocador/a Master ↔ Unidad SSR Devota de Gacha',
  'Mesugaki Burlona ↔ Senpai / Blanco Favorito de Provocaciones',
  'Kouhai Consentida/o ↔ Senpai Protector/a',
  'Tsundere en Negación (Te insulta pero daría la vida por ti)'
];

export const FEELINGS_TOWARDS_SUGGESTIONS = [
  'Devoción absoluta, lealtad inquebrantable y gratitud profunda.',
  'Admiración respetuosa y deseo secreto de obtener su aprobación.',
  'Afecto fraternal sincero y necesidad imperiosa de proteger su bienestar.',
  'Rivalidad encendida, envidia contenida y fascinación competitiva.',
  'Rencor reprimido y desconfianza por agravios y promesas rotas del pasado.',
  'Temor reverencial y sumisión obligada ante su inmenso poder o estatus.',
  'Distancia emocional cautelosa y escepticismo ante sus verdaderas intenciones.',
  'Atracción magnética inconfesable con tensión latente en cada encuentro.',
  'Deuda de honor eterna tras haberle salvado la vida en el momento más oscuro.',
  'Compasión y tristeza al conocer la tragedia y soledad que carga sobre sus hombros.',
  // Oscuros
  'Obsesión posesiva asfixiante: si no puede tenerlo/a en exclusiva, prefiere destruirlo/a.',
  'Fascinación morbosa por su agonía o por quebrar su voluntad inquebrantable.',
  'Vínculo de almas sangriento donde el dolor de uno se refleja en el otro.',
  // Modernos & Cyber
  'Respeto pragmático callejero: la única persona en la megaciudad que jamás le vendió por créditos.',
  'Dependencia operativa absoluta: su interfaz sináptica se siente vacía sin su señal.',
  // Provocativos & Sensuales
  'Deseo ardiente y lujuria inconfesada enmascarada tras comentarios mordaces y coqueteos.',
  'Placer sádico en sonrojarlo/a, provocarlo/a e invadir su espacio personal hasta hacerlo perder el control.',
  'Sumisión voluptuosa: siente éxtasis al recibir sus órdenes y complacer sus caprichos.',
  // Anime & Gachas
  'Tsunderismo puro: irritación nerviosa en su presencia, disimulando un cariño desbordante.',
  'Devoción ciega de Servant / Invocación de Gacha: daría cada gota de maná por su victoria.',
  'Burlas incesantes («Za~ko»): placer travieso en ver su rostro enfurruñado y avergonzado.'
];

export const OPINION_ON_SUGGESTIONS = [
  '«Es la única persona en quien confío plenamente mi espalda y mis secretos.»',
  '«Demasiado ingenuo/a y bondadoso/a para el mundo real; necesita que alguien cuide sus pasos.»',
  '«Un talento formidable pero arrogante; un día tendré que darle una lección de humildad.»',
  '«Un líder formidable e intachable; su palabra es ley para mí.»',
  '«Una mente calculadora y peligrosa, a quien es mejor tener de aliada que de enemiga.»',
  '«Un estorbo testarudo, pero no soportaría ver que le ocurra una desgracia.»',
  '«El/la único/a digno/a de llamarse mi rival; sólo yo tengo derecho a superarle.»',
  '«Un alma rota que oculta su dolor tras una máscara de frialdad y disciplina.»',
  '«Un sirviente leal y eficiente que conoce su lugar, pero cuyo valor es incalculable.»',
  '«Mi señor/a legítimo/a, a cuyos dictámenes consagraré mi espada y mi existencia.»',
  // Oscuras
  '«Es mi presa más codiciada. Ningún otro cazador tiene derecho a arrancarle un solo suspiro.»',
  '«Un monstruo necesario. Mientras sus garras apunten hacia mis enemigos, no cuestionaré sus métodos sangrientos.»',
  // Modernas & Cyber
  '«El mejor netrunner del bajo mundo. Si el sistema colapsa, es la única llamada que haría.»',
  '«Un soldado corporativo programado para matar, pero con un fallo de fábrica llamado compasión.»',
  // Provocativas & Sensuales
  '«Una tentación andante vestida de pecado; cada segundo a su lado es un juego peligroso.»',
  '«Cree que tiene el control, pero un solo susurro mío en su oído lo desarma por completo.»',
  // Anime & Gachas
  '«¡Za~ko, za~ko! Es un senpai patético e indefenso, pero supongo que tendré que cuidarlo yo misma.»',
  '«Mi invocador/a predestinado/a. Mi linaje SSR y todo mi poder están a su entera disposición.»',
  '«¡N-No es como si me importara lo que le pase! Simplemente sería molesto tener que buscar otro rival.»'
];

export const INTERACTION_DYNAMICS_SUGGESTIONS = [
  'Trato formal y reverente, ocultando una profunda devoción o afecto contenido.',
  'Rivalidad feroz constante con pullas sarcásticas, pero lealtad ciega al combatir hombro a hombro.',
  'Protección sobreprotectora y paternal/maternal, vigilando discretamente sus espaldas.',
  'Desconfianza cautelosa y distancia profesional con miradas analíticas.',
  'Complicidad traviesa, bromas internas y sincronización intuitiva en batalla.',
  'Sumisión disciplinada y respuesta marcial inmediata a sus órdenes.',
  'Tensión electrizante con miradas desafiantes y silencios cargados de significado.',
  'Paciencia pedagógica tolerante, guiando con sabiduría y pequeños reproches constructivos.',
  'Frialdad calculada y resentimiento reprimido por una traición del pasado.',
  // Oscuras & Intensas
  'Contacto visual penetrante y silencios cargados de amenaza letal o posesión enfermiza.',
  'Dominación implacable: órdenes secas con exigencia de sumisión inmediata de rodillas.',
  // Modernas & Cyber
  'Comunicación rápida por ping holográfico cifrado, intercambiando datos tácticos y sarcasmo seco.',
  'Pacto de supervivencia callejera: espalda contra espalda en tiroteos de neón sin preguntas.',
  // Provocativas & Sensuales
  'Invasión constante del espacio personal, susurros al oído que erizan la piel y roces "accidentales".',
  'Juego de miradas ardientes a través de copas de vino o humo, desnudándolo/a con los ojos.',
  // Anime & Gachas
  'Provocación descarada y risitas burlonas («¡Za~ko!»), inclinándose hacia adelante con las manos en la cintura.',
  'Tsunderismo en combate: desvía golpes mortales dirigidos al objetivo y luego grita que fue por casualidad.'
];

export const VOICE_TONES = [
  'Grave, profundo y resonante',
  'Melifluo, seductor y persuasivo',
  'Áspero, curtido y ronco',
  'Suave, susurrante y aterciopelado',
  'Melódico, cantarín y armonioso',
  'Metálico / Sintético con leve eco digital o biónico',
  'Juvenil, vibrante y enérgico',
  'Frío, glacial y monocorde',
  'Gutural y amenazante',
  'Cristalino, etéreo y solemne',
  'Cálido, paternal y reconfortante',
  'Trémulo, tímido y contenido',
  // Oscuras / Dark & Edgy
  'Fascinantemente ronco, oscuro y sensual (Femme Fatale / Vampiro)',
  'Susurrante, jadeante y seductor con respiración cercana',
  'Grave, dominante y autoritario con peso de terciopelo pesado',
  'Teatral, profundo y dramático con eco espectral sombrío (Chuunibyou)',
  // Modernas & Cyberpunk
  'Sintético, filtrado con vocoder cibernético y leves glitches (Androide / Netrunner)',
  'Seco, sarcástico y desenfadado con cadencia callejera de megaciudad',
  // Provocativas & Sensuales
  'Sensual, ronco y ronroneante como un felino al acecho',
  'Provocador, agudo y juguetón con risitas cómplices y pausas insinuantes',
  // Anime & Gachas
  'Agudo, burlón y cantarín con risitas despectivas irresistibles (Mesugaki)',
  'Dulce y empalagoso en público, glacial y tembloroso de locura en privado (Yandere)',
  'Glacial, inexpresivo y monótono de comandante de flota SSR (Kuudere)',
  'Alegre, estridente y coqueto con inflexiones desenfadadas (Gyaru / Gal)',
  'Cantarino, alegre y travieso, con modulaciones cantarinas y risitas pícaras'
];

export const SPEECH_STYLES = [
  'Registro formal y cortesano de alta alcurnia (uso de usted, protocolo impecable)',
  'Coloquial y callejero con jerga gremial o de bajos fondos',
  'Arcaico y poético (retórica shakesperiana o épica antigua)',
  'Críptico y oracular (aforismos místicos, profecías y acertijos)',
  'Técnico, metódico y analítico (orientado a datos, lógica y precisión)',
  'Directo, rudo y sin rodeos (marcial, lacónico, órdenes tajantes)',
  'Burlón, mordaz y sarcástico (ironía continua y juegos de palabras)',
  'Silencioso y minimalista (habla solo lo estrictamente necesario)',
  'Teatral, declamatorio y apasionado (gestualidad dramática)',
  // Oscuras & Edgy
  'Susurros venenosos y órdenes dominantes indiscutibles con frialdad regia',
  'Poético-sombrío y grandilocuente, citando profecías de dragones oscuros y llamas negras (Chuunibyou)',
  'Sádico y burlón, deleitándose en la vulnerabilidad y el sufrimiento ajeno',
  // Modernas & Cyberpunk
  'Slang urbano cyberpunk (términos de red, ICE, ciberimplantes, glitches y sarcasmo)',
  'Protocolo militar conciso de operaciones encubiertas (códigos breves, porcentajes y cero sentimentalismo)',
  // Provocativas & Sensuales
  'Provocativo e insinuante con dobles sentidos continuos, jadeos suaves y susurros tentadores',
  'Dominante y exigente, tratando a sus interlocutores como mascotas consentidas o juguetes',
  // Anime & Gachas
  'Burlón e insolente: "¡Za~ko, za~ko!", "¡Qué patético!", tratando a todos de debiluchos (Mesugaki)',
  'Meloso y cariñoso con su amado/a, pero homicida y despiadado con cualquier tercero (Yandere)',
  'Tsundere clásico: tartamudeos enfurruñados ("¡B-Baka!", "¡No es lo que piensas!") seguidos de silencios avergonzados',
  'Descarado, coqueto y directo sin pudor ni vergüenza (Gyaru / Gal urbana)',
  'Informal, desinhibido y juguetón, alternando tarareos rítmicos y burlas afectuosas'
];

export const CATCHPHRASES_SUGGESTIONS = [
  '«Por el filo del alba...»',
  '«¿Comprendes la premisa o requieres diagrama?»',
  '«Fascinante... pero predecible.»',
  '«Tch, qué pérdida de tiempo.»',
  '«Si el destino lo permite, así será.»',
  '«Parámetros evaluados. Procedo.»',
  '«Por mi honor y mi palabra.»',
  '«Las sombras nunca mienten.»',
  '«Que las cenizas dicten sentencia.»',
  '«No te acostumbres a mi amabilidad.»',
  // Oscuras / Dark & Edgy
  '«De rodillas... aún no te he dado permiso para mirarme a los ojos.»',
  '«El dragón negro sellado en mi brazo arde con sed de almas pecadoras.»',
  '«El dolor es solo una caricia más si sabes pedirlo con educación.»',
  '«La muerte es un alivio que no pienso concederte tan rápido.»',
  // Modernas & Cyberpunk
  '«Tu firewall neuronal es un chiste; ya descargué tu memoria antes de que parpadearas.»',
  '«Todo tiene un precio en este callejón; dime con qué vas a pagar.»',
  '«Cero errores, cero rastros. Misión cumplida.»',
  // Provocativas & Sensuales
  '«¿Te gusta lo que ves, cariño... o prefieres que me acerque y te lo demuestre?»',
  '«Ven aquí... te prometo que morderé suavemente.»',
  '«Un juego sin apuestas peligrosas no merece la pena jugarse.»',
  // Anime & Gachas
  '«Za~ko, za~ko~ ¿en serio ese es todo tu poder, senpai debilucho? ¡Das pena!»',
  '«Si no eres mío/a, de nadie más serás en este mundo... jamás.»',
  '«¡B-Baka! No creas que te salvé porque me importes, ¡solo estorbabas en mi camino!»',
  '«Sincronización al 100%. Iniciando protocolo de aniquilación táctica SSR.»'
];

export const SKILLS_CATEGORIES: { category: string; skills: string[] }[] = [
  {
    category: 'Combate & Tácticas',
    skills: [
      'Esgrima de duelo y parada con estoque',
      'Maestría con espada a dos manos y mandoble',
      'Tiro con arco de precisión a larga distancia',
      'Combate desarmado y artes marciales marciales',
      'Lanza, alabarda y armas de asta',
      'Doble empuñadura de dagas acrobática',
      'Tácticas de asedio y mando de escuadrones',
      'Tirador de armas de fuego / pólvora arcana'
    ]
  },
  {
    category: 'Medicina, Alquimia & Ciencias',
    skills: [
      'Conocimientos de medicina y cirugía de campo',
      'Farmacopea, toxicología y antídotos',
      'Herbolaria mística y botánica curativa',
      'Alquimia transmutativa y destilación de pociones',
      'Anatomía comparada y puntos vitales',
      'Mecatrónica biónica e ingeniería mecánica',
      'Astronomía, cartografía estelar y navegación'
    ]
  },
  {
    category: 'Misticismo, Magia & Conocimiento',
    skills: [
      'Canalización de magia elemental (Fuego/Hielo/Rayo)',
      'Artes arcanas de sombras e ilusionismo',
      'Nigromancia y percepción de almas errantes',
      'Criptografía y descifrado de runas antiguas',
      'Rituales de purificación y bendiciones sacras',
      'Adivinación astrológica y lectura de augurios',
      'Pactos con espíritus de la naturaleza'
    ]
  },
  {
    category: 'Sigilo, Subterfugio & Supervivencia',
    skills: [
      'Sigilo de sombras y movimiento silencioso',
      'Cerrajería, ganzúas y desactivación de trampas',
      'Supervivencia en entornos extremos y rastreo',
      'Robo de bolsas y prestidigitación',
      'Disfraz, mimetismo y falsificación de sellos',
      'Escalada acrobática y parkour urbano',
      'Domador de bestias y empatía animal'
    ]
  },
  {
    category: 'Sociedad, Arte & Erudición',
    skills: [
      'Etiqueta noble y diplomacia cortesana',
      'Negociación comercial y tasación de gemas/reliquias',
      'Políglota (domina múltiples dialectos y lenguas extintas)',
      'Música instrumental y canto cautivador',
      'Oratoria persuasiva y retórica política',
      'Historia de dinastías y heráldica',
      'Lectura del lenguaje corporal y microexpresiones'
    ]
  },
  {
    category: 'Artes Oscuras, Nigromancia & Tormento (Dark)',
    skills: [
      'Maldiciones de sangre y enlaces empáticos de dolor',
      'Manipulación de sombras umbrales y espectros devoradores',
      'Tortura psicológica e interrogatorio mental invasivo',
      'Nigromancia de almas cautivas y animación cadavérica',
      'Invocación de llamas negras del abismo primordial',
      'Drenaje de energía vital y vampirismo sutil'
    ]
  },
  {
    category: 'Seducción, Manipulación & Encanto Prohibido (Sexy)',
    skills: [
      'Seducción hipnótica y lenguaje corporal magnético irresistible',
      'Elaboración de feromonas afrodisíacas y filtros de amor embriagantes',
      'Dagas envenenadas ocultas en liguero o corset de encaje',
      'Baile sensual de distracción táctica y desarme sensorial',
      'Juegos de dominación mental y extorsión emocional',
      'Masajes terapéuticos erógenos y toque de puntos de placer'
    ]
  },
  {
    category: 'Cibernética, Netrunning & Guerra Urbana (Moderno)',
    skills: [
      'Hacking neuronal directo y sobrecarga de ciberimplantes',
      'Guerra electrónica, saturación de ICE y bloqueo de satélites',
      'Tirador táctico con armas de plasma silenciadas y miras térmicas',
      'Pilotaje de drones de asalto y exoesqueletos de combate',
      'Infiltración en servidores de megacorporaciones',
      'Parkour vertical en rascacielos con anclajes magnéticos'
    ]
  },
  {
    category: 'Poderes de Anime, Gacha & Despertar Legendario',
    skills: [
      'Ataque cinemático definitivo (Burst Elemental / Noble Phantasm SSR)',
      'Despliegue de campos de fuerza cuánticos y barreras de maná puro',
      'Invocación de familiares míticos y armas astrales flotantes',
      'Despertar del modo berserker / furia de sangre sellada',
      'Evasión acrobática perfecta con estela de destellos luminosos',
      'Buffs de inspiración cósmica y sincronización en cadena de party'
    ]
  }
];

export const HABITS_AND_MANNERISMS_POOL = [
  'Acaricia el pomo o empuñadura de su arma al reflexionar',
  'Ajusta meticulosamente sus guantes antes de iniciar una conversación',
  'Evita el contacto visual prolongado, mirando al horizonte o a las salidas',
  'Murmura fórmulas, versos o notas tácticas en voz muy baja',
  'Mantiene siempre la espalda apoyada firmemente contra una pared o pilar',
  'Sonríe de medio lado con ironía ante situaciones de extremo peligro',
  'Juega con una moneda, dado o anillo girándolo velozmente entre los nudillos',
  'Inspecciona minuciosamente la comida o bebida antes de probarla (oler/mirar)',
  'Cruza los brazos con postura marcial rígida e impenetrable',
  'Se toca el lóbulo de la oreja o un mechón de pelo al dudar o mentir',
  'Exhala un suspiro pesado y pausado antes de desenvainar o actuar',
  'Inclina levemente la cabeza como un ave rapaz al escuchar a alguien',
  'Limpia obsesivamente sus anteojos, dagas o instrumental de trabajo',
  'Camina con pasos casi inaudibles sin proyectar peso sobre los talones',
  'Toma notas constantes en un pequeño cuaderno de cuero desgastado',
  // Oscuros
  'Sonríe con ojos sombríos y mirada vacía sin brillo (mirada Yandere)',
  'Lame una gota de sangre o residuo arcano de su pulgar con deleite morboso',
  'Juega con una daga cerca de su propio cuello o el de su interlocutor sin inmutarse',
  'Observa fijamente la garganta de las personas mientras hablan como evaluando una yugular',
  'Mantiene una sonrisa siniestra inmutable mientras inflige dolor o recibe amenazas',
  'Arrastra la punta de su arma por el suelo dejando un chirrido metálico inquietante',
  // Modernos & Cyberpunk
  'Teclea en el aire interactuando con su interfaz holográfica flotante o visores AR',
  'Masca chicle con indolencia y hace pompas mientras recibe órdenes de superiores',
  'Revisa el estado de batería o sincronización de sus implantes con un chasquido',
  'Se coloca auriculares o sube la capucha con gesto rebelde ante charlas tediosas',
  'Enciende un cigarrillo sintético o vaporizador de neón al calcular riesgos',
  'Golpea el suelo con su bota táctica al compás de una pista synthwave interna',
  // Provocativos & Sensuales
  'Se muerde el labio inferior o se acaricia la clavícula con mirada insinuante y sugerente',
  'Cruza lentamente las piernas con lentitud teatral captando todas las miradas de la sala',
  'Enrolla un mechón de cabello en el dedo mientras lanza una mirada coqueta bajo las pestañas',
  'Invade el espacio personal del interlocutor susurrándole al oído a pocos milímetros',
  'Humedece sus labios antes de contestar con una sonrisa pícara y descarada',
  'Acomoda lentamente el escote o la caída de su vestimenta con fingida inocencia',
  'Pasa un dedo por el mentón o pecho del interlocutor antes de formular una petición',
  // Anime & Gachas
  'Saca la lengua burlonamente jalando el párpado inferior en gesto de burla (Akanbe / Mesugaki)',
  'Se cubre un ojo con la mano dejando escapar una risita siniestra teatral (pose Chuunibyou)',
  'Pone las manos en las caderas y se inclina hacia adelante con una gran sonrisa burlona',
  'Infla las mejillas enfurruñada y aparta la mirada cruzando los brazos (Pout Tsundere)',
  'Acaricia o agita nerviosamente sus orejas kemono o cola cuando se avergüenza',
  'Guiña un ojo a la "cámara" o al interlocutor con gesto de idol carismática',
  'Secciona o aparta flequillos mientras sus ojos destellan con un brillo de poder SSR',
  'Se sonroja hasta las orejas y golpea accidentalmente el suelo o una pared por vergüenza',
  'Baila y tararea melodías al andar, sacudiendo su cola para presumir sus colores pastel',
  'Se ajusta la máscara de cráneo animal sobre la coronilla cuando adopta una pose desafiante',
  'Señala con picardía y saca la lengua en son de broma cuando alguien se sonroja al mirarle',
  'Danza al ritmo de pisadas descalzas sobre la arena mientras hace tintinear sus tobilleras y cascabeles',
  'Sonríe con picardía ladeando las orejas y guiñando un ojo mientras provoca al rival («¡Atrápame si puedes!»)',
  'Sacude y esponja sus colas de colores pastel al recibir cumplidos con fingida arrogancia',
  // Ferales, Guerreros & Mandoble Colosal
  'Descansa el enorme mandoble de acero forjado sobre el hombro con naturalidad feroz',
  'Exhibe una sonrisa desafiante con colmillos afilados al encarar a rivales que le doblan el tamaño',
  'Ajusta con brusquedad las hebillas de cuero en sus muslos antes de arremeter en carrera',
  'Pasa el pulgar sobre las muescas de batalla en el filo de su arma colosal con orgullo salvaje',
  'Sacude su melena rubia salvaje apartando el mechón negro frontal antes de soltar un rugido de combate',
  // Felinos Urbanos & Streetwear
  'Alza una mano flexionando los dedos para mostrar sus almohadillas dérmicas haciendo un saludo felino juguetón («Nya~»)',
  'Se sienta sobre pupitres o mesas balanceando las piernas mientras ladea la cabeza con curiosidad traviesa',
  'Cruza los brazos dejando caer su chaqueta sobre los hombros mientras hace un puchero desafiante'
];

export * from './data/roleAttireData';
export * from './data/orientalFantasyData';
export * from './data/styleArmorAccessoriesData';



