import {
  WorldPlace,
  WorldBuildingConfig,
  CriticalPointOfInterest,
  ConvergenceZone,
  HousingRoom,
  UniqueElement,
  WorldFaction,
  WorldSpecialLaw,
  WorldLaw
} from '../types';

// ========================================================
// 1. ARQUETIPOS DE ESCENARIO (PLACE ARCHETYPES)
// ========================================================

export interface PlacePreset {
  id: string;
  name: string;
  badge: string;
  description: string;
  icon: string;
  data: Partial<WorldPlace>;
}

export const PLACE_PRESETS: PlacePreset[] = [
  {
    id: 'oasis_sagrado',
    name: 'Oasis de Santuario Arcano',
    badge: 'Místico & Protector',
    icon: 'Palmtree',
    description: 'Refugio milenario rodeado de dunas, aguas sagradas cristalinas y custodios devotos.',
    data: {
      name: 'Oasis de las Tres Lunas',
      geographicContext: 'Asentamiento aislado',
      region: 'Desierto de las Arenas Susurrantes',
      environmentType: 'Oasis',
      dangerLevel: 'Seguro',
      rhythmOrVibes: ['Tranquilo', 'Místico', 'Vigilado'],
      atmosphere: 'Aguas turquesas reflejando constelaciones, brisa cálida con incienso de mirra y susurro de palmeras doradas.',
      description: 'Un santuario pacífico neutral donde las caravanas y los místicos deponen sus armas ante la autoridad sagrada del pozo de agua.',
      constructionStyle: 'Tradicional',
      materials: ['Piedra', 'Madera', 'Vidrio', 'Materiales fantásticos'],
      condition: 'Conservado',
      criticalPointsOfInterest: [
        {
          id: 'POI-OASIS-01',
          name: 'Manantial del Reflejo Astral',
          type: 'Fuente sagrada',
          function: 'Purificación ritual, descanso y comunión mística',
          owner: 'Sumo Custodio del Velo',
          location: 'Centro del oasis',
          importance: 'Crítica',
          description: 'Aguas cristalinas imbuyen vigor a quien bebe con intención sincera.'
        },
        {
          id: 'POI-OASIS-02',
          name: 'Pabellón de las Caravanares',
          type: 'Bazar / Posada',
          function: 'Comercio de sedas, trueque de especias y hospedaje',
          owner: 'Gremio de Comerciantes del Desierto',
          location: 'Margen este del lago',
          importance: 'Alta',
          description: 'Tiendas de lona gruesa con alfombras persas, té caliente y relatos de viajeros.'
        },
        {
          id: 'POI-OASIS-03',
          name: 'Puesto de Guardia de los Vigías del Velo',
          type: 'Puesto de guardia',
          function: 'Custodia del perímetro y registro de armas de viajeros',
          owner: 'Guardia Sagrada',
          location: 'Entrada norte de las dunas',
          importance: 'Alta',
          description: 'Torreón de piedra caliza con arqueros y observadores del horizonte.'
        }
      ],
      convergenceZones: [
        {
          id: 'ZONE-OASIS-01',
          name: 'Plaza de las Lámparas de Aceite',
          type: 'Plaza',
          schedule: 'Atardecer y noche estrellada',
          npcDensity: 'Media',
          frequentEvents: 'Danzas rituales, tertulias alrededor del fuego y trueque de talismanes',
          securityLevel: 'Medio',
          associatedCharacters: ['Danzarinas', 'Peregrinos', 'Caravaneros']
        }
      ],
      cultureAndSecurity: {
        authority: 'Gobierno',
        surveillance: 'Media',
        socialConduct: ['Hospitalidad', 'Solidaridad', 'Devoción']
      },
      hasHousing: true,
      housing: {
        buildingType: 'Residencia',
        levels: [
          {
            levelNumber: 0,
            levelName: 'NIVEL 0 — PABELLÓN DE ACCESO & PATIO',
            rooms: [
              {
                id: 'R-OASIS-01',
                name: 'Patio de los Jazmines',
                function: 'Recepción y descanso fresco',
                location: 'Entrada principal con fuente central',
                furniture: ['Divanes de seda', 'Mesas de cobre repujado'],
                objects: ['Jarras de agua fresca', 'Incensarios de bronce'],
                accesses: ['Arquería exterior', 'Aposentos privados'],
                associatedCharacters: ['Anfitriones del Santuario'],
                description: 'Patio abierto bajo pérgolas florecidas con sombras protectoras.'
              }
            ]
          },
          {
            levelNumber: 1,
            levelName: 'NIVEL 1 — APOSENTOS PRIVADOS',
            rooms: [
              {
                id: 'R-OASIS-02',
                name: 'Cámara del Reposo',
                function: 'Dormitorio y meditación íntima',
                location: 'Piso superior orientado a las estrellas',
                furniture: ['Cama dosel de madera aromática', 'Cojines de plumón', 'Escritorio de cedro'],
                objects: ['Lámpara de aceite perfumado', 'Pergaminos de navegación celeste'],
                accesses: ['Escalera de caracol', 'Balcón con vista al manantial'],
                associatedCharacters: [],
                description: 'Estancia ventilada con celosías talladas que filtran la luz dorada.'
              }
            ]
          }
        ],
        exteriorsAndConnectivity: ['Patios interiores', 'Terrazas con celosías', 'Mirador astral']
      },
      uniqueElements: [
        {
          id: 'UNIQ-OASIS-01',
          name: 'Loto de Obsidiana y Cristal',
          type: 'ANOMALÍA',
          description: 'Una flor mineral que florece únicamente cuando se aproxima una tormenta mágica.',
          behavior: 'Emite un zumbido armónico que calma a las bestias de carga.',
          importance: 'Elemento ambiental'
        }
      ],
      ambientColorTheme: 'from-amber-950/40 via-cyan-950/20 to-black'
    }
  },
  {
    id: 'bastion_militar',
    name: 'Bastión de la Guardia / Fortaleza',
    badge: 'Defensa & Disciplina',
    icon: 'Shield',
    description: 'Complejo fortificado con murallas de sillar, centinelas disciplinados y armería subterránea.',
    data: {
      name: 'Bastión de Hierro y Ceniza',
      geographicContext: 'Zona fronteriza',
      region: 'Frontera de las Fauces Escarpadas',
      environmentType: 'Ciudadela',
      dangerLevel: 'Disputado',
      rhythmOrVibes: ['Vigilado', 'Tenso', 'Frenético'],
      atmosphere: 'Rechinar de mallas de acero, olor a humo de fragua y viento helado sobre las almenas.',
      description: 'El último bastión civilizado antes de las tierras salvajes. Los centinelas patrullan día y noche sin descanso.',
      constructionStyle: 'Brutalismo',
      materials: ['Piedra', 'Metal', 'Hormigón'],
      condition: 'Conservado',
      criticalPointsOfInterest: [
        {
          id: 'POI-BASTION-01',
          name: 'Comandancia & Mesa de Guerra',
          type: 'Puesto de mando',
          function: 'Planificación táctica, asignación de misiones y decretos marciales',
          owner: 'Comandante de Guarnición',
          location: 'Planta noble del baluarte',
          importance: 'Crítica',
          description: 'Mesa con mapas topográficos, estandartes de facción y expedientes de reclutas.'
        },
        {
          id: 'POI-BASTION-02',
          name: 'Gran Fragua & Armería',
          type: 'Taller / Armería',
          function: 'Reparación de escudos, forja de hojas y munición pesada',
          owner: 'Maestro Herrero Militar',
          location: 'Patio de armas inferior',
          importance: 'Alta',
          description: 'Hornos de carbón mineral encendidos día y noche con yunques repicando.'
        },
        {
          id: 'POI-BASTION-03',
          name: 'Torre del Vigía de Almenas',
          type: 'Torre de vigilancia',
          function: 'Alerta temprana contra incursiones y balista de defensa',
          owner: 'Tropa de Exploradores',
          location: 'Punto más alto de la muralla norte',
          importance: 'Alta',
          description: 'Catalejos de bronce, campana de alarma y proyectiles incendiarios preparados.'
        }
      ],
      convergenceZones: [
        {
          id: 'ZONE-BASTION-01',
          name: 'Patio de Entrenamiento & Reclutamiento',
          type: 'Patio',
          schedule: 'Madrugadas y mediodías',
          npcDensity: 'Alta',
          frequentEvents: 'Duelos con espadas de madera, formación en falange y relevo de guardias',
          securityLevel: 'Vigilancia militar',
          associatedCharacters: ['Reclutas', 'Instructores', 'Veteranos']
        }
      ],
      cultureAndSecurity: {
        authority: 'Milicia',
        surveillance: 'Extrema',
        socialConduct: ['Competencia', 'Desconfianza', 'Honor marcial']
      },
      hasHousing: true,
      housing: {
        buildingType: 'Búnker',
        levels: [
          {
            levelNumber: 0,
            levelName: 'NIVEL 0 — BARRACONES & ARMERÍA',
            rooms: [
              {
                id: 'R-BASTION-01',
                name: 'Barracón de la Guardia',
                function: 'Descanso de la tropa en guardia',
                location: 'Ala este del patio',
                furniture: ['Literas de madera maciza', 'Baúles numerados', 'Armeros'],
                objects: ['Capas de lana militar', 'Piedras de afilar'],
                accesses: ['Patio de armas', 'Comedor'],
                associatedCharacters: ['Guardias de turno'],
                description: 'Espacio sobrio, limpio y ordenado con rigor espartano.'
              }
            ]
          },
          {
            levelNumber: 1,
            levelName: 'NIVEL 1 — CÁMARA DEL OFICIAL',
            rooms: [
              {
                id: 'R-BASTION-02',
                name: 'Aposento del Capitán',
                function: 'Descanso privado y custodia de documentos reservados',
                location: 'Torreón este',
                furniture: ['Cama individual robusta', 'Escritorio con cerradura de combinación', 'Estantería de tácticas'],
                objects: ['Libro de órdenes', 'Daga ceremonial', 'Cáliz de peltre'],
                accesses: ['Escalera de la muralla'],
                associatedCharacters: [],
                description: 'Habitación de piedra fría iluminada por una sola chimenea de leña de pino.'
              }
            ]
          }
        ],
        exteriorsAndConnectivity: ['Murallas con almenas', 'Foso defensivo', 'Puente levadizo', 'Pasajes subterráneos']
      },
      uniqueElements: [
        {
          id: 'UNIQ-BASTION-01',
          name: 'Campana de Sitio "Voz de Bronce"',
          type: 'MECANISMO',
          description: 'Campana colosal forjada con metal templado en cenizas de dragón.',
          behavior: 'Su tañido infunde coraje a los defensores y desalienta a los intrusos.',
          importance: 'Peligro / Alerta'
        }
      ],
      ambientColorTheme: 'from-slate-950/50 via-rose-950/20 to-black'
    }
  },
  {
    id: 'distrito_comercial',
    name: 'Bazar & Distrito Comercial de la Encrucijada',
    badge: 'Comercio & Vida Urbana',
    icon: 'Coins',
    description: 'Distrito mercantil vibrante repleto de puestos de especias, casas de cambio, tabernas y artesanos.',
    data: {
      name: 'Gran Bazar del Zoco Dorado',
      geographicContext: 'Distrito urbano',
      region: 'Metrópolis Fluvial de Val-Meridia',
      environmentType: 'Taberna',
      dangerLevel: 'Neutral',
      rhythmOrVibes: ['Frenético', 'Caótico', 'Hospitalidad'],
      atmosphere: 'Pregoneros ofreciendo telas raras, aroma penetrante a azafrán y café torrefacto, bullicio continuo.',
      description: 'El corazón latiente de la economía local. Miles de monedas cambian de manos cada hora entre gremios rivales y forasteros.',
      constructionStyle: 'Tradicional',
      materials: ['Madera', 'Piedra', 'Vidrio', 'Ladrillo'],
      condition: 'Conservado',
      criticalPointsOfInterest: [
        {
          id: 'POI-BAZAR-01',
          name: 'Lonja de Cambio de los Siete Sellos',
          type: 'Banco / Comercio',
          function: 'Intercambio de divisas, pagarés y tasación de gemas',
          owner: 'Consorcio de Cambistas',
          location: 'Esquina de la Alameda Central',
          importance: 'Alta',
          description: 'Balanza de precisión con mostradores enrejados de latón pulido.'
        },
        {
          id: 'POI-BAZAR-02',
          name: 'Taberna del Fénix de Cobre',
          type: 'Posada & Taberna',
          function: 'Lugar de tertulia, contratos mercantiles y comida caliente',
          owner: 'Tabernera Maren',
          location: 'Costado del canal de descarga',
          importance: 'Media',
          description: 'Mesas comunales de roble, barriles de cerveza negra y músicos ambulantes.'
        },
        {
          id: 'POI-BAZAR-03',
          name: 'Botica de las Esencias Arcanas',
          type: 'Taller / Botica',
          function: 'Venta de bálsamos, elixires digestivos y catalizadores',
          owner: 'Herborista Vael',
          location: 'Callejón de las Especias',
          importance: 'Media',
          description: 'Estantes repletos de frascos de vidrio ámbar y raíces secas colgadas del techo.'
        }
      ],
      convergenceZones: [
        {
          id: 'ZONE-BAZAR-01',
          name: 'Plaza del Reloj Solar de Mármol',
          type: 'Mercado',
          schedule: 'Desde el amanecer hasta medianoche',
          npcDensity: 'Frenética',
          frequentEvents: 'Subastas callejeras, trileros, pregones de noticias y música festiva',
          securityLevel: 'Bajo',
          associatedCharacters: ['Mercaderes', 'Ladronzuelos', 'Guardias de mercado']
        }
      ],
      cultureAndSecurity: {
        authority: 'Comunidad',
        surveillance: 'Baja',
        socialConduct: ['Competencia', 'Hospitalidad', 'Indiferencia']
      },
      hasHousing: true,
      housing: {
        buildingType: 'Taller-vivienda',
        levels: [
          {
            levelNumber: 0,
            levelName: 'NIVEL 0 — TIENDA & TALLER A PIE DE CALLE',
            rooms: [
              {
                id: 'R-BAZAR-01',
                name: 'Mostrador & Almacén',
                function: 'Atención al público y almacenamiento de cajas',
                location: 'Frente al callejón principal',
                furniture: ['Mostrador de pino', 'Estanterías altas', 'Banqueta'],
                objects: ['Báscula', 'Caja de caudales con doble cerrojo', 'Libro de cuentas'],
                accesses: ['Puerta a la calle', 'Trampilla al sótano', 'Escalera al desván'],
                associatedCharacters: ['Comerciante'],
                description: 'Espacio concurrido con estantes bien aprovechados hasta el techo.'
              }
            ]
          },
          {
            levelNumber: 1,
            levelName: 'NIVEL 1 — VIVIENDA FAMILIAR & REPOSO',
            rooms: [
              {
                id: 'R-BAZAR-02',
                name: 'Salón-Dormitorio de la Buhardilla',
                function: 'Descanso privado y cena',
                location: 'Planta superior abuhardillada',
                furniture: ['Cama amplia con edredón de parches', 'Mesa redonda', 'Armario ropero'],
                objects: ['Farol de aceite', 'Tetera de arcilla', 'Alfombra tejida a mano'],
                accesses: ['Escalera interior', 'Ventanal con polea exterior'],
                associatedCharacters: [],
                description: 'Acogedora buhardilla con olor a té y madera vieja que aísla del ruido de la calle.'
              }
            ]
          }
        ],
        exteriorsAndConnectivity: ['Balcones sobre el callejón', 'Pasadizo de carga', 'Azotea para tender ropa']
      },
      uniqueElements: [
        {
          id: 'UNIQ-BAZAR-01',
          name: 'Reloj Hidráulico de los Mercaderes',
          type: 'MECANISMO',
          description: 'Mecanismo de agua y engranajes que marca las horas con silbatos de flauta.',
          behavior: 'Regula la apertura y cierre de puestos en todo el distrito.',
          importance: 'Elemento ambiental'
        }
      ],
      ambientColorTheme: 'from-amber-950/40 via-emerald-950/20 to-black'
    }
  },
  {
    id: 'suburbio_industrial',
    name: 'Sector Subterráneo / Fundición Industrial',
    badge: 'Vapor & Maquinaria',
    icon: 'Cpu',
    description: 'Nivel inferior de la ciudad con calderas masivas, tuberías de vapor y talleres de chatarra.',
    data: {
      name: 'Nivel de Fuego y Vapor - Sector 4',
      geographicContext: 'Distrito industrial',
      region: 'Fondo de la Metrópolis / Suburbio Minero',
      environmentType: 'Mazmorra',
      dangerLevel: 'Hostil',
      rhythmOrVibes: ['Frenético', 'Tenso', 'Caótico'],
      atmosphere: 'Vapor a presión silbando por juntas corroídas, resplandor rojizo de fundiciones y olor a grasa mineral.',
      description: 'El motor silencioso que abastece de energía a las alturas. La vida aquí es ruda, calurosa y peligrosa.',
      constructionStyle: 'Industrial',
      materials: ['Metal', 'Hormigón', 'Ladrillo', 'Materiales sintéticos'],
      condition: 'Deteriorado',
      criticalPointsOfInterest: [
        {
          id: 'POI-IND-01',
          name: 'Caldera Magna Núcleo Alfa',
          type: 'Mecanismo de energía',
          function: 'Generación de calor y bombeo de fluidos a alta presión',
          owner: 'Sindicato de Fogoneros',
          location: 'Bóveda central de acero',
          importance: 'Crítica',
          description: 'Horno titánico con remaches de acero y manómetros al borde de la sobrepresión.'
        },
        {
          id: 'POI-IND-02',
          name: 'Taller de Ensamblaje y Desguace',
          type: 'Taller mecánico',
          function: 'Modificación de prótesis, soldadura de engranajes y reciclaje',
          owner: 'Chatarrero Boris',
          location: 'Túnel de ventilación secundario',
          importance: 'Media',
          description: 'Montones de piezas de cobre, herramientas neumáticas y sopladores de gas.'
        }
      ],
      convergenceZones: [
        {
          id: 'ZONE-IND-01',
          name: 'Cantina de los Fogoneros "El Pistón"',
          type: 'Bar',
          schedule: 'Turnos rotativos 24/7',
          npcDensity: 'Media',
          frequentEvents: 'Peleas a puño limpio, timbas de naipes aceitosos y quejas laborales',
          securityLevel: 'Sin vigilancia',
          associatedCharacters: ['Obreros', 'Mecánicos', 'Contrabandistas']
        }
      ],
      cultureAndSecurity: {
        authority: 'Organización criminal',
        surveillance: 'Nula',
        socialConduct: ['Solidaridad', 'Miedo', 'Desconfianza']
      },
      hasHousing: true,
      housing: {
        buildingType: 'Departamento colmena',
        levels: [
          {
            levelNumber: 0,
            levelName: 'NIVEL 0 — MÓDULOS DE HABITÁCULO',
            rooms: [
              {
                id: 'R-IND-01',
                name: 'Cápsula de Sueño #402',
                function: 'Reposo en espacio compacto',
                location: 'Pared de nichos habitables',
                furniture: ['Colchón ignífugo', 'Repisa metálica abatible'],
                objects: ['Respirador de filtro de carbono', 'Gafas de soldador', 'Linterna recargable'],
                accesses: ['Pasarela enrejada suspendida'],
                associatedCharacters: [],
                description: 'Habitáculo minimalista de chapa remachada que protege del calor y las chispas.'
              }
            ]
          }
        ],
        exteriorsAndConnectivity: ['Pasarelas de rejilla metálica', 'Conductos de ventilación', 'Montacargas ruidoso']
      },
      uniqueElements: [
        {
          id: 'UNIQ-IND-01',
          name: 'Válvula de Alivio Sísmico',
          type: 'MECANISMO',
          description: 'Enorme compuerta de bronce que expulsa chorros de vapor hirviendo cada dos horas.',
          behavior: 'Genera una densa niebla cálida que ciega temporalmente el sector.',
          importance: 'Peligro / Ambiental'
        }
      ],
      ambientColorTheme: 'from-orange-950/50 via-zinc-950/40 to-black'
    }
  },
  {
    id: 'ruinas_antiguas',
    name: 'Ruinas del Santuario Prohibido',
    badge: 'Misterio & Peligro Ancestral',
    icon: 'Sparkles',
    description: 'Complejo derruido con arquitectura ciclópea, estatuas rotas y anomalías mágicas latentes.',
    data: {
      name: 'Catacumbas de la Corona de Jade',
      geographicContext: 'Asentamiento aislado',
      region: 'Tierras Muertas de los Reyes Olvidados',
      environmentType: 'Ruinas',
      dangerLevel: 'Mortal',
      rhythmOrVibes: ['Aislado', 'Estancado', 'Tenso'],
      atmosphere: 'Silencio sepulcral solo roto por gotas de agua mineral, brillo esmeralda fosforescente en las paredes.',
      description: 'Construido por una civilización extinta antes de la fractura del mundo. Las trampas y ecos mágicos aún custodian sus tesoros.',
      constructionStyle: 'Mágico',
      materials: ['Piedra', 'Materiales fantásticos'],
      condition: 'Abandonado',
      criticalPointsOfInterest: [
        {
          id: 'POI-RUIN-01',
          name: 'Altar del Ojo Ancestral',
          type: 'Templo / Altar',
          function: 'Foco de canalización mística y portal sellado',
          owner: 'Espíritu Guardián sin voz',
          location: 'Cámara abovedada central',
          importance: 'Crítica',
          description: 'Bloque monolítico de piedra negra con runas grabadas que brillan con pulso propio.'
        }
      ],
      convergenceZones: [
        {
          id: 'ZONE-RUIN-01',
          name: 'Atrio Derrumbado',
          type: 'Parque',
          schedule: 'Silencio perpetuo',
          npcDensity: 'Nula',
          frequentEvents: 'Aparición de fuegos fatuos y sombras desvanecidas',
          securityLevel: 'Sin vigilancia',
          associatedCharacters: ['Sombras errantes']
        }
      ],
      cultureAndSecurity: {
        authority: 'Nadie',
        surveillance: 'Nula',
        socialConduct: ['Miedo', 'Desconfianza']
      },
      hasHousing: false,
      uniqueElements: [
        {
          id: 'UNIQ-RUIN-01',
          name: 'Monolito de la Resonancia',
          type: 'ANOMALÍA',
          description: 'Pilar que desafía la gravedad, suspendido a un metro del suelo con rotación lenta.',
          behavior: 'Repele proyectiles mundanos y distorsiona el flujo temporal en su proximidad.',
          importance: 'Clave de trama / Mágico'
        }
      ],
      ambientColorTheme: 'from-emerald-950/50 via-purple-950/30 to-black'
    }
  }
];

// ========================================================
// 2. ARQUETIPOS DE WORLDBUILDING (WORLD PRESETS)
// ========================================================

export interface WorldPreset {
  id: string;
  name: string;
  badge: string;
  tone: string;
  icon: string;
  description: string;
  config: Partial<WorldBuildingConfig>;
}

export const WORLD_PRESETS: WorldPreset[] = [
  {
    id: 'alta_fantasia',
    name: 'Alta Fantasía Arcana & Dioses Antiguos',
    badge: 'Magia Plena & Heroísmo',
    tone: 'Épico & Solemne',
    icon: 'Sparkles',
    description: 'Un mundo donde la magia fluye como ríos, los dioses responden oraciones y los linajes defienden juramentos milenarios.',
    config: {
      worldName: 'Elysia: El Reino de las Siete Coronas',
      version: 'v1.0',
      eraOrTone: 'Épico & Solemne • Era de las Siete Coronas',
      magicLevel: 'Alta',
      history: {
        origin: 'Nacido del tejido primordial de las tres deidades estelares, que esculpieron los continentes con arpas de luz cristalina.',
        eras: 'Era del Génesis Astral → Era de los Reyes Hechiceros → Época de la Fractura → Renacimiento de las Siete Coronas (Actual)',
        keyEvents: ['La Coronación de Al-Zahra', 'El Descenso de los Dragones de Jade', 'La Gran Tregua de los Templos'],
        wars: ['Guerra de los Cien Velos', 'Rebelión de las Sombras Huérfanas'],
        catastrophes: ['El Cataclismo de la Luna Rota', 'La Sequía de Maná de Vel-Drakor'],
        politicalChanges: ['Establecimiento del Concilio Supremo de Arcanistas', 'Pacto de Fronteras Libres'],
        fundamentalEvents: ['Aparición de los Manantiales Eternos en los desiertos meridionales']
      },
      geographyHierarchy: {
        continents: ['Val-Elysium (Continente Central)', 'Aethelgard (Tierras del Norte)', 'Zul-Shara (Desiertos del Sur)'],
        countries: ['Imperio del Sol Poniente', 'Reino de las Aguas Claras', 'Confederación de los Nómadas del Velo'],
        regions: ['Desierto de las Cenizas Doradas', 'Bosque de las Espinas de Plata', 'Cordillera de los Titanes'],
        cities: ['Ciudadela de Al-Zahra', 'Capital Fluvial de Meridia', 'Bastión de la Puerta Alta'],
        climates: ['Desértico cálido con noches gélidas', 'Templado atlántico con brisas arcanas', 'Tundra mágica boreal'],
        resources: ['Cristales de Maná', 'Especias Astrales', 'Madera de Roble Blanco', 'Mithril'],
        specialZones: ['Falla del Horizonte Torcido', 'Oasis Sagrado de Aguas Vivas'],
        hierarchy: []
      },
      politics: {
        governments: ['Monarquía Teocrática Constitucional', 'Concilio de Gremios Mercantiles', 'Clanes Tribales Autónomos'],
        factions: [
          {
            id: 'FAC-01',
            name: 'Guardia del Velo Dorado',
            ideology: 'Custodia rigurosa de los santuarios sagrados, protección de peregrinos y defensa del honor marcial.',
            emblemIcon: 'Shield',
            color: '#D4AF37',
            reputationWithPlayer: 'Amistosa',
            description: 'Orden caballeresca de elite con armaduras de orfebrería y lanzas imbuidas en luz solar.',
            activeEnemies: ['FAC-03']
          },
          {
            id: 'FAC-02',
            name: 'Consorcio de las Especias Astrales',
            ideology: 'Comercio libre, diplomacia mercantil pragmática y monopolio de las rutas caravaneras.',
            emblemIcon: 'Gem',
            color: '#38BDF8',
            reputationWithPlayer: 'Neutral',
            description: 'Comerciantes acaudalados que operan bazares, casas de cambio y barcos de cabotaje fluvial.',
            activeEnemies: []
          },
          {
            id: 'FAC-03',
            name: 'Culto del Eclipse Sombrío',
            ideology: 'Destrucción de los sellos de los santuarios, abolición de las castas sacerdotales y liberación del Vacío.',
            emblemIcon: 'Flame',
            color: '#E11D48',
            reputationWithPlayer: 'Hostil',
            description: 'Fanáticos y asesinos que operan desde ruinas hundidas y ejecutan golpes clandestinos.',
            activeEnemies: ['FAC-01', 'FAC-02']
          }
        ],
        organizations: ['Gremio de Alquimistas de la Corte', 'Hermandad de los Navegantes del Cielo'],
        relationships: [
          { id: 'REL-01', factionAId: 'FAC-01', factionBId: 'FAC-02', status: 'Pacto', notes: 'Tratado de escolta pagada en rutas' },
          { id: 'REL-02', factionAId: 'FAC-01', factionBId: 'FAC-03', status: 'Hostil', notes: 'Guerra santa declarada' }
        ],
        conflicts: ['Disputa por los derechos arancelarios en el Oasis', 'Tensión por infiltración del Culto'],
        hierarchies: ['Sumo Sacerdote > Comandante de Orden > Capitán > Escudero']
      },
      economy: {
        currency: 'Corona de Oro de Al-Zahra (10 Coronas = 100 Dracmas de Plata = 1000 Cobres)',
        resources: ['Cristales de energía pura', 'Seda de gusano estelar', 'Agua bendita de oasis'],
        trade: 'Rutas terrestres de caravanas de dromedarios acorazados y barcazas fluviales',
        markets: ['Gran Bazar del Zoco Dorado', 'Feria de Reliquias de Meridia'],
        keyGoods: ['Incienso sagrado', 'Armamento de acero templado', 'Pócimas curativas'],
        scarcity: ['Madera noble en el desierto', 'Hierro puro en las islas fluviales'],
        wealth: 'Concentrada en los templos de orfebrería y en las casas matrices de los mercaderes',
        systems: ['Monetarismo respaldado por reservas de grano y cristales mágicos']
      },
      religionAndCulture: {
        isApplicable: true,
        religions: ['Culto a las Tres Lunas Gemelas', 'Veneración del Fuego Primordial'],
        traditions: ['Ofrenda del primer cuenco de agua al visitante', 'Festival de las Lámparas Flotantes'],
        customs: ['Taparse el rostro al ingresar al santuario mayor', 'Saludo con mano en el pecho'],
        festivities: ['Noche del Solsticio de Oro', 'Día de la Gran Siembra'],
        taboos: ['Derramar sangre en agua dulce', 'Falsificar el sello del templo', 'Dañar a un emisario'],
        values: ['Honor a la palabra dada', 'Hospitalidad sagrada', 'Respeto al maestro'],
        culturalNorms: ['Las disputas de sangre se resuelven en juicio ante el Consejo de Ancianos']
      },
      technology: {
        level: 'Medieval',
        allowedTech: ['Forja de acero de alta pureza', 'Arquitectura abovedada ciclópea', 'Molinos de agua y viento', 'Sistemas hidráulicos de regadío'],
        forbiddenTech: ['Pólvora y armas de fuego', 'Motores de combustión', 'Inteligencia artificial', 'Armamento nuclear']
      },
      magicSystem: {
        hasMagic: true,
        source: 'El Flujo de los Manantiales Cósmicos que discurre bajo la corteza del mundo.',
        rules: ['La magia requiere concentración y voluntad alineada', 'Toda energía invocada debe ser restituida al entorno'],
        limitations: ['Fatiga severa del taumaturgo', 'No se puede crear materia permanente de la nada', 'Los metales pesados amortiguan el flujo'],
        cost: 'Gasto de CEP (Puntos de Enfoque Psíquico) y deshidratación progresiva',
        users: 'Sacerdotisas del Velo, Magos de Academia y Eruditos Nacidos con Vena Astral',
        types: ['Artes Curativas', 'Canalización de Luz Solar', 'Encantamiento de Metales', 'Adivinación Estelar'],
        effects: ['Sanación acelerada de heridas', 'Resplandor cegador', 'Escudos de fuerza cinética'],
        restrictions: ['La nigromancia directa está penalizada con el destierro absoluto']
      },
      physicalRules: {
        gravity: 'Equivalente a 1.0G terrestre. Estable y continua.',
        biology: 'Fisiología humanoide estándar con metabolismo enriquecido por la pureza del aire arcano.',
        healing: 'Recuperación natural complementada por infusiones de hierbas y cataplasmas de loto.',
        death: 'Irreversible bajo leyes ordinarias. Las almas trascienden al Gran Océano de Estrellas.',
        travel: 'A pie, monturas cuadrúpedas del desierto (avestruces acorazadas y camellos de cuatro jorobas) y carretas.',
        time: 'Ciclo de 24 horas solares con dos estaciones principales: Estación del Sol Alto y Estación de las Nieblas.',
        space: 'Geometría euclidiana tridimensional continua.',
        energy: 'Conservación de masa-energía salvo en vórtices de manantial sagrado.',
        supernaturalPhenomena: 'Tormentas de arena de cuarzo luminoso y auroras astrales que revelan caminos ocultos.'
      },
      socialRules: {
        hierarchies: 'Sacerdotes y Guardianes > Maestros de Gremio > Ciudadanos y Artesanos > Viajeros y Forasteros',
        customs: 'El anfitrión debe servir tres tazas de té antes de abordar asuntos de dinero o política.',
        familyRelations: 'Familias extendidas organizadas en casas matriciales con patriarcas o matriarcas consejeras.',
        socialNorms: 'El respeto a los mayores y la custodia de los niños es un deber comunal innegociable.',
        acceptedBehaviors: ['Generosidad con los necesitados', 'Humildad en el templo', 'Valor marcial sin fanfarronería'],
        rejectedBehaviors: ['Usura abusiva', 'Agresión sin previo aviso', 'Blasfemia en fuentes de agua'],
        protocols: ['Inclinación de cabeza con mano en el plexo solar ante autoridades sagradas'],
        socialRoles: ['Custodio del Velo', 'Tesorero de Gremio', 'Maestra Danzarina', 'Explorador de Dunas']
      },
      specialLaws: [
        {
          id: 'LAW-SPEC-01',
          title: 'Tregua Sagrada de las Fuentes',
          scope: 'Todos los Oasis y Manantiales registrados',
          condition: 'Desenvainar armas con intención letal dentro del perímetro de agua',
          effect: 'Intervención inmediata de los centinelas y despojo de armas por 30 días',
          exceptions: 'Defensa propia autorizada por el Sumo Sacerdote',
          isActive: true
        },
        {
          id: 'LAW-SPEC-02',
          title: 'Diezmo del Agua y la Sal',
          scope: 'Todas las caravanas mercantiles en tránsito',
          condition: 'Transportar más de diez fardos de mercancía',
          effect: 'Pago del 5% del valor en sal o grano para mantenimiento comunal',
          exceptions: 'Peregrinos desarmados y médicos ambulantes',
          isActive: true
        }
      ],
      canon: {
        characters: ['Alta Sacerdotisa Zehra', 'Comandante Tariq del Velo', 'Gran Comerciante Malik'],
        facts: [
          'El Oasis Sagrado de Al-Zahra nunca se ha secado en cuatro milenios.',
          'Las armas de acero forjado en la Gran Fragua resisten la corrosión del ácido de las bestias.',
          'Nadie puede gobernar la ciudadela sin haber prestado juramento ante la piedra madre.'
        ],
        relationships: [
          'La Guardia del Velo y el Consorcio Mercantil mantienen un pacto de mutua defensa.',
          'El Culto de las Sombras opera en la clandestinidad y es perseguido por toda autoridad.'
        ],
        places: ['Oasis Sagrado de Al-Zahra', 'Ciudadela Central', 'Desierto de las Cenizas Doradas'],
        events: ['La Fiesta de las Lámparas de Aceite se celebra cada luna nueva'],
        rules: ['Ninguna criatura del Vacío puede cruzar el umbral del templo consagrado'],
        historicalData: ['Fundación de Al-Zahra en el año 12 del Calendario Solar']
      },
      narrativeRestrictions: {
        forbiddenTech: ['Pistolas, rifles, teléfonos móviles, electricidad moderna, satélites'],
        unauthorizedCharacters: ['Entidades alienígenas de ciencia ficción dura, robots humanoides'],
        incompatibleEvents: ['Destrucción nuclear, bombardeos aéreos tecnológicos, teletransportación instantánea masiva'],
        arbitraryRuleChanges: ['La magia no puede resucitar muertos sin coste ni alterar leyes de causa y efecto arbitrariamente']
      }
    }
  },
  {
    id: 'cyberpunk_distopico',
    name: 'Metrópolis Cyberpunk & Megacorporaciones',
    badge: 'Cibertecnología & Lucha Callejera',
    tone: 'Cínico & Eléctrico',
    icon: 'Cpu',
    description: 'Rascacielos monolíticos tocando nubes tóxicas, implantes neuronales, mercado negro y policías privadas al servicio del mejor postor.',
    config: {
      worldName: 'Neo-Kowloon 2099',
      version: 'v1.0',
      eraOrTone: 'Cínico, Distópico & Neón • Posguerra Corporativa',
      magicLevel: 'Nula',
      history: {
        origin: 'Nacido del colapso ecológico y bancario del siglo XXI, donde los estados soberanos vendieron sus territorios a conglomerados tecnológicos.',
        eras: 'Era del Colapso Global → Tratado de Cesión Territorial → Guerra de los Datos → Supremacía Megacorporativa (Actual)',
        keyEvents: ['La Gran Caída del Satélite Helios', 'El Alzamiento de los Hackers del Subsuelo', 'El Decreto de Registro Biométrico Universal'],
        wars: ['Tercera Guerra de Patentes', 'Purga del Sector 8'],
        catastrophes: ['Lluvia ácida persistente en niveles inferiores', 'El Virus Neural BlackICE que cegó a diez millones'],
        politicalChanges: ['Abolición de los parlamentos electos en favor de Juntas de Accionistas'],
        fundamentalEvents: ['Instalación de la Red Cuántica Orbital Neo-Grid']
      },
      geographyHierarchy: {
        continents: ['Megasector Pacífico Occidental', 'Sector Atlántico Sumergido', 'Enclave Euroasiático'],
        countries: ['Distrito Autónomo Corporativo de Neo-Kowloon', 'Zona Libre del Bajofondo', 'Archipiélago Industrial Arasaka'],
        regions: ['Nivel 100 — Penthouse y Jardines Aéreos', 'Nivel 40 — Oficinas y Comercio', 'Nivel 0 — Callejo y Alcantarillas'],
        cities: ['Sector Neón Central', 'Bahía de los Contenedores', 'Distrito Gris de la Maquinaria'],
        climates: ['Llovizna ácida perpetua con densa polución industrial', 'Microclimas climatizados artificiales en las alturas'],
        resources: ['Chips de Procesamiento Cuántico', 'Órganos Sintéticos Clonados', 'Agua Purificada Grado A', 'Baterías de Grafeno'],
        specialZones: ['Zona Muerta Sin Señal de Red', 'Plataforma Espacial de la Junta'],
        hierarchy: []
      },
      politics: {
        governments: ['Junta Corporativa de Megadirectores', 'Sindicatos Clandestinos de Chummers', 'Alianzas Callejeras'],
        factions: [
          {
            id: 'FAC-CYBER-01',
            name: 'Kurogane Heavy Industries & Security',
            ideology: 'Orden absoluto mediante vigilancia biométrica total y fuerza letal disuasoria.',
            emblemIcon: 'Shield',
            color: '#3B82F6',
            reputationWithPlayer: 'Desconfiada',
            description: 'Policía privada con exoesqueletos negros, drones cazadores y blindaje balístico pesado.',
            activeEnemies: ['FAC-CYBER-03']
          },
          {
            id: 'FAC-CYBER-02',
            name: 'Sindicato de los Cableados Libres',
            ideology: 'Descentralización de datos, código libre y liberación de las IAs restringidas.',
            emblemIcon: 'Cpu',
            color: '#10B981',
            reputationWithPlayer: 'Amistosa',
            description: 'Netrunners, contrabandistas de ciberware y técnicos callejeros que operan en los bajos fondos.',
            activeEnemies: ['FAC-CYBER-01']
          },
          {
            id: 'FAC-CYBER-03',
            name: 'Cártel de las Prótesis Rojas',
            ideology: 'Lucro despiadado mediante extorsión, tráfico de bio-piezas y drogas de interfaz neural.',
            emblemIcon: 'Skull',
            color: '#EF4444',
            reputationWithPlayer: 'Hostil',
            description: 'Banda despiadada de cíborgs modificados que controlan los callejones oscuros.',
            activeEnemies: ['FAC-CYBER-01', 'FAC-CYBER-02']
          }
        ],
        organizations: ['Gremio de Cirujanos Callejeros', 'Red de Mensajeros Físicos No Trazables'],
        relationships: [
          { id: 'REL-C1', factionAId: 'FAC-CYBER-01', factionBId: 'FAC-CYBER-03', status: 'Hostil', notes: 'Guerra territorial constante' },
          { id: 'REL-C2', factionAId: 'FAC-CYBER-02', factionBId: 'FAC-CYBER-03', status: 'Rival', notes: 'Disputa de hardware y software' }
        ],
        conflicts: ['Huelga de los técnicos de refrigeración de servidores', 'Robo de prototipos de prótesis de camuflaje'],
        hierarchies: ['Director Ejecutivo > Supervisor de Seguridad > Contratista > Suburbano sin Credencial']
      },
      economy: {
        currency: 'Créditos Cuánticos Digitales (Creds) y Billetes Físicos del Mercado Negro',
        resources: ['Ciberware militar', 'Datos bancarios encriptados', 'Filtros de pulmón'],
        trade: 'Redes P2P encriptadas y contrabando físico por ductos de desecho',
        markets: ['Mercado Negro del Puerto Flotante', 'Bazar de Hardware Usado'],
        keyGoods: ['Estimulantes de reflejos', 'Baterías de alta densidad', 'Identidades falsificadas'],
        scarcity: ['Comida natural sin sintetizar', 'Luz solar directa en la superficie'],
        wealth: '99% en manos del 0.1% en las cúpulas superiores',
        systems: ['Capitalismo salvaje no regulado con hiperinflación de bienes básicos']
      },
      religionAndCulture: {
        isApplicable: true,
        religions: ['Culto al Silicio y la Singularity', 'Transhumanismo Fanático del Código'],
        traditions: ['Brindis con sintetizador de vodka al cerrar un contrato', 'Tatuaje digital reactivo al pulso'],
        customs: ['Verificar la señal de cifrado antes de hablar en persona', 'No mirar a los ojos a guardias armados'],
        festivities: ['Noche del Apagón Conmemorativo', 'Festival del Nuevo Ciclo Fiscal'],
        taboos: ['Delatar a un netrunner que te salvó la vida', 'Dejar una prótesis defectuosa sin mantenimiento'],
        values: ['Lealtad a la tripulación local', 'Velocidad de reacción', 'Autosuficiencia'],
        culturalNorms: ['Las deudas de sangre se pagan con chips o ciberware equivalente']
      },
      technology: {
        level: 'Futurista',
        allowedTech: ['Cibernética avanzada y prótesis biónicas', 'Drones autónomos con reconocimiento facial', 'Interfaces cerebro-computadora (Brain-Drives)', 'Armas de energía electromagnética y lásers'],
        forbiddenTech: ['Magia o hechicería (no existe físicamente)']
      },
      magicSystem: {
        hasMagic: false,
        source: 'Inexistente. Todo efecto análogo se logra mediante algoritmos, nanotecnología y overclocking de prótesis.',
        rules: [],
        limitations: [],
        cost: '',
        users: '',
        types: [],
        effects: [],
        restrictions: []
      },
      physicalRules: {
        gravity: '1.0G constante en tierra.',
        biology: 'Cuerpos profundamente modificados con aleaciones de titanio, polímeros y nano-inyectores.',
        healing: 'Reparación de hardware, reemplazo de extremidades sintéticas y estimulantes coagulantes rápidos.',
        death: 'La muerte cerebral es definitiva salvo que exista una copia de seguridad cortical reciente en la nube privada.',
        travel: 'Monorrieles de levitación magnética, aerotaxis corporativos y motocicletas eléctricas de alta cilindrada.',
        time: 'Marcado por el reloj atómico central de la red corporativa.',
        space: 'Espacio físico denso y espacio virtual tridimensional simultáneo.',
        energy: 'Redes de plasma frío, baterías de litio-azufre y generadores de fisión confinada.',
        supernaturalPhenomena: 'Glitchs masivos en hologramas por tormentas electromagnéticas.'
      },
      socialRules: {
        hierarchies: 'Accionistas > Directivos > Especialistas con Licencia > Trabajadores de Planta > Parias Sin Registro',
        customs: 'El respeto se gana por la capacidad de fuego, el saldo en la cuenta o la pericia con la consola.',
        familyRelations: 'Familias fragmentadas; se forman sindicatos o hermandades de banda como unidad de apoyo.',
        socialNorms: 'El silencio sobre operaciones ajenas es la norma de supervivencia básica.',
        acceptedBehaviors: ['Autodefensa preventiva', 'Negociación agresiva', 'Mejora continua del cuerpo'],
        rejectedBehaviors: ['Ingenuidad', 'Cooperar voluntariamente con la policía corporativa'],
        protocols: ['Desactivación de ciberarmas al ingresar a clubes de alto nivel'],
        socialRoles: ['Netrunner', 'Samurái Callejero', 'Técnico de Clímax', 'Fixer de Contratos']
      },
      specialLaws: [
        {
          id: 'LAW-SPEC-CYBER-01',
          title: 'Directiva de Seguridad 404: Portación de Grado Militar',
          scope: 'Niveles 30 y superiores de Neo-Kowloon',
          condition: 'Llevar instalados implantes bélicos sin permiso corporativo',
          effect: 'Neutralización inmediata por dron centinela y confiscación de hardware',
          exceptions: 'Contratistas de seguridad privada en servicio',
          isActive: true
        }
      ],
      canon: {
        characters: ['Directora Ejecutiva Chen', 'El Hacker Fantasma "Zero"', 'Doctor de Callejón Doc Marcus'],
        facts: [
          'La red cuántica Neo-Grid monitorea todas las transacciones financieras autorizadas.',
          'El nivel cero no recibe luz solar directa desde hace más de cuarenta años.'
        ],
        relationships: ['Kurogane Industries mantiene el control absoluto de los muelles de atraque.'],
        places: ['Neo-Kowloon', 'Distrito Neón', 'Nivel Cero de Alcantarillas'],
        events: ['El toque de queda se activa automáticamente a las 02:00 AM en zonas comerciales'],
        rules: ['Nadie puede desconectarse de la red sin activar una alerta de sospecha biométrica'],
        historicalData: ['Tratado de Kowloon firmado el 14 de Noviembre de 2074']
      },
      narrativeRestrictions: {
        forbiddenTech: ['Varitas mágicas, conjuros sobrenaturales, dioses interviniendo místicamente'],
        unauthorizedCharacters: ['Elfos de bosque, magos arcanos, criaturas mitológicas'],
        incompatibleEvents: ['Milagros divinos, resurrección mágica'],
        arbitraryRuleChanges: ['Los implantes consumen energía y se averían si reciben daño balístico directo']
      }
    }
  },
  {
    id: 'fantasia_oscura',
    name: 'Fantasía Oscura & Reinos Fracturados',
    badge: 'Horror & Fe Fanática',
    tone: 'Tenebroso & Agónico',
    icon: 'Skull',
    description: 'Tierras malditas bajo la sombra del eclipse, herejías sangrientas, monstruos en los bosques y una Inquisición implacable.',
    config: {
      worldName: 'Mornheim: El Valle de los Aullidos',
      version: 'v1.0',
      eraOrTone: 'Tenebroso, Hostil & Agónico • Era de la Larga Noche',
      magicLevel: 'Baja',
      history: {
        origin: 'El Sol se apagó tras la traición de los Siete Duques; desde entonces el cielo arde con un resplandor ceniciento.',
        eras: 'Era de la Luz Antigua → La Noche del Sacrificio → Las Cruzadas del Fuego Fatuo (Actual)',
        keyEvents: ['La Herejía de los Espejos Negros', 'La Quema de los Bosques de Hueso'],
        wars: ['Purga de la Sangre Impura', 'Defensa de las Almenas de Ceniza'],
        catastrophes: ['La Peste de los Ojos Vacíos', 'Invasión de las Bestias de la Niebla'],
        politicalChanges: ['La Inquisición asume el control civil de todos los pueblos del valle'],
        fundamentalEvents: ['Consagración de las Campanas de Hierro para ahuyentar a las sombras']
      },
      geographyHierarchy: {
        continents: ['Tierras de la Penumbra'],
        countries: ['Teocracia de la Llama Santa', 'Ruinas de los Antiguos Ducados'],
        regions: ['Valle de los Aullidos', 'Paso de la Peste', 'Bosque de las Cruces'],
        cities: ['Fortaleza de San Lázaro', 'Pueblo Maldito de Graven'],
        climates: ['Frío perpetuo con nieblas tóxicas y lloviznas de ceniza'],
        resources: ['Hierro frío', 'Madera de tejo negro', 'Plata pura', 'Aceite bendito'],
        specialZones: ['Cráter de la Luna Caída'],
        hierarchy: []
      },
      politics: {
        governments: ['Tribunal Eclesiástico Militar', 'Consejo de Cazadores de Brujas'],
        factions: [
          {
            id: 'FAC-DARK-01',
            name: 'Santa Inquisición de la Llama Viva',
            ideology: 'Purificación mediante el fuego, erradicación de mutantes y obediencia ciega a las escrituras.',
            emblemIcon: 'Flame',
            color: '#B91C1C',
            reputationWithPlayer: 'Desconfiada',
            description: 'Clérigos acorazados con antorchas de brea y verdugos enmascarados.',
            activeEnemies: ['FAC-DARK-02']
          },
          {
            id: 'FAC-DARK-02',
            name: 'Akelarre de la Niebla Cárdena',
            ideology: 'Supervivencia pactando con los espíritus antiguos del bosque y venganza contra la Iglesia.',
            emblemIcon: 'Moon',
            color: '#7C3AED',
            reputationWithPlayer: 'Neutral',
            description: 'Brujas, herboristas exiliadas y cambiaformas que dominan ponzoñas ancestrales.',
            activeEnemies: ['FAC-DARK-01']
          }
        ],
        organizations: ['Orden de los Sepultureros de Hierro', 'Compañía de los Mercenarios de la Cruz'],
        relationships: [
          { id: 'REL-D1', factionAId: 'FAC-DARK-01', factionBId: 'FAC-DARK-02', status: 'Hostil', notes: 'Exterminio y caza permanente' }
        ],
        conflicts: ['Inquisidores registran casa por casa en busca de infectados con la marca'],
        hierarchies: ['Gran Inquisidor > Párroco Castigador > Centinela del Fuego > Penitente']
      },
      economy: {
        currency: 'Chelines de Plata Vieja y Trueque de Grano/Sal',
        resources: ['Plata bendecida', 'Carbón vegetal', 'Ungüentos cicatrizantes'],
        trade: 'Extremadamente peligroso; las caravanas solo viajan con escoltas fuertemente armadas',
        markets: ['Mercado de la Horca en San Lázaro'],
        keyGoods: ['Antorchas de brea', 'Plata fundida', 'Trigo limpio'],
        scarcity: ['Comida fresca no contaminada', 'Medicina'],
        wealth: 'Cofres de la Iglesia y arcones de los barones fortificados',
        systems: ['Feudalismo de subsistencia bajo economía de sitio']
      },
      religionAndCulture: {
        isApplicable: true,
        religions: ['Culto a la Llama Sagrada de los Mártires'],
        traditions: ['Quemar las ropas de los difuntos', 'Encender hogueras en cada cruce de caminos al anochecer'],
        customs: ['Persignarse al escuchar un graznido de cuervo', 'Mantener una vela encendida en la ventana'],
        festivities: ['Vigilia de los Fuegos Vivos'],
        taboos: ['Entrar a un camposanto de noche', 'Aceptar comida de un desconocido en la niebla'],
        values: ['Piedad fervorosa', 'Desconfianza protectora', 'Resistencia al dolor'],
        culturalNorms: ['Cualquier persona que muestre ojos enrojecidos o fiebre debe aislarse en el granero']
      },
      technology: {
        level: 'Medieval',
        allowedTech: ['Forja de hierro pesado', 'Balestas y trampas mecánicas', 'Alquimia básica de azufre y brea'],
        forbiddenTech: ['Electricidad', 'Maquinaria compleja', 'Armas automáticas']
      },
      magicSystem: {
        hasMagic: true,
        source: 'Pactos de sangre con deidades oscuras o milagros agónicos de la Llama Santa.',
        rules: ['Toda hechicería exige un tributo carnal o de cordura', 'La magia atrae a las sombras'],
        limitations: ['Riesgo de corrupción corporal y locura', 'Alcance muy limitado'],
        cost: 'Pérdida permanente de salud o cicatrices místicas',
        users: 'Brujas del bosque y Clérigos quemados por el fuego',
        types: ['Maldiciones de sangre', 'Amuletos de protección', 'Fuego purificador'],
        effects: ['Cauterización mágica de heridas', 'Repeler espectros con fuego sagrado'],
        restrictions: ['La magia no puede curar sin infligir dolor extremo']
      },
      physicalRules: {
        gravity: '1.0G.',
        biology: 'Humana vulnerable a la putrefacción, frío y venenos de criaturas.',
        healing: 'Lenta, dolorosa y sujeta a fiebres e infecciones mortales.',
        death: 'Frecuente y brutal. Los cuerpos no quemados pueden reanimarse si la luna está oculta.',
        travel: 'Caminatas a pie con antorchas, carretas blindadas con estacas.',
        time: 'Días breves de luz grisácea y noches interminables de oscuridad total.',
        space: 'Geometría continua pero con zonas de niebla donde las distancias parecen alargarse.',
        energy: 'El fuego es la principal fuente de supervivencia.',
        supernaturalPhenomena: 'Ecos de llanto en los vientos y espectros errantes en pantanos.'
      },
      socialRules: {
        hierarchies: 'Inquisición > Caballeros de la Fe > Campesinos > Parias Sospechosos',
        customs: 'Los extranjeros deben permanecer en el establo exterior hasta ser purificados con humo de salvia.',
        familyRelations: 'Familias unidas por el miedo común y la defensa mutua.',
        socialNorms: 'No responder a voces que llamen por tu nombre desde la oscuridad.',
        acceptedBehaviors: ['Vigilia constante', 'Oración antes de comer', 'Denunciar herejías'],
        rejectedBehaviors: ['Simpatía con los desterrados', 'Salir del pueblo de noche'],
        protocols: ['Mostrar las palmas de las manos para probar que no se tienen garras ni marcas'],
        socialRoles: ['Inquisidor', 'Cazador de Sombras', 'Boticaria Hereje', 'Campanero']
      },
      specialLaws: [
        {
          id: 'LAW-DARK-01',
          title: 'Toque de Queda de las Campanas de Ceniza',
          scope: 'Todos los pueblos del Valle de Mornheim',
          condition: 'Estar fuera de una vivienda fortificada tras sonar la campana de las ocho',
          effect: 'Apresamiento inmediato o ejecución sumaria si se portan símbolos no consagrados',
          exceptions: 'Patrullas de la Santa Inquisición con farol bendecido',
          isActive: true
        }
      ],
      canon: {
        characters: ['Gran Inquisidor Malakor', 'La Bruja del Lago Ilena', 'Capitán Vane'],
        facts: [
          'La sal bendecida quema la carne de los no-muertos como si fuera carbón ardiendo.',
          'Las campanas de San Lázaro son el único artefacto que la niebla no puede atravesar.'
        ],
        relationships: ['Nadie confía en nadie a menos que medie un juramento sellado ante la Llama.'],
        places: ['San Lázaro', 'Bosque de las Cruces', 'Valle de los Aullidos'],
        events: ['La Luna Sangrienta se eleva una vez cada tres meses'],
        rules: ['Los muertos deben ser incinerados antes de que caiga el rocío de la medianoche'],
        historicalData: ['La Noche del Sacrificio ocurrió hace ciento veinte años']
      },
      narrativeRestrictions: {
        forbiddenTech: ['Cualquier tecnología superior al siglo XIV'],
        unauthorizedCharacters: ['Seres alegres de dibujos animados, héroes intocables sin debilidades'],
        incompatibleEvents: ['Victorias fáciles sin sacrificio, curaciones milagrosas instantáneas y gratuitas'],
        arbitraryRuleChanges: ['El peligro debe sentirse real y las consecuencias permanentes']
      }
    }
  }
];

// ========================================================
// 3. SMART HELPERS & GENERADORES ASISTIDOS
// ========================================================

export const SUGGESTIONS_BANK = {
  poiTypes: [
    'Comercio / Tienda',
    'Taller artesanal',
    'Puesto de guardia',
    'Templo / Santuario',
    'Posada / Taberna',
    'Fuente / Manantial',
    'Biblioteca / Archivo',
    'Botica / Hospital',
    'Torre de vigía',
    'Almacén / Silo',
    'Forja militar',
    'Bazar ambulante'
  ],
  poiImportance: ['Baja', 'Media', 'Alta', 'Crítica'] as const,
  vibes: [
    'Tranquilo',
    'Vigilado',
    'Frenético',
    'Tenso',
    'Caótico',
    'Aislado',
    'Estancado',
    'Místico',
    'Festivo',
    'Decadente',
    'Solemne',
    'Hospitalario'
  ],
  materials: [
    'Piedra',
    'Madera',
    'Metal',
    'Hormigón',
    'Vidrio',
    'Ladrillo',
    'Adobe',
    'Mármol',
    'Materiales sintéticos',
    'Materiales fantásticos',
    'Cristales arcanos',
    'Hueso y cuero'
  ],
  socialConducts: [
    'Hospitalidad',
    'Desconfianza',
    'Miedo',
    'Solidaridad',
    'Indiferencia',
    'Competencia',
    'Honor marcial',
    'Devoción religiosa',
    'Curiosidad',
    'Hermetismo'
  ],
  connectivityTags: [
    'Patios interiores',
    'Balcones con celosías',
    'Terrazas al aire libre',
    'Azoteas comunicadas',
    'Escaleras de caracol',
    'Muralla exterior transitable',
    'Pasadizos secretos',
    'Foso con puente levadizo',
    'Embarcadero / Muelle fluvial',
    'Conductos de ventilación',
    'Pórticos con arcos'
  ],
  roomFunctions: [
    'Recepción / Vestíbulo',
    'Salón social / Estancia',
    'Dormitorio principal',
    'Taller de trabajo',
    'Biblioteca / Estudio',
    'Cocina / Fogón',
    'Comedor',
    'Despensa / Almacén',
    'Aposento de descanso íntimo',
    'Buhardilla de descanso',
    'Cámara de meditación',
    'Terraza mirador'
  ],
  worldClimates: [
    'Desértico árido con tormentas de arena',
    'Templado húmedo con neblinas matutinas',
    'Tundra glacial con auroras permanentes',
    'Tropical lluvioso con monzones estacionales',
    'Mediterráneo cálido con brisas marinas',
    'Volcánico con lloviznas de ceniza',
    'Microclima climatizado artificial (Subterráneo/Cúpula)'
  ],
  worldResources: [
    'Cristales de Maná',
    'Especias Astrales',
    'Madera de Roble Negro',
    'Hierro de Frío Puro',
    'Agua de Manantial Sagrado',
    'Chips Cuánticos',
    'Oro de Aluvión',
    'Piedra de Fuego',
    'Petróleo Refinado',
    'Seda de Gusano Estelar',
    'Plata Bendecida',
    'Aleaciones de Titanio'
  ],
  worldCurrencies: [
    'Corona de Oro / Dracma de Plata / Chelín de Cobre',
    'Créditos Cuánticos Digitales (Creds)',
    'Monedas de Plata Vieja y Trueque de Grano',
    'Lingotes de Mithril Sellados',
    'Fichas de Resina y Sal Marina'
  ],
  techLevels: [
    'Primitivo',
    'Medieval',
    'Industrial',
    'Moderno',
    'Futurista',
    'Post-tecnológico',
    'Híbrido'
  ] as const,
  forbiddenTechOptions: [
    'Pólvora y armas de fuego',
    'Inteligencia Artificial y redes cuánticas',
    'Motores de combustión interna',
    'Electricidad y telecomunicaciones',
    'Armamento nuclear o de destrucción masiva',
    'Clonación biológica y genética sintética',
    'Vehículos aéreos autopropulsados'
  ],
  magicSchools: [
    'Artes Curativas & Regeneración',
    'Canalización de Luz Solar & Sacra',
    'Manipulación Elemental (Fuego, Agua, Tierra, Viento)',
    'Encantamiento de Forja & Runas',
    'Adivinación Estelar & Cartomancia',
    'Nigromancia & Pactos de Sangre (Restringida)',
    'Ilusiones & Desplazamiento Espacial',
    'Alquimia de Transmutación'
  ],
  magicCosts: [
    'Fatiga severa y deshidratación progresiva',
    'Gasto de Puntos de Enfoque Psíquico (CEP)',
    'Tributo de gotas de sangre o cicatrices kármicas',
    'Consumo de gemas o catalizadores minerales',
    'Envejecimiento prematuro temporal tras hechizos mayores',
    'Pérdida momentánea de sentidos (ceguera o sordera breve)'
  ],
  specialLawTemplates: [
    {
      title: 'Tregua Sagrada del Agua',
      scope: 'Manantiales, Oasis y Pozos comunales',
      condition: 'Desenvainar armas con actitud amenazante',
      effect: 'Intervención inmediata de la guardia y confiscación de armas por 30 días',
      exceptions: 'Defensa propia autorizada por el tribunal de ancianos'
    },
    {
      title: 'Veda Nocturna de Hechicería',
      scope: 'Dentro de las murallas de la ciudad',
      condition: 'Canalizar conjuros ofensivos entre el ocaso y el alba',
      effect: 'Arresto inmediato y colocación de grilletes de amortiguación de maná',
      exceptions: 'Sacerdocio en ritos fúnebres autorizados'
    },
    {
      title: 'Diezmo Arancelario de Frontera',
      scope: 'Puntos de control y puertas mayores',
      condition: 'Ingresar cargamentos mercantiles superiores a 5 fardos',
      effect: 'Cobro del 5% del valor estimado en moneda local o especie',
      exceptions: 'Caravanas de ayuda humanitaria y médicos itinerantes'
    },
    {
      title: 'Prohibición de Portación Bélica Pesada',
      scope: 'Distrito civil, templos y mercados centrales',
      condition: 'Portar armas de dos manos desenfundadas o armadura completa',
      effect: 'Guardias escoltan al individuo fuera del perímetro civil',
      exceptions: 'Compañías de escolta con salvoconducto sellado'
    }
  ],
  tabooOptions: [
    'Derramar sangre viva en fuentes o aguas dulces',
    'Falsificar el sello del gobernante o templo mayor',
    'Dañar o capturar a un heraldo o emisario con bandera blanca',
    'Pronunciar el nombre del dios primordial en vano durante el eclipse',
    'Comerciar con reliquias funerarias o profanar sepulcros',
    'Usar magia para alterar la memoria o voluntad de conciudadanos'
  ],
  traditionOptions: [
    'Servir tres cuencos de té caliente antes de negociar acuerdos',
    'Encender lámparas de aceite flotantes en cada luna nueva',
    'Cubrirse el rostro ante la presencia de los ancianos del templo',
    'Hacer un brindis solemne arrojando la primera gota a la tierra',
    'Presentar un obsequio de sal y pan al cruzar el umbral de una casa ajena'
  ]
};
