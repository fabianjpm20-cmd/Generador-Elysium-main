import { RoleAttireConfig } from './types';

export const CIVIL_ROLES: Record<string, RoleAttireConfig> = {
  'Civil Genérico': {
    roleName: 'Civil Genérico',
    category: 'Civiles',
    tagline: 'Ropa cotidiana cómoda, lino natural, delantales de trabajo y accesorios utilitarios',
    description: 'Indumentaria básica y versátil de ciudadanos y habitantes comunes. Destaca por fibras transpirables, costuras sencillas y accesorios de uso diario.',
    recommendedOutfitType: 'O1 Ligera / Civil (Telas finas, lino, algodón rústico)',
    outfitTypes: [
      { id: 'O-CIVIL-LGT', name: 'O-CIVIL-LGT Túnica y Pantalón de Lino Fresco' },
      { id: 'O-CIVIL-WRK', name: 'O-CIVIL-WRK Atuendo de Trabajo con Mandil de Tela' },
      { id: 'O-CIVIL-FST', name: 'O-CIVIL-FST Traje Festivo de Algodón con Bordados' },
      { id: 'O-CIVIL-WTR', name: 'O-CIVIL-WTR Abrigo de Lana Gruesa con Cuello' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Sombreros y Pañuelos',
        pieces: [
          'P1.1 Pañuelo de Cabeza de Lino Anudado',
          'P1.2 Sombrero de Paja de Ala Ancha para el Sol',
          'P1.3 Boina Sencilla de Fieltro de Lana',
          'P1.4 Gorro de Punto Suave Acogedor',
          'P1.5 Cinta de Tela para Recoger el Cabello'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Blusas, Chalecos y Camisolas',
        pieces: [
          'P2.1 Camisola Holgada de Lino con Cuello Abierto',
          'P2.2 Chaleco de Paño con Botones de Madera',
          'P2.3 Blusa Rústica con Frunces en el Pecho',
          'P2.4 Jubón Liviano de Algodón Crudo',
          'P2.5 Jersey de Punto de Lana Suave'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Chales y Capelinas',
        pieces: [
          'P3.1 Chal de Lana Cruzado con Broche de Madera',
          'P3.2 Capelina Corta de Algodón con Capucha',
          'P3.3 Poncho Ligero de Fibras Naturales',
          'P3.4 Pañolón Estampado a los Hombros'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Manguitos y Pulseras',
        pieces: [
          'P4.1 Manguitos Protectores de Lino para Trabajo',
          'P4.2 Mangas Remangadas con Cordones de Algodón',
          'P4.3 Pulsera de Hilo Trenzado Artesanal',
          'P4.4 Mitones de Lana para Clima Frío'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Fajas y Mandiles',
        pieces: [
          'P5.1 Faja de Tela Enrollada a la Cintura',
          'P5.2 Delantal Corto con Bolsillos Frontales',
          'P5.3 Cinturón Delgado de Cuero con Hebilla Simple',
          'P5.4 Cordón de Cáñamo Anudado con Borla'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalones y Faldas',
        pieces: [
          'P6.1 Pantalón Recto de Algodón Resistente',
          'P6.2 Falda Larga Plisada de Lino con Dobladillo',
          'P6.3 Bombachos Cómodos con Ajuste en Tobillo',
          'P6.4 Falda Acampanada Midi de Algodón'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Zapatos y Sandalias',
        pieces: [
          'P7.1 Zapatos Bajos de Cuero Suave con Hebilla',
          'P7.2 Sandalias Cómodas de Suela de Esparto',
          'P7.3 Botines Flexibles de Gamuza con Cordones',
          'P7.4 Zapatillas de Tela para Casa o Taller'
        ]
      }
    ],
    materials: ['Lino orgánico transpirable', 'Algodón rústico peinado', 'Lana hilada a mano', 'Cuero suave curtido', 'Fieltro ligero'],
    finishes: ['Mate natural lavado', 'Suave cepillado', 'Tejido artesanal texturizado', 'Ligeramente gastado por uso diario'],
    armorDefenses: [
      { id: 'Ninguna', name: 'Ninguna / Ropa Civil Pura', desc: 'Prendas sin refuerzo físico para máxima comodidad' },
      { id: 'AR-CLOTH-PAD', name: 'Forro Interior Acolchado', desc: 'Capa interna de lana que mitiga el frío y roces' }
    ],
    weapons: [
      'Bastón de Paseo de Madera de Fresno',
      'Navaja Plegable de Bolsillo Multiusos',
      'Pértiga de Madera con Contera de Latón',
      'Cuchillo Pequeño de Talla y Fruta'
    ],
    relicsAndItems: [
      'Reloj de Bolsillo de Latón con Cadena',
      'Cuaderno de Notas con Lápiz de Grafito',
      'Pañuelo Bordado con Iniciales Familiares',
      'Caja Metálica de Pastillas y Especias'
    ],
    bags: [
      'Zurrón de Lona Cruzado al Pecho',
      'Bolsa de Tela de Algodón Reutilizable',
      'Limosnera de Cuero Ajustable al Cinto',
      'Morral de Bandolera con Hebilla Simple'
    ],
    equipmentFinishes: [
      'Madera de roble encerada a mano',
      'Latón envejecido con pátina cálida',
      'Cuero engrasado con acabado mate',
      'Acero pulido suave sin brillo excesivo'
    ],
    suggestedColors: [
      { id: 'lino_natural', name: 'Lino Natural / Avena', hex: '#E2D9C8' },
      { id: 'azul_indigo', name: 'Azul Índigo Lavado', hex: '#3B5998' },
      { id: 'verde_salvia', name: 'Verde Salvia / Musgo', hex: '#6B8E23' },
      { id: 'terracota', name: 'Terracota / Arcilla', hex: '#C86D51' }
    ],
    suggestedWardrobeDetails: ['Botones de madera tallada', 'Bordados florales sencillos', 'Costuras vistas contrastadas', 'Pliegues de fuelle'],
    styleNote: 'Telas naturales transpirables, patrones relajados y acabados mate orgánicos.'
  },

  'Aldeano': {
    roleName: 'Aldeano',
    category: 'Civiles',
    tagline: 'Faenas de campo, lana gruesa, sombreros de paja, delantales de cuero y herramientas de cosecha',
    description: 'Atuendo rural adaptado al trabajo agrario y ganadero, resistente a la intemperie y al barro.',
    recommendedOutfitType: 'O2 Media / Aventurero (Lana gruesa, cuero engrasado, pana)',
    outfitTypes: [
      { id: 'O-RURAL-FLD', name: 'O-RURAL-FLD Ropa de Labranza con Camisa de Estopa y Peto' },
      { id: 'O-RURAL-WTR', name: 'O-RURAL-WTR Chaquetón de Lana Cruda y Cuero' },
      { id: 'O-RURAL-HRV', name: 'O-RURAL-HRV Traje de Cosecha con Fajín y Faldón' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Sombreros Campestres',
        pieces: [
          'P1.1 Sombrero Campestre de Paja con Cinta de Cuero',
          'P1.2 Gorra de Plañidero de Pana con Visera',
          'P1.3 Pañuelo Rústico de Cuello y Cabeza',
          'P1.4 Caperuza de Lana para la Lluvia'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Blusones y Petos',
        pieces: [
          'P2.1 Blusón Rural de Estopa con Cuello Fruncido',
          'P2.2 Peto de Trabajo de Lona Reforzada',
          'P2.3 Chaleco de Piel de Oveja con Forro de Lana',
          'P2.4 Camisa Campesina de Mangas Holgadas'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Mantas y Capotes',
        pieces: [
          'P3.1 Manta Rural de Pastor Terciada al Pecho',
          'P3.2 Capote Impermeable de Lona Encerada',
          'P3.3 Capa Corta de Sarga con Capucha'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Guantes de Faena',
        pieces: [
          'P4.1 Guantes de Cuero Rudo para Espinos',
          'P4.2 Manguitos Protectores de Loneta Engrasada',
          'P4.3 Muñequeras de Cordel con Nudo de Seguridad'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Mandiles de Trabajo',
        pieces: [
          'P5.1 Mandil de Cuero Grueso para Tareas Agrarias',
          'P5.2 Cinturón Rústico con Gancho para Herramientas',
          'P5.3 Faja de Lana Gruesa para Proteger la Espalda'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalones de Faena',
        pieces: [
          'P6.1 Pantalón de Pana Gruesa con Rodilleras Reforzadas',
          'P6.2 Falda Campesina de Sarga con Doble Enagua',
          'P6.3 Calzones Rústicos de Lana con Ataduras'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Zuecos y Botas de Barro',
        pieces: [
          'P7.1 Zuecos de Madera de Aliso con Empeine de Cuero',
          'P7.2 Botas de Cuero Graso Resistentes al Barro',
          'P7.3 Alpargatas de Esparto con Cintas Negras'
        ]
      }
    ],
    materials: ['Lona de cáñamo resistente', 'Pana gruesa acanalada', 'Lana virgen sin teñir', 'Cuero graso impermeable', 'Madera de aliso'],
    finishes: ['Envejecido por el sol', 'Encerado impermeable', 'Tratado con grasa vegetal', 'Tejido áspero rústico'],
    armorDefenses: [
      { id: 'Ninguna', name: 'Ninguna / Sin Armadura', desc: 'Ropajes de campo orientados al movimiento continuo' },
      { id: 'AR-LEATHER-APRON', name: 'Mandil de Cuero Curtido', desc: 'Mitiga raspaduras, espinas y cortes de herramientas' }
    ],
    weapons: [
      'Hoz de Cosecha con Hoja Dentada Curva',
      'Horca de Fresno con Tres Puntas de Hierro',
      'Garrote Campesino de Acebuche Nudoso',
      'Guadaña de Siega de Mango Curvo'
    ],
    relicsAndItems: [
      'Cantimplora de Calabaza Curada con Tapón de Corcho',
      'Piedra de Afilar Silícea en Funda de Madera',
      'Bolsita de Semillas Sagradas de Buena Cosecha',
      'Amuleto de Paja Trenzada de la Fertilidad'
    ],
    bags: [
      'Cesta de Mimbre Tejida a Mano con Asa Reforzada',
      'Morral de Pastor de Piel de Cabra',
      'Saco de Yute Bandolera para Semillas',
      'Alforja Doble de Lona para Bestias o Espalda'
    ],
    equipmentFinishes: [
      'Hierro forjado rústico con huellas de martillo',
      'Madera de fresno aceitada sin pulir',
      'Cuero de vaca curtido al vegetal',
      'Mimbre barnizado con cera de abejas'
    ],
    suggestedColors: [
      { id: 'trigo_dorado', name: 'Trigo / Paja Dorada', hex: '#D4AF37' },
      { id: 'tierra_humeda', name: 'Marrón Tierra Fértil', hex: '#5C4033' },
      { id: 'verde_olivo', name: 'Verde Olivo / Hoja', hex: '#556B2F' },
      { id: 'rojo_oxido', name: 'Rojo Arcilla / Óxido', hex: '#8B3A2B' }
    ],
    suggestedWardrobeDetails: ['Rodilleras con parches cosidos', 'Remiendos de tela cruzada', 'Botones de asta de ciervo', 'Fibras deshilachadas'],
    styleNote: 'Siluetas resistentes, tonos ocres y de tierra, texturas de lona y cáñamo.'
  },

  'Ciudadano': {
    roleName: 'Ciudadano',
    category: 'Civiles',
    tagline: 'Moda urbana civil, paño fino, chalecos estructurados, sombreros de copa baja y guantes de paseo',
    description: 'Habitante metropolitano de vida civil y comercial. Combina prendas pulcras con estética urbana.',
    recommendedOutfitType: 'O1 Ligera / Civil (Paño fino, algodón peinado, terciopelo leve)',
    outfitTypes: [
      { id: 'O-CITIZEN-DAY', name: 'O-CITIZEN-DAY Traje de Día con Chaqueta de Paseo y Corbata' },
      { id: 'O-CITIZEN-EVN', name: 'O-CITIZEN-EVN Vestido o Levita de Tarde con Bordados' },
      { id: 'O-CITIZEN-CSL', name: 'O-CITIZEN-CSL Conjunto Urbano de Paseo y Sombrilla' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Sombreros Urbanos',
        pieces: [
          'P1.1 Bombín de Fieltro Negro con Cinta de Raso',
          'P1.2 Sombrero de Copa Baja Elegante',
          'P1.3 Tocado de Paseo con Tul y Plumas Discretas',
          'P1.4 Gorra de Paño de Ocho Paneles'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Levitas y Chaquetas',
        pieces: [
          'P2.1 Chaqueta de Paseo Corta con Solapas de Terciopelo',
          'P2.2 Chaleco Cruzado de Seda con Botones de Nácar',
          'P2.3 Blusa Estructurada con Cuello Camisero Alto',
          'P2.4 Corsé de Paseo con Ballenas Ligeras'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Sobretodos y Estolas',
        pieces: [
          'P3.1 Sobretodo de Paño Fino con Cuello de Aterciopelado',
          'P3.2 Estola Ligera de Seda y Piel Sintética',
          'P3.3 Capa Corta de Lluvia Urbana con Broche Plateado'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Guantes de Paseo',
        pieces: [
          'P4.1 Guantes de Cabritilla Fina Ajustados',
          'P4.2 Manguitos de Terciopelo con Ribete de Encaje',
          'P4.3 Pulsera de Eslabones Plateados con Guardapelo'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Fajines y Cadenillas',
        pieces: [
          'P5.1 Cadena de Reloj Leontina Cruzando el Chaleco',
          'P5.2 Cinturón Fino de Charol con Hebilla Labrada',
          'P5.3 Fajín de Raso a Juego con el Traje'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalones de Vestir y Faldas',
        pieces: [
          'P6.1 Pantalón Recto de Lana Fría con Raya Marcada',
          'P6.2 Falda de Tubo con Abertura Posterior Elegante',
          'P6.3 Falda Evasé con Pliegues Tablados'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Zapatos de Paseo y Botines',
        pieces: [
          'P7.1 Zapatos Oxford Bicolores de Cuero Pulido',
          'P7.2 Botines de Botones Laterales de Época',
          'P7.3 Zapatos de Tacón Medio con Lazo de Raso'
        ]
      }
    ],
    materials: ['Paño fino de lana peinada', 'Seda mate de sarga', 'Popelín de algodón egipcio', 'Charol brillante', 'Terciopelo liso'],
    finishes: ['Satinado pulcro', 'Planchado impecable', 'Mate refinado', 'Bordes ribeteados en seda'],
    armorDefenses: [
      { id: 'Ninguna', name: 'Ninguna / Ropa Civil Urbana', desc: 'Confección puramente estética y formal' },
      { id: 'AR-SILK-VEST', name: 'Chaleco Forrado con Seda Reforzada', desc: 'Protección ligera discreta bajo la ropa' }
    ],
    weapons: [
      'Bastón con Estoque Oculto en el Mango',
      'Paraguas Reforzado con Punta de Acero',
      'Pistola de Bolsillo Derringer Grabada',
      'Navaja de Plata Labrada con Seguro'
    ],
    relicsAndItems: [
      'Reloj de Bolsillo con Tapa de Plata Cincelada',
      'Lorgnette / Gafas de Mano Plegables',
      'Frasco de Sales Aromáticas de Cristal Tallado',
      'Tarjetero de Filigrana Plateada'
    ],
    bags: [
      'Maletín Ejecutivo de Cuero Rígido con Cierre de Llave',
      'Bolso de Mano de Terciopelo con Boquilla Metálica',
      'Portadocumentos Delgado de Piel Bovina',
      'Bolsa de Paseo con Cadena de Hombro'
    ],
    equipmentFinishes: [
      'Plata pulida espejo con grabados victorianos',
      'Cuero negro charolado de alto brillo',
      'Madera de ébano torneada y laqueada',
      'Acero niquelado brillante'
    ],
    suggestedColors: [
      { id: 'azul_marino', name: 'Azul Marino / Medianoche', hex: '#1B263B' },
      { id: 'gris_antracita', name: 'Gris Antracita / Grafito', hex: '#3E4444' },
      { id: 'vino_burdeos', name: 'Vino Tinto / Burdeos', hex: '#6A1B29' },
      { id: 'blanco_marfil', name: 'Blanco Marfil / Hueso', hex: '#FFFFF0' }
    ],
    suggestedWardrobeDetails: ['Solapas forradas en seda', 'Botones de nácar genuino', 'Ojales bordados a mano', 'Ribetes de terciopelo'],
    styleNote: 'Patronaje riguroso, elegancia civil sobria y cortes rectos y pulidos.'
  },

  'Comerciante': {
    roleName: 'Comerciante',
    category: 'Civiles',
    tagline: 'Comercio y caravanas, sedas suntuosas, bolsas múltiples, libros de cuentas y básculas de precisión',
    description: 'Atuendo representativo de mercaderes prósperos. Mezcla telas exóticas con elementos utilitarios para transportar mercancía y monedas.',
    recommendedOutfitType: 'O4 Ceremonial / Nobleza (Terciopelo, sedas exóticas, capas forradas)',
    outfitTypes: [
      { id: 'O-MRCH-SILK', name: 'O-MRCH-SILK Túnica de Brocado y Seda de Importación' },
      { id: 'O-MRCH-TRVL', name: 'O-MRCH-TRVL Ropa de Caravana con Capa de Viaje y Cuero' },
      { id: 'O-MRCH-GUILD', name: 'O-MRCH-GUILD Traje de Gremio con Medallón Comercial' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Turbantes y Gorros de Gremio',
        pieces: [
          'P1.1 Turbante de Seda con Broche de Joya Central',
          'P1.2 Gorro de Terciopelo con Ribete de Piel de Armiño',
          'P1.3 Sombrero de Mercader con Pluma de Avestruz',
          'P1.4 Monóculo de Tasador con Cadena de Oro'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Caftanes y Jubones Ricos',
        pieces: [
          'P2.1 Caftán de Seda de Damasco con Ribetes de Oro',
          'P2.2 Jubón de Terciopelo Forrado en Piel con Botones Enjoyados',
          'P2.3 Túnica Cruzada con Bolsillos Secretos Interiores',
          'P2.4 Chaleco Acolchado de Seda con Bordados de Rutas'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Mantos de Viaje y Pieles',
        pieces: [
          'P3.1 Manto Amplio de Viaje con Cuello de Zorro',
          'P3.2 Capa de Seda Pesada con Broches Gemelos de Oro',
          'P3.3 Chal Oriental con Flecos de Hilo Dorado'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Anillos y Manguitos',
        pieces: [
          'P4.1 Anillos Múltiples de Oro y Piedras Preciosas en Cada Dedo',
          'P4.2 Manguitos de Terciopelo con Filamentos Metálicos',
          'P4.3 Brazalete de Comerciante con Sellos de Aduana'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturones con Monederos',
        pieces: [
          'P5.1 Cinturón Ancho de Cuero Repujado con Múltiples Monederos',
          'P5.2 Fajín de Seda Oriental Anudado con Borlas Doradas',
          'P5.3 Tahalí para Balanza y Sellos de Cera'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalones Exóticos',
        pieces: [
          'P6.1 Pantalones Bombachos de Seda Gruesa Estampada',
          'P6.2 Calzas de Paño Fino con Bragheta Ornamentada',
          'P6.3 Falda-Pantalón de Mercader con Pliegues de Viaje'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Babuchas y Botas de Cuero',
        pieces: [
          'P7.1 Babuchas de Terciopelo Bordado con Punta Curva',
          'P7.2 Botas de Montar de Cuero Marroquí Flexible',
          'P7.3 Zapatos de Tacón Cuadrado con Hebillas de Oro'
        ]
      }
    ],
    materials: ['Seda de Damasco importada', 'Terciopelo genovés pesado', 'Cuero marroquí repujado', 'Brocado con hilo de oro', 'Pieles finas'],
    finishes: ['Brillo sedoso rico', 'Bordado en filigrana de oro', 'Cuero teñido y pulido', 'Acentos de joyas engastadas'],
    armorDefenses: [
      { id: 'Ninguna', name: 'Ninguna / Sin Armadura', desc: 'Riqueza visible para inspirar solvencia' },
      { id: 'AR-CHAIN-HIDDEN', name: 'Cota de Malla Oculta de Mithril Ligero', desc: 'Protección contra asaltantes oculta bajo la túnica' }
    ],
    weapons: [
      'Daga Ceremonial Enjoyada con Vaina de Plata',
      'Ballesta Ligera de Mano con Virolas de Oro',
      'Bastón con Pomo Pesado de Ámbar y Bronce',
      'Cimitarra de Mercader con Guarda Damasquinada'
    ],
    relicsAndItems: [
      'Balanza de Precisión de Latón en Estuche de Terciopelo',
      'Piedra de Toque para Evaluar Pureza del Oro',
      'Libro Mayor de Cuentas Encuadernado en Piel con Candado',
      'Sello de Cera Personal con Emblema Mercantil'
    ],
    bags: [
      'Bolsa de Cuero Reforzada con Malla Antirrobo',
      'Cofre Portátil de Caoba con Refuerzos de Latón',
      'Alforjas de Caravana de Tapiz Exótico',
      'Limosnera de Terciopelo con Bordados de Monedas'
    ],
    equipmentFinishes: [
      'Latón dorado pulido y brillante',
      'Madera de caoba barnizada con laca oriental',
      'Cuero teñido en azafrán con estampados en relieve',
      'Gemas cabujón engastadas en biseles dorados'
    ],
    suggestedColors: [
      { id: 'oro_imperial', name: 'Dorado Oro / Azafrán', hex: '#FFD700' },
      { id: 'purpura_tiro', name: 'Púrpura de Tiro / Amatista', hex: '#4B0082' },
      { id: 'verde_esmeralda', name: 'Verde Esmeralda Profundo', hex: '#004B23' },
      { id: 'rojo_carmesí', name: 'Rojo Carmesí / Granada', hex: '#9E0000' }
    ],
    suggestedWardrobeDetails: ['Brocados de seda con motivos geométricos', 'Hebillas macizas de latón', 'Borlas de hilo de seda y oro', 'Piedras engastadas en los botones'],
    styleNote: 'Suntuosidad ostentosa, mezclas textiles de múltiples reinos y accesorios de comercio.'
  },

  'Artesano': {
    roleName: 'Artesano',
    category: 'Civiles',
    tagline: 'Maestría gremial, cuero curtido, mandil reforzado, cartucheras de herramientas y gafas protectoras',
    description: 'Creador de manufacturas, forja, carpintería o joyería. Viste prendas resistentes preparadas para el calor, chispas y herramientas.',
    recommendedOutfitType: 'O2 Media / Aventurero (Cuero rudo, lona ignífuga, peto)',
    outfitTypes: [
      { id: 'O-ARTISAN-WRK', name: 'O-ARTISAN-WRK Mandil de Cuero Rudo y Camisa de Lona' },
      { id: 'O-ARTISAN-MAS', name: 'O-ARTISAN-MAS Traje de Maestro de Gremio con Emblema' },
      { id: 'O-ARTISAN-JEW', name: 'O-ARTISAN-JEW Atuendo de Precisión para Joyero / Relojero' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Gafas y Cintas de Taller',
        pieces: [
          'P1.1 Gafas Protectoras de Taller con Lentes de Cristal Grueso',
          'P1.2 Cinta de Cuero para Proteger la Frente del Sudor',
          'P1.3 Lupa de Aumento Articulada para el Ojo',
          'P1.4 Máscara de Respiración con Filtro de Cuero y Carbón'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Mandiles y Camisas Ignífugas',
        pieces: [
          'P2.1 Mandil Completo de Cuero Grueso Remachado con Cobre',
          'P2.2 Camisa de Lona Ignífuga de Cuello Cerrado',
          'P2.3 Chaleco de Cuero con Bolsillos Estrechos para Cinceles',
          'P2.4 Peto de Trabajo Cruzado con Tirantes de Cuero'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Hombreras de Carga',
        pieces: [
          'P3.1 Hombrera de Cuero Acolchada para Cargar Vigas y Lingotes',
          'P3.2 Capa Corta Ignífuga Resistente a Chispas',
          'P3.3 Arnés de Espalda para Sujetar Herramientas Grandes'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Guanteletes y Mangas de Cuero',
        pieces: [
          'P4.1 Guantes Gruesos de Forja de Cuero de Alce Ignífugo',
          'P4.2 Manguitos Protectores de Cuero Tachonado',
          'P4.3 Muñequeras Anchas con Imán para Sujetar Clavos'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturón de Herramientas',
        pieces: [
          'P5.1 Cinturón Grueso con Fundas para Martillo y Tenazas',
          'P5.2 Cartuchera de Cuero con Cinceles y Punzones Clasificados',
          'P5.3 Faja de Cuero con Hebilla de Forja Personalizada'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalones Reforzados',
        pieces: [
          'P6.1 Pantalón de Lona Pesada con Doble Capa en Muslos',
          'P6.2 Perneras de Cuero para Protección contra Chispas',
          'P6.3 Bombachos de Trabajo con Bolsillos Laterales'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Botas de Seguridad Reforzadas',
        pieces: [
          'P7.1 Botas de Trabajo con Puntera y Empeine Reforzado de Acero',
          'P7.2 Polainas de Cuero Grueso sobre el Calzado',
          'P7.3 Botines Flexibles con Suela de Goma Antideslizante'
        ]
      }
    ],
    materials: ['Cuero de vaca de curtición pesada', 'Lona de algodón ignífuga', 'Remaches de cobre macizo', 'Hebillas de hierro forjado', 'Vidrio templado'],
    finishes: ['Aceitado y curtido', 'Marcas de chispas y calor', 'Pátina de taller', 'Bordes biselados a mano'],
    armorDefenses: [
      { id: 'Ninguna', name: 'Ninguna / Sin Armadura', desc: 'Indumentaria de taller libre' },
      { id: 'AR-HEAVY-LEATHER', name: 'Peto y Mandil de Cuero Balístico Reforzado', desc: 'Resistente a impactos y calor extremo' }
    ],
    weapons: [
      'Martillo de Forja Pesado de Acero al Carbono',
      'Cincel de Cantero Afilado como Daga',
      'Tenazas Largas de Herrero Templadas al Fuego',
      'Sierra Manual de Precisión de Acero Templado'
    ],
    relicsAndItems: [
      'Calibrador de Precisión de Latón y Acero (Vernier)',
      'Compás de Cantero de Puntas de Acero',
      'Nivel de Burbuja de Latón en Madera de Nogal',
      'Sello de Marca de Maestro Artesano'
    ],
    bags: [
      'Caja de Herramientas de Roble con Cantoneras de Hierro',
      'Rollo de Herramientas de Cuero con Compartimentos Cilíndricos',
      'Morral de Taller con Compartimento para Lingotes',
      'Cartuchera de Cinturón para Instrumentos de Medición'
    ],
    equipmentFinishes: [
      'Acero bruñido al fuego con temple azulado',
      'Cobre martillado a mano con remaches pulidos',
      'Madera de nogal curada con aceite de linaza',
      'Cuero rudo encerado al calor'
    ],
    suggestedColors: [
      { id: 'cuero_habano', name: 'Cuero Habano / Silla', hex: '#8B4513' },
      { id: 'hierro_forja', name: 'Hierro Gris / Grafito', hex: '#333333' },
      { id: 'cobre_calido', name: 'Cobre / Bronce Rojizo', hex: '#B87333' },
      { id: 'lona_cruda', name: 'Lona Cruda / Arena', hex: '#D2B48C' }
    ],
    suggestedWardrobeDetails: ['Remaches de cobre en puntos de tensión', 'Costuras dobles con hilo encerado', 'Presillas para colgar martillo', 'Bolsillos con refuerzo de latón'],
    styleNote: 'Estética de maestría técnica, cuero aceitado, herramientas accesibles y acabados industriales artesanales.'
  }
};
