import { RoleAttireConfig } from './types';

export const MARTIAL_ROLES: Record<string, RoleAttireConfig> = {
  'B1 Berserker': {
    roleName: 'B1 Berserker',
    category: 'Marcial y Combate Pesado',
    tagline: 'Furia bárbara, pieles de oso y lobo, huesos tallados, pinturas de guerra de sangre y hachas gigantes a dos manos',
    description: 'Guerrero salvaje de tierras norteñas. Viste pieles brutas, cuero tachonado y runas sangrientas, con el torso semidescubierto para exhibir cicatrices de combate.',
    recommendedOutfitType: 'O-BARBARIAN Atuendo Bárbaro de Pieles con Hombrera de Cráneo y Taparrabos de Cuero',
    outfitTypes: [
      { id: 'O-BARBARIAN-FUR', name: 'O-BARBARIAN-FUR Manto de Piel de Lobo Ártico con Arnés de Cuero Crudo' },
      { id: 'O-BARBARIAN-GLADIATOR', name: 'O-BARBARIAN-GLADIATOR Berserker de Foso con Hombrera Metálica Dentada y Pecho Desnudo' },
      { id: 'O-BARBARIAN-JUGGERNAUT', name: 'O-BARBARIAN-JUGGERNAUT Placas de Hierro Brutales Remachadas sobre Piel de Oso' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Cráneos de Bestia y Cascos de Cuernos',
        pieces: [
          'P1.1 Cráneo de Lobo o Escalofrío Llevado como Casco / Caperuza',
          'P1.2 Casco de Hierro Forjado con Cuernos de Búfalo Macizos',
          'P1.3 Corona de Espinas y Huesos de Bestias Abatidas',
          'P1.4 Máscara de Cuero Rudo con Dientes de Sable Incrustados',
          'P1.5 Cinta de Cuero Sangrienta con Pinturas Faciales de Ceniza y Ocre'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Arneses de Cuero y Pecho Tatuado',
        pieces: [
          'P2.1 Arnés en X de Cuero de Mamut con Argollas de Hierro Forjado',
          'P2.2 Pechera de Huesos Entrelazados con Tendones de Bestia',
          'P2.3 Chaleco de Piel de Oso Desgarrado con Dientes Colgantes',
          'P2.4 Peto de Hierro Brutal Forjado a Martillo con Muescas de Hachazos',
          'P2.5 Torso Descubierto con Tatuajes Rúnicos y Cicatrices de Garrapatas'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Manto de Gran Depredador',
        pieces: [
          'P3.1 Gran Manto de Piel de Oso Cavernario que Cubre la Espalda Entera',
          'P3.2 Hombrera Gigante de Cráneo de Monstruo con Dientes Afilados',
          'P3.3 Capa Corta de Cuero Desgarrado con Salpicaduras de Sangre Seca'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Brazales de Hueso y Guanteletes de Púas',
        pieces: [
          'P4.1 Brazales de Cuero Grueso con Púas de Hierro Oxidado',
          'P4.2 Envolturas de Piel y Cuerda en los Antebrazos con Huesos Tallados',
          'P4.3 Guanteletes Rústicos de Cuero sin Dedos con Nudillos Reforzados'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturón de Trofeos y Taparrabos',
        pieces: [
          'P5.1 Cinturón Ancho de Cuero de Bestia con Calaveras y Mandíbulas Trofeo',
          'P5.2 Faja de Piel de Lobo Sujeta con Argollas de Bronce Macizo',
          'P5.3 Tahalí Doble para Hachas de Mano Cruzadas en la Espalda'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalones de Piel y Perneras',
        pieces: [
          'P6.1 Pantalón de Piel de Ciervo Rústico con Costuras Gruesas de Tendón',
          'P6.2 Faldón / Taparrabos de Cuero y Piel con Flecos Sangrientos',
          'P6.3 Perneras de Cuero Curtido con Rodilleras de Hueso Tallado'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Botas de Piel de Oso y Nieve',
        pieces: [
          'P7.1 Botas de Piel de Oso Cavernario con Cintas de Cuero Cruzadas',
          'P7.2 Botines de Cuero Crudo con Garras de Bestia en la Suela',
          'P7.3 Envolturas de Lana y Piel con Tobilleras de Dientes'
        ]
      }
    ],
    materials: ['Piel de oso cavernario no tratada', 'Cuero crudo de buey salvaje', 'Huesos y colmillos de monstruos', 'Hierro forjado rudo con huellas de maza', 'Tendones y cuerdas de cáñamo'],
    finishes: ['Desgarrado y ensangrentado', 'Piel bruta con pelo natural', 'Hierro con óxido y marcas de combate', 'Hueso amarilleado y grabado'],
    armorDefenses: [
      { id: 'AR-BEAST-HIDE', name: 'Pieles de Bestia y Densidad Muscular', desc: 'Amortigua golpes contundentes por puro grosor y resistencia salvaje' },
      { id: 'AR-RAGE-RUNES', name: 'Marcas Rúnicas de Furia Inmortal', desc: 'Magia de sangre que ignora el dolor y reduce heridas mortales' },
      { id: 'AR-IRON-PLATES', name: 'Placas de Hierro Remachadas', desc: 'Blindaje tosco y pesado contra estocadas frontales' }
    ],
    weapons: [
      'Gran Hacha Doble a Dos Manos con Filo Dentado y Muescas',
      'Espadón Bárbaro de Hierro Macizo con Mango Forrado en Piel',
      'Par de Hachas de Mano de Guerra Arrojadizas',
      'Maza de Púas Gigante con Cabeza de Meteorito',
      'Lanza de Caza de Mamut con Punta de Sílex Gigante'
    ],
    relicsAndItems: [
      'Collar de Colmillos de Gran Lobo Alfa Abatido en Solitario',
      'Cuerno de Guerra para Rugido de Carga Bársarka',
      'Frasco de Hidromiel de Raíces Negras para Entrar en Trance Feroz',
      'Tótem de Piedra Tallada con Forma de Oso Rugiente'
    ],
    bags: [
      'Zurrón de Piel de Jabalí con Cierre de Colmillo',
      'Morral de Cuero Crudo para Carne Seca y Setas de Furia',
      'Funda Dorsal Gigante de Piel para Gran Hacha',
      'Bolsa de Tendones para Trofeos de Cabezas Enemigas'
    ],
    equipmentFinishes: [
      'Hierro negro forjado al carbón con filos desgastados y muescas',
      'Mango de roble silvestre envuelto en tiras de cuero ensangrentadas',
      'Hueso pulido por la intemperie con runas chamánicas grabadas a fuego',
      'Bronce antiguo golpeado con pátina de sangre seca'
    ],
    suggestedColors: [
      { id: 'marron_oso', name: 'Piel de Oso / Pardo', hex: '#451A03' },
      { id: 'rojo_sangre', name: 'Rojo Sangre / Carmín Bárbaro', hex: '#7F1D1D' },
      { id: 'gris_hierro_salvaje', name: 'Gris Hierro Forja', hex: '#262626' },
      { id: 'blanco_hueso', name: 'Blanco Hueso / Ceniza', hex: '#E7E5E4' }
    ],
    suggestedWardrobeDetails: ['Pinturas de guerra en rostro y torso en ocre y ceniza', 'Collares de garras y cráneos pequeños de trofeo', 'Bordes de piel deshilachados y salvajes', 'Remaches de hierro toscos en arneses'],
    styleNote: 'Brutalidad primitiva, pieles sin curtir, cicatrices de guerra y armas colosales a dos manos.'
  },

  'B2 Caballero de Placas': {
    roleName: 'B2 Caballero de Placas',
    category: 'Marcial y Combate Pesado',
    tagline: 'Honor caballeresco, armadura gótica completa de acero pulido, sobreveste heráldica, yelmo con penacho y mandoble',
    description: 'Paladín o señor de la guerra con armadura completa de placas articuladas (Maximilian o Gótica). Símbolo de invulnerabilidad, heráldica y disciplina militar.',
    recommendedOutfitType: 'O-KNIGHT Armadura Completa de Placas Góticas de Acero con Sobreveste Heráldica',
    outfitTypes: [
      { id: 'O-KNIGHT-GOTHIC', name: 'O-KNIGHT-GOTHIC Armadura Gótica Flotada con Filos y Puntas Articuladas' },
      { id: 'O-KNIGHT-CRUSADER', name: 'O-KNIGHT-CRUSADER Cota de Malla Completa con Gran Yelmo de Cubo y Tabardo de Cruz' },
      { id: 'O-KNIGHT-CEREMONIAL', name: 'O-KNIGHT-CEREMONIAL Armadura de Justas con Grabados en Pan de Oro y Penacho' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Yelmos de Celada y Barbutas',
        pieces: [
          'P1.1 Yelmo de Celada Gótica con Visera Móvil y Ranuras de Respiración',
          'P1.2 Gran Yelmo de Cruzado Cilíndrico con Ranura en T',
          'P1.3 Barbuta de Acero de Estilo Italiano con Borde Pulido',
          'P1.4 Cresta / Penacho de Plumas Escarlatas y Doradas para el Yelmo',
          'P1.5 Cofia de Malla de Anillas Remachadas Protegiendo Cuello y Cabeza'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Peto Gótico y Guardarrenes',
        pieces: [
          'P2.1 Peto de Acero de Doble Curvatura con Cresta Central (Stop-Rib)',
          'P2.2 Sobreveste / Tabardo de Lino con el Blasón Heráldico Bordado',
          'P2.3 Gorguera Articulada de Cuello de Acero con Cierre de Pasador',
          'P2.4 Brigantina de Placas de Acero Remachadas bajo Terciopelo Azul Real',
          'P2.5 Gambesón Acolchado Interior con Costuras Verticales de Lana'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Hombreras de Justa y Capas Heráldicas',
        pieces: [
          'P3.1 Hombreras de Placas Asimétricas (Pauldrons) con Guardacaras',
          'P3.2 Espaldar Completo de Acero Articulado con Enlace de Cintura',
          'P3.3 Capa Heráldica Larga Forrada de Seda Sujeta con Broches de León'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Guanteletes de Manopla y Brazales',
        pieces: [
          'P4.1 Guanteletes de Acero de Dedos Articulados con Nudillos en Punta',
          'P4.2 Brazales Completos (Rerebraces y Vambraces) con Codales de Ala',
          'P4.3 Manoplas de Justa de Acero Pesado de Una Sola Pieza'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturón de Caballería y Fauld',
        pieces: [
          'P5.1 Fauld de Láminas de Acero Articuladas Protegiendo el Abdomen',
          'P5.2 Cinturón Militar de Caballero con Placas de Bronce Dorado y Eslabones',
          'P5.3 Tahalí para Espada Bastarda con Vaina Forrada en Cuero Real'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Escarcelas y Grebas Completas',
        pieces: [
          'P6.1 Escarcelas (Tassets) de Placas Colgando de la Cintura a los Muslos',
          'P6.2 Quijotes y Rodilleras (Poleyns) con Aletas Laterales Articuladas',
          'P6.3 Grebas Anatómicas de Acero Cerradas Cubriendo Pantorrillas'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Escarpines de Acero Articulados',
        pieces: [
          'P7.1 Escarpines (Sabatons) de Placas Articuladas con Puntera Ancha (Pata de Oso)',
          'P7.2 Escarpines Góticos con Puntera Larga Afilada (Poulaine de Acero)',
          'P7.3 Botas de Montar de Cuero Rígido con Espuelas Doradas de Caballero'
        ]
      }
    ],
    materials: ['Acero al carbono templado y pulido', 'Latón dorado para grabados y rebordes', 'Cota de malla remachada 4 en 1', 'Lino pesado para sobreveste', 'Cuero grueso para correajes'],
    finishes: ['Pulido a espejo brillante', 'Grabado al aguafuerte con motivos florales', 'Rebordes de latón dorado', 'Acero pavonado azul medianoche'],
    armorDefenses: [
      { id: 'AR-FULL-PLATE', name: 'Armadura Completa de Placas Góticas', desc: 'Máxima protección física contra proyectiles, cortes y estocadas' },
      { id: 'AR-BLESSED-STEEL', name: 'Acero Bendecido con Óleos Sagrados', desc: 'Resistencia incrementada contra corrupción y magia oscura' }
    ],
    weapons: [
      'Espada Larga Bastarda (Hand-and-a-Half) con Gavilanes en Cruz y Pomo Esférico',
      'Mandoble Zweihänder con Paradas de Diente de Jabalí y Empuñadura Larga',
      'Lanza de Justa con Guarda de Mano de Acero y Estandarte',
      'Maza de Armas de Aletas de Acero Templado (Flanged Mace)',
      'Escudo de Lágrima / Escudo de Armas Triangular de Madera y Acero'
    ],
    relicsAndItems: [
      'Sellos de Cera con Voto de Cruzada Colgando del Peto (Purity Seals)',
      'Relicario Portátil de Plata con Fragmento de Hueso de Santo',
      'Pañuelo de la Dama de Seda Bordado Llevado en la Hombrera',
      'Piedra de Afilar de Caballero y Frasco de Aceite para Pulir Armaduras'
    ],
    bags: [
      'Funda de Cuero Acolchada para Escudo de Armas',
      'Bolsa de Cuero Reforzada de Cinturón para Monedas de Oro de Honor',
      'Alforjas de Montura de Caballo de Guerra de Cuero Rígido',
      'Estuche Rígido para el Yelmo con Forro de Lana'
    ],
    equipmentFinishes: [
      'Acero bruñido a espejo impecable con reflejos plateados',
      'Rebordes y florituras de latón dorado al fuego',
      'Empuñadura de espada envuelta en alambre de plata y cuero negro',
      'Escudo pintado con blasón en esmalte brillante al óleo'
    ],
    suggestedColors: [
      { id: 'acero_brillante', name: 'Acero Pulido / Plata', hex: '#E2E8F0' },
      { id: 'azul_real_caballero', name: 'Azul Real Heráldico', hex: '#1D4ED8' },
      { id: 'oro_heráldico', name: 'Oro / Latón Dorado', hex: '#F59E0B' },
      { id: 'rojo_carmesí_orden', name: 'Rojo Carmesí Orden Militar', hex: '#B91C1C' }
    ],
    suggestedWardrobeDetails: ['Placas con acanaladuras góticas funcionales (Fluting)', 'Sobreveste con el león o águila heráldica bordada', 'Correas de cuero con hebillas de flor de lis', 'Penacho de plumas ondulando al viento sobre el yelmo'],
    styleNote: 'Caballerosidad imponente, acero gótico milimétrico, simetría heráldica y dignidad marcial.'
  },

  'B3 Duelista': {
    roleName: 'B3 Duelista',
    category: 'Marcial y Combate Pesado',
    tagline: 'Esgrima de precisión, jubón de cuero ajustado, capa terciada al hombro, guantelete de parada y florete letal',
    description: 'Maestro de la estocada y el honor personal. Ropajes elegantes de corte renacentista o mosquetero, diseñados para giros rápidos, fintas y paradas milimétricas.',
    recommendedOutfitType: 'O-DUELIST Jubón de Cuero Noble con Mangas Abullonadas y Capa Corta Terciada',
    outfitTypes: [
      { id: 'O-DUELIST-RAPIER', name: 'O-DUELIST-RAPIER Traje Renacentista con Jubón Ajustado, Cuello de Encaje y Capa' },
      { id: 'O-DUELIST-MUSKETEER', name: 'O-DUELIST-MUSKETEER Atuendo de Mosquetero con Sombrero de Pluma y Casaca Cruzada' },
      { id: 'O-DUELIST-FENICER', name: 'O-DUELIST-FENICER Chaleco de Esgrima Liviano con Pechera Reforzada' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Sombreros con Pluma y Antifaces',
        pieces: [
          'P1.1 Sombrero Mosquetero de Fieltro con Ala Doblada y Gran Pluma de Avestruz',
          'P1.2 Sombrero de Ala Ancha con Cinta de Cuero y Hebilla Plateada',
          'P1.3 Antifaz de Seda Negra de Duelista Nocturno',
          'P1.4 Cinta de Pelo de Terciopelo para Despejar la Visión'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Jubones de Cuero y Camisas de Esgrima',
        pieces: [
          'P2.1 Jubón de Cuero Fino Ajustado con Costuras en Diagonal y Ojales Metálicos',
          'P2.2 Camisa de Esgrima de Lino Blanco con Cuello Desbocado y Cordones',
          'P2.3 Casaca Cruzada de Paño con Solapas Bordadas en Hilo de Plata',
          'P2.4 Corpiño / Chaleco de Cuero con Media Placa de Acero sobre el Corazón'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Capas Terciadas y Capotillos',
        pieces: [
          'P3.1 Capa Corta Terciada sobre el Hombro Izquierdo (Usada para Envolver el Brazo Defensivo)',
          'P3.2 Capotillo de Esgrima con Forro de Seda en Contraste',
          'P3.3 Manto Ligero de Satén con Broche de Filigrana'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Guantelete de Parada y Mangas Acuchilladas',
        pieces: [
          'P4.1 Guante de Esgrima de Cuero Fino para la Mano de la Espada',
          'P4.2 Guantelete de Malla Reforzado para la Mano Izquierda (Main Gauche)',
          'P4.3 Mangas Acuchilladas Desmontables con Cintas de Raso',
          'P4.4 Puños de Encaje Plisado Asomando por las Mangas'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Tahalí Bandolera de Ropera',
        pieces: [
          'P5.1 Tahalí Cruzado al Pecho de Cuero Repujado con Soporte para Ropera y Daga',
          'P5.2 Fajín de Seda Escarlata o Azul Marino con Nudo Lateral',
          'P5.3 Cinturón Doble con Hebillas de Plata Cincelada'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Calzones de Esgrima y Bombachos',
        pieces: [
          'P6.1 Calzones de Paño Fino Ajustados a la Rodilla con Botones',
          'P6.2 Bombachos Cortos con Cuchilladas Elegantes',
          'P6.3 Pantalones de Montar Flexibles con Refuerzo Interior de Cuero'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Botas de Mosquetero de Caña Vuelta',
        pieces: [
          'P7.1 Botas Altas de Caña Vuelta de Cuero Flexible con Espuelas Plateadas',
          'P7.2 Zapatos de Baile y Esgrima con Suela de Cuero Antideslizante',
          'P7.3 Botines Victorianos con Botones Laterales y Puntera Afilada'
        ]
      }
    ],
    materials: ['Cuero de ternera suave y elástico', 'Lino holandés almidonado', 'Terciopelo de seda', 'Acero flexible toledano', 'Plumas de avestruz seleccionadas'],
    finishes: ['Cuero pulido al guante', 'Bordados en hilo de plata brillante', 'Satinado en capas interiores', 'Plumas vaporosas y ligeras'],
    armorDefenses: [
      { id: 'AR-DUELIST-LEATHER', name: 'Jubón de Cuero Reforzado y Capa Envuelta', desc: 'Protección ágil basada en desvíos de tela y absorción de filo' },
      { id: 'AR-HEART-GUARD', name: 'Placa de Corazón de Acero Toledano', desc: 'Protege órganos vitales sin penalizar la velocidad de estocada' }
    ],
    weapons: [
      'Espada Ropera (Rapier) con Guarnición de Cazoleta Calada en Filigrana de Plata',
      'Daga de Mano Izquierda (Main-Gauche) con Gavilanes Curvos y Rompe-Espadas',
      'Florete de Duelo Ligero de Acero Flexible de Toledo',
      'Pistola de Chispa de Duelo con Cañón Estriado y Grabados de Marfil',
      'Estoque Fino de Paseo con Pomo de Cabeza de Águila'
    ],
    relicsAndItems: [
      'Cartel de Desafío de Duelo Sellado en Cera con el Nombre del Rival',
      'Par de Guantes de Seda Blanca para Arrojar en Reto de Honor',
      'Frasco de Ungüento Cicatrizante Rápido de Esgrimidor',
      'Reloj de Bolsillo para Cronometrar los Asaltos de Duelo'
    ],
    bags: [
      'Funda Rígida Forrada en Terciopelo para Par de Espadas Roperas',
      'Estuche de Madera de Nogal para Pistolas de Duelo Gemelas',
      'Limosnera de Cuero Fino con Monedas de Apuestas de Duelo',
      'Bolsa Bandolera de Seda para Capas de Repuesto'
    ],
    equipmentFinishes: [
      'Guarnición de cazoleta de acero cincelado en filigrana de flores',
      'Madera de nogal con incrustaciones de hilo de plata',
      'Cuero coñac con cantos pulidos y costuras blancas',
      'Hoja de acero con canaladura central y grabado del lema familiar'
    ],
    suggestedColors: [
      { id: 'negro_mosquetero', name: 'Negro Noble / Terciopelo', hex: '#0F172A' },
      { id: 'rojo_carmesi_fajin', name: 'Rojo Carmesí / Fajín', hex: '#BE123C' },
      { id: 'blanco_pluma', name: 'Blanco Lino / Pluma', hex: '#F8FAFC' },
      { id: 'oro_toledo', name: 'Oro Viejo / Latón Toledano', hex: '#EAB308' }
    ],
    suggestedWardrobeDetails: ['Guarnición de cazoleta intrincadamente calada', 'Gran pluma curvándose sobre el ala del sombrero', 'Capa doblada con maestría sobre un hombro', 'Camisa abierta en el pecho mostrando cadena de plata'],
    styleNote: 'Agilidad aristocrática, elegancia de esgrima renacentista, ropajes dinámicos y armas de precisión.'
  },

  'B4 Gladiador': {
    roleName: 'B4 Gladiador',
    category: 'Marcial y Combate Pesado',
    tagline: 'Espectáculo de arena, manica de bronce en brazo hábil, casco crestado con rejilla, subligaculum y red de tridente',
    description: 'Luchador de coliseos y fosos de sangre. Su armadura es asimétrica y teatral (estilo Mirmillón, Retiario o Tracio), diseñada para emocionar al público y proteger puntos críticos.',
    recommendedOutfitType: 'O-GLADIATOR Atuendo de Arena con Manica de Bronce, Casco Crestado y Taparrabos',
    outfitTypes: [
      { id: 'O-GLADIATOR-MURMILLO', name: 'O-GLADIATOR-MURMILLO Gladiador Mirmillón con Gran Casco de Pez, Escudo Rectangular y Gladius' },
      { id: 'O-GLADIATOR-RETIARIUS', name: 'O-GLADIATOR-RETIARIUS Retiario con Manica, Galerus de Hombro, Tridente y Red de Pesca' },
      { id: 'O-GLADIATOR-THRAX', name: 'O-GLADIATOR-THRAX Tracio con Dos Grebas Altas, Sica Curva y Escudo Redondo Pequeño' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Cascos de Arena con Rejilla y Cresta',
        pieces: [
          'P1.1 Casco de Bronce de Mirmillón con Gran Cresta de Pez y Visera de Rejilla Perforada',
          'P1.2 Casco de Tracio con Borde Ancho y Cabeza de Grifo Tallada en la Cresta',
          'P1.3 Corona de Hojas de Roble de Campeón de la Arena',
          'P1.4 Máscara Facial de Bronce Pulido con Boca Rictus Burlona'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Pecho Descubierto con Arnés de Cuero',
        pieces: [
          'P2.1 Arnés Cruzado de Cuero Bronceado sobre Pecho Musculoso Descubierto',
          'P2.2 Galerus (Placa de Hombro Rectangular Curva de Bronce) para Proteger Cuello',
          'P2.3 Pectoral Mínimo de Cuero Tachonado Protegiendo el Corazón',
          'P2.4 Envolturas de Lino Acolchado Cruzando el Pecho'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Capas Cortas y Placas de Hombro',
        pieces: [
          'P3.1 Galerus de Bronce de Retiario Llevado en el Hombro Izquierdo',
          'P3.2 Capa Corta de Arena Teñida en Sangre de Foso',
          'P3.3 Manto de Campeón de Terciopelo Escarlata para la Entrada Triunfal'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Manica de Placas y Guantelete de Cuero',
        pieces: [
          'P4.1 Manica (Protector Segmentado de Placas de Bronce o Cuero) Cubriendo el Brazo Hábil',
          'P4.2 Envolturas Acolchadas de Lino (Fasciae) en el Antebrazo con Correas',
          'P4.3 Cestus (Guantelete de Cuero con Púas de Plomo para Pugilismo)',
          'P4.4 Brazalete de Campeón de Oro Grabado con Laureles'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Balteus Ancho de Bronce',
        pieces: [
          'P5.1 Balteus (Cinturón Ancho de Cuero Grueso Cubierto de Placas de Bronce Repujado)',
          'P5.2 Subligaculum (Taparrabos de Lino Sujeto por el Cinturón de Arena)',
          'P5.3 Faja de Cuero con Gancho para Red de Pesca'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Faldones de Arena y Grebas Asimétricas',
        pieces: [
          'P6.1 Faldón Corto de Lino Teñido con Pliegues de Movilidad',
          'P6.2 Greba Alta de Bronce en la Pierna Izquierda (Ocreas) hasta la Rodilla',
          'P6.3 Fasciae (Envolturas de Lino Grueso) Protegiendo Espinillas y Muslos'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Caligae de Cuero con Clavos de Arena',
        pieces: [
          'P7.1 Caligae (Sandalias Militares de Tiras de Cuero con Clavos de Tracción para la Arena)',
          'P7.2 Sandalias Gladiatorias con Tiras Cruzadas hasta la Pantorrilla',
          'P7.3 Pies Descalzos con Envolturas de Lino en Tobillos'
        ]
      }
    ],
    materials: ['Bronce martillado y repujado', 'Cuero grueso de toro', 'Lino crudo almidonado', 'Hierro para clavos y remaches', 'Cerdas de caballo para penachos'],
    finishes: ['Bronce dorado brillante por el sol', 'Cuero engrasado con arena incrustada', 'Marcas de arañazos y tajos de arena', 'Lino teñido en carmesí'],
    armorDefenses: [
      { id: 'AR-GLADIATOR-MANICA', name: 'Manica Segmentada y Galerus de Bronce', desc: 'Protección asimétrica optimizada para desviar armas a distancia y de corte' },
      { id: 'AR-COLOSSEUM-FAVOR', name: 'Bendición de la Multitud Rugiente', desc: 'Aumenta la adrenalina y resistencia al dolor frente a espectadores' }
    ],
    weapons: [
      'Gladius (Espada Corta de Arena con Hoja Ancha y Pomo de Hueso)',
      'Tridente de Combate de Tres Puntas con Púas Barbeladas',
      'Red Lastrada de Retiario con Plomadas de Bronce',
      'Sica (Espada Curva Tracia de Filo Interior Letal)',
      'Scutum / Escudo Rectangular Curvo con Umbo Central de Bronce'
    ],
    relicsAndItems: [
      'Rudis (Espada de Madera de la Libertad Otorgada por el César)',
      'Frasco de Arena Mezclada con Sangre de su Primer Oponente Vencido',
      'Laurel de Oro Macizo de la Victoria en el Coliseo',
      'Strigil de Bronce y Frasco de Aceite para Limpiar Arena y Sudor del Cuerpo'
    ],
    bags: [
      'Bolsa de Lona para Guardar la Red y Dagas de Arena',
      'Zurrón de Cuero para Monedas de Premio del Emperador',
      'Funda de Piel para el Casco Crestado',
      'Porta-Gladius de Cinturón con Apliques de Bronce'
    ],
    equipmentFinishes: [
      'Bronce pulido deslumbrante con grabados de bestias mitológicas',
      'Hierro de hoja afilado al máximo con canaladuras de sangre',
      'Madera tallada con empuñadura anatómica de hueso pulido',
      'Cuero de toro con remaches dorados'
    ],
    suggestedColors: [
      { id: 'bronce_solar', name: 'Bronce Solar / Oro de Arena', hex: '#D97706' },
      { id: 'rojo_gladiador', name: 'Rojo Carmesí de Coliseo', hex: '#991B1B' },
      { id: 'cuero_toro', name: 'Cuero de Toro / Tostado', hex: '#78350F' },
      { id: 'arena_dorada', name: 'Arena Dorada / Lino', hex: '#FBBF24' }
    ],
    suggestedWardrobeDetails: ['Gran cresta de cerdas rojas en el casco de bronce', 'Rejilla perforada que oculta los ojos en sombras', 'Cinturón ancho lleno de placas de bronce decoradas con victorias', 'Manica segmentada de brillo reflectante en el brazo que empuña el arma'],
    styleNote: 'Asimetría gladiatoria, bronce resplandeciente, torso descubierto con arnés y estética triunfal de coliseo.'
  },

  'B5 Samurái Pesado': {
    roleName: 'B5 Samurái Pesado',
    category: 'Marcial y Combate Pesado',
    tagline: 'Honor del código Bushido, armadura O-Yoroi de placas laqueadas, casco kabuto con cuernos maedate, máscara menpo y katana',
    description: 'Guerrero aristocrático del Japón feudal con armadura completa de placas de hierro y cuero laqueado unidas por cordones de seda (Odoshi).',
    recommendedOutfitType: 'O-SAMURAI Armadura Completa O-Yoroi Laqueada con Kabuto, Menpo y Jinbaori',
    outfitTypes: [
      { id: 'O-SAMURAI-OYOROI', name: 'O-SAMURAI-OYOROI Armadura O-Yoroi Clásica con Gran Sode y Cordones de Seda' },
      { id: 'O-SAMURAI-DO-MARU', name: 'O-SAMURAI-DO-MARU Armadura Ligera Do-Maru para Combate a Pie con Katana' },
      { id: 'O-SAMURAI-JINBAORI', name: 'O-SAMURAI-JINBAORI Chaleco Jinbaori de Seda sobre Armadura con Emblema del Clan' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Kabuto, Menpo y Cuernos Maedate',
        pieces: [
          'P1.1 Casco Kabuto de Placas de Acero con Gran Cresta Maedate de Luna Creciente o Cuernos de Ciervo',
          'P1.2 Máscara Menpo de Hierro con Expresión de Demonio Oni y Bigote de Cerda',
          'P1.3 Shikoro (Protector de Nuca Articulado de Placas Laqueadas) Cayendo del Kabuto',
          'P1.4 Cinta Hachimaki Blanca con Disco Solar Rojo'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Do (Peto) y Jinbaori',
        pieces: [
          'P2.1 Do (Coraza de Placas de Hierro Laqueadas Unidas por Cordones de Seda Odoshi)',
          'P2.2 Jinbaori (Chaleco sin Mangas de Brocado de Seda de Alto Rango con Blasón Mon)',
          'P2.3 Kimono Interior de Seda (Shitagi) con Cuello Cruzado Impecable',
          'P2.4 Kusari (Cota de Malla Japonesa Ligera) bajo las Placas'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / O-Sode (Grandes Hombreras) y Sashimono',
        pieces: [
          'P3.1 O-Sode (Grandes Hombreras Escudo de Placas de Seda y Metal)',
          'P3.2 Sashimono (Estandarte Dorsal Cuadrado con el Emblema del Clan en Palo de Bambú)',
          'P3.3 Capa Horo Inflable de Seda para Detener Flechas por la Espalda'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Kote (Mangas Blindadas)',
        pieces: [
          'P4.1 Kote (Mangas Blindadas de Seda con Placas de Acero y Cota de Malla Kusari)',
          'P4.2 Tekko (Protectores de Dorso de Mano de Acero en Forma de Pétalo)',
          'P4.3 Guantes de Cuero de Ciervo Suave para Disparo con Arco'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Obi y Soporte de Vainas Daisho',
        pieces: [
          'P5.1 Obi Ancho de Seda Gruesa Sujetando el Conjunto Daisho (Katana y Wakizashi)',
          'P5.2 Kusazuri (Faldón de Placas Articuladas en Cuatro o Seis Secciones Colgando de la Coraza)',
          'P5.3 Cordón Sageo de Seda Trenzada Decorando la Vaina'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Haidate (Musleras) y Hakama',
        pieces: [
          'P6.1 Haidate (Musleras de Placas de Metal y Seda en Forma de Delantal Dividido)',
          'P6.2 Hakama Plisada de Seda Gruesa de Combate con Piernas Anchas',
          'P6.3 Pantalones de Montar con Cintas de Ajuste en la Rodilla'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Suneate (Espinilleras) y Waraji',
        pieces: [
          'P7.1 Suneate (Espinilleras de Placas de Acero y Seda con Protector de Rodilla)',
          'P7.2 Calzado Kutsura de Piel de Oso para Invierno de Samurái',
          'P7.3 Sandalias Waraji de Paja de Arroz sobre Calcetines Tabi Divididos'
        ]
      }
    ],
    materials: ['Acero laqueado en laca urushi (Negro o Rojo Carmín)', 'Cordones de seda de colores vivos (Odoshi)', 'Cuero de ciervo curtido (Kawa)', 'Brocado de seda con hilos dorados', 'Paja de arroz tejida'],
    finishes: ['Laca brillante urushi impermeable', 'Tejido odoshi geométrico multicolor', 'Grabados dorados del escudo mon', 'Hierro forjado oscurecido'],
    armorDefenses: [
      { id: 'AR-OYOROI-PLATES', name: 'Armadura O-Yoroi de Acero Laqueado', desc: 'Defensa excepcional contra flechas, cortes de katana y lanzas' },
      { id: 'AR-BUSHIDO-SPIRIT', name: 'Espíritu Indomable del Código Bushido', desc: 'Inmunidad a la intimidación y reducción de daño crítico' }
    ],
    weapons: [
      'Katana de Acero Tamahagane Plegado Mil Veces con Línea de Temple Hamon Ondulada',
      'Wakizashi de Acompañamiento en Vaina Laqueada a Juego',
      'Yari (Lanza Japonesa de Hoja Recta de Doble Filo)',
      'Naginata (Alabarda Curva con Hoja Esbelta)',
      'Yumi (Arco Asimétrico Gigante de Bambú y Madera)'
    ],
    relicsAndItems: [
      'Sello Inkan de Madera Noble con el Nombre del Linaje del Samurái',
      'Abanico de Guerra Tessen de Varillas de Hierro y Papel Dorado',
      'Caja Inro de Tres Niveles de Laca con Cordón de Jade y Netsuke Tallado',
      'Juego de Piedras de Pulido de Katana y Aceite de Camelia Sagrado'
    ],
    bags: [
      'Funda de Seda Brocada para Portar la Katana fuera de Combate',
      'Carcaj Yebira de Bambú y Laca para Flechas del Yumi',
      'Cofre Gusoku Bitsu de Madera Laqueada para Guardar la Armadura Completa',
      'Bolsa Kinchaku de Seda Colgando del Obi'
    ],
    equipmentFinishes: [
      'Laca urushi negra brillante con polvo de oro (Makie)',
      'Filo de acero tamahagane con patrón de temple hamon visible y nítido',
      'Tsuba (guardamano) de hierro cincelada con olas o dragones',
      'Empuñadura tsuka forrada en piel de raya blanca (Same) con cordón negro'
    ],
    suggestedColors: [
      { id: 'laca_negra', name: 'Laca Negra Urushi / Ébano', hex: '#0A0A0A' },
      { id: 'rojo_shinto', name: 'Rojo Carmesí Shinto / Laca', hex: '#B91C1C' },
      { id: 'dorado_imperial', name: 'Oro Imperial / Makie', hex: '#F59E0B' },
      { id: 'azul_indigo_samurai', name: 'Azul Índigo Tradicional', hex: '#1E3A8A' }
    ],
    suggestedWardrobeDetails: ['Cordones de seda odoshi trenzados en degradado de color', 'Máscara menpo de colmillos prominentes y ceño fruncido', 'Emblema Mon familiar en el peto y en el kabuto', 'Cresta maedate dorada elevándose sobre la frente'],
    styleNote: 'Artesanía militar japonesa suprema, laca urushi, cordones de seda odoshi y letalidad disciplinada.'
  },

  'B6 Guardián de Escudo': {
    roleName: 'B6 Guardián de Escudo',
    category: 'Marcial y Combate Pesado',
    tagline: 'Muralla viviente, escudo torre pavés, coraza pesada de bastión, hombreras reforzadas y lanza de contención',
    description: 'Defensor inamovible de falanges y fortalezas. Viste coraza maciza, grebas anchas y empuña un escudo torre capaz de resistir cargas de caballería y fuego de artillería.',
    recommendedOutfitType: 'O-FORTRESS Armadura de Bastión Pesada con Escudo Torre Pavés y Lanza de Detención',
    outfitTypes: [
      { id: 'O-FORTRESS-TOWER', name: 'O-FORTRESS-TOWER Armadura Pesada con Escudo Pavés de Suelo y Peto Doble' },
      { id: 'O-FORTRESS-PHALANX', name: 'O-FORTRESS-PHALANX Armadura de Falange con Escudo Redondo Pesado y Pica' },
      { id: 'O-FORTRESS-DEFENDER', name: 'O-FORTRESS-DEFENDER Guardián Urbano con Escudo Antidisturbios Reforzado' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Yelmos de Bastión con Visera Estrecha',
        pieces: [
          'P1.1 Yelmo de Bastión con Visera de Ranura Mínima para Proteger los Ojos',
          'P1.2 Casco Cerrado con Placas Frontales Superpuestas y Barbote Soldado',
          'P1.3 Sallet Pesado con Cobertura Completa de Nuca y Cuello'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Peto de Bastión de Acero Reforzado',
        pieces: [
          'P2.1 Peto Macizo de Doble Espesor de Acero con Refuerzo Frontal de Rombo',
          'P2.2 Coraza de Placas Pesadas con Soporte para Apoyar el Escudo',
          'P2.3 Gambesón de Triple Capa Acolchada de Lana y Crin de Caballo'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Hombreras de Bastión Gigantes',
        pieces: [
          'P3.1 Hombreras de Placas Gigantes con Reborde Alto Protegiendo el Cuello',
          'P3.2 Espaldar Grueso con Ganchos de Anclaje para Escudo en la Espalda',
          'P3.3 Capa Corta de Lona Pesada Resistente a Proyectiles Incendiarios'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Guanteletes de Bloqueo y Brazales Gruesos',
        pieces: [
          'P4.1 Guanteletes de Placas Reforzadas con Almohadilla Antivibración',
          'P4.2 Brazales Anchos con Placa Adicional en el Antebrazo Izquierdo de Soporte',
          'P4.3 Correas de Agarre Doble de Cuero Grueso para el Escudo'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturón de Placas y Fauld Grueso',
        pieces: [
          'P5.1 Fauld de Placas Gruesas Cubriendo Ingle y Caderas',
          'P5.2 Cinturón de Bastión con Hebilla de Hierro Forjado y Argollas de Estaca',
          'P5.3 Tahalí para Maza Pesada de Defensa Corta'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Grebas de Asedio y Escarcelas',
        pieces: [
          'P6.1 Escarcelas Anchas de Placas que se Solapan con las Rodilleras',
          'P6.2 Grebas Pesadas con Puntas de Fijación al Suelo',
          'P6.3 Quijotes de Acero Macizo Protegiendo Muslos Frontales'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Escarpines de Fijación Pesada',
        pieces: [
          'P7.1 Escarpines de Acero de Base Ancha con Púas de Agarre al Terreno',
          'P7.2 Botas de Asedio con Placas de Hierro Remachadas en Empeine y Talón',
          'P7.3 Calzado Blindado Antiaplastamiento'
        ]
      }
    ],
    materials: ['Acero fundido de alto espesor', 'Madera de roble macizo con refuerzo de hierro', 'Cuero balístico de buey', 'Hierro remachado', 'Lona ignífuga'],
    finishes: ['Acabado mate de fortaleza sin reflejos', 'Huellas de flechas y perdigones deflectados', 'Reborde de hierro forjado macizo', 'Pintura heráldica de bastión'],
    armorDefenses: [
      { id: 'AR-TOWER-WALL', name: 'Muro de Escudo Pavés y Placas Pesadas', desc: 'Inmunidad a proyectiles frontales y absorción masiva de impacto de carga' },
      { id: 'AR-UNYIELDING-STANCE', name: 'Postura Inamovible de Bastión', desc: 'Resistencia absoluta a derribos, empujones y aturdimientos' }
    ],
    weapons: [
      'Escudo Torre Pavés de Suelo de 1.80m con Ventanilla de Visión y Púa de Anclaje',
      'Lanza de Contención de 3 Metros con Contera de Acero y Gancho Antijinete',
      'Maza de Impacto de Cabeza Hexagonal de Hierro Macizo',
      'Espada Corta de Empuje (Spatha de Bastión) de Filo Grueso',
      'Mangual Pesado de Bola de Púas con Cadena Reforzada'
    ],
    relicsAndItems: [
      'Estacas de Hierro de Trinchera para Anclar el Escudo al Suelo',
      'Cuerno de Alerta de Fuerte de Bronce Pesado',
      'Frasco de Ungüento Ignífugo para el Escudo',
      'Piedra de Afilar de Lanza con Funda de Cuero'
    ],
    bags: [
      'Funda Impermeable de Lona Encerada para Escudo Torre',
      'Morral de Asedio con Herramientas de Fortificación Rápida',
      'Carcaj Dorsal para Jabalinas de Detención Cortas',
      'Bolsa de Munición para Clavos y Estacas de Fijación'
    ],
    equipmentFinishes: [
      'Hierro fundido de textura rugosa con pintura negra anticorrosión',
      'Roble macizo tratado con brea protectora',
      'Remaches de acero de cabeza redonda sobredimensionados',
      'Puntas de anclaje de acero templado al fuego'
    ],
    suggestedColors: [
      { id: 'gris_granito', name: 'Gris Granito / Fortaleza', hex: '#374151' },
      { id: 'hierro_oscuro', name: 'Hierro Forjado / Carbón', hex: '#1F2937' },
      { id: 'azul_acero_guardia', name: 'Azul Acero Guardia', hex: '#1E40AF' },
      { id: 'bronce_muro', name: 'Bronce Envejecido / Muralla', hex: '#92400E' }
    ],
    suggestedWardrobeDetails: ['Escudo torre con ranura superior para apoyar la lanza', 'Remaches colosales en todas las uniones de placa', 'Púas inferiores en el escudo para clavarlo en la tierra', 'Ranura milimétrica en la visera del yelmo'],
    styleNote: 'Inamovilidad absoluta, blindaje masivo de fortaleza, geometría de bastión y defensa impenetrable.'
  },

  'B7 Mercenario': {
    roleName: 'B7 Mercenario',
    category: 'Marcial y Combate Pesado',
    tagline: 'Soldado de fortuna, armadura combinada de botín, capa de viaje desgastada, ballesta pesada y bolsa de oro',
    description: 'Veterano de mil campañas que lucha por oro. Viste una mezcla pragmática de piezas de armadura de diferentes naciones, cuero curtido y armas versátiles.',
    recommendedOutfitType: 'O-MERCENARY Armadura Mixta de Cuero y Placas con Capa de Viaje y Ballesta',
    outfitTypes: [
      { id: 'O-MERCENARY-VETERAN', name: 'O-MERCENARY-VETERAN Brigantina de Placas con Mangas de Malla y Capa con Piel' },
      { id: 'O-MERCENARY-CROSSBOW', name: 'O-MERCENARY-CROSSBOW Atuendo de Tirador Pesado con Pavés de Espalda y Ballesta' },
      { id: 'O-MERCENARY-LANDSKNECHT', name: 'O-MERCENARY-LANDSKNECHT Ropajes Acuchillados Multicolor con Gran Sombrero de Plumas y Espadón' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Sallets, Boinas y Cascos Abiertos',
        pieces: [
          'P1.1 Casco Sallet Alemán con Barbote y Visera Abatible',
          'P1.2 Gran Sombrero de Landsknecht con Múltiples Plumas de Colores',
          'P1.3 Casco de Infantería de Cuenco (Kettle Hat / Morrion) con Borde Ancho',
          'P1.4 Pañuelo Bandana de Cuello con Marca de Gremio de Mercenarios'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Brigantinas y Camisolas de Malla',
        pieces: [
          'P2.1 Brigantina de Placas de Acero Remachadas en Cuero Marrón o Verde',
          'P2.2 Camisola de Cota de Malla Remachada con Forro de Lino',
          'P2.3 Jubón de Landsknecht con Mangas Acuchilladas Bicolor',
          'P2.4 Peto de Infantería con Muescas de Batalla y Correa de Espalda'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Capas de Viaje y Hombreras Mixtas',
        pieces: [
          'P3.1 Capa de Viaje Desgastada con Cuello de Piel de Lobo',
          'P3.2 Hombrera Asimétrica de Placas en el Brazo Expuesto',
          'P3.3 Manto Impermeable Enrollado en Bandolera a la Espalda'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Guantes de Cuero y Brazales de Malla',
        pieces: [
          'P4.1 Guantes de Cuero Grueso con Muñequeras Tachonadas',
          'P4.2 Brazales de Cuero con Refuerzos de Varillas de Acero',
          'P4.3 Manguitos de Malla Flexibles para Movilidad Rápida'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturones con Bolsas de Monedas',
        pieces: [
          'P5.1 Cinturón Ancho de Cuero con Bolsa Pesada para Monedas de Oro del Contrato',
          'P5.2 Tahalí para Espada Corta Katzbalger y Daga de Remate',
          'P5.3 Faja de Tela a Rayas Multicolor de Landsknecht'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Calzas Acuchilladas y Perneras',
        pieces: [
          'P6.1 Calzas Acuchilladas con Tiras de Tela Dejando Ver el Forro de Color',
          'P6.2 Pantalones Resistentes de Lana con Rodilleras de Cuero',
          'P6.3 Perneras de Malla con Rodilleras de Placa Simple'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Botas de Campaña y Zapatos Pata de Oso',
        pieces: [
          'P7.1 Botas de Campaña de Cuero Rudo con Suela Claveteada',
          'P7.2 Zapatos Pata de Oso (Kuhmaul) de Cuero con Aberturas',
          'P7.3 Botines Flexibles con Cordones Laterales'
        ]
      }
    ],
    materials: ['Cuero curtido resistente al agua', 'Acero templado con huellas de uso', 'Cota de malla flexible', 'Lana pesada de campaña', 'Fieltro y plumas para sombreros'],
    finishes: ['Envejecido en batalla con pátina de uso', 'Costuras reforzadas con remaches de latón', 'Cuero engrasado con grasa animal', 'Colores contrastantes descoloridos por el sol'],
    armorDefenses: [
      { id: 'AR-MERCENARY-MIX', name: 'Armadura Mixta de Brigantina y Malla', desc: 'Excelente balance entre protección contra armas blancas y peso para marchas largas' },
      { id: 'AR-VETERAN-INSTINCT', name: 'Instinto de Supervivencia Veterano', desc: 'Detecta emboscadas y reduce el daño de ataques por la espalda' }
    ],
    weapons: [
      'Espada Katzbalger de Guarda en Forma de Ocho y Punta Redonda',
      'Ballesta Pesada con Cranequín de Tensión de Acero',
      'Alabarda de Infantería con Hacha, Púa de Empuje y Gancho Desmontador',
      'Daga de Misericordia con Hoja Triangular Rígida de Remate',
      'Arquebús / Pistola de Mecha con Baqueta y Polvorera'
    ],
    relicsAndItems: [
      'Contrato de Mercenario Firmado en Pergamino con Sello de Cera y Paga',
      'Bolsa con Dados Cargados de Hueso y Baraja de Taberna',
      'Cantimplora Forrada en Cuero con Aguardiente Fuerte',
      'Frasco de Grasa de Cerdo para Mantenimiento de Armas y Malla'
    ],
    bags: [
      'Morral de Campaña de Lona con Cubiertos, Yesca y Raciones',
      'Carcaj de Cuero Rígido para Virolotes de Ballesta',
      'Bolsa Pesada de Cuero con Cierre de Candado para Monedas del Contrato',
      'Funda Dorsal para Alabarda o Espadón'
    ],
    equipmentFinishes: [
      'Acero con acabado gris mate antibrillo para operaciones nocturnas',
      'Madera de fresno con marcas de uso y cortes de filo',
      'Latón patinado con reflejos dorados desgastados',
      'Cuero marrón curtido al aceite de pescado'
    ],
    suggestedColors: [
      { id: 'verde_cazador', name: 'Verde Bosque / Mercenario', hex: '#166534' },
      { id: 'marron_cuero_rudo', name: 'Marrón Cuero / Campaña', hex: '#713F12' },
      { id: 'rojo_oxido_veterano', name: 'Rojo Óxido / Ladrillo', hex: '#991B1B' },
      { id: 'amarillo_oro_paga', name: 'Amarillo Paga / Oro', hex: '#CA8A04' }
    ],
    suggestedWardrobeDetails: ['Plumas de colores llamativos en el sombrero de ala', 'Mangas acuchilladas con tela interior en contraste', 'Bolsas múltiples colgadas del cinturón', 'Muescas talladas en el mango del arma contando victorias'],
    styleNote: 'Pragmatismo de veterano, combinación de armaduras de botín, vistosidad de Landsknecht y versatilidad táctica.'
  },

  'B8 Campeón de Arena': {
    roleName: 'B8 Campeón de Arena',
    category: 'Marcial y Combate Pesado',
    tagline: 'Gloria eterna del foso, armadura enjoyada de oro y acero, corona de laureles de emperador, manto escarlata y gladius de leyenda',
    description: 'El guerrero invicto que ha conquistado el clamor de las masas. Su equipo combina la brutalidad del combate en la arena con la suntuosidad del oro, joyas y la gloria imperial.',
    recommendedOutfitType: 'O-CHAMPION Armadura de Campeón Invicto de Oro y Acero con Manto Imperial',
    outfitTypes: [
      { id: 'O-CHAMPION-GOLD', name: 'O-CHAMPION-GOLD Armadura de Placas de Oro y Acero Pulido con Escarcelas de Rubíes' },
      { id: 'O-CHAMPION-BEAST', name: 'O-CHAMPION-BEAST Atuendo de Cazador de Monstruos de Arena con Piel de León de Nemea' },
      { id: 'O-CHAMPION-CEREMONIAL', name: 'O-CHAMPION-CEREMONIAL Túnica de Seda Carmesí con Corona de Laureles de Diamantes' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Coronas de Laureles y Cascos de Oro',
        pieces: [
          'P1.1 Corona de Laureles de Oro Macizo con Hojas Cinceladas a Mano',
          'P1.2 Casco de Campeón de Oro y Acero con Cresta Escarlata Gigante',
          'P1.3 Diadema de Platino con Rubí Central de la Victoria',
          'P1.4 Máscara Facial de Oro Pulido con Mirada Triunfal'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Peto Anatómico Musculado de Oro y Acero',
        pieces: [
          'P2.1 Peto Anatómico Esculpido en Relieve Muscular de Acero y Oro (Musculata)',
          'P2.2 Arnés de Cuero de Dragón con Engastes de Rubíes y Zafiros',
          'P2.3 Pechera de Placas de Oro con Relieve de León Rugiente',
          'P2.4 Pteruges (Tiras de Cuero y Seda con Puntas de Oro) en los Hombros'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Gran Manto Escarlata Imperial',
        pieces: [
          'P3.1 Gran Manto de Terciopelo Escarlata con Broches Gemelos de Oro de León',
          'P3.2 Piel de Gran León con Cabeza Rugiente sobre el Hombro Derecho',
          'P3.3 Hombreras de Oro Cinceladas con Escenas de Victorias en la Arena'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Manica de Oro y Brazaletes de Diamantes',
        pieces: [
          'P4.1 Manica de Oro Escamado Cubriendo el Brazo con Reflejos Solares',
          'P4.2 Brazaletes Anchos de Platino con Inscripción de Cien Victorias Invicto',
          'P4.3 Guanteletes de Cuero Blanco y Oro con Garras Afiladas'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturón de Campeón con Gemas',
        pieces: [
          'P5.1 Gran Cinturón de Campeón de Oro Macizo con Relieve del Coliseo y Gemas',
          'P5.2 Pteruges de Doble Capa de Cuero con Remaches de Oro en la Cintura',
          'P5.3 Fajín de Seda Escarlata Imperial con Flecos de Hilo de Oro'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Grebas de Oro Esculpidas',
        pieces: [
          'P6.1 Grebas de Oro con Escultura de Dioses de la Guerra en Relieve',
          'P6.2 Faldón de Seda Carmesí con Cenefas Griegas de Pan de Oro',
          'P6.3 Musleras de Cuero Blanco con Tachuelas de Rubí'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Sandalias de Oro Imperial',
        pieces: [
          'P7.1 Sandalias Altas de Tiras de Cuero Dorado con Hebillas de Joyas hasta la Rodilla',
          'P7.2 Botines de Cuero de Becerro Blanco con Punteras de Oro Cincelado',
          'P7.3 Caligae de Campeón con Clavos de Oro para Pisar la Arena de Sangre'
        ]
      }
    ],
    materials: ['Oro de 24 quilates batido y cincelado', 'Acero de damasco celestial', 'Terciopelo escarlata imperial', 'Cuero blanco de becerro selecto', 'Rubíes y diamantes engastados'],
    finishes: ['Oro pulido espejo cegador', 'Relieve escultórico anatómico de alta definición', 'Bordados en hilo de oro de tres cabos', 'Lustre imperial impecable'],
    armorDefenses: [
      { id: 'AR-CHAMPION-GOLD', name: 'Coraza Anatómica de Oro Bendecido', desc: 'Blindaje insuperable que desvía ataques mortales y deslumbra a los enemigos' },
      { id: 'AR-GLORY-AURA', name: 'Aura de Inmortalidad de la Arena', desc: 'La aclamación popular regenera la vitalidad y fuerza del campeón' }
    ],
    weapons: [
      'Gladius de Oro y Acero Damasco con Empuñadura de Marfil y Pomo de Rubí',
      'Lanza de Campeón con Punta de Cristal de Fuego y Regatón Dorado',
      'Escudo Redondo Aspis de Oro Macizo con Cabeza de Medusa en Relieve',
      'Espadón de Arena de Filo Plateado con Grabado de Cien Triunfos',
      'Mangual de Oro de Tres Bolas de Fuego Griego'
    ],
    relicsAndItems: [
      'Copa de la Victoria de Oro con Vino Sagrado del Emperador',
      'Decreto Imperial de Libertad y Título de Patricio Honorario',
      'Medallón de Campeón con el Rostro del César en Relieve',
      'Frasco de Ungüento de Mirra y Oro para Curar Heridas de Combate'
    ],
    bags: [
      'Cofre de Oro y Caoba para Joyas y Monedas de Victorias',
      'Funda de Terciopelo Escarlata para el Escudo de Medusa',
      'Bolsa de Seda Púrpura para la Corona de Laureles',
      'Porta-Gladius de Cuero Blanco con Guarnición de Oro'
    ],
    equipmentFinishes: [
      'Oro pulido a espejo con incrustaciones de rubíes cabujón',
      'Marfil tallado con motivos heráldicos de victoria',
      'Acero de damasco celestial con patrón de olas de fuego',
      'Esmalte escarlata vidriado al calor'
    ],
    suggestedColors: [
      { id: 'oro_campeon', name: 'Oro Real / 24K', hex: '#EAB308' },
      { id: 'rojo_imperial', name: 'Rojo Púrpura Imperial', hex: '#991B1B' },
      { id: 'blanco_marmol', name: 'Blanco Mármol / Marfil', hex: '#F8FAFC' },
      { id: 'acero_celestial', name: 'Acero Celestial / Platino', hex: '#E2E8F0' }
    ],
    suggestedWardrobeDetails: ['Peto anatómico musculado esculpido a la perfección', 'Corona de laureles de oro con reflejos brillantes', 'Manto escarlata ondeando con broches de cabeza de león', 'Cinturón de campeón con esmeraldas y rubíes resplandecientes'],
    styleNote: 'Majestuosidad suprema de la arena, oro reluciente, anatomía heroica esculpida y gloria de gladiador invicto.'
  }
};
