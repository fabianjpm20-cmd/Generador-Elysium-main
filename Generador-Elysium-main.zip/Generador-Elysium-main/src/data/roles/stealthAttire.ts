import { RoleAttireConfig } from './types';

export const STEALTH_ROLES: Record<string, RoleAttireConfig> = {
  'D1 Pícaro Asesino': {
    roleName: 'D1 Pícaro Asesino',
    category: 'Sigilo y Subterfugio',
    tagline: 'Muerte silenciosa, capa con capucha de sombras, cuero tachonado negro ajustado, dagas envenenadas gemelas y máscara de tela',
    description: 'Ejecutor letal que opera desde la penumbra. Viste cuero mate ajustado para no hacer ruido, capuchas que cubren el rostro y arneses con dagas arrojadizas y venenos.',
    recommendedOutfitType: 'O-ASSASSIN Atuendo de Cuero Negro Mate Ajustado con Capucha de Sombras y Dagas Gemelas',
    outfitTypes: [
      { id: 'O-ASSASSIN-SHADOW', name: 'O-ASSASSIN-SHADOW Cuero Negro Mate con Capucha de Pico y Dagas Envenenadas' },
      { id: 'O-ASSASSIN-ROOFTOP', name: 'O-ASSASSIN-ROOFTOP Ropajes Ligeros de Acróbata Nocturno con Cuerdas de Escape' },
      { id: 'O-ASSASSIN-CONTRACT', name: 'O-ASSASSIN-CONTRACT Traje de Gremio de Asesinos con Máscara de Porcelana y Capa Corta' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Capuchas de Pico y Máscaras de Asesino',
        pieces: [
          'P1.1 Capucha Puntiaguda de Cuero Negro con Borde Rígido sobre los Ojos',
          'P1.2 Máscara de Tela Negra / Velo Inferior Cubriendo Nariz y Boca',
          'P1.3 Máscara de Porcelana Blanca con Lágrima Negra de Asesino de Élite',
          'P1.4 Cinta de Cuero con Antifaz de Malla Fina Oscura'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Jubones de Cuero Ajustados y Arneses en X',
        pieces: [
          'P2.1 Jubón de Cuero Negro Mate Ajustado con Costuras Silenciosas y Ojales Oscuros',
          'P2.2 Arnés en X de Cuero Cruzado con Portadagas Arrojadizas en el Pecho',
          'P2.3 Pechera Ligera de Cuero Endurecido con Acolchado Antivibración',
          'P2.4 Camisola de Malla Oscurecida Fina Debajo del Cuero'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Capas Cortas Asimétricas y Hombreras de Cuero',
        pieces: [
          'P3.1 Capa Corta Asimétrica de Sombras con Forro de Seda Silenciosa',
          'P3.2 Hombrera Única de Cuero Tachonado en el Brazo Hábil',
          'P3.3 Manto Rasgado de Camuflaje Nocturno con Capucha Desmontable'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Brazales con Cuchilla Oculta y Guantes',
        pieces: [
          'P4.1 Brazal de Antebrazo Izquierdo con Mecanismo de Cuchilla Oculta Retráctil',
          'P4.2 Guantes de Cuero Fino sin Dedos con Palmas de Gamuza Antideslizante',
          'P4.3 Muñequeras con Ranuras para Dardos Envenenados de Lanzamiento Rápido'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturones con Viales de Veneno',
        pieces: [
          'P5.1 Cinturón Ancho de Cuero con Compartimentos para 6 Viales de Venenos Letales',
          'P5.2 Tahalí Doble Cruzado en la Espalda Baja para Dagas Gemelas',
          'P5.3 Faja de Seda Negra con Bolsillos Ocultos para Ganzúas'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalones Elásticos de Cuero y Perneras',
        pieces: [
          'P6.1 Pantalones de Cuero Flexible Mate Ajustados con Refuerzo en Entrepierna',
          'P6.2 Perneras de Cuero con Fundas Laterales para Cuchillos de Lanzamiento',
          'P6.3 Rodilleras de Cuero Acolchadas para Movimiento Sigiloso a Gatas'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Botas Silenciosas de Suela Blanda',
        pieces: [
          'P7.1 Botas de Cuero Suave con Suela de Gamuza Acolchada sin Tacón (Moccasin Táctico)',
          'P7.2 Botines de Asesino con Cuchilla Retráctil en la Puntera',
          'P7.3 Calzado de Escalada con Puntera Dividida Tabi'
        ]
      }
    ],
    materials: ['Cuero negro mate curtido con corteza de roble', 'Seda de araña absorbente de ruido', 'Acero pavonado oscuro no reflectante', 'Gamuza suave antideslizante', 'Venenos y toxinas de belladona'],
    finishes: ['Negro mate antirreflejos total', 'Costuras invisibles sin crujidos', 'Hoja de acero oscurecida químicamente', 'Textura de piel fina elástica'],
    armorDefenses: [
      { id: 'AR-SHADOW-BLEND', name: 'Manto de Fusión con las Sombras', desc: 'Invisibilidad parcial en zonas de penumbra y evasión de ataques sorpresa' },
      { id: 'AR-LETHAL-AGILITY', name: 'Reflejos Felinos de Asesino', desc: 'Esquiva ágil automática contra el primer golpe en combate' }
    ],
    weapons: [
      'Dagas Gemelas de Asesino de Hoja Ondulada con Canal de Veneno',
      'Cuchilla Oculta de Resorte de Muñeca (Hidden Blade)',
      'Juego de 6 Cuchillos Arrojadizos Equilibrados de Acero Negro',
      'Ballesta de Mano Silenciosa con Virolotes Envenenados',
      'Garrote de Alambre de Piano con Mangos de Ébano'
    ],
    relicsAndItems: [
      'Frasco de Veneno de Lágrimas de Medianoche (Parálisis Instantánea)',
      'Juego de Ganzúas Profesionales de Acero Templado en Estuche de Cuero',
      'Bomba de Humo Negra de Fuga Rápida',
      'Moneda Negra Marcada con el Sello del Gremio de Asesinos'
    ],
    bags: [
      'Estuche Rígido Acolchado de Cinturón para Frascos de Venenos Delicados',
      'Morral Plano de Espalda para Cuerda de Seda y Gancho de Escalada',
      'Bolsa Oculta de Muslo para Contratos de Asesinato Sellados',
      'Funda Dorsal Cruzada de Dagas'
    ],
    equipmentFinishes: [
      'Acero al carbono negro mate oxidado sin ningún brillo',
      'Cuero teñido en negro ceniza con cantos sellados con cera negra',
      'Mangos de dagas forrados en cuero de serpiente con agarre perfecto',
      'Frascos de veneno de cristal ahumado oscuro'
    ],
    suggestedColors: [
      { id: 'negro_mate_asesino', name: 'Negro Sombras / Mate', hex: '#09090B' },
      { id: 'gris_carbon', name: 'Gris Carbón / Asfalto', hex: '#27272A' },
      { id: 'rojo_sangre_veneno', name: 'Rojo Sangre / Veneno', hex: '#991B1B' },
      { id: 'verde_toxico_oscuro', name: 'Verde Tóxico / Cicuta', hex: '#14532D' }
    ],
    suggestedWardrobeDetails: ['Capucha con corte en pico sobre la frente que sombrea la mirada', 'Arnés de pecho cargado de cuchillos arrojadizos', 'Brazalete con la ranura de la cuchilla oculta retráctil', 'Capa corta asimétrica ondeando tras pasos silenciosos'],
    styleNote: 'Sigilo mortal, cuero negro mate absoluto, cuchillas ocultas mecánicas y venenos letales.'
  },

  'D2 Ladrón / Escurridizo': {
    roleName: 'D2 Ladrón / Escurridizo',
    category: 'Sigilo y Subterfugio',
    tagline: 'Destreza de manos, ganzúas maestras, chaleco con bolsillos secretos, cuerda con gancho de agarre y botín brillante',
    description: 'Especialista en infiltración, desvalijamiento de cajas fuertes y carterismo. Viste ropajes cómodos de tonos pardos y grises con infinidad de bolsillos ocultos.',
    recommendedOutfitType: 'O-THIEF Atuendo Urbano de Infiltración con Chaleco Multibolsillos y Gancho de Escalada',
    outfitTypes: [
      { id: 'O-THIEF-STREET', name: 'O-THIEF-STREET Ropas de Carterista Callejero con Gorra Plana y Pañuelo' },
      { id: 'O-THIEF-BURGLAR', name: 'O-THIEF-BURGLAR Malla de Infiltración de Tejados con Cuerda y Ganzúas' },
      { id: 'O-THIEF-SMUGGLER', name: 'O-THIEF-SMUGGLER Chaquetón de Contrabandista con Forro de Bolsillos Secretos' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Gorras Planas y Pañuelos de Cuello',
        pieces: [
          'P1.1 Gorra Plana de Lana (Newsboy Cap) Calada sobre los Ojos',
          'P1.2 Pañuelo de Cuello Gris que se Sube Rápidamente como Pasamontañas',
          'P1.3 Capucha Ligera de Lino con Cordón de Ajuste Rápido',
          'P1.4 Lupa de Joyero Monocular para Examinar Gemas y Cerraduras'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Chalecos Multibolsillos y Camisas Holgadas',
        pieces: [
          'P2.1 Chaleco de Cuero con 12 Bolsillos Secretos Interiores y Cremalleras Ocultas',
          'P2.2 Camisa de Lino Gris con Cordones y Mangas Remangadas',
          'P2.3 Chaquetón Corto de Paño con Forro de Seda Resbaladiza para Ocultar Joyas',
          'P2.4 Arnés de Escalada de Pecho con Mosquetones de Latón Silenciosos'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Cuerdas de Escalada y Morrales Planos',
        pieces: [
          'P3.1 Rollo de Cuerda de Seda Fina de 20 Metros con Gancho de Garra Plegable',
          'P3.2 Mochila Plana de Espalda de Lona Impermeable para el Botín',
          'P3.3 Capa Corta Impermeable de Tejado'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Mitones de Carterista y Muñequeras',
        pieces: [
          'P4.1 Mitones de Cuero Suave sin Dedos con Yemas Descubiertas para Sentir Cerraduras',
          'P4.2 Muñequeras de Cuero con Ranura Oculta para Ganzúa Tensora',
          'P4.3 Manguitos Protectores contra Roces de Tejas y Muros'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturones con Bolsas de Ganzúas',
        pieces: [
          'P5.1 Cinturón de Ladrón con Estuche Enrollable de 18 Ganzúas y Llaves Maestras',
          'P5.2 Faja Ancha de Tela con Bolsillos para Monedas y Joyas Hurtadas',
          'P5.3 Tahalí para Daga Corta Oculta tras la Espalda'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalones Cómodos con Refuerzo',
        pieces: [
          'P6.1 Pantalones de Pana o Lona Flexible con Bolsillos Laterales',
          'P6.2 Calzones Ajustados a la Rodilla con Espacio para Guardar Bolsas',
          'P6.3 Rodilleras de Cuero Suave para Gatear por Conductos y Tejados'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Zapatos de Suela de Goma Silenciosa',
        pieces: [
          'P7.1 Zapatos Ligeros de Cuero Flexible con Suela de Goma de Agarre para Tejados',
          'P7.2 Botines de Cordones Flexibles con Bolsillo en el Tacón',
          'P7.3 Calzado de Lona Liviano para Carreras Rápidas'
        ]
      }
    ],
    materials: ['Lona de algodón resistente', 'Cuero flexible de cordero', 'Lana fina para gorras', 'Seda de escalada ultrafina', 'Acero elástico para ganzúas'],
    finishes: ['Colores urbanos apagados (gris, pardo, ceniza)', 'Cuero ablandado con cera para evitar ruidos', 'Bolsillos con cierres magnéticos silenciosos', 'Pátina de hollín de tejados'],
    armorDefenses: [
      { id: 'AR-THIEF-SLIP', name: 'Escurridizo / Evasión de Presas', desc: 'Inmunidad a agarres, cuerdas y reducción masiva de daño de caídas' },
      { id: 'AR-LUCKY-DODGE', name: 'Suerte del Pillo Callejero', desc: 'Probabilidad de convertir ataques críticos recibidos en simples rasguños' }
    ],
    weapons: [
      'Daga de Ladrón Corta de Ocultación Rápida con Mango Hueco',
      'Porra de Cuero Rellena de Plomo (Blackjack) para Noqueos Silenciosos',
      'Cerbatana con Dardos Somníferos de Acción Instantánea',
      'Navaja de Resorte Plegable con Bloqueo de Seguridad',
      'Bolas de Abrojos de Metal para Frenar Persecuciones'
    ],
    relicsAndItems: [
      'Juego Maestro de Ganzúas de Aleación de Titanio',
      'Gancho de Escalada Plegable de Tres Puntas con Cuerda de Seda',
      'Bolsa Rebosante de Monedas de Oro y Gemas Recién Robadas',
      'Espejo Telescópico Pequeño para Mirar bajo las Puertas'
    ],
    bags: [
      'Saco de Botín de Terciopelo con Cordón de Cierre Rápido',
      'Mochila Antirrobo de Tejado con Cremalleras Ocultas en la Espalda',
      'Cartuchera de Pierna para Frascos de Ácido Rompe-Cerraduras',
      'Limosnera de Cinturón con Fondo Falso'
    ],
    equipmentFinishes: [
      'Acero pulido mate con puntas finas milimétricas en ganzúas',
      'Cuero marrón gastado por el uso intensivo en las esquinas',
      'Latón envejecido con marcas de aceite lubricante',
      'Cuerda de seda trenzada oscura con mosquetones de aluminio'
    ],
    suggestedColors: [
      { id: 'gris_tejado', name: 'Gris Tejado / Pizarra', hex: '#4B5563' },
      { id: 'marron_pardo', name: 'Marrón Pardo / Callejón', hex: '#57534E' },
      { id: 'negro_hollin', name: 'Negro Hollín / Chimenea', hex: '#18181B' },
      { id: 'oro_botin', name: 'Oro Brillante / Botín', hex: '#EAB308' }
    ],
    suggestedWardrobeDetails: ['Gorra inclinada tapando la mirada pícara', 'Cuerda y gancho de agarre enrollados a la espalda', 'Bolsillo del chaleco entreabierto mostrando una ganzúa o joya brillante', 'Zapatos con suela de goma flexible para no resbalar en tejas'],
    styleNote: 'Agilidad urbana pícara, destreza de ganzúas, botines rebosantes y escapismo acrobático.'
  },

  'D3 Cazador de Sombras': {
    roleName: 'D3 Cazador de Sombras',
    category: 'Sigilo y Subterfugio',
    tagline: 'Exterminador de horrores nocturnos, abrigo largo de cuero tachonado, sombrero de ala ancha, ballesta de repetición y hojas de plata',
    description: 'Cazador solitario de monstruos y criaturas de la oscuridad. Viste gabardina de cuero endurecido, cartucheras de estacas de plata, frascos de agua bendita y sombrero de ala.',
    recommendedOutfitType: 'O-HUNTER Gabardina Larga de Cuero Endurecido con Sombrero de Cazador y Ballesta',
    outfitTypes: [
      { id: 'O-HUNTER-TRENCH', name: 'O-HUNTER-TRENCH Gabardina de Cuero con Hombreras Tachonadas y Sombrero de Ala' },
      { id: 'O-HUNTER-INQUISITION', name: 'O-HUNTER-INQUISITION Capote de Cuero Negro con Sello Sagrado y Máscara de Ojos' },
      { id: 'O-HUNTER-NIGHT', name: 'O-HUNTER-NIGHT Ropajes Tácticos de Emboscada con Capa Impermeable y Cuchillas de Plata' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Sombreros de Cazador y Pañuelos',
        pieces: [
          'P1.1 Sombrero de Ala Ancha Rígida de Cuero de Cazador con Cinta de Plata',
          'P1.2 Pañuelo de Cuello Triangular Cubriendo la Boca contra Sangre y Ceniza',
          'P1.3 Gafas de Visión Nocturna con Lentes de Cristal Carmesí',
          'P1.4 Máscara de Cuero con Filtro de Ajo y Plata'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Gabardinas de Cuero y Chalecos Blindados',
        pieces: [
          'P2.1 Gabardina Larga de Cuero Grueso con Cuello Alto Alzado y Solapas Anchas',
          'P2.2 Chaleco de Cuero Tachonado con Placas de Acero y Plata Interiores',
          'P2.3 Bandolera Cruzada al Pecho con Virolotes de Plata y Estacas',
          'P2.4 Camisa de Paño Oscuro con Botones de Hueso'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Hombreras de Cuero y Capelinas',
        pieces: [
          'P3.1 Capelina de Cuero sobre los Hombros para Repeler Lluvia y Mordeduras',
          'P3.2 Hombreras de Cuero con Tachuelas de Plata Pura',
          'P3.3 Arnés Dorsal para Espada de Plata Gigante y Ballesta'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Guantes de Cuero Grueso y Brazales Blindados',
        pieces: [
          'P4.1 Guantes de Cuero Grueso con Puños Largos Resistentes a Garras',
          'P4.2 Brazales de Acero y Plata Grabados con Sellos de Purificación',
          'P4.3 Muñequeras con Dispensador de Alambre de Plata Cortante'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturones con Frascos de Aceites Sagrados',
        pieces: [
          'P5.1 Cinturón Militar con Viales de Aceite de Plata y Agua Bendita Concentrada',
          'P5.2 Tahalí para Machete de Caza y Daga de Plata Bendecida',
          'P5.3 Cartuchera de Cuero para Munición de Fuego y Fósforo'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalones de Cuero Reforzado',
        pieces: [
          'P6.1 Pantalón de Cuero Grueso con Costuras Dobles y Refuerzo en Rodillas',
          'P6.2 Faldones Laterales de la Gabardina Abriéndose para Correr',
          'P6.3 Perneras con Bolsillos para Estacas de Fresno'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Botas de Caza con Hebillas de Plata',
        pieces: [
          'P7.1 Botas Altas de Cuero Rígido con Múltiples Hebillas de Plata hasta la Rodilla',
          'P7.2 Botines de Caza con Puntera de Acero y Clavos Antideslizantes',
          'P7.3 Polainas de Cuero Grueso Protegiendo Espinillas de Mordiscos'
        ]
      }
    ],
    materials: ['Cuero de búfalo endurecido', 'Plata pura bendecida', 'Lona encerada impermeable', 'Madera de fresno consagrada', 'Acero templado al aceite'],
    finishes: ['Cuero envejecido por la intemperie y la sangre de monstruos', 'Plata grabada con runas sagradas', 'Acero con pátina gris oscura', 'Hebillas y remaches cromados'],
    armorDefenses: [
      { id: 'AR-BEAST-WARD', name: 'Cuero Bendecido con Óleos de Plata', desc: 'Resistencia masiva contra venenos, mordeduras de bestias y magia de sangre' },
      { id: 'AR-NIGHT-INSTINCT', name: 'Sentidos Aguzados de Cazador Nocturno', desc: 'Inmunidad a la ceguera y detección de enemigos invisibles' }
    ],
    weapons: [
      'Espada de Plata Pura de Dos Manos con Gavilanes en Cruz para Bestias',
      'Ballesta de Repetición con Cargador de 5 Virolotes de Fósforo',
      'Par de Pistolas de Chispa con Balas de Plata Maciza',
      'Machete de Caza Pesado (Cleaver) con Hoja Dentada de Desmembramiento',
      'Látigo con Filamentos de Plata y Puntas Barbeladas'
    ],
    relicsAndItems: [
      'Relicario con Cenizas de Santo que Brillan ante Presencias Malignas',
      'Farol de Cazador de Aceite Sagrado que Disipa Sombras Mágicas',
      'Estacas de Madera de Fresno Consagradas en Agua Bendita',
      'Cuaderno de Bestiario con Dibujos y Puntos Débiles de Monstruos'
    ],
    bags: [
      'Morral de Caza de Cuero Impermeable con Raciones y Aceites',
      'Carcaj Rígido con Forro de Terciopelo para Virolotes de Plata',
      'Bolsa de Cinturón con Trampas Mecánicas de Oso Plegables',
      'Funda Dorsal de Cuero para Espada de Plata'
    ],
    equipmentFinishes: [
      'Plata pulida con inscripciones latinas grabadas a buril',
      'Cuero marrón oscuro con remaches de acero pulido',
      'Madera de fresno tallada con mango ergonómico antideslizante',
      'Cristal grueso tintado de rojo en el farol'
    ],
    suggestedColors: [
      { id: 'cuero_cazador_oscuro', name: 'Marrón Cuero / Ébano', hex: '#292524' },
      { id: 'plata_purificadora', name: 'Plata Purificadora', hex: '#E2E8F0' },
      { id: 'rojo_sangre_bestia', name: 'Rojo Sangre Oscura', hex: '#7F1D1D' },
      { id: 'negro_noche_caza', name: 'Negro Noche / Sombras', hex: '#0C0A09' }
    ],
    suggestedWardrobeDetails: ['Gabardina ondeando al viento con cuello alzado', 'Sombrero de ala ancha arrojando sombra sobre los ojos', 'Farol de cazador emitiendo luz cálida colgado de la cintura', 'Múltiples frascos de aceites y estacas en las bandoleras'],
    styleNote: 'Gótico victoriano de caza de monstruos, gabardinas pesadas de cuero, armas de plata pura y faroles nocturnos.'
  },

  'D4 Espía / Agente': {
    roleName: 'D4 Espía / Agente',
    category: 'Sigilo y Subterfugio',
    tagline: 'Infiltración cortesana, traje noble con armas ocultas, anteojos de visión arcana, cartas cifradas y estilete de manga',
    description: 'Agente encubierto de inteligencia real o corporativa. Viste elegantes ropas aristocráticas de corte impecable, pero repletas de artilugios de espionaje, dardos y microcámaras.',
    recommendedOutfitType: 'O-SPY Traje Diplomático de Alta Sociedad con Forro Blindado y Compartimentos Ocultos',
    outfitTypes: [
      { id: 'O-SPY-TUXEDO', name: 'O-SPY-TUXEDO Esmoquin / Chaqué Noble con Seda Blindada y Estilete de Solapa' },
      { id: 'O-SPY-COURT-GOWN', name: 'O-SPY-COURT-GOWN Vestido de Noche de Gala con Escote Ocultando Dagas y Venenos' },
      { id: 'O-SPY-DISGUISE', name: 'O-SPY-DISGUISE Atuendo de Camaleón con Capas Reversibles para Cambio de Identidad' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Monóculos y Gafas de Aumento',
        pieces: [
          'P1.1 Monóculo de Oro con Lente de Detección de Magia y Microcifrado',
          'P1.2 Gafas Elegantes con Espejos Retrovisores en las Patillas',
          'P1.3 Sombrero de Copa o Tocado Elegante con Ranura para Documentos',
          'P1.4 Pendientes con Transmisor de Audio Acústico Mágico'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Chaquetas Blindadas y Corsés Secretos',
        pieces: [
          'P2.1 Chaqueta de Gala de Corte Impecable con Forro de Kevlar / Seda Balística',
          'P2.2 Corsé Reforzado con Varillas de Acero Afiladas como Cuchillas',
          'P2.3 Camisa de Seda con Botones Desmontables que son Cápsulas de Cianuro',
          'P2.4 Chaleco Elegante con Funda Sobaquera para Pistola Silenciada'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Capas Cortas Reversibles y Estolas',
        pieces: [
          'P3.1 Capa Corta Reversible (Azul Diplomático por Fuera, Negro Nocturno por Dentro)',
          'P3.2 Estola de Piel Fina con Microcables de Escucha Ocultos',
          'P3.3 Manto Ligero de Satén con Broche Grabadora de Sonido'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Gemelos Desmontables y Relojes Láser',
        pieces: [
          'P4.1 Reloj de Pulsera de Oro con Cuerda de Resorte Cortante y Brújula Secreta',
          'P4.2 Gemelos de Camisa con Lente Desplegable de Microfotografía',
          'P4.3 Guantes de Piel Fina con Yemas que Replican Huellas Dactilares'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturones con Compartimentos Secretos',
        pieces: [
          'P5.1 Cinturón de Cuero de Lujo con Hebilla que Oculta Cuchilla de Escape y Ganzúa',
          'P5.2 Fajín de Seda con Funda Oculta para Papel Cifrado',
          'P5.3 Liguero de Encaje con Funda para Daga de Diamante'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalones de Vestir Elásticos o Faldas',
        pieces: [
          'P6.1 Pantalones de Vestir de Lana Fina con Tejido Elástico para Patadas y Huida',
          'P6.2 Falda de Tubo con Abertura Oculta mediante Botones de Presión Rápida',
          'P6.3 Medias de Seda con Costura que Oculta Hilo de Diamante'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Zapatos de Charol con Tacón Hueco',
        pieces: [
          'P7.1 Zapatos Oxford de Charol con Tacón Hueco para Guardar Microcifras',
          'P7.2 Zapatos de Tacón de Aguja con Cuchilla Oculta de Resorte en el Tacón',
          'P7.3 Botines Elegantes con Suela de Goma Insonorizada'
        ]
      }
    ],
    materials: ['Seda balística de alta resistencia', 'Lana fina inglesa de traje', 'Charol brillante de lujo', 'Platino y oro para joyería espía', 'Papel de arroz soluble en agua'],
    finishes: ['Impecable sastrería de alta alcurnia', 'Compartimentos secretos invisibles al tacto', 'Acabado satinado de noche', 'Mecanismos de resorte de microrelojería'],
    armorDefenses: [
      { id: 'AR-DIPLOMATIC-CLOTH', name: 'Traje de Seda Balística Reforzada', desc: 'Disimula armadura antibalas y anticorte bajo la apariencia de ropa de gala' },
      { id: 'AR-FALSE-IDENTITY', name: 'Aura de Camuflaje Social', desc: 'Dificulta enormemente ser identificado como amenaza o sospechoso' }
    ],
    weapons: [
      'Pistola de Bolsillo de Doble Cañón con Silenciador Integrado',
      'Pluma Estilográfica de Oro con Dardo Somnífero de Aire Comprimido',
      'Estilete Fino de Manga con Mecanismo de Expulsión Neumática',
      'Abanico con Borde de Cuchillas de Diamante Ocultas',
      'Anillo con Sello Giratorio Envenenado para Apretón de Manos'
    ],
    relicsAndItems: [
      'Rueda de Cifrado Criptográfico Mecánico de Bolsillo',
      'Juego de Documentos Falsos con Sellos Reales Auténticos',
      'Cigarrera de Plata con Fósforos Incendiarios y Microcámara',
      'Frasco de Tinta Invisible Revelable con Calor o Maná'
    ],
    bags: [
      'Maletín Diplomático de Cuero con Fondo Falso Blindado y Cierre Explosivo',
      'Bolso de Noche de Satén con Detector de Magia Oculto',
      'Portadocumentos Cifrado con Autodestrucción por Ácido',
      'Funda Sobaquera de Cuero Fino para Pistola Compacta'
    ],
    equipmentFinishes: [
      'Oro y platino con grabados de relojero de precisión suiza',
      'Cuero acharolado brillante impecable sin rozaduras',
      'Acero pulido espejo con mecanismos diminutos de resorte',
      'Terciopelo negro con costuras invisibles a mano'
    ],
    suggestedColors: [
      { id: 'negro_esmoquin', name: 'Negro Esmoquin / Ónice', hex: '#0F172A' },
      { id: 'azul_diplomatico', name: 'Azul Diplomático / Medianoche', hex: '#1E3A8A' },
      { id: 'dorado_champagne_espia', name: 'Dorado Champagne / Reloj', hex: '#FDE047' },
      { id: 'blanco_camisa', name: 'Blanco Nieve / Seda', hex: '#F8FAFC' }
    ],
    suggestedWardrobeDetails: ['Corte de sastrería milimétrico y elegante de alta sociedad', 'Monóculo o gafas finas que escanean el entorno', 'Reloj de oro con bisel multifunción', 'Postura calmada y calculadora en medio de fiestas palaciegas'],
    styleNote: 'Glamour de espionaje aristocrático, sastrería blindada, gadgets de microrelojería y letalidad encubierta.'
  },

  'D5 Corsario / Pirata': {
    roleName: 'D5 Corsario / Pirata',
    category: 'Sigilo y Subterfugio',
    tagline: 'Libertad de altamar, casaca de capitán desabrochada, sombrero tricornio con pluma, sable curvo alfanje y parche en el ojo',
    description: 'Navegante intrépido de los siete mares. Viste casacas bordadas de botín, fajines de seda carmesí, tricornios, pistolas de pedernal en bandolera y alfanjes de abordaje.',
    recommendedOutfitType: 'O-PIRATE Casaca de Capitán Pirata con Tricornio, Fajín de Seda y Alfanje de Abordaje',
    outfitTypes: [
      { id: 'O-PIRATE-CAPTAIN', name: 'O-PIRATE-CAPTAIN Casaca Larga de Terciopelo con Galones de Oro y Tricornio' },
      { id: 'O-PIRATE-SWASHBUCKLER', name: 'O-PIRATE-SWASHBUCKLER Camisa Desabrochada de Pirata con Chaleco y Pañuelo' },
      { id: 'O-PIRATE-GHOST', name: 'O-PIRATE-GHOST Corsario Maldito con Ropajes de Niebla Marina y Joyas Malditas' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Tricornios, Bandanas y Parches',
        pieces: [
          'P1.1 Sombrero Tricornio de Cuero Envejecido con Gran Pluma de Loro y Calavera de Plata',
          'P1.2 Parche en el Ojo de Cuero Repujado con Hilo Dorado',
          'P1.3 Bandana de Seda Escarlata Anudada a la Cabeza con Aro de Oro en la Oreja',
          'P1.4 Barba Trenzada con Cuentas de Hueso y Pólvora'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Casacas de Capitán y Camisas de Pirata',
        pieces: [
          'P2.1 Casaca Larga de Capitán de Paño Azul Marino con Solapas de Oro y Botones de Latón',
          'P2.2 Camisa de Pirata de Lino Blanco con Pecho Abierto y Cuello Desbocado',
          'P2.3 Chaleco de Cuero sin Mangas con Hebillas Cruzadas',
          'P2.4 Corsé de Cuero de Pirata con Ojales de Bronce y Cordones de Cuerda'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Capotes de Tormenta y Loros de Hombro',
        pieces: [
          'P3.1 Capote Corto Encerado para Tormentas de Mar',
          'P3.2 Hombrera de Cuero con Garra de Anclaje de Abordaje',
          'P3.3 Loro Exótico / Mono de Hombro con Chaleco en Miniatura'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Mangas Acampanadas y Muñequeras',
        pieces: [
          'P4.1 Mangas de Camisa Holgadas con Puños de Volantes y Manchas de Salitre',
          'P4.2 Brazales de Cuero con Brújula Marina Integrada',
          'P4.3 Garfio de Acero Pulido o Mano Ortopédica de Madera y Latón'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Fajines de Seda y Bandoleras de Pistolas',
        pieces: [
          'P5.1 Gran Fajín de Seda Carmesí Anudado con Caída Lateral',
          'P5.2 Cinturón Ancho de Cuero con Gran Hebilla de Latón de Ancla',
          'P5.3 Bandolera Cruzada al Pecho con Tres Pistolas de Pedernal en Hilera'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalones de Marinero y Bombachos',
        pieces: [
          'P6.1 Pantalones de Marinero a Rayas Verticales Blancas y Azules',
          'P6.2 Calzones de Cuero Holgados con Refuerzo en Rodillas para Cabuyería',
          'P6.3 Falda-Pantalón de Corsaria con Vuelo y Cuchillo de Bota'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Botas de Bucanero de Caña Alta',
        pieces: [
          'P7.1 Botas de Bucanero de Caña Ancha Doblada con Hebillas Laterales de Latón',
          'P7.2 Pata de Palo de Madera de Roble Noble con Contera de Bronce Labrado',
          'P7.3 Zapatos de Marinero con Suela Antideslizante para Cubiertas Mojadas'
        ]
      }
    ],
    materials: ['Paño de lana azul marino de alta mar', 'Seda oriental de botín saqueado', 'Cuero curtido resistente al agua salada', 'Latón naval y bronce pulido', 'Lino desgastado por el sol'],
    finishes: ['Pátina de salitre y sol caribeño', 'Galones dorados de botines navales', 'Cuero curtido flexible', 'Latón con reflejos dorados cálidos'],
    armorDefenses: [
      { id: 'AR-SEAS-FORTUNE', name: 'Suerte de Fortuna del Corsario', desc: 'Esquiva ágil sobre cuerdas y balanceo con bonificación en superficies móviles' },
      { id: 'AR-RUM-HARDINESS', name: 'Dureza Inmune al Ron Marino', desc: 'Resistencia a aturdimientos, mareos y venenos alimentarios' }
    ],
    weapons: [
      'Alfanje de Abordaje (Cutlass) de Hoja Curva con Guarnición de Cazoleta de Latón',
      'Trío de Pistolas de Pedernal de Doble Cañón con Incrustaciones de Nácar',
      'Trabuco de Boca Acampanada de Dragón con Disparo de Metralla',
      'Daga de Marinero con Punzón Desatador de Cabos en el Pomo',
      'Arpón Ballestero de Caza de Monstruos Marinos'
    ],
    relicsAndItems: [
      'Brújula Mágica que Apunta a lo que el Corazón Más Desea',
      'Mapa del Tesoro en Pergamino Manchado de Ron y Quemado en los Bordes',
      'Catalejo de Latón Extensible con Lentes de Zafiro para Ver Barcos Fantasma',
      'Frasco de Ron Añejo de Kraken que Concede Fuerza Titánica'
    ],
    bags: [
      'Cofre Pequeño de Madera Reforzada con Monedas de Oro Españolas (Doblones)',
      'Morral de Lona Encerada Impermeable para Cartas Náuticas',
      'Bolsa de Cuero para Balas de Plomo y Cuerno de Pólvora de Toro',
      'Funda de Cuero para Alfanje de Abordaje'
    ],
    equipmentFinishes: [
      'Latón naval pulido por el roce del viento marino',
      'Madera de caoba náutica con barniz impermeabilizante',
      'Acero con filo curvo afilado y canal de desagüe',
      'Nácar tornasolado incrustado en empuñaduras de pistola'
    ],
    suggestedColors: [
      { id: 'azul_marino_corsario', name: 'Azul Marino / Océano', hex: '#1E3A8A' },
      { id: 'rojo_carmesi_fajin', name: 'Rojo Carmesí / Fajín', hex: '#BE123C' },
      { id: 'oro_doblones', name: 'Oro Doblón / Botín', hex: '#EAB308' },
      { id: 'marron_cuero_sal', name: 'Cuero Marino / Salitre', hex: '#78350F' }
    ],
    suggestedWardrobeDetails: ['Tricornio inclinado con gran pluma meciéndose con el viento', 'Fajín rojo anudado a la cintura con tres pistolas asomando', 'Alfanje curvado en la mano listo para cortar jarcias de abordaje', 'Aro de oro en la oreja y parche con calavera bordada'],
    styleNote: 'Romanticismo pirata de altamar, casacas fastuosas de botín, olor a pólvora y audacia marinera.'
  },

  'D6 Tirador de Precisión': {
    roleName: 'D6 Tirador de Precisión',
    category: 'Sigilo y Subterfugio',
    tagline: 'Muerte a larga distancia, rifle de francotirador arcano con mira telescópica, capa de camuflaje ghillie, visor óptico y munición perforante',
    description: 'Francotirador y tirador de élite. Viste ropa de camuflaje táctico o natural, visor óptico monocular, cinturones de munición especializada y rifle de precisión.',
    recommendedOutfitType: 'O-SNIPER Atuendo de Francotirador con Capa Ghillie de Camuflaje y Rifle de Precisión',
    outfitTypes: [
      { id: 'O-SNIPER-GHILLIE', name: 'O-SNIPER-GHILLIE Capa de Camuflaje Forestal con Hilos de Follaje y Rifle de Francotirador' },
      { id: 'O-SNIPER-TACTICAL', name: 'O-SNIPER-TACTICAL Traje Táctico de Cuero Oscuro con Visor Monocular y Cartucheras' },
      { id: 'O-SNIPER-DESERT', name: 'O-SNIPER-DESERT Ropajes de Tirador de Dunas con Velo de Arena y Capucha' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Visores Ópticos y Capuchas de Camuflaje',
        pieces: [
          'P1.1 Visor Monocular Táctico con Zoom Óptico y Detección de Viento',
          'P1.2 Capucha con Tiras de Camuflaje Ghillie que se Funden con la Vegetación',
          'P1.3 Velo de Tirador de Malla Fina que Oculta los Reflejos de los Ojos',
          'P1.4 Sombrero de Cazador con Ala Recortada para Apuntar Cómodamente'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Chaquetas de Tirador y Arneses Acolchados',
        pieces: [
          'P2.1 Chaqueta de Tirador con Hombrera Derecha Acolchada de Cuero Antirretroceso',
          'P2.2 Arnés de Pecho con Cartucheras para Proyectiles de Calibre Pesado / Arcanos',
          'P2.3 Chaleco de Lona Camuflada con Bolsillos para Prismáticos y Telémetro',
          'P2.4 Camisa Térmica de Cuello Alto Transpirable'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Manto Ghillie y Fundas de Rifle',
        pieces: [
          'P3.1 Gran Manto Ghillie de Fibras de Yute y Hojas Secas para Fusión Total',
          'P3.2 Funda Dorsal Rígida Acolchada para Rifle de Precisión Largo',
          'P3.3 Capa Corta Impermeable con Estampado de Camuflaje Digital o Bosque'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Guantes de Tirador y Muñequeras de Cálculo',
        pieces: [
          'P4.1 Guantes de Tirador de Precisión con Dedo Índice Derecho Recortado',
          'P4.2 Muñequera con Tabla de Corrección Balística y Viento',
          'P4.3 Manguitos de Cuero Acolchados para Apoyo en el Suelo'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturones con Cargadores Especiales',
        pieces: [
          'P5.1 Cinturón Táctico con Cargadores para Balas Perforantes, Explosivas e Incendiarias',
          'P5.2 Tahalí Lateral para Pistola de Respaldo Corta',
          'P5.3 Faja con Soporte para Bípode Plegable'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalones de Camuflaje con Rodilleras',
        pieces: [
          'P6.1 Pantalón de Lona Resistente con Rodilleras Rígidas Acolchadas para Posición Tendida',
          'P6.2 Perneras de Camuflaje con Tiras de Vegetación Artificial',
          'P6.3 Bolsillos de Carga en Muslos para Kits de Limpieza de Cañón'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Botas de Terreno de Agarre Silencioso',
        pieces: [
          'P7.1 Botas de Media Caña de Senderismo Táctico con Suela de Goma Antideslizante',
          'P7.2 Polainas de Lona Impermeables que Cubren los Cordones',
          'P7.3 Botines Flexibles con Tiras de Ajuste Rápido'
        ]
      }
    ],
    materials: ['Lona de algodón camuflada', 'Fibras de yute y cáñamo para ghillie', 'Cuero grueso acolchado antirretroceso', 'Acero estriado de alta precisión', 'Cristal óptico multicapa'],
    finishes: ['Tratamiento mate antibrillo absoluto en metal y cristal', 'Textura rugosa de camuflaje natural', 'Cuero impermeabilizado', 'Pintura de camuflaje de rayas'],
    armorDefenses: [
      { id: 'AR-GHILLIE-CAMO', name: 'Camuflaje Óptico de Posición Oculta', desc: 'Indetectable a más de 30 metros de distancia mientras se mantenga inmóvil' },
      { id: 'AR-EAGLE-EYE', name: 'Ojo de Águila / Concentración Absoluta', desc: 'Inmunidad a la distracción y certeza crítica en disparos a la cabeza' }
    ],
    weapons: [
      'Rifle de Precisión Arcano de Cerrojo con Mira Telescópica de Aumento 12x y Bípode',
      'Arco Largo Compuesto de Poleas con Mira de Fibra Óptica y Flechas de Carbono',
      'Ballesta Pesada de Francotirador con Palanca de Tensión y Estabilizador',
      'Pistola de Respaldo Silenciada de Cañón Largo',
      'Cuchillo de Trinchera con Sierra en el Lomo para Cortar Follaje'
    ],
    relicsAndItems: [
      'Telémetro Óptico de Precisión con Indicador de Distancia Láser / Maná',
      'Anemómetro de Mano para Medir la Velocidad y Dirección del Viento',
      'Caja Metálica con 10 Balas Arcanas Perforadoras de Blindaje',
      'Monocular de Visión Térmica que Detecta Calor a Través de Paredes'
    ],
    bags: [
      'Estuche Rígido Acolchado de Rifle con Bloqueo Hermético',
      'Mochila Táctica de Tirador con Soporte para Trípode',
      'Cartuchera Bandolera para Munición de Gran Calibre',
      'Bolsa de Lona para Guardar el Traje Ghillie Plegado'
    ],
    equipmentFinishes: [
      'Pintura de camuflaje mate verde oliva y marrón tierra en el cañón',
      'Lentes con recubrimiento antirreflejante de color ámbar oscuro',
      'Madera de nogal tratada al aceite con culata anatómica regulable',
      'Acero pavonado negro antirreflejos'
    ],
    suggestedColors: [
      { id: 'verde_oliva_camo', name: 'Verde Oliva / Follaje', hex: '#3F6212' },
      { id: 'marron_tierra_camo', name: 'Marrón Tierra / Corteza', hex: '#57534E' },
      { id: 'gris_piedra_camo', name: 'Gris Piedra / Ceniza', hex: '#4B5563' },
      { id: 'negro_mate_canon', name: 'Negro Mate / Cañón', hex: '#18181B' }
    ],
    suggestedWardrobeDetails: ['Mira telescópica con tapas protectoras y visor óptico iluminado', 'Fibras ghillie colgando de hombros y capucha', 'Almohadilla de cuero acolchada en el hombro del retroceso', 'Rifle apoyado con bípode apuntando con calma matemática'],
    styleNote: 'Letalidad a mil metros, camuflaje óptico perfecto, balística de precisión e ingeniería de francotirador.'
  },

  'D7 Ninja / Shinobi': {
    roleName: 'D7 Ninja / Shinobi',
    category: 'Sigilo y Subterfugio',
    tagline: 'Sombras del Japón feudal, shozoku negro ajustado, máscara menpo de tela, ninjato a la espalda, shurikens y bombas de humo',
    description: 'Espía y saboteador clandestino oriental. Viste el traje tradicional Shinobi Shozoku con capucha y máscara de tela, ninjato de hoja recta y arsenal de kunais y abrojos.',
    recommendedOutfitType: 'O-NINJA Shinobi Shozoku Tradicional Negro con Máscara Facial, Ninjato Dorsal y Kunais',
    outfitTypes: [
      { id: 'O-NINJA-SHADOW', name: 'O-NINJA-SHADOW Shozoku Negro Medianoche con Capucha Fukumen y Ninjato' },
      { id: 'O-NINJA-KUNOICHI', name: 'O-NINJA-KUNOICHI Traje Ligero de Kunoichi con Mallas de Red, Cintas y Senbon' },
      { id: 'O-NINJA-WHITE', name: 'O-NINJA-WHITE Shinobi de Nieve con Ropajes Blancos de Infiltración Invernal' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Capuchas Fukumen y Máscaras Shinobi',
        pieces: [
          'P1.1 Capucha Fukumen de Tela Negra Envolviendo la Cabeza Dejando solo los Ojos Visibles',
          'P1.2 Máscara Menpo Metálica de Rostro de Demonio Oni Oscurecida',
          'P1.3 Cinta Hachimaki con Placa de Acero Frontal Oculta',
          'P1.4 Velo de Sombras Ninja de Malla Fina'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Chaquetas Shozoku y Malla Kusari',
        pieces: [
          'P2.1 Chaqueta Shinobi Shozoku Cruzada con Forro Interior Reversible y Bolsillos Ocultos',
          'P2.2 Camiseta de Malla Kusari (Cota de Malla Japonesa Ligera) Anti-Corte',
          'P2.3 Arnés de Cuero de Pecho para Sujeción de Shurikens y Ninjato',
          'P2.4 Chaleco de Cuero Acolchado con Ranuras de Kunais'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Fundas Dorsales y Capas de Fuga',
        pieces: [
          'P3.1 Funda Dorsal Cruzada para Ninjato de Hoja Recta',
          'P3.2 Manto de Fuga de Tela Negra Reversible a Mimetismo de Tejado',
          'P3.3 Hombreras de Cuero Suave sin Brillo'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Tekko y Guantes de Escalada con Garras',
        pieces: [
          'P4.1 Guanteletes Tekko con Garras de Acero Ocultas en las Palmas (Shuko) para Escalar',
          'P4.2 Envolturas de Tela Negra Apretadas en los Antebrazos con Agujas Senbon',
          'P4.3 Guantes de Cuero Fino sin Dedos para Lanzar Shurikens'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Obi con Bolsas de Humo y Abrojos',
        pieces: [
          'P5.1 Obi Ancho de Tela Negra con Compartimento Oculto para Polvos Cegadores (Metsubushi)',
          'P5.2 Bolsas Kinchaku Laterales Llenas de Abrojos Metálicos (Tetsubishi)',
          'P5.3 Tahalí para Cerbatana de Bambú y Dagas Kunai'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalones Iga Holgados con Ataduras',
        pieces: [
          'P6.1 Pantalones Iga-Bakama Holgados en Muslos y Ceñidos en Pantorrillas con Cintas',
          'P6.2 Medias de Red de Seda Resistente de Kunoichi con Fundas de Senbon',
          'P6.3 Perneras con Garras de Pie (Ashiko) para Escalada Vertical'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Botas Tabi con Dedo Dividido',
        pieces: [
          'P7.1 Botas Ninja Jika-Tabi de Lona Negra con Dedo Gordo Dividido y Suela de Goma Flexible',
          'P7.2 Sandalias Waraji Silenciosas con Plantilla de Tela Acolchada',
          'P7.3 Calzado de Agua Mizugumo para Caminar sobre el Agua y Fango'
        ]
      }
    ],
    materials: ['Lona de algodón teñida en azul noche profundo / negro', 'Malla ligera kusari de acero negro', 'Seda de alta resistencia para ataduras', 'Bambú tratado para cerbatanas', 'Acero forjado oscuro no reflectante'],
    finishes: ['Negro mate antirreflejos de noche', 'Tela silenciosa con doble costura plana', 'Acero oscurecido químicamente', 'Ataduras ajustadas sin cabos sueltos'],
    armorDefenses: [
      { id: 'AR-KAWARIMI-JUTSU', name: 'Técnica de Sustitución (Kawarimi)', desc: 'Al recibir un impacto letal, es reemplazado por un tronco de madera o humo' },
      { id: 'AR-SHINOBI-AGILITY', name: 'Paso Silencioso sobre Papel de Arroz', desc: 'Inaudible e indetectable por trampas acústicas o de vibración' }
    ],
    weapons: [
      'Ninjato (Espada Ninja de Hoja Recta de 60cm con Vaina Usada como Respiradero)',
      'Juego de 8 Shurikens de Estrella de Cuatro Puntas de Acero Templado',
      'Par de Dagas Kunai de Lanzamiento y Apalancamiento de Paredes',
      'Kusarigama (Hoz con Cadena y Contrapeso de Hierro para Desarmar)',
      'Cerbatana de Bambú Negro con Agujas Senbon Envenenadas'
    ],
    relicsAndItems: [
      'Bombas de Humo de Ceniza y Fósforo (Kemuridama) para Evasión Inmediata',
      'Polvos de Pimienta y Arena para Cegar (Metsubushi) en Cáscara de Huevo',
      'Pergamino con Técnicas Prohibidas del Clan Ninja Sellado en Sangre',
      'Garras Metálicas de Escalada de Mano (Shuko) y Pie (Ashiko)'
    ],
    bags: [
      'Funda Dorsal de Madera de Laca Negra Mate para Ninjato',
      'Morral Kinchaku de Tela para Proyectiles y Bombas de Humo',
      'Bolsa de Cinturón para Abrojos Tetsubishi de Despliegue Rápido',
      'Estuche Cilíndrico de Bambú para Agujas Senbon'
    ],
    equipmentFinishes: [
      'Acero al carbono oscurecido con acabado mate carbón',
      'Lona de algodón teñida con índigo oscuro tradicional japonés',
      'Vaina de ninjato con punta desmontable utilizable como cerbatana',
      'Empuñadura envuelta en cordón negro con textura antideslizante'
    ],
    suggestedColors: [
      { id: 'negro_shozoku', name: 'Negro Shinobi / Sombras', hex: '#09090B' },
      { id: 'azul_indigo_ninja', name: 'Azul Índigo Nocturno', hex: '#1E293B' },
      { id: 'rojo_kunoichi', name: 'Rojo Sangre / Kunoichi', hex: '#991B1B' },
      { id: 'blanco_nieve_ninja', name: 'Blanco Nieve / Infiltración', hex: '#F8FAFC' }
    ],
    suggestedWardrobeDetails: ['Capucha fukumen ajustada revelando solo la mirada concentrada', 'Ninjato cruzado en la espalda con la tsuka asomando sobre el hombro', 'Garras de escalada shuko en las manos listas para trepar muros', 'Pantalones abombados con ataduras ceñidas en las pantorrillas'],
    styleNote: 'Misticismo ninja oriental, funcionalidad acrobática de infiltración, kunais, shurikens y fugas de humo.'
  }
};
