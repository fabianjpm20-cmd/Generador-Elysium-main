import { RoleAttireConfig } from './types';

export const DARK_TECH_ROLES: Record<string, RoleAttireConfig> = {
  'F1 Caballero Oscuro': {
    roleName: 'F1 Caballero Oscuro',
    category: 'Oscuro, Abisal y Tecnología',
    tagline: 'Maldición y penitencia, armadura completa de hierro negro espinado, yelmo con cuernos demoníacos, capa rasgada y mandoble de llamas oscuras',
    description: 'Guerrero caído consumido por el abismo o la magia de sangre. Viste pesadas placas de hierro negro con bordes afilados y espinas, capa rasgada y mandoble corrupto.',
    recommendedOutfitType: 'O-DARK-KNIGHT Armadura Completa de Hierro Negro Espinado con Mandoble de Sangre',
    outfitTypes: [
      { id: 'O-DARK-KNIGHT-ABYSS', name: 'O-DARK-KNIGHT-ABYSS Placas Negras Afiladas con Ojos Carmesíes Resplandecientes' },
      { id: 'O-DARK-KNIGHT-DEATH', name: 'O-DARK-KNIGHT-DEATH Armadura de Caballero de la Muerte con Runas de Hielo Azul' },
      { id: 'O-DARK-KNIGHT-FALLEN', name: 'O-DARK-KNIGHT-FALLEN Paladín Caído con Armadura Plateada Agrietada y Cubierta de Espinas' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Yelmos con Cuernos y Visera Demoníaca',
        pieces: [
          'P1.1 Yelmo Cerrado de Hierro Negro con Cuernos Curvos de Carnero y Ojos Carmesíes Luminosos',
          'P1.2 Casco con Visera de Calavera Demoníaca en Relieve Afilado',
          'P1.3 Corona de Espinas de Hierro Oxidado sobre Cabeza Descubierta',
          'P1.4 Sallet Oscurecido con Ranura de Visión en T Llena de Sombras'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Peto de Hierro Negro y Escamas Abisales',
        pieces: [
          'P2.1 Peto de Hierro Negro Forjado en Fuego Demoníaco con Rebordes Dentados',
          'P2.2 Coraza de Placas Negras con Runa Abisal Sangrante en el Centro',
          'P2.3 Brigantina de Cuero Negro Reforzada con Placas de Acero Maldito',
          'P2.4 Malla de Anillas Negras de Alta Densidad bajo la Coraza'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Hombreras Espinadas y Capas Rasgadas',
        pieces: [
          'P3.1 Hombreras Gigantes con Espinas de Hierro y Cráneos de Carnero en los Vértices',
          'P3.2 Gran Capa Negra Desgarrada en la Base con Efecto de Humo Abisal Ondulante',
          'P3.3 Espaldar Pesado con Cadenas de Castigo Colgantes'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Guanteletes de Garras y Brazales Dentados',
        pieces: [
          'P4.1 Guanteletes de Placas de Hierro Negro con Dedos Rematados en Garras Afiladas',
          'P4.2 Brazales Dentados con Filos Cortantes en los Bordes Exteriores',
          'P4.3 Cadenas Negras Envolviendo los Antebrazos como Sello de Maldición'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Fauld de Hierro Negro y Cintos de Calaveras',
        pieces: [
          'P5.1 Fauld de Placas Negras Articuladas con Calaveras en Relieve',
          'P5.2 Cinturón Militar de Cuero Negro Grueso con Hebilla de Ojo Demoníaco',
          'P5.3 Tahalí para Mandoble Abisal y Daga de Sacrificio'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Escarcelas Espinadas y Grebas Negras',
        pieces: [
          'P6.1 Escarcelas Dentadas de Placas de Hierro Negro Protegiendo Muslos',
          'P6.2 Grebas de Acero Negro con Rodilleras de Cara Demoníaca',
          'P6.3 Quijotes Acolchados Forrados en Cuero Oscuro'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Escarpines de Garras de Hierro',
        pieces: [
          'P7.1 Escarpines de Hierro Negro con Puntas Afiladas en Forma de Garras',
          'P7.2 Botas Blindadas de Asedio con Suela Dentada Antiaplastamiento',
          'P7.3 Calzado de Placas con Espuelas de Púas Negras'
        ]
      }
    ],
    materials: ['Hierro negro forjado en fuego del abismo', 'Acero corrupto con pátina de sangre seca', 'Terciopelo negro rasgado', 'Cuero negro grueso de bestia abisal', 'Obsidiana volcánica'],
    finishes: ['Negro carbón mate con filos bruñidos', 'Resplandor carmesí / morado pulsante en runas y ojos', 'Acero espinado sin pulir', 'Rasgado en jirones de sombras'],
    armorDefenses: [
      { id: 'AR-ABYSSAL-PLATE', name: 'Armadura de Hierro Abisal Inquebrantable', desc: 'Absorbe daño físico y lo convierte en energía de furia corrupta' },
      { id: 'AR-DREAD-AURA', name: 'Aura de Pavor / Presencia Terrorífica', desc: 'Reduce el ataque y la moral de los enemigos que se enfrentan al caballero' }
    ],
    weapons: [
      'Mandoble de Dos Manos (Greatsword) de Hierro Negro con Filo Dentado e Imbuido en Fuego Carmesí',
      'Maza de Guerra Abisal con Cabeza de Estrella de Púas Maciza',
      'Hacha de Batalla Doble de Filos de Media Luna Negros',
      'Escudo Pesado en Forma de Ataúd con Ojo Abisal Central',
      'Lanza de Justa Negra con Púa Barbelada de Desgarrar'
    ],
    relicsAndItems: [
      'Corazón de Demonio Petrificado que Late con Fuego Negro',
      'Cadenas de Penitencia Forjadas con Almas Atormentadas',
      'Frasco de Sangre Corrupta que Imbuye las Armas en Veneno Mágico',
      'Grimorio de Juramentos Rotos Encuadernado en Cuero Negro'
    ],
    bags: [
      'Funda Dorsal de Cuero Negro Tachonado para el Mandoble Colosal',
      'Morral de Campaña Oscuro con Hebillas de Calavera',
      'Carcaj de Piel Negra para Jabalinas Dentadas',
      'Estuche Rígido de Hierro para el Yelmo Demoníaco'
    ],
    equipmentFinishes: [
      'Hierro forjado negro profundo con filos afilados expuestos en plata oscura',
      'Runas grabadas en bajo relieve con resplandor carmesí pulsante',
      'Cuero negro aceitado con remaches de punta cónica',
      'Empuñadura forrada en tiras de cuero desgastadas por sangre'
    ],
    suggestedColors: [
      { id: 'negro_hierro_abismo', name: 'Negro Abismo / Hierro', hex: '#09090B' },
      { id: 'rojo_carmesi_corrupcion', name: 'Rojo Carmesí / Sangre', hex: '#991B1B' },
      { id: 'purpura_abismo_oscuro', name: 'Púrpura Abisal / Maldición', hex: '#581C87' },
      { id: 'gris_plata_agrietada', name: 'Plata Ennegrecida / Ceniza', hex: '#475569' }
    ],
    suggestedWardrobeDetails: ['Placas de hierro negro con espinas y bordes afilados', 'Resplandor carmesí brillante en las hendiduras del yelmo y la espada', 'Gran capa negra rasgada en la base ondeando como alas de pesadilla', 'Cadenas de hierro negro colgando del peto y hombreras'],
    styleNote: 'Terror gótico abisal, hierro negro espinado, resplandor carmesí demoníaco y colosal presencia física.'
  },

  'F2 Inquisidor': {
    roleName: 'F2 Inquisidor',
    category: 'Oscuro, Abisal y Tecnología',
    tagline: 'Celo fanático de purga, abrigo largo de cuero rojo y negro con cuello alto, sombrero tricornio / capirote, espada bendecida y pistola de fuego sagrado',
    description: 'Juez implacable y cazador de herejes. Viste gabardinas de cuero estructuradas con cadenas de purificación, cruces de hierro, sombreros rígidos y porta decretos de condena.',
    recommendedOutfitType: 'O-INQUISITOR Gabardina de Cuero de Purga con Sombrero Rígido, Cruz de Hierro y Pistola de Fuego Sagrado',
    outfitTypes: [
      { id: 'O-INQUISITOR-PURGE', name: 'O-INQUISITOR-PURGE Gabardina Escarlata y Negra con Charreteras Doradas y Decretos' },
      { id: 'O-INQUISITOR-HOOD', name: 'O-INQUISITOR-HOOD Atuendo de Juez Supremo con Gran Capirote y Máscara de Ojos de Plata' },
      { id: 'O-INQUISITOR-ZEALOT', name: 'O-INQUISITOR-ZEALOT Armadura de Pecho de Acero con Cadenas de Culpabilidad y Antorcha' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Sombreros de Inquisidor y Máscaras',
        pieces: [
          'P1.1 Sombrero Rígido de Copa Ancha de Inquisidor con Cinta de Cuero y Cruz de Plata',
          'P1.2 Gran Capirote / Capucha Puntiaguda con Ranuras para Ojos de Penitente',
          'P1.3 Máscara de Acero Plateado que Oculta la Mitad Inferior del Rostro',
          'P1.4 Cuello Alzado Rígido de Cuero que Cubre hasta la Barbilla'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Gabardinas Escarlatas y Pecheras de Acero',
        pieces: [
          'P2.1 Gabardina Larga de Cuero Escarlata y Negro con Doble Fila de Botones Dorados',
          'P2.2 Peto de Acero Grabado con el Emblema del Tribunal Sagrado',
          'P2.3 Chaleco de Terciopelo Púrpura Oscuro con Cadena de Relicario',
          'P2.4 Camisa de Lino Negro con Cuello Almidonado Riguroso'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Hombreras de Mando y Capas Militares',
        pieces: [
          'P3.1 Capa Corta Terciada Escarlata con Charreteras de Flecos de Oro',
          'P3.2 Hombreras de Cuero Grueso con Puntas de Cruz Latina',
          'P3.3 Manto Largo de Purga con Forro Ignífugo'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Guantes de Cuero Rígido y Brazales',
        pieces: [
          'P4.1 Guantes de Cuero Negro de Caña Alta con Hebillas de Oro en la Muñeca',
          'P4.2 Brazales de Acero con Sellos de Excomunión Grabados',
          'P4.3 Muñequeras con Tiras de Pergamino de Juicios Pendientes'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturones con Decretos y Cadenas',
        pieces: [
          'P5.1 Cinturón Ancho de Cuero con Sellos de Cera Roja, Manojo de Llaves de Celda y Decretos',
          'P5.2 Tahalí Doble Cruzado para Espada de Ejecución y Pistola de Chispa',
          'P5.3 Faja Escarlata con Cadenas de Culpabilidad Colgantes'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalones de Montar y Faldones de Gabardina',
        pieces: [
          'P6.1 Pantalones de Montar de Paño Negro Ajustados y Reforzados en Entrepierna',
          'P6.2 Faldones Largos de la Gabardina con Forro Carmesí Abriéndose al Caminar',
          'P6.3 Perneras de Cuero Grueso con Costuras Dobles'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Botas de Oficial de Caña Alta',
        pieces: [
          'P7.1 Botas de Montar Militares de Charol Negro con Espuelas de Plata',
          'P7.2 Botines de Cuero Rígido con Hebillas Doradas Frontales',
          'P7.3 Botas de Suela Gruesa Claveteada con Puntera de Acero'
        ]
      }
    ],
    materials: ['Cuero negro y escarlata de alta calidad', 'Paño militar pesado', 'Plata esterlina y latón dorado', 'Acero templado al aceite', 'Pergamino y cera de sellado'],
    finishes: ['Sastrería militar autoritaria impecable', 'Charol negro brillante', 'Oro y plata con pátina solemne', 'Bordes con vivos dorados'],
    armorDefenses: [
      { id: 'AR-PURGE-ZEAL', name: 'Celo Fanático Inviolable', desc: 'Inmunidad a la manipulación mental, encantos y daño de fuego o magia oscura' },
      { id: 'AR-INQUISITION-MIGHT', name: 'Autoridad del Gran Tribunal', desc: 'Provoca parálisis y temor en enemigos culpables de herejía o traición' }
    ],
    weapons: [
      'Espada de Ejecución de Hoja Recta con Punta Cuadrada y Grabados de Purga',
      'Pistola de Chispa de Fuego Sagrado con Cañón de Plata y Balas Incendiarias',
      'Martillo de Hereje con Cabeza Cuadrada Grabada con Cruces',
      'Látigo de Cadenas de Nueve Puntas con Púas de Plata (Flagelo Sagrado)',
      'Estoque Fino de Inquisidor con Guarda de Cruz'
    ],
    relicsAndItems: [
      'Decreto de Purga Sellado en Cera con el Nombre del Condenado',
      'Marca de Fuego de Hierro con el Emblema del Tribunal',
      'Libro de Condenas / Manual del Inquisidor con Tapa de Cuero Rojo',
      'Frasco de Fuego Sagrado Líquido que Arde sin Extinguirse'
    ],
    bags: [
      'Portadocumentos Rígido de Cuero con Sellos de Seguridad para Actas de Juicio',
      'Cartuchera de Cuero para Munición Sagrada y Fósforo',
      'Funda Rígida Forrada en Terciopelo para Espada de Ejecución',
      'Maletín de Interrogatorio con Instrumentos de Acero de Precisión'
    ],
    equipmentFinishes: [
      'Cuero escarlata y negro brillante con remaches dorados',
      'Plata y acero pulidos con citas eclesiásticas en bajorrelieve',
      'Sellos de cera roja brillante con cintas de tela blanca',
      'Madera noble de caoba en culatas de pistolas'
    ],
    suggestedColors: [
      { id: 'rojo_inquisidor', name: 'Rojo Carmesí / Purga', hex: '#991B1B' },
      { id: 'negro_inquisidor', name: 'Negro Tribunal / Charol', hex: '#0F172A' },
      { id: 'dorado_celo', name: 'Dorado Celo / Autoridad', hex: '#EAB308' },
      { id: 'blanco_pergamino', name: 'Blanco Pergamino / Decreto', hex: '#F8FAFC' }
    ],
    suggestedWardrobeDetails: ['Gabardina escarlata estructurada con doble fila de botones dorados', 'Sombrero rígido con cruz de plata arrojando sombra', 'Pistola de chispa en la mano izquierda y espada de ejecución en la derecha', 'Pergaminos con sellos de cera colgando de la cintura'],
    styleNote: 'Fanatismo implacable de inquisición, elegancia autoritaria, cuero escarlata y fuego de purga.'
  },

  'F3 Cazador de Monstruos / Brujo': {
    roleName: 'F3 Cazador de Monstruos / Brujo',
    category: 'Oscuro, Abisal y Tecnología',
    tagline: 'Mutagénesis y contratos, armadura ligera de cuero y cota de malla, dos espadas a la espalda (acero y plata), pociones mutagénicas y ojos felinos',
    description: 'Guerrero mutado profesional en la caza de aberraciones. Porta dos espadas cruzadas a la espalda (acero para humanos, plata para monstruos), pociones tóxicas y signos mágicos.',
    recommendedOutfitType: 'O-WITCHER Armadura de Cuero Tachonado y Cota de Malla con Dos Espadas a la Espalda',
    outfitTypes: [
      { id: 'O-WITCHER-WOLF', name: 'O-WITCHER-WOLF Jubón de Cuero de la Escuela del Lobo con Hombreras de Malla y Medallón' },
      { id: 'O-WITCHER-CAT', name: 'O-WITCHER-CAT Armadura Ligera de Cuero Azul con Capucha y Dagas de Agilidad' },
      { id: 'O-WITCHER-BEAR', name: 'O-WITCHER-BEAR Armadura Pesada con Falda Larga de Paño y Cuello de Piel de Oso' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Medallón de Lobo y Ojos Felinos',
        pieces: [
          'P1.1 Medallón de Cabeza de Lobo / Bestia de Plata que Vibra ante la Magia',
          'P1.2 Cinta de Cuero Fina para el Pelo Despejando Ojos Felinos Amarillos Mutados',
          'P1.3 Capucha de Cuero Oscuro de la Escuela del Gato',
          'P1.4 Máscara de Respiración contra Esporas de Monstruos de Ciénaga'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Jubones de Cuero y Malla Remachada',
        pieces: [
          'P2.1 Jubón de Cuero Tachonado con Refuerzos de Cota de Malla en Axilas y Cuello',
          'P2.2 Arnés de Pecho en X con Soportes Gemelos de Espaldas Cruzadas',
          'P2.3 Chaleco de Cuero Acolchado con Bandolera de Pociones de Mutágeno',
          'P2.4 Camisa de Lino Rústico con Cordones Sueltos'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Fundas Gemelas Cruzadas y Cuellos de Piel',
        pieces: [
          'P3.1 Funda Dorsal Doble Cruzada para Espada de Acero y Espada de Plata',
          'P3.2 Cuello de Piel de Oso o Lobo Protegiendo los Hombros del Frío',
          'P3.3 Capa Corta Impermeable de Viajero Encerada'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Guanteletes con Tachuelas y Brazales de Malla',
        pieces: [
          'P4.1 Guanteletes de Cuero con Tachuelas de Plata en Nudillos para Golpear Espectros',
          'P4.2 Brazales de Cuero con Refuerzos de Acero Roscado',
          'P4.3 Manguitos de Cota de Malla Flexibles'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturones con Bombas y Pociones',
        pieces: [
          'P5.1 Cinturón Militar con Bolsas de Bombas de Metralla, Fuego y Polvo Lunar',
          'P5.2 Estuche de Cinturón con 4 Frascos de Pociones Mutagénicas (Golondrina, Gato, Trueno)',
          'P5.3 Tahalí para Cuchillo de Desollar Bestias y Gancho de Trofeo'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalones de Cuero Reforzado y Faldón',
        pieces: [
          'P6.1 Pantalón de Cuero Grueso Flexible con Costuras en Zigzag',
          'P6.2 Faldón Corto de Cuero Dividido para Libertad de Giros y Piruetas',
          'P6.3 Rodilleras de Cuero Rígido Acolchado'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Botas de Caza con Hebillas Múltiples',
        pieces: [
          'P7.1 Botas de Cuero de Caña Alta con Múltiples Hebillas y Suela de Goma de Agarre',
          'P7.2 Botines de Combate con Puntera Blindada',
          'P7.3 Polainas de Cuero Encerado contra Sangre Ácida de Monstruos'
        ]
      }
    ],
    materials: ['Cuero de ternera curtido al cromo', 'Plata pura encantada para monstruos', 'Acero de meteorito para bestias terrenales', 'Cota de malla remachada', 'Mutágenos alquímicos'],
    finishes: ['Cuero gastado con pátina de cien batallas', 'Plata con grabados de runas élficas', 'Cota de malla oscurecida', 'Venas oscuras temporales por toxicidad de pociones'],
    armorDefenses: [
      { id: 'AR-WITCHER-MUTATIONS', name: 'Mutaciones de Brujo / Sangre Tóxica', desc: 'Inmunidad total a venenos comunes y resistencia masiva a magia mental' },
      { id: 'AR-QUEN-SHIELD', name: 'Escudo Quen / Campo de Fuerza Reactivo', desc: 'Absorbe por completo el daño del primer ataque enemigo' }
    ],
    weapons: [
      'Espada de Acero de Meteorito (Para Humanos y Bestias Físicas)',
      'Espada de Plata Pura con Runas de Daño a Espectros y Monstruos Mágicos',
      'Ballesta de Mano Ligera para Disparos Rápidos a Voladores',
      'Bombas Alquímicas (Viento del Norte, Estrella Danzante, Polvo Lunar)',
      'Daga de Despiece con Mango de Cuerno de Quimera'
    ],
    relicsAndItems: [
      'Medallón de la Escuela del Brujo que Vibra ante Monstruos Cercanos',
      'Aceite para Espadas de Veneno de Ahorcado y Aceite para Espectros',
      'Frasco de Poción Golondrina de Regeneración Celular Acelerada',
      'Gancho de Trofeo con Cabeza de Grifo / Cocatriz Recién Abatida'
    ],
    bags: [
      'Alforjas de Cuero para Caballo con Libros de Monstruos e Ingredientes',
      'Carcaj de Virolotes Cortos para Ballesta de Mano',
      'Funda Doble Dorsal de Madera y Cuero para Espadas Gemelas',
      'Bolsa de Bandolera para Frascos de Mutágenos'
    ],
    equipmentFinishes: [
      'Plata resplandeciente con runas de brillo azul tenue',
      'Acero gris mate con canal de desagüe de sangre',
      'Cuero marrón tostado con tachuelas de latón envejecido',
      'Frascos de pociones con tapón de cera y líquidos de colores vivos'
    ],
    suggestedColors: [
      { id: 'marron_cuero_brujo', name: 'Cuero Brujo / Roble', hex: '#57534E' },
      { id: 'plata_espada_monstruo', name: 'Plata Monstruo / Élfica', hex: '#CBD5E1' },
      { id: 'amarillo_ojos_mutados', name: 'Amarillo Ojo Felino', hex: '#EAB308' },
      { id: 'negro_malla_cota', name: 'Negro Cota de Malla', hex: '#1C1917' }
    ],
    suggestedWardrobeDetails: ['Dos empuñaduras de espada asomando sobre el hombro derecho', 'Medallón de plata de lobo visible sobre el pecho', 'Venas oscuras tenues en el rostro por el uso de pociones mutagénicas', 'Ojos de pupila vertical felina color amarillo dorado'],
    styleNote: 'Pragmatismo de cazador profesional, doble espada a la espalda, pociones mutagénicas y letalidad calculada.'
  },

  'F4 Guerrero Rúnico': {
    roleName: 'F4 Guerrero Rúnico',
    category: 'Oscuro, Abisal y Tecnología',
    tagline: 'Fusión de forja nórdica y magia de grabado, armadura pesada con glifos brillantes, runas talladas en piel y acero, y gran martillo rúnico',
    description: 'Campeón imbuido con la magia primordial de las runas nórdicas. Porta armadura de placas grabada con inscripciones resplandecientes que potencian su fuerza y defensa.',
    recommendedOutfitType: 'O-RUNIC Armadura Pesada Nórdica con Runas Grabadas Resplandecientes y Martillo Gigante',
    outfitTypes: [
      { id: 'O-RUNIC-TITAN', name: 'O-RUNIC-TITAN Placas de Acero Grabadas con Runas Azules de Hielo y Espadón Gigante' },
      { id: 'O-RUNIC-VALKYRIE', name: 'O-RUNIC-VALKYRIE Armadura Escamada Plateada con Runas Doradas y Lanza de Rayo' },
      { id: 'O-RUNIC-BERSERK', name: 'O-RUNIC-BERSERK Cuero y Pieles con Runas de Sangre Tatuadas Brillantes' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Cascos Rúnicos y Diademas Nórdicas',
        pieces: [
          'P1.1 Casco Nórdico con Protectores Faciales Grabados con Runas Resplandecientes',
          'P1.2 Diadema de Mithril con Runa de Sabiduría Ancestral en la Frente',
          'P1.3 Tatuajes Faciales Rúnicos que Brillan al Concentrar Energía',
          'P1.4 Casco con Cuernos de Carnero Grabados con Glifos de Protección'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Peto de Acero Rúnico y Corazas',
        pieces: [
          'P2.1 Peto de Acero Forjado con un Gran Glifo de la Montaña Brillando en el Pecho',
          'P2.2 Cota de Escamas de Acero con Cada Escama Grabada con una Runa',
          'P2.3 Brigantina de Cuero con Placas Rúnicas Interiores',
          'P2.4 Manto Cruzado con Broche Rúnico de Ojo de Odín'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Hombreras Rúnicas y Mantos de Piel',
        pieces: [
          'P3.1 Hombreras de Placas de Acero con Runas de Fuerza que Emite Luz Pulsante',
          'P3.2 Manto de Piel de Lobo Blanco Nórdico Sujeto con Cadenas Rúnicas',
          'P3.3 Espaldar con Runa de Inamovilidad Grabada'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Brazaletes Rúnicos y Guanteletes de Titán',
        pieces: [
          'P4.1 Guanteletes de Placas con Runas de Aplastamiento en los Nudillos',
          'P4.2 Brazales de Acero con Glifos de Velocidad que Brillan al Golpear',
          'P4.3 Envolturas de Cuero con Tatuajes Rúnicos en los Antebrazos'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturones con Piedras Rúnicas',
        pieces: [
          'P5.1 Cinturón Militar con 6 Piedras Rúnicas de Conjuración Engarzadas en Oro',
          'P5.2 Fauld de Placas Grabadas Protegiendo Caderas',
          'P5.3 Tahalí para Gran Martillo Rúnico o Espadón'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Grebas Rúnicas y Escarcelas',
        pieces: [
          'P6.1 Grebas de Acero con Runas de Salto y Resistencia Terrestre',
          'P6.2 Escarcelas de Placas con Bordes Grabados al Aguafuerte',
          'P6.3 Pantalón de Paño de Lana Gruesa Nórdica'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Escarpines con Sellos de Terreno',
        pieces: [
          'P7.1 Escarpines de Acero con Runas de Agarre al Hielo y Terreno Rocoso',
          'P7.2 Botas de Cuero de Oso con Placas Rúnicas Frontales',
          'P7.3 Calzado Blindado con Puntera de Impacto Rúnico'
        ]
      }
    ],
    materials: ['Acero estelar forjado con runas nórdicas', 'Mithril con incrustaciones de polvo de cristal', 'Pieles árticas de lobo blanco y oso', 'Piedras de granito rúnico', 'Cuero grueso de buey nórdico'],
    finishes: ['Luminiscencia azul celeste / dorada en los grabados rúnicos', 'Acero con pátina de hielo ártico', 'Relieves profundos tallados a cincel', 'Pieles suaves y densas'],
    armorDefenses: [
      { id: 'AR-RUNIC-AEGIS', name: 'Égida Rúnica de la Forja Ancestral', desc: 'Absorbe daño elemental (hielo, fuego, rayo) y lo disipa sin dañar al guerrero' },
      { id: 'AR-TITAN-STRENGTH', name: 'Poder de los Titanes Rúnicos', desc: 'Otorga una fuerza destructiva colosal capaz de quebrar armaduras enemigas' }
    ],
    weapons: [
      'Gran Martillo de Guerra Rúnico con Cabeza de Meteorito y Glifos de Trueno',
      'Espadón Nórdico de Dos Manos con Runas de Fuego Flotando en el Filo',
      'Hacha Rúnica de Dos Filos con Runa de Hielo Glaciar',
      'Escudo Redondo Nórdico con el Nudo Rúnico de Valknut Tallado en Oro',
      'Lanza de Rayo con Punta de Mithril Rúnico'
    ],
    relicsAndItems: [
      'Piedra Rúnica de Teletransporte / Retorno a la Forja Sagrada',
      'Bolsa con Conjunto de 24 Runas del Futhark de Hueso de Dragón',
      'Cincel Rúnico de Diamante para Grabar Magia en Nuevas Armas',
      'Cuerno con Hidromiel de los Dioses que Otorga Visión Mística'
    ],
    bags: [
      'Morral de Cuero de Oso con Compartimentos para Piedras Rúnicas',
      'Funda Dorsal Blindada para Martillo Colosal',
      'Bolsa de Fieltro para Guardar las Runas de Adivinación',
      'Alforjas de Cuero Reforzado con Sellos de Seguridad'
    ],
    equipmentFinishes: [
      'Grabados rúnicos con acabado de esmalte brillante luminiscente',
      'Acero con reflejos azulados de temple ártico',
      'Madera de fresno (Yggdrasil) tratada con aceites sagrados',
      'Cuero marrón oscuro con estampados geométricos nórdicos'
    ],
    suggestedColors: [
      { id: 'azul_runico_brillante', name: 'Azul Rúnico / Hielo', hex: '#38BDF8' },
      { id: 'acero_nordico', name: 'Acero Nórdico / Forja', hex: '#CBD5E1' },
      { id: 'dorado_valquiria', name: 'Dorado Runa / Sol', hex: '#F59E0B' },
      { id: 'marron_cuero_nordico', name: 'Marrón Cuero / Piel', hex: '#451A03' }
    ],
    suggestedWardrobeDetails: ['Runas brillantes iluminándose con intensidad al empuñar el arma', 'Manto de piel de lobo blanco sobre los hombros', 'Gran martillo rúnico con chispas de energía mágica', 'Tatuajes rúnicos en los brazos que coinciden con los de la armadura'],
    styleNote: 'Majestuosidad nórdica imponente, magia de runas vivas resplandecientes, forja de titanes y fuerza mítica.'
  },

  'F5 Ingeniero Steampunk / Tecnomago': {
    roleName: 'F5 Ingeniero Steampunk / Tecnomago',
    category: 'Oscuro, Abisal y Tecnología',
    tagline: 'Vapor, engranajes y magia voltaica, chaleco de cuero con relojería de latón, gafas goggles de lentes múltiples, exoesqueleto y llave inglesa neumática',
    description: 'Inventor y manipulador de la tecno-magia de vapor y éter. Viste trajes de estilo victoriano con arneses de cobre, gafas de ingeniero (goggles), manómetros y prótesis mecánicas.',
    recommendedOutfitType: 'O-STEAMPUNK Atuendo de Ingeniero Victoriano con Goggles, Chaleco de Latón y Guantelete a Vapor',
    outfitTypes: [
      { id: 'O-STEAMPUNK-INVENTOR', name: 'O-STEAMPUNK-INVENTOR Chaleco de Tweed con Engranajes de Latón, Manómetros y Goggles' },
      { id: 'O-STEAMPUNK-EXO', name: 'O-STEAMPUNK-EXO Exoesqueleto de Cobre y Pistones Hidráulicos con Caldera Dorsal' },
      { id: 'O-STEAMPUNK-AIRSHIP', name: 'O-STEAMPUNK-AIRSHIP Uniforme de Capitán de Dirigible con Chaqueta Cruzada y Catalejo' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Goggles de Engranajes y Sombreros de Copa',
        pieces: [
          'P1.1 Goggles / Gafas de Latón con Lentes de Cristal Múltiples Tinte Ámbar y Lupa Abatible',
          'P1.2 Sombrero de Copa de Cuero con Engranajes y Pluma de Cobre Decorativa',
          'P1.3 Máscara de Respiración de Cuero con Filtro de Válvula de Latón y Escape de Vapor',
          'P1.4 Monóculo Mecánico con Indicador de Presión Voltaica'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Chalecos de Tweed y Arneses de Pistones',
        pieces: [
          'P2.1 Chaleco de Tweed / Paño con Doble Fila de Botones de Engranajes de Latón',
          'P2.2 Arnés de Cuero de Pecho con Manómetro de Presión y Válvula de Escape',
          'P2.3 Camisa de Cuello Mao con Rayas Finas Victorianas',
          'P2.4 Corpiño / Corsé de Cuero con Varillas de Cobre y Reloj de Bolsillo'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Caldera de Vapor Dorsal y Tubos de Cobre',
        pieces: [
          'P3.1 Caldera Dorsal Compacta de Cobre y Latón con Escape de Vapor y Chimenea Pequeña',
          'P3.2 Mochila Jetpack de Propulsión Voltaica con Aspas Giratorias',
          'P3.3 Hombrera Mecánica de Latón con Pistón Neumático Articulado'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Brazo Mecánico de Latón y Guanteletes Neumáticos',
        pieces: [
          'P4.1 Brazo Ortopédico de Cobre y Latón con Dedos Articulados y Engranajes Visibles',
          'P4.2 Guantelete de Cuero con Bobina de Tesla Integrada en la Muñeca',
          'P4.3 Manguitos de Cuero con Pulsera de Destornilladores de Precisión'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturones con Herramientas y Manómetros',
        pieces: [
          'P5.1 Cinturón de Herramientas de Cuero con Llaves Inglesas, Alicates y Aceitera de Bronce',
          'P5.2 Bandolera Cruzada con Baterías de Éter Cilíndricas',
          'P5.3 Tahalí para Llave Neumática de Asalto y Pistola Voltaica'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalones con Pistones y Refuerzos',
        pieces: [
          'P6.1 Pantalones de Rayas Victorianas con Refuerzos de Cuero en Rodillas',
          'P6.2 Musleras con Pistones Neumáticos que Aumentan la Fuerza de Salto',
          'P6.3 Falda con Corsé Asimétrica con Volantes y Hebillas Mecánicas'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Botas de Encofrado con Válvulas de Escape',
        pieces: [
          'P7.1 Botas Altas de Cuero de Aviador con Hebillas de Latón y Puntera de Cobre',
          'P7.2 Calzado con Muelles Amortiguadores Hidráulicos en la Suela',
          'P7.3 Botines Victorianos con Engranajes en los Tacones'
        ]
      }
    ],
    materials: ['Latón dorado y cobre rojo pulidos', 'Cuero grueso curtido al aceite', 'Tweed y lana británica clásica', 'Cristal óptico grueso de aumento', 'Tubos flexibles de caucho vulcanizado'],
    finishes: ['Latón brillante con vapor condensado', 'Engranajes mecánicos en movimiento', 'Cuero engrasado con manchas de aceite de motor', 'Reflejos ámbar en cristales'],
    armorDefenses: [
      { id: 'AR-STEAM-SHIELD', name: 'Escudo de Vapor y Presión Voltaica', desc: 'Emite una descarga de vapor a 200°C que ciega y empuja a los agresores' },
      { id: 'AR-EXO-REINFORCEMENT', name: 'Exoesqueleto Hidráulico de Cobre', desc: 'Incrementa masivamente la capacidad de carga y resistencia a impactos aplastantes' }
    ],
    weapons: [
      'Pistola Voltaica / Revólver de Chispa de Éter con Tambor de Cristal Giratorio',
      'Gran Llave Inglesa Neumática de Asalto con Pistón de Golpeo Hidráulico',
      'Rifle Lanzallamas de Vapor Recalentado con Depósito Dorsal',
      'Sierra Circular de Mano de Vapor con Disco Dentado de Diamante',
      'Cañón Arcano de Bobinas de Tesla de Bolsillo'
    ],
    relicsAndItems: [
      'Reloj de Bolsillo Multifunción con Barómetro, Brújula y Contador Geiger de Maná',
      'Plano Holográfico en Rollo de Papel de Calco de una Máquina Voladora',
      'Frasco de Éter Purificado / Batería de Carga Rápida Voltaica',
      'Juego de Llaves de Precisión de Relojero en Estuche de Terciopelo'
    ],
    bags: [
      'Maletín Rígido de Cuero y Latón con Compartimentos para Herramientas de Precisión',
      'Mochila Blindada con Caldera Compacta y Salida de Escape',
      'Cartuchera de Cuero para Baterías Cilíndricas de Cristal',
      'Funda de Cuero para Llave Neumática de Gran Tamaño'
    ],
    equipmentFinishes: [
      'Latón y bronce pulidos con pequeños remaches redondos en hilera',
      'Cristal óptico ámbar con tratamiento antirreflejante de época',
      'Tubos de cobre curvados con racores de unión roscados',
      'Cuero color marrón tostado con costuras gruesas de hilo blanco'
    ],
    suggestedColors: [
      { id: 'laton_dorado_steam', name: 'Latón Dorado / Engranaje', hex: '#CA8A04' },
      { id: 'cobre_rojo_steam', name: 'Cobre Rojo / Tubería', hex: '#B45309' },
      { id: 'marron_tweed', name: 'Marrón Tweed / Cuero', hex: '#78350F' },
      { id: 'azul_voltaico', name: 'Azul Voltaico / Éter', hex: '#0284C7' }
    ],
    suggestedWardrobeDetails: ['Goggles con múltiples lentes de aumento colocados en la frente o sombrero', 'Tubos de cobre y manómetros en miniatura conectados al pecho', 'Pequeñas bocanadas de vapor saliendo periódicamente de las válvulas', 'Guantelete o brazo con engranajes giratorios visibles'],
    styleNote: 'Ingenio victoriano retrofuturista, estética steampunk de latón y vapor, relojería intrincada y energía voltaica.'
  },

  'F6 Pistolero Arcano': {
    roleName: 'F6 Pistolero Arcano',
    category: 'Oscuro, Abisal y Tecnología',
    tagline: 'Duelo en la frontera mágica, poncho de viajero, sombrero vaquero de ala doblada, revólveres arcanos con runas y cartucheras de cristales',
    description: 'Pistolero del lejano oeste mágico. Viste guardapolvo largo desgastado, sombrero vaquero, botas con espuelas resonantes y desenfunda revólveres imbuidos en hechizos elementales.',
    recommendedOutfitType: 'O-GUNSLINGER Guardapolvo de Cuero Desgastado con Sombrero Vaquero y Revólveres Arcanos Gemelos',
    outfitTypes: [
      { id: 'O-GUNSLINGER-DESERT', name: 'O-GUNSLINGER-DESERT Poncho de Lana con Sombrero Vaquero, Bandolera de Balas y Duelo Rápido' },
      { id: 'O-GUNSLINGER-ARCANE', name: 'O-GUNSLINGER-ARCANE Guardapolvo Largo Negro con Runas Azules y Revólveres de Plasma' },
      { id: 'O-GUNSLINGER-SHERIFF', name: 'O-GUNSLINGER-SHERIFF Chaqueta de Sheriff con Placa de Oro y Escopeta Arcana' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Sombreros Vaqueros y Pañuelos de Duelo',
        pieces: [
          'P1.1 Sombrero Vaquero de Fieltro / Cuero con Ala Ancha Doblada y Banda de Balas',
          'P1.2 Pañuelo Bandana de Seda Roja Cubriendo Nariz y Boca contra el Polvo de Dunas',
          'P1.3 Ojos Entrecerrados con Puro / Cerilla Mágica en la Comisura de los Labios',
          'P1.4 Gafas de Duelo contra Resplandores de Fogonazo Arcano'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Guardapolvos Largos y Chalecos de Cuero',
        pieces: [
          'P2.1 Guardapolvo Largo (Duster Coat) de Lona Encerada Abriéndose al Desenfunde',
          'P2.2 Poncho de Lana con Patrón Geométrico del Desierto Terciado al Hombro',
          'P2.3 Chaleco de Cuero Negro con Botones de Plata y Cadena de Reloj',
          'P2.4 Camisa Vaquera de Algodón con Cuello Abierto y Mangas Remangadas'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Hombreras de Cuero y Fundas de Escopeta',
        pieces: [
          'P3.1 Hombrera de Cuero con Cartuchera para Cartuchos de Escopeta Arcana',
          'P3.2 Manto de Guardapolvo con Vuelo al Viento del Desierto',
          'P3.3 Arnés Dorsal para Escopeta Recortada de Dos Cañones'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Guantes de Desenfunde Rápido y Brazales',
        pieces: [
          'P4.1 Guantes de Piel de Ciervo Suave de Desenfunde Rápido (Quick-Draw)',
          'P4.2 Brazales de Cuero con Grabados de Llamas y Compartimento de Balas',
          'P4.3 Muñequeras con Resorte Expulsor de Cartucho Vacío'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Pistoleras Gemelas de Desenfunde Rápido',
        pieces: [
          'P5.1 Cartuchera Doble de Cuero Bajada a los Muslos (Low-Drop Holsters) con Cordones de Amarre',
          'P5.2 Cinturón de Balas con 30 Cartuchos de Colores Elementales (Fuego, Hielo, Rayo)',
          'P5.3 Gran Hebilla Vaquera de Plata con Cabeza de Toro o Cruz Arcana'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Zahones de Cuero (Chaps) y Pantalones',
        pieces: [
          'P6.1 Zahones (Chaps) de Cuero Grueso sobre Pantalones Vaqueros con Flecos Laterales',
          'P6.2 Pantalones de Mezclilla Resistentes con Refuerzo de Cuero',
          'P6.3 Perneras con Fundas para Cuchillo Bowie'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Botas Vaqueras con Espuelas Sonoras',
        pieces: [
          'P7.1 Botas Vaqueras de Cuero con Tacón Cubano y Puntera Afilada con Espuelas de Plata',
          'P7.2 Espuelas con Ruedas de Púas de Plata que Suenan al Caminar (Jingle-Jangle)',
          'P7.3 Botines de Duelo de Agarre Rápido en Suelo Arenoso'
        ]
      }
    ],
    materials: ['Lona encerada de guardapolvo', 'Cuero grueso de vaqueta curtido', 'Plata cincelada para hebillas y espuelas', 'Acero templado con grabado al aguafuerte', 'Madera de nogal para cachas de revólver'],
    finishes: ['Desgastado por el polvo del desierto y el humo de pólvora', 'Plata patinada con brillo en aristas', 'Cuero flexible en pistoleras', 'Filos y cañones con pátina pavonada'],
    armorDefenses: [
      { id: 'AR-QUICK-REFLEX', name: 'Reflejo de Desenfunde Instantáneo', desc: 'Dispara y esquiva antes de que el agresor pueda completar su movimiento' },
      { id: 'AR-DUST-EVASION', name: 'Evasión de Torbellino de Arena', desc: 'Genera una nube de polvo que desvía proyectiles y ataques a distancia' }
    ],
    weapons: [
      'Par de Revólveres Arcanos de Seis Balas con Cañón Estriado y Tambor de Cristal de Fuego',
      'Escopeta de Dos Cañones Recortada Arcana con Disparo de Metralla de Fuego Griego',
      'Rifle de Palanca Winchester Arcano con Mira de Precisión',
      'Cuchillo Bowie Gigante con Sierra en el Lomo',
      'Dinamita Arcana de Cristal con Mecha de Fósforo Mágico'
    ],
    relicsAndItems: [
      'Cartucho de Cristal de la Última Esperanza (Bala Legendaria Perforante)',
      'Reloj de Bolsillo con Foto Antigua y Marcas de Tiempo de Duelos Vencidos',
      'Placa de Estrella de Sheriff de Plata de la Frontera Arcana',
      'Petaca de Cuero con Whisky de Raíces de Fuego'
    ],
    bags: [
      'Pistoleras Gemelas de Cuero Repujado con Forro de Gamuza Rápida',
      'Alforjas de Cuero para Caballo con Suministros de Campamento',
      'Caja Metálica Impermeable para Cartuchos Arcanos de Repuesto',
      'Funda Rígida para Escopeta Recortada'
    ],
    equipmentFinishes: [
      'Cachas de revólver de madera de nogal o nácar con relieve de águila',
      'Cañón de acero pavonado azul profundo con grabados florales dorados',
      'Espuelas de plata con sonido tintineante característico',
      'Cuero marrón gastado con aceite de linaza'
    ],
    suggestedColors: [
      { id: 'marron_tierra_vaquero', name: 'Marrón Cuero / Dunas', hex: '#78350F' },
      { id: 'rojo_poncho', name: 'Rojo Poncho / Atardecer', hex: '#B91C1C' },
      { id: 'plata_espuela', name: 'Plata Espuela / Placa', hex: '#E2E8F0' },
      { id: 'negro_polvora', name: 'Negro Pólvora / Duelo', hex: '#18181B' }
    ],
    suggestedWardrobeDetails: ['Guardapolvo ondeando hacia atrás dejando ver las pistoleras en las caderas', 'Espuelas de plata sonando a cada paso pausado', 'Sombrero vaquero tapando la mitad de la mirada desafiante', 'Humo azul tenue saliendo de los cañones de los revólveres'],
    styleNote: 'Western mágico de frontera salvaje, revólveres arcanos rápidos, guardapolvos polvorientos y espuelas de plata.'
  },

  'F7 Señor de la Guerra': {
    roleName: 'F7 Señor de la Guerra',
    category: 'Oscuro, Abisal y Tecnología',
    tagline: 'Dominación imperial tiránica, armadura colosal de hierro y púas, hombreras gigantes con cráneos, manto de sangre y maza del conquistador',
    description: 'Comandante supremo de ejércitos conquistadores. Su sola presencia infunde pavor. Viste armadura monumental sobredimensionada con relieves de bestias de presa y trono de guerra.',
    recommendedOutfitType: 'O-WARLORD Armadura Monumental de Placas de Hierro y Púas con Gran Manto de Sangre',
    outfitTypes: [
      { id: 'O-WARLORD-CONQUEROR', name: 'O-WARLORD-CONQUEROR Placas de Hierro Negro y Oro con Gran Manto Carmesí y Maza de Conquista' },
      { id: 'O-WARLORD-HORDE', name: 'O-WARLORD-HORDE Armadura de Horda Bárbara con Cráneos Gigantes y Pieles de Mamut' },
      { id: 'O-WARLORD-TYRANT', name: 'O-WARLORD-TYRANT Armadura Imperial de Placas de Acero y Corona de Púas de Tirano' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Coronas de Tirano y Cascos Monstruosos',
        pieces: [
          'P1.1 Corona de Púas de Hierro Forjado de Conquistador con Joyas Ensangrentadas',
          'P1.2 Casco Cerrado con Máscara Facial de Rictus de Bestia Rugiente y Colmillos',
          'P1.3 Gran Yelmo con Penacho Gigante de Crin de Caballo Negra',
          'P1.4 Diadema de Mando con Ojo Carmesí Central de la Tiranía'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Coraza Colosal de Doble Espesor y Relieves',
        pieces: [
          'P2.1 Peto Colosal de Hierro Forjado con Relieve de Dragón / León Devorando Coronas',
          'P2.2 Pechera de Placas Superpuestas de Acero Pesado de Asedio',
          'P2.3 Brigantina de Cuero de Rinoceronte Reforzada con Pernos de Bronce',
          'P2.4 Malla de Guerra de Eslabones Gruesos bajo la Armadura'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Hombreras Colosales y Manto Imperial de Conquista',
        pieces: [
          'P3.1 Hombreras Monstruosas Sobredimensionadas con Púas de Asedio y Cráneos Trofeo',
          'P3.2 Gran Manto de Sangre de Terciopelo Escarlata de 4 Metros de Cola',
          'P3.3 Piel de Monstruo Alfa Gigante con la Cabeza Reposando en el Hombro'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Guanteletes de Aplastamiento y Brazales de Mando',
        pieces: [
          'P4.1 Guanteletes Gigantes de Placas Articuladas con Púas Rompehuesos en los Nudillos',
          'P4.2 Brazales de Acero con Cuchillas Laterales para Combate en Melé',
          'P4.3 Brazaletes Anchos de Oro y Hierro de Señor de la Guerra'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Fauld de Conquistador y Cinturón de Mandíbulas',
        pieces: [
          'P5.1 Fauld de Placas de Asedio Articuladas con Relieves de Ciudades en Llamas',
          'P5.2 Cinturón Ancho de Cuero Grueso con Calaveras de Reyes Derrotados',
          'P5.3 Tahalí Doble para Gran Maza y Espada de Guerra'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Escarcelas Monumentales y Grebas Pesadas',
        pieces: [
          'P6.1 Escarcelas de Placas de Hierro que Cubren Muslos Enteros',
          'P6.2 Grebas Pesadas de Acero de Asedio con Puntas en las Rodillas',
          'P6.3 Quijotes Acorazados con Forro de Cuero de Bestia'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Escarpines Pesados Antiaplastamiento',
        pieces: [
          'P7.1 Escarpines de Hierro de Base Ancha Diseñados para Pisar Enemigos Caídos',
          'P7.2 Botas Blindadas de Conquista con Punteras Dentadas',
          'P7.3 Calzado de Placas con Espuelas de Púas Gigantes'
        ]
      }
    ],
    materials: ['Hierro negro macizo forjado a martillo de vapor', 'Acero templado de blindaje de asedio', 'Terciopelo escarlata pesado', 'Pieles de bestias alfa descomunales', 'Oro de tesoros de reinos saqueados'],
    finishes: ['Hierro mate imponente con muescas de asedio', 'Relieves escultóricos agresivos de victoria', 'Terciopelo ondeante pesado', 'Remaches colosales'],
    armorDefenses: [
      { id: 'AR-WARLORD-JUGGERNAUT', name: 'Blindaje Imparable de Juggernaut', desc: 'Inmunidad a derribos, aturdimientos y absorción de impacto de artillería' },
      { id: 'AR-COMMAND-DOMINION', name: 'Dominio Tiránico del Conquistador', desc: 'Aumenta el daño de todos los aliados y debilita la resistencia de los enemigos' }
    ],
    weapons: [
      'Gran Maza del Conquistador de Hierro Macizo con Cabeza de Rombo de 50kg',
      'Espadón Colosal de Asedio con Filo de Dos Metros',
      'Gran Hacha Doble de Verdugo de Reyes con Filos de Media Luna',
      'Lanza de Carga de Asedio con Estandarte Imperial Manchado de Sangre',
      'Escudo Torre Monumental de Hierro con Relieve de Calavera Coronada'
    ],
    relicsAndItems: [
      'Corona de Hierro Forjada con las Espadas de Cien Generales Vencidos',
      'Cuerno de Guerra Titánico que Resuena a Kilómetros de Distancia',
      'Estandarte de Guerra Manchado con la Sangre del Último Rey',
      'Traspaso de Conquista Sellado en Plomo con el Destino del Mundo'
    ],
    bags: [
      'Cofre de Oro y Hierro de Campaña para Botines de Guerra',
      'Funda Monumental Acolchada para Gran Maza del Conquistador',
      'Porta-Estandarte Dorsal Blindado',
      'Alforjas de Cuero de Mamut de Montura de Guerra'
    ],
    equipmentFinishes: [
      'Hierro negro martillado con textura rugosa y reflejos de acero',
      'Oro imperial pulido con pátina de sangre seca en las ranuras',
      'Cuero de bestia sin curtir con remaches de acero de cabeza hexagonal',
      'Esmalte rojo fuego vidriado en el blasón'
    ],
    suggestedColors: [
      { id: 'hierro_negro_warlord', name: 'Hierro Negro / Conquista', hex: '#18181B' },
      { id: 'rojo_sangre_conquistador', name: 'Rojo Sangre / Imperial', hex: '#7F1D1D' },
      { id: 'oro_botin_reyes', name: 'Oro Botín / Tiranía', hex: '#CA8A04' },
      { id: 'gris_acero_asedio', name: 'Acero de Asedio', hex: '#374151' }
    ],
    suggestedWardrobeDetails: ['Hombreras colosales sobredimensionadas con cráneos de reyes', 'Gran manto de terciopelo escarlata arrastrando por el suelo', 'Maza gigante de hierro apoyada en el suelo con desdén', 'Corona de púas de hierro imponiendo dominio indiscutible'],
    styleNote: 'Tiranía imperial monumental, armadura colosal sobredimensionada, terciopelo ensangrentado y terror marcial.'
  },

  'F8 Princesa / Príncipe': {
    roleName: 'F8 Princesa / Príncipe',
    category: 'Nobleza y Política',
    tagline: 'Linaje dinástico y heredero/a al trono, porte regio impecable, capa de terciopelo con ribetes de armiño, espada ceremonial de parada y corona principesca',
    description: 'Heredero/a directo/a de la corona. Porta ropajes nobiliarios de corte imperial, combinando elementos marciales de gala con la elegancia suprema de la alta realeza.',
    recommendedOutfitType: 'O-ROYAL-HEIR Traje de Gran Gala Nobiliaria con Manto Principesco, Diadema de Rubíes y Espada de Parada',
    outfitTypes: [
      { id: 'O-PRINCE-GALA', name: 'O-PRINCE-GALA Jubón de Brocado de Oro y Plata con Capa de Armiño Corta y Espada de Parada' },
      { id: 'O-PRINCESS-GALA', name: 'O-PRINCESS-GALA Vestido Imperial de Seda Nácar con Mirinaque, Tiara de Diamantes y Manto Real' },
      { id: 'O-ROYAL-RIDER', name: 'O-ROYAL-RIDER Traje de Monta Real con Casaca Escarlata, Botas de Charol y Guantes Blancos' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Coronas Principescas y Tiaras de Rubíes',
        pieces: [
          'P1.1 Corona Principesca de Oro Macizo con Rubí Central y Cuarzo Blanco',
          'P1.2 Tiara de Platino con Lágrimas de Diamantes y Esmeraldas',
          'P1.3 Diadema de Oro Filigranado con Sello de la Dinastía',
          'P1.4 Tocado de Seda Púrpura con Broche de Joyas de la Corona'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Jubones Reales y Vestidos de Seda Nácar',
        pieces: [
          'P2.1 Jubón de Gala Blanco y Oro con Bordados Imperiales y Tapeta con Carrera de Botones de Zafiro',
          'P2.2 Vestido de Gran Princesa de Seda Nácar con Escote Cuadrado y Pavé de Diamantes',
          'P2.3 Frac / Tailcoat Ceremonial de Terciopelo Escarlata con Botonadura Doble de Oro',
          'P2.4 Coraza Ceremonial de Oro Batido con Relieves del Blasón Dinástico'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Manto de Terciopelo con Ribetes de Armiño',
        pieces: [
          'P3.1 Manto Principesco de Terciopelo Carmesí Forrado en Armiño Blanco',
          'P3.2 Capa Corta de Hombro de Seda Azul Noche con Broche de León Imperial',
          'P3.3 Estola de Piel de Armiño Sujeta con Cordones de Hilo de Oro'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Mangas de Brocado y Guantes Blancos de Parada',
        pieces: [
          'P4.1 Mangas de Seda Brocada con Acuchillados que Revelan Encaje de Oro',
          'P4.2 Guantes de Cuero Blanco con Botones Dorados en la Muñeca',
          'P4.3 Brazaletes de Oro Grabados con el Lema del Reino'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinto de Espada de Parada con Hebilla de Oro',
        pieces: [
          'P5.1 Cinto Real de Cuero Blanco con Filigrana de Oro y Rubí Central',
          'P5.2 Fajín de Seda Azul con Borlas de Hilo de Oro',
          'P5.3 Tahalí de Espada de Parada con Gavilanes de Diamantes'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalón de Gala con Galón de Oro o Falda de Corte',
        pieces: [
          'P6.1 Pantalón de Gala Blanco con Galón Lateral de Hilo de Oro',
          'P6.2 Falda de Gran Corte con Mirinaque y Cenefa de Terciopelo Carmesí',
          'P6.3 Calzas de Paño Fino Púrpura con Botones de Zafiro'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Botas de Charol con Hebilla de Oro o Zapatos de Raso',
        pieces: [
          'P7.1 Botas de Montar de Charol Negro Lustrado con Espuelas de Oro',
          'P7.2 Zapatos de Raso Real con Puntas Redondeadas y Broches de Rubí',
          'P7.3 Botines de Terciopelo Escarlata con Carrera de Botones Dorados'
        ]
      }
    ],
    materials: ['Seda brocada de nácar y plata', 'Terciopelo carmesí dinástico', 'Piel de armiño blanco', 'Oro fino de 24 quilates', 'Rubíes de Ceilán y diamantes'],
    finishes: ['Lujo aristocrático regio', 'Bordados en canutillo de oro con relieve', 'Armiño blanco suave', 'Filigrana de oro pulido espejo'],
    armorDefenses: [
      { id: 'AR-PRINCE-GRACE', name: 'Gracia Principesca Inviolable', desc: 'Aura noble que infunde respeto y reduce la agresividad de oponentes' },
      { id: 'AR-ROYAL-GUARD-AURA', name: 'Escudo de la Guardia de la Corona', desc: 'Barrera de protección dorada que desvía ataques a distancia' }
    ],
    weapons: [
      'Espada de Parada Principesca con Pomo Enjoyado y Funda de Terciopelo',
      'Estoque de Duelo Real con Gavilanes de Filigrana de Oro',
      'Arco Ceremonial de Tejo con Incrustaciones de Nácar',
      'Daga de Gala con Vaina de Plata y Rubíes'
    ],
    relicsAndItems: [
      'Sello Anular de Heredero/a al Trono',
      'Colgante de la Orden del Fénix Imperial',
      'Estandarte Principesco de Seda Bordada en Oro'
    ],
    bags: [
      'Cofre Personal de Sellos y Joyas de Seda Acolchada',
      'Limosnera de Terciopelo Carmesí con Monedas de Oro Dinásticas'
    ],
    equipmentFinishes: [
      'Oro de 24 quilates pulido espejo con rubíes y diamantes',
      'Terciopelo carmesí y blanco nácar con bordados de hilo de oro',
      'Charol brillante y cuero de potro blanco'
    ],
    suggestedColors: [
      { id: 'blanco_nacar_principe', name: 'Blanco Nácar / Seda Imperial', hex: '#F8FAFC' },
      { id: 'rojo_carmesi_real', name: 'Carmesí Dinástico / Terciopelo', hex: '#8A1524' },
      { id: 'oro_principe', name: 'Oro Real / Filigrana', hex: '#E5C17D' },
      { id: 'azul_guardia_corona', name: 'Azul Zafiro de la Corona', hex: '#1E3A8A' }
    ],
    suggestedWardrobeDetails: ['Corona principesca de rubí resplandeciente', 'Capa de terciopelo carmesí con armiño', 'Espada de gala con funda de terciopelo', 'Bordados en canutillo de oro en jubón y solapas'],
    styleNote: 'Elegancia regia, linaje hereditario, distinción marcial de corte y suntuosidad aristocrática.'
  },

  'F9 Rey / Emperador': {
    roleName: 'F9 Rey / Emperador',
    category: 'Nobleza y Política',
    tagline: 'Majestad imperial y soberanía absoluta, gran manto de coronación de terciopelo púrpura y armiño, corona imperial de oro macizo y diamantes, cetro y orbe de oro',
    description: 'Soberano absoluto del imperio o reino. Viste los atuendos más fastuosos del continente: terciopelos de púrpura imperial, pieles de armiño blanco con motas negras, oro macizo de 24 quilates y las joyas legendarias de la corona.',
    recommendedOutfitType: 'O-MONARCH Atuendo Real de Coronación con Gran Manto de Armiño, Corona Imperial de Oro y Cetro',
    outfitTypes: [
      { id: 'O-EMPEROR-CORONATION', name: 'O-EMPEROR-CORONATION Gran Manto Imperial de Terciopelo Púrpura y Armiño con Corona y Cetro' },
      { id: 'O-EMPEROR-COURT', name: 'O-EMPEROR-COURT Traje de Gran Audiencia de Brocado de Oro con Gorguera y Espada de Estado' },
      { id: 'O-EMPRESS-GOWN', name: 'O-EMPRESS-GOWN Vestido de Gran Emperatriz con Mirinaque de Seda, Diamantes y Tiara Imperial' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Gran Corona Imperial y Cetros',
        pieces: [
          'P1.1 Corona Imperial de Oro Macizo con Flores de Lis, Diamantes, Rubíes y Gran Zafiro Central',
          'P1.2 Tiara Imperial de Platino con Lágrimas de Diamantes y Esmeraldas',
          'P1.3 Corona de Hojas de Laurel de Oro Macizo de Emperador César',
          'P1.4 Tocado Imperial de Seda Púrpura con Broche del Gran Águila de Diamantes'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Jubones Imperiales y Vestidos de Seda Real',
        pieces: [
          'P2.1 Jubón de Terciopelo Púrpura Imperial con Bordados en Hilo de Oro de Tres Cabos y Botones de Diamante',
          'P2.2 Vestido de Gran Coronación de Seda Nácar con Escote Cuadrado y Pavé de Diamantes',
          'P2.3 Gorguera Española de Encaje Francés Almidonada de Alta Realeza',
          'P2.4 Coraza Ceremonial de Oro Batido con Relieves de Ángeles y Batallas Imperiales'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Gran Manto de Coronación con Armiño',
        pieces: [
          'P3.1 Gran Manto de Coronación de Terciopelo Púrpura Forrado en Armiño Blanco con Motas Negras (Cola de 5 Metros)',
          'P3.2 Estola de Armiño Real Sujeta con Grandes Broches de Oro y Rubí',
          'P3.3 Capa Real de Terciopelo Azul con Sembrado de Flores de Lis de Oro'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Mangas Acuchilladas Reales y Guantes de Seda',
        pieces: [
          'P4.1 Mangas de Seda Brocada con Acuchillados que Revelan Encaje de Oro',
          'P4.2 Guantes de Coronación de Terciopelo Púrpura con Anillos Reales en los Dedos',
          'P4.3 Brazaletes de Diamantes y Oro Macizo de la Dinastía Imperial'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Gran Cinto de Coronación y Fajín Imperial',
        pieces: [
          'P5.1 Gran Cinturón de Coronación de Placas de Oro con Rubíes Cabujón',
          'P5.2 Fajín de Seda Azul con Cordones y Borlas de Hilo de Oro',
          'P5.3 Tahalí de Seda para Espada de Estado Real con Gavilanes de Diamantes'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Gran Falda de Corte Imperial o Calzas de Paño Fino',
        pieces: [
          'P6.1 Gran Falda de Corte Real con Mirinaque de Seda y Bordados de Pan de Oro',
          'P6.2 Calzas de Paño Fino de Seda Púrpura con Botones de Zafiro',
          'P6.3 Sobrefalda de Terciopelo con Cenefa de Armiño en el Dobladillo'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Zapatos de Coronación de Terciopelo y Oro',
        pieces: [
          'P7.1 Zapatos de Coronación de Terciopelo Púrpura Forrados con Hebillas de Diamantes',
          'P7.2 Zapatos de Tacón de Raso Real con Puntas Redondeadas y Broches de Rubí',
          'P7.3 Botines Reales de Cuero de Flandes con Botonadura de Platino'
        ]
      }
    ],
    materials: ['Púrpura imperial de Tiro', 'Terciopelo suntuoso de seda pura', 'Piel de armiño blanco con motas negras', 'Oro macizo de 24 quilates batido', 'Pavé de diamantes y rubíes imperiales'],
    finishes: ['Lujo imperial supremo', 'Bordados en canutillo de oro macizo', 'Piel de armiño inmaculada', 'Joyas pulidas fuego'],
    armorDefenses: [
      { id: 'AR-EMPEROR-SOVEREIGNTY', name: 'Soberanía Imperial Inviolable', desc: 'Presencia de mando absoluta que anula intimidaciones y hechizos mentales' },
      { id: 'AR-CROWN-AEGIS', name: 'Égida de la Gran Corona', desc: 'Domo de protección sagrada dorada ante daño mortal' }
    ],
    weapons: [
      'Cetro Imperial de Mando de Oro Macizo Rematado en Flor de Lis y Gran Diamante',
      'Espada de Estado y Coronación de Gavilanes de Oro y Pomo de Rubí',
      'Orbe Imperial del Mundo de Oro con Cruz de Esmeraldas y Zafiros',
      'Estilete de Oro con Mango de Marfil para Banquetes de Estado'
    ],
    relicsAndItems: [
      'Gran Corona Imperial de la Dinastía Sagrada',
      'Gran Sello de Estado del Imperio en Oro y Rubí',
      'Orbe del Mundo Símbolo del Dominio Universal',
      'Tomo Sagrado de Decretos y Leyes Imperiales'
    ],
    bags: [
      'Cofre de Madera de Ébano y Oro Macizo para las Joyas de la Corona',
      'Funda de Terciopelo Púrpura para el Cetro de Mando Imperial'
    ],
    equipmentFinishes: [
      'Oro de 24 quilates pulido espejo con pavé de diamantes',
      'Rubíes de color sangre de paloma engastados en biseles de oro',
      'Terciopelo púrpura imperial profundo con caída majestuosa',
      'Piel de armiño blanco con motas negras'
    ],
    suggestedColors: [
      { id: 'purpura_imperial_rey', name: 'Púrpura Imperial / Majestad', hex: '#581C87' },
      { id: 'oro_imperial_rey', name: 'Oro Imperial / Corona', hex: '#F59E0B' },
      { id: 'blanco_armino_rey', name: 'Blanco Armiño Real', hex: '#FFFFFF' },
      { id: 'rojo_rubi_rey', name: 'Rojo Rubí / Cetro', hex: '#BE123C' }
    ],
    suggestedWardrobeDetails: ['Gran Corona Imperial enjoyada con diamantes resplandecientes sobre la frente', 'Gran manto de coronación de terciopelo púrpura y armiño con cola de 5 metros', 'Cetro imperial de oro macizo en mano diestra y orbe de oro en la siniestra', 'Jubón de brocado de oro puro con botones de zafiro'],
    styleNote: 'Soberanía imperial absoluta, poder supremo indiscutible, pompa de coronación universal y joyas de la corona.'
  },

  'F8 Noble / Monarca': {
    roleName: 'F8 Noble / Monarca',
    category: 'Oscuro, Abisal y Tecnología',
    tagline: 'Majestad imperial y linaje supremo, túnica de terciopelo real y armiño, corona enjoyada de diamantes y rubíes, cetro de mando y orbe de oro',
    description: 'Soberano absoluto de reinos e imperios. Viste los ropajes más suntuosos y costosos posibles: terciopelos de púrpura imperial, pieles de armiño blanco con motas negras, oro macizo y joyas de la corona.',
    recommendedOutfitType: 'O-MONARCH Atuendo Real de Coronación con Manto de Armiño, Corona de Oro Enjoyada y Cetro',
    outfitTypes: [
      { id: 'O-MONARCH-CORONATION', name: 'O-MONARCH-CORONATION Gran Manto de Terciopelo Púrpura y Armiño con Corona Imperial y Cetro' },
      { id: 'O-MONARCH-COURT', name: 'O-MONARCH-COURT Traje de Corte de Brocado de Oro con Gorguera de Encaje y Espada de Paseo' },
      { id: 'O-MONARCH-QUEEN', name: 'O-MONARCH-QUEEN Vestido de Gran Reina con Mirinaque de Seda, Diamantes y Tiara de Rubíes' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Coronas Imperiales y Tiaras de Diamantes',
        pieces: [
          'P1.1 Corona Imperial de Oro Macizo con Flores de Lis, Diamantes, Rubíes y Gran Zafiro Central',
          'P1.2 Tiara de Platino con Lágrimas de Diamantes y Esmeraldas',
          'P1.3 Corona de Hojas de Laurel de Oro Macizo de Emperador',
          'P1.4 Tocado de Seda Púrpura con Broche de Joyas de la Dinastía'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Jubones de Brocado de Oro y Vestidos de Seda Real',
        pieces: [
          'P2.1 Jubón de Terciopelo Púrpura Imperial con Bordados en Hilo de Oro de Tres Cabos',
          'P2.2 Vestido de Coronación de Seda Nácar con Escote Cuadrado y Pavé de Diamantes',
          'P2.3 Gorguera Española de Encaje Francés Almidonada de Alta Realeza',
          'P2.4 Coraza Ceremonial de Oro Batido con Relieves de Ángeles y Reyes'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Gran Manto de Coronación con Armiño',
        pieces: [
          'P3.1 Gran Manto de Coronación de Terciopelo Púrpura Forrado en Armiño Blanco con Motas Negras (Cola de 5 Metros)',
          'P3.2 Estola de Armiño Real Sujeta con Grandes Broches de Oro y Rubí',
          'P3.3 Capa Real de Terciopelo Azul con Sembrado de Flores de Lis de Oro'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Mangas Acuchilladas Reales y Guantes de Seda',
        pieces: [
          'P4.1 Mangas de Seda Brocada con Acuchillados que Revelan Encaje de Oro',
          'P4.2 Guantes de Coronación de Terciopelo Púrpura con Anillos Reales en los Dedos',
          'P4.3 Brazaletes de Diamantes y Oro Macizo de la Dinastía'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cintos Reales de Oro y Fajines de Seda',
        pieces: [
          'P5.1 Gran Cinturón de Coronación de Placas de Oro con Rubíes Cabujón',
          'P5.2 Fajín de Seda Azul con Cordones y Borlas de Hilo de Oro',
          'P5.3 Tahalí de Seda para Espada de Paseo Real con Gavilanes de Diamantes'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Calzas de Seda y Faldas con Mirinaque',
        pieces: [
          'P6.1 Gran Falda de Corte Real con Mirinaque de Seda y Bordados de Pan de Oro',
          'P6.2 Calzas de Paño Fino de Seda Púrpura con Botones de Zafiro',
          'P6.3 Sobrefalda de Terciopelo con Cenefa de Armiño en el Dobladillo'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Zapatos de Coronación de Terciopelo y Oro',
        pieces: [
          'P7.1 Zapatos de Coronación de Terciopelo Púrpura Forrados con Hebillas de Diamantes',
          'P7.2 Zapatos de Tacón de Raso Real con Puntas Redondeadas y Broches de Rubí',
          'P7.3 Botines de Cuero Fino Blanco con Espuelas de Oro Real'
        ]
      }
    ],
    materials: ['Púrpura imperial de Tiro (Seda natural teñida)', 'Terciopelo de seda de Génova', 'Piel de armiño blanco con motas negras', 'Oro de 24 quilates batido y cincelado', 'Diamantes, rubíes birmanos y zafiros de Ceilán'],
    finishes: ['Lujo supremo imperial sin límites de riqueza', 'Bordados en canutillo de oro de relieve tridimensional', 'Armiño blanco suave inmaculado', 'Joyas pulidas con brillo de fuego'],
    armorDefenses: [
      { id: 'AR-ROYAL-MAJESTY', name: 'Majestad Suprema Inviolable', desc: 'Ningún súbdito o ser de menor linaje puede atacar directamente al monarca' },
      { id: 'AR-CROWN-SHIELD', name: 'Corona de Protección Dinástica', desc: 'Genera un domo de luz dorada que rechaza cualquier daño mortal' }
    ],
    weapons: [
      'Cetro Real de Mando de Oro Macizo Rematado en Flor de Lis y Gran Diamante',
      'Espada de Coronación de Gavilanes de Oro y Pomo de Rubí Grabada con el Lema Real',
      'Orbe Imperial del Mundo de Oro con Cruz de Esmeraldas y Zafiros',
      'Estilete de Oro con Mango de Marfil para Banquetes Reales',
      'Daga de Gala con Vaina de Filigrana de Oro y Perlas'
    ],
    relicsAndItems: [
      'Corona Imperial de la Dinastía Ancestral',
      'Sello Real del Reino con el Escudo Dinástico en Oro y Cera Roja',
      'Orbe del Mundo Símbolo del Dominio Absoluto',
      'Libro de Linajes y Decretos Reales Encuadernado en Terciopelo Púrpura'
    ],
    bags: [
      'Cofre de las Joyas de la Corona de Madera de Ébano y Oro Macizo',
      'Funda de Terciopelo Púrpura para el Cetro de Mando',
      'Limosnera Real de Brocado de Oro con Monedas de Oro de Donación',
      'Bolsa de Seda para la Corona Imperial'
    ],
    equipmentFinishes: [
      'Oro de 24 quilates pulido espejo con pavé de diamantes',
      'Rubíes de color sangre de paloma engastados en biseles de oro',
      'Terciopelo púrpura profundo con caída majestuosa',
      'Piel de armiño con suave pelaje blanco impoluto'
    ],
    suggestedColors: [
      { id: 'purpura_imperial_tiro', name: 'Púrpura Imperial / Real', hex: '#6B21A8' },
      { id: 'oro_real_24k', name: 'Oro Real / Corona', hex: '#F59E0B' },
      { id: 'blanco_armino', name: 'Blanco Armiño / Nácar', hex: '#FFFFFF' },
      { id: 'rojo_rubi_monarca', name: 'Rojo Rubí / Cetro', hex: '#BE123C' }
    ],
    suggestedWardrobeDetails: ['Corona imperial enjoyada con diamantes resplandecientes sobre la cabeza', 'Gran manto de terciopelo púrpura con forro de armiño arrastrando por la sala del trono', 'Cetro de oro en una mano y orbe imperial en la otra', 'Bordados en canutillo de hilo de oro puro cubriendo el jubón'],
    styleNote: 'Majestuosidad imperial suprema, pompa y suntuosidad de coronación, terciopelo púrpura, armiño y joyas de la corona.'
  },

  'Noble': {
    roleName: 'Noble',
    category: 'Nobleza y Política',
    tagline: 'Alta alcurnia y distinción aristocrática, tejidos de seda y terciopelo, sellos de linaje, capas con ribetes finos y aderezos de orfebrería',
    description: 'Representante de la aristocracia, casas nobiliarias y linajes de abolengo. Viste prendas de gran calidad textil —terciopelos, brocados, sedas y encajes finos— complementadas con sellos heráldicos, capas elegantes y armas de parada o duelo.',
    recommendedOutfitType: 'O4 Ceremonial / Nobleza (Terciopelo, brocados, sedas y orfebrería)',
    outfitTypes: [
      { id: 'O-NOBLE-COURT', name: 'O-NOBLE-COURT Traje de Corte con Jubón de Terciopelo, Capa Corta y Espada de Duelo' },
      { id: 'O-NOBLE-GALA', name: 'O-NOBLE-GALA Vestido de Gala Aristocrático con Corsé de Brocado y Falda de Seda' },
      { id: 'O-NOBLE-TRAVEL', name: 'O-NOBLE-TRAVEL Atuendo de Paseo y Viaje con Casaca Bordada, Botas de Montar y Sombrero de Pluma' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Tocados, Tiaras y Sombreros Nobiliarios',
        pieces: [
          'P1.1 Tiara de Filigrana de Oro con Gemas Finas',
          'P1.2 Sombrero de Terciopelo con Pluma de Pavo Real y Broche de Oro',
          'P1.3 Tocado de Seda con Redecilla de Perlas',
          'P1.4 Diadema Heráldica con Blasón Nobiliario',
          'P1.5 Monóculo de Oro con Cadena Fina de Eslabones'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Jubones, Blusas de Seda y Corpiños de Brocado',
        pieces: [
          'P2.1 Jubón de Terciopelo con Bordados de Hilo de Oro y Botones de Nácar',
          'P2.2 Vestido de Corte de Seda y Raso con Escote Cuadrado y Encajes de Venecia',
          'P2.3 Blusa de Seda con Chorrera de Encaje y Puños Fruncidos',
          'P2.4 Corpiño / Corsé Estructurado de Brocado con Ballenas y Cintas de Raso',
          'P2.5 Casaca Nobiliaria Entallada con Solapas de Damasco'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Capas Nobiliarias y Estolas',
        pieces: [
          'P3.1 Capa Corta de Terciopelo al Hombro con Broche de Blasón Familiar',
          'P3.2 Manto de Paseo Forrado en Seda con Ribete de Piel Fina',
          'P3.3 Estola de Armiño o Zorro Sujeta con Cadena Dorada',
          'P3.4 Capelina de Encaje Fino con Forro de Satén'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Mangas Acuchilladas y Guantes de Cabritilla',
        pieces: [
          'P4.1 Guantes de Cabritilla Fina Blancos con Botones de Perla',
          'P4.2 Mangas Acuchilladas de Brocado con Forro de Seda Visible',
          'P4.3 Manguitos de Terciopelo con Ribete de Encaje y Pulseras de Oro',
          'P4.4 Muñequeras de Seda con Cintas y Gemelos de Oro'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cintos Nobiliarios y Fajines de Raso',
        pieces: [
          'P5.1 Cinto Fino de Cuero Repujado con Hebilla de Oro y Engastes',
          'P5.2 Fajín de Raso de Seda Cruzado con Borlas Doradas',
          'P5.3 Tahalí Nobiliario para Estoque con Adornos de Plata',
          'P5.4 Cadena Leontina de Oro con Reloj de Bolsillo y Sello'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalones de Gala y Faldas con Vuelo',
        pieces: [
          'P6.1 Calzas de Paño Fino con Galón Lateral Dorado',
          'P6.2 Falda de Seda Plisada con Sobrefalda de Terciopelo y Enaguas',
          'P6.3 Pantalón Entallado de Monta de Lana Peinada de Alta Costura',
          'P6.4 Falda Evasé de Brocado con Motivos Florales Heráldicos'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Zapatos de Raso y Botas de Montar Lustradas',
        pieces: [
          'P7.1 Zapatos de Raso o Terciopelo con Hebillas de Oro y Pedrería',
          'P7.2 Botas de Montar de Cuero Lustrado con Espuelas de Plata',
          'P7.3 Botines Nobiliarios con Botonadura Lateral de Nácar',
          'P7.4 Zapatos de Salón con Tacón de Ébano y Lazo de Raso'
        ]
      }
    ],
    materials: ['Terciopelo de Génova', 'Seda natural brocada', 'Damasco y raso fino', 'Encaje de Venecia / Chantilly', 'Cuero suave de cabritilla', 'Oro y plata cincelados'],
    finishes: ['Satinado de alta costura', 'Bordados en canutillo de oro y plata', 'Pulido espejo de orfebrería', 'Textura aterciopelada impecable'],
    armorDefenses: [
      { id: 'Ninguna', name: 'Ninguna / Indumentaria Nobiliaria Pura', desc: 'Prendas de corte y etiqueta enfocadas en el prestigio visual y la distinción' },
      { id: 'AR-NOBLE-CHAIN', name: 'Cota de Malla Oculta de Mithril / Seda Reforzada', desc: 'Protección ligera de altísima calidad oculta bajo el jubón de corte' },
      { id: 'AR-NOBLE-DIGNITY', name: 'Aura de Dignidad Nobiliaria', desc: 'Presencia de alcurnia que infunde respeto y diplomacia en cualquier corte' }
    ],
    weapons: [
      'Estoque Nobiliario de Duelo con Taza de Filigrana de Oro',
      'Espadín de Corte con Empuñadura de Nácar y Oro',
      'Daga de Parada Enjoyada con Vaina de Terciopelo y Plata',
      'Bastón de Paseo de Ébano con Pomo de Oro y Gema Incrustada',
      'Pistola de Duelo de Chispa con Cañón Damasquinado y Culata de Nogal'
    ],
    relicsAndItems: [
      'Anillo Sello de Linaje Familiar con Blasón Grabado en Oro',
      'Reloj de Bolsillo de Oro Cincelado con Tapa de Esmalte',
      'Abanico de Varillas de Marfil y Seda Pintada a Mano',
      'Frasco de Esencias Perfumadas de Cristal Tallado y Plata',
      'Carta de Concesión Real y Árbol Genealógico Sellado'
    ],
    bags: [
      'Limosnera de Terciopelo Bordada con Hilo de Oro',
      'Neceser Nobiliario de Cuero Fino con Compartimentos Acolchados',
      'Portadocumentos Diplomático de Piel con Cierre de Oro',
      'Bolsita de Seda y Perlas para Monedas de Oro'
    ],
    equipmentFinishes: [
      'Oro fino de 18k pulido espejo con grabados heráldicos',
      'Plata cincelada a mano con pátina noble',
      'Madera de ébano y caoba con laca satinada',
      'Cuero fino teñido y encerado al alto brillo'
    ],
    suggestedColors: [
      { id: 'azul_real', name: 'Azul Real / Cobalto Nobiliario', hex: '#1E40AF' },
      { id: 'rojo_carmesi', name: 'Rojo Carmesí / Terciopelo', hex: '#991B1B' },
      { id: 'oro_heráldico', name: 'Dorado Heráldico / Oro', hex: '#D97706' },
      { id: 'purpura_noble', name: 'Púrpura / Amatista Nobiliaria', hex: '#7E22CE' },
      { id: 'verde_esmeralda_noble', name: 'Verde Esmeralda Oscuro', hex: '#065F46' },
      { id: 'marfil_seda', name: 'Blanco Marfil / Seda', hex: '#FFFBEB' }
    ],
    suggestedWardrobeDetails: [
      'Blasón bordado en hilo de oro sobre el pecho',
      'Capa corta terciada sujeta con broche heráldico',
      'Chorrera de encaje fino en el cuello',
      'Anillo de sello nobiliario en la mano diestra',
      'Estoque de duelo con taza dorada al cinto'
    ],
    styleNote: 'Distinción aristocrática, tejidos nobles de gran caída, contrastes entre terciopelo y seda, bordados heráldicos y accesorios de prestigio.'
  }
};
