import { RoleAttireConfig } from './types';

export const ORIENTAL_ROLES: Record<string, RoleAttireConfig> = {
  'G1 Samurái Imperial / Ronin': {
    roleName: 'G1 Samurái Imperial / Ronin',
    category: 'Fantasía Oriental',
    tagline: 'Honor del Bushido y acero plegado tamahagane, armadura O-Yoroi de placas lacadas, casco kabuto con cresta maedate, máscara mempo demoníaca, daisho (katana y wakizashi)',
    description: 'Guerrero de la casta samurái feudal o espadachín errante ronin. Viste armadura clásica O-Yoroi o Do-Maru de láminas de hierro lacado unidas por cordones de seda (odoshi), casco kabuto con imponentes cornamentas o medias lunas, y empuña el daisho sagrado.',
    recommendedOutfitType: 'O-SAMURAI Armadura Completa O-Yoroi de Placas Lacadas con Casco Kabuto, Máscara Mempo y Daisho',
    outfitTypes: [
      { id: 'O-SAMURAI-IMPERIAL', name: 'O-SAMURAI-IMPERIAL O-Yoroi Lacada en Rojo y Oro con Maedate de Dragón Imperial y Manto Jinbaori' },
      { id: 'O-SAMURAI-RONIN', name: 'O-SAMURAI-RONIN Kimono Desgastado con Hakama Oscura, Sombrero Kasa de Paja y Katana Enfundada' },
      { id: 'O-SAMURAI-SHOGUN', name: 'O-SAMURAI-SHOGUN Armadura Ceremonial de Shōgun de Laca Negra Brillante con Cordones de Seda Dorada' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Cascos Kabuto, Crestas Maedate y Máscaras Mempo',
        pieces: [
          'P1.1 Casco Kabuto con Placas de Hierro Remachadas y Gran Cresta Maedate de Media Luna Dorada',
          'P1.2 Máscara Facial Mempo de Hierro Forjado con Rictus de Demonio Oni y Bigote de Cerda',
          'P1.3 Sombrero Cónico de Paja Ronin (Jingasa o Sandogasa) Ocultando la Mirada',
          'P1.4 Cinta Hachimaki de Algodón Blanco Atada con Caracteres de Coraje'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Coraza Do de Placas Kozane y Chalecos Jinbaori',
        pieces: [
          'P2.1 Coraza Do de Láminas de Hierro Kozane Lacadas Unidas con Cordones de Seda Odoshi Carmesí',
          'P2.2 Chaleco Jinbaori de Terciopelo y Seda con Blasón Mon del Clan Bordado en la Espalda',
          'P2.3 Kimono Interior Shitagi de Seda Pura con Cuello Cruzado',
          'P2.4 Peto de Placa Única Nanban-Do de Influencia Occidental con Cruz de Oro'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Grandes Hombreras Sode y Estandarte Sashimono',
        pieces: [
          'P3.1 Grandes Hombreras Rectangulares O-Sode de Láminas Lacadas con Borlas de Seda',
          'P3.2 Estandarte Sashimono Sujeto a la Espalda con el Emblema Heráldico Mon ondeando al Viento',
          'P3.3 Capa Jinbaori Larga de Gala con Forro de Brocado Dorado'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Mangas Acorazadas Kote y Guanteletes Yugake',
        pieces: [
          'P4.1 Mangas Acorazadas Kote de Malla y Placas de Hierro sobre Tela de Seda Gruesa',
          'P4.2 Guantes Yugake de Piel de Ciervo Suave para Manejo Preciso de la Katana y el Arco',
          'P4.3 Brazaletes Tekko de Hierro Cubriendo el Dorso de las Manos'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinto Obi con Daisho (Katana & Wakizashi)',
        pieces: [
          'P5.1 Cinto Obi de Seda Ancha Gruesa Sosteniendo la Katana y el Wakizashi con el Filo Hacia Arriba',
          'P5.2 Cordones Sageo de Seda Trenzada Decorativos Sujetando las Vainas Saya',
          'P5.3 Faldón Kusazuri de Seis Secciones Lacadas Protegiendo Caderas e Ingle'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalones Hakama y Musleras Haidate',
        pieces: [
          'P6.1 Musleras Haidate de Placas Escamadas Lacadas con Forro de Seda Brocada',
          'P6.2 Pantalones Hakama de Seda Pesada con Pliegues Tradicionales',
          'P6.3 Calzones Kobakama Ajustados bajo la Armadura'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Grebas Suneate y Zapatos de Piel de Oso Tsuranuki',
        pieces: [
          'P7.1 Grebas Suneate de Láminas de Hierro Lacado Curvadas con Rodilleras Tateage',
          'P7.2 Zapatos de Piel de Oso de Montaña Tsuranuki Tradicionales de Alto Rango',
          'P7.3 Sandalias Waraji de Paja de Arroz con Calcetines Tabi de Algodón Azul Índigo'
        ]
      }
    ],
    materials: ['Acero Tamahagane forjado y plegado en mil capas', 'Laca Urushi natural roja y negra', 'Seda japonesa teñida con índigo y carmesí', 'Piel de raya Samegawa para empuñaduras', 'Madera de magnolia para vainas Saya'],
    finishes: ['Laca Urushi con brillo cristalino profundo', 'Cordones de seda Odoshi trenzados a mano', 'Acero con línea de temple Hamon ondulante visible', 'Relieves de oro en crestas Maedate'],
    armorDefenses: [
      { id: 'AR-BUSHIDO-HONOR', name: 'Espíritu Inquebrantable del Bushido', desc: 'Inmunidad al miedo y reducción masiva de daño en combates cara a cara uno contra uno' },
      { id: 'AR-DEFLECT-STRIKE', name: 'Desvío de Acero Tamahagane', desc: 'Permite parar y desviar proyectiles y tajos con un movimiento de la katana' }
    ],
    weapons: [
      'Daisho Tradicional: Katana (Espada Larga) y Wakizashi (Espada Corta) de Filo Hamon Perfecto',
      'Gran Arco Japonés Yumi Asimétrico de Bambú y Madera con Flechas Ya',
      'Lanza Naginata de Hoja Curva para Desmontar Jinetes y Cortes Circulares',
      'Lanza Yari de Tres Filos con Asta de Madera de Roble Reforzada con Anillas de Bronce',
      'Gran Maza de Guerra Tetsubo / Kanabo de Madera con Púas de Hierro'
    ],
    relicsAndItems: [
      'Tsuba (Guarda de Katana) Ancestral con Calados de Dragón y Flor de Cerezo en Oro',
      'Abanico de Guerra Tessen de Varillas de Hierro para Señales de Mando y Paradas',
      'Bolsa Kinchaku con Polvo de Pulido Uchiko y Papel de Arroz Nuguigami para Mantenimiento de la Katana',
      'Pergamino del Clan con el Código de Honor y Genealogía Imperial'
    ],
    bags: [
      'Funda de Seda de Damasco Acolchada para Katana y Daisho',
      'Carcaj Yebira Tradicional Lacado con 24 Flechas Emplumadas de Halcón',
      'Caja de Armadura Yoroi-Bitsu de Madera Laqueada con Asas de Cuerda',
      'Bolsa de Arroz y Raciones Kinchaku de Seda Índigo'
    ],
    equipmentFinishes: [
      'Laca Urushi negra brillante con bordes dorados maki-e',
      'Filo de katana con línea de temple Hamon de nubes ondulantes brillante',
      'Piel de raya Samegawa blanca bajo trenzado de seda negra Tsukaito',
      'Vainas Saya lacadas con motas de polvo de oro'
    ],
    suggestedColors: [
      { id: 'rojo_laca_urushi', name: 'Rojo Carmesí / Laca Urushi', hex: '#991B1B' },
      { id: 'negro_laca_shogun', name: 'Negro Laca / Noche', hex: '#09090B' },
      { id: 'oro_maedate', name: 'Oro Maedate / Cresta', hex: '#F59E0B' },
      { id: 'azul_indigo_samurai', name: 'Azul Índigo Tradicional', hex: '#1E3A8A' }
    ],
    suggestedWardrobeDetails: ['Casco Kabuto con gran cresta Maedate dorada de media luna', 'Máscara Mempo demoníaca cubriendo la mitad inferior de la cara', 'Daisho enfundado en el obi izquierdo con empuñaduras trenzadas visibles', 'Cordones de seda Odoshi de colores vivos enlazando cada placa de la coraza'],
    styleNote: 'Honor imperial del Bushido feudal, laca Urushi impecable, filo Hamon perfecto y presencia intimidante.'
  },

  'G2 Ninja Shinobi / Kunoichi': {
    roleName: 'G2 Ninja Shinobi / Kunoichi',
    category: 'Fantasía Oriental',
    tagline: 'Infiltración sigilosa en la sombra, traje Shinobi Shozoku negro y medianoche, máscara que oculta el rostro, ninjato recto a la espalda, shurikens y bombas de humo',
    description: 'Agente de infiltración, espionaje y asesinato silencioso. Viste el atuendo Shinobi Shozoku de lino oscuro reversible con capuchas, vendas silenciosas, ninjato de hoja recta y venenos letales.',
    recommendedOutfitType: 'O-NINJA Traje Completo Shinobi Shozoku Oscuro con Máscara, Ninjato a la Espalda y Shurikens',
    outfitTypes: [
      { id: 'O-NINJA-SHADOW', name: 'O-NINJA-SHADOW Traje Negro Azabache Ajustado con Capucha Fukumen, Ninjato y Shurikens' },
      { id: 'O-KUNOICHI-BLOSSOM', name: 'O-KUNOICHI-BLOSSOM Kimono Corto de Disfraz Carmesí con Mallas Interiores y Dagas Ocultas' },
      { id: 'O-NINJA-RECON', name: 'O-NINJA-RECON Atuendo de Camuflaje Forestal / Nieve con Garras de Escalada y Cerbatana' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Máscaras Fukumen y Capuchas Ninja',
        pieces: [
          'P1.1 Capucha Fukumen Envolvente que Oculta Todo el Rostro Excepto los Ojos Penetrantes',
          'P1.2 Máscara de Media Cara de Cuero Negro con Ranuras de Respiración Silenciosa',
          'P1.3 Cinta de Frente Negra con Placa de Acero Oculta de Protección',
          'P1.4 Máscara de Zorro Kitsune de Infiltración Nocturna'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Chaquetas Shinobi Shozoku y Mallas Kusari',
        pieces: [
          'P2.1 Chaqueta Shinobi Shozoku Cruzada con Bolsillos Secretos Interiores para Venenos',
          'P2.2 Camiseta Interior de Cota de Malla Fina Kusari que Detiene Dagas sin Hacer Ruido',
          'P2.3 Chaleco de Cuero Ajustado con Arnés para Ninjato Dorsal',
          'P2.4 Kimono Corto de Kunoichi con Aperturas Rápidas para Ataque'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Arnés para Ninjato y Capas de Sombra',
        pieces: [
          'P3.1 Arnés Dorsal para Ninjato con Empuñadura Asomando sobre el Hombro Izquierdo',
          'P3.2 Capa Corta de Seda Negra Reversible (Negro Noche / Blanco Nieve)',
          'P3.3 Soporte de Espalda para Gancho de Escalada Kaginawa con Cuerda'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Manguitos Acorazados y Garras Tekko-Kagi',
        pieces: [
          'P4.1 Manguitos de Tela Negra Ajustada con Garras Ocultas de Escalada Tekko-Kagi',
          'P4.2 Brazales de Cuero con Compartimentos para Agujas Venenosas Senbon',
          'P4.3 Vendas de Algodón Negro Apretadas en Muñecas y Palmas'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Fajas con Bolsas de Shurikens y Bombas',
        pieces: [
          'P5.1 Faja Ancha de Seda Oscura con Compartimentos para 12 Shurikens de Estrella y Bombas Metsubushi',
          'P5.2 Tahalí para Kunai de Lanzamiento y Daga Tanto',
          'P5.3 Frascos Ocultos de Veneno Letal de Pez Globo y Parálisis'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalones Igabakama Ajustados',
        pieces: [
          'P6.1 Pantalones Igabakama Holgados Arriba y Estrechos en Pantorrillas para Agilidad Absoluta',
          'P6.2 Polainas de Tela Negra Atadas con Cintas Cruzadas Silenciosas',
          'P6.3 Musleras con Fundas para Cuchillos Arrojadizos'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Calzado Tabi Dividido y Garras Ashiko',
        pieces: [
          'P7.1 Botas Ninja Jikatabi con Dedo Pulgar Separado y Suela de Goma Suave Amortiguada',
          'P7.2 Garras de Escalada de Hierro Ashiko Acopladas a la Suela de los Pies',
          'P7.3 Calcetines Tabi de Algodón Negro para Caminar por Tejados sin Crujidos'
        ]
      }
    ],
    materials: ['Lino y algodón negro azabache teñido con ceniza', 'Seda cruda ligera y silenciosa', 'Acero oscurecido no reflectante', 'Cuero flexible tratado', 'Cuerdas de cáñamo negro para escalada'],
    finishes: ['Acero mate oscurecido sin ningún brillo metálico', 'Tejido mate que absorbe la luz ambiental', 'Suelas de goma silenciosa absoluta', 'Venenos cristalinos en viales herméticos'],
    armorDefenses: [
      { id: 'AR-SHADOW-VEIL', name: 'Velo de Sombras / Mimetismo de Noche', desc: 'Invisibilidad casi total en penumbra y ventaja crítica en ataques sorpresa' },
      { id: 'AR-KAWARIMI', name: 'Técnica de Reemplazo del Cuerpo (Kawarimi)', desc: 'Esquiva un ataque mortal dejando un tronco de madera o un muñeco en su lugar' }
    ],
    weapons: [
      'Ninjato de Hoja Recta Oscurecida con Vaina Saya Hueca Utilizable como Cerbatana y Respirador Acuático',
      'Juego de 8 Shurikens de Estrella de 4 Puntas y Shurikens Bo de Aguja',
      'Par de Kunai de Hierro con Anilla Posterior para Lanzamiento y Escalada',
      'Hoz con Cadena y Peso de Hierro (Kusarigama) para Desarmar y Enredar',
      'Cerbatana Disimulada Fukiya con Agujas Imbuidas en Veneno Paralizante'
    ],
    relicsAndItems: [
      'Bombas de Humo Negro y Polvo Cegador de Cáscara de Huevo Metsubushi',
      'Gancho de Cuatro Puntas de Hierro Kaginawa con Cuerda de Seda Resistente de 15m',
      'Frasco de Veneno Incoloro e Inodoro de Loto de Medianoche',
      'Monóculo de Visión Nocturna Arcano de Lente Ahumada'
    ],
    bags: [
      'Mochila Plana de Infiltración Dorsal Ajustada al Cuerpo',
      'Bolsas Secretas Cosidas en el Forro Interior del Traje',
      'Funda de Cuero para Juego de Kunais de Lanzamiento',
      'Estuche Rígido Acolchado para Bombas de Humo Frágiles'
    ],
    equipmentFinishes: [
      'Acero pavonado negro mate para evitar reflejos bajo la luna',
      'Madera laqueada en negro mate con textura antideslizante',
      'Cordones de seda de alta densidad sin remates sueltos',
      'Cuchillas con acanaladuras para albergar veneno concentrado'
    ],
    suggestedColors: [
      { id: 'negro_shinobi', name: 'Negro Medianoche / Sombra', hex: '#0B0F19' },
      { id: 'gris_carbon_ninja', name: 'Gris Ceniza / Carbón', hex: '#334155' },
      { id: 'rojo_kunoichi', name: 'Rojo Carmesí / Pétalo', hex: '#991B1B' },
      { id: 'azul_marino_noche', name: 'Azul Noche Profunda', hex: '#0F172A' }
    ],
    suggestedWardrobeDetails: ['Máscara Fukumen cubriendo todo el rostro dejando sólo los ojos al descubierto', 'Ninjato recto cruzado en la espalda con empuñadura mate', 'Bolsillo en la faja repleto de shurikens de estrella', 'Botas Jikatabi con dedo separado pisando en silencio absoluto'],
    styleNote: 'Sigilo mortal implacable, traje negro mate antireflectante, armas disimuladas y letalidad invisible.'
  },

  'G3 Cultivador Inmortal (Xianxia)': {
    roleName: 'G3 Cultivador Inmortal (Xianxia)',
    category: 'Fantasía Oriental',
    tagline: 'Trascendencia del Dao y energía Qi celestial, túnica flotante de seda de nubes Hanfu, corona de jade Guan, espada voladora de Qi y aura inmortal de loto',
    description: 'Practicante de artes inmortales y cultivo del Dao. Viste túnicas Hanfu flotantes de seda blanca, celeste o esmeralda, coronas de jade Guan, anillos de almacenamiento espacial y controla espadas voladoras con la mente.',
    recommendedOutfitType: 'O-XIANXIA Hanfu Flotante de Seda Blanca y Jade con Corona Guan y Espada Voladora de Qi',
    outfitTypes: [
      { id: 'O-XIANXIA-CELESTIAL', name: 'O-XIANXIA-CELESTIAL Hanfu de Seda Blanca Translúcida con Bordados de Nubes de Oro y Espada de Jade' },
      { id: 'O-XIANXIA-SWORD', name: 'O-XIANXIA-SWORD Túnica de Maestro de la Secta de la Espada con Mangas Anchas y Diez Espadas de Luz' },
      { id: 'O-XIANXIA-DEMONIC', name: 'O-XIANXIA-DEMONIC Cultivador Demoníaco con Ropajes Negros y Rojos, Qi Carmesí y Flauta de Hueso' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Coronas de Jade Guan y Horquillas Inmortales',
        pieces: [
          'P1.1 Corona de Jade Blanco Guan con Horquilla Zan de Plata Sujetando el Moño de Pelo Largo',
          'P1.2 Horquilla de Jade Esmeralda Tallada en Forma de Fénix o Dragón',
          'P1.3 Marca de Frente del Ojo Celestial / Loto Dorado que Brilla con el Qi',
          'P1.4 Cinta de Pelo Flotante de Seda Blanca con Caracteres del Dao'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Túnicas Hanfu de Seda de Nubes Flotantes',
        pieces: [
          'P2.1 Túnica Hanfu Cruzada de Seda de Nubes Inmaculada con Bordados de Grullas y Montañas Sagradas',
          'P2.2 Chaqueta Exterior Translúcida Flotante de Gasa de Hielo que Ondula sin Viento',
          'P2.3 Colgante de Jade Magatama / Bi de Jade Sagrado sobre el Pecho',
          'P2.4 Chaleco Cruzado con Bordado del Diagrama de los Ocho Trigramas (Bagua)'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Cintas Flotantes Celestiales y Espadas Voladoras',
        pieces: [
          'P3.1 Cintas de Seda Celestial (Pibo) Flotando en Arcos Alrededor del Cuerpo por Energía Qi',
          'P3.2 Espada de Qi Inmortal Flotando Levita Detrás de la Espalda',
          'P3.3 Manto de Seda de Luna Llena que Refleja la Luz Astral'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Mangas Gigantes Flotantes y Anillo Espacial',
        pieces: [
          'P4.1 Mangas Gigantes de Seda Hanfu de Dos Metros de Caída (Sleeve of the Universe)',
          'P4.2 Anillo de Jade de Almacenamiento Espacial Interdimensional en el Dedo Pulgar',
          'P4.3 Brazaletes de Jade Blanco que Suprimen el Demonio Interno'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinto de Jade y Colgantes Pei',
        pieces: [
          'P5.1 Cinto Ancho de Seda con Placas de Jade Blanco Tallado y Borlas de Hilo de Oro Colgantes',
          'P5.2 Colgante de Jade Pei que Suena con Tono Musical Puro al Caminar',
          'P5.3 Calabaza de Almacenamiento de Píldoras de Inmortalidad y Licor Espiritual'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Faldas de Capas Plisadas Hanfu',
        pieces: [
          'P6.1 Falda Hanfu Plisada de Múltiples Capas de Seda Ondulando como Olas de Nieve',
          'P6.2 Calzas de Seda Blanca Suave con Forro de Loto',
          'P6.3 Faldón Trasero con Bordados de Constelaciones Celestiales'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Zapatos de Tela de Nube con Puntera Elevada',
        pieces: [
          'P7.1 Zapatos de Seda Blanca con Bordados de Nubes y Puntera Curvada hacia Arriba',
          'P7.2 Botines de Seda y Brocado de Oro con Suela que No Toca el Polvo del Suelo',
          'P7.3 Pies Pisando Pétalos de Loto de Energía Qi de Luz Dorada'
        ]
      }
    ],
    materials: ['Seda de nubes inmortales de gusanos celestiales', 'Jade blanco de Hetian y jade esmeralda imperial', 'Mithril espiritual y cristal de Qi', 'Oro celestial de nueve cielos', 'Madera de sándalo milenario'],
    finishes: ['Luminiscencia celestial etérea suave', 'Seda translúcida ondeando ingrávida', 'Jade perfectamente pulido con brillo acuoso', 'Aura de loto de Qi dorado'],
    armorDefenses: [
      { id: 'AR-QI-SHIELD', name: 'Domo de Protección de Qi Inmortal', desc: 'Un campo de energía espiritual rechaza ataques físicos y mágicos elementales' },
      { id: 'AR-TRANSCENDENCE', name: 'Trascendencia del Dominio del Dao', desc: 'Permite volar, levitar y no recibir daño de caídas ni enfermedades mortales' }
    ],
    weapons: [
      'Espada Inmortal de Jade y Acero Celestial que Vuela y Responde a los Comandos Mentales',
      'Flauta de Bambú Espiritual / Hueso de Dragón que Canaliza Ondas Sonoras Destructivas de Qi',
      'Matamoscas Ceremonial de Taoísta (Fuchen) de Crin de Caballo Blanco para Disipar Hechizos',
      'Conjunto de Siete Espadas Voladoras que Forman una Formación de Espada Bagua',
      'Guqin (Cítara China) de Siete Cuerdas de Seda que Dispara Cuchillas de Sonido'
    ],
    relicsAndItems: [
      'Calabaza de Jade con Píldoras de Avance de Nivel de Cultivo de Nueve Revoluciones',
      'Espejo de los Ocho Trigramas Bagua que Revela la Verdadera Forma de los Demonios',
      'Anillo Espacial de Jade con Capacidad de Almacenar Montañas de Tesoros',
      'Pergamino del Manual de Cultivo del Dao Primordial con Caracteres de Fuego Dorado'
    ],
    bags: [
      'Bolsa Espacial Qunkun de Seda que Desafía las Dimensiones Físicas',
      'Funda de Terciopelo Blanco y Cintas de Jade para el Guqin',
      'Calabaza de Licor Espiritual Atada al Cinto con Cordón de Oro',
      'Cofrecito de Sándalo Sagrado para Píldoras Medicinales de Longevidad'
    ],
    equipmentFinishes: [
      'Jade blanco translúcido con brillo de rocío celestial',
      'Bordados de hilo de oro y plata de artesanos inmortales',
      'Filo de espada de cristal celestial con resplandor de Qi azul cian',
      'Seda de nubes de textura ultraligera que parece flotar sin gravedad'
    ],
    suggestedColors: [
      { id: 'blanco_nube_celestial', name: 'Blanco Nube / Inmortal', hex: '#F8FAFC' },
      { id: 'azul_cian_qi', name: 'Azul Cian / Energía Qi', hex: '#06B6D4' },
      { id: 'verde_jade_imperial', name: 'Verde Jade Hetian', hex: '#10B981' },
      { id: 'oro_celestial_dao', name: 'Oro Celestial / Dao', hex: '#F59E0B' }
    ],
    suggestedWardrobeDetails: ['Túnica Hanfu blanca con mangas gigantes ondeando ingrávidas', 'Corona de jade Guan sujetando el peinado con elegancia celestial', 'Espada de Qi translúcida flotando en el aire junto al hombro', 'Aura sutil de pétalos de loto de luz emanando de su paso'],
    styleNote: 'Trascendencia etérea Xianxia taoísta, cultivo inmortal, sedas flotantes ingrávidas y control mental de espadas.'
  },

  'G4 Guerrero Wuxia / Espadachín Errante': {
    roleName: 'G4 Guerrero Wuxia / Espadachín Errante',
    category: 'Fantasía Oriental',
    tagline: 'Justicia en el Jianghu y ligereza Qinggong, túnica Hanfu de viajero, sombrero Douli de bambú con velo negro, espada Jian fina, calabaza de vino y pasos sobre el agua',
    description: 'Héroe errante de los ríos y lagos (Jianghu). Domina el arte del movimiento ligero (Qinggong) para correr sobre ramas y agua. Viste ropa práctica de paño y cuero, sombrero Douli con velo y espada recta Jian.',
    recommendedOutfitType: 'O-WUXIA Atuendo de Espadachín Errante con Sombrero Douli de Velo, Túnica Hanfu y Espada Jian',
    outfitTypes: [
      { id: 'O-WUXIA-WANDERER', name: 'O-WUXIA-WANDERER Túnica de Paño Gris y Azul con Sombrero Douli de Velo Negro y Calabaza de Vino' },
      { id: 'O-WUXIA-NOBLE-HERO', name: 'O-WUXIA-NOBLE-HERO Traje de Seda Blanca con Espada Jian de Plata y Abanico Metálico' },
      { id: 'O-WUXIA-SHADOW-BLADE', name: 'O-WUXIA-SHADOW-BLADE Jubón de Cuero Negro Ajustado con Dagas Arrojadizas y Capa Corta' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Sombreros Douli con Velo y Cintas de Héroe',
        pieces: [
          'P1.1 Sombrero Cónico de Bambú Douli con Velo de Gasa Negra que Cubre el Rostro',
          'P1.2 Cinta de Frente de Seda con Nudo de Cola de Golondrina al Viento',
          'P1.3 Máscara de Bambú Tallado de Héroe Anónimo Justiciero',
          'P1.4 Mechón de Pelo Rebelde sobre la Mirada Decidida y Seria'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Túnicas Hanfu Cruzadas y Chalecos de Viaje',
        pieces: [
          'P2.1 Túnica Cruzada Hanfu de Algodón y Lino Resistente para Viajes por el Jianghu',
          'P2.2 Chaleco de Cuero Fino Ajustado con Costuras Reforzadas',
          'P2.3 Camisa de Cuello Cruzado con Forro Acolchado contra Tajos',
          'P2.4 Manto Terciado al Hombro al Estilo del Espadachín Bohemio'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Capas de Viajero y Espada Jian Cruzada',
        pieces: [
          'P3.1 Capa de Viaje Corta de Paño Oscuro Resistente al Viento y la Lluvia',
          'P3.2 Soporte de Espalda de Cuero para la Espada Recta Jian',
          'P3.3 Manto de Paja contra Tormentas de Río'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Brazaletes de Cuero y Vendas de Espadachín',
        pieces: [
          'P4.1 Brazaletes de Cuero Repujado con Cintas de Amarre Apretadas en Muñecas',
          'P4.2 Vendas de Algodón Oscuro en Antebrazos para Sujetar las Mangas Anchas al Luchar',
          'P4.3 Guantes Finos de Piel para Agarre Óptimo de la Empuñadura'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinto de Cuero con Calabaza de Licor',
        pieces: [
          'P5.1 Cinto Ancho de Cuero con Hebilla de Bronce y Calabaza de Vino de Arroz Colgando',
          'P5.2 Tahalí para Espada Jian con Borla Roja de Seda en el Pomo',
          'P5.3 Faja de Tela con Bolsillos para Monedas de Cobre y Fichas de Posada'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalones de Vuelo Controlado y Polainas',
        pieces: [
          'P6.1 Pantalones de Algodón Holgados con Gran Libertad para Acrobacias Qinggong',
          'P6.2 Polainas de Cuero Fino Atadas con Cordones desde el Tobillo a la Rodilla',
          'P6.3 Faldón Lateral Dividido para Desplazamientos Rápidos'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Botas de Tela de Suela Flexible de Qinggong',
        pieces: [
          'P7.1 Botas de Tela Negra de Suela de Mil Capas Ultraligera para Correr sobre Hojas de Bambú',
          'P7.2 Botines de Cuero Suave de Viajero del Jianghu con Puntera Redondeada',
          'P7.3 Sandalias de Paja con Vendas de Algodón para Caminatas de Días'
        ]
      }
    ],
    materials: ['Algodón y lino de alta resistencia', 'Cuero fino flexible de viaje', 'Bambú tejido a mano para sombrero Douli', 'Acero de damasco para espada Jian', 'Seda roja para borlas decorativas'],
    finishes: ['Pátina de viaje por caminos de tierra y bosques de bambú', 'Acero de espada pulido con reflejos de agua pura', 'Cuero marrón gastado por el uso', 'Bambú dorado natural'],
    armorDefenses: [
      { id: 'AR-QINGGONG-AGILITY', name: 'Agilidad de Qinggong / Ligereza del Viento', desc: 'Permite esquivar ataques moviéndose sobre el aire, ramas o techos' },
      { id: 'AR-JIANGHU-JUSTICE', name: 'Determinación Heroica del Jianghu', desc: 'Aumenta el daño crítico al defender a inocentes y personas desvalidas' }
    ],
    weapons: [
      'Espada Recta Jian de Doble Filo con Borla de Seda Roja Flotante en el Pomo',
      'Sable Dao Curvo de Hoja Ancha para Cortes Potentes de Guardia',
      'Abanico Metálico de Varillas de Acero Afilado con Filos Ocultos',
      'Dardos Arrojadizos Voladores (Feibiao) con Cintas de Seda Roja de Vuelo',
      'Vara de Bambú Verde de Maestro de Acrobacias'
    ],
    relicsAndItems: [
      'Calabaza de Vino de Arroz Tradicional que Otorga Energía y Valor',
      'Ficha de Jade de la Hermandad Justiciera del Jianghu',
      'Manual de Estilo de Espada de las Nueve Sombras en Bambú Atado',
      'Frasco de Bálsamo Curativo de Hierbas de los Acantilados'
    ],
    bags: [
      'Morral de Tela de Viajero Cruzado al Pecho con Mudas de Ropa y Dinero',
      'Funda de Madera y Cuero con Broches de Bronce para la Espada Jian',
      'Bolsa de Cuero para Agujas y Dardos Voladores',
      'Cantimplora de Bambú con Cierre de Madera'
    ],
    equipmentFinishes: [
      'Espada Jian con filo pulido a espejo y guarda en forma de cabeza de dragón',
      'Borla de seda roja carmesí brillante en el pomo de la espada',
      'Bambú tejido con barniz natural repelente de agua en el sombrero Douli',
      'Cuero marrón oliva curtido de forma tradicional'
    ],
    suggestedColors: [
      { id: 'azul_marino_wuxia', name: 'Azul Marino / Viajero', hex: '#1E3A8A' },
      { id: 'gris_niebla_jianghu', name: 'Gris Niebla / Jianghu', hex: '#64748B' },
      { id: 'rojo_borla_espada', name: 'Rojo Carmesí / Borla', hex: '#DC2626' },
      { id: 'marron_bambu_douli', name: 'Marrón Bambú / Douli', hex: '#78350F' }
    ],
    suggestedWardrobeDetails: ['Sombrero Douli de bambú con velo de gasa negra ocultando la mirada', 'Espada recta Jian sostenida casualmente con una mano y borla roja ondeando', 'Calabaza de vino de arroz colgada de la cintura', 'Paso ligero y equilibrado que apenas roza el suelo'],
    styleNote: 'Caballerosidad errante del Jianghu, agilidad Qinggong, elegancia marcial de la espada Jian y sombrero con velo misterioso.'
  },

  'G5 Onmyoji / Maestro del Yin-Yang': {
    roleName: 'G5 Onmyoji / Maestro del Yin-Yang',
    category: 'Fantasía Oriental',
    tagline: 'Adivinación cosmológica y espíritus Shikigami, túnica Sokutai de la corte Heian, sombrero Eboshi alto, abanico ceremonial Oguruma y talismanes de papel con sellos de pentagrama Seiman',
    description: 'Maestro del misticismo esotérico Yin-Yang (Onmyodo) y la corte imperial. Viste túnicas amplias de seda de la era Heian (Kariginu o Sokutai), sombrero Eboshi alto, abanico de señales y convoca espíritus Shikigami mediante talismanes de papel.',
    recommendedOutfitType: 'O-ONMYOJI Kariginu de Seda Blanca y Púrpura de la Corte Heian con Sombrero Eboshi y Talismanes Shikigami',
    outfitTypes: [
      { id: 'O-ONMYOJI-COURT', name: 'O-ONMYOJI-COURT Kariginu de Seda Blanca con Cordones Púrpuras, Sombrero Eboshi y Abanico' },
      { id: 'O-ONMYOJI-EXORCIST', name: 'O-ONMYOJI-EXORCIST Túnica Negra y Carmesí con Sellos de Pentagrama Seiman y Espejo Bagua' },
      { id: 'O-ONMYOJI-SUMMONER', name: 'O-ONMYOJI-SUMMONER Ropajes Rituales con Muñecos de Papel Shikigami Flotantes y Fuego Espiritual' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Sombreros Tate-Eboshi y Marcas Rituales',
        pieces: [
          'P1.1 Sombrero Tate-Eboshi Alto de Seda Negra Laqueada Rígida de la Corte Imperial',
          'P1.2 Tocado Kanmuri de Alto Ministro de los Asuntos Espirituales',
          'P1.3 Puntos Rituales de Cinabrio Rojo en la Frente y Comisura de los Ojos',
          'P1.4 Máscara de Media Cara de Zorro Plateado de Convocación'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Túnicas Kariginu de la Corte Heian',
        pieces: [
          'P2.1 Túnica Kariginu de Seda Blanca con Mangas Abiertas y Cordones Kukuri-Himo Púrpuras',
          'P2.2 Kimono Interior Hitoe de Seda Verde o Nácar con Cuello Escalonado',
          'P2.3 Gran Emblema del Pentagrama Seiman de Abe no Seimei Bordado en Oro en el Pecho',
          'P2.4 Chaqueta Ceremonial Suikan con Botones de Nudo de Seda'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Cintas Ceremoniales y Espíritus Flotantes',
        pieces: [
          'P3.1 Cintas de Seda Púrpura y Oro Flotando en la Espalda con Nudos Rituales',
          'P3.2 Dos Espíritus Shikigami de Papel Blanco con Forma Humanoide Flotando sobre los Hombros',
          'P3.3 Capa Corta de Brocado de Noche Estrellada con Constelaciones Bordadas'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Mangas Gigantes Kariginu con Cordones',
        pieces: [
          'P4.1 Mangas Colosales de Kariginu con Cordones Trenzados para Recogerlas en Combate',
          'P4.2 Pulseras de Cuentas de Cristal de Adivinación y Jade en las Muñecas',
          'P4.3 Manos Pálidas Sosteniendo Muñecos de Papel Shikigami entre los Dedos'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Sashinuki y Fajas de Brocado',
        pieces: [
          'P5.1 Faja Ancha de Brocado Dorado con Soporte para Abanico Plegable y Talismanes',
          'P5.2 Cintas Rojas y Blancas Ceremoniales Mizuhiki Atadas al Cinto',
          'P5.3 Bolsa Kinchaku de Seda con Tinta de Cinabrio y Pinceles Finos'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalones Plisados Sashinuki Abullonados',
        pieces: [
          'P6.1 Pantalones Sashinuki de Seda Púrpura Abullonados y Atados en los Tobillos con Cordones',
          'P6.2 Falda Plisada Hakama de Corte Noble Heian con Gran Caída',
          'P6.3 Calzas Blancas Tabi de Seda Suave'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Zapatos Asagutsu Laqueados de Madera',
        pieces: [
          'P7.1 Zapatos Asagutsu de Madera de Paulownia Laqueados en Negro Brillante',
          'P7.2 Sandalias de Seda con Puntera Curvada Ceremonial',
          'P7.3 Calcetines Tabi Blancos Impolutos'
        ]
      }
    ],
    materials: ['Seda pura japonesa Heian (Nishijin-ori)', 'Papel Washi sagrado con fibras de mora', 'Tinta de cinabrio rojo sagrado', 'Madera de paulownia y laca urushi', 'Hilos de oro y plata batida'],
    finishes: ['Seda con caída imperial majestuosa', 'Papel Shikigami crujiente que brilla con fuego azul espiritual', 'Laca negra profunda brillante', 'Tinta roja fresca en sellos'],
    armorDefenses: [
      { id: 'AR-SHIKIGAMI-BARRIER', name: 'Barrera de Shikigami Guardián', desc: 'Espíritus de papel interceptan ataques físicos y mágicos absorbiendo el impacto' },
      { id: 'AR-YIN-YANG-BALANCE', name: 'Equilibrio Cósmico del Yin-Yang', desc: 'Convierte el daño recibido de un elemento en sanación de su elemento opuesto' }
    ],
    weapons: [
      'Abanico Ceremonial de Señales (Ogi / Gunsen) de Seda Pintada y Varillas de Bambú o Hierro',
      'Mazo de Talismanes de Papel Washi con Sellos de Pentagrama que se Convierten en Bestias Espirituales',
      'Vara de Exorcismo con Anillas de Bronce y Cintas de Papel Sagrado',
      'Daga Ceremonial Tanto con Vaina de Laca Púrpura y Guarda de Flor de Ciruelo',
      'Pincel de Caligrafía Mágica que Dibuja Hechizos en el Aire con Fuego Sagrado'
    ],
    relicsAndItems: [
      'Muñecos de Papel Shikigami Autónomos que Espían y Transmiten Mensajes',
      'Astrolabio / Brújula de Feng Shui Luopan de Madera de Ébano y Aguja de Oro',
      'Espejo de Bronce Exorcista que Quema Demonios con Rayos de Luz Solar',
      'Tintero de Piedra de Jade con Tinta de Cinabrio Sagrado Molido'
    ],
    bags: [
      'Caja de Madera Laqueada de Tres Pisos (Jubako) para Talismanes y Sellos',
      'Funda de Seda Púrpura Acolchada para el Abanico Ceremonial',
      'Bolsa Kinchaku de Seda Dorada para el Pincel Mágico y Piedra de Tinta',
      'Estuche Rígido para el Sombrero Eboshi'
    ],
    equipmentFinishes: [
      'Seda de Nishijin con patrones florales y de mariposas en oro',
      'Papel Washi con marcas de agua de dragones y caracteres kanji',
      'Madera de laca negra con incrustaciones de nácar Raden',
      'Abanico con dibujo del sol rojo y la luna plateada'
    ],
    suggestedColors: [
      { id: 'purpura_heian', name: 'Púrpura Imperial Heian', hex: '#6B21A8' },
      { id: 'blanco_seda_kariginu', name: 'Blanco Seda / Puro', hex: '#FFFFFF' },
      { id: 'rojo_cinabrio_onmyoji', name: 'Rojo Cinabrio / Sello', hex: '#DC2626' },
      { id: 'azul_espiritual_fuego', name: 'Azul Fuego Espiritual', hex: '#38BDF8' }
    ],
    suggestedWardrobeDetails: ['Kariginu de seda blanca con amplias mangas y cordones púrpuras', 'Sombrero Tate-Eboshi alto de seda negra laqueada en la cabeza', 'Talismanes de papel flotando a su alrededor imbuidos en fuego azul', 'Abanico ceremonial plegable sostenido frente al pecho'],
    styleNote: 'Misticismo esotérico de la corte Heian, adivinación Yin-Yang, espíritus Shikigami de papel y elegancia aristocrática.'
  }
};
