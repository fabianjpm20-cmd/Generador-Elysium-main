import { RoleAttireConfig } from './types';

export const ARCANE_ROLES: Record<string, RoleAttireConfig> = {
  'C1 Hechicero Clásico': {
    roleName: 'C1 Hechicero Clásico',
    category: 'Arcano y Magia',
    tagline: 'Tradición mágica pura, túnica rúnica con bordados celestiales, sombrero cónico puntiagudo, orbe de foco y báculo',
    description: 'Arquetipo clásico del mago y hechicero. Viste túnicas amplias de seda y paño con bordados astronómicos, cinturón con saquillos de componentes y báculo rematado en cristal.',
    recommendedOutfitType: 'O-MAGE Túnica Arcana Clásica con Bordados Celestiales y Capucha Puntiaguda',
    outfitTypes: [
      { id: 'O-MAGE-CLASSIC', name: 'O-MAGE-CLASSIC Túnica Larga de Seda y Terciopelo con Runas Luminiscentes' },
      { id: 'O-MAGE-ASTRAL', name: 'O-MAGE-ASTRAL Manto Celestial con Estampado de Nebulosas y Constelaciones' },
      { id: 'O-MAGE-TRAVEL', name: 'O-MAGE-TRAVEL Túnica de Viaje con Capucha Amplia y Bolsas de Componentes' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Sombreros Cónicos y Tiaras Celestiales',
        pieces: [
          'P1.1 Sombrero Cónico Puntiagudo de Hechicero con Ala Ancha y Bordado de Fases Lunares',
          'P1.2 Tiara de Plata de Sabio con Cristal de Cuarzo en el Tercer Ojo',
          'P1.3 Capucha Amplia con Forro de Seda Estrellada',
          'P1.4 Velo de Sombras Etéreas sobre el Rostro'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Túnicas Rúnicas y Cuellos de Solapa',
        pieces: [
          'P2.1 Túnica Arcana de Seda Pesada con Dobladillo de Símbolos Mágicos',
          'P2.2 Jubón Interior de Terciopelo Azul Noche con Botones de Zafiro',
          'P2.3 Pechera de Cuero Suave con Sello de Conjuración Central',
          'P2.4 Manto Cruzado con Broche de Cristal de Maná Luminoso'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Capas Celestiales y Estolas',
        pieces: [
          'P3.1 Gran Capa de Terciopelo Azul Profundo con Constelaciones de Hilo Plateado',
          'P3.2 Estola de Hechicero con Runas de los Cuatro Elementos',
          'P3.3 Capelina Corta con Cuello Alzado Rígido'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Mangas Acampanadas y Anillos de Poder',
        pieces: [
          'P4.1 Mangas Gigantes Acampanadas con Caída hasta la Rodilla y Forro Estrellado',
          'P4.2 Manguitos de Seda con Runas de Canalización que Brillan al Conjurar',
          'P4.3 Anillos Arcanos de Oro Blanco con Gemas Elementales en Cada Dedo'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cintos con Bolsitas de Componentes',
        pieces: [
          'P5.1 Cinturón de Cuero Repujado con Frascos de Cristal y Saquillos de Polvos Mágicos',
          'P5.2 Cordón de Seda Trenzada con Borlas de Oro y Símbolo del Infinito',
          'P5.3 Faja de Terciopelo con Soporte para Varita y Pergaminos'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Ropajes Interiores Cómodos',
        pieces: [
          'P6.1 Túnica Interior hasta los Tobillos con Pliegues Suaves',
          'P6.2 Pantalones de Lino Suave de Movilidad Mágica',
          'P6.3 Falda-Túnica Dividida para Facilitar el Paso'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Zapatos de Tela de Hechicero',
        pieces: [
          'P7.1 Zapatos de Terciopelo con Puntera Curvada y Bordados Mágicos',
          'P7.2 Botines de Cuero Suave con Hebillas de Luna Creciente',
          'P7.3 Zapatillas de Paño Silenciosas con Suela de Goma'
        ]
      }
    ],
    materials: ['Seda de morera pesada', 'Terciopelo azul noche', 'Hilo de plata pura para bordados', 'Cuarzo y gemas arcanas', 'Cuero flexible para complementos'],
    finishes: ['Luminiscencia mágica tenue', 'Bordados celestiales de alta precisión', 'Satinado aterciopelado', 'Brillo cristalino facetado'],
    armorDefenses: [
      { id: 'AR-MAGE-ARMOR', name: 'Armadura de Mago (Conjuro de Fuerza)', desc: 'Escudo invisible de energía pura que desvía ataques físicos sin penalizar peso' },
      { id: 'AR-ARCANE-WARD', name: 'Guarda Arcana de Resonancia Elemental', desc: 'Absorbe daño de fuego, hielo y rayos convirtiéndolo en maná' }
    ],
    weapons: [
      'Báculo de Madera Milenaria Rematado en Gran Cristal de Zafiro Flotante',
      'Varita de Madera de Ébano con Núcleo de Pelo de Unicornio',
      'Orbe de Foco de Cristal de Cuarzo con Galaxia Interior Giratoria',
      'Daga Ritual de Plata de Siete Puntas para Trazar Círculos',
      'Tomo de Conjuros con Páginas de Fuego Arcano'
    ],
    relicsAndItems: [
      'Grimorio de Hechizos Mayores Encuadernado en Piel de Quimera con Candado Rúnico',
      'Reloj de Arena Astral que Mide el Flujo de Maná en el Entorno',
      'Amuleto de Concentración con Ojo de Gato Místico',
      'Frasco de Éter Purificado / Poción de Maná Concentrada'
    ],
    bags: [
      'Bolsa de Contención Espacial Inagotable de Terciopelo Azul',
      'Tubo Portapergaminos de Plata Cincelada con Sellos Protectores',
      'Morral de Cinturón para Componentes Raros de Conjuro',
      'Funda Acolchada de Seda para Báculo Desmontable'
    ],
    equipmentFinishes: [
      'Cristal de zafiro facetado con halo de luz azul interior',
      'Madera de ébano pulida con vetas plateadas naturales',
      'Plata envejecida con grabados de constelaciones y runas',
      'Cuero azul noche con gofrado en pan de plata'
    ],
    suggestedColors: [
      { id: 'azul_noche_arcano', name: 'Azul Noche / Zafiro', hex: '#1E3A8A' },
      { id: 'purpura_mistico', name: 'Púrpura Místico / Maná', hex: '#7C3AED' },
      { id: 'plata_lunar', name: 'Plata Lunar / Estrellas', hex: '#E2E8F0' },
      { id: 'oro_celeste', name: 'Dorado Solar / Foco', hex: '#F59E0B' }
    ],
    suggestedWardrobeDetails: ['Runas que se iluminan al gesticular con las manos', 'Bordes de túnica con fases lunares bordadas en plata', 'Gran cristal de foco levitando en el extremo del báculo', 'Mangas amplias que ondean con energía arcana'],
    styleNote: 'Magia clásica majestuosa, astronomía celeste, túnicas ricas en terciopelo y báculos arcanos luminosos.'
  },

  'C2 Elementalista': {
    roleName: 'C2 Elementalista',
    category: 'Arcano y Magia',
    tagline: 'Maestría de fuego, hielo, rayo y tierra, ropajes bicromáticos en llamas y escarcha, orbes flotantes y báculo elemental',
    description: 'Canalizador de las fuerzas primordiales de la naturaleza. Sus ropas reflejan su elemento afín (fuego llameante, escarcha cristalina, tormenta eléctrica o roca viva).',
    recommendedOutfitType: 'O-ELEMENTAL Túnica Primordial con Degradado de Fuego / Hielo y Orbes Flotantes',
    outfitTypes: [
      { id: 'O-ELEMENTAL-FIRE', name: 'O-ELEMENTAL-FIRE Manto de Llamas con Bordes de Ceniza y Oro Carmesí' },
      { id: 'O-ELEMENTAL-ICE', name: 'O-ELEMENTAL-ICE Túnica de Escarcha con Cristales Glaciares y Seda Celeste' },
      { id: 'O-ELEMENTAL-STORM', name: 'O-ELEMENTAL-STORM Atuendo de Tormenta con Seda Violeta y Descargas Eléctricas' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Coronas Elementales y Diademas',
        pieces: [
          'P1.1 Corona de Llamas Danzantes de Oro y Rubí / Corona de Cristales de Hielo',
          'P1.2 Diadema de Cobre con Cristales de Rayo Chisporroteantes',
          'P1.3 Máscara de Piedra y Obsidiana Elemental',
          'P1.4 Tocado de Plumas de Fénix Ardientes'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Túnicas con Degradado Elemental',
        pieces: [
          'P2.1 Túnica de Seda con Degradado de Carmesí a Amarillo Fuego / Blanco a Azul Glaciar',
          'P2.2 Peto de Cristal Elemental Resonante sobre el Pecho',
          'P2.3 Jubón de Cuero de Salamandra Resistente a Temperaturas Extremas',
          'P2.4 Corpiño Asimétrico con Hombro Elementalmente Transformado'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Mantos de Energía Elemental',
        pieces: [
          'P3.1 Manto Ondulante con Terminación en Puntas de Fuego o Estalactitas de Hielo',
          'P3.2 Alas de Energía Elemental Pura (Llamas, Viento o Rayos)',
          'P3.3 Capa Corta con Salpicaduras de Escarcha Brillante'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Brazaletes de Canalización',
        pieces: [
          'P4.1 Brazaletes de Cobre y Oro con Runas de Ignición y Congelación',
          'P4.2 Guanteletes de Cuero con Gemas Elementales en los Nudillos',
          'P4.3 Manguitos de Seda con Chispas o Copos de Nieve Flotantes'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cintos con Viales Elementales',
        pieces: [
          'P5.1 Cinturón de Cuero con Viales de Lava Líquida y Agua Bendita',
          'P5.2 Fajín de Seda con Degradado de Elementos y Cuentas de Ámbar',
          'P5.3 Tahalí para Báculo o Varas Elementales Cortas'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Faldas de Movilidad Elemental',
        pieces: [
          'P6.1 Falda de Seda Plisada con Dobladillo de Ceniza o Cristales de Escarcha',
          'P6.2 Bombachos de Lino Fresco con Bordados de Tormenta',
          'P6.3 Calzas de Cuero Térmico con Grabados de Llamas'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Botines con Huella Elemental',
        pieces: [
          'P7.1 Botines de Cuero Térmico que Dejan Huellas de Ceniza o Escarcha al Pisar',
          'P7.2 Sandalias Mágicas con Tiras de Cuero y Gemas Elementales',
          'P7.3 Botas Altas de Cuero de Dragón con Hebillas de Oro'
        ]
      }
    ],
    materials: ['Seda tratada ignífuga / criogénica', 'Cuero de salamandra volcánica', 'Cristales elementales facetados', 'Cobre y oro conductores', 'Obsidiana volcánica'],
    finishes: ['Degradado cromático térmico', 'Brillo cristalino helado', 'Chispas eléctricas estáticas', 'Bordes incandescentes'],
    armorDefenses: [
      { id: 'AR-ELEMENTAL-BARRIER', name: 'Barrera Elemental Reactiva', desc: 'Quema o congela a los atacantes cuando impactan un golpe cuerpo a cuerpo' },
      { id: 'AR-PRIMAL-SHIELD', name: 'Escudo de Tierra y Rocas Flotantes', desc: 'Piedras mágicas que orbitan al hechicero interceptando proyectiles' }
    ],
    weapons: [
      'Báculo de los Cuatro Elementos con Cuatro Gemas Orbitando en la Cúspide',
      'Orbes Elementales Triples Flotando en Torno a las Manos',
      'Vara de Fuego de Madera de Fresno Quemada con Núcleo de Magma',
      'Espada de Hielo Puro Forjada de un Glaciar Ancestral',
      'Lanza de Rayo de Cobre con Descargas de Plasma Continuas'
    ],
    relicsAndItems: [
      'Corazón de Fénix en Frasco de Cristal Blindado',
      'Fragmento de Glaciar Eterno que Nunca se Derrite',
      'Piedra de Rayo / Fulgurita Encantada con Carga Eléctrica',
      'Amuleto de Equilibrio Elemental de Jade y Ágata de Fuego'
    ],
    bags: [
      'Bolsa Térmica de Cuero de Salamandra para Guardar Cristales Calientes',
      'Morral Criogénico Aislante con Cierre de Plata',
      'Estuche Rígido de Madera y Cuero para Varas Elementales',
      'Carcaj para Proyectiles de Energía Pura'
    ],
    equipmentFinishes: [
      'Cristal con refracción térmica (rojo cálido o azul polar)',
      'Oro bruñido al fuego con pátina de hollín elegante',
      'Obsidiana negra con reflejos vítreos afilados',
      'Cobre brillante con descargas eléctricas violáceas'
    ],
    suggestedColors: [
      { id: 'rojo_fuego', name: 'Rojo Fuego / Llama', hex: '#DC2626' },
      { id: 'azul_glaciar', name: 'Azul Glaciar / Hielo', hex: '#38BDF8' },
      { id: 'dorado_electricidad', name: 'Amarillo Rayo / Tormenta', hex: '#FACC15' },
      { id: 'naranja_magma', name: 'Naranja Magma / Ceniza', hex: '#EA580C' }
    ],
    suggestedWardrobeDetails: ['Degradado de color simulando fuego ascendente o hielo cristalizado', 'Orbes mágicos de colores flotando libremente sobre las manos', 'Bordes de la tela con chispas de luz tenue', 'Bordados de olas, llamas y rayos'],
    styleNote: 'Poder primordial elemental, colores saturados en degradado térmico, gemas orbitantes y energía viva.'
  },

  'C3 Nigromante': {
    roleName: 'C3 Nigromante',
    category: 'Arcano y Magia',
    tagline: 'Magia de ultratumba, túnica de seda negra y huesos, guadaña de almas, calaveras rúnicas y resplandor verde espectral',
    description: 'Señor de la muerte y los espíritus. Viste ropajes oscuros decorados con osamentas, cadenas de almas, símbolos de niebla espectral y empuña guadañas o cetros nigrománticos.',
    recommendedOutfitType: 'O-NECRO Túnica Nigromántica Negra con Hombreras de Cráneo y Resplandor Verde Espectral',
    outfitTypes: [
      { id: 'O-NECRO-ROBE', name: 'O-NECRO-ROBE Túnica de Seda Negra con Bordados de Almas y Cadenas de Hueso' },
      { id: 'O-NECRO-LICH', name: 'O-NECRO-LICH Vestiduras de Lich Ancestral con Filigrana de Plata Oscura y Corona' },
      { id: 'O-NECRO-REAPER', name: 'O-NECRO-REAPER Atuendo de Parca con Gran Capucha de Sombras y Guadaña Gigante' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Capuchas de Sombras y Tiaras de Hueso',
        pieces: [
          'P1.1 Capucha Profunda de Seda Negra que Deja el Rostro en Sombras Totales',
          'P1.2 Tiara / Corona de Huesos Tallados con Calavera de Cuervo Central',
          'P1.3 Máscara Funeraria de Plata Ennegrecida con Ojos Verdes Resplandecientes',
          'P1.4 Velo de Sombras Funerarias de Gasa Negra'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Túnicas de Terciopelo Negro y Pecheras de Costillas',
        pieces: [
          'P2.1 Túnica de Terciopelo Negro con Forro Verde Espectral y Bordados de Almas',
          'P2.2 Pechera de Costillas de Hueso Talladas Protegiendo el Pecho',
          'P2.3 Corsé de Cuero Negro con Cadenas de Plata Oscura y Relicario Funerario',
          'P2.4 Manto Cruzado con Broche de Ojo de Calavera Iluminado'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Hombreras de Cráneos y Capas Rasgadas',
        pieces: [
          'P3.1 Hombreras de Cráneos Humanos o de Monstruos con Llamas Espectrales Verdes',
          'P3.2 Capa Larga de Seda Negra Rasgada en la Base con Niebla Flotante',
          'P3.3 Manto de Plumas de Cuervo Funerario'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Guanteletes Esqueléticos y Mangas de Sombras',
        pieces: [
          'P4.1 Guanteletes de Garras Metálicas Esqueléticas de Plata Oscura',
          'P4.2 Mangas Acampanadas Negras con Dobladillo de Símbolos Funerarios',
          'P4.3 Brazaletes de Vértebras Entrelazadas con Alambre de Cobre'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturones con Frascos de Almas',
        pieces: [
          'P5.1 Cinturón de Cuero Negro con Calaveras en Miniatura y Frascos de Almas Verdes',
          'P5.2 Cadena de Huesos de Dedos Entrelazados con Relicario',
          'P5.3 Tahalí para Libro de los Muertos y Daga Sacrificial'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Faldas de Caída Espectral y Calzas',
        pieces: [
          'P6.1 Falda de Seda Negra Larga con Abertura Frontal y Bordado de Runas de Muerte',
          'P6.2 Calzas Negras de Paño Fino con Bordados de Huesos',
          'P6.3 Sobrefalda Rasgada que Flota como Niebla de Cripta'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Botines Funerarios y Zapatos Silenciosos',
        pieces: [
          'P7.1 Botines de Cuero Negro con Punteras Metálicas de Calavera',
          'P7.2 Zapatos de Terciopelo Negro con Suela Silenciosa para Criptas',
          'P7.3 Botas Altas con Hebillas de Hueso y Cordones Negros'
        ]
      }
    ],
    materials: ['Terciopelo negro profundo devoré', 'Seda de araña espectral', 'Huesos pulidos y marfil fosilizado', 'Plata ennegrecida al sulfuro', 'Cuero negro curtido'],
    finishes: ['Resplandor verde espectral / azul fantasmagórico', 'Hueso pulido envejecido', 'Mate absorbente de luz', 'Rasgado etéreo en dobladillos'],
    armorDefenses: [
      { id: 'AR-BONE-ARMOR', name: 'Armadura de Huesos y Almas Errantes', desc: 'Espíritus protectores absorben el daño físico y debilitan a los agresores' },
      { id: 'AR-DEATH-SHROUD', name: 'Velo de la Muerte Inmortal', desc: 'Inmunidad a venenos, enfermedades y resistencia masiva a magia necrótica' }
    ],
    weapons: [
      'Guadaña de Almas con Hoja de Acero Espectral Negro y Filo Verde Luminoso',
      'Cetro Nigromántico con Calavera que Emite Niebla Espectral Verde',
      'Daga Sacrificial Ondulada de Obsidiana con Mango de Hueso',
      'Vara de Ébano con Jaula de Almas de Plata Oscura en la Cúspide',
      'Grimorio de Nigromancia Flotante Encuadernado en Piel Humana'
    ],
    relicsAndItems: [
      'Filacteria de Lich / Joya de Resurrección con Alma Cautiva',
      'Candelabro con Vela Negra de Grasa de Ahorcado',
      'Frasco de Cristal con Fuego Fatuo de Niebla Espectral',
      'Calavera Parlante de su Antiguo Maestro Nigromante'
    ],
    bags: [
      'Bolsa Funeraria de Terciopelo para Huesos y Polvo de Tumba',
      'Morral de Cuero Negro con Cierre de Garra Esquelética',
      'Cofre de Plata Oscura Hermético para Cenizas Sagradas',
      'Funda Acolchada de Seda Negra para la Guadaña'
    ],
    equipmentFinishes: [
      'Acero negro mate con filo imbuido en resplandor verde tóxico',
      'Huesos amarilleados pulidos a mano con runas negras inscritas',
      'Plata oxidada al sulfuro con pátina de cripta',
      'Cristal verde esmeralda con vapor de almas cautivo'
    ],
    suggestedColors: [
      { id: 'negro_abismo', name: 'Negro Abismo / Carbón', hex: '#09090B' },
      { id: 'verde_espectral', name: 'Verde Espectral / Fuego Fatuo', hex: '#10B981' },
      { id: 'purpura_nigromante', name: 'Púrpura Tumba / Muerte', hex: '#581C87' },
      { id: 'blanco_calavera', name: 'Blanco Calavera / Marfil', hex: '#E2E8F0' }
    ],
    suggestedWardrobeDetails: ['Resplandor verde brillante saliendo de los ojos de los cráneos', 'Cadenas de huesos de dedos colgando de la cintura', 'Bordes de la capa rasgados y deshilachados con humo tenue', 'Bordados en hilo de plata oscura con sellos nigrománticos'],
    styleNote: 'Gótico funerario, resplandor verde espectral de fuego fatuo, osamentas esculpidas y majestad de ultratumba.'
  },

  'C4 Mago de Batalla': {
    roleName: 'C4 Mago de Batalla',
    category: 'Arcano y Magia',
    tagline: 'Fusión bélica y arcana, coraza de placas grabada con runas, capa corta militar, espada imbuida en maná y báculo táctico',
    description: 'Erudito marcial entrenado en primera línea de combate. Combina placas de acero o mithril grabadas con runas defensivas, espada mágica y báculo táctico.',
    recommendedOutfitType: 'O-WARMAGE Armadura de Placas Rúnicas de Acero y Túnica Militar Reforzada',
    outfitTypes: [
      { id: 'O-WARMAGE-HEAVY', name: 'O-WARMAGE-HEAVY Coraza Completa de Placas de Mithril con Sellos de Ignición y Espada' },
      { id: 'O-WARMAGE-SKIRMISH', name: 'O-WARMAGE-SKIRMISH Brigantina Reforzada con Hombreras Mágicas y Capa Táctica' },
      { id: 'O-WARMAGE-OFFICER', name: 'O-WARMAGE-OFFICER Traje Militar de Oficial Arcano con Charreteras y Espada Mágica' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Yelmos Rúnicos y Diademas de Batalla',
        pieces: [
          'P1.1 Yelmo Abierto de Acero con Runas Grabadas en la Frente y Visera Táctica',
          'P1.2 Diadema Blindada de Mithril con Foco de Telepatía Militar',
          'P1.3 Capucha Táctica Blindada de Malla de Mithril y Paño Azul',
          'P1.4 Máscara de Respiración Arcana contra Gas Mágico'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Peto de Acero Rúnico y Túnica de Campaña',
        pieces: [
          'P2.1 Peto de Acero y Mithril Grabado con Runas de Absorción Cinética',
          'P2.2 Brigantina de Cuero y Placas con Núcleo de Maná Frontal',
          'P2.3 Casaca Militar Azul con Galones Dorados y Cota de Malla Interior',
          'P2.4 Gambesón Blindado con Costuras de Hilo de Plata Conductor'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Hombreras de Artillería y Capas Militares',
        pieces: [
          'P3.1 Hombreras de Placas Asimétricas con Runas de Disparo de Proyectiles Mágicos',
          'P3.2 Capa Corta Militar Azul Real con Forro Ignífugo',
          'P3.3 Capote de Oficial de Batalla con Charreteras Doradas'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Guanteletes de Canalización y Brazales',
        pieces: [
          'P4.1 Guanteletes de Acero con Gemas de Maná en el Dorso de la Mano para Disparar Hechizos',
          'P4.2 Brazales Rúnicos de Mithril con Conductores de Energía',
          'P4.3 Guantes de Cuero Balístico con Refuerzo para Empuñar Espadas'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturón Táctico con Cartucheras Arcanas',
        pieces: [
          'P5.1 Cinturón Militar con Cartucheras de Pergaminos de Lanzamiento Rápido',
          'P5.2 Tahalí Doble para Espada Mágica y Báculo Táctico Plegable',
          'P5.3 Fauld de Placas de Acero Protegiendo Caderas y Muslos'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Grebas de Combate y Pantalón Militar',
        pieces: [
          'P6.1 Grebas de Acero y Mithril con Rodilleras Articuladas',
          'P6.2 Pantalón Militar de Paño Resistente con Refuerzos de Cuero',
          'P6.3 Escarcelas Cortas de Placas con Runas de Velocidad'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Botas de Combate Blindadas',
        pieces: [
          'P7.1 Botas de Cuero Grueso con Puntera y Empeine de Acero Templado',
          'P7.2 Escarpines de Mithril Ligeros con Amortiguación de Impactos',
          'P7.3 Botas de Marcha Militar con Suela Antideslizante'
        ]
      }
    ],
    materials: ['Mithril ligero y acero templado', 'Paño militar de alta resistencia', 'Cuero balístico reforzado', 'Gemas de foco arcano militar', 'Hilo de plata conductor'],
    finishes: ['Acero azulado pavonado con runas grabadas', 'Pulido militar estricto', 'Bordes con galones dorados', 'Luminiscencia táctica en gemas'],
    armorDefenses: [
      { id: 'AR-WARMAGE-PLATE', name: 'Armadura de Placas Rúnicas de Mithril', desc: 'Protección militar híbrida de alto nivel contra ataques físicos y mágicos' },
      { id: 'AR-KINETIC-BARRIER', name: 'Generador de Barrera Cinética Arcana', desc: 'Desvía proyectiles balísticos y metralla de explosiones' }
    ],
    weapons: [
      'Espada de Hoja Ancha Imbuida en Relámpagos con Runas en la Canaladura',
      'Báculo Táctico de Acero y Mithril Rematado en Cuchilla de Lanza y Foco Mágico',
      'Escudo Redondo de Mithril con Proyector de Campo de Fuerza Mágico',
      'Pistola Arcana de Repetición con Tambor de Cristales de Fuego',
      'Daga de Asalto con Filo de Plasma Azul'
    ],
    relicsAndItems: [
      'Brújula Militar Táctica de Detección de Concentraciones de Maná',
      'Mapas Topográficos de Campaña con Posiciones Mágicas Marcadas',
      'Frasco de Éter de Combate de Recarga Instantánea',
      'Insignia de Oficial de la Legión de Magos de Batalla'
    ],
    bags: [
      'Cartuchera Militar de Cuero para Rollos de Hechizos Tácticos',
      'Mochila de Campaña Ignífuga con Compartimento para Baterías de Maná',
      'Funda Rígida de Espada con Forro Conductor de Energía',
      'Portabáculos Táctico Bandolera de Cuero Reforzado'
    ],
    equipmentFinishes: [
      'Acero pavonado en azul oscuro militar con grabados en pan de oro',
      'Hoja de espada con runas azul celeste que emiten zumbido eléctrico',
      'Cuero negro engrasado con remaches de acero pulido',
      'Cristales de maná cilíndricos pulidos a máquina'
    ],
    suggestedColors: [
      { id: 'azul_militar', name: 'Azul Militar / Real', hex: '#1E40AF' },
      { id: 'acero_mithril', name: 'Mithril Plateado / Acero', hex: '#CBD5E1' },
      { id: 'dorado_galon', name: 'Dorado Galón / Rango', hex: '#EAB308' },
      { id: 'negro_tactico', name: 'Negro Táctico / Cuero', hex: '#0F172A' }
    ],
    suggestedWardrobeDetails: ['Placas de acero pulcro con runas brillantes inscritas', 'Charreteras doradas de rango militar en los hombros', 'Espada mágica con filo envuelto en corriente eléctrica', 'Capa militar corta con el emblema de la legión arcana'],
    styleNote: 'Disciplina militar, armadura híbrida de acero y mithril, pragmatismo táctico y poder ofensivo devastador.'
  },

  'C5 Alquimista': {
    roleName: 'C5 Alquimista',
    category: 'Arcano y Magia',
    tagline: 'Transmutación y química, abrigo de cuero ignífugo con viales múltiples, máscara de pico o respirador y mortero de cobre',
    description: 'Científico místico de matraces, ácidos y elixires. Viste gabardina de cuero grueso resistente a quemaduras, bandoleras llenas de tubos de ensayo y gafas de protección.',
    recommendedOutfitType: 'O-ALCHEMIST Gabardina de Cuero Químico con Bandoleras de Viales y Máscara de Gas',
    outfitTypes: [
      { id: 'O-ALCHEMIST-COAT', name: 'O-ALCHEMIST-COAT Gabardina Larga de Cuero Encerado con Portaviales Múltiples' },
      { id: 'O-ALCHEMIST-PLAGUE', name: 'O-ALCHEMIST-PLAGUE Médico de la Peste Alquímico con Máscara de Pico y Sombrero' },
      { id: 'O-ALCHEMIST-TRANSMUTE', name: 'O-ALCHEMIST-TRANSMUTE Atuendo de Maestro de la Piedra Filosofal con Seda y Oro' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Máscaras de Pico y Gafas de Laboratorio',
        pieces: [
          'P1.1 Máscara de Pico de Cuero (Médico de la Peste) con Filtro de Hierbas Aromáticas',
          'P1.2 Gafas de Protección con Lentes de Cristal Grueso Tinte Ámbar y Lupa Articulada',
          'P1.3 Sombrero de Cuero de Ala Ancha con Banda de Probetas',
          'P1.4 Máscara de Respiración Alquímica con Filtro de Carbón y Válvula de Bronce'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Gabardinas Ignífugas y Mandiles Químicos',
        pieces: [
          'P2.1 Gabardina Larga de Cuero Tratado contra Ácidos con Cuello Alto Abotonado',
          'P2.2 Mandil de Cuero Pesado con Múltiples Fundas Elásticas para Tubos de Ensayo',
          'P2.3 Chaleco de Alquimista con Portaviales en Diagonal Cruzando el Pecho',
          'P2.4 Camisa de Lona Gruesa con Manchas de Reactivos Químicos'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Alambiques Portátiles y Capas Cortas',
        pieces: [
          'P3.1 Arnés Dorsal con Alambique de Cobre Portátil y Tubos de Serpentín',
          'P3.2 Capa Corta Ignífuga de Cuero con Forro Antihumedad',
          'P3.3 Mochila de Vidrio Reforzado Llena de Líquido Fosforescente'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Guantes de Cuero Químico de Caña Alta',
        pieces: [
          'P4.1 Guantes Gruesos de Cuero Tratado hasta el Codo para Manipular Ácidos',
          'P4.2 Manguitos de Cuero con Pulseras Portaviales de Lanzamiento Rápido',
          'P4.3 Dedales de Bronce para Medición de Polvos Peligrosos'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Bandoleras y Cinturones de Pociones',
        pieces: [
          'P5.1 Cinturón Ancho de Cuero con Tres Hileras de Viales de Cristal de Colores',
          'P5.2 Bandolera Cruzada al Pecho con Pociones Explosivas y de Curación',
          'P5.3 Tahalí con Soporte para Mortero de Bronce y Cuchillo Alquímico'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalones de Lona Reforzada',
        pieces: [
          'P6.1 Pantalón de Lona Pesada con Doble Capa Impermeable en Muslos',
          'P6.2 Perneras de Cuero con Bolsillos para Frascos de Reactivos',
          'P6.3 Faldón de Cuero de Protección contra Salpicaduras Químicas'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Botas de Suela de Goma Antiácido',
        pieces: [
          'P7.1 Botas Altas de Cuero Encerado con Suela Gruesa de Goma Resistente a Corrosivos',
          'P7.2 Polainas de Cuero Selladas sobre el Calzado',
          'P7.3 Botines Flexibles con Punteras de Bronce'
        ]
      }
    ],
    materials: ['Cuero grueso tratado con aceite y cera impermeabilizante', 'Lona de algodón ignífuga', 'Vidrio soplado reforzado de borosilicato', 'Cobre y latón para alambiques', 'Caucho y corcho natural'],
    finishes: ['Cuero engrasado con manchas de reactivos', 'Líquidos luminiscentes de colores brillantes', 'Cobre martillado brillante', 'Vidrio transparente impoluto'],
    armorDefenses: [
      { id: 'AR-CHEMICAL-COAT', name: 'Gabardina de Aislamiento Químico e Ígneo', desc: 'Inmunidad a daño por ácidos, fuego, venenos corrosivos y gases tóxicos' },
      { id: 'AR-MUTAGENIC-VITALITY', name: 'Elixir de Vitalidad Mutagénica', desc: 'Regeneración celular constante y tolerancia a toxinas' }
    ],
    weapons: [
      'Pistola Lanzamatraces Neumática para Disparo de Pociones a Distancia',
      'Frascos Arrojadizos de Fuego Alquímico / Ácido Concentrado / Hielo Criogénico',
      'Mortero Pesado de Bronce con Mango de Acero Usado como Maza Contundente',
      'Daga de Disección de Acero Quirúrgico con Canal para Inyección de Venenos',
      'Báculo de Transmutación con Alambique de Cobre en la Cabeza'
    ],
    relicsAndItems: [
      'Piedra Filosofal en Miniatura en Jaula de Oro Hermética',
      'Mortero y Maja de Ágata Maciza para Pulverizar Ingredientes Raros',
      'Libreta de Fórmulas Secretas Escrita en Código Transmutatorio',
      'Balanza de Precisión de Joyero con Pesas de Miligramos'
    ],
    bags: [
      'Maletín de Laboratorio de Cuero Acolchado con Compartimentos para 24 Viales',
      'Bolsa Ignífuga de Bandolera para Compuestos Inestables y Fósforo Blanco',
      'Mochila Rígida con Soporte para Matraces Erlenmeyer',
      'Estuche Cilíndrico de Cuero para Pipetas y Termómetros'
    ],
    equipmentFinishes: [
      'Vidrio transparente con líquidos fluorescentes en verde, rojo y azul',
      'Cobre rojo pulido con conexiones de latón brillante',
      'Cuero marrón avellana con pátina de ceras vegetales',
      'Tapones de corcho natural sellados con cera roja'
    ],
    suggestedColors: [
      { id: 'marron_cuero_alquimista', name: 'Cuero Encerado / Avellana', hex: '#78350F' },
      { id: 'verde_acido', name: 'Verde Ácido / Reactivo', hex: '#22C55E' },
      { id: 'cobre_alambique', name: 'Cobre Rojo / Alambique', hex: '#B45309' },
      { id: 'ambar_pocion', name: 'Ámbar / Oro Alquímico', hex: '#F59E0B' }
    ],
    suggestedWardrobeDetails: ['Docenas de tubos de ensayo con líquidos de colores vivos en el pecho', 'Gafas con múltiples lentes de aumento sobre los ojos o el sombrero', 'Manchas de reactivos químicos en el dobladillo de la gabardina', 'Tubos de serpentín de cobre asomando por la espalda'],
    styleNote: 'Ciencia alquímica mística, cristalería de laboratorio viva, cuero aceitado y máscaras protectoras.'
  },

  'C6 Invocador': {
    roleName: 'C6 Invocador',
    category: 'Arcano y Magia',
    tagline: 'Pactos con seres de otros planos, túnica de invocación con sigilos demoníacos o celestiales, báculo de cuernos y llaves planares',
    description: 'Maestro de portales y convocatorias. Abre fisuras hacia planos elementales, demoníacos o celestiales mediante sellos mágicos, llaves planares y báculos de invocación.',
    recommendedOutfitType: 'O-SUMMONER Túnica de Conjuración Planar con Gran Sigilo Central y Capucha con Cuernos',
    outfitTypes: [
      { id: 'O-SUMMONER-DEMONIC', name: 'O-SUMMONER-DEMONIC Túnica Carmesí y Negra con Runas Demoníacas y Hombreras de Cuernos' },
      { id: 'O-SUMMONER-CELESTIAL', name: 'O-SUMMONER-CELESTIAL Vestiduras Blancas y Doradas con Alas de Luz e Invocación Sagrada' },
      { id: 'O-SUMMONER-SPIRIT', name: 'O-SUMMONER-SPIRIT Atuendo Chamánico con Campanas de Espíritus y Talismanes' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Tiaras de Cuernos y Vendas Oculares',
        pieces: [
          'P1.1 Diadema de Plata con Cuernos Curvos de Entidad Invocada',
          'P1.2 Venda Ocular de Seda con Runa de Visión Planar Bordada en Oro',
          'P1.3 Corona de Plumas Astrales y Cristales de Foco',
          'P1.4 Máscara de Bestia Mitológica en Relieve de Bronce'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Túnicas con Gran Círculo de Conjuración',
        pieces: [
          'P2.1 Túnica de Seda Pesada con un Círculo Mágico de Invocación Bordado en el Pecho',
          'P2.2 Pechera de Cuero con Sellos Planáres Grabados al Aguafuerte',
          'P2.3 Jubón Cruzado con Broches de Garras de Entidades Extraplanares',
          'P2.4 Manto Asimétrico que Parece Desvanecerse en un Portal de Sombras'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Alas Astrales y Mantos de Portales',
        pieces: [
          'P3.1 Gran Capa con el Interior Estampado con el Vórtice de un Portal Planar',
          'P3.2 Alas de Energía Espiritual Semi-Translúcidas',
          'P3.3 Hombreras de Garras de Dragón o Demonio Esculpidas'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Cadenas de Control y Brazaletes de Sellos',
        pieces: [
          'P4.1 Cadenas de Plata Astral Envolviendo los Brazos para Controlar Bestias',
          'P4.2 Brazaletes Anchos con Sellos Rúnicos de Sujeción Planar',
          'P4.3 Guantes de Seda con Símbolos de Invocación Tatuados en las Palmas'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturones con Llaves Planares y Campanas',
        pieces: [
          'P5.1 Cinturón de Cuero con Manojo de Llaves Planares de Oro, Plata y Hueso',
          'P5.2 Campanas de Invocación de Bronce Tintineantes en la Cadera',
          'P5.3 Faja de Seda con Sellos de Conjuración Colgantes'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Faldas de Movimiento Flotante',
        pieces: [
          'P6.1 Falda de Capas de Seda que Parecen Flotar como Niebla Planar',
          'P6.2 Pantalones Holgados con Acentos de Fuego Fatuo en los Dobladillos',
          'P6.3 Calzas de Paño Oscuro con Sellos de Protección en las Rodillas'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Calzado Levitante o Babuchas de Seda',
        pieces: [
          'P7.1 Zapatos de Seda con Bordados de Portales y Puntas Elevadas',
          'P7.2 Botines de Cuero Suave con Tobilleras de Campanas Espirituales',
          'P7.3 Sandalias Mágicas con Sellos de Vuelo Planar'
        ]
      }
    ],
    materials: ['Seda astral tejida con hilos de maná', 'Cuero de bestias extraplanares', 'Plata pura y oro bendecido', 'Huesos de entidades convocadas', 'Gemas de foco planar'],
    finishes: ['Luminiscencia de portal dimensional', 'Bordados intrincados de círculos de invocación', 'Brillo etéreo en ojos y sellos', 'Seda flotante ingrávida'],
    armorDefenses: [
      { id: 'AR-GUARDIAN-AEGIS', name: 'Égida del Familiar Guardián', desc: 'Una entidad etérea intercepta los ataques mortales en lugar del invocador' },
      { id: 'AR-PLANAR-SHIFT', name: 'Desplazamiento Planar Reactivo', desc: 'Permite desvanecerse brevemente al recibir un golpe para evitar daño' }
    ],
    weapons: [
      'Báculo de Invocador con Cabeza de Cuernos y Gran Esfera de Portal Giratoria',
      'Látigo de Cadenas Astrales de Plata para Dirigir Conjuraciones',
      'Daga de Pacto con Hoja Rúnica para Trazar Puertas Planares',
      'Grimorio de Sellos de Demonios y Espíritus Flotando al Costado',
      'Campana de Convocación de Bronce Macizo con Mango de Dragón'
    ],
    relicsAndItems: [
      'Familiar Menor Invocado (Pequeño Dragón, Diablillo o Espíritu de Luz en el Hombro)',
      'Llave Planar Maestra de Platino que Abre Cualquier Fisura Dimensional',
      'Matraz con Esencia de Entidad Extraplanar Atrapada',
      'Piedra de Invocación con el Nombre Verdadero de un Gran Espíritu'
    ],
    bags: [
      'Grimorio-Estuche Rígido para Sellos de Conjuración',
      'Bolsa Astral Hermética para Alimentar Criaturas Convocadas',
      'Funda de Terciopelo para Llaves Planares',
      'Morral de Seda Negra para Cenizas de Conjuración'
    ],
    equipmentFinishes: [
      'Plata brillante con runas de luz púrpura o dorada incisas',
      'Madera de tejo oscuro con tallas de criaturas mitológicas',
      'Oro pulido con reflejos de portal dimensional',
      'Cuero teñido en rojo carmesí o blanco puro'
    ],
    suggestedColors: [
      { id: 'purpura_abismo', name: 'Púrpura Abismal / Portal', hex: '#6B21A8' },
      { id: 'rojo_pacto', name: 'Rojo Carmesí de Pacto', hex: '#991B1B' },
      { id: 'oro_celestial_invocador', name: 'Oro Celestial / Sigilo', hex: '#F59E0B' },
      { id: 'blanco_astral', name: 'Blanco Astral / Luz', hex: '#F8FAFC' }
    ],
    suggestedWardrobeDetails: ['Círculo de invocación brillante bordado en el pecho o la espalda', 'Familiar etéreo reposando sobre el hombro del personaje', 'Llaves de metales raros colgando de la cintura', 'Cadenas de luz astral rodeando los antebrazos'],
    styleNote: 'Misticismo de pactos dimensionales, familiares mágicos vivos, círculos de invocación y llaves planares.'
  },

  'C8 Hechicero de Cristal': {
    roleName: 'C8 Hechicero de Cristal',
    category: 'Arcano y Magia',
    tagline: 'Geometría prismática, cristales de cuarzo y amatista brotando de la armadura, espejos de refracción, báculo de prisma y destellos de luz',
    description: 'Canalizador de la magia de resonancia cristalina y refracción lumínica. Porta túnicas con cristales puros integrados, corazas facetadas y báculos de cuarzo resonante.',
    recommendedOutfitType: 'O-CRYSTAL Túnica Prismática con Formaciones de Cuarzo y Hombreras de Amatista',
    outfitTypes: [
      { id: 'O-CRYSTAL-PRISM', name: 'O-CRYSTAL-PRISM Túnica de Seda Blanca con Cristales de Cuarzo Facetados y Espejos' },
      { id: 'O-CRYSTAL-AMETHYST', name: 'O-CRYSTAL-AMETHYST Armadura de Placas de Amatista Violeta con Túnica Púrpura' },
      { id: 'O-CRYSTAL-OBSIDIAN', name: 'O-CRYSTAL-OBSIDIAN Manto de Cristal de Obsidiana Negra con Filos Cortantes' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Coronas de Cristales y Tiaras Prismáticas',
        pieces: [
          'P1.1 Corona de Agujas de Cuarzo y Amatista Creciendo hacia Arriba',
          'P1.2 Tiara de Plata con Espejo Prismático en la Frente',
          'P1.3 Antifaz de Cristal Translúcido con Refracción de Arcoíris',
          'P1.4 Pendientes Largos de Prismas de Vidrio de Bohemia'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Pecheras Facetadas y Túnicas de Seda',
        pieces: [
          'P2.1 Pechera de Placas de Cuarzo Rosa y Diamante Ensambladas Geométricamente',
          'P2.2 Túnica de Seda con Bordados de Red Cristalina en Hilo de Plata',
          'P2.3 Corpiño con Cristales Brotando de los Hombros y Clavícula',
          'P2.4 Peto de Espejos Pulidos de Plata y Cristal'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Hombreras de Geoda y Capas de Prisma',
        pieces: [
          'P3.1 Hombreras Formadas por Grandes Geodas de Amatista Abiertas',
          'P3.2 Capa de Seda Tornasolada que Cambia de Color con la Luz',
          'P3.3 Alas de Cristales Flotantes que Levitan a la Espalda'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Brazales Facetados y Guanteletes de Cuarzo',
        pieces: [
          'P4.1 Brazales de Plata con Cristales de Cuarzo en Hilera Resonante',
          'P4.2 Guanteletes con Puntas de Dedos de Cristal Afilado como Diamantes',
          'P4.3 Manguitos de Seda Blanca con Cristales Cosidos en los Puños'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturones con Geodas y Prismas',
        pieces: [
          'P5.1 Cinturón de Placas Plateadas con Gran Geoda de Amatista Central',
          'P5.2 Cadena de Cintura con Prismas Colgantes que Proyectan Arcoíris',
          'P5.3 Tahalí para Báculo de Cristal y Daga de Cuarzo'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Faldas con Cascadas de Cristales',
        pieces: [
          'P6.1 Falda de Seda Plisada con Gotas de Cristal Colgando del Dobladillo',
          'P6.2 Pantalones Ajustados con Grebas de Placas de Cristal en las Espinillas',
          'P6.3 Sobrefalda Transparente con Destellos de Purpurina y Microcristales'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Zapatos de Cristal y Botines de Plata',
        pieces: [
          'P7.1 Zapatos de Tacón de Puro Cristal Facetado Transparente',
          'P7.2 Botines de Cuero Blanco con Punteras de Cuarzo',
          'P7.3 Sandalias de Plata con Joyas de Amatista en el Empeine'
        ]
      }
    ],
    materials: ['Cristal de cuarzo puro de roca', 'Amatista natural de geoda', 'Seda tornasolada iridiscente', 'Plata esterlina brillante', 'Diamantes y circonitas'],
    finishes: ['Facetado geométrico de alta precisión', 'Refracción de arcoíris bajo la luz', 'Transparencia cristalina pura', 'Efecto tornasolado brillante'],
    armorDefenses: [
      { id: 'AR-CRYSTAL-REFRACTION', name: 'Armadura de Refracción Cristalina', desc: 'Refleja rayos mágicos y proyectiles de energía devolviéndolos al atacante' },
      { id: 'AR-PRISM-SHATTER', name: 'Barrera de Fragmentación de Cuarzo', desc: 'Al romperse, estalla en miles de esquirlas cortantes que dañan a los agresores' }
    ],
    weapons: [
      'Báculo de Cuarzo Puro con Gran Prisma Giratorio en la Cúspide que Emite Láseres',
      'Espada de Cristal de Amatista Translúcida con Filo Resonante',
      'Orbes de Cuarzo Levitantes que Disparan Proyectiles de Luz Concentrada',
      'Dagas de Diamante Gemelas con Vainas de Plata Espejo',
      'Arco de Cristal con Cuerda de Hilo de Luz y Flechas de Prisma'
    ],
    relicsAndItems: [
      'Prisma de Refracción Lumínica que Separa la Luz en Siete Rayos Elementales',
      'Geoda Sonora que Resuena en Frecuencias Capaces de Romper Rocas',
      'Diapasón de Cristal de Maná para Afinar Hechizos de Resonancia',
      'Espejo de Adivinación de Cuarzo Ahumado'
    ],
    bags: [
      'Estuche Rígido Acolchado en Terciopelo Púrpura para Cristales Delicados',
      'Bolsa de Seda Tornasolada con Forro Antigolpes para Gemas',
      'Funda de Plata Acolchada para Báculo de Cristal',
      'Morral de Cinturón para Fragmentos de Cuarzo de Repuesto'
    ],
    equipmentFinishes: [
      'Cristal facetado a mano con caras pulidas a espejo y brillo prismático',
      'Plata rodiada de alto brillo anticorrosión',
      'Amatista violeta profunda con inclusiones naturales brillantes',
      'Seda blanca nacarada con reflejos violetas y celestes'
    ],
    suggestedColors: [
      { id: 'violeta_amatista', name: 'Violeta Amatista / Geoda', hex: '#8B5CF6' },
      { id: 'blanco_diamante_cristal', name: 'Blanco Diamante / Prisma', hex: '#FFFFFF' },
      { id: 'azul_cian_cristal', name: 'Azul Celeste / Cuarzo', hex: '#38BDF8' },
      { id: 'rosa_cuarzo', name: 'Rosa Cuarzo / Ópalo', hex: '#F472B6' }
    ],
    suggestedWardrobeDetails: ['Cristales de cuarzo y amatista brotando en hombreras y corona', 'Refracción de arcoíris visible en la tela y en los rayos mágicos', 'Báculo de cristal transparente con energía pulsante interior', 'Facetas geométricas impecables en la armadura'],
    styleNote: 'Geometría cristalina pura, refracción de luz de arcoíris, amatistas y cuarzo resplandecientes.'
  }
};
