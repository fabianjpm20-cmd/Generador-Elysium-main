import { CIVIL_ROLES } from './civilAttire';
import { SERVICE_ROLES } from './serviceAttire';
import { ENTERTAINMENT_ROLES } from './entertainmentAttire';
import { MARTIAL_ROLES } from './martialAttire';
import { ARCANE_ROLES } from './arcaneAttire';
import { STEALTH_ROLES } from './stealthAttire';
import { DIVINE_NATURE_ROLES } from './divineNatureAttire';
import { DARK_TECH_ROLES } from './darkTechAttire';
import { ORIENTAL_ROLES } from './orientalAttire';
import { RoleAttireConfig, RoleAttirePieceSlot } from './types';

export * from './types';
export * from './civilAttire';
export * from './serviceAttire';
export * from './entertainmentAttire';
export * from './martialAttire';
export * from './arcaneAttire';
export * from './stealthAttire';
export * from './divineNatureAttire';
export * from './darkTechAttire';
export * from './orientalAttire';

export const ROLE_SPECIFIC_CATALOG: Record<string, RoleAttireConfig> = {
  ...CIVIL_ROLES,
  ...SERVICE_ROLES,
  ...ENTERTAINMENT_ROLES,
  ...MARTIAL_ROLES,
  ...ARCANE_ROLES,
  ...STEALTH_ROLES,
  ...DIVINE_NATURE_ROLES,
  ...DARK_TECH_ROLES,
  ...ORIENTAL_ROLES
};

export function getRoleAttireConfig(roleName?: string): RoleAttireConfig | undefined {
  if (!roleName) return undefined;
  if (ROLE_SPECIFIC_CATALOG[roleName]) {
    return ROLE_SPECIFIC_CATALOG[roleName];
  }
  
  // Try case-insensitive or partial matching
  const lower = roleName.toLowerCase().trim();
  const keys = Object.keys(ROLE_SPECIFIC_CATALOG);
  
  const directKey = keys.find(k => k.toLowerCase() === lower);
  if (directKey) return ROLE_SPECIFIC_CATALOG[directKey];
  
  // Try substring match
  const partialKey = keys.find(k => {
    const kLower = k.toLowerCase();
    return kLower.includes(lower) || lower.includes(kLower);
  });
  if (partialKey) return ROLE_SPECIFIC_CATALOG[partialKey];
  
  // Fallback to Civil Genérico if exists
  return ROLE_SPECIFIC_CATALOG['Civil Genérico'];
}
