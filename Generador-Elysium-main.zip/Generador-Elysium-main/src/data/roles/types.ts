export interface RoleAttirePieceSlot {
  slotId: 'P1' | 'P2' | 'P3' | 'P4' | 'P5' | 'P6' | 'P7';
  slotName: string;
  pieces: string[];
}

export interface RoleAttireConfig {
  roleName: string;
  category: string;
  tagline: string;
  description: string;
  recommendedOutfitType: string;
  outfitTypes: { id: string; name: string }[];
  slots: RoleAttirePieceSlot[];
  materials: string[];
  finishes: string[];
  armorDefenses: { id: string; name: string; desc: string }[];
  weapons: string[];
  relicsAndItems: string[];
  bags: string[];
  equipmentFinishes?: string[];
  suggestedColors: { id: string; name: string; hex: string }[];
  suggestedWardrobeDetails: string[];
  styleNote: string;
}

export const DETAIL_LOCATIONS = [
  'Bordes y dobladillos',
  'Pecho / Centro frontal',
  'Hombros y hombreras',
  'Mangas, puños y antebrazos',
  'Cuello, solapas y escote',
  'Cintura, pretina y fajín',
  'Costuras laterales y flancos',
  'Espalda y omóplatos',
  'Faldones y muslos',
  'Espinillas, tobillos y calzado',
  'Corona, frente o sien (Tocado)',
  'Patrón integral / Toda la superficie'
];

export const GENERAL_ROLE_MATERIALS = [
  'Algodón',
  'Lino',
  'Lana',
  'Seda',
  'Terciopelo',
  'Cuero',
  'Acero',
  'Malla',
  'Encaje',
  'Brocado',
  'Gasa / Tul',
  'Titanio',
  'Madera',
  'PVC',
  'Piel sintética'
];

export const GENERAL_ROLE_FINISHES = [
  'Mate',
  'Satinado',
  'Brillante',
  'Pulido espejo',
  'Bruñido',
  'Desgastado',
  'Filigrana',
  'Translúcido',
  'Metalizado',
  'Adamascado',
  'Acolchado',
  'Lacado'
];

export function getPieceLengthOptions(pieceName?: string, slotId?: string): string[] {
  if (!pieceName) return ['Estándar', 'Corto', 'Medio', 'Largo', 'Extra Largo'];
  const p = pieceName.toLowerCase();

  // Capas, mantos, túnicas, velos
  if (p.includes('manto') || p.includes('capa') || p.includes('velo') || p.includes('cola') || p.includes('toga') || p.includes('hábito')) {
    return [
      'Corto (Sobre Hombros / Cuello)',
      'Medio (A la Cintura)',
      'Largo (A las Rodillas)',
      'Extra Largo (A los Tobillos)',
      'Drapeado al Suelo / Con Cola Arrastrada'
    ];
  }

  // Mangas, guantes, brazales
  if (p.includes('manga') || p.includes('guante') || p.includes('brazal') || p.includes('manopla') || p.includes('muñequera')) {
    return [
      'Corto (A la Muñeca)',
      'Medio (Hasta el Antebrazo)',
      'Largo (Hasta el Codo)',
      'Extra Largo (Hasta el Bíceps)',
      'Completo (Hasta el Hombro)'
    ];
  }

  // Faldones, hakama, faldas, tassets, escarcelas
  if (p.includes('faldón') || p.includes('hakama') || p.includes('falda') || p.includes('tasset') || p.includes('escarcela') || p.includes('tabardo')) {
    return [
      'Micro / Corto (Muslo Alto)',
      'Medio (A Media Pierna)',
      'Largo (Bajo la Rodilla)',
      'Maxi (Hasta los Tobillos)',
      'Asimétrico / Puntas en Cascada'
    ];
  }

  // Botas, grebas, escarpines, calzado
  if (p.includes('bota') || p.includes('greba') || p.includes('escarpín') || p.includes('pernera') || p.includes('calza')) {
    return [
      'Corta (Al Tobillo)',
      'Media (Media Pantorrilla / Espinilla)',
      'Alta (Bajo la Rodilla)',
      'Over-Knee (Sobre la Rodilla / Muslo)'
    ];
  }

  // Tocados, coronas, velos faciales, capuchas
  if (p.includes('capucha') || p.includes('tocado') || p.includes('corona') || p.includes('tiara') || p.includes('diadema')) {
    return [
      'Compacto / Ajustado',
      'Medio con Caída al Cuello',
      'Flotante / Amplio',
      'Con Caídas Laterales Largas'
    ];
  }

  // Fajines, cinturones, arneses
  if (p.includes('fajín') || p.includes('cinturón') || p.includes('arnés') || p.includes('bandolera')) {
    return [
      'Estrecho / Discreto',
      'Medio Estándar',
      'Ancho / Corsetero',
      'Con Caídas y Lazos Colgantes Largos'
    ];
  }

  return ['Estándar', 'Corto', 'Medio', 'Largo', 'Extra Largo'];
}

export function getDefaultPieceLength(pieceName?: string, slotId?: string): string {
  const options = getPieceLengthOptions(pieceName, slotId);
  if (options.length >= 3) {
    return options[1] || options[0];
  }
  return options[0] || 'Estándar';
}
