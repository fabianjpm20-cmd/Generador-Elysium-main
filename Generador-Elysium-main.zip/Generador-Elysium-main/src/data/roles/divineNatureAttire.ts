import { RoleAttireConfig } from './types';

export const DIVINE_NATURE_ROLES: Record<string, RoleAttireConfig> = {
  'E1 Clérigo / Sanador': {
    roleName: 'E1 Clérigo / Sanador',
    category: 'Divino y Naturaleza',
    tagline: 'Gracia y sanación divina, túnica blanca y dorada inmaculada, estola sagrada, símbolo solar y maza bendecida',
    description: 'Ministro de la fe y protector de los heridos. Viste túnicas sacras con bordados de hilo de oro, estolas episcopales, cadenas con símbolos sagrados y empuña mazas bendecidas.',
    recommendedOutfitType: 'O-CLERIC Túnica Sagrada de Seda Blanca y Oro con Estola y Maza Bendecida',
    outfitTypes: [
      { id: 'O-CLERIC-HEALER', name: 'O-CLERIC-HEALER Túnica Inmaculada Blanca y Dorada con Capucha de Oración' },
      { id: 'O-CLERIC-TEMPLAR', name: 'O-CLERIC-TEMPLAR Cota de Malla Plateada con Tabardo Sagrado y Escudo Cruzado' },
      { id: 'O-CLERIC-BISHOP', name: 'O-CLERIC-BISHOP Vestiduras Episcopales con Mitra, Gran Manto y Báculo Pastoral' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Mitras, Tiaras de Luz y Capuchas Sagradas',
        pieces: [
          'P1.1 Mitra Sagrada / Tiara de Oro y Plata con Halo de Luz Celestial',
          'P1.2 Capucha de Oración de Lino Blanco con Borde de Hilo de Oro',
          'P1.3 Corona de Espinas Plateadas de Penitente Devoto',
          'P1.4 Velo de Novicia / Sacerdotisa de Gasa Blanca Pura'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Túnicas Inmaculadas y Tabardos Cruzados',
        pieces: [
          'P2.1 Túnica Larga de Seda Blanca Inmaculada con Bordados en Pan de Oro',
          'P2.2 Tabardo de Lino Pesado con la Cruz Solar o Emblema Divino Bordado en el Pecho',
          'P2.3 Cota de Malla Plateada Pulida bajo la Sobreveste Sagrada',
          'P2.4 Peto de Acero y Oro con Relieve de Alas de Ángel'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Estolas Episcopales y Mantos Sagrados',
        pieces: [
          'P3.1 Estola Sagrada Cruzada al Pecho con Símbolos de Sanación y Bendición',
          'P3.2 Gran Manto Episcopal de Terciopelo Blanco y Oro con Forro de Seda Azul',
          'P3.3 Capelina de Cuello con Broche de Sol Radiante'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Manguitos Sagrados y Rosario de Muñeca',
        pieces: [
          'P4.1 Manguitos de Seda Blanca con Bordados de Oraciones en Latín / Lengua Sagrada',
          'P4.2 Rosario de Cuentas de Madera Sagrada y Oro Envolviendo la Mano Derecha',
          'P4.3 Guanteletes Plateados con Palmas de Cuero Suave para Imposición de Manos'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cíngulos y Cinturones con Viales de Óleos',
        pieces: [
          'P5.1 Cíngulo de Cordón de Hilo de Oro Trenzado con Borlas Colgantes',
          'P5.2 Cinturón de Cuero Blanco con Frascos de Óleos Sagrados y Agua Bendita',
          'P5.3 Tahalí para Maza Bendecida y Libro de Salmos'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Faldas de Túnica con Dobladillos Ricos',
        pieces: [
          'P6.1 Falda de Túnica Sagrada con Caída Majestuosa y Cenefa de Pan de Oro',
          'P6.2 Calzas Blancas de Lino Puro Cómodas para Peregrinaje',
          'P6.3 Grebas de Acero Plateado sobre Pantalón de Paño'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Sandalias de Peregrino o Botines Blancos',
        pieces: [
          'P7.1 Sandalias de Cuero Bendecido con Tiras Blancas y Suela Acolchada',
          'P7.2 Botines de Cuero Blanco Inmaculado con Hebillas de Oro Solar',
          'P7.3 Escarpines Plateados con Puntas Redondeadas'
        ]
      }
    ],
    materials: ['Seda inmaculada blanca', 'Lino puro de monasterio', 'Hilo de oro batido', 'Plata esterlina bendecida', 'Madera de olivo centenario'],
    finishes: ['Luminiscencia dorada sagrada tenue', 'Bordados eclesiásticos de alta densidad', 'Acero y plata pulidos a espejo sin mácula', 'Blanco puro reflectante'],
    armorDefenses: [
      { id: 'AR-DIVINE-GRACE', name: 'Gracia Divina / Velo de Pureza', desc: 'Inmunidad absoluta a enfermedades, maldiciones y reducción masiva de daño necrótico' },
      { id: 'AR-SANCTUARY-AURA', name: 'Aura de Santuario Inviolable', desc: 'Los enemigos deben superar una prueba de voluntad antes de poder atacar al sanador' }
    ],
    weapons: [
      'Maza de Armas Sagrada de Oro y Acero con Cabeza en Forma de Sol Radiante',
      'Báculo Pastoral de Obispo Rematado en Espiral de Plata y Cruz Solar',
      'Escudo Sagrado de Lágrima Pintado con la Cruz Radiante y Reborde Dorado',
      'Daga de Consagración con Hoja de Plata y Mango de Marfil',
      'Incensario / Turíbulo Encendido de Bronce con Cadena de Oro para Ataque y Purificación'
    ],
    relicsAndItems: [
      'Símbolo Sagrado de Oro Macizo Llevado al Cuello que Emite Luz Divina',
      'Libro Sagrado de Salmos y Milagros con Broches de Plata',
      'Frasco de Óleo Sagrado de Sanación Instantánea de Heridas Mortales',
      'Cáliz de Oro con Agua Bendecida por los Ángeles'
    ],
    bags: [
      'Morral de Peregrino de Lino Blanco con Cruz Roja de Curación',
      'Cofrecito de Plata para Óleos de la Unción y Reliquias',
      'Bolsa de Seda para Hierbas Medicinales Purificadas',
      'Funda Acolchada para Báculo Sagrado'
    ],
    equipmentFinishes: [
      'Oro pulido resplandeciente con grabados de rayos solares',
      'Plata inmaculada que no acumula suciedad ni sangre',
      'Madera de olivo encerada con aroma a sándalo',
      'Cuero blanco impoluto tratado con esencias sagradas'
    ],
    suggestedColors: [
      { id: 'blanco_inmaculado', name: 'Blanco Inmaculado / Pureza', hex: '#FFFFFF' },
      { id: 'oro_solar_clerigo', name: 'Oro Solar / Divino', hex: '#F59E0B' },
      { id: 'azul_cielo_celeste', name: 'Azul Celeste / Gracia', hex: '#38BDF8' },
      { id: 'rojo_sacro', name: 'Rojo Carmesí / Sagrado', hex: '#DC2626' }
    ],
    suggestedWardrobeDetails: ['Estola bordada en oro cruzada sobre el pecho', 'Halo de luz suave rodeando la cabeza o el símbolo sagrado', 'Turíbulo humeante con incienso aromático ondeando con la cadena', 'Túnica blanca impoluta sin ninguna mancha de combate'],
    styleNote: 'Pureza sacra celestial, oro resplandeciente, sanación milagrosa y devoción solemne.'
  },

  'E2 Paladín Sagrado': {
    roleName: 'E2 Paladín Sagrado',
    category: 'Divino y Naturaleza',
    tagline: 'Justicia inquebrantable, armadura completa de placas de plata y oro, tabardo blanco, espada a dos manos bendecida y escudo de luz',
    description: 'Guerrero sagrado juramentado a la defensa del bien. Combina la invulnerabilidad de la armadura gótica completa con el poder del castigo divino y las auras de protección.',
    recommendedOutfitType: 'O-PALADIN Armadura Completa de Placas de Plata y Oro con Tabardo Sagrado y Espada de Luz',
    outfitTypes: [
      { id: 'O-PALADIN-JUSTICE', name: 'O-PALADIN-JUSTICE Placas de Plata Espejo con Grabados Dorados, Gran Yelmo y Espada de Dos Manos' },
      { id: 'O-PALADIN-SUN', name: 'O-PALADIN-SUN Armadura Dorada del Sol Radiante con Manto Carmesí y Martillo de Castigo' },
      { id: 'O-PALADIN-OATH', name: 'O-PALADIN-OATH Armadura de Voto Sagrado con Pergaminos y Sellos de Cera de Pureza' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Yelmos con Corona y Penachos Sagrados',
        pieces: [
          'P1.1 Yelmo de Celada de Plata con Corona de Oro Integrada y Visera de Cruz',
          'P1.2 Gran Yelmo Cilíndrico de Cruzado con Corona de Hojas de Roble de Oro',
          'P1.3 Corona / Diadema de Paladín de Platino con Rubí Central',
          'P1.4 Penacho de Plumas Blancas Majestuosas sobre el Yelmo'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Peto de Acero y Oro con Relieve Sagrado',
        pieces: [
          'P2.1 Peto de Doble Placa de Plata con Gran Cruz Solar de Oro en Relieve',
          'P2.2 Tabardo de Seda Blanca con Blasón de la Orden de la Luz Bordado',
          'P2.3 Gorguera de Placas Articuladas con Cierre de Oro',
          'P2.4 Brigantina Sagrada de Escamas de Plata bajo Terciopelo Azul'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Grandes Hombreras y Capas Heráldicas',
        pieces: [
          'P3.1 Hombreras Gigantes de Placas con Alas de Ángel Esculpidas',
          'P3.2 Gran Manto Blanco con Forro Carmesí Sujeto con Broches de Sol de Oro',
          'P3.3 Espaldar de Plata Pulida con Soporte para Gran Espada de Luz'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Guanteletes de Castigo Divino',
        pieces: [
          'P4.1 Guanteletes de Placas Articuladas de Plata con Runas Sagradas en los Nudillos',
          'P4.2 Brazales Completos con Relieves de Ángeles Guerreros',
          'P4.3 Manoplas Pesadas para Empuñar Armas de Dos Manos'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturón Militar con Sellos de Juramento',
        pieces: [
          'P5.1 Cinturón Militar de Placas de Oro con Pergaminos del Voto Sagrado y Sellos de Cera Roja',
          'P5.2 Fauld de Láminas de Plata Articuladas Protegiendo Caderas',
          'P5.3 Tahalí para Espada Sagrada con Vaina de Cuero Blanco y Oro'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Escarcelas y Grebas de Paladín',
        pieces: [
          'P6.1 Escarcelas de Placas de Plata con Bordes de Pan de Oro Protegiendo Muslos',
          'P6.2 Grebas Anatómicas de Plata con Rodilleras de Sol Radiante',
          'P6.3 Quijotes Acolchados con Refuerzo de Malla'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Escarpines de Plata Articulados',
        pieces: [
          'P7.1 Escarpines de Acero y Plata con Puntera Ancha y Espuelas de Oro',
          'P7.2 Botas de Montar Blindadas con Placas Frontales',
          'P7.3 Calzado de Placas con Suela Antideslizante Bendecida'
        ]
      }
    ],
    materials: ['Plata celestial y acero templado al fuego sagrado', 'Oro de 24K para relieves y cruces', 'Terciopelo blanco y seda carmesí', 'Cuero blanco de toro bendecido', 'Cera de abeja consagrada para sellos'],
    finishes: ['Plata brillante a espejo con reflejos divinos', 'Relieves escultóricos de ángeles en oro', 'Pintura heráldica impecable', 'Luz sagrada pulsante en armas'],
    armorDefenses: [
      { id: 'AR-HOLY-AEGIS', name: 'Armadura Sagrada de la Fe Inquebrantable', desc: 'Máxima defensa física y mágica, con inmunidad al miedo y la corrupción' },
      { id: 'AR-SMITE-AURA', name: 'Aura de Castigo Divino', desc: 'Daña automáticamente a no-muertos y demonios que se acerquen al paladín' }
    ],
    weapons: [
      'Espada de Dos Manos (Greatsword) de Luz Bendecida con Filo Plateado Ardiente',
      'Martillo de Guerra de Paladín con Cabeza de Oro Macizo y Púa Sagrada',
      'Escudo Torre de Plata y Oro con Relieve del Sol de la Justicia',
      'Lanza de Cruzado con Estandarte Blanco y Filo de Diamante',
      'Espada Larga de Una Mano con Gavilanes en Cruz de Oro'
    ],
    relicsAndItems: [
      'Relicario con Cenizas de los Primeros Mártires de la Orden',
      'Sellos de Cera Roja con Pergaminos del Voto de Cruzada Colgando de la Armadura',
      'Frasco de Óleo Sagrado para Imbuir Armas en Fuego Divino',
      'Cuerno de Plata de la Victoria de los Justos'
    ],
    bags: [
      'Funda de Terciopelo Blanco y Oro para Gran Espada Sagrada',
      'Morral de Campaña de Cuero Blanco con Sellos de la Orden',
      'Alforjas de Montura de Caballo de Guerra Blindado',
      'Estuche Rígido de Plata para el Yelmo'
    ],
    equipmentFinishes: [
      'Plata pulida a espejo sin una sola huella ni rasguño',
      'Relieves de oro bruñido con alto contraste tridimensional',
      'Empuñadura de espada envuelta en alambre de oro y cuero blanco',
      'Escudo con esmalte blanco y sol dorado en relieve'
    ],
    suggestedColors: [
      { id: 'plata_paladin', name: 'Plata Celestial / Espejo', hex: '#E2E8F0' },
      { id: 'oro_justicia', name: 'Oro Real / Justicia', hex: '#EAB308' },
      { id: 'blanco_orden', name: 'Blanco Orden de la Luz', hex: '#FFFFFF' },
      { id: 'rojo_carmesi_paladin', name: 'Rojo Carmesí / Voto', hex: '#991B1B' }
    ],
    suggestedWardrobeDetails: ['Placas de plata resplandeciente con bordes de pan de oro', 'Espada imbuida en un resplandor dorado de luz sagrada', 'Múltiples sellos de cera con tiras de pergamino de votos sagrados', 'Tabardo blanco inmaculado con la cruz de la justicia'],
    styleNote: 'Justicia marcial absoluta, plata y oro resplandecientes, castigo divino y armadura monumental.'
  },

  'E3 Druida': {
    roleName: 'E3 Druida',
    category: 'Divino y Naturaleza',
    tagline: 'Voz del bosque ancestral, túnica de corteza y musgo, cuernos de ciervo, hoz de oro, báculo de roble vivo y hojas de otoño',
    description: 'Guardián del equilibrio natural y los círculos de piedra. Viste ropas confeccionadas con fibras vegetales, cueros naturales, musgo, cornamentas de ciervo y empuña hoces de oro vegetal.',
    recommendedOutfitType: 'O-DRUID Túnica de Fibras Vegetales con Hombros de Musgo, Cornamenta y Báculo de Roble',
    outfitTypes: [
      { id: 'O-DRUID-FOREST', name: 'O-DRUID-FOREST Túnica Verde Hoja con Manto de Musgo, Flores Silvestres y Hoz de Oro' },
      { id: 'O-DRUID-CIRCLE', name: 'O-DRUID-CIRCLE Tocado de Gran Cornamenta de Ciervo con Piel de Lobo y Huesos' },
      { id: 'O-DRUID-AUTUMN', name: 'O-DRUID-AUTUMN Atuendo de Hojas de Otoño Doradas y Capucha de Corteza' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Cornamentas de Ciervo y Coronas de Hojas',
        pieces: [
          'P1.1 Gran Cornamenta de Ciervo Noble / Alce Brotando de la Cabeza con Musgo y Hojas',
          'P1.2 Corona de Ramas de Roble Entrelazadas con Bellotas y Bayas Silvestres',
          'P1.3 Capucha de Piel de Lobo o Tejón con Orejas Naturales',
          'P1.4 Máscara de Corteza de Abedul con Pinturas de Esporas Verdes'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Túnicas de Fibras Vegetales y Musgo',
        pieces: [
          'P2.1 Túnica de Fibras de Lino y Ortiga Teñida con Extracto de Musgo y Hojas',
          'P2.2 Pechera de Placas de Corteza de Roble Endurecida y Raíces Vivas',
          'P2.3 Chaleco de Cuero Suave de Ciervo con Pelo Natural',
          'P2.4 Envolturas de Enredaderas Floridas sobre el Pecho'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Mantos de Musgo y Capas de Hojas',
        pieces: [
          'P3.1 Gran Manto de Musgo Vivo y Líquenes que Crecen sobre los Hombros',
          'P3.2 Capa de Hojas de Otoño Cosidas en Degradado de Verde a Dorado',
          'P3.3 Piel de Oso Pardo Salvaje Llevada sobre la Espalda'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Envolturas de Raíces y Brazaletes de Madera',
        pieces: [
          'P4.1 Envolturas de Raíces Flexibles que se Mueven con la Voluntad del Druida',
          'P4.2 Brazales de Madera de Tejo Tallada con Símbolos Espirales Ogham',
          'P4.3 Guantes de Cuero Crudo con Semillas y Esporas en los Nudillos'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cintos de Lianas y Bolsas de Semillas',
        pieces: [
          'P5.1 Cinturón de Liana Trenzada con Bolsitas de Semillas Mágicas y Frascos de Rocío',
          'P5.2 Tahalí de Cuero para Hoz de Oro Sagrada de Recolección',
          'P5.3 Faja de Corteza Flexible con Hojas Colgantes'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Faldones de Hojas y Pantalones de Lino',
        pieces: [
          'P6.1 Faldón de Capas de Hojas Superpuestas y Helechos',
          'P6.2 Pantalones de Fibras Naturales Holgados con Tinte de Tierra',
          'P6.3 Perneras de Cuero de Ciervo con Enredaderas'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Mocasines de Cuero Suave o Pies Descalzos',
        pieces: [
          'P7.1 Mocasines de Cuero Suave con Suela Flexible que Siente la Tierra',
          'P7.2 Envolturas de Hojas y Cuerdas en Pies Descalzos con Musgo',
          'P7.3 Botines de Madera y Cuero con Suela Silenciosa'
        ]
      }
    ],
    materials: ['Corteza de roble y abedul tratada', 'Musgo vivo y líquenes silvestres', 'Fibras de ortiga, lino y cáñamo', 'Cuero curtido naturalmente con bellotas', 'Oro vegetal y ámbar fósil'],
    finishes: ['Orgánico vivo con plantas que brotan', 'Corteza con vetas naturales de madera', 'Pieles suaves sin teñir', 'Musgo húmedo y rocío matutino'],
    armorDefenses: [
      { id: 'AR-BARKSKIN', name: 'Piel de Roble Ancestral (Barkskin)', desc: 'La piel se endurece como madera milenaria otorgando gran absorción de daño' },
      { id: 'AR-NATURES-EMBRACE', name: 'Abrazo de la Madre Tierra', desc: 'Regeneración continua de vitalidad mientras esté en contacto con suelo natural' }
    ],
    weapons: [
      'Báculo de Roble Vivo con Ramas que Florecen y Gran Gema de Ámbar',
      'Hoz Sagrada de Oro (Golden Sickle) para Cortar Muérdago y Desgarrar',
      'Garrote de Espinas de Madera de Tejo Imbuido en Veneno Vegetal',
      'Honda de Fibras de Cáñamo con Semillas Explosivas de Esporas',
      'Daga de Hueso de Ciervo Tallado con Empuñadura de Madera'
    ],
    relicsAndItems: [
      'Brote de Árbol del Mundo en Frasco de Vidrio con Tierra Sagrada',
      'Frasco de Rocío de Luna Recogido en el Solsticio de Verano',
      'Cuerno de Cornalina para Comunicarse con las Bestias del Bosque',
      'Semillas Milagrosas que Crecen en Enredaderas Gigantes en Segundos'
    ],
    bags: [
      'Morral de Fibras de Cáñamo con Frascos de Hierbas y Semillas',
      'Bolsa de Cuero de Ciervo para Guardar la Hoz de Oro',
      'Cesta de Mimbre Tradicional para Bayas y Hongos Curativos',
      'Funda de Corteza de Abedul para el Báculo'
    ],
    equipmentFinishes: [
      'Madera de roble natural sin barniz químico con savia brillante',
      'Oro suave pulido para no dañar las plantas sagradas',
      'Ámbar fósil transparente con hojas o insectos preservados',
      'Cuero en tono tierra natural con costuras de cáñamo'
    ],
    suggestedColors: [
      { id: 'verde_bosque_druida', name: 'Verde Bosque / Musgo', hex: '#166534' },
      { id: 'marron_corteza', name: 'Marrón Corteza / Roble', hex: '#78350F' },
      { id: 'dorado_ambar', name: 'Ámbar / Oro Vegetal', hex: '#F59E0B' },
      { id: 'verde_salvia', name: 'Verde Salvia / Hoja', hex: '#84CC16' }
    ],
    suggestedWardrobeDetails: ['Gran cornamenta de ciervo con ramas y hojas vivas', 'Musgo verde y flores silvestres creciendo sobre los hombros', 'Hoz de oro curvada colgada de la cintura con cordón de liana', 'Báculo de madera nudosa con brotes verdes floreciendo'],
    styleNote: 'Conexión sagrada con la naturaleza salvaje, vegetación viva integrada, cornamentas y hoces de oro.'
  },

  'E4 Guardabosques / Ranger': {
    roleName: 'E4 Guardabosques / Ranger',
    category: 'Divino y Naturaleza',
    tagline: 'Supervivencia en tierra salvaje, abrigo de cuero verde y marrón, gran arco recurvo, carcaj de flechas emplumadas y compañero animal',
    description: 'Rastreador y cazador de fronteras salvajes. Viste ropa práctica de cuero curtido y paño verde, botas de marcha, arco largo o ballesta y dagas gemelas de caza.',
    recommendedOutfitType: 'O-RANGER Atuendo de Rastreador de Bosque con Capa Verde, Arco Largo y Carcaj Dorsal',
    outfitTypes: [
      { id: 'O-RANGER-ARCHER', name: 'O-RANGER-ARCHER Capa de Cazador con Gran Arco Largo y Carcaj de 30 Flechas' },
      { id: 'O-RANGER-DUAL', name: 'O-RANGER-DUAL Jubón de Cuero Reforzado con Dagas Gemelas y Arco Corto' },
      { id: 'O-RANGER-SNOW', name: 'O-RANGER-SNOW Ropajes de Explorador Ártico con Cuello de Piel y Esquís' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Capuchas de Cazador y Cintas',
        pieces: [
          'P1.1 Capucha de Cuero Verde Bosque con Borde Reforzado contra Lluvia',
          'P1.2 Sombrero de Cazador de Fieltro con Pluma de Halcón',
          'P1.3 Cinta de Cuero para el Pelo con Cuentas de Madera',
          'P1.4 Pañuelo de Cuello Triangular de Camuflaje Forestal'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Jubones de Cuero y Chalecos Reforzados',
        pieces: [
          'P2.1 Jubón de Cuero Curtido con Costuras Dobles y Refuerzo en Pecho',
          'P2.2 Camisa de Lino Grueso Verde Oliva con Cordones',
          'P2.3 Protector de Pecho de Cuero Rígido (Chest-Guard) para Evitar Roces de la Cuerda del Arco',
          'P2.4 Bandolera de Cuero Cruzada con Cuchillo de Caza'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Capas de Rastreador y Carcajs Dorsales',
        pieces: [
          'P3.1 Capa de Viaje Verde Bosque Impermeable con Forro de Lana',
          'P3.2 Carcaj Dorsal de Cuero Repujado con Capacidad para 30 Flechas',
          'P3.3 Hombrera de Cuero Grueso en el Hombro que Apoya el Arco'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Brazalete de Arquero (Bracer) y Guantes',
        pieces: [
          'P4.1 Brazalete de Arquero (Bracer) de Cuero Rígido en el Antebrazo Izquierdo',
          'P4.2 Guantelete de Tres Dedos (Tab de Arquero) de Cuero Suave',
          'P4.3 Manguitos de Cuero con Refuerzos contra Ramas y Espinas'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturones con Herramientas de Trampero',
        pieces: [
          'P5.1 Cinturón Ancho de Cuero con Trampas Plegables, Cuerdas y Cuchillo de Desollar',
          'P5.2 Tahalí Lateral para Espada Corta / Machete de Monte',
          'P5.3 Faja de Tela Resistente con Bolsa de Yesca y Sal'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalones de Cuero y Perneras de Caza',
        pieces: [
          'P6.1 Pantalones de Cuero Flexible con Refuerzos en Rodillas y Entrepierna',
          'P6.2 Perneras de Lona Encerada contra Barro y Zarzas',
          'P6.3 Calzones de Lana Gruesa Cómodos para Marchas de Días'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Botas de Caza de Caña Alta',
        pieces: [
          'P7.1 Botas de Caza de Cuero Impermeabilizado con Suela de Tracción de Tierra',
          'P7.2 Polainas de Cuero Ajustadas con Cordones hasta la Rodilla',
          'P7.3 Mocasines Silenciosos de Acecho'
        ]
      }
    ],
    materials: ['Cuero curtido al aceite impermeable', 'Lana hilada resistente', 'Lino verde oliva teñido', 'Madera de tejo para arcos', 'Plumas de ganso y águila para flechas'],
    finishes: ['Colores terrosos y forestales integrados', 'Cuero encerado mate', 'Costuras reforzadas con hilo encerado', 'Madera barnizada al aceite natural'],
    armorDefenses: [
      { id: 'AR-FOREST-AGILITY', name: 'Agilidad y Movilidad Forestal', desc: 'Velocidad de movimiento superior en terreno accidentado y ventaja en rastreo' },
      { id: 'AR-SURVIVOR-INSTINCT', name: 'Instinto de Supervivencia en la Naturaleza', desc: 'Resistencia a climas extremos (frío, calor) y detección de trampas' }
    ],
    weapons: [
      'Arco Largo Recurvo de Tejo con Refuerzos de Hueso y Cuerda de Seda Encerada',
      'Par de Espadas Cortas / Machetes de Cazador para Combate Cercano',
      'Gran Arco Compuesto con Mira de Puntería para Presas Colosales',
      'Cuchillo de Monte de Hoja Ancha con Gancho de Desollar en la Punta',
      'Lanza de Caza Corta con Púa Cruzada de Jabalí'
    ],
    relicsAndItems: [
      'Silbato de Hueso de Águila para Llamar al Compañero Animal',
      'Kit de Trampero con Alambre de Acero, Cepos y Cebo de Rastreo',
      'Pedernal y Yesca de Hongo en Caja Estanca de Latón',
      'Mapa Topográfico de Cuero Dibujado a Mano de las Tierras Salvajes'
    ],
    bags: [
      'Mochila de Exploración de Lona con Manta Enrollada en la Parte Superior',
      'Carcaj de Flechas Rígido con Tapa Impermeable de Piel',
      'Cantimplora de Cuero Encerado con Cierre de Madera',
      'Zurrón de Caza para Raciones y Piezas Cobradas'
    ],
    equipmentFinishes: [
      'Madera de tejo noble con veta rojiza pulida con cera de abeja',
      'Flechas con astiles de cedro pintados con cresting verde y blanco',
      'Plumas de empenaje cortadas con precisión milimétrica',
      'Cuero marrón oliva con remaches de latón apagado'
    ],
    suggestedColors: [
      { id: 'verde_bosque_ranger', name: 'Verde Guardabosques', hex: '#15803D' },
      { id: 'marron_tierra_ranger', name: 'Marrón Cuero / Corteza', hex: '#713F12' },
      { id: 'gris_granito_caza', name: 'Gris Granito / Piedra', hex: '#4B5563' },
      { id: 'dorado_hoja_seca', name: 'Dorado Hoja Seca', hex: '#CA8A04' }
    ],
    suggestedWardrobeDetails: ['Carcaj repleto de flechas con plumas asomando sobre el hombro', 'Protector de brazo de arquero de cuero rígido atado al antebrazo', 'Capa verde con capucha caída sobre la espalda', 'Cuchillo de caza grande sujeto horizontalmente en la cintura'],
    styleNote: 'Supervivencia táctica forestal, arquería magistral, cuero aceitado y rastreo implacable.'
  },

  'E5 Chamán Espiritual': {
    roleName: 'E5 Chamán Espiritual',
    category: 'Divino y Naturaleza',
    tagline: 'Comunión con los ancestros, pinturas rituales de arcilla, máscara totémica, báculo de sonajas y calaveras con plumas y tambor chamánico',
    description: 'Canalizador del mundo espiritual y los ancestros tribales. Viste pieles de animales tótem, collares de dientes y garras, tocados de plumas y toca tambores sagrados.',
    recommendedOutfitType: 'O-SHAMAN Atuendo Chamánico con Tocado de Plumas de Águila, Pinturas Rituales y Tambor',
    outfitTypes: [
      { id: 'O-SHAMAN-TOTEM', name: 'O-SHAMAN-TOTEM Tocado de Gran Pluma con Pieles de Lobo, Pinturas de Arcilla y Sonajas' },
      { id: 'O-SHAMAN-MASK', name: 'O-SHAMAN-MASK Máscara de Madera Tallada de Espíritu Ancestral con Cuernos' },
      { id: 'O-SHAMAN-VOODOO', name: 'O-SHAMAN-VOODOO Manto de Plumas Negras con Muñecos de Paja y Frascos de Almas' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Tocados de Plumas y Máscaras Totémicas',
        pieces: [
          'P1.1 Gran Tocado de Plumas de Águila y Halcón con Banda de Cuentas de Turquesa',
          'P1.2 Máscara de Madera Tallada de Espíritu de la Selva con Ojos Huecos Luminosos',
          'P1.3 Cráneo de Ciervo con Cornamenta Llevado como Casco Ritual',
          'P1.4 Pinturas Faciales de Arcilla Blanca y Ocre Rojo con Símbolos de Espíritus'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Pechos Pintados y Chalecos de Piel',
        pieces: [
          'P2.1 Torso Descubierto con Tatuajes Sagrados y Líneas de Arcilla Ritual',
          'P2.2 Poncho / Chaleco de Piel de Jaguar o Lobo con Flecos de Cuero',
          'P2.3 Gran Pectoral de Huesos de Pecho y Cuentas de Conchas Marinas',
          'P2.4 Túnica Corta de Cáñamo con Cenefas de Animales Sagrados'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Mantos de Pieles y Capas de Plumas',
        pieces: [
          'P3.1 Manto Completo de Piel de Gran Felino con Garras Colgando de los Hombros',
          'P3.2 Capa de Plumas de Guacamayo Multicolor que Reflejan el Sol',
          'P3.3 Arnés Dorsal para Portar el Tambor Sagrado'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Pulseras de Semillas y Sonajas de Pezuña',
        pieces: [
          'P4.1 Pulseras de Pezuñas de Ciervo Secas que Suenan al Mover los Brazos',
          'P4.2 Brazaletes de Cobre y Plata con Piedras de Turquesa Incrustadas',
          'P4.3 Envolturas de Cuero con Pinturas de Fuego en los Antebrazos'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturones con Talismanes y Fetiches',
        pieces: [
          'P5.1 Cinturón de Cuero con Fetiches de Madera, Bolsas de Hierbas Medicinales y Plumas',
          'P5.2 Faja de Lana Tejida a Mano con Diseños Geométricos Ancestrales',
          'P5.3 Tahalí de Cuero para Hacha Ceremonial Tomahawk'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Taparrabos de Piel y Faldones con Flecos',
        pieces: [
          'P6.1 Taparrabos de Cuero Suave de Antílope con Bordados de Cuentas',
          'P6.2 Faldón de Capas de Piel con Sonajas de Concha en los Bordes',
          'P6.3 Polainas de Piel con Flecos que Ondulan al Bailar en Trance'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Mocasines Bordados y Tobilleras Sonoras',
        pieces: [
          'P7.1 Mocasines de Cuero de Búfalo con Bordados de Cuentas de Vidrio',
          'P7.2 Tobilleras con Cascabeles de Bronce y Semillas Sonoras para la Danza Ritual',
          'P7.3 Pies Descalzos Marcados con Cenizas Sagradas'
        ]
      }
    ],
    materials: ['Pieles curtidas al humo con pelo', 'Plumas de aves rapaces y selváticas', 'Turquesa, jade y conchas marinas', 'Madera de cedro sagrado', 'Arcilla blanca y ocre mineral'],
    finishes: ['Pintura ritual mate sobre piel y madera', 'Sonajas sonoras rítmicas', 'Flecos de cuero en movimiento', 'Cuentas de piedra pulidas'],
    armorDefenses: [
      { id: 'AR-SPIRIT-TOTEM', name: 'Protección del Tótem Ancestral', desc: 'Espíritus guías interceptan hechizos y ataques oscuros protegiendo al chamán' },
      { id: 'AR-TRANCE-INVULNERABILITY', name: 'Trance del Éxtasis Sagrado', desc: 'Inmunidad al dolor físico y potenciación mágica masiva durante danzas rituales' }
    ],
    weapons: [
      'Báculo Chamánico con Cabeza de Cráneo de Animal, Plumas y Campanas',
      'Tambor Chamánico de Piel de Venado con Baqueta de Cuero para Conjuración Sonora',
      'Tomahawk / Hacha Ceremonial con Cabeza de Piedra Tallada y Mango Decorado',
      'Daga de Sílex Ritual con Mango Enuelto en Tendones',
      'Cerbatana Chamánica para Disparo de Polvos Alucinógenos'
    ],
    relicsAndItems: [
      'Pipa Sagrada de la Paz de Piedra Roja (Catlinita) con Tabaco Sagrado',
      'Bolsa de Medicina Tribal con Huesos de Adivinación y Piedras de Poder',
      'Cuenco de Sahumerio con Salvia Blanca y Copal Encendido',
      'Fetiche de Madera Tallada con el Espíritu del Oso Atrapado'
    ],
    bags: [
      'Bolsa de Medicina de Cuero de Nutria con Cierre de Hueso',
      'Funda de Piel Acolchada para Tambor Sagrado',
      'Morral de Lana Tejida para Hierbas Sagradas y Polvos de Colores',
      'Carcaj de Piel para Flautas de Bambú y Cerbatanas'
    ],
    equipmentFinishes: [
      'Madera de cedro tallada con gubia y teñida con pigmentos naturales',
      'Piedra de sílex lascada con filos cristalinos y aristas vivas',
      'Turquesa pulida cabujón con vetas oscuras naturales',
      'Cobre batido con pátina verdosa decorativa'
    ],
    suggestedColors: [
      { id: 'ocre_rojo_arcilla', name: 'Ocre Rojo / Arcilla', hex: '#991B1B' },
      { id: 'turquesa_sagrada', name: 'Turquesa / Cielo', hex: '#06B6D4' },
      { id: 'marron_búfalo', name: 'Marrón Búfalo / Piel', hex: '#451A03' },
      { id: 'blanco_ceniza_ritual', name: 'Blanco Ceniza / Arcilla', hex: '#E7E5E4' }
    ],
    suggestedWardrobeDetails: ['Pinturas de guerra de arcilla blanca y roja en cara y pecho', 'Gran tocado de plumas ondeando con solemnidad', 'Tambor de piel de ciervo en una mano y baqueta en la otra', 'Sonajas de pezuña en muñecas y tobillos sonando con cada paso'],
    styleNote: 'Trance chamánico ancestral, conexión con espíritus totémicos, tambores rituales y pinturas de arcilla.'
  },

  'E6 Monje Marcial': {
    roleName: 'E6 Monje Marcial',
    category: 'Divino y Naturaleza',
    tagline: 'Disciplina del Ki y artes marciales, túnica monástica de seda o lino, vendas en puños y piernas, rosario budista gigante y bastón bo',
    description: 'Maestro del combate cuerpo a cuerpo y la canalización de la energía espiritual (Ki). Viste túnicas monásticas cruzadas, vendas en manos y pies, y porta bastones de madera.',
    recommendedOutfitType: 'O-MONK Túnica Monástica Cruzada de Lino Naranja / Blanco con Vendas de Puños y Bastón Bo',
    outfitTypes: [
      { id: 'O-MONK-SHAOLIN', name: 'O-MONK-SHAOLIN Túnica Shaolin Naranja / Azafrán con Vendas en Pantorrillas y Bastón' },
      { id: 'O-MONK-WANDERER', name: 'O-MONK-WANDERER Ropajes de Monje Errante con Sombrero Cónico de Paja y Rosario Gigante' },
      { id: 'O-MONK-KI-MASTER', name: 'O-MONK-KI-MASTER Atuendo de Maestro del Dragón con Torso al Aire y Tatuajes de Ki' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Sombreros de Paja Kasa y Marcas de Ki',
        pieces: [
          'P1.1 Sombrero Cónico de Paja Kasa con Ala Ancha que Sombrea el Rostro',
          'P1.2 Cabeza Afeitada con Seis Puntos de Incienso Monástico en la Coronilla',
          'P1.3 Cinta de Frente de Algodón Blanco con Runa de Concentración',
          'P1.4 Venda Ocular de Seda para Luchar Mediante la Detección del Ki'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Túnicas Cruzadas y Pecho con Rosario',
        pieces: [
          'P2.1 Túnica Monástica Cruzada de Lino Azafrán con un Hombro al Descubierto (Estilo Kasaya)',
          'P2.2 Chaleco Corto de Algodón de Artes Marciales con Botones de Nudo Chino',
          'P2.3 Gran Rosario de Cuentas de Madera Gigantes Llevado al Cuello',
          'P2.4 Torso Musculado Descubierto con Tatuaje de Dragón / Tigre de Ki'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Manto Kasaya y Bastón a la Espalda',
        pieces: [
          'P3.1 Gran Manto Kasaya Rojo de Capas sobre la Túnica Azafrán',
          'P3.2 Soporte de Espalda de Cuerda para el Bastón Bo',
          'P3.3 Capa Corta de Paja de Arroz contra la Lluvia (Mino)'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Vendas de Puños y Anillos de Hierro',
        pieces: [
          'P4.1 Vendas de Lino Blanco Apretadas en Nudillos y Muñecas para Golpear Piedra',
          'P4.2 Anillos de Hierro de Entrenamiento en los Antebrazos (Iron Rings de Hung Gar)',
          'P4.3 Muñequeras de Cuero con Símbolos del Yin y el Yang'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Fajas de Artes Marciales',
        pieces: [
          'P5.1 Faja Ancha de Seda Negra o Roja Atada con Nudo Lateral de Maestro',
          'P5.2 Cordón de Algodón con Calabaza de Agua / Licor Medicinal',
          'P5.3 Tahalí para Nunchakus de Madera Noble'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalones Holgados con Polainas',
        pieces: [
          'P6.1 Pantalones de Seda o Algodón Holgados con Gran Libertad para Patadas Altas',
          'P6.2 Polainas de Tela Blanca Ajustadas con Cintas Cruzadas Negras en Pantorrillas',
          'P6.3 Calzas de Lino con Refuerzos en Rodillas para Meditación en Flor de Loto'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Zapatillas de Kung-Fu y Sandalias Waraji',
        pieces: [
          'P7.1 Zapatillas de Kung-Fu de Tela Negra con Suela de Goma Flexible o Cuerda',
          'P7.2 Sandalias de Paja de Arroz con Calcetines Tabi Blancos',
          'P7.3 Pies Descalzos con Vendas en Empeines y Tobillos'
        ]
      }
    ],
    materials: ['Lino puro de azafrán o blanco', 'Seda cruda ligera', 'Madera de roble blanco y bambú', 'Cuentas de madera de sándalo', 'Cuerdas de cáñamo y algodón'],
    finishes: ['Lino austero impoluto', 'Madera de bastón pulida por el sudor y uso', 'Vendas blancas limpias', 'Hierro forjado en anillos'],
    armorDefenses: [
      { id: 'AR-UNARMORED-KI', name: 'Defensa de Ki sin Armadura', desc: 'La energía interna desvía impactos y proyectiles otorgando agilidad sobrehumana' },
      { id: 'AR-DIAMOND-BODY', name: 'Cuerpo de Diamante Monástico', desc: 'Inmunidad a venenos, enfermedades y resistencia a caídas desde grandes alturas' }
    ],
    weapons: [
      'Bastón Bo de Madera de Roble Blanco de 1.80m con Conteras de Bronce',
      'Par de Nunchakus de Madera de Ébano Unidos por Cadena de Acero',
      'Bastón con Anillos de Monje Budista (Khakkhara) que Repica al Andar',
      'Par de Tonfas de Madera con Mango Perpendicular',
      'Espadas Mariposa Gemelas de Kung Fu para Combate Rápido'
    ],
    relicsAndItems: [
      'Rosario de Cuentas de Madera de Sándalo Sagrado con 108 Cuentas',
      'Calabaza de Bambú para Agua de Manantial Bendecida',
      'Cuenco de Limosnas de Bronce de Monje Mendicante',
      'Pergamino con los Principios del Flujo de Energía Ki'
    ],
    bags: [
      'Morral de Tela Cruzado al Pecho para Raciones de Arroz y Cuenco',
      'Funda de Lona para el Bastón Bo',
      'Bolsa Kinchaku de Seda para Guardar Cuentas de Oración',
      'Fajín de Transporte Enrollado a la Cintura'
    ],
    equipmentFinishes: [
      'Madera de roble pulida al aceite con textura sedosa y firme',
      'Bronce sonoro con tono dorado envejecido en el bastón khakkhara',
      'Algodón blanco y azafrán con tinte vegetal tradicional',
      'Cuentas de sándalo oscuro aromáticas'
    ],
    suggestedColors: [
      { id: 'naranja_azafran', name: 'Naranja Azafrán / Monje', hex: '#EA580C' },
      { id: 'rojo_kasaya', name: 'Rojo Kasaya / Sagrado', hex: '#991B1B' },
      { id: 'blanco_lino_monje', name: 'Blanco Lino / Pureza', hex: '#F8FAFC' },
      { id: 'negro_faja', name: 'Negro Cinturón / Faja', hex: '#18181B' }
    ],
    suggestedWardrobeDetails: ['Vendas blancas perfectamente cruzadas en puños y pantorrillas', 'Gran rosario de cuentas de madera colgando sobre el pecho', 'Bastón bo sostenido con firmeza y equilibrio perfecto', 'Sombrero kasa de paja proyectando sombra sobre la mirada serena'],
    styleNote: 'Disciplina marcial oriental austera, dominio del Ki, simplicidad monástica y fluidez física.'
  },

  'E7 Sacerdote de Templo': {
    roleName: 'E7 Sacerdote de Templo',
    category: 'Divino y Naturaleza',
    tagline: 'Rituales ancestrales de santuario, kimono ceremonial blanco y rojo Miko / Kannushi, vara gohei de papel sagrado y espejo de bronce',
    description: 'Sacerdote o sacerdotisa sintoísta / de templo oriental. Viste kimono ceremonial de colores sagrados (blanco y rojo carmesí), corona con flores, vara gohei y espejo sagrado.',
    recommendedOutfitType: 'O-SHINTO Atuendo Ceremonial de Templo Shinto (Kosode Blanco y Hakama Escarlata Miko)',
    outfitTypes: [
      { id: 'O-SHINTO-MIKO', name: 'O-SHINTO-MIKO Vestimenta de Miko Tradicional con Kosode Blanco, Hakama Roja y Gohei' },
      { id: 'O-SHINTO-KANNUSHI', name: 'O-SHINTO-KANNUSHI Túnica de Kannushi Blanca y Turquesa con Sombrero Eboshi y Shaku' },
      { id: 'O-SHINTO-FESTIVAL', name: 'O-SHINTO-FESTIVAL Traje de Danza Kagura con Máscara de Zorro Kitsune y Cascabeles' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Máscaras Kitsune y Tocados de Flores',
        pieces: [
          'P1.1 Máscara de Zorro Kitsune de Madera Laqueada en Blanco y Rojo con Ojos Rasgados',
          'P1.2 Tocado de Flores de Ciruelo y Cintas de Papel Shide Sagrado',
          'P1.3 Sombrero Eboshi Alto de Seda Negra Laqueada de Sacerdote Kannushi',
          'P1.4 Horquillas Kanzashi con Campanas de Plata Tintineantes'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Kosode Blanco y Chaquetas Ceremoniales',
        pieces: [
          'P2.1 Kosode (Kimono Blanco Puro de Seda) con Cuello Cruzado y Mangas Anchas',
          'P2.2 Chaqueta Ceremonial Haori de Seda Translúcida con Bordados de Grullas',
          'P2.3 Suzu-Obi (Cinturón con Cascabeles Sagrados)',
          'P2.4 Jubón Ceremonial Imperial con Mangas Abullonadas y Cordones Rojos'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Cintas Shimenawa y Mantos Flotantes',
        pieces: [
          'P3.1 Cuerda Sagrada Shimenawa de Paja de Arroz con Papeles Shide en Zigzag',
          'P3.2 Manto de Danza Kagura de Seda Translúcida con Flecos de Oro',
          'P3.3 Gran Lazo Rojo Trasero Sujetando la Hakama'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Mangas Amplias de Miko y Cintas',
        pieces: [
          'P4.1 Mangas Gigantes de Kimono Kosode Blancas que Ondulan con el Viento',
          'P4.2 Cintas Rojas de Seda (Tasuki) Cruzadas para Recoger las Mangas al Realizar Rituales',
          'P4.3 Pulseras de Cuentas de Jade Magatama en las Muñecas'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Hakama y Cintas Sagradas',
        pieces: [
          'P5.1 Hakama (Pantalón-Falda Plisada de Color Rojo Carmesí Brillante)',
          'P5.2 Cintas Rojas Atadas a la Cintura con Nudos Ceremoniales Mizuhiki',
          'P5.3 Faja de Brocado Dorado con Soporte para Espejo y Talismanes'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pliegues de Hakama Escarlata',
        pieces: [
          'P6.1 Pliegues Esculturales de la Hakama Roja que Llegan hasta los Tobillos',
          'P6.2 Falda Ceremonial de Capas de Seda Blanca y Carmesí',
          'P6.3 Calzas Blancas Tabi de Seda Suave'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Calcetines Tabi y Sandalias Zori',
        pieces: [
          'P7.1 Sandalias Zori de Cuero Rojo y Suela de Paja con Tiras Blancas',
          'P7.2 Zapatos Asagutsu de Madera Laqueada en Negro de Alto Sacerdote',
          'P7.3 Calcetines Tabi de Algodón Blanco Puro con Cierre de Botón'
        ]
      }
    ],
    materials: ['Seda blanca pura japonesa (Habotai)', 'Paño de lino carmesí brillante', 'Papel Washi sagrado doblado a mano', 'Paja de arroz bendecida para cuerdas shimenawa', 'Madera de ciprés hinoki y laca urushi'],
    finishes: ['Blanco puro inmaculado y rojo carmesí vivo', 'Papel washi crujiente y rígido', 'Laca negra brillante en madera', 'Cascabeles con sonido puro y cristalino'],
    armorDefenses: [
      { id: 'AR-SHINTO-PURITY', name: 'Pureza del Santuario Sagrado', desc: 'Disipa maldiciones, venenos y purifica instantáneamente la corrupción espiritual' },
      { id: 'AR-KAMI-PROTECTION', name: 'Protección de los Espíritus Kami', desc: 'Un escudo de viento divino y pétalos de cerezo intercepta ataques a distancia' }
    ],
    weapons: [
      'Vara Gohei / Haraegushi de Madera de Hinoki con Serpentinas de Papel Blanco Shide',
      'Vara de Cascabeles Kagura Suzu de Tres Niveles para la Danza Sagrada',
      'Arco Ceremonial Sagrado (Hama Yumi) para Disipar Demonios con Flechas de Pluma Blanca',
      'Katana Ceremonial Sagrada con Vaina de Laca Blanca y Pomo de Flor de Loto',
      'Abanico Ceremonial Plegable de Papel Dorado con Dibujo de Sol Naciente'
    ],
    relicsAndItems: [
      'Espejo Sagrado de Bronce Pulido (Yata no Kagami) que Revela Espíritus Invisibles',
      'Joya Sagrada Magatama de Jade Verde en Forma de Coma Curva',
      'Talismanes de Papel Ofuda Escritos con Tinta Negra de Cinabrio',
      'Frasco de Sake Sagrado Consagrado a los Kami del Templo'
    ],
    bags: [
      'Cofrecito de Madera de Hinoki con Cierre de Seda para Talismanes Ofuda',
      'Bolsa Kinchaku de Seda Roja Bordada con Flores de Cerezo',
      'Funda de Seda Acolchada para la Vara Kagura Suzu',
      'Carcaj Yebira Ceremonial Lacado en Blanco para Flechas Hama Yumi'
    ],
    equipmentFinishes: [
      'Madera de ciprés hinoki claro con aroma sagrado natural',
      'Papel washi blanco inmaculado doblado en pliegues geométricos shide',
      'Bronce pulido a espejo con reflejos dorados cálidos',
      'Cintas ceremoniales mizuhiki en rojo y blanco con nudos de bendición'
    ],
    suggestedColors: [
      { id: 'rojo_miko', name: 'Rojo Carmesí Shinto / Hakama', hex: '#DC2626' },
      { id: 'blanco_kosode', name: 'Blanco Nieve Shinto / Kosode', hex: '#FFFFFF' },
      { id: 'dorado_shinto', name: 'Dorado Ceremonial / Sol', hex: '#F59E0B' },
      { id: 'verde_jade_magatama', name: 'Verde Jade / Magatama', hex: '#059669' }
    ],
    suggestedWardrobeDetails: ['Kosode blanco inmaculado contrastando con la hakama roja brillante', 'Vara gohei con papeles shide ondeando en el ritual de purificación', 'Máscara kitsune colocada al costado de la cabeza con cintas rojas', 'Cascabeles kagura suzu emitiendo un repique sagrado al moverse'],
    styleNote: 'Pureza sintoísta japonesa tradicional, contraste estricto blanco y rojo, papeles sagrados shide y devoción a los Kami.'
  }
};
