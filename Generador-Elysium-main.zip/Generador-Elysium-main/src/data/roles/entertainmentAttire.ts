import { RoleAttireConfig } from './types';

export const ENTERTAINMENT_ROLES: Record<string, RoleAttireConfig> = {
  'Ent1 Bailarín/a Exótico/a': {
    roleName: 'Ent1 Bailarín/a Exótico/a',
    category: 'Entretenimiento y Arte',
    tagline: 'Sensualidad coreográfica, velos de seda translúcida, cadenas de vientre, monedas tintineantes y cimitarras de danza',
    description: 'Atuendo oriental y escénico de danza de vientre y harén. Diseñado para cautivar mediante transparencias, cadencia rítmica de monedas y joyería corporal.',
    recommendedOutfitType: 'O-DANCE Traje de Danza Oriental (Top bralette enjoyado, falda abierta de gasa y velos)',
    outfitTypes: [
      { id: 'O-DANCE-BELLY', name: 'O-DANCE-BELLY Danza del Vientre Clásica con Cadenas de Monedas y Falda Abierta' },
      { id: 'O-DANCE-SWORD', name: 'O-DANCE-SWORD Danza de Espadas de Harén con Pantalón Bombacho y Top de Seda' },
      { id: 'O-DANCE-TEMPLE', name: 'O-DANCE-TEMPLE Bailarina Sagrada de Templo con Joyas de Oro y Velos Celestiales' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Velos y Tiaras Orientales',
        pieces: [
          'P1.1 Velo Facial de Gasa Translúcida con Cadena de Perlas',
          'P1.2 Tiara de Monedas Doradas Colgantes sobre la Frente',
          'P1.3 Tocado de Plumas de Pavo Real y Pedrería Brillante',
          'P1.4 Cadena de Nariz a Oreja con Gemas Talladas',
          'P1.5 Gargantilla de Filigrana de Oro con Colgantes de Rubí'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Tops Bralette Enjoyados y Corpiños',
        pieces: [
          'P2.1 Top Bralette de Seda Forrado en Monedas Tintineantes y Flecos de Perlas',
          'P2.2 Corpiño Escotado de Terciopelo con Bordados de Hilo de Oro',
          'P2.3 Top de Cuello Halter Cruzado en Gasa Semitransparente',
          'P2.4 Pechera Malla de Cadena Dorada Suelta sobre Piel Descubierta',
          'P2.5 Bolero Corto de Manga Larga Acampanada de Gasa con Abertura Frontal'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Velos de Seda Flotantes y Mantos',
        pieces: [
          'P3.1 Gran Velo de Seda Translúcido Ondulante Sujeto a Muñecas',
          'P3.2 Capa Corta de Plumas Escarlatas y Doradas',
          'P3.3 Manto Ligero de Gasa con Lentejuelas de Luz',
          'P3.4 Alas de Isis Plisadas de Seda Dorada Refractaria'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Manguitos Flotantes y Brazaletes de Serpiente',
        pieces: [
          'P4.1 Brazaletes de Bíceps Rígidos en Forma de Serpiente Enjoyada',
          'P4.2 Manguitos de Gasa Abullonados Flotantes con Cinta Dorada',
          'P4.3 Pulseras de Muñeca con Crótalos Sonoros de Bronce',
          'P4.4 Guantes de Red de Hilo Dorado sin Dedos'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturones de Monedas y Cadenas de Cadera',
        pieces: [
          'P5.1 Cinturón Ancho de Danza con Múltiples Hileras de Monedas Sonoras',
          'P5.2 Cadena de Vientre de Eslabones Finos con Gema en el Ombligo',
          'P5.3 Fajín de Seda Oriental Anudado Lateralmente con Borlas Largas',
          'P5.4 Cinto de Terciopelo con Broche de Sol Radiante y Pedrería'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Faldas de Gasa con Abertura y Bombachos',
        pieces: [
          'P6.1 Falda de Gasa Plisada de Dos Capas con Abertura Lateral Alta al Muslo',
          'P6.2 Pantalón Bombacho Translúcido de Seda con Aberturas Laterales',
          'P6.3 Sobrefalda Corta de Cuentas y Monedas sobre Culotte de Seda',
          'P6.4 Falda de Vuelo Circular de Seda Degradada en Colores Vivos'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Tobilleras con Cascabeles y Sandalias',
        pieces: [
          'P7.1 Tobilleras de Oro con Cascabeles Tintineantes en Pies Descalzos',
          'P7.2 Sandalias Mínimas de Suela Fina con Tiras de Cuero y Oro al Tobillo',
          'P7.3 Joyas de Empeine de Cadenas Finas Conectadas al Dedo del Pie',
          'P7.4 Babuchas de Seda con Punta Levantada y Bordado Floral'
        ]
      }
    ],
    materials: ['Seda de morera translúcida', 'Gasa de chifón flotante', 'Terciopelo de seda suave', 'Latón y oro batido para monedas', 'Perlas naturales y cuentas de vidrio'],
    finishes: ['Translúcido etéreo con caída suave', 'Brillo metálico tintineante', 'Lentejuelas reflectantes de luz', 'Filigrana de oro en joyas corporales'],
    armorDefenses: [
      { id: 'Ninguna', name: 'Ninguna / Piel Descubierta y Agilidad', desc: 'Máxima ligereza física para realizar giros y acrobacias' },
      { id: 'AR-DANCE-VEIL', name: 'Velo de Evasión Etérea Mágica', desc: 'Encantamiento que distorsiona la silueta y desvía ataques con ilusiones' },
      { id: 'AR-SILK-SHIELD', name: 'Seda Protectora Reforzada con Éter', desc: 'Hebras mágicas invisibles que amortiguan impactos cortantes leves' }
    ],
    weapons: [
      'Cimitarras Gemelas de Danza con Hojas Onduladas y Pomos Enjoyados',
      'Abanicos de Guerra con Varillas de Acero Afilado y Seda Carmesí',
      'Daga Corta Enjoyada de Vientre con Vaina de Filigrana',
      'Cintas de Seda Ponderadas con Plomo para Látigo Danzante',
      'Látigo Enjoyado de Seda con Filamentos Cortantes'
    ],
    relicsAndItems: [
      'Crótalos / Zills de Bronce Sonoros para los Dedos',
      'Frasco de Aceite Perfumado Embriagador de Jazmín y Ambar',
      'Velo de Repuesto con Perlas y Lentejuelas del Harén Real',
      'Espejo de Mano de Plata Labrada con Marco de Jade',
      'Joyero Portátil de Pedrería, Kohol y Cosméticos'
    ],
    bags: [
      'Limosnera de Seda Bordada con Borlas de Oro',
      'Bolsa de Terciopelo Púrpura para Joyas y Monedas de Propinas',
      'Cofrecito Portátil de Ungüentos y Perfumes Orientales',
      'Funda Enjoyada Forrada de Seda para Cimitarras Gemelas'
    ],
    equipmentFinishes: [
      'Oro brillante pulido con incrustaciones de rubíes y zafiros',
      'Bronce sonoro con tono dorado cálido',
      'Acero de damasco pulido espejo en hojas de danza',
      'Seda teñida a mano con degradado de colores solares'
    ],
    suggestedColors: [
      { id: 'dorado_solar', name: 'Dorado Solar / Ámbar', hex: '#F59E0B' },
      { id: 'rosa_fucsia', name: 'Rosa Fucsia / Neón', hex: '#EC4899' },
      { id: 'purpura_amatista', name: 'Púrpura Amatista / Harén', hex: '#7C3AED' },
      { id: 'rojo_rubi', name: 'Rojo Rubí / Carmesí', hex: '#DC2626' },
      { id: 'azul_noche', name: 'Azul Noche / Zafiro', hex: '#1E3A8A' }
    ],
    suggestedWardrobeDetails: ['Monedas tintineantes en bordes de top y cinturón', 'Transparencias de gasa con dobladillo dorado', 'Bordados en hilo de oro brillante', 'Flecos de perlas y cuentas que se mueven al girar'],
    styleNote: 'Sensualidad coreográfica, telas semitransparentes fluidas, monedas tintineantes y joyas corporales vibrantes.'
  },

  'Ent2 Músico Callejero': {
    roleName: 'Ent2 Músico Callejero',
    category: 'Entretenimiento y Arte',
    tagline: 'Melodías errantes, laúd gastado, capas de colores vivos, sombrero con pluma y estuche de partituras',
    description: 'Bardo bohemio o trovador de tabernas y plazas. Viste ropajes coloridos, boinas con plumas y porta instrumentos de cuerda o viento.',
    recommendedOutfitType: 'O-MINSTREL Jubón Bicolor con Mangas Acuchilladas y Capa Corta de Trovador',
    outfitTypes: [
      { id: 'O-MINSTREL-BOHEMIAN', name: 'O-MINSTREL-BOHEMIAN Jubón Desabrochado con Camisa Holgada y Laúd' },
      { id: 'O-MINSTREL-COURT', name: 'O-MINSTREL-COURT Traje de Músico de Corte con Medias Bicolores y Rapsodia' },
      { id: 'O-MINSTREL-WANDER', name: 'O-MINSTREL-WANDER Capa de Viajero con Instrumento a la Espalda' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Boinas con Pluma y Bandanas',
        pieces: [
          'P1.1 Boina Bohemia con Gran Pluma de Faisán Coloreada',
          'P1.2 Sombrero de Ala Ancha Doblada con Broche de Clave Musical',
          'P1.3 Bandana de Seda Estampada Anudada al Costado',
          'P1.4 Cinta de Cuero con Cascabel Discreto'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Jubones y Camisas de Trovador',
        pieces: [
          'P2.1 Jubón Bicolor con Mangas Acuchilladas que Dejan Ver el Forro',
          'P2.2 Camisa de Poeta con Cuello Desbocado y Cordones Cruzados',
          'P2.3 Chaleco de Terciopelo Verde con Bordados de Notas Musicales',
          'P2.4 Blusón Bohemio con Cuello Fruncido y Vuelo Romántico'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Capas Terciadas y Correas de Instrumento',
        pieces: [
          'P3.1 Capa Corta Terciada sobre un Solo Hombro con Broche de Arpa',
          'P3.2 Manto de Viaje con Forro de Cuadros Tartán',
          'P3.3 Arnés de Espalda Acolchado para Portar el Laúd o Violín'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Mangas Abullonadas y Cintas',
        pieces: [
          'P4.1 Mangas Abullonadas Divididas con Cintas de Raso',
          'P4.2 Mitones de Cuero Fino para Tocar Instrumentos sin Resbalar',
          'P4.3 Pulseras de Cuerdas de Instrumento Trenzadas con Abalorios'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Fajas y Tahalíes Musicales',
        pieces: [
          'P5.1 Faja de Seda Brillante Anudada con Flecos Largos',
          'P5.2 Cinturón de Cuero con Funda para Flauta de Pan y Plectros',
          'P5.3 Tahalí con Soporte para Diapasón y Partituras Enrolladas'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Calzas Bicolores y Bombachos',
        pieces: [
          'P6.1 Calzas Ajustadas con Piernas en Colores Contrastantes',
          'P6.2 Bombachos de Rayas Verticales con Pliegues Suaves',
          'P6.3 Pantalones Bohemios Cómodos con Ajuste en Tobillo'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Botas de Bucanero y Zapatos de Baile',
        pieces: [
          'P7.1 Botas de Caña Vuelta de Cuero Flexible con Hebilla',
          'P7.2 Zapatos de Baile Ligeros con Suela de Cuero Suave',
          'P7.3 Botines con Cascabeles en las Punteras'
        ]
      }
    ],
    materials: ['Terciopelo de algodón brillante', 'Lino fino de poeta', 'Paño de lana peinada', 'Cuero suave de becerro', 'Seda multicolor'],
    finishes: ['Colores vivos con contraste', 'Acuchillado decorativo', 'Bordados en hilo metálico', 'Madera barnizada acústica'],
    armorDefenses: [
      { id: 'Ninguna', name: 'Ninguna / Sin Armadura', desc: 'Libertad de movimiento total para cantar e interpretar' },
      { id: 'AR-SONIC-WARD', name: 'Amuleto de Resonancia Acústica', desc: 'Genera una vibración armónica que desvía flechas y golpes directos' }
    ],
    weapons: [
      'Laúd de Batalla con Caja Reforzada en Bronce y Cuchilla Oculta',
      'Estoque Fino con Guarda en Forma de Clave de Sol',
      'Flauta Travesera de Acero Macizo Usada como Porra o Cerbatana',
      'Daga de Trovador con Vaina Decorada con Claves Musicales'
    ],
    relicsAndItems: [
      'Diapasón Mágico de Resonancia Sonora Purificadora',
      'Libro de Baladas y Cancionero con Tapas de Cuero Repujado',
      'Sombrero con Monedas de Aplausos y Monedas de Oro de Propinas',
      'Juego de Cuerdas de Seda de Hada de Repuesto'
    ],
    bags: [
      'Estuche Rígido de Madera y Cuero Acolchado para Instrumentos',
      'Morral Bohemio de Tapiz Multicolor para Partituras',
      'Limosnera de Terciopelo para Recaudar Monedas del Público',
      'Funda de Cuero para Flautas y Plectros de Concha'
    ],
    equipmentFinishes: [
      'Madera de abeto y arce con barniz dorado de luthier',
      'Latón pulido brillante en llaves e instrumentos de viento',
      'Cuero color coñac con pespuntes en contraste',
      'Incrustaciones de nácar en el diapasón y la roseta'
    ],
    suggestedColors: [
      { id: 'verde_bosque', name: 'Verde Bosque / Trovador', hex: '#15803D' },
      { id: 'amarillo_azafran', name: 'Amarillo Azafrán / Oro', hex: '#EAB308' },
      { id: 'rojo_vino', name: 'Rojo Vino / Bohemio', hex: '#991B1B' },
      { id: 'azul_turquesa', name: 'Azul Turquesa / Rapsodia', hex: '#06B6D4' }
    ],
    suggestedWardrobeDetails: ['Mangas acuchilladas con forro de seda contrastante', 'Plumas largas y curvadas en el sombrero', 'Botones dorados en hilera oblicua', 'Cintas de colores flotando al compás de la música'],
    styleNote: 'Bohemio vivaz, contrastes cromáticos alegres, romanticismo lírico y accesorios de luthier.'
  },

  'Ent3 Cortesano/a': {
    roleName: 'Ent3 Cortesano/a',
    category: 'Entretenimiento y Arte',
    tagline: 'Seducción palaciega, vestidos de corsetería victoriana o sedas orientales, abanicos de plumas y perfumes caros',
    description: 'Figura de alta sociedad cortesana, experta en diplomacia de alcoba, intrigas palaciegas y fascinación estética.',
    recommendedOutfitType: 'O-COURTESAN Vestido de Gala Corsetero con Escote Corazón y Falda de Sirena',
    outfitTypes: [
      { id: 'O-COURTESAN-GALA', name: 'O-COURTESAN-GALA Vestido de Gala Corsetero de Terciopelo y Encaje' },
      { id: 'O-COURTESAN-KIMONO', name: 'O-COURTESAN-KIMONO Oiran / Kimono Imperial de Capas de Seda Suntuosas' },
      { id: 'O-COURTESAN-BOUDOIR', name: 'O-COURTESAN-BOUDOIR Négligée de Seda y Encaje Francés con Liguero' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Tocados de Joyas y Máscaras Venecianas',
        pieces: [
          'P1.1 Antifaz Veneciano de Filigrana de Oro con Cristales Swarovski',
          'P1.2 Tiara de Platino con Lágrimas de Zafiro y Diamantes',
          'P1.3 Tocado de Plumas de Avestruz y Broche de Perlas',
          'P1.4 Peinetas de Marfil y Horquillas Kanzashi Enjoyadas'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Corsés de Alta Costura y Escotes Pronunciados',
        pieces: [
          'P2.1 Corsé Reductor de Raso de Seda con Varillas de Acero y Escote Corazón',
          'P2.2 Vestido de Gala de Terciopelo con Abertura Frontal Profunda',
          'P2.3 Kimono de Seda de Doce Capas (Juni-hitoe) con Cuello Cruzado Revelador',
          'P2.4 Bralette de Encaje Francés Bordado en Hilo de Oro'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Estolas de Piel y Capas de Cola Larga',
        pieces: [
          'P3.1 Estola de Armiño Blanco Sujeta con Broche de Diamante',
          'P3.2 Capa de Terciopelo con Gran Cola Arrastrando por el Suelo',
          'P3.3 Chal de Gasa Translúcida con Destellos Plateados'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Guantes de Ópera y Brazaletes de Diamantes',
        pieces: [
          'P4.1 Guantes Largos de Ópera de Satén de Seda hasta el Bíceps',
          'P4.2 Brazalete de Diamantes y Rubíes en la Muñeca',
          'P4.3 Manguitos de Encaje Negro con Cintas de Terciopelo'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Lazos Obi de Brocado y Cadenas de Joyas',
        pieces: [
          'P5.1 Gran Lazo Obi Frontal de Brocado de Oro (Estilo Oiran)',
          'P5.2 Cinturón Corsetero con Ajuste de Cordón de Seda Posterior',
          'P5.3 Cadena de Caderas con Colgantes de Perlas Naturales'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Faldas de Sirena y Medias de Seda',
        pieces: [
          'P6.1 Falda Estilo Sirena Ceñida con Abertura Lateral hasta el Muslo',
          'P6.2 Falda con Mirinaque y Múltiples Capas de Enagua de Encaje',
          'P6.3 Medias de Seda con Costura Posterior y Ligueros Enjoyados'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Zapatos de Tacón Enjoyados y Geta Laqueadas',
        pieces: [
          'P7.1 Zapatos de Tacón de Aguja Forrados en Raso con Broche de Cristal',
          'P7.2 Zancos Geta Laqueados en Negro y Oro de Alta Cortesana',
          'P7.3 Sandalias de Tiras de Oro con Pedrería en el Empeine'
        ]
      }
    ],
    materials: ['Seda salvaje de alta costura', 'Terciopelo de seda devoré', 'Encaje de Chantilly', 'Brocado imperial japonés', 'Pieles selectas'],
    finishes: ['Satinado de lujo brillante', 'Devoré transparente con texturas', 'Bordados en pan de oro y plata', 'Laqueado espejo'],
    armorDefenses: [
      { id: 'Ninguna', name: 'Ninguna / Sin Armadura', desc: 'Atuendo consagrado al encanto visual y la seducción' },
      { id: 'AR-SEDUCTION-CHARM', name: 'Encantamiento de Fascinación Inmune', desc: 'Aura mágica que desvía intenciones hostiles y reduce el daño de agresores' }
    ],
    weapons: [
      'Abanico Plegable de Plumas con Varillas de Acero Afiladas como Navajas',
      'Horquilla Kanzashi de Oro con Punta Envenenada Oculta',
      'Estilete de Diamantes Escondido en el Escote del Corsé',
      'Frasco de Veneno de Acción Lenta Disfrazado de Perfume'
    ],
    relicsAndItems: [
      'Abanico de Plumas de Marabú con Mango de Nácar',
      'Frasco de Cristal Tallado de Perfume de Orquídea Negra',
      'Cajita de Música de Oro Esmaltada con Bailarina Mecánica',
      'Libreta Secreta con Secretos Inconfesables de los Nobles de la Corte'
    ],
    bags: [
      'Bolso de Mano de Terciopelo Bordado con Cierre de Oro y Joyas',
      'Limosnera de Seda con Forro Antihumedad para Venenos',
      'Cofrecito de Maquillaje y Joyas de Madera de Sándalo',
      'Funda de Seda Acolchada para Abanicos de Combate'
    ],
    equipmentFinishes: [
      'Oro pulido espejo con pavé de diamantes y rubíes',
      'Nácar iridiscente con reflejos tornasolados',
      'Cristal de Baccarat tallado a mano',
      'Madera de sándalo aromatizada con incrustaciones de plata'
    ],
    suggestedColors: [
      { id: 'rojo_pasion', name: 'Rojo Carmesí / Pasión', hex: '#BE123C' },
      { id: 'negro_onice', name: 'Negro Ónice / Seducción', hex: '#0F172A' },
      { id: 'dorado_champagne', name: 'Dorado Champagne / Lujo', hex: '#FDE047' },
      { id: 'rosa_empolvado', name: 'Rosa Empolvado / Boudoir', hex: '#F43F5E' }
    ],
    suggestedWardrobeDetails: ['Varillas de corsé visibles y moldeadoras', 'Encaje floral con transparencias estratégicas', 'Perlas y diamantes cayendo en cascada', 'Gran lazo posterior con caída majestuosa'],
    styleNote: 'Glamour de alta seducción, corsetería impecable, sedas suntuosas y armas sutiles de alcoba.'
  },

  'Ent4 Bufón / Arlequín': {
    roleName: 'Ent4 Bufón / Arlequín',
    category: 'Entretenimiento y Arte',
    tagline: 'Comedia burlona, indumentaria asimétrica en damero, cascabeles sonoros, gorgueras plisadas y cetro marotte',
    description: 'Atuendo festivo y satírico. Bicolor, cargado de contrastes geométricos, golas españolas, cascabeles y máscaras de la comedia del arte.',
    recommendedOutfitType: 'O-JESTER Traje Completo de Arlequín / Bufón (Damero bicolor, cascabeles y gorguera)',
    outfitTypes: [
      { id: 'O-JESTER-HARLEQUIN', name: 'O-JESTER-HARLEQUIN Traje de Damero Bicolor en Rombos con Cascabeles' },
      { id: 'O-JESTER-THEATER', name: 'O-JESTER-THEATER Atuendo Teatral de la Comedia del Arte con Máscara' },
      { id: 'O-JESTER-ACROBAT', name: 'O-JESTER-ACROBAT Malla Ajustada Bicolor Elástica de Acróbata Real' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Capirotes y Máscaras de Comedia',
        pieces: [
          'P1.1 Capirote de Bufón de Tres Puntas con Cascabeles Sonoros',
          'P1.2 Máscara de Comedia del Arte / Antifaz de Rombos Asimétrico',
          'P1.3 Sombrero de Dos Cuernos Bicolor con Campanillas de Latón',
          'P1.4 Corona de Cascabeles y Fieltro Festoneado'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Jubones Arlequín y Gorgueras',
        pieces: [
          'P2.1 Jubón Asimétrico en Damero / Rombos Bicolor (Rojo y Negro / Morado y Oro)',
          'P2.2 Gorguera Plisada de Cuello (Gola Española Almidonada)',
          'P2.3 Corsé Arlequín con Botones de Campanilla y Puntas Colgantes',
          'P2.4 Chaleco Festoneado con Cascabeles en Cada Pico'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Capas Festoneadas y Alas Bicolores',
        pieces: [
          'P3.1 Capa Corta Festoneada Bicolor con Terminación en Puntas',
          'P3.2 Capa de Rombos con Borlas Sonoras en los Extremos',
          'P3.3 Cuello Alado de Puntas Colgantes de Fieltro'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Mangas Abullonadas y Guantes Bicolores',
        pieces: [
          'P4.1 Mangas Abullonadas Divididas por Cintas en Colores Opuestos',
          'P4.2 Guantes Bicolores (Mano Derecha Blanca, Mano Izquierda Negra)',
          'P4.3 Muñequeras Festoneadas con Cascabeles en las Muñecas'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Fajas con Borlas y Tahalíes',
        pieces: [
          'P5.1 Cinturón con Bolsitas de Trucos, Barajas y Cascabeles',
          'P5.2 Faja Bicolor con Puntas Colgantes y Bolas de Latón',
          'P5.3 Tahalí para Cetro Marotte de Bufón'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Calzas Asimétricas y Bombachos',
        pieces: [
          'P6.1 Calzas Bicolores Asimétricas (Pierna Izquierda a Rayas, Derecha a Rombos)',
          'P6.2 Bombachos Cortos con Pliegues y Rombos de Colores',
          'P6.3 Medias de Arlequín con Costura de Cascabeles Laterales'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Zapatos de Bufón con Punta Enrollada',
        pieces: [
          'P7.1 Zapatos de Puntas Enrolladas con Cascabeles en las Puntas',
          'P7.2 Zapatillas de Acróbata Flexibles de Cuero Bicolor',
          'P7.3 Botines Festoneados con Campanillas en los Tobillos'
        ]
      }
    ],
    materials: ['Fieltro de lana flexible', 'Raso de seda estampado en rombos', 'Algodón almidonado para golas', 'Latón pulido para cascabeles', 'Cuero teñido en colores vivos'],
    finishes: ['Damero geométrico nítido', 'Almidonado rígido en gorgueras', 'Cascabeles con repique cristalino', 'Contraste cromático saturado'],
    armorDefenses: [
      { id: 'Ninguna', name: 'Ninguna / Sin Armadura', desc: 'Acrobacias y evasión cómica como única salvaguarda' },
      { id: 'AR-TRICKSTER-CLOAK', name: 'Manto de Truco y Distracción', desc: 'Crea imágenes reflejadas que desconciertan a los atacantes' }
    ],
    weapons: [
      'Cetro Marotte de Bufón con Cabeza Parlante y Cuchilla Retráctil',
      'Dagas Arrojadizas de Malabarista Equilibradas',
      'Bomba Cómica de Humo con Polvo Picante de Colores',
      'Maza Ligera con Cabeza de Gomaespuma Acorazada en Plomo',
      'Bastón Resorte Plegable para Salto Acrobático'
    ],
    relicsAndItems: [
      'Baraja de Cartas Mágicas de Ilusión y Azar',
      'Caja de Sorpresas Mecánica con Muelle y Muñeco Cómico',
      'Silbato de Tres Tonos para Convocar alboroto en la Corte',
      'Espejo Deformante de Bolsillo que Muestra Miedos Ocultos'
    ],
    bags: [
      'Bolsa Mágica de Trucos Inagotable con Estampado de Rombos',
      'Morral Festoneado con Cascabeles en las Solapas',
      'Limosnera de Arlequín con Compartimento Secreto para Naipes',
      'Funda de Fieltro Bicolor para el Cetro Marotte'
    ],
    equipmentFinishes: [
      'Esmaltado en damero brillante de alto contraste',
      'Latón dorado y pulido con sonido claro de campana',
      'Madera tallada pintada a mano con muecas grotescas',
      'Cuero acharolado en rojo y negro brillante'
    ],
    suggestedColors: [
      { id: 'rojo_bufon', name: 'Rojo Arlequín / Carmín', hex: '#DC2626' },
      { id: 'negro_azabache', name: 'Negro Azabache / Damero', hex: '#111827' },
      { id: 'amarillo_bufon', name: 'Amarillo Canario / Oro', hex: '#FACC15' },
      { id: 'purpura_comedia', name: 'Púrpura Comedia / Bufón', hex: '#9333EA' }
    ],
    suggestedWardrobeDetails: ['Estampado en rombos arlequín bicolor estricto', 'Cascabeles de latón cosidos en cada punta', 'Gorguera plisada en abanico circular', 'Puntas rizadas hacia arriba en el calzado'],
    styleNote: 'Ironía juglaresca, contrastes geométricos saturados, sonido de cascabeles y dinamismo acrobático.'
  },

  'Ent5 Ídolo / Cantante': {
    roleName: 'Ent5 Ídolo / Cantante',
    category: 'Entretenimiento y Arte',
    tagline: 'Espectáculo deslumbrante, brillos tornasolados, micrófono Enjoyado, corsetería pop y capas etéreas de escenario',
    description: 'Estrella de escenario y fenómeno musical. Viste prendas vibrantes con tejidos reflectantes, lentejuelas, pedrería y accesorios futuristas o de alta fantasía escénica.',
    recommendedOutfitType: 'O-IDOL Traje de Escenario Pop-Fantasy con Falda Voluminosa de Capas y Micrófono',
    outfitTypes: [
      { id: 'O-IDOL-STAGE', name: 'O-IDOL-STAGE Traje de Ídolo Pop con Falda de Tul Neón y Corsé de Cristales' },
      { id: 'O-IDOL-CYBER', name: 'O-IDOL-CYBER Atuendo Tecno-Pop con Luces LED y Auriculares Holográficos' },
      { id: 'O-IDOL-DIVA', name: 'O-IDOL-DIVA Vestido de Gran Diva con Cola de Plumas y Guantes Largos' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Auriculares de Micrófono y Diademas Pop',
        pieces: [
          'P1.1 Diadema de Ídolo con Orejeras de Cristal y Micrófono de Diadema',
          'P1.2 Tocado de Estrellas Holográficas con Purpurina en las Mejillas',
          'P1.3 Gran Lazo Escénico con Centro de Corazón Luminoso',
          'P1.4 Horquillas de Flores de Neón y Cristales Prisma'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Tops de Escenario y Corsés Brillantes',
        pieces: [
          'P2.1 Corsé Escénico Recubierto de Lentejuelas Reflectantes con Ribete Dorado',
          'P2.2 Top Holográfico con Mangas de Farol Desmontables',
          'P2.3 Chaqueta Corta de Estilo Pop-Militar con Hombreras de Flecos de Oro',
          'P2.4 Bralette de Cristales con Cuello Gargantilla Conectado'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Capas de Tul Flotantes y Alas de Luz',
        pieces: [
          'P3.1 Capa Corta de Tul Translúcido con Lentejuelas Flotantes',
          'P3.2 Alas Escénicas de Cristal Prisma que Refractan los Focos',
          'P3.3 Gran Lazo Trasero Gigante con Cintas Largas hasta el Suelo'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Manguitos Neón y Guantes de Diva',
        pieces: [
          'P4.1 Manguitos Fruncidos de Gasa Brillante con Cintas Elásticas',
          'P4.2 Guantes Cortos de Charol Neón con Pulseras de Cristales',
          'P4.3 Pulseras Luminosas con Sensor de Ritmo Musical'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturones con Dijes y Cadenas',
        pieces: [
          'P5.1 Cinturón Holográfico con Hebilla de Estrella de Cristal',
          'P5.2 Cadenas de Cadera con Dijes Colgantes de Notas Musicales y Corazones',
          'P5.3 Fajín de Raso Neón con Gran Broche Central'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Minifaldas de Volantes y Medias de Red',
        pieces: [
          'P6.1 Minifalda Voluminosa de Múltiples Capas de Tul con Luces Interiores',
          'P6.2 Falda Asimétrica Corta por Delante y con Cola de Gasa por Detrás',
          'P6.3 Medias por Encima de la Rodilla con Lazo de Satén y Brillo de Diamantes',
          'P6.4 Medias de Red Finas con Cristales Pegados a Mano'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Botas de Plataforma de Escenario',
        pieces: [
          'P7.1 Botas Altas de Plataforma de Charol Blanco con Cordones Rosas',
          'P7.2 Botines de Escenario con Luces en la Suela y Hebillas de Estrella',
          'P7.3 Zapatos Mary Jane con Tacón Ancho Brillante y Purpurina'
        ]
      }
    ],
    materials: ['Vinilo holográfico reflectante', 'Tul multicapa iridiscente', 'Lentejuelas termoselladas', 'Satén elástico de escenario', 'Charol brillante'],
    finishes: ['Reflejo prismático holográfico', 'Purpurina sellada', 'Acabado neón vibrante', 'Lentejuelas tornasoladas'],
    armorDefenses: [
      { id: 'Ninguna', name: 'Ninguna / Sin Armadura', desc: 'Foco total en la estética y coreografía de escenario' },
      { id: 'AR-SPOTLIGHT-BARRIER', name: 'Barrera de Resonancia Sonora', desc: 'El eco de la voz genera un escudo sonoro protector' }
    ],
    weapons: [
      'Micrófono de Pie con Base de Acero Capaz de Emitir Ondas de Choque',
      'Varita Mágica de Ídolo con Proyector de Rayos de Luz y Chispas',
      'Bastón de Escenario con Cristal Resonador de Notas Altas',
      'Dagas Acústicas Arrojadizas que Silban Notas Musicales al Volar'
    ],
    relicsAndItems: [
      'Auricular / Receptor In-Ear de Oro Rosa con Cristal de Cancelación de Ruido',
      'Barra de Luz / Lightstick Oficial con Cristal de Resonancia Mágica',
      'Frasco de Elixir de Cuerdas Vocales de Miel Celestial',
      'Medallón con Disco de Vinilo en Miniatura de su Primer Éxito'
    ],
    bags: [
      'Estuche Rígido Acolchado en Raso Rosa para Micrófonos Enjoyados',
      'Mochila Escénica Holográfica con Bolsillo para Diademas y Maquillaje',
      'Bolso en Forma de Corazón con Cadena de Oro',
      'Maleta de Vestuario con Ruedas y Compartimento de Calzado de Escenario'
    ],
    equipmentFinishes: [
      'Oro rosa con cristales Swarovski incrustados',
      'Holograma iridiscente con efecto arcoíris',
      'Esmalte rosa pastel y blanco perla brillante',
      'Cromo espejo plateado reflectante'
    ],
    suggestedColors: [
      { id: 'rosa_chicle', name: 'Rosa Chicle / Neón', hex: '#F43F5E' },
      { id: 'azul_cielo_holograma', name: 'Azul Celeste / Holográfico', hex: '#38BDF8' },
      { id: 'blanco_diamante', name: 'Blanco Diamante / Nácar', hex: '#FFFFFF' },
      { id: 'amarillo_estrella', name: 'Amarillo Pastel / Estrella', hex: '#FEF08A' }
    ],
    suggestedWardrobeDetails: ['Lentejuelas en degradado que brillan bajo los focos', 'Falda de tul con enaguas infladas', 'Hombreras con flecos dorados estilo militar pop', 'Lazos gigantes en la espalda y cabeza'],
    styleNote: 'Energía pop deslumbrante, contrastes pasteles y neón, brillo holográfico y accesorios de concierto.'
  },

  'Ent6 Actor / Actriz': {
    roleName: 'Ent6 Actor / Actriz',
    category: 'Entretenimiento y Arte',
    tagline: 'Metamorfosis teatral, máscaras de tragedia y comedia, trajes de época versátiles, capas dobles y capa de camerino',
    description: 'Intérprete dramático capaz de adoptar mil personalidades. Viste ropas teatrales de corte versátil con capas reversibles y accesorios de caracterización.',
    recommendedOutfitType: 'O-ACTOR Traje de Teatro Barroco con Capa Reversible y Máscaras Dobles',
    outfitTypes: [
      { id: 'O-ACTOR-DRAMA', name: 'O-ACTOR-DRAMA Vestuario de Tragedia Clásica con Toga Oscura y Corona de Laurel' },
      { id: 'O-ACTOR-BAROQUE', name: 'O-ACTOR-BAROQUE Traje Teatral Barroco con Jubón Recargado y Gorguera' },
      { id: 'O-ACTOR-CAMERINO', name: 'O-ACTOR-CAMERINO Bata de Camerino de Seda con Espejo y Maquillaje' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Máscaras de Teatro y Pelucas',
        pieces: [
          'P1.1 Máscaras Gemelas de Tragedia y Comedia Colgando al Cuello o Cintura',
          'P1.2 Peluca Barroca Blanca Rizada de Época',
          'P1.3 Corona de Laurel Dorado de Actor Laureado',
          'P1.4 Máscara Neutra Blanca de Expresión Maleable'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Jubones de Teatro y Vestidos Dramáticos',
        pieces: [
          'P2.1 Jubón Teatral con Apliques de Oro y Brocado de Escena',
          'P2.2 Camisa Dramática con Mangas de Encaje Extensas y Cuello Abierto',
          'P2.3 Corsé de Época Forrado en Terciopelo Escarlata',
          'P2.4 Túnica Dramática con Pliegues Esculturales de Tragedia Griega'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Capas Reversibles y Mantos Reales Falsos',
        pieces: [
          'P3.1 Gran Capa Reversible (Negro Tragedia por Fuera, Carmesí Rey por Dentro)',
          'P3.2 Manto de Armiño Teatral con Broches Dorados Falsos',
          'P3.3 Capa Volátil de Viento Escénico'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Puños de Encaje y Manoplas',
        pieces: [
          'P4.1 Puños Extensos de Encaje Plisado para Gestos Dramáticos',
          'P4.2 Guantes de Terciopelo con Anillos Falsos de Cristal Gigante',
          'P4.3 Brazaletes Escénicos de Imitación de Oro'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cintos con Libretos y Espadas de Atrezzo',
        pieces: [
          'P5.1 Cinturón de Cuero Labrado con Soporte para Libreto Teatral',
          'P5.2 Fajín Escarlata de Gran Caída para Pose Teatral',
          'P5.3 Tahalí para Estoque Teatral sin Filo'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Calzas de Época y Sobrefaldas',
        pieces: [
          'P6.1 Calzas de Paño Negro con Botones Dorados Laterales',
          'P6.2 Falda con Vuelo Dramático para Giros Escénicos',
          'P6.3 Pantalones de Época con Fuelle y Ribetes Plateados'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Coturnos y Zapatos de Escena',
        pieces: [
          'P7.1 Coturnos Clásicos de Suela Alta para Imponer Altura en Escena',
          'P7.2 Zapatos de Tacón de Época con Hebillas Gigantes de Cristal',
          'P7.3 Botines Flexibles de Mímica y Coreografía'
        ]
      }
    ],
    materials: ['Terciopelo teatral pesado', 'Brocado de atrezzo con hilo de oro falso', 'Encaje de algodón almidonado', 'Cuero flexible teñido', 'Madera tallada para máscaras'],
    finishes: ['Acabado escénico de alto contraste', 'Doble faz reversible', 'Bordados llamativos visibles desde lejos', 'Pátina de maquillaje teatral'],
    armorDefenses: [
      { id: 'Ninguna', name: 'Ninguna / Sin Armadura', desc: 'Ropaje escénico puramente dramático' },
      { id: 'AR-MIMIC-CLOTH', name: 'Tejido Mímico Camaleónico', desc: 'Permite alterar el color y apariencia de la ropa instantáneamente' }
    ],
    weapons: [
      'Estoque Teatral de Atrezzo con Cuchilla Oculta de Acero Real',
      'Daga de Truco con Hoja Retráctil de Escenario y Cápsula de Sangre Falsa',
      'Bastón de Mando Dramático con Pomo de Calavera Shakesperiana',
      'Abanico con Dardo Somnífero para Monólogos Trágicos'
    ],
    relicsAndItems: [
      'Máscara de la Comedia y la Tragedia Talladas en Madera Noble',
      'Libreto Teatral Original con Acotaciones Escritas en Sangre',
      'Calavera de Atrezzo para el Soliloquio de Hamlet',
      'Caja de Caracterización con Cera, Pelucas y Pinturas Faciales'
    ],
    bags: [
      'Baúl de Vestuario Teatral con Ruedas y Espejo Iluminado',
      'Portadocumentos de Cuero para Guiones y Contratos de Gira',
      'Bolsa de Terciopelo para Pelucas y Máscaras',
      'Morral de Atrezzo con Utilería de Mano'
    ],
    equipmentFinishes: [
      'Madera de tilo tallada con acabado encerado clásico',
      'Latón dorado y envejecido con efecto de oropel',
      'Cuero burdeos con grabados de motivos de comedia',
      'Papel pergamino amarillento con caligrafía teatral'
    ],
    suggestedColors: [
      { id: 'rojo_teatro', name: 'Rojo Telón / Carmesí', hex: '#991B1B' },
      { id: 'dorado_oropel', name: 'Dorado Oropel / Escena', hex: '#CA8A04' },
      { id: 'negro_dramatico', name: 'Negro Dramático / Sombras', hex: '#18181B' },
      { id: 'blanco_mascara', name: 'Blanco Yeso / Máscara', hex: '#F4F4F5' }
    ],
    suggestedWardrobeDetails: ['Capa con forro en contraste para revelar al abrir los brazos', 'Gorguera amplia que enmarca el rostro', 'Máscaras gemelas sujetas con cintas de raso', 'Pliegues de tela diseñados para acentuar el movimiento dramático'],
    styleNote: 'Dramatismo teatral barroco, metamorfosis escénica, máscaras de doble emoción y ropajes de alta presencia.'
  }
};
