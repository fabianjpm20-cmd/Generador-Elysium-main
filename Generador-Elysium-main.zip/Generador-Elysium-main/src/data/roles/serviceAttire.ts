import { RoleAttireConfig } from './types';

export const SERVICE_ROLES: Record<string, RoleAttireConfig> = {
  'A1 Maid de Mansión': {
    roleName: 'A1 Maid de Mansión',
    category: 'Servicio y Academia',
    tagline: 'Elegancia servil victoriana, cofias de encaje, delantales albos con volantes y plumero ceremonial',
    description: 'Atuendo clásico y pulcro de doncella de mansión noble. Destaca por el contraste de blanco y negro, lazos pulcros y ligueros o medias discretas.',
    recommendedOutfitType: 'O-MAID Traje de Maid Clásico Victoriano (Vestido negro, delantal blanco con volantes)',
    outfitTypes: [
      { id: 'O-MAID-CLASSIC', name: 'O-MAID-CLASSIC Traje de Maid Clásico Victoriano con Enagua' },
      { id: 'O-MAID-GOTHIC', name: 'O-MAID-GOTHIC Vestido de Doncella Gótica con Corsé y Cuello Alto' },
      { id: 'O-MAID-BATTLE', name: 'O-MAID-BATTLE Maid Táctica de Combate con Refuerzos Ocultos' },
      { id: 'O-MAID-SUMMER', name: 'O-MAID-SUMMER Maid de Salón Ligera con Mangas Cortas y Encaje Francés' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Cofias y Lazos',
        pieces: [
          'P1.1 Cofia de Encaje Blanco con Volantes y Lazos Laterales',
          'P1.2 Diadema de Maid con Lazo de Raso Negro',
          'P1.3 Tocado de Encaje Francés Plisado con Alfileres de Perla',
          'P1.4 Gargantilla de Terciopelo con Cascabel o Medallón',
          'P1.5 Lazo para Recoger el Pelo en Coleta Baja'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Vestidos y Corpiños de Servicio',
        pieces: [
          'P2.1 Vestido de Doncella con Cuello Peter Pan Blanco y Botones',
          'P2.2 Corpiño Ajustado con Ballenas y Ribete de Encaje',
          'P2.3 Blusa de Seda Blanca de Cuello Alto con Chorrera',
          'P2.4 Chaleco Negro Ceñido de Servicio con Tirantes Cruzados'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Capelinas y Lazos Posteriores',
        pieces: [
          'P3.1 Gran Lazo Posterior de Satén Blanco del Delantal',
          'P3.2 Capelina Corta de Terciopelo con Borde de Armiño Falso',
          'P3.3 Chal de Encaje Blanco sobre los Hombros'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Manguitos y Guantes',
        pieces: [
          'P4.1 Manguitos de Algodón Blanco con Volantes en la Muñeca',
          'P4.2 Guantes Cortos de Cabritilla Blanca Inmaculada',
          'P4.3 Mangas Abullonadas Desmontables con Cintas Negras',
          'P4.4 Muñequeras de Encaje Negro con Lazo de Satén'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Delantales con Volantes',
        pieces: [
          'P5.1 Delantal Blanco Albo con Tirantes de Volantes y Bolsillo Frontal',
          'P5.2 Cinturón de Cuero Fino para Manojo de Llaves de la Mansión',
          'P5.3 Corsé Bajo Pecho (Underbust) con Ribete de Encaje'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Faldas con Enagua y Medias',
        pieces: [
          'P6.1 Falda Acampanada Negra con Enagua de Tul y Encaje Asomando',
          'P6.2 Medias Blancas hasta el Muslo con Liga de Encaje',
          'P6.3 Medias Negras Opacas con Costura Posterior y Liguero',
          'P6.4 Falda Corta de Maid con Tablas Plisadas'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Zapatos Mary Jane y Botines',
        pieces: [
          'P7.1 Zapatos Mary Jane de Charol Negro con Hebilla Plateada',
          'P7.2 Botines Victorianos de Tacón Fino y Botones Laterales',
          'P7.3 Zapatos Planos Silenciosos para Tareas Domésticas'
        ]
      }
    ],
    materials: ['Algodón egipcio almidonado', 'Paño negro mate de alta densidad', 'Encaje de bolillos francés', 'Satén de seda', 'Charol brillante'],
    finishes: ['Almidonado inmaculado', 'Mate profundo sin brillos', 'Encaje calado transparente', 'Satinado suave en lazos'],
    armorDefenses: [
      { id: 'Ninguna', name: 'Ninguna / Sin Armadura', desc: 'Indumentaria doméstica pura y elegante' },
      { id: 'AR-KEVLAR-MAID', name: 'Forro Reforzado Antikukri bajo el Delantal', desc: 'Protección oculta para sirvientas de combate' }
    ],
    weapons: [
      'Plumero de Limpieza con Mango de Ébano y Aguja Oculta',
      'Cuchillo de Chef de Acero Damasco de Cocina de Mansión',
      'Bandeja de Plata Maciza Arrojadiza y Defensiva',
      'Tijeras de Sastre de Plata Afiladas como Dagas',
      'Pistola de Bolsillo de Perforación Oculta en la Liga'
    ],
    relicsAndItems: [
      'Manojo de Llaves Maestras de la Mansión en Argolla de Plata',
      'Juego de Té de Porcelana Fina Pintado a Mano',
      'Reloj de Bolsillo Colgante de Cuello de Doncella',
      'Frasco de Veneno Inodoro de Azúcar de Cristal',
      'Campanilla de Llamada de Plata Maciza'
    ],
    bags: [
      'Limosnera de Terciopelo con Cordón de Seda para Llaves',
      'Bolsillo Oculto Cosido en el Forro del Delantal',
      'Cesta de Picnic Forrada en Cuadros Vichy para Recados',
      'Maletín de Cubiertos de Plata y Cristal de Servicio'
    ],
    equipmentFinishes: [
      'Plata esterlina pulida a espejo sin pátina',
      'Ébano lacado en brillo piano',
      'Porcelana esmaltada con ribete de pan de oro',
      'Acero quirúrgico reluciente y esterilizado'
    ],
    suggestedColors: [
      { id: 'negro_azabache', name: 'Negro Azabache / Noche', hex: '#0D0D0D' },
      { id: 'blanco_albo', name: 'Blanco Albo / Nieve', hex: '#FFFFFF' },
      { id: 'burdeos_noble', name: 'Rojo Burdeos Mansión', hex: '#58111A' },
      { id: 'azul_marino_servicio', name: 'Azul Marino Servicio', hex: '#111D4A' }
    ],
    suggestedWardrobeDetails: ['Volantes almidonados de 3 niveles', 'Lazos de satén brillante en cuello y delantal', 'Botones de nácar pulido', 'Dobladillo con encaje de flores'],
    styleNote: 'Pulcritud extrema, contraste de blanco nítido sobre negro profundo y detalles refinados.'
  },

  'A2 Mayordomo Principal': {
    roleName: 'A2 Mayordomo Principal',
    category: 'Servicio y Academia',
    tagline: 'Distinción aristocrática servil, frac impecable, chaleco cruzado, guantes blancos y reloj leontina',
    description: 'La máxima autoridad del servicio en grandes palacios. Impecabilidad postural, etiqueta rigurosa y cortesía gélida.',
    recommendedOutfitType: 'O-BUTLER Frac Clásico con Chaleco Cruzado y Corbata de Plastrón',
    outfitTypes: [
      { id: 'O-BUTLER-FRAC', name: 'O-BUTLER-FRAC Frac con Faldones Largos y Pajarita Blanca' },
      { id: 'O-BUTLER-SMK', name: 'O-BUTLER-SMK Smoking Negro con Solapas de Raso' },
      { id: 'O-BUTLER-BTL', name: 'O-BUTLER-BTL Mayordomo Marcial con Chaleco Antibalas Oculto' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Monóculos y Peinado Impecable',
        pieces: [
          'P1.1 Monóculo de Borde Dorado con Cordoncillo de Seda',
          'P1.2 Gafas de Lectura Finas con Montura de Plata',
          'P1.3 Sombrero de Copa Alta de Fieltro Pulido (Para exteriores)'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Frac, Chaleco y Camisa Almidonada',
        pieces: [
          'P2.1 Frac de Corte Inglés con Faldones Posteriores Cruzados',
          'P2.2 Chaleco Cruzado de Piqué Blanco con Botones de Nácar',
          'P2.3 Camisa de Cuello Pajarita Almidonado Rígido',
          'P2.4 Plastrón de Seda Gris Perla con Alfiler de Corbata'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Faldones de Frac y Sobretodo',
        pieces: [
          'P3.1 Faldones del Frac Divididos con Caída a la Corva',
          'P3.2 Sobretodo Chesterfield con Cuello de Terciopelo Negro',
          'P3.3 Capote de Mayordomo de Lana para Guardia Nocturna'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Guantes Blancos y Gemelos',
        pieces: [
          'P4.1 Guantes Blancos de Algodón Inmaculado para Manejo de Vajilla',
          'P4.2 Gemelos de Plata Grabados con el Blasón de la Casa',
          'P4.3 Pañuelo de Lino Blanco Doblado sobre el Antebrazo'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Leontina y Fajín de Esmoquin',
        pieces: [
          'P5.1 Cadena de Oro para Reloj Leontina Cruzando el Chaleco',
          'P5.2 Fajín de Raso Negro Plisado para Esmoquin',
          'P5.3 Cinturón de Cuero Negro con Hebilla Discreta Invisible'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalón de Frac con Galón',
        pieces: [
          'P6.1 Pantalón Recto de Paño Negro con Galón Lateral de Raso',
          'P6.2 Pantalón de Rayas Diplomáticas Gris y Negro',
          'P6.3 Calzas de Servicio con Botones Laterales'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Zapatos Oxford de Charol',
        pieces: [
          'P7.1 Zapatos Oxford de Charol con Suela de Cuero Silenciosa',
          'P7.2 Botines de Caña Baja con Polainas Blancas de Botones',
          'P7.3 Zapatos de Salón con Hebilla de Plata Satinada'
        ]
      }
    ],
    materials: ['Paño fino de vicuña o merino', 'Piqué de algodón almidonado', 'Raso de seda para solapas', 'Charol lustrado', 'Lino blanco puro'],
    finishes: ['Planchado con filo de navaja', 'Lustrado brillante en calzado', 'Satinado en solapas y vivos', 'Bordado heráldico discreto'],
    armorDefenses: [
      { id: 'Ninguna', name: 'Ninguna / Sin Armadura', desc: 'Protocolo de etiqueta absoluta' },
      { id: 'AR-SILK-CHEST', name: 'Chaleco Interior de Malla de Titanio Flexible', desc: 'Blindaje balístico y cortante imperceptible' }
    ],
    weapons: [
      'Bastón de Paseo con Estoque Templado Oculto de Acero de Solingen',
      'Paraguas Reforzado con Puntera Balística y Varillas de Titanio',
      'Pluma Estilográfica con Dardo de Neurotoxina',
      'Navaja de Plata Oculta en el Reverso de la Bandeja',
      'Cuerda de Piano de Alta Tensión en el Dobladillo de la Manga'
    ],
    relicsAndItems: [
      'Reloj de Bolsillo Savonette de Oro con Grabado Familiar',
      'Bandeja de Plata de Servir con Borde Festoneado',
      'Sacacorchos de Sommelier de Precisión con Mango de Hueso',
      'Libreta de Cuero con las Rutinas Secretas de los Señores',
      'Mechero de Gasolina de Plata Cincelada'
    ],
    bags: [
      'Portadocumentos Delgado de Cuero Negro con Cierre de Oro',
      'Maletín de Llaves y Sellos Notariales de la Mansión',
      'Funda de Terciopelo para Cubiertos de Plata y Cristalería',
      'Bolsillo Interior Reforzado para Correspondencia Privada'
    ],
    equipmentFinishes: [
      'Oro blanco satinado con monograma cincelado',
      'Plata inglesa con contraste de ley y brillo alto',
      'Cuero de becerro pulido al aceite con cantos pintados a mano',
      'Madera de palo rosa barnizada al alcohol'
    ],
    suggestedColors: [
      { id: 'negro_medianoche', name: 'Negro Medianoche / Carbón', hex: '#101014' },
      { id: 'blanco_pique', name: 'Blanco Piqué / Almidón', hex: '#FDFEFE' },
      { id: 'gris_perla', name: 'Gris Perla / Plata', hex: '#C0C0C0' },
      { id: 'dorado_oro', name: 'Oro Viejo / Detalle', hex: '#D4AF37' }
    ],
    suggestedWardrobeDetails: ['Solapas forradas en raso negro', 'Rayas diplomáticas milimétricas', 'Botones de nácar cosidos a mano', 'Pajarita anudada a mano'],
    styleNote: 'Pulcritud milimétrica, porte solemne, solapas de seda y elementos metálicos aristocráticos.'
  },

  'A3 Artificiero': {
    roleName: 'A3 Artificiero',
    category: 'Servicio y Academia',
    tagline: 'Mecánica arcana, engranajes de bronce, lentes telescópicas, guantelete tecno-mágico y viales de éter',
    description: 'Erudito ingeniero que fusiona magia elemental con relojería y alquimia. Su indumentaria está llena de instrumentos de medición y protección contra detonaciones.',
    recommendedOutfitType: 'O2 Media / Aventurero (Cuero reforzado, peto articulado, lentes múltiples)',
    outfitTypes: [
      { id: 'O-ARTIFICER-TECH', name: 'O-ARTIFICER-TECH Gabardina de Cuero Ignífugo con Cinturón de Engranajes' },
      { id: 'O-ARTIFICER-MECH', name: 'O-ARTIFICER-MECH Exo-Arnés de Bronce y Pistones Neumáticos' },
      { id: 'O-ARTIFICER-LAB', name: 'O-ARTIFICER-LAB Guardapolvo de Laboratorio Arcano con Peto de Cuero' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Lentes Telescópicas y Auriculares',
        pieces: [
          'P1.1 Gafas de Artificiero con Múltiples Lentes Articuladas y Filtros de Color',
          'P1.2 Monóculo de Cristal de Éter con Retícula de Enfoque',
          'P1.3 Casco Ligero de Cuero y Cobre con Antena de Detección Arcana',
          'P1.4 Máscara de Respiración con Filtro de Cobre y Resina Alquímica'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Petos de Cuero y Gabardinas',
        pieces: [
          'P2.1 Gabardina de Cuero Tratado contra Ácido con Hombreras de Cobre',
          'P2.2 Peto de Cuero Reforzado con Portaviales de Cristal en Diagonal',
          'P2.3 Chaleco de Mecánico con Engranajes Expuestos y Manómetro Frontal',
          'P2.4 Camisa de Trabajo con Mangas Remangadas y Cuello Abierto'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Mochilas de Vapor y Capas Cortas',
        pieces: [
          'P3.1 Mochila Generadora de Vapor y Éter con Chimeneas de Cobre',
          'P3.2 Arnés Dorsal con Brazo Articulado para Sostener Herramientas',
          'P3.3 Capa Corta Ignífuga de Cuero Asimétrica'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Guantelete Mecánico y Relojes',
        pieces: [
          'P4.1 Guantelete Mecánico de Bronce con Pistones de Precisión en la Mano Hábil',
          'P4.2 Manguito de Cuero con Brújula de Éter y Viales de Resina',
          'P4.3 Guantes de Cuero Térmico con Dedos Descubiertos para Manipulación Fina'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturón de Herramientas Tecnológicas',
        pieces: [
          'P5.1 Cinturón Ancho con Cartucheras de Cristales Arcanos y Destornilladores',
          'P5.2 Tahalí Doble con Funda para Llave Inglesa Gigante y Pistola Hextech',
          'P5.3 Faja de Cuero con Bobinas de Cobre Conductoras'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalones con Rodilleras de Bronce',
        pieces: [
          'P6.1 Pantalón Cargo de Cuero y Lona con Rodilleras Articuladas de Cobre',
          'P6.2 Bombachos de Mecánico con Bolsillos de Fuelle para Engranajes',
          'P6.3 Perneras Protectoras con Pistones Laterales de Asistencia'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Botas de Suela Neumática y Cobre',
        pieces: [
          'P7.1 Botas Pesadas con Puntera de Bronce y Suelas Aislantes de Goma',
          'P7.2 Botines de Cuero Engrasado con Espuelas de Engranaje',
          'P7.3 Calzado Magnético para Caminar sobre Placas de Metal'
        ]
      }
    ],
    materials: ['Cuero grueso curtido al cromo', 'Bronce fosforoso pulido', 'Cobre rojo conductor', 'Cristal óptico reforzado', 'Lona de aramida ignífuga'],
    finishes: ['Pátina de taller con aceite de máquina', 'Bronce cepillado satinado', 'Cobre pulido con reflejos cálidos', 'Cristal tratado antirreflejante'],
    armorDefenses: [
      { id: 'AR-STEAM-PLATING', name: 'Placas de Bronce y Cuero Mecanizado', desc: 'Blindaje contra esquirlas, descargas y calor de calderas' },
      { id: 'AR-FORCEFIELD', name: 'Emisor de Campo de Fuerza de Éter', desc: 'Proyector cinético que deflecta proyectiles' }
    ],
    weapons: [
      'Pistola de Éter con Cañón de Bobinas Magnéticas y Cristal de Foco',
      'Llave Dinamométrica Gigante Reforzada con Energía de Vapor',
      'Ballesta Neumática Repetidora con Cargador Cilíndrico de Viñetas',
      'Daga de Plasma con Filo de Cristal Resonante',
      'Lanzallamas Portátil de Ignición Alquímica'
    ],
    relicsAndItems: [
      'Núcleo de Energía de Cristal de Maná en Jaula de Cobre Giratoria',
      'Autómata Mecánico de Bolsillo en Forma de Búho o Escarabajo',
      'Multímetro Arcano de Aguja con Caja de Madera de Roble',
      'Plano Holográfico en Rollo de Pergamino de Cuarzo',
      'Juego de Llaves de Relojero y Micrómetros de Precisión'
    ],
    bags: [
      'Mochila Rígida de Cuero y Bronce con Compartimentos Herméticos',
      'Cartuchera de Cinturón para Baterías de Cristal Arcano',
      'Maletín de Instrumentos de Calibración con Interior de Terciopelo',
      'Bolsa Ignífuga de Bandolera para Compuestos Explosivos'
    ],
    equipmentFinishes: [
      'Bronce pulido a mano con sutil óxido verde verdigris en hendiduras',
      'Cristal de cuarzo facetado con brillo prismático',
      'Madera de teca aceitada con remaches de latón dorado',
      'Acero pavonado al aceite negro grafito'
    ],
    suggestedColors: [
      { id: 'bronce_dorado', name: 'Bronce Envejecido / Ámbar', hex: '#CD7F32' },
      { id: 'cobre_rojo', name: 'Cobre Rojo / Llama', hex: '#D97706' },
      { id: 'azul_eter', name: 'Azul Éter / Hextech', hex: '#06B6D4' },
      { id: 'cuero_marron', name: 'Cuero Marrón Taller', hex: '#78350F' }
    ],
    suggestedWardrobeDetails: ['Tubos de cobre flexibles conectados al peto', 'Engranajes móviles visibles', 'Viales de líquido luminiscente azul o verde', 'Costuras dobles con remaches de latón'],
    styleNote: 'Steampunk sofisticado, fusión de relojería e ingeniería arcana con materiales nobles.'
  },

  'A4 Bibliotecario Arcano': {
    roleName: 'A4 Bibliotecario Arcano',
    category: 'Servicio y Academia',
    tagline: 'Custodia de grimorios ancestrales, túnica académica de terciopelo, gafas de lectura y cadenas de tomos',
    description: 'Guardián del saber prohibido en archivos milenarios. Porta pergaminos, sellos de cera, guantes de conservación y llaves de bóvedas mágicas.',
    recommendedOutfitType: 'O-SCHOLAR Túnica Académica con Capucha de Terciopelo y Bordados Celestiales',
    outfitTypes: [
      { id: 'O-LIBRARIAN-ROBE', name: 'O-LIBRARIAN-ROBE Túnica Académica con Mangas Acampanadas y Estola' },
      { id: 'O-LIBRARIAN-SUIT', name: 'O-LIBRARIAN-SUIT Traje Formal de Archivero con Chaleco y Corbata' },
      { id: 'O-LIBRARIAN-OCCULT', name: 'O-LIBRARIAN-OCCULT Vestiduras de Conservador de Tomos Prohibidos con Cadenas' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Gafas de Aumento y Birretes',
        pieces: [
          'P1.1 Gafas de Media Luna de Plata con Cadena al Cuello',
          'P1.2 Birrete Académico de Terciopelo con Borla de Seda',
          'P1.3 Cinta para el Cabello con Runa de Mnemotecnia',
          'P1.4 Máscara Antipolvo de Seda Fina para Archivos Antiguos'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Túnicas y Chalecos de Archivero',
        pieces: [
          'P2.1 Túnica Larga de Paño con Cuello Alto y Bordados de Constelaciones',
          'P2.2 Chaleco de Terciopelo Verde Oscuro con Botones de Hueso',
          'P2.3 Blusa de Lino Blanco con Chorrera Sencilla y Cuello Rígido',
          'P2.4 Guardapolvo Académico con Bolsillos Alargados para Plumas'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Estolas y Capas de Sabio',
        pieces: [
          'P3.1 Estola Académica de Terciopelo con el Emblema de la Gran Biblioteca',
          'P3.2 Capa de Sabio con Forro de Seda Estrellada',
          'P3.3 Capelina Corta con Capucha Amplia para Lectura Silenciosa'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Guantes de Conservación y Manguitos',
        pieces: [
          'P4.1 Guantes Blancos de Algodón Especial para Manipular Pergaminos Antiguos',
          'P4.2 Manguitos de Terciopelo para Proteger las Mangas de la Tinta',
          'P4.3 Mangas Acampanadas con Forro de Seda en Contraste'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cadenas de Tomos y Sellos',
        pieces: [
          'P5.1 Arnés de Cintura con Cadena de Plata para Sujetar Grimorios Flotantes',
          'P5.2 Cinturón de Cuero Fino con Tintero Portátil Antiderrames',
          'P5.3 Faja de Seda con Medallón de Llave de Archivo Secreto'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Faldas Largas y Calzas Sobrias',
        pieces: [
          'P6.1 Falda Larga Plisada de Paño Gris Marengo',
          'P6.2 Pantalón de Vestir Académico de Lana Peinada',
          'P6.3 Enagua Liviana con Abertura Frontal Cómoda para Escaleras'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Zapatos Silenciosos de Biblioteca',
        pieces: [
          'P7.1 Zapatos de Suela de Fieltro Silenciosa para No Hacer Ruido al Caminar',
          'P7.2 Botines de Cuero Suave con Hebillas de Bronce',
          'P7.3 Babuchas de Terciopelo con Bordado de Letras Mágicas'
        ]
      }
    ],
    materials: ['Terciopelo de algodón denso', 'Paño de lana académica', 'Seda con estampado celestial', 'Cuero pergamino para encuadernación', 'Plata esterlina'],
    finishes: ['Mate solemne', 'Bordados en hilo de plata y oro', 'Tinta caligráfica brillante', 'Pátina de papel antiguo'],
    armorDefenses: [
      { id: 'Ninguna', name: 'Ninguna / Sin Armadura', desc: 'Indumentaria consagrada al estudio y la preservación' },
      { id: 'AR-RUNE-SHROUD', name: 'Manto con Sigilos Rúnicos de Disipación', desc: 'Anula maldiciones de libros sellados y ataques mágicos leves' }
    ],
    weapons: [
      'Bastón con Candelabro y Cristal de Luz de Lectura Eterna',
      'Cortapapeles de Plata Antigua Capaz de Cortar Hechizos',
      'Vara de Archivero con Gancho para Bajar Tomos de Grandes Alturas',
      'Pluma Metálica Arrojadiza Imbuida en Tinta Paralyzadora'
    ],
    relicsAndItems: [
      'Grimorio Encadenado con Cerradura de Tres Runas',
      'Tintero Portátil de Cristal de Bohemia con Tinta de Pulpo de las Profundidades',
      'Lupa de Lectura con Revelador de Textos Invisibles',
      'Reloj de Arena con Polvo de Estrellas de Tiempo Suspendido',
      'Sello de Lacre Notarial con Emblema del Consejo de Sabios'
    ],
    bags: [
      'Portagrimorios de Cuero Rígido con Forro de Terciopelo Acolchado',
      'Tubo Portapergaminos de Cuero Repujado Impermeable',
      'Bolso Bandolera para Libros y Frascos de Tinta',
      'Estuche de Madera de Nogal para Plumas de Ave Raras'
    ],
    equipmentFinishes: [
      'Cuero envejecido con aroma a cera y cedro',
      'Plata envejecida con grabado de runas de conocimiento',
      'Cristal óptico ámbar con montura de latón patinado',
      'Papel vitela encerado con cantos dorados'
    ],
    suggestedColors: [
      { id: 'verde_biblioteca', name: 'Verde Botella / Biblioteca', hex: '#1E3A2F' },
      { id: 'azul_noche_sabio', name: 'Azul Noche Académico', hex: '#1C2541' },
      { id: 'oro_pergamino', name: 'Pergamino Antiguo / Oro Viejo', hex: '#D4AF37' },
      { id: 'burdeos_terciopelo', name: 'Burdeos / Vino de Claustro', hex: '#4A1521' }
    ],
    suggestedWardrobeDetails: ['Bordados de constelaciones y runas en hilo de plata', 'Bordes ribeteados en terciopelo', 'Cadenas finas de plata colgando de la cintura', 'Botones de madera de roble barnizada'],
    styleNote: 'Erudición solemne, terciopelos densos, tonos oscuros y accesorios de caligrafía y custodia mágica.'
  },

  'A5 Sirviente / Esclavo': {
    roleName: 'A5 Sirviente / Esclavo',
    category: 'Servicio y Academia',
    tagline: 'Sometimiento y cadenas, telas desgastadas o sedas transparentes de concubina, collares de sumisión y grilletes',
    description: 'Indumentaria de cautiverio o servidumbre forzada. Desde harapos rústicos de siervo hasta atuendos suntuosos y reveladores de concubina con cadenas doradas.',
    recommendedOutfitType: 'O-SLAVE Túnica de Seda Translúcida con Gargantilla y Cadenas Doradas',
    outfitTypes: [
      { id: 'O-SLAVE-SILK', name: 'O-SLAVE-SILK Atuendo de Concubina con Velos de Gasa y Joyas de Cautiverio' },
      { id: 'O-SLAVE-RAGS', name: 'O-SLAVE-RAGS Túnica Rústica de Estopa Deshilachada con Grilletes de Hierro' },
      { id: 'O-SLAVE-LEATHER', name: 'O-SLAVE-LEATHER Arnés de Cuero de Sumisión con Correas Cruzadas' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Collares y Máscaras de Vientre',
        pieces: [
          'P1.1 Gargantilla Rígida de Oro o Hierro de Propiedad con Cadena',
          'P1.2 Velo Facial de Gasa Translúcida con Cuentas',
          'P1.3 Máscara de Sumisión de Cuero o Metal Labrado',
          'P1.4 Diadema de Cadenillas Colgantes sobre la Frente'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Tops de Cadenas y Túnicas Rasgadas',
        pieces: [
          'P2.1 Top Bralette de Malla de Cadenas de Oro con Acentos de Seda',
          'P2.2 Túnica Rasgada de Lino Asimétrica con Hombro Descubierto',
          'P2.3 Arnés de Cuero en X sobre el Pecho con Argollas de Metal',
          'P2.4 Corpiño de Seda Transparente con Ribetes Dorados'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Cadenas Cruzadas y Capas de Gasa',
        pieces: [
          'P3.1 Cadenas Cruzadas en la Espalda con Argolla Central de Sujeción',
          'P3.2 Capa Larga de Gasa Translúcida Flotante',
          'P3.3 Manto de Estopa Rasgado Atado al Cuello'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Grilletes y Manillas de Oro',
        pieces: [
          'P4.1 Grilletes de Muñeca de Bronce o Hierro con Eslabones Colgantes',
          'P4.2 Brazaletes Rígidos de Bíceps en Forma de Serpiente o Aro de Oro',
          'P4.3 Vendas de Lino Envolviendo las Manos y Antebrazos',
          'P4.4 Muñequeras de Cuero con Anillas de Arrastre'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cadenas de Vientre y Fajas',
        pieces: [
          'P5.1 Cadena de Vientre de Eslabones Finos con Monedas Tintineantes',
          'P5.2 Cinturón Rígido de Metal con Candado de Castidad / Servidumbre',
          'P5.3 Faja de Cuerda de Cáñamo Anudada a la Cadera'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Sobrefaldas Abiertas y Bombachos',
        pieces: [
          'P6.1 Falda de Gasa Translúcida con Doble Abertura Lateral hasta la Cadera',
          'P6.2 Bombachos Cortos de Seda Suave de Harén',
          'P6.3 Taparrabos de Lino Sujeto con Cintas',
          'P6.4 Grilletes de Tobillo con Cadena de Paso Corto'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Tobilleras y Pies Descalzos',
        pieces: [
          'P7.1 Tobilleras de Oro con Cascabeles Suaves en Pies Descalzos',
          'P7.2 Sandalias Mínimas de Suela Fina y Tiras Cruzadas',
          'P7.3 Grilletes de Tobillo Forrados en Cuero para Evitar Laceraciones'
        ]
      }
    ],
    materials: ['Gasa de seda translúcida', 'Estopa de cáñamo áspera', 'Latón pulido brillante', 'Hierro forjado rudo', 'Cuero crudo'],
    finishes: ['Transparencia etérea de gasa', 'Hierro con pátina de óxido', 'Oro brillante pulido', 'Bordes deshilachados rústicos'],
    armorDefenses: [
      { id: 'Ninguna', name: 'Ninguna / Desprotección Total', desc: 'Cuerpo vulnerable para enfatizar sumisión y agilidad' },
      { id: 'AR-CHARM-WARD', name: 'Talismán Protector Oculto en el Collar', desc: 'Runa secreta que mitiga daño elemental o golpes' }
    ],
    weapons: [
      'Daga Oculta en el Dobladillo de la Falda o Velo',
      'Cadena de Grillete Usada como Látigo o Garrote Improvisto',
      'Horquilla de Pelo Afilada como Estilete Envenenado',
      'Cuchillo de Servidumbre Oculto en la Tobillera'
    ],
    relicsAndItems: [
      'Llave Pequeña de Grillete Escondida en el Cabello',
      'Frasco de Aceite Aromático de Jazmín y Loto',
      'Medallón con el Retrato del Hogar Perdido',
      'Amuleto de Buena Fortuna Tallado en Hueso'
    ],
    bags: [
      'Bolsita de Seda Escondida bajo la Falda',
      'Limosnera de Lino Atada con Cordel a la Cadera',
      'Cofrecito Portátil de Joyas del Amo',
      'Zurrón Rústico de Trapos para Comida'
    ],
    equipmentFinishes: [
      'Oro reluciente con grabados de cadenas decorativas',
      'Hierro fundido oscuro con marcas de forja pesada',
      'Bronce pulido a mano con pátina ámbar',
      'Cordel de cáñamo natural sin teñir'
    ],
    suggestedColors: [
      { id: 'oro_bronce', name: 'Oro Reluciente / Latón', hex: '#E5A93C' },
      { id: 'blanco_gasa', name: 'Blanco Seda Translúcida', hex: '#F8F9FA' },
      { id: 'rosa_clavel', name: 'Rosa Seda / Harén', hex: '#F472B6' },
      { id: 'gris_hierro', name: 'Hierro Forjado / Ceniza', hex: '#4A5568' }
    ],
    suggestedWardrobeDetails: ['Cadenillas doradas colgando en hombros y cadera', 'Cascabeles tintineantes en los tobillos', 'Bordes de gasa con dobladillo dorado', 'Grabado de propiedad en el collar rígido'],
    styleNote: 'Dualidad entre sensualidad cautiva oriental o rusticidad de siervo con cadenas.'
  },

  'A6 Aprendiz': {
    roleName: 'A6 Aprendiz',
    category: 'Servicio y Academia',
    tagline: 'Iniciación mágica, túnica corta juvenil, cuadernos de conjuros, varita de práctica y zurrón de viales',
    description: 'Estudiante novel de artes arcanas o alquimia. Atuendo juvenil, práctico, con manchas de pociones y accesorios de estudio básico.',
    recommendedOutfitType: 'O-APPRENTICE Túnica Corta con Cinturón de Bolsas y Capucha Juvenil',
    outfitTypes: [
      { id: 'O-APPRENTICE-MAGIC', name: 'O-APPRENTICE-MAGIC Túnica de Estudiante de Primer Año con Ribetes Azules' },
      { id: 'O-APPRENTICE-ALCH', name: 'O-APPRENTICE-ALCH Atuendo de Laboratorio con Delantal de Cuero y Manchas' },
      { id: 'O-APPRENTICE-FIELD', name: 'O-APPRENTICE-FIELD Ropa de Exploración Arcana con Capa Corta y Botines' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Gorros Cónicos y Cintas',
        pieces: [
          'P1.1 Sombrero Cónico Pequeño de Aprendiz con Hebilla',
          'P1.2 Cinta para el Pelo con Runa de Concentración',
          'P1.3 Gafas Protectoras sobre la Frente con Manchas de Hollín',
          'P1.4 Boina de Estudiante con Pluma Corta'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Túnicas Cortas y Chalecos',
        pieces: [
          'P2.1 Túnica Corta hasta el Muslo con Cuello de Solapa y Bordado de Rango',
          'P2.2 Chaleco de Paño Juvenil con Botones de Madera',
          'P2.3 Camisa de Lino Cómoda con Cuello Desabotonado',
          'P2.4 Blusón de Alquimista con Bolsillos Frontales para Viales'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Capas Cortas con Capucha',
        pieces: [
          'P3.1 Capa Corta Juvenil con Capucha Puntiaguda',
          'P3.2 Capelina de Lana con Broche de Bronce Simple',
          'P3.3 Mochilero de Hombro con Soporte para Varita'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Manguitos y Guantes Cortados',
        pieces: [
          'P4.1 Guantes sin Dedos de Lana para Escribir sin Pasar Frío',
          'P4.2 Manguitos Protectores de Cuero Suave',
          'P4.3 Pulsera de Hilo Mágico Trenzado por el Mentor'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Cinturones con Frascos y Bolsas',
        pieces: [
          'P5.1 Cinturón de Cuero con Funda de Varita y Dos Bolsitas de Polvos',
          'P5.2 Faja de Tela a Rayas con Nudo Lateral',
          'P5.3 Tahalí Delgado para Cuaderno de Hechizos'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Pantalones Cortos y Faldas',
        pieces: [
          'P6.1 Pantalón Corto de Paño con Medias Altas hasta la Rodilla',
          'P6.2 Falda Plisada de Estudiante con Dobladillo de Color de Escuela',
          'P6.3 Calzas de Lana Ajustadas con Refuerzo en Rodillas'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Botines Cómodos y Zapatos de Cordones',
        pieces: [
          'P7.1 Botines de Cuero Suave con Cordones Cruzados',
          'P7.2 Zapatos de Estudiante con Suela de Goma Flexible',
          'P7.3 Zapatillas de Paño para Clases en Interiores'
        ]
      }
    ],
    materials: ['Paño de lana ligero', 'Lino de algodón transpirable', 'Cuero flexible de cordero', 'Latón satinado', 'Fieltro suave'],
    finishes: ['Mate juvenil', 'Bordes con cinta de sarga de color', 'Ligeras manchas de tinta y poción', 'Costuras visibles pulcras'],
    armorDefenses: [
      { id: 'Ninguna', name: 'Ninguna / Ropa de Estudiante', desc: 'Ligereza máxima para correr por los pasillos' },
      { id: 'AR-WARD-RUNE', name: 'Bordado Rúnico de Protección Básica', desc: 'Hechizo de protección elemental contra quemaduras menores' }
    ],
    weapons: [
      'Varita de Práctica de Madera de Sauce con Núcleo de Pluma',
      'Bastón Corto de Aprendiz con Cristal de Cuarzo sin Tallar',
      'Frasco Arrojadizo de Polvo de Humo Mágico',
      'Daga Pequeña de Tallar Runas con Vaina de Cuero'
    ],
    relicsAndItems: [
      'Cuaderno de Apuntes de Hechizos Lleno de Anotaciones y Dibujos',
      'Familiar Menor en el Hombro (Ratón, Murciélago o Gato)',
      'Brújula Mágica de Orientación Elemental',
      'Tintero con Plumilla y Borrador de Hechizos'
    ],
    bags: [
      'Mochila Escolar de Cuero con Hebillas de Bronce',
      'Bandolera para Libros y Tubo de Pergaminos',
      'Bolsita de Cinturón para Componentes de Conjuros',
      'Estuche Cilíndrico para Varitas Mágicas'
    ],
    equipmentFinishes: [
      'Madera de sauce pulida a mano con barniz claro',
      'Cuero color miel con pátina de uso diario',
      'Latón brillante sin envejecer',
      'Cristal de cuarzo transparente y luminoso'
    ],
    suggestedColors: [
      { id: 'azul_estudiante', name: 'Azul Real / Estudiante', hex: '#2563EB' },
      { id: 'dorado_miel', name: 'Amarillo Mostaza / Miel', hex: '#EAB308' },
      { id: 'blanco_crema', name: 'Blanco Crema / Lino', hex: '#FDFBF7' },
      { id: 'marron_cuero', name: 'Marrón Cuero Claro', hex: '#A16207' }
    ],
    suggestedWardrobeDetails: ['Cintas de color de la casa académica en cuello y puños', 'Manchitas de tinta mágica en los dedos', 'Hebillas cuadradas de latón pulido', 'Bolsillos laterales funcionales'],
    styleNote: 'Inocencia académica, prendas dinámicas y accesorios de estudio listos para la aventura.'
  },

  'A7 Erudito': {
    roleName: 'A7 Erudito',
    category: 'Servicio y Academia',
    tagline: 'Sabiduría madura, togas universitarias solemnes, estolas magistrales, pergaminos de tesis y astrolabios',
    description: 'Catedrático, filósofo o sabio consular. Viste togas y ropajes majestuosos que imponen respeto intelectual en cortes y senados.',
    recommendedOutfitType: 'O-MAGISTER Toga Magistral con Capucha Forrada en Seda y Estola de Rango',
    outfitTypes: [
      { id: 'O-MAGISTER-TOGA', name: 'O-MAGISTER-TOGA Toga Doctoral con Ribetes de Oro y Gran Cuello' },
      { id: 'O-MAGISTER-SENATE', name: 'O-MAGISTER-SENATE Túnica Consular de Filósofo con Capa Terciada' },
      { id: 'O-MAGISTER-TRVL', name: 'O-MAGISTER-TRVL Ropaje de Erudito Itinerante con Manto de Lana Pesada' }
    ],
    slots: [
      {
        slotId: 'P1',
        slotName: 'P1 Cabeza & Rostro / Gorros Magistrales y Barbas',
        pieces: [
          'P1.1 Gorro Magistral de Cuatro Puntas de Terciopelo',
          'P1.2 Corona de Laurel de Bronce o Plata de Sabio',
          'P1.3 Gafas Redondas con Montura de Hueso y Cadena',
          'P1.4 Capucha Académica Forrada en Piel Suave'
        ]
      },
      {
        slotId: 'P2',
        slotName: 'P2 Torso & Pecho / Túnicas Plisadas y Jubones de Terciopelo',
        pieces: [
          'P2.1 Toga Larga Plisada con Gran Caída y Mangas Magistrales',
          'P2.2 Jubón de Terciopelo Forrado con Botones de Metal Labrado',
          'P2.3 Túnica de Seda Pesada con Cuello Alto Rígido',
          'P2.4 Camisón Interior de Lino Fino con Puños Almidonados'
        ]
      },
      {
        slotId: 'P3',
        slotName: 'P3 Espalda & Hombros / Gran Manto Magistral',
        pieces: [
          'P3.1 Gran Manto Forrado de Armiño o Terciopelo Cruzando la Espalda',
          'P3.2 Estola Doctoral con Bordados en Hilo de Oro de las Siete Artes',
          'P3.3 Capa Plisada al Viento con Cierre de Broche Doble'
        ]
      },
      {
        slotId: 'P4',
        slotName: 'P4 Brazos & Muñecas / Mangas Amplias y Anillos de Rector',
        pieces: [
          'P4.1 Mangas de Toga Gigantes con Abertura para Sacar los Brazos',
          'P4.2 Anillo de Rector con Sello de la Universidad',
          'P4.3 Guantes Finos de Piel de Cabra para Firmas Oficiales'
        ]
      },
      {
        slotId: 'P5',
        slotName: 'P5 Cintura & Cinto / Fajas Magistrales y Sellos',
        pieces: [
          'P5.1 Faja de Seda Pesada con Borlas de Oro en los Extremos',
          'P5.2 Cordón Doctoral Trenzado con Nudos Simbólicos',
          'P5.3 Cinturón de Cuero con Funda de Astrolabio'
        ]
      },
      {
        slotId: 'P6',
        slotName: 'P6 Piernas & Caderas / Ropajes Interiores Sobrios',
        pieces: [
          'P6.1 Túnica Interior hasta los Pies con Caída Recta',
          'P6.2 Calzas de Paño Fino de Color Negro o Burdeos',
          'P6.3 Pantalones de Vestir Académicos de Corte Recto'
        ]
      },
      {
        slotId: 'P7',
        slotName: 'P7 Pies & Calzado / Zapatos de Magistrado y Babuchas',
        pieces: [
          'P7.1 Zapatos de Terciopelo con Suela de Cuero y Hebilla de Oro',
          'P7.2 Botines de Paño Fino con Cordones Ocultos',
          'P7.3 Sandalias de Cuero de Filósofo Clásico'
        ]
      }
    ],
    materials: ['Terciopelo genovés pesado', 'Lana merina de alta calidad', 'Seda de damasco', 'Pieles finas de adorno', 'Oro en lingote y broches'],
    finishes: ['Plisado solemne', 'Bordados heráldicos en oro y plata', 'Bordes con piel de armiño', 'Satinado de lujo austero'],
    armorDefenses: [
      { id: 'Ninguna', name: 'Ninguna / Ropaje Magistral Puro', desc: 'Aura de respeto intelectual como principal defensa' },
      { id: 'AR-SANCTUARY-ROBE', name: 'Toga Tejida con Hilos de Santuario', desc: 'Resistencia a influencias mentales y confusión mágica' }
    ],
    weapons: [
      'Bastón de Rector con Pomo de Esfera Armilar Giratoria',
      'Vara de Ébano con Punta de Plata y Letras Cinceladas',
      'Daga Ceremonial con Empuñadura de Marfil y Blasón',
      'Pluma Estilográfica de Oro Puro Capaz de Escribir en el Aire'
    ],
    relicsAndItems: [
      'Astrolabio de Latón Macizo con Anillos Planetarios Móviles',
      'Esfera Armilar de Bolsillo de Plata y Oro',
      'Tratado Filosófico Original Encuadernado en Piel de Dragón',
      'Medalla de Oro al Mérito de la Gran Academia'
    ],
    bags: [
      'Maletín de Piel de Becerro para Tratados y Manuscritos Reales',
      'Cofre Cilíndrico de Cuero para Pergaminos Sagrados',
      'Bolso de Hombro de Terciopelo con Forro de Seda',
      'Funda Rígida para Instrumentos Astronómicos'
    ],
    equipmentFinishes: [
      'Latón dorado y envejecido con números astronómicos grabados a buril',
      'Madera de ébano con incrustaciones de nácar',
      'Plata con pátina antigua en relieves de filósofos',
      'Cuero marroquí con gofrado en pan de oro'
    ],
    suggestedColors: [
      { id: 'purpura_doctoral', name: 'Púrpura Doctoral / Cardenal', hex: '#6B21A8' },
      { id: 'azul_ultramar', name: 'Azul Ultramar / Zafiro', hex: '#1E40AF' },
      { id: 'oro_viejo', name: 'Oro Viejo / Latón', hex: '#CA8A04' },
      { id: 'negro_academico', name: 'Negro Académico / Paño', hex: '#18181B' }
    ],
    suggestedWardrobeDetails: ['Pliegues verticales majestuosos en la toga', 'Bordados de constelaciones y símbolos alquímicos', 'Broches de cadenas dobles doradas en el pecho', 'Forro de seda en contraste al caminar'],
    styleNote: 'Solemnidad augusta, amplias caídas de tela, sabiduría milenaria y accesorios astronómicos y filosóficos.'
  }
};
