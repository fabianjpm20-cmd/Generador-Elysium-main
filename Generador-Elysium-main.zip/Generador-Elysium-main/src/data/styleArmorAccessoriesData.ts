export interface StyleThematicTradition {
  id: string;
  name: string;
  subtitle: string;
  category: string;
  description: string;
  iconTag: string;
  suggestedArmor: string[];
  suggestedAccessories: string[];
  suggestedWeapon: string;
  suggestedMotif: string;
  suggestedSilk: string;
  suggestedJade: string;
  suggestedAura: string;
}

export interface StyleThematicPieceOption {
  id: string;
  name: string;
  category: 'Armadura Torso' | 'Hombreras & Brazos' | 'Cabeza & Máscara' | 'Piernas & Pies' | 'Accesorio Sagrado' | 'Joyería & Cabello' | 'Prenda Flotante';
  culturalOrigin: string;
  description: string;
  icon?: string;
}

export interface StyleAccentMineral {
  id: string;
  name: string;
  hex: string;
  desc: string;
}

export interface StyleWeaponOption {
  name: string;
  type: string;
  desc: string;
}

export interface StyleThematicDataPackage {
  styleName: string;
  title: string;
  tag: string;
  subtitle: string;
  description: string;
  traditions: StyleThematicTradition[];
  armorPieces: StyleThematicPieceOption[];
  culturalAccessories: StyleThematicPieceOption[];
  spiritualMotifs: string[];
  silkPatterns: string[];
  jadeColors: StyleAccentMineral[];
  weapons: StyleWeaponOption[];
  auras: string[];
}

export const ALL_STYLE_THEMATIC_DATA: Record<string, StyleThematicDataPackage> = {
  'Fantasía Oriental': {
    styleName: 'Fantasía Oriental',
    title: 'Fantasía Oriental & Artes Marciales Místicas',
    tag: '☯️ Xianxia / Wuxia / Sengoku',
    subtitle: 'Cultivo Inmortal, Honor Dinástico y Mística Ancestral',
    description: 'Armaduras lamelares Shanwenjia, sedas fluidas de mangas anchas, horquillas de jade pulido, talismanes taoístas flotantes y armamento de acero plegado.',
    traditions: [
      {
        id: 'XIANXIA',
        name: 'Xianxia / Cultivador Inmortal Taoísta',
        subtitle: 'Arquetipo de Ascensión Celestial',
        category: 'Místico & Daoísta',
        description: 'Túnicas de seda flotante de múltiples capas con mangas anchas, horquillas de jade pulido, talismanes flotantes y espada voladora espiritual.',
        iconTag: '☯️ Dao / Xianxia',
        suggestedArmor: ['Peto Shanwenjia Ligero de Escamas de Montaña', 'Faja Kuadai con Placas de Jade Blanco Hetian'],
        suggestedAccessories: ['Horquilla Zan de Jade con Borlas de Seda', 'Colgante de Jade Espiritual y Nudo Infinito Chino', 'Talismanes Ofuda / Taoístas Flotantes', 'Calabaza Hulu de Elixir de Inmortalidad'],
        suggestedWeapon: 'Espada Jian Recta de Doble Filo con Borla Sagrada',
        suggestedMotif: 'Nubes Celestiales Taoístas & Loto de Nácar',
        suggestedSilk: 'Gasa Translúcida Multicapa con Hilos de Plata',
        suggestedJade: 'Jade Hetian Blanco Puro',
        suggestedAura: 'Qi Espiritual Dorado & Hojas de Loto Luminosas'
      },
      {
        id: 'WUXIA',
        name: 'Wuxia / Espadachín Errante (Jianghu)',
        subtitle: 'Héroe Solitario de los Caminos',
        category: 'Marcial & Aventura',
        description: 'Sombrero cónico douli de bambú con velo de gasa oscura, brazales de cuero reforzado, faja ancha de tela, calabaza de vino al cinto y letal espada jian o sable dao.',
        iconTag: '⚔️ Jianghu / Wuxia',
        suggestedArmor: ['Jubón de Cuero Reforzado y Seda Oscura', 'Brazales de Cuero de Bambú y Metal Lacado (Biguan)'],
        suggestedAccessories: ['Sombrero Douli / Kasa de Paja con Velo de Gasa Flotante', 'Pipa Larga Tradicional de Latón y Ébano (Yandai)', 'Calabaza Hulu de Elixir / Vino de Jianghu'],
        suggestedWeapon: 'Sable Curvo Dao / Jian con Empuñadura Encordada',
        suggestedMotif: 'Bambú y Flor de Ciruelo en la Nieve',
        suggestedSilk: 'Sarga Negra Mate y Algodón Reforzado',
        suggestedJade: 'Jade Negro Ébano',
        suggestedAura: 'Niebla de Tinta / Suibokuga Mística'
      },
      {
        id: 'IMPERIAL_GUARD',
        name: 'Guardia Imperial / Dinastía Celestial',
        subtitle: 'Élite Marcial de la Ciudad Prohibida',
        category: 'Militar Dinástico',
        description: 'Imponente armadura lamelar dorada y escarlata, hombreras con cabezas de león o dragón, capa escarlata forrada y sable imperial de mando.',
        iconTag: '🐉 Dinastía Imperial',
        suggestedArmor: ['Armadura Lamelar Shanwenjia (Escamas de Montaña)', 'Hombreras de Cabeza de Dragón Dorado (Longlin)', 'Peto Brigantina Dingjia Tachonado de Bronce', 'Grebas Dingjia Reforzadas'],
        suggestedAccessories: ['Faja Kuadai con Placas de Jade Blanco Hetian', 'Capa Imperial Escarlata de Seda Pesada', 'Anillo de Pulgar de Jade para Arquero (Ban Zhi)'],
        suggestedWeapon: 'Lanza Guandao de Dragón Imperial',
        suggestedMotif: 'Dragón Celestial Dorado de Cinco Garras',
        suggestedSilk: 'Brocado Imperial con Hilos de Oro Puro',
        suggestedJade: 'Jade Verde Esmeralda Imperial',
        suggestedAura: 'Resplandor Solar Imperial y Cenizas de Dragón'
      },
      {
        id: 'SAMURAI_MYSTIC',
        name: 'Samurái / Místico Sengoku',
        subtitle: 'Honor, Acero Plegado y Deber Ancestral',
        category: 'Marcial de Élite',
        description: 'Armadura tradicional dō lacada en negro y bermellón, hombreras sode articuladas con cordones de seda, máscara demoníaca menpo y katana forjada.',
        iconTag: '🏯 Sengoku / Bushido',
        suggestedArmor: ['Coraza Dō Lacada en Negro y Bermellón', 'Hombreras Lamelares Sode con Cordaje de Seda', 'Máscara Facial Demoníaca Menpo', 'Espinilleras Suneate con Placas de Hierro'],
        suggestedAccessories: ['Abanico de Guerra Tessen / Gunbai de Acero y Oro', 'Cordón Trenzado Odoshi de Seda Carmesí', 'Mon con Escudo de Clan Familiar'],
        suggestedWeapon: 'Katana Forjada en Acero Plegado Tamahagane',
        suggestedMotif: 'Flor de Cerezo y Ondas de Agua (Seigaiha)',
        suggestedSilk: 'Seda Pesada con Tejido Chirimen',
        suggestedJade: 'Jade Rojo Sangre / Laca Bermellón',
        suggestedAura: 'Flores de Cerezo Iluminadas y Chispas de Acero'
      },
      {
        id: 'ONMYOJI_SHINTO',
        name: 'Onmyoji / Hechicero Shintoísta',
        subtitle: 'Maestro del Yin-Yang y los Espíritus Shikigami',
        category: 'Mágico & Espiritual',
        description: 'Túnica blanca sacerdotal kariginu, sombrero alto eboshi negro, abanico ceremonial sensu, talismanes espirituales de papel y sellos bagua flotantes.',
        iconTag: '⛩️ Onmyodo / Shinto',
        suggestedArmor: ['Manto Ceremonial Kariginu con Cordones Trenzados', 'Hakama Sacerdotal Escarlata de Seda'],
        suggestedAccessories: ['Talismanes Ofuda / Taoístas Flotantes', 'Abanico Ceremonial Sensu con Pintura Dorada', 'Campanilla Ritual Fengling / Suzu con Cascabel de Bronce', 'Espejo Sagrado de Bronce Protector'],
        suggestedWeapon: 'Báculo Monacal Khakkhara con Anillos Sonoros',
        suggestedMotif: 'Sello Yin-Yang Bagua y Estrellas Pentagrámicas',
        suggestedSilk: 'Seda Blanca Sagrada Inmaculada',
        suggestedJade: 'Jade Lavanda Místico',
        suggestedAura: 'Aura Relampagueante Azur y Papeles Shikigami'
      },
      {
        id: 'CELESTIAL_HANFU',
        name: 'Corte Celestial / Hanfu Místico',
        subtitle: 'Gracia Divina, Realeza de las Alturas',
        category: 'Alta Nobleza Mística',
        description: 'Suntuoso vestido Hanfu de capas translúcidas superpuestas, mangas anchas de agua ondulantes, capa flotante pibo, tiara fénix de filigrana dorada y gemas de jade.',
        iconTag: '🦚 Hanfu Celestial',
        suggestedArmor: ['Corsé de Seda Estructurado con Bordados de Fénix', 'Fajín Ancho Kuadai con Borlas de Perlas'],
        suggestedAccessories: ['Tiara Fénix de Filigrana Dorada con Borlas (Fengguan)', 'Horquilla Zan de Jade con Borlas de Seda', 'Capa Flotante Pibo / Hagoromo de Hilos Celestiales', 'Colgante de Jade Espiritual y Nudo Infinito Chino'],
        suggestedWeapon: 'Cítara Guqin Encantada con Sonidos de Dragón',
        suggestedMotif: 'Fénix Inmortal Carmesí (Fenghuang)',
        suggestedSilk: 'Seda Damascada con Lotos Flotantes y Bordados de Oro',
        suggestedJade: 'Jade Hetian Blanco con Perlas de Río',
        suggestedAura: 'Resplandor Iridiscente y Pétalos de Ciruelo Flotantes'
      }
    ],
    armorPieces: [
      { id: 'ARM_SHANWENJIA', name: 'Peto Shanwenjia (Escamas de Montaña)', category: 'Armadura Torso', culturalOrigin: 'China Tang / Song', description: 'Armadura icónica formada por placas metálicas entrelazadas con forma de estrella de tres puntas que forman una cota impenetrable y flexible.' },
      { id: 'ARM_DO_LACQUER', name: 'Coraza Dō Lacada en Negro y Bermellón', category: 'Armadura Torso', culturalOrigin: 'Japón Sengoku / Edo', description: 'Coraza de placas de acero endurecido y cuero recubierta de laca pulida protectora, atada con cordones de seda colorida odoshi.' },
      { id: 'ARM_DINGJIA', name: 'Peto Brigantina Dingjia Tachonado de Bronce', category: 'Armadura Torso', culturalOrigin: 'China Ming / Qing', description: 'Chaqueta de seda pesada o terciopelo con placas de metal remachadas por dentro, mostrando filas de tachones dorados en el exterior.' },
      { id: 'ARM_DRAGON_SHOULDERS', name: 'Hombreras de Cabeza de Dragón Dorado (Longlin)', category: 'Hombreras & Brazos', culturalOrigin: 'Mitología Dinástica', description: 'Hombreras esculpidas con fauces de dragón dorado de cuyas bocas surgen placas de escamas metálicas superpuestas.' },
      { id: 'ARM_SODE', name: 'Hombreras Lamelares Sode con Cordaje de Seda', category: 'Hombreras & Brazos', culturalOrigin: 'Japón Tradicional', description: 'Grandes placas defensivas rectangulares de láminas de hierro atadas con cordoncillos de seda, protegiendo los hombros durante el combate.' },
      { id: 'ARM_BIGUAN_BRACERS', name: 'Brazales de Cuero de Bambú y Metal Lacado (Biguan / Kote)', category: 'Hombreras & Brazos', culturalOrigin: 'China / Japón', description: 'Brazales reforzados con placas metálicas y varillas de bambú endurecido, grabados con motivos de nubes o kanjis de protección.' },
      { id: 'ARM_MENPO_MASK', name: 'Máscara Facial Demoníaca Menpo / Gui Mian', category: 'Cabeza & Máscara', culturalOrigin: 'Japón / China Mística', description: 'Media máscara de hierro lacado con expresión de ogro demoníaco (Oni / Yaoguai), con bigotes de cerdas y protector de garganta.' },
      { id: 'ARM_KABUTO_HELM', name: 'Yelmo Kabuto con Maedate de Media Luna Dorada', category: 'Cabeza & Máscara', culturalOrigin: 'Japón Samurai', description: 'Casco de múltiples placas remachadas con cresta ornamental de luna creciente de latón pulido y protector de nuca shikoro.' },
      { id: 'ARM_SUNEATE_GREAVES', name: 'Espinilleras Suneate con Placas de Hierro y Seda', category: 'Piernas & Pies', culturalOrigin: 'Japón Tradicional', description: 'Grebas formadas por láminas verticales de acero unidas por malla de hierro sobre un forro de tela bordada, atadas con tiras de cuero.' },
      { id: 'ARM_KUADAI_BELT', name: 'Faja Kuadai con Placas de Jade Blanco Hetian', category: 'Armadura Torso', culturalOrigin: 'China Dinástica', description: 'Cinturón ceremonial de cuero forrado de seda con placas rectangulares de auténtico jade blanco tallado que denotan alto rango.' }
    ],
    culturalAccessories: [
      { id: 'ACC_DOULI_HAT', name: 'Sombrero Douli / Kasa de Paja con Velo de Gasa Flotante', category: 'Cabeza & Máscara', culturalOrigin: 'Tradición Jianghu / Wuxia', description: 'Sombrero cónico tejido de bambú del cual cuelga un velo translúcido de gasa negra o blanca que oculta la mirada y protege de la intemperie.' },
      { id: 'ACC_ZAN_HAIRPIN', name: 'Horquilla Zan / Kanzashi de Jade y Borlas de Seda', category: 'Joyería & Cabello', culturalOrigin: 'Corte Imperial Hanfu', description: 'Elegante horquilla de jade blanco tallado con motivos florales, de la que cuelgan finas cadenas de oro y borlas de seda teñida.' },
      { id: 'ACC_JADE_PENDANT', name: 'Colgante de Jade Espiritual y Nudo Infinito Chino', category: 'Accesorio Sagrado', culturalOrigin: 'Tradición Taoísta', description: 'Medallón circular Bi de jade puro suspendido por un elaborado cordón rojo trenzado en nudo de la buena fortuna y borla caída.' },
      { id: 'ACC_WAR_FAN', name: 'Abanico de Guerra Tessen / Sensu de Pan de Oro', category: 'Accesorio Sagrado', culturalOrigin: 'Corte & Estrategia Marcial', description: 'Abanico plegable con varillas exteriores de acero afilado y tela de seda pintada a mano con caligrafía o dragones sobre pan de oro.' },
      { id: 'ACC_TALISMANS_OFUDA', name: 'Talismanes Ofuda / Taoístas de Purificación Flotantes', category: 'Accesorio Sagrado', culturalOrigin: 'Daoísmo & Onmyodo', description: 'Tiras de papel amarillo sagrado escritas con tinta bermellón de cinabrio que canalizan encantamientos de sellado y protección espiritual.' },
      { id: 'ACC_KISERU_PIPE', name: 'Pipa Larga Tradicional de Latón y Ébano (Kiseru / Yandai)', category: 'Accesorio Sagrado', culturalOrigin: 'Cultura Clásica Oriental', description: 'Pipa esbelta con cazoleta y boquilla de latón dorado labrado unidas por un tubo de madera oscura de ébano pulido.' },
      { id: 'ACC_HULU_GOURD', name: 'Calabaza Hulu de Elixir Espiritual y Cintas Escarlata', category: 'Accesorio Sagrado', culturalOrigin: 'Xianxia / Wuxia', description: 'Calabaza seca natural pulida y lacada, atada a la cintura con un cordón escarlata, utilizada para contener vino medicinal o píldoras de cultivo.' },
      { id: 'ACC_PIBO_CLOAK', name: 'Capa Pibo / Hagoromo de Seda Celestial Flotante', category: 'Prenda Flotante', culturalOrigin: 'Mitología Celestial / Hanfu', description: 'Estola larga y etérea de gasa translúcida que flota grácilmente alrededor de los hombros y brazos del personaje, emulando hadas inmortales.' },
      { id: 'ACC_THUMB_RING', name: 'Anillo de Pulgar de Jade para Arquero (Ban Zhi)', category: 'Joyería & Cabello', culturalOrigin: 'Nobleza Dinástica', description: 'Anillo cilíndrico grueso de jade translúcido usado en el pulgar para disparar arcos compuestos con nobleza y destreza.' }
    ],
    spiritualMotifs: [
      'Dragón Celestial Dorado (Lóng / Ryū)',
      'Fénix Inmortal Carmesí (Fenghuang / Suzaku)',
      'Tigre Blanco del Viento Otoñal (Baihu / Byakko)',
      'Tortuga Negra y Serpiente Espiritual (Xuanwu / Genbu)',
      'Flor de Loto Sagrada de Nácar Flotante',
      'Nubes Celestiales Taoístas & Viento Divino',
      'Sello Yin-Yang Bagua con Trigramas Sagrados',
      'Bambú Verdeante & Flor de Ciruelo en la Nieve'
    ],
    silkPatterns: [
      'Brocado Imperial con Hilos de Oro Puro y Dragones',
      'Seda Damascada con Flores de Loto Flotantes',
      'Gasa Translúcida Multicapa con Hilos de Plata',
      'Sarga Negra Mate con Motivos Geométricos Ocultos',
      'Seda Carmesí con Patrón Tradicional de Olas (Seigaiha)',
      'Seda Chirimen con Textura Ondulada de Gran Caída'
    ],
    jadeColors: [
      { id: 'hetian_white', name: 'Jade Hetian Blanco Puro', hex: '#F0FDF4', desc: 'Virtud suprema, pureza e inmortalidad celestial' },
      { id: 'imperial_emerald', name: 'Jade Verde Esmeralda Imperial', hex: '#059669', desc: 'Rango noble supremo y vitalidad espiritual' },
      { id: 'black_ebony', name: 'Jade Negro Ébano de Sombra', hex: '#18181B', desc: 'Protección contra artes oscuras y sigilo' },
      { id: 'lavender_mystic', name: 'Jade Lavanda Místico', hex: '#C084FC', desc: 'Conexión con el reino astral y magia espiritual' },
      { id: 'blood_red', name: 'Jade Rojo Sangre / Cornalina', hex: '#DC2626', desc: 'Fuerza marcial, pasión y energía yang ardiente' }
    ],
    weapons: [
      { name: 'Espada Recta Jian de Doble Filo con Borla Sagrada', type: 'Espada', desc: 'El caballero de las armas, ligera y precisa con borla estabilizadora' },
      { name: 'Sable Curvo Dao con Hoja Ancha Forjada', type: 'Sable', desc: 'El general de las armas, demoledor en cortes fluidos' },
      { name: 'Katana Forjada en Acero Plegado Tamahagane', type: 'Sable', desc: 'Filo curvado perfecto pulido al espejo con línea hamon visible' },
      { name: 'Lanza Guandao con Cuchilla de Dragón Pesada', type: 'Arma de Asta', desc: 'Gran cuchilla curva montada sobre asta de madera férrea' },
      { name: 'Lanza Naginata con Hoja Curva y Protector Tsuba', type: 'Arma de Asta', desc: 'Elegante y veloz arma de asta para barridos letales' },
      { name: 'Cítara Guqin Encantada con Cuerdas de Seda Mágicas', type: 'Instrumento Marcial', desc: 'Proyecta ondas de choque sónicas y cortes de energía Qi' }
    ],
    auras: [
      'Qi Espiritual Dorado & Hojas de Loto Luminosas',
      'Niebla de Tinta / Suibokuga Flotante con Caracteres Antiguos',
      'Fuego de Fénix Carmesí & Cenizas Chispeantes',
      'Aura Relampagueante Azur del Dragón del Trueno',
      'Flores de Cerezo Iluminadas Flotando en el Viento',
      'Sin Aura (Aspecto Natural Puramente Físico)'
    ]
  },

  'Cyberpunk': {
    styleName: 'Cyberpunk',
    title: 'Cyberpunk & Alta Tecnología Distópica',
    tag: '⚡ High-Tech / Low-Life / Chrome',
    subtitle: 'Implantes Cibernéticos, Neón Cromado y Protección Táctica',
    description: 'Armaduras balísticas modulares, visores ópticos HUD, cables neuronales trenzados, placas de fibra de carbono reflectante e implantes de combate.',
    traditions: [
      {
        id: 'NETRUNNER',
        name: 'Netrunner / Hacker de la Red Profunda',
        subtitle: 'Navegante de la Matriz Cuántica',
        category: 'Cibernética & Datos',
        description: 'Chaqueta aislante con refrigeración líquida interna, visor neural monocular, puertos de conexión en las sienes y cables de datos bioluminiscentes.',
        iconTag: '💾 Netrunner / Cyber',
        suggestedArmor: ['Chaleco de Fibra Balística y Kevlar Hexagonal', 'Guantelete Táctico con Teclado Holográfico'],
        suggestedAccessories: ['Visor Monocular HUD de Realidad Aumentada', 'Cables de Datos Neuronales Trenzados con LED Neón', 'Chipset Cerebral Expuesto con Disipador de Cobre', 'Deck de Intrusión Cyberdeck Portátil'],
        suggestedWeapon: 'Pistola Inteligente con Guiado Láser Autodirigido',
        suggestedMotif: 'Circuito Impreso Cuántico & Glitch Hexagonal',
        suggestedSilk: 'Tejido de Fibra de Carbono con Filamentos Neón',
        suggestedJade: 'Cromo Espejado Pulido',
        suggestedAura: 'Glitch Holográfico Azur & Código Binario Flotante'
      },
      {
        id: 'CYBER_SAMURAI',
        name: 'Ciber-Samurái / Ronin Callejero',
        subtitle: 'Filo Térmico y Código de Honor Urbano',
        category: 'Combate Cibernético',
        description: 'Armadura lamelar cibernética de grafeno, máscara de respiración sintética con colmillos cromados, hombreras balísticas y katana de plasma térmico.',
        iconTag: '⚔️ Ciber-Ronin',
        suggestedArmor: ['Pechera de Grafeno y Placas Lamelares de Titanio', 'Hombreras Balísticas Angulares Arasaka', 'Grebas Cibernéticas Hidráulicas con Amortiguación'],
        suggestedAccessories: ['Máscara Facial Cibernética Menpo de Cromo con Filtro', 'Visor Óptico Cyber-Visor de Tres Lentes', 'Cinturón Táctico con Baterías de Supercondensador'],
        suggestedWeapon: 'Katana Térmica de Plasma de Alta Frecuencia',
        suggestedMotif: 'Dragón Mecánico de Neón Rojo y Kanjis Callejeros',
        suggestedSilk: 'Kevlar Negro Mate Antirreflectante',
        suggestedJade: 'Titanio Iridiscente Anodizado',
        suggestedAura: 'Chispas de Descarga Eléctrica & Vapor de Nitrógeno'
      },
      {
        id: 'CORP_ELITE_SEC',
        name: 'Seguridad Corporativa / Élite Arasaka-Militech',
        subtitle: 'Fuerza de Choque Ejecutiva de Megacorporación',
        category: 'Militar Corporativo',
        description: 'Traje blindado de nanopolímeros con corbata ignífuga, hombreras monolíticas con logotipos corporativos iluminados y casco de asalto sellado.',
        iconTag: '🏢 Corp Sec',
        suggestedArmor: ['Exo-Peto Balístico Integral de Polímero Cerámico', 'Protectores Brazo a Brazo de Titanio Negro Mate', 'Espinilleras de Choque con Exoesqueleto'],
        suggestedAccessories: ['Casco Táctico Sellado con Visor Polarizado Oro', 'Emblema Holográfico de Megacorporación Flotante', 'Arnés de Carga Magnética con Cintas Reforzadas'],
        suggestedWeapon: 'Subfusil Compacto Bullpup de Proyectiles Magnéticos',
        suggestedMotif: 'Triángulo Corporativo Monolítico & Hexágonos',
        suggestedSilk: 'Sartorial Blindado Hidrófugo y Seda Sintética',
        suggestedJade: 'Oro de Conectores Microelectrónicos',
        suggestedAura: 'Red de Escaneo Láser Rojo & Matriz de Detección'
      }
    ],
    armorPieces: [
      { id: 'ARM_CYBER_CHEST', name: 'Exo-Peto de Nanopolímeros y Placas de Cerámica Balística', category: 'Armadura Torso', culturalOrigin: 'Ingeniería Megacorp', description: 'Coraza pectoral de alta densidad resistente a impactos sónicos y calor de plasma con batería interna.' },
      { id: 'ARM_CYBER_SHOULDERS', name: 'Hombreras Angulares de Grafeno con LED de Estado', category: 'Hombreras & Brazos', culturalOrigin: 'Militech Táctico', description: 'Hombreras articuladas con ranuras de ventilación y luces de diagnóstico biométrico en tiempo real.' },
      { id: 'ARM_CYBER_ARMS', name: 'Brazos de Exoesqueleto Hidráulico con Servomotores', category: 'Hombreras & Brazos', culturalOrigin: 'Cyberpunk Industrial', description: 'Brazaletes reforzados con pistones neumáticos visibles y articulaciones de aleación ligera.' },
      { id: 'ARM_CYBER_HELMET', name: 'Casco de Asalto Hermético con Visera Holográfica HUD', category: 'Cabeza & Máscara', culturalOrigin: 'Black-Ops Cyber', description: 'Casco táctico completo con visión nocturna, térmica y enlace satelital con interfaz neuronal.' },
      { id: 'ARM_CYBER_GREAVES', name: 'Grebas de Impacto con Propulsores de Salto y Exo-Pies', category: 'Piernas & Pies', culturalOrigin: 'Submundo Cyberpunk', description: 'Botas cibernéticas reforzadas con suspensión magnética para absorber caídas de edificios.' }
    ],
    culturalAccessories: [
      { id: 'ACC_CYBER_VISOR', name: 'Visor Óptico Cyberpunk de Realidad Aumentada', category: 'Cabeza & Máscara', culturalOrigin: 'Cultura Tech Calle', description: 'Gafas de una sola pieza envolvente con proyección de datos tácticos y mapas de calor.' },
      { id: 'ACC_CYBER_RESPIRATOR', name: 'Respirador Cibernético con Cartuchos Filtrantes Iluminados', category: 'Cabeza & Máscara', culturalOrigin: 'Subniveles Tóxicos', description: 'Máscara inferior con doble filtro de carbono activado y luces de neón en las válvulas de escape.' },
      { id: 'ACC_CYBER_CABLES', name: 'Arnés de Conexiones Neuronales y Cables de Datos con Neón', category: 'Accesorio Sagrado', culturalOrigin: 'Deep Net Cult', description: 'Manzanas de cables mallados en espiral que conectan puertos corporales con interfaces externas.' },
      { id: 'ACC_CYBER_HOLOTAG', name: 'Emisor Holográfico Flotante con Credenciales Digitales', category: 'Accesorio Sagrado', culturalOrigin: 'BTL & Black Markets', description: 'Pequeño proyector en el hombro que emite hologramas publicitarios o identificadores cifrados.' }
    ],
    spiritualMotifs: [
      'Glitch Hexagonal y Ruido Digital de Baja Frecuencia',
      'Dragón Mecánico de Neón con Trazas de Placa Madre',
      'Calavera Cibernética con Ojo de Láser Carmesí',
      'Sello de Advertencia de Alta Tensión y Peligro Bioquímico',
      'Logotipo Monocromo de Megacorporación Global',
      'Kanjis Japoneses de Neón Callejero Brillante'
    ],
    silkPatterns: [
      'Fibra de Carbono Tejida con Filamentos Electroluminiscentes',
      'Kevlar Antibalas de Patrón Hexagonal Reflectante',
      'Neopreno Táctico Negro con Costuras Térmicas Selladas',
      'Tejido Sintético Camaleónico con Cambio de Color Dinámico',
      'Mylar Aislante Plateado con Efecto Espejado'
    ],
    jadeColors: [
      { id: 'chrome_mirror', name: 'Cromo Espejado Pulido', hex: '#E2E8F0', desc: 'Reflexión metálica impecable de rascacielos corporativos' },
      { id: 'neon_cyan', name: 'Azul Neón / Cian Cibernético', hex: '#06B6D4', desc: 'Energía de datos de la red y pantallas holográficas' },
      { id: 'neon_magenta', name: 'Magenta Neón / Rosa Láser', hex: '#EC4899', desc: 'Estética de callejones y clubes nocturnos clandestinos' },
      { id: 'toxic_amber', name: 'Ámbar Radiactivo / Advertencia', hex: '#F59E0B', desc: 'Sistemas de alerta industrial y celdas de energía' },
      { id: 'stealth_matte', name: 'Negro Mate de Absorción de Radar', hex: '#090A0C', desc: 'Operaciones clandestinas y sigilo militar' }
    ],
    weapons: [
      { name: 'Katana Térmica de Plasma con Filo Incandescente', type: 'Arma Blanca Tech', desc: 'Hoja de aleación ultraafilada con canal de plasma a 3000°C' },
      { name: 'Pistola Inteligente con Visor de Guiado Neural', type: 'Arma de Fuego Tech', desc: 'Dispara micromuniciones autoestabilizadas guiadas por IA' },
      { name: 'Rifle de Asalto Electromagnético Gauss / Railgun', type: 'Arma Pesada', desc: 'Acelerador magnético que atraviesa coberturas blindadas' },
      { name: 'Cuchillas Monomoleculares Ocultas en Antebrazos (Mantis)', type: 'Implante Ofensivo', desc: 'Hojas retráctiles de un átomo de grosor para combate cuerpo a cuerpo' }
    ],
    auras: [
      'Glitch Holográfico Azur & Código Binario Flotante',
      'Chispas de Descarga Eléctrica & Vapor de Nitrógeno Frío',
      'Aura de Neón Magenta y Escaneo de Líneas Láser',
      'Distorsión de Calor Térmico y Resplandor de Plasma',
      'Sin Aura (Aspecto Físico Puramente Realista)'
    ]
  },

  'Fantasía Tradicional': {
    styleName: 'Fantasía Tradicional',
    title: 'Fantasía Tradicional & Alta Épica Medieval',
    tag: '🛡️ High Fantasy / Élfico / Dragontino',
    subtitle: 'Caballeros de Honor, Magia Arcana y Herrería Legendaria',
    description: 'Armaduras de placas de acero templado, filigrana de mithril élfico, capas con broches heráldicos, gemas rúnicas encantadas y báculos de poder.',
    traditions: [
      {
        id: 'ELVEN_ROYALTY',
        name: 'Guardia Real Élfica / Noble de las Estrellas',
        subtitle: 'Gracia Inmortal y Filigrana de Mithril',
        category: 'Alta Fantasía Élfica',
        description: 'Armadura ligera de hojas superpuestas de mithril plateado, capa de seda de hoja perenne, diadema de plata lunar y arco largo grabado con runas estelares.',
        iconTag: '🧝 Élfico / Mithril',
        suggestedArmor: ['Coraza Élfica de Escamas de Hoja Plateada', 'Hombreras de Filigrana de Plata y Vidrio Estelar', 'Brazales de Cuero de Bosque Antiguo'],
        suggestedAccessories: ['Diadema Coronaria Élfica con Gema de Lágrima Lunar', 'Capa de Viaje de Hoja Verde con Broche de Lórien', 'Anillo de Poder con Runas Arcanas Brillantes'],
        suggestedWeapon: 'Arco Largo Élfico Tallado en Madera de Mallorn',
        suggestedMotif: 'Árbol Sagrado de la Vida & Hojas de Plata',
        suggestedSilk: 'Seda Élfica Hilada con Luz de Luna',
        suggestedJade: 'Gema Lágrima de Luna Plateada',
        suggestedAura: 'Resplandor Astral Plateado y Brillo de Luciérnagas'
      },
      {
        id: 'DRAGON_KNIGHT',
        name: 'Caballero Dragontino / Orden de las Escamas',
        subtitle: 'Fuego Ancestral y Placas de Hierro Negro',
        category: 'Orden de Caballería',
        description: 'Imponente armadura completa de placas forjadas en fuego de dragón, tabardo heráldico con blasón de dragón bicéfalo, gran mandoble llameante y yelmo con cuernos esculpidos.',
        iconTag: '🐉 Caballero Dragón',
        suggestedArmor: ['Arnés Completo de Placas Forjadas en Fuego de Dragón', 'Hombreras de Escamas de Wyrm con Bordes Dorados', 'Yelmo de Caballero con Cresta de Cuernos Forjados', 'Grebas de Acero Templado Articuladas'],
        suggestedAccessories: ['Tabardo de Terciopelo Escarlata con Blasón de Dragón', 'Cinturón de Campeón con Hebilla de Garra de Fuego', 'Capa Pesada con Forro de Piel de Lobo Ártico'],
        suggestedWeapon: 'Mandoble Pesado a Dos Manos con Filo Rúnico de Fuego',
        suggestedMotif: 'Dragón Rampante con Espada Flamígera',
        suggestedSilk: 'Terciopelo Escarlata Grueso con Bordados en Hilo de Oro',
        suggestedJade: 'Rubí Corazón de Dragón Sangriento',
        suggestedAura: 'Llamas Sagradas Danzantes & Brasas Flotantes'
      },
      {
        id: 'HIGH_MAGE',
        name: 'Archimago de la Torre Arcana',
        subtitle: 'Maestría de los Elementos y Runas Antiguas',
        category: 'Magia Arcana',
        description: 'Túnicas ceremoniales de terciopelo azul noche con constelaciones bordadas, cuello alto rígido, orbe de levitación, báculo arcano coronado por un cristal flotante.',
        iconTag: '🔮 Alta Magia',
        suggestedArmor: ['Pectoral de Cuero Suave Encantado con Runas de Protección', 'Manto de Magisterio con Hombreras de Cristal Arcana'],
        suggestedAccessories: ['Tomo de Hechizos Encadenado al Cinturón', 'Orbe de Cristal de Adivinación Flotante', 'Amuleto del Ojo Que Todo lo Ve en Oro Blanco'],
        suggestedWeapon: 'Báculo Arcano de Fresno Blanco con Cristal de Mana Flotante',
        suggestedMotif: 'Círculo Rúnico de Siete Estrellas Arcanas',
        suggestedSilk: 'Seda Azul Noche con Constelaciones de Hilo de Plata',
        suggestedJade: 'Zafiro Arcano de Mana Profundo',
        suggestedAura: 'Glifos Arcanos Flotantes & Órbitas de Luz Púrpura'
      }
    ],
    armorPieces: [
      { id: 'ARM_MED_PLATE', name: 'Coraza Completa de Placas de Acero Templado', category: 'Armadura Torso', culturalOrigin: 'Reino Humano Central', description: 'Peto y espaldar de acero pulido al espejo con nervadura central para desviar estocadas.' },
      { id: 'ARM_ELVEN_CUIRASS', name: 'Coraza Élfica de Escamas de Hoja Plateada', category: 'Armadura Torso', culturalOrigin: 'Reinos Élficos', description: 'Placas ligeras superpuestas de aleación de mithril con grabados vegetales inspirados en árboles milenarios.' },
      { id: 'ARM_KNIGHT_SHOULDERS', name: 'Guardahombros de Justa con Guardas de Cuello Reforzadas', category: 'Hombreras & Brazos', culturalOrigin: 'Órdenes de Caballería', description: 'Grandes hombreras de placas con escarcela para proteger la clavícula y cuello.' },
      { id: 'ARM_GREAT_HELM', name: 'Yelmo de Caballero con Visor Ranurado y Penacho de Plumas', category: 'Cabeza & Máscara', culturalOrigin: 'Cruzadas Medievales', description: 'Yelmo cerrado que ofrece protección total con ranura estrecha de visión y penacho heráldico.' },
      { id: 'ARM_GREAVES_SABATONS', name: 'Grebas y Escarpines de Acero Articulado para Caballería', category: 'Piernas & Pies', culturalOrigin: 'Alta Nobleza Feudal', description: 'Protección completa de piernas con rodilleras en flor de lis y calzado de placas flexibles.' }
    ],
    culturalAccessories: [
      { id: 'ACC_HERALDIC_TABARD', name: 'Tabardo de Terciopelo con Blasón Heráldico Bordado', category: 'Prenda Flotante', culturalOrigin: 'Corte Feudal', description: 'Prenda sin mangas vestida sobre la armadura con los colores y emblemas de la casa noble.' },
      { id: 'ACC_RUNE_AMULET', name: 'Amuleto Rúnico de Protección Arcana con Cadena de Oro', category: 'Accesorio Sagrado', culturalOrigin: 'Cónclave de Sabios', description: 'Medallón grabado con encantamientos defensivos que disipan maleficios.' },
      { id: 'ACC_SPELL_TOME', name: 'Grimorio de Hechizos Encuadernado en Piel de Dragón con Cierre de Bronce', category: 'Accesorio Sagrado', culturalOrigin: 'Colegios Arcanos', description: 'Libro de conjuros ancestrales sujeto al cinto con cadenas de plata bendita.' },
      { id: 'ACC_WAR_HORN', name: 'Cuerno de Batalla Forjado en Marfil de Behemoth con Boquilla de Plata', category: 'Accesorio Sagrado', culturalOrigin: 'Campeones de la Frontera', description: 'Instrumento para convocar refuerzos cuyo bramido infunde valor a los aliados.' }
    ],
    spiritualMotifs: [
      'León Rampante Coronado con Espada de Justicia',
      'Árbol Sagrado de la Vida con Frutos de Cristal',
      'Dragón Alado Escupiendo Fuego Sagrado',
      'Círculo de Runas Antiguas de Poder Elemental',
      'Espada Clavada en el Yunque de la Leyenda',
      'Grypho de Oro sobre Fondo Azur Real'
    ],
    silkPatterns: [
      'Terciopelo Escarlata Real con Brocado de Flores de Lis en Oro',
      'Seda Élfica Translúcida con Hilos de Plata Estelar',
      'Lana Virgen Pesada Teñida en Azul Ultramar',
      'Lino Crudo Reforzado con Cuero Repujado a Mano',
      'Malla de Anillos de Mithril Entrelazada de Alta Densidad'
    ],
    jadeColors: [
      { id: 'royal_gold', name: 'Oro Real de Corona', hex: '#EAB308', desc: 'Nobleza, divinidad y linaje de reyes antiguos' },
      { id: 'mithril_silver', name: 'Plata de Mithril Élfico', hex: '#E2E8F0', desc: 'Pureza mágica, ligereza y acero bendito' },
      { id: 'dragon_ruby', name: 'Rubí Corazón de Dragón', hex: '#DC2626', desc: 'Fuego primordial, coraje marcial y sangre heroica' },
      { id: 'arcane_sapphire', name: 'Zafiro de Mana Profundo', hex: '#2563EB', desc: 'Conocimiento arcano y dominio de los cielos' },
      { id: 'emerald_forest', name: 'Esmeralda de Bosque Ancestral', hex: '#16A34A', desc: 'Vida eterna, armonía druídica y naturaleza' }
    ],
    weapons: [
      { name: 'Mandoble Legendario de Acero Santo a Dos Manos', type: 'Espada Pesada', desc: 'Gran espada con gavilanes curvos bendecida por el sumo sacerdote' },
      { name: 'Arco Largo Élfico de Madera de Tejo y Cuerda de Seda', type: 'Arma a Distancia', desc: 'Precisión mortal a cientos de metros con flechas de pluma de cisne' },
      { name: 'Báculo de Mago con Cristal de Mana Encapsulado', type: 'Foco Mágico', desc: 'Canalizador de rayos arcanos y barreras mágicas' },
      { name: 'Martillo de Guerra de Forja Enana con Runas de Impacto', type: 'Arma Contundente', desc: 'Cabeza pesada de hierro meteórico capaz de quebrar corazas' }
    ],
    auras: [
      'Aura de Luz Sagrada Dorada y Partículas de Polvo Estelar',
      'Glifos Arcanos Azules Orbitando en Espirales Alrededor del Cuerpo',
      'Llamas de Fuego Dragontino Danzantes en las Hombreras',
      'Brisa de Hojas y Polen Mágico Flotante',
      'Sin Aura (Presencia Puramente Física y Noble)'
    ]
  },

  'Gótico': {
    styleName: 'Gótico',
    title: 'Gótico, Vampírico & Barroco Oscuro',
    tag: '🦇 Gothic / Aristocracia Oscura / Nigromancia',
    subtitle: 'Elegancia Macabra, Terciopelo Negro, Encajes y Filigrana Siniestra',
    description: 'Corsés victorianos de terciopelo obsidiana, capas con cuellos almidonados de vampiro, relicarios de plata oxidada, crucifijos góticos y anillos con rubíes sangre.',
    traditions: [
      {
        id: 'VAMPIRE_ARISTOCRAT',
        name: 'Señor / Dama Vampírica Victoriana',
        subtitle: 'Seducción Eterna y Nobleza Sangrienta',
        category: 'Gótico Victoriano',
        description: 'Frac o vestido de corte victoriano en terciopelo negro y forro carmesí, capa con cuello alzado de murciélago, bastón con estoque oculto y guardapelo de sangre.',
        iconTag: '🩸 Aristocracia Vampírica',
        suggestedArmor: ['Corsé Victoriano Estructurado de Terciopelo y Huesos de Acero', 'Hombreras de Filigrana de Plata Ennegrecida con Cuervos'],
        suggestedAccessories: ['Capa de Ópera Negra con Forro de Seda Sangre', 'Gargantilla de Terciopelo con Cruz de Rubí', 'Anillo de Sello con Gema de Sangre Sellada', 'Bastón de Ébano con Cabeza de Lobo de Plata'],
        suggestedWeapon: 'Estoque Oculto en Bastón de Ébano y Plata',
        suggestedMotif: 'Murciélago Heráldico & Rosas Negras Marchitas',
        suggestedSilk: 'Terciopelo Negro Noche y Encaje de Chantilly',
        suggestedJade: 'Rubí Sangre de Pichón Profundo',
        suggestedAura: 'Niebla Nocturna Escarlata & Mariposas Negras Flotantes'
      },
      {
        id: 'NECROMANCER_SCHOLAR',
        name: 'Nigromante / Erudito de los Criptas',
        subtitle: 'Secretos de Ultratumba y Almas Atadas',
        category: 'Ocultismo & Sombras',
        description: 'Túnicas andrajosas de lino negro y pieles oscuras, pectoral con huesos tallados, farol de fuego fatuo espectral verde y báculo con cráneo enjoyado.',
        iconTag: '💀 Nigromancia',
        suggestedArmor: ['Coraza de Huesos Tallados y Placas de Hierro Oxidado', 'Brazales de Cuero Negro con Reliquias Óseas'],
        suggestedAccessories: ['Farol de Fuego Fatuo Espectral Verde al Cinto', 'Grimorio Necronómico de Piel Pálida', 'Rosario de Vértebras y Cuentas de Obsidiana'],
        suggestedWeapon: 'Guadaña de Cosechador de Almas con Filo Esmeralda',
        suggestedMotif: 'Cráneo Coronado & Luna Llena Eclipsada',
        suggestedSilk: 'Lino Negro Deshilachado y Sedas Fúnebres',
        suggestedJade: 'Obsidiana Negra Volcánica',
        suggestedAura: 'Fuego Fatuo Verde Espectral & Susurros de Sombras'
      }
    ],
    armorPieces: [
      { id: 'ARM_GOTH_CORSET', name: 'Corsé Armadurado de Cuero Negro y Ballenas de Acero', category: 'Armadura Torso', culturalOrigin: 'Gótico Victoriano', description: 'Prenda ceñida estructurada que proporciona protección rígida con elegancia barroca.' },
      { id: 'ARM_GOTH_PAULDRONS', name: 'Hombreras Esculpidas con Gárgolas y Rosas de Plata', category: 'Hombreras & Brazos', culturalOrigin: 'Catedrales Góticas', description: 'Placas de metal oscuro labradas con tracerías arquitectónicas y relieves fúnebres.' },
      { id: 'ARM_GOTH_MASK', name: 'Máscara de Filigrana Metálica de Encaje Veneciano', category: 'Cabeza & Máscara', culturalOrigin: 'Baile de Máscaras Oscuro', description: 'Máscara intrincada de metal calado con incrustaciones de piedras negras.' },
      { id: 'ARM_GOTH_BOOTS', name: 'Botas Altas de Cuero Negro con Múltiples Hebillas de Plata', category: 'Piernas & Pies', culturalOrigin: 'Subcultura Gótica', description: 'Calzado militarizado de cuero pesado con puntera reforzada y hebillas victorianas.' }
    ],
    culturalAccessories: [
      { id: 'ACC_GOTH_CHOKER', name: 'Gargantilla de Terciopelo con Crucifijo Barroco de Rubí', category: 'Joyería & Cabello', culturalOrigin: 'Moda Gótica de Época', description: 'Collar ceñido al cuello de terciopelo suave con colgante religioso decadente.' },
      { id: 'ACC_GOTH_CAPE', name: 'Capa Larga con Capucha Forrada en Raso Carmesí', category: 'Prenda Flotante', culturalOrigin: 'Tradición Vampírica', description: 'Manto pesado que roza el suelo con caída dramática y cierre de cadena de plata.' },
      { id: 'ACC_GOTH_LANTERN', name: 'Farol de Fuego Fatuo Espectral Verde', category: 'Accesorio Sagrado', culturalOrigin: 'Criptas y Mausoleos', description: 'Lámpara de hierro forjado que arde con una llama fría que revela lo invisible.' },
      { id: 'ACC_GOTH_PARASOL', name: 'Sombrilla de Encaje Negro con Mango de Marfil Tallado', category: 'Accesorio Sagrado', culturalOrigin: 'Corte Victoriana', description: 'Sombrilla aristocrática para protegerse de la luz solar con elegancia sombría.' }
    ],
    spiritualMotifs: [
      'Rosa Negra Marchita con Espinas Sangrantes',
      'Murciélago con Alas Desplegadas y Ojos de Rubí',
      'Cruz Gótica Catedralicia con Tracería Calada',
      'Cráneo Humano Coronado con Hiedra de Plata',
      'Cuervo Posado sobre Reloj de Arena Roto'
    ],
    silkPatterns: [
      'Terciopelo Negro Devoré con Motivos Barrocos',
      'Encaje Francés Chantilly de Flores Oscuras',
      'Seda Raso Escarlata Sangre de Alta Densidad',
      'Brocado Damasco Tenebroso de Fondo Mate',
      'Malla de Red Negra Fina con Cristales'
    ],
    jadeColors: [
      { id: 'pigeon_blood_ruby', name: 'Rubí Sangre de Pichón', hex: '#991B1B', desc: 'Pasión inmortal, sed de sangre y realeza vampírica' },
      { id: 'obsidian_void', name: 'Obsidiana Negra Absoluta', hex: '#0B0B0E', desc: 'Misterio insondable, absorción de luz y silencio' },
      { id: 'aged_silver', name: 'Plata Oxidada Ennegrecida', hex: '#94A3B8', desc: 'Reliquias sagradas marchitas por el tiempo' },
      { id: 'amethyst_twilight', name: 'Amatista Púrpura Sombrío', hex: '#7E22CE', desc: 'Conexión con el más allá y magia nigromántica' },
      { id: 'emerald_ghoul', name: 'Esmeralda Fuego Fatuo', hex: '#10B981', desc: 'Energía espectral y luminiscencia de ultratumba' }
    ],
    weapons: [
      { name: 'Estoque Florentino con Empuñadura en Cruz Gótica', type: 'Arma Blanca Fina', desc: 'Hoja esbelta de acero toledano con gavilán en filigrana' },
      { name: 'Guadaña Ritual de Plata Bendita y Ébano', type: 'Arma de Asta', desc: 'Cuchilla curvada pulida para recolectar esencias vitales' },
      { name: 'Dagas Gemelas de Sacrificio con Canal de Sangre', type: 'Dagas', desc: 'Hojas serradas con mangos de hueso pulido' }
    ],
    auras: [
      'Niebla Nocturna Púrpura y Escarlata Danzante',
      'Murciélagos y Mariposas Negras Espectrales en Vuelo',
      'Llamas Frías de Fuego Fatuo Verde Esmeralda',
      'Gotas de Sangre Suspendidas en Levitas Místicas',
      'Sin Aura (Oscuridad Sobria y Amenazante)'
    ]
  },

  'Steampunk': {
    styleName: 'Steampunk',
    title: 'Steampunk & Revolución Industrial Retrofuturista',
    tag: '⚙️ Vapor / Latón / Engranajes',
    subtitle: 'Mecanismos de Relojería, Lentes de Bronce y Vapor a Presión',
    description: 'Corazas de cuero curtido con manómetros integrados, gafas protectoras con lentes intercambiables, guanteletes con pistones de latón y pistolas de chispa voltaica.',
    traditions: [
      {
        id: 'AIRSHIP_CAPTAIN',
        name: 'Capitán de Dirigible / Navegante del Éter',
        subtitle: 'Señor de las Alturas y los Cielos Nublados',
        category: 'Aeronáutica Steampunk',
        description: 'Chaqueta de oficial de cuero con botones de latón dorado, monóculo de precisión náutica, brújula aetérea al pecho y sable de oficial a vapor.',
        iconTag: '🎈 Capitán Aéreo',
        suggestedArmor: ['Peto de Cuero Curtido con Remaches de Cobre y Manómetro', 'Hombreras de Cuero con Placas Articuladas de Latón'],
        suggestedAccessories: ['Gafas Goggles de Aviador con Lentes de Aumento Graduadas', 'Brújula Aetérea de Bolsillo con Cadena de Latón', 'Arnés de Vuelo con Tanque de Gas Comprimido'],
        suggestedWeapon: 'Pistola Flintlock Voltaica con Bobina Tesla de Cobre',
        suggestedMotif: 'Engranaje de Doce Dientes & Alas Mecánicas',
        suggestedSilk: 'Tweed Escocés Grueso y Cuero Envejecido al Aceite',
        suggestedJade: 'Latón Dorado Envejecido',
        suggestedAura: 'Vaho de Vapor Cálido & Chispas de Relojería'
      },
      {
        id: 'CLOCKWORK_ALCHEMIST',
        name: 'Alquimista de Relojería / Ingeniero de Autómatas',
        subtitle: 'Fórmulas Químicas y Precisión Mecánica',
        category: 'Ciencia & Alquimia',
        description: 'Mandil de cuero impermeable a reactivos, guantelete articulado con herramientas miniaturizadas, cinturón con viales de éter brillante y máscara con respirador de cobre.',
        iconTag: '⚙️ Alquimista',
        suggestedArmor: ['Mandil Blindado de Cuero Pesado y Placas de Bronce', 'Guantelete Mecánico de Relojería con Engranajes Expuestos'],
        suggestedAccessories: ['Cinturón con Frascos de Reactivos Químicos Brillantes', 'Máscara con Filtro de Carbón y Válvula de Latón', 'Catalejo Plegable de Latón con Micro-Medidor'],
        suggestedWeapon: 'Cañón de Descarga Alquímica con Tubos de Vidrio Refractario',
        suggestedMotif: 'Matraz Alquímico Cruzado con Llave Inglesa',
        suggestedSilk: 'Lona Impermeabilizada de Algodón Pesado',
        suggestedJade: 'Cobre Pulido Brillante',
        suggestedAura: 'Vapor Esmeralda Químico & Resplandor Voltaico'
      }
    ],
    armorPieces: [
      { id: 'ARM_STEAM_CHEST', name: 'Peto de Cuero Curtido con Placas de Latón y Manómetro Central', category: 'Armadura Torso', culturalOrigin: 'Talleres Industriales', description: 'Coraza protectora con indicadores analógicos de presión de vapor y válvulas de escape.' },
      { id: 'ARM_STEAM_GAUNTLET', name: 'Guantelete de Relojería con Pistones Neumáticos y Engranajes', category: 'Hombreras & Brazos', culturalOrigin: 'Ingeniería Mecánica', description: 'Brazo articulado accionado por micro-pistones que multiplica la fuerza de agarre.' },
      { id: 'ARM_STEAM_GOGGLES', name: 'Gafas Goggles de Aviador con Múltiples Lentes Plegables', category: 'Cabeza & Máscara', culturalOrigin: 'Gremio de Exploradores', description: 'Gafas de bronce con montura de cuero y lentes tintadas intercambiables para filtrar humo y luz.' },
      { id: 'ARM_STEAM_BOOTS', name: 'Botas de Ingeniero con Suela de Goma Reforzada y Espuelas Dentadas', category: 'Piernas & Pies', culturalOrigin: 'Minas y Calderas', description: 'Calzado resistente al calor con placas protectoras en las espinillas.' }
    ],
    culturalAccessories: [
      { id: 'ACC_STEAM_WATCH', name: 'Reloj de Bolsillo con Esfera Esqueleto y Escape Tourbillon', category: 'Accesorio Sagrado', culturalOrigin: 'Alta Relojería', description: 'Cronómetro de precisión en caja de oro y latón con tapa grabada.' },
      { id: 'ACC_STEAM_JETPACK', name: 'Mochila Propulsora de Vapor a Presión con Dos Cilindros de Cobre', category: 'Prenda Flotante', culturalOrigin: 'Aeronáutica Experimental', description: 'Artefacto dorsal con toberas orientables que permite planear en ráfagas cortas.' },
      { id: 'ACC_STEAM_FLASKS', name: 'Cartuchera con Tubos de Vidrio Sellados con Éter Volátil', category: 'Accesorio Sagrado', culturalOrigin: 'Laboratorios de Alquimia', description: 'Frascos luminiscentes sujetos por cinchas de cuero que contienen compuestos reactivos.' }
    ],
    spiritualMotifs: [
      'Engranaje Solar con Agujas de Reloj en Punto',
      'Dirigible Flotando sobre Nubes de Humo Industrial',
      'Bobina Tesla con Relámpagos Eléctricos Atraídos',
      'Brújula Magnética de Rosa de los Vientos de Latón',
      'Autómata Mecánico con Corazón de Cuerda'
    ],
    silkPatterns: [
      'Tweed de Lana Pesada con Cuadros Marrón y Ocre',
      'Lona de Algodón Encerada Impermeable',
      'Cuero Envejecido Marrón Tabaco con Pátina',
      'Seda de Rayas Diplomáticas de Época Victoriana',
      'Malla de Alambre de Bronce Flexible'
    ],
    jadeColors: [
      { id: 'steampunk_brass', name: 'Latón Dorado Industrial', hex: '#D97706', desc: 'Material predilecto de manómetros, tubos y engranajes' },
      { id: 'steampunk_copper', name: 'Cobre Rojizo Pulido', hex: '#B45309', desc: 'Excelente conductor de calor y electricidad voltaica' },
      { id: 'leather_cognac', name: 'Cuero Coñac Envejecido', hex: '#78350F', desc: 'Resistencia rústica curtida al aceite' },
      { id: 'ether_cyan', name: 'Luz de Éter Azulino', hex: '#0EA5E9', desc: 'Fluido misterioso y combustible de alta energía' },
      { id: 'smoke_iron', name: 'Hierro Forjado de Caldera', hex: '#334155', desc: 'Resistencia estructural a presiones extremas' }
    ],
    weapons: [
      { name: 'Carabina de Aire Comprimido con Mira Telescópica de Bronce', type: 'Arma de Fuego a Vapor', desc: 'Disparo silencioso de gran potencia accionado por tanque dorsal' },
      { name: 'Espada Sierra a Vapor con Dientes Giratorios de Acero', type: 'Arma Motorizada', desc: 'Filo rotatorio que desgarra madera, cueros y placas blindadas' },
      { name: 'Pistola de Chispa Voltaica con Bobinas de Inducción', type: 'Arma Eléctrica', desc: 'Genera arcos voltaicos que paralizan al objetivo' }
    ],
    auras: [
      'Chorros de Vapor de Agua Caliente y Olor a Aceite de Máquinas',
      'Chispas Voltaicas de Color Azul Aether Chisporroteando',
      'Giro Rítmico de Engranajes Holográficos Transparentes',
      'Resplandor Cálido de Lámpara de Filamento Incandescente',
      'Sin Aura (Mecánica Pura y Realismo Ingenieril)'
    ]
  },

  'Militar': {
    styleName: 'Militar',
    title: 'Militar, Táctico Operativo & Élite de Gala',
    tag: '🎖️ Táctico / Fuerzas Especiales / Oficial',
    subtitle: 'Disciplina Marcial, Camuflaje Operativo y Condecoraciones',
    description: 'Chalecos portaplacas balísticos con sistema MOLLE, correajes tácticos de liberación rápida, fundas de arma Kydex, condecoraciones de gala y uniformes reglamentarios.',
    traditions: [
      {
        id: 'SPEC_OPS_OPERATOR',
        name: 'Operador de Fuerzas Especiales (Black-Ops)',
        subtitle: 'Infiltración Nocturna y Eficiencia Táctica',
        category: 'Operaciones Especiales',
        description: 'Uniforme de combate multicam oscuro, portaplacas balístico de bajo perfil, casco FAST con montura para visión nocturna y silenciador táctico.',
        iconTag: '🎯 Black-Ops',
        suggestedArmor: ['Portaplacas Balístico Modular con Placas Cerámicas Nivel IV', 'Hombreras Tácticas de Kevlar Antifragmentación'],
        suggestedAccessories: ['Casco Táctico FAST con Montura NVG y Auriculares Comms', 'Cinturón de Primera Línea con Funda Rápida Kydex', 'Torniquete CAT y Bolsa de Primeros Auxilios IFAK'],
        suggestedWeapon: 'Carabina Táctica con Supresor de Sonido y Mira Holográfica',
        suggestedMotif: 'Calavera Táctica con Cuchillo de Combate',
        suggestedSilk: 'Cordura 1000D Antidesgarro y Ripstop Multicam',
        suggestedJade: 'Verde Oliva Militar / Ranger Green',
        suggestedAura: 'Láser Infrarrojo Táctico & Humo de Cobertura'
      },
      {
        id: 'IMPERIAL_OFFICER',
        name: 'Oficial de Alto Mando / Gala Imperial',
        subtitle: 'Elegancia de Estado Mayor y Liderazgo Marcial',
        category: 'Gala & Oficialidad',
        description: 'Guerrera cruzada con botones dorados de alta graduación, charreteras con flecos de oro, fajín de seda con espada de gala y gorra de plato con emblema águila.',
        iconTag: '🎖️ Gala de Mando',
        suggestedArmor: ['Peto de Gala Acorazado con Esmaltes de Honor', 'Charreteras Militares de Oro con Galones de Mando'],
        suggestedAccessories: ['Medallas y Cruces de Honor al Mérito en el Pecho', 'Gorra de Plato con Insignia de Águila Imperial', 'Fajín Ceremonial de Seda Escarlata'],
        suggestedWeapon: 'Sable Ceremonial de Oficial con Vaina de Acero Niquelado',
        suggestedMotif: 'Águila Imperial Bicéfala con Laureles de Victoria',
        suggestedSilk: 'Paño de Lana Fina Azul Marino y Entorchados de Oro',
        suggestedJade: 'Oro de Galones Militares',
        suggestedAura: 'Resplandor Dorado de Mando & Estandarte Flotante'
      }
    ],
    armorPieces: [
      { id: 'ARM_MIL_CARRIER', name: 'Chaleco Portaplacas Táctico con Sistema MOLLE y Placas de Cerámica', category: 'Armadura Torso', culturalOrigin: 'Equipamiento Militar Moderno', description: 'Protección balística modular para órganos vitales con bolsillos modulares de munición.' },
      { id: 'ARM_MIL_HELMET', name: 'Casco Táctico FAST de Kevlar con Rieles ARC y Visor Antidisturbios', category: 'Cabeza & Máscara', culturalOrigin: 'Fuerzas de Asalto', description: 'Casco ligero con soporte para luces, cámaras de combate y protección auditiva electrónica.' },
      { id: 'ARM_MIL_PADS', name: 'Rodilleras y Coderas de Polímero Rígido Integradas en el Pantalón', category: 'Piernas & Pies', culturalOrigin: 'Infantería Mecanizada', description: 'Protectores articulados que permiten adoptar posiciones de tiro en terreno pedregoso.' },
      { id: 'ARM_MIL_EPAULETS', name: 'Charreteras Militares de Gala con Flecos de Oro Forjado', category: 'Hombreras & Brazos', culturalOrigin: 'Uniformidad de Oficial', description: 'Distintivo ornamental en los hombros que denota rango supremo y autoridad.' }
    ],
    culturalAccessories: [
      { id: 'ACC_MIL_MEDALS', name: 'Barra de Condecoraciones y Medallas al Valor Militar', category: 'Accesorio Sagrado', culturalOrigin: 'Estado Mayor', description: 'Cintas de esmalte y metal que certifican campañas victoriosas y heroísmo en batalla.' },
      { id: 'ACC_MIL_NVG', name: 'Gafas Panorámicas de Visión Nocturna Cuádruple (GPNVG-18)', category: 'Cabeza & Máscara', culturalOrigin: 'Operaciones Nocturnas', description: 'Dispositivo electro-óptico con campo de visión de 97 grados en fósforo blanco.' },
      { id: 'ACC_MIL_RADIO', name: 'Radio Táctica Militar con Auricular Intrauditivo y PTT en Pecho', category: 'Accesorio Sagrado', culturalOrigin: 'Comunicaciones de Combate', description: 'Enlace cifrado en tiempo real con mando aéreo y escuadrón.' }
    ],
    spiritualMotifs: [
      'Águila Imperial con Laureles de la Victoria',
      'Doble Fusil Cruzado con Corona de Espinas',
      'Diana Táctica de Precisión con Coordenadas',
      'Escudo con Banda Diagonal y Tres Estrellas de General',
      'Calavera con Boina de Operaciones Especiales'
    ],
    silkPatterns: [
      'Tejido Ripstop Antidesgarro en Camuflaje Multicam',
      'Cordura 1000D Resistente a la Fricción Extrema',
      'Paño de Lana Virgen de Uniformidad de Gala',
      'Nylon Balístico Impermeabilizado de Alta Tensión',
      'Malla Transpirable Táctica de Secado Rápido'
    ],
    jadeColors: [
      { id: 'ranger_green', name: 'Verde Ranger / Oliva Militar', hex: '#3F6212', desc: 'Camuflaje en terrenos boscosos y templados' },
      { id: 'coyote_tan', name: 'Coyote Tan / Desierto Árido', hex: '#A16207', desc: 'Operaciones en entornos desérticos y urbanos secos' },
      { id: 'tactical_black', name: 'Negro Táctico Antirreflejo', hex: '#18181B', desc: 'Incursiones nocturnas y unidades antiterroristas' },
      { id: 'ceremonial_gold', name: 'Oro de Entorchado Militar', hex: '#CA8A04', desc: 'Galones, botones y bordados de alta oficialidad' },
      { id: 'battleship_grey', name: 'Gris Acorazado Naval', hex: '#475569', desc: 'Fuerzas aeronavales y ambientes industriales' }
    ],
    weapons: [
      { name: 'Carabina de Asalto Modular con Silenciador y Láser', type: 'Arma de Fuego Principal', desc: 'Arma de servicio polivalente para distancias cortas y medias' },
      { name: 'Sable de Parada y Gala de Oficial con Empuñadura Dorada', type: 'Arma Blanca de Mando', desc: 'Símbolo de liderazgo marcial y duelo de honor' },
      { name: 'Cuchillo Táctico de Combate de Acero al Carbono', type: 'Cuchillo de Combate', desc: 'Hoja fija con filo aserrado y recubrimiento antirreflejo' }
    ],
    auras: [
      'Líneas de Láser Infrarrojo de Apuntado Táctico Cruzadas',
      'Humo de Señalización Táctica de Cobertura',
      'Resplandor de Focos de Búsqueda y Radar Giratorio',
      'Sin Aura (Rigor Militar Puro y Realista)'
    ]
  },

  'Techwear': {
    styleName: 'Techwear',
    title: 'Techwear & Streetwear Táctico Futurista',
    tag: '🌧️ Waterproof / Acronym / Modular',
    subtitle: 'Membranas Gore-Tex, Cintas Molle, Hebillas Magnéticas Fidlock',
    description: 'Chaquetas con mangas articuladas hidrófugas, pantalones cargo drop-crotch con bolsillos modulares, cintas colgantes con hebillas magnéticas y calzado sneaker-boot impermeable.',
    traditions: [
      {
        id: 'URBAN_NINJA_TECH',
        name: 'Ninja Urbano / Infiltrador Techwear',
        subtitle: 'Agilidad Asfáltica y Silueta Táctica',
        category: 'Streetwear Táctico',
        description: 'Chaqueta impermeable con capucha anatómica profunda, máscara de neopreno con válvula, pantalón cargo con cinchas de ajuste y zapatillas técnicas con suela Vibram.',
        iconTag: '🥷 Urban Ninja',
        suggestedArmor: ['Chaqueta de Membrana Gore-Tex Pro con Paneles Articulados', 'Pantalones Cargo Técnicos con Bolsillos Modulares Desmontables'],
        suggestedAccessories: ['Máscara Facial Antipolución con Válvulas Neopreno', 'Bolso Cruzado Sling Bag con Hebilla Magnética Fidlock', 'Cintas de Carga Tácticas Colgantes con Tipografía Técnica'],
        suggestedWeapon: 'Bastón Extensible de Fibra de Carbono y Dagas Arrojadizas',
        suggestedMotif: 'Tipografía Táctica Industrial & Coordenadas GPS',
        suggestedSilk: 'Gore-Tex Pro 3L Hidrófugo y Schoeller Dryskin',
        suggestedJade: 'Negro Carbón Mate Triple Black',
        suggestedAura: 'Gotas de Lluvia Resbalando en Membrana Hidrófuga'
      }
    ],
    armorPieces: [
      { id: 'ARM_TECH_SHELL', name: 'Chaqueta Hardshell Gore-Tex Pro de 3 Capas con Bolsillos Ocultos', category: 'Armadura Torso', culturalOrigin: 'Vanguardia Techwear', description: 'Capa exterior impermeable y transpirable con cremalleras estancas YKK AquaGuard.' },
      { id: 'ARM_TECH_VEST', name: 'Chaleco Modular con Bolsillos Desmontables y Paneles Molle', category: 'Armadura Torso', culturalOrigin: 'Moda Táctica Urbana', description: 'Portaequipaje ligero adaptable con anillas en D para colgar accesorios.' },
      { id: 'ARM_TECH_CARGO', name: 'Pantalones Cargo Ergonómicos con Cinchas de Ajuste en Tobillos', category: 'Piernas & Pies', culturalOrigin: 'Diseño Acronym', description: 'Pantalones de corte holgado en muslos que se estrechan en los tobillos para máxima movilidad.' },
      { id: 'ARM_TECH_HOOD', name: 'Pasamontañas Táctico Balaclava con Panel de Malla Transpirable', category: 'Cabeza & Máscara', culturalOrigin: 'Protección Urbana', description: 'Capucha ajustada que cubre cabeza y rostro dejando libre la zona ocular.' }
    ],
    culturalAccessories: [
      { id: 'ACC_TECH_SLING', name: 'Bolso Cruzado Sling Bag con Hebilla Magnética Fidlock V-Buckle', category: 'Accesorio Sagrado', culturalOrigin: 'Accesorios Techwear', description: 'Bolsa ergonómica impermeable con compartimento acolchado para tecnología.' },
      { id: 'ACC_TECH_STRAPS', name: 'Juego de Cintas Tácticas Colgantes con Mosquetones de Aluminio', category: 'Prenda Flotante', culturalOrigin: 'Estética Modular', description: 'Cintas de nylon de alta resistencia con detalles reflectantes y hebillas de liberación rápida.' },
      { id: 'ACC_TECH_MASK', name: 'Máscara Facial de Polímero y Neopreno con Filtro de Partículas', category: 'Cabeza & Máscara', culturalOrigin: 'Supervivencia Urbana', description: 'Protección respiratoria estilizada contra polución y agentes químicos urbanos.' }
    ],
    spiritualMotifs: [
      'Logotipo Tipográfico Técnico con Especificaciones Militares',
      'Código QR de Acceso Encriptado',
      'Símbolo Internacional de Impermeabilidad y Resistencia al Viento',
      'Patrón de Rejilla Isométrica con Puntos de Anclaje'
    ],
    silkPatterns: [
      'Membrana Gore-Tex Pro 3L Negro Mate Hidrófuga',
      'Tejido Elástico Bidireccional Schoeller Dryskin',
      'Cordura Ballistic de Alta Densidad',
      'Ripstop Reflectante con Tecnología 3M Scotchlite',
      'Neopreno Perforado de Respiración Dinámica'
    ],
    jadeColors: [
      { id: 'triple_black', name: 'Negro Absoluto Triple Black', hex: '#0A0B0D', desc: 'El tono definitivo de la cultura Techwear' },
      { id: 'dark_charcoal', name: 'Gris Carbón / Antracita', hex: '#27272A', desc: 'Matiz técnico urbano para contrastes tonales' },
      { id: 'safety_orange', name: 'Naranja de Seguridad Industrial', hex: '#EA580C', desc: 'Acentos en tiradores de cremallera y cintas de aviso' },
      { id: 'cyber_volt', name: 'Verde Voltio Neón Fluorescente', hex: '#84CC16', desc: 'Detalles reflectantes de alta visibilidad' }
    ],
    weapons: [
      { name: 'Bastón Táctico Extensible de Fibra de Carbono con Punta Rompecristales', type: 'Arma Contundente Urbana', desc: 'Despliegue instantáneo mediante resorte interno' },
      { name: 'Karas Tácticos y Shurikens de Titanio con Agarre Ergonómico', type: 'Armas Arrojadizas', desc: 'Herramientas de corte silencioso para defensa urbana' },
      { name: 'Cuchillo Karambit Táctico con Anillo de Retención', type: 'Cuchillo Defensivo', desc: 'Hoja curva para combate a corta distancia' }
    ],
    auras: [
      'Llovizna Fina Urbana Resbalando en Membrana Hidrófuga',
      'Resplandor de Tiras Reflectantes 3M al Contacto con Luces',
      'Sin Aura (Estética Minimalista y Urbana Pura)'
    ]
  },

  'Elegante': {
    styleName: 'Elegante',
    title: 'Elegante, Alta Costura & Aristocracia Clásica',
    tag: '🎩 Haute Couture / Gala / Aristocracia',
    subtitle: 'Sastrería Bespoke, Sedas Finas, Joyería de Diamantes y Distinción',
    description: 'Esmoquin y trajes a medida con solapas de raso de seda, vestidos de gala con caídas fluidas, gemelos de oro y platino, relojes de alta complicación y abrigos de cachemira.',
    traditions: [
      {
        id: 'HAUTE_ARISTOCRAT',
        name: 'Gran Aristócrata / Embajador de Gala',
        subtitle: 'Soberanía, Refinamiento y Etiqueta Imperial',
        category: 'Alta Sociedad',
        description: 'Frac negro impecable con chaleco de piqué blanco, solapas de seda brillante, reloj de bolsillo con cadena de platino y bastón con pomo de marfil.',
        iconTag: '👑 Aristocracia',
        suggestedArmor: ['Jubón de Terciopelo Estructurado con Forro de Seda Pura', 'Chaleco Acolchado de Sastrería con Botones de Nácar'],
        suggestedAccessories: ['Gemelos de Oro Blanco con Zafiros Engastados', 'Reloj de Alta Complicación con Pulsera de Piel de Aligátor', 'Pañuelo de Bolsillo de Seda Pura con Monograma'],
        suggestedWeapon: 'Estoque de Duelo con Cazoleta Cincelada en Plata',
        suggestedMotif: 'Flor de Lis en Oro & Corona Aristocrática',
        suggestedSilk: 'Cachemira Fina y Seda Jacquard de Alta Densidad',
        suggestedJade: 'Diamante y Platino Brillante',
        suggestedAura: 'Brillo Sutil de Cristal de Bohemia & Polvo de Oro'
      }
    ],
    armorPieces: [
      { id: 'ARM_ELEG_TUX', name: 'Guerrera de Sastrería Bespoke con Forro de Seda y Solapas de Raso', category: 'Armadura Torso', culturalOrigin: 'Savile Row', description: 'Corte impecable que realza la postura con entretelas naturales y acabado artesanal.' },
      { id: 'ARM_ELEG_CORSET', name: 'Corsé de Gala Estructurado con Varillas de Titanio y Seda Natural', category: 'Armadura Torso', culturalOrigin: 'Alta Costura de París', description: 'Silueta estilizada con ajuste milimétrico y bordados sutiles al tono.' },
      { id: 'ARM_ELEG_SHOULDERS', name: 'Hombreras Armadas de Sastrería Fina con Caída Escultural', category: 'Hombreras & Brazos', culturalOrigin: 'Sastrería Italiana', description: 'Estructura que confiere porte aristocrático sin rigidez excesiva.' },
      { id: 'ARM_ELEG_SHOES', name: 'Zapatos Oxford de Piel de Becerro Pulida al Espejo (Glacage)', category: 'Piernas & Pies', culturalOrigin: 'Artesanía de Calzado', description: 'Calzado formal de suela de cuero con costura Goodyear y puntera abrillantada.' }
    ],
    culturalAccessories: [
      { id: 'ACC_ELEG_CUFFLINKS', name: 'Gemelos de Platino con Zafiros de Cachemira Engastados', category: 'Joyería & Cabello', culturalOrigin: 'Alta Joyería', description: 'Cierres de puño de camisa con gemas preciosas de talla brillante.' },
      { id: 'ACC_ELEG_TIARA', name: 'Diadema de Filigrana de Platino con Perlas Naturales', category: 'Joyería & Cabello', culturalOrigin: 'Cortes Reales Europeas', description: 'Joya dinástica que corona el peinado con sobriedad y distinción.' },
      { id: 'ACC_ELEG_CANE', name: 'Bastón de Paseo en Ébano con Pomo de Plata Maciza Labrada', category: 'Accesorio Sagrado', culturalOrigin: 'Dandismo Clásico', description: 'Accesorio de distinción y apoyo con pomo esculpido a mano.' }
    ],
    spiritualMotifs: [
      'Flor de Lis Imperial con Puntas de Diamante',
      'Monograma Personal Entrelazado en Caligrafía Inglesa',
      'Laurel de la Victoria Tejido en Hilo de Oro',
      'Rosa de los Vientos Minimalista en Platino'
    ],
    silkPatterns: [
      'Cachemira de Vicuña de Suavidad Suprema',
      'Seda Jacquard con Motivos Florales Tono sobre Tono',
      'Lana Fina Super 180s de Sastrería Inglesa',
      'Raso de Seda Duchesse de Gran Peso y Brillo Noble'
    ],
    jadeColors: [
      { id: 'pure_diamond', name: 'Diamante Blanco & Platino', hex: '#F8FAFC', desc: 'Lujo atemporal y pureza cristalina' },
      { id: 'midnight_navy', name: 'Azul Marino Noche Profundo', hex: '#1E293B', desc: 'El color clásico del esmoquin de etiqueta' },
      { id: 'champagne_gold', name: 'Oro Champán Pálido', hex: '#FDE68A', desc: 'Refinamiento cálido sin ostentación' },
      { id: 'bordeaux_velvet', name: 'Rojo Burdeos / Borgoña Noble', hex: '#881337', desc: 'Aristocracia y suntuosidad de terciopelo' }
    ],
    weapons: [
      { name: 'Estoque de Duelo de Caballero con Empuñadura de Plata', type: 'Arma de Duelo', desc: 'Equilibrio perfecto para defender el honor con caballerosidad' },
      { name: 'Pistola de Duelo de Época en Estuche de Caoba con Incrustaciones', type: 'Arma de Fuego Clásica', desc: 'Cañón ochavado de acero damasquinado' }
    ],
    auras: [
      'Destellos de Luz Cristalina y Reflejos de Diamantes',
      'Aroma Visual Sutil a Cedro y Perfume Clásico Francés',
      'Sin Aura (Distinción y Elegancia Natural Impecable)'
    ]
  },

  'Bohemio / Boho': {
    styleName: 'Bohemio / Boho',
    title: 'Bohemio, Chamánico & Mística Étnica',
    tag: '🌿 Étnico / Chamán / Nomad',
    subtitle: 'Fibras Naturales, Joyería de Cuentas, Plumas y Conexión Espiritual',
    description: 'Ponchos y túnicas de lino rústico con bordados étnicos, collares de turquesas y ámbar, plumas de aves rapaces, talismanes de hueso y bolsas de cuero repujado.',
    traditions: [
      {
        id: 'ASTRAL_SHAMAN',
        name: 'Chamán Astral / Nómada de los Espíritus',
        subtitle: 'Vínculo con la Tierra y los Guías Espirituales',
        category: 'Chamanismo & Naturaleza',
        description: 'Manto de lana tejida a telar con motivos totémicos, corona de plumas y astas de ciervo pulidas, tambor chamánico de cuero y collares de cuentas de ámbar.',
        iconTag: '🦌 Chamán Astral',
        suggestedArmor: ['Pectoral de Huesos de Búfalo y Cuero Crudo', 'Brazales de Cuero Repujado con Amuletos de Turquesa'],
        suggestedAccessories: ['Corona de Plumas Sagradas y Cuarzos Naturales', 'Collar Pectoral con Múltiples Vueltas de Turquesas y Ámbar', 'Bolsa de Medicina Tradicional con Hierbas Secas'],
        suggestedWeapon: 'Báculo Ritual Chamánico con Cascabeles y Atrapasueños',
        suggestedMotif: 'Espiral de la Vida Cósmica & Huella de Oso',
        suggestedSilk: 'Lino Crudo Tejido a Mano y Lana de Oveja Virgen',
        suggestedJade: 'Turquesa Natural del Desierto',
        suggestedAura: 'Bruma Verdeante & Luciérnagas Espirituales'
      }
    ],
    armorPieces: [
      { id: 'ARM_BOHO_VEST', name: 'Chaleco de Cuero Suave con Flecos Largos y Cuentas de Hueso', category: 'Armadura Torso', culturalOrigin: 'Tradición Nómada', description: 'Prenda ligera de ante que protege el pecho con libertad total de movimientos.' },
      { id: 'ARM_BOHO_BRACERS', name: 'Brazales de Cuero Repujado con Insertos de Turquesa y Coral', category: 'Hombreras & Brazos', culturalOrigin: 'Orfebrería Étnica', description: 'Protección para antebrazos decorada con motivos de la naturaleza y piedras sagradas.' },
      { id: 'ARM_BOHO_CROWN', name: 'Diadema de Cuero con Plumas de Halcón y Cuarzo Ahumado', category: 'Cabeza & Máscara', culturalOrigin: 'Ritos Chamánicos', description: 'Tocado ceremonial que conecta la mente del portador con los espíritus del aire.' }
    ],
    culturalAccessories: [
      { id: 'ACC_BOHO_DRUM', name: 'Tambor Chamánico de Cuero de Ciervo con Baqueta de Madera', category: 'Accesorio Sagrado', culturalOrigin: 'Música Ritual', description: 'Instrumento de percusión para inducir trances y armonizar las energías del entorno.' },
      { id: 'ACC_BOHO_NECKLACE', name: 'Collar Pectoral Multicapa de Turquesas, Plata y Conchas Marinas', category: 'Joyería & Cabello', culturalOrigin: 'Artesanía Tribal', description: 'Cascada de cuentas minerales que cubren el pecho con simbolismo de fertilidad y protección.' },
      { id: 'ACC_BOHO_POUCH', name: 'Bolsa de Medicina Tradicional con Cierre de Hueso Tallado', category: 'Accesorio Sagrado', culturalOrigin: 'Herbolaria Ancestral', description: 'Contenedor sagrado de hierbas protectoras, raíces y piedras de poder.' }
    ],
    spiritualMotifs: [
      'Atrapasueños Sagrado con Plumas y Telaraña Central',
      'Espiral Cósmica del Eterno Retorno de la Naturaleza',
      'Árbol Tótem con Animales Guardianes Entrelazados',
      'Sol y Luna Unidos en un Abrazo Celestial'
    ],
    silkPatterns: [
      'Lino Crudo sin Blanquear de Trama Rústica',
      'Lana de Telar Andino con Tintes Naturales de Raíces',
      'Algodón Orgánico Bordado a Mano con Hilos de Colores',
      'Ante Suave de Ciervo con Teñido al Humo'
    ],
    jadeColors: [
      { id: 'desert_turquoise', name: 'Turquesa Natural del Desierto', hex: '#06B6D4', desc: 'Protección de viajeros y conexión con el cielo' },
      { id: 'warm_amber', name: 'Ámbar Báltico Solar', hex: '#D97706', desc: 'Resina fosilizada con calor y vitalidad ancestral' },
      { id: 'sacred_coral', name: 'Coral Rojo Marino', hex: '#EF4444', desc: 'Fuerza vital y conexión con las aguas profundas' },
      { id: 'raw_copper', name: 'Cobre Nativo Martillado', hex: '#C2410C', desc: 'Conductor de energías telúricas' }
    ],
    weapons: [
      { name: 'Báculo Chamánico con Cuerno de Ciervo y Cascabeles', type: 'Arma Espiritual', desc: 'Canaliza fuerzas elementales y ahuyenta malas entidades' },
      { name: 'Daga Ritual de Obsidiana con Mango de Madera de Sabina', type: 'Cuchillo Sagrado', desc: 'Hoja de vidrio volcánico tallada por percusión' },
      { name: 'Honda de Cuero Trenzado con Piedras de Río Pulidas', type: 'Arma a Distancia', desc: 'Proyectiles precisos impulsados con destreza ancestral' }
    ],
    auras: [
      'Bruma Esmeralda y Esporas Luminosas Flotando',
      'Aura de Viento Cálido con Hojas Secas en Espiral',
      'Sin Aura (Aspecto Natural y Orgánico)'
    ]
  },

  'Kawaii / Lindo': {
    styleName: 'Kawaii / Lindo',
    title: 'Kawaii, Mahou Shoujo & Pastel Dreams',
    tag: '🎀 Magical Girl / Pastel / Harajuku',
    subtitle: 'Lazos Encantados, Gemas de Corazón, Volantes y Magia Dulce',
    description: 'Vestidos con volantes esponjosos en capas, corsés con lazos de raso pastel, varitas mágicas con cristales en forma de estrella o corazón, tiaras tiernas y calzado con pompones.',
    traditions: [
      {
        id: 'MAHOU_SHOUJO',
        name: 'Magical Girl / Guerrera de las Estrellas Dulces',
        subtitle: 'El Poder del Amor, la Amistad y la Luz Radiante',
        category: 'Magical Girl & Pop',
        description: 'Vestido marinero o falda con vuelo esponjoso de tul, gran lazo en el pecho con broche de corazón de cristal, tiara con alitas doradas y varita mágica celestial.',
        iconTag: '💖 Magical Girl',
        suggestedArmor: ['Corsé Dulce de Satén Rosa con Lazos y Volantes de Encaje', 'Hombreras Aladas de Porcelana Mágica'],
        suggestedAccessories: ['Tiara de Princesa con Corazón de Rubí y Alitas de Ángel', 'Broche Pectoral Mágico con Cristal de Estrella Fugaz', 'Lazos Gigantes de Organza Traslúcida en la Espalda'],
        suggestedWeapon: 'Varita Mágica de Cristal Estelar con Sonajero de Campanas',
        suggestedMotif: 'Corazón Alado con Destellos de Estrellas Fugaces',
        suggestedSilk: 'Tul Esponjoso Multicapa y Satén Rosa Pastel',
        suggestedJade: 'Cuarzo Rosa del Amor Eterno',
        suggestedAura: 'Lluvia de Estrellitas Brillantes & Corazones Flotantes'
      }
    ],
    armorPieces: [
      { id: 'ARM_KAWAII_CORSET', name: 'Corsé Estructurado con Volantes de Encaje y Lazos Rosados', category: 'Armadura Torso', culturalOrigin: 'Harajuku / Mahou Shoujo', description: 'Protección ligera encantada reforzada con magia de afecto y alegría.' },
      { id: 'ARM_KAWAII_SHOULDERS', name: 'Hombreras en Forma de Alas de Ángel de Porcelana Encantada', category: 'Hombreras & Brazos', culturalOrigin: 'Anime Mágico', description: 'Placas decorativas con plumas esculpidas y gemas de brillo suave.' },
      { id: 'ARM_KAWAII_BOOTS', name: 'Botas Altas con Lazos de Satén y Pompones Suaves', category: 'Piernas & Pies', culturalOrigin: 'Moda Lolita Dulce', description: 'Calzado tierno con plataforma cómoda y costuras reforzadas.' }
    ],
    culturalAccessories: [
      { id: 'ACC_KAWAII_WAND', name: 'Varita Mágica de Corazón con Cristales Celestiales y Cascabeles', category: 'Accesorio Sagrado', culturalOrigin: 'Grimorios Mágicos Pop', description: 'Canalizador de rayos de purificación que emite campanadas musicales.' },
      { id: 'ACC_KAWAII_TIARA', name: 'Tiara Mágica con Estrella de Cristal y Lazos Laterales', category: 'Joyería & Cabello', culturalOrigin: 'Reino de los Dulces', description: 'Accesorio para el cabello que brilla cuando el portador sonríe.' }
    ],
    spiritualMotifs: [
      'Corazón con Alas de Querubín y Lazo Rosado',
      'Estrella Fugaz Sonriente de Cinco Puntas',
      'Gatito con Corona y Cascabel Dorado',
      'Luna Creciente con Nube de Algodón de Azúcar'
    ],
    silkPatterns: [
      'Satén Suave en Tono Rosa Pastel / Fresa con Nata',
      'Tul Esponjoso con Purpurina Iridiscente',
      'Encaje Dulce con Motivos de Fresas y Flores',
      'Algodón Pima Blanco Inmaculado'
    ],
    jadeColors: [
      { id: 'rose_quartz', name: 'Cuarzo Rosa Pastel', hex: '#F472B6', desc: 'Amor puro, alegría y protección contra la tristeza' },
      { id: 'baby_blue', name: 'Azul Bebé Celestial', hex: '#60A5FA', desc: 'Serenidad y cielo de ensueño' },
      { id: 'mint_pastel', name: 'Verde Menta Dulce', hex: '#34D399', desc: 'Frescura mágica y esperanza' },
      { id: 'sparkle_gold', name: 'Oro Estelar con Purpurina', hex: '#FBBF24', desc: 'Brillo deslumbrante de los hechizos' }
    ],
    weapons: [
      { name: 'Cetro Mágico de Luz con Corazón de Cristal Giratorio', type: 'Foco Mágico', desc: 'Dispara haces de energía purificadora' },
      { name: 'Arco de Cinta Mágica con Flechas de Corazón Radiante', type: 'Arma a Distancia Encantada', desc: 'Crea flechas de pura luz benevolente' }
    ],
    auras: [
      'Lluvia de Estrellas Fugaces y Destellos Rosados Brillantes',
      'Burbujas Iridiscentes de Jabón Mágico Flotantes',
      'Sin Aura (Aspecto Tierno Puramente Terrenal)'
    ]
  },

  'Rústico / Superviviente': {
    styleName: 'Rústico / Superviviente',
    title: 'Rústico, Yermo Postapocalíptico & Supervivencia',
    tag: '☢️ Wasteland / Superviviente / Primitivo',
    subtitle: 'Chatarra Reutilizada, Cuero Curtido, Vendajes y Adaptabilidad',
    description: 'Armaduras improvisadas con placas de matrícula y neumáticos, capas de lona rasgada, máscaras de gas modificadas, machetes forjados con hojas de sierra y mochilas de armazón metálico.',
    traditions: [
      {
        id: 'WASTELAND_SCAVENGER',
        name: 'Chatarrero del Páramo / Nómada Radiactivo',
        subtitle: 'Supervivencia a Cualquier Costo en el Fin del Mundo',
        category: 'Postapocalíptico',
        description: 'Peto fabricado con señales de tráfico y bandas de goma, máscara de gas con filtro de botella, vendajes en extremidades, mochila con provisiones y bate con alambre de espino.',
        iconTag: '☢️ Yermo / Chatarra',
        suggestedArmor: ['Peto de Chapa Metálica Remachada y Neumáticos de Coche', 'Hombrera de Hombrera de Fútbol Americano Reforzada con Metal'],
        suggestedAccessories: ['Máscara de Gas Militar Modificada con Doble Filtro', 'Mochila de Armazón Tubular con Cuerdas y Cantimploras', 'Contador Geiger de Bolsillo con Aguja Oscilante'],
        suggestedWeapon: 'Machete Pesado Forjado de Ballesta de Camión',
        suggestedMotif: 'Símbolo de Peligro Radiactivo y Calavera con Gafas',
        suggestedSilk: 'Lona de Camión Desgastada y Cuero Quemado',
        suggestedJade: 'Hierro Oxidado y Chatarra',
        suggestedAura: 'Polvo Radiactivo del Páramo & Calor de Cenizas'
      }
    ],
    armorPieces: [
      { id: 'ARM_RUST_CHEST', name: 'Coraza Improvisada de Placas de Acero y Tiras de Cuero Reciclado', category: 'Armadura Torso', culturalOrigin: 'Talleres del Páramo', description: 'Defensa contundente construida con piezas de maquinaria pesada y remaches manuales.' },
      { id: 'ARM_RUST_PAULDRON', name: 'Hombrera Asimétrica de Neumático Blindado con Pinchos', category: 'Hombreras & Brazos', culturalOrigin: 'Incursores del Yermo', description: 'Protección de choque para embestidas cuerpo a cuerpo.' },
      { id: 'ARM_RUST_MASK', name: 'Máscara de Gas con Visores de Rejilla Metálica y Tubo Respirador', category: 'Cabeza & Máscara', culturalOrigin: 'Zonas Contaminadas', description: 'Filtrado de aire contra tormentas de arena ácida y esporas tóxicas.' }
    ],
    culturalAccessories: [
      { id: 'ACC_RUST_BACKPACK', name: 'Mochila de Supervivencia con Cantimplora, Cuerda y Ganchos', category: 'Accesorio Sagrado', culturalOrigin: 'Supervivientes Nómadas', description: 'Todo el equipo necesario para subsistir semanas en el desierto tóxico.' },
      { id: 'ACC_RUST_GEIGER', name: 'Contador Geiger Analógico de Aguja con Carcasa de Baquelita', category: 'Accesorio Sagrado', culturalOrigin: 'Cazadores de Ruinas', description: 'Dispositivo salvavidas para detectar focos de radiación letal.' }
    ],
    spiritualMotifs: [
      'Trébol de Radiación Nuclear Manchado de Óxido',
      'Lobo Solitario Aullando a la Luna Rota',
      'Engranaje Agrietado Cubierto de Cenizas',
      'Pala y Pico Cruzados sobre Huella de Bota'
    ],
    silkPatterns: [
      'Lona de Tienda Militar Descolorida por el Sol',
      'Cuero Curtido con Salitre y Manchas de Aceite',
      'Arpillera de Cáñamo Grueso y Deshilachado',
      'Vendas de Algodón Sucio Envejecidas'
    ],
    jadeColors: [
      { id: 'rust_orange', name: 'Naranja Óxido de Metal', hex: '#C2410C', desc: 'Metal corroído por décadas de intemperie' },
      { id: 'toxic_green_rad', name: 'Verde Radiactivo Fosforescente', hex: '#84CC16', desc: 'Brillo de isótopos y residuos contaminantes' },
      { id: 'charcoal_ash', name: 'Gris Ceniza de Ruina', hex: '#374151', desc: 'Polvo de ciudades destruidas' },
      { id: 'desert_dust', name: 'Marrón Polvo de Desierto', hex: '#78350F', desc: 'La tierra yerma interminable' }
    ],
    weapons: [
      { name: 'Machete Dentado de Hoja de Sierra Industrial', type: 'Arma de Choque', desc: 'Corte devastador con peso balanceado hacia la punta' },
      { name: 'Escopeta Recortada de Dos Cañones con Empuñadura Encordada', type: 'Arma de Fuego Casera', desc: 'Potencia demoledora a quemarropa' },
      { name: 'Ballesta de Caza con Palas de Fibra de Vidrio Reciclada', type: 'Arma Silenciosa', desc: 'Disparo letal que permite recuperar proyectiles' }
    ],
    auras: [
      'Torbellino de Polvo y Cenizas del Páramo en Suspensión',
      'Resplandor Radiactivo Verde Fosforescente Débil',
      'Sin Aura (Supervivencia Áspera y Brutal)'
    ]
  },

  'Sexy / Provocativo': {
    styleName: 'Sexy / Provocativo',
    title: 'Sexy, Provocativo & Erotic Romance',
    tag: '💋 Femme Fatale / Erotic Romance',
    subtitle: 'Siluetas Seductoras, Micro Prendas, Látex y Transparencias Vaporosas',
    description: 'Bustiers ceñidos, micro tops underboob, bodysuits de látex líquido, micro qipaos de seda translúcida con aberturas extremas, lencería nupcial romántica, arneses y medias asimétricas con ligas.',
    traditions: [
      {
        id: 'FEMME_FATALE_OPERATIVE',
        name: 'Femme Fatale / Asesina Seductora',
        subtitle: 'Belleza Deslumbrante y Letalidad Oculta',
        category: 'Seducción & Espionaje',
        description: 'Bustier de cuero charol negro ajustado, liguero con funda para daga de marfil, guantes largos de terciopelo, antifaz de encaje y tacones de aguja con punta de acero.',
        iconTag: '👠 Femme Fatale',
        suggestedArmor: ['Bustier Armado de Cuero Charol con Ballenas Rígidas', 'Arnés Corporal de Tiras de Cuero y Hebillas Doradas'],
        suggestedAccessories: ['Liguero con Funda Secreta para Daga de Estilete', 'Guantes Largos de Ópera de Satén Negro Brillante', 'Gargantilla de Cuero con Anilla y Cadena Fina'],
        suggestedWeapon: 'Estilete de Aguja de Titanio con Empuñadura de Nácar',
        suggestedMotif: 'Beso Escarlata con Daga Cruzada',
        suggestedSilk: 'Látex Negro Líquido y Encaje de Rejilla',
        suggestedJade: 'Rubí Carmesí Brillante',
        suggestedAura: 'Niebla Rosada con Perfume Hipnótico & Pétalos de Rosa'
      },
      {
        id: 'TACTICAL_TECHWEAR_CYBER',
        name: 'Street Techwear Provocativo / Cyber Pin-up',
        subtitle: 'Estética Urbana Rebelde, Micro Tops y Cinchas Tácticas',
        category: 'Techwear & Cyberpunk',
        description: 'Micro chaquetas cropped sobre el busto, tops underboob asimétricos con cremallera, arneses de cinchas elásticas, micro shorts con argollas, medias asimétricas con ligas al muslo y botines de plataforma.',
        iconTag: '⚡ Techwear',
        suggestedArmor: ['Micro Chaqueta Bomber sobre el Busto', 'Arnés Underboob de Cintas Elásticas Cruzadas'],
        suggestedAccessories: ['Ligas de Cuero Tácticas con Enganches de Medias', 'Choker de Cuero con Correa / Leash Desmontable', 'Botines Tácticos de Tacón Alto y Plataforma'],
        suggestedWeapon: 'Cuchillas Ocultas de Titanio y Cable Monomolecular Eléctrico',
        suggestedMotif: 'Relámpago Neón con Corazón de Grafiti y Cinta de Precaución',
        suggestedSilk: 'Vinilo Negro Brillante con Franjas Amarillo Neón',
        suggestedJade: 'Amarillo Neón & Negro Carbono',
        suggestedAura: 'Destellos de Glitch Neón Magenta y Humo Holográfico'
      },
      {
        id: 'KEMONO_ROMANCE_BOUDOIR',
        name: 'Kemono Romance Dinástico / Boudoir Oriental',
        subtitle: 'Seda Oriental Translúcida, Micro Qipaos y Cadenas Doradas',
        category: 'Fantasía Oriental & Kemono Boudoir',
        description: 'Micro qipaos y cheongsams de seda transparente con escote gota en el busto y aberturas laterales extremas a la cintura, orejitas suaves con lazos y campanillas, faja obi con bordados de dragón y cadenas de cuerpo de oro puro.',
        iconTag: '🦊 Kemono',
        suggestedArmor: ['Micro Qipao / Cheongsam Erótico con Aberturas Extremas', 'Hombreras Flotantes de Seda con Placas Doradas'],
        suggestedAccessories: ['Diadema de Orejas Kemono con Lazos y Campanillas', 'Cadena Erótica de Caderas con Cascabeles de Oro', 'Tacones Lace-up de Tiras Cruzadas hasta la Rodilla'],
        suggestedWeapon: 'Abanico de Cuchillas Doradas de Fénix Carmesí',
        suggestedMotif: 'Flor de Loto Carmesí con Dragón Dorado Entrelazado',
        suggestedSilk: 'Gasa de Seda Translúcida con Bordados de Hilos de Oro',
        suggestedJade: 'Rojo Escarlata Sangre de Loto & Oro Imperial',
        suggestedAura: 'Pétalos de Flor de Cerezo Brillantes y Campanas Tintineantes'
      },
      {
        id: 'DARK_EROTIC_VALKYRIE',
        name: 'Dark Fantasy Erotic Valkyrie / Bondage Táctico',
        subtitle: 'Látex Líquido, Micro Placas de Acero y Arneses O-Ring',
        category: 'Dark Fantasy & Bondage Táctico',
        description: 'Bodysuit esculpido de látex negro brillante con cutouts anatómicos, micro placas de armadura pulida sobre los hombros y caderas, arneses de anillas O-ring, gargantilla con correa desmontable y medias de látex hasta el muslo.',
        iconTag: '🖤 Dark Valkyrie',
        suggestedArmor: ['Bodysuit Táctico de Látex / Vinilo con Cutouts Anatómicos', 'Micro Placas de Armadura Pulida de Hombro y Cadera'],
        suggestedAccessories: ['Arnés Bondage de Cuero Erótico con Anillas O-Ring', 'Botas Altas de Látex con Tacón de Aguja', 'Esposas / Manillas Suaves de Cuero con Cadena'],
        suggestedWeapon: 'Estoque Enjoyado con Empuñadura de Filigrana y Daga Parrying',
        suggestedMotif: 'Calavera Coronada con Espinas y Anilla O-Ring de Plata',
        suggestedSilk: 'Látex Líquido Negro Ultra-Brillante y Cuero Charol',
        suggestedJade: 'Negro Látex Espejo & Plata Mithril Abisal',
        suggestedAura: 'Niebla Oscura con Partículas Carmesí y Resplandor Sombrío'
      },
      {
        id: 'ROMANTIC_BRIDAL_NOCTURNE',
        name: 'Lencería Nupcial de Gala / Novia Romántica',
        subtitle: 'Satén Nupcial, Encaje de Chantilly, Velos y Babydolls',
        category: 'Romance & Boudoir Nupcial',
        description: 'Corsé nupcial semitransparente con varillas vistas, babydoll de tul con encaje floral, peignoir de satén marfil con ribetes de plumas de marabú, velo nupcial corto con corona de azahar y medias de seda blanca bordadas.',
        iconTag: '💍 Bridal Romance',
        suggestedArmor: ['Vestido de Novia Erótico con Faldón Abierto', 'Corsé Bustier de Encaje de Chantilly'],
        suggestedAccessories: ['Velo Nupcial Romántico de Novia con Corona de Flores', 'Medias Nupciales de Seda Blanca Bordada', 'Sandalias Nupciales Románticas con Cintas de Satén'],
        suggestedWeapon: 'Cetro Nupcial de Cristal de Cuarzo Rosa con Cinta de Raso',
        suggestedMotif: 'Anillo de Bodas Entrelazado con Rosa Blanca y Cinta de Satén',
        suggestedSilk: 'Tul Nupcial Translúcido y Satén Líquido Marfil',
        suggestedJade: 'Blanco Nupcial Perla & Oro Rosa Champagne',
        suggestedAura: 'Destellos de Luz Dorada Cálida y Pétalos Blancos Flotantes'
      }
    ],
    armorPieces: [
      { id: 'ARM_SEXY_BUSTIER', name: 'Bustier Acorazado de Charol Negro con Escote Escultural', category: 'Armadura Torso', culturalOrigin: 'Alta Seducción', description: 'Pieza que moldea el torso con precisión y placas de protección interna.' },
      { id: 'ARM_SEXY_HARNESS', name: 'Arnés de Pecho y Cintura con Anillas Metálicas Pulidas', category: 'Armadura Torso', culturalOrigin: 'Moda Vanguardista', description: 'Cinchas cruzadas de cuero que enfatizan la silueta.' },
      { id: 'ARM_SEXY_HEELS', name: 'Botas Altas de Tacón de Aguja con Puntera Blindada', category: 'Piernas & Pies', culturalOrigin: 'Calzado Audaz', description: 'Botas por encima de la rodilla con tacón metálico funcional para combate.' },
      { id: 'ARM_SEXY_LATEX_BODYSUIT', name: 'Bodysuit Táctico de Látex Esculpido con Placas Reforzadas', category: 'Armadura Torso', culturalOrigin: 'Dark Fantasy', description: 'Segunda piel de látex de alto brillo con refuerzos en zonas vitales.' },
      { id: 'ARM_SEXY_MICRO_QIPAO', name: 'Micro Qipao de Seda Carmesí con Aberturas Extremas', category: 'Armadura Torso', culturalOrigin: 'Fantasía Oriental', description: 'Corte oriental provocativo con escote gota y ribetes dorados.' },
      { id: 'ARM_SEXY_BRIDAL_CORSET', name: 'Corsé Nupcial Translúcido con Varillas Vistas y Encaje', category: 'Armadura Torso', culturalOrigin: 'Alta Costura Nupcial', description: 'Corsetería de alta gama con transparencias de tul y copas armadas.' }
    ],
    culturalAccessories: [
      { id: 'ACC_SEXY_GARTER', name: 'Liguero Reforzado con Funda Oculta para Daga de Asesina', category: 'Accesorio Sagrado', culturalOrigin: 'Espionaje Clandestino', description: 'Sujeción de medias con compartimento disimulado.' },
      { id: 'ACC_SEXY_GLOVES', name: 'Guantes de Ópera por Encima del Codo en Satén Negro', category: 'Joyería & Cabello', culturalOrigin: 'Elegancia Sensual', description: 'Guantes ceñidos de tacto sedoso con flexibilidad total.' },
      { id: 'ACC_SEXY_KEMONO_BELLS', name: 'Diadema Kemono con Campanillas Doradas y Lazos', category: 'Joyería & Cabello', culturalOrigin: 'Fantasía Kemono', description: 'Orejitas suaves con cascabeles que emiten un tintineo seductor.' },
      { id: 'ACC_SEXY_CHOKER_LEASH', name: 'Choker de Cuero con Anilla O-Ring y Correa Desmontable', category: 'Joyería & Cabello', culturalOrigin: 'Bondage Táctico', description: 'Gargantilla ajustable de cuero negro con herrajes de acero inoxidable.' },
      { id: 'ACC_SEXY_BRIDAL_VEIL', name: 'Velo Nupcial Corto de Tul con Bordados de Perlas', category: 'Joyería & Cabello', culturalOrigin: 'Romance Nupcial', description: 'Velo vaporoso transparente que cae delicadamente sobre los hombros.' },
      { id: 'ACC_SEXY_BODY_CHAINS', name: 'Cadenas Corporales de Oro con Perlas sobre el Escote', category: 'Joyería & Cabello', culturalOrigin: 'Alta Costura Boudoir', description: 'Finas cadenas doradas que abrazan el busto y las caderas.' }
    ],
    spiritualMotifs: [
      'Labios Carmesí con Colmillos de Vampiro',
      'Corazón Espinado Atravesado por Tacón de Aguja',
      'Látigo Enroscado con Rosa de Espinas',
      'Flor de Loto Carmesí con Dragón Dorado Entrelazado',
      'Relámpago Neón con Corazón de Grafiti',
      'Calavera de Cristal con Velo Nupcial y Rosa Blanca',
      'Marca Arcana de Posesión Carmesí'
    ],
    silkPatterns: [
      'Látex Líquido Negro Ultrabrillante',
      'Encaje Floral Transparente de Alta Costura',
      'Cuero Charol Pulido con Reflejos Rojizos',
      'Malla de Red de Seda Suave con Strass',
      'Gasa de Seda Translúcida con Bordados Dorados',
      'Satén Nupcial Marfil con Caída Líquida',
      'Tejido Transparente Efecto Mojado'
    ],
    jadeColors: [
      { id: 'crimson_kiss', name: 'Rojo Carmesí Pasión', hex: '#E11D48', desc: 'Atracción fatal y fuego magnético' },
      { id: 'glossy_black', name: 'Negro Charol / Látex', hex: '#09090B', desc: 'Reflejos de luz sobre superficies pulidas' },
      { id: 'pure_gold_accent', name: 'Oro Pulido de Cadenas', hex: '#F59E0B', desc: 'Herrajes brillantes y joyas corporales' },
      { id: 'tactical_neon_yellow', name: 'Amarillo Neón Táctico', hex: '#EAB308', desc: 'Acentos techwear de alto contraste' },
      { id: 'bridal_white_pearl', name: 'Blanco Nácar Nupcial', hex: '#FFFFFF', desc: 'Transparencias delicadas de novia' },
      { id: 'succubus_purple', name: 'Púrpura Seducción Oscuro', hex: '#581C87', desc: 'Misterio y magnetismo erótico' }
    ],
    weapons: [
      { name: 'Estilete de Asesina con Hoja Triangular Ultraafilada', type: 'Daga Oculta', desc: 'Penetración instantánea en puntos vulnerables' },
      { name: 'Látigo de Cuero Trenzado con Puntas Metálicas', type: 'Arma Flexible', desc: 'Control de distancia y desarme ágil' },
      { name: 'Abanico de Cuchillas Doradas de Fénix Carmesí', type: 'Abanico Cortante', desc: 'Danza letal con cortes invisibles a corta distancia' },
      { name: 'Cuchillas Monomoleculares Ocultas en Botines de Tacón', type: 'Arma Oculta', desc: 'Golpes sorpresa con filo cortante integrado' },
      { name: 'Cetro Nupcial de Cristal de Cuarzo con Cinta de Raso', type: 'Cetro Mágico', desc: 'Canalización de encantamientos de atracción y amor' }
    ],
    auras: [
      'Aura de Fragancia Hipnótica con Pétalos de Rosa Carmesí',
      'Resplandor Iridiscente Violeta y Rojo Neón',
      'Destellos de Glitch Neón Magenta y Humo Holográfico',
      'Pétalos de Flor de Cerezo Brillantes y Campanas Tintineantes',
      'Niebla Oscura con Partículas Carmesí y Resplandor Sombrío',
      'Destellos de Luz Dorada Cálida y Pétalos Blancos Flotantes',
      'Sin Aura (Seducción Física y Magnética Pura)'
    ]
  },

  'Vanguardista / Haute Couture': {
    styleName: 'Vanguardista / Haute Couture',
    title: 'Vanguardista, Haute Couture & Geometría Escultural',
    tag: '📐 Escultórico / Asimétrico / Runway',
    subtitle: 'Siluetas Arquitectónicas, Asimetría Futurista y Texturas Innovadoras',
    description: 'Estructuras rígidas tridimensionales, cuellos sobredimensionados, pliegues origami en telas tecnológicas, joyería conceptual de titanio y calzado escultural.',
    traditions: [
      {
        id: 'RUNWAY_VISIONARY',
        name: 'Visionario de Pasarela / Escultura Viva',
        subtitle: 'Arte Vestible y Desafío a la Gravedad',
        category: 'Arte & Moda Futurista',
        description: 'Chaqueta de origami metálico con solapas asimétricas gigantes, cuello alto rígido, tocado geométrico de alambre dorado y gafas conceptuales sin montura.',
        iconTag: '📐 Haute Couture',
        suggestedArmor: ['Coraza Arquitectónica Asimétrica de Paneles Plegados', 'Hombrera Monolítica Escultural de Resina Traslúcida'],
        suggestedAccessories: ['Tocado Escultural de Filamentos Metálicos Orbitantes', 'Gafas de Espejo Monolíticas sin Patillas', 'Guantelete Conceptual de Anillos Conectados'],
        suggestedWeapon: 'Estilete Geométrico de Titanio Facetado',
        suggestedMotif: 'Poliedro de Oro Flotante & Líneas Fractales',
        suggestedSilk: 'Tejido Termoformado Rígido con Acabado Cromático',
        suggestedJade: 'Titanio Iridiscente de Pasarela',
        suggestedAura: 'Refracciones Prismáticas de Luz Espectral'
      }
    ],
    armorPieces: [
      { id: 'ARM_VANG_CHEST', name: 'Peto Escultórico con Pliegues Geométricos de Origami Tridimensional', category: 'Armadura Torso', culturalOrigin: 'Alta Costura Conceptual', description: 'Estructura rígida de polímeros termoformados con ángulos asimétricos.' },
      { id: 'ARM_VANG_SHOULDER', name: 'Hombrera Monolítica Exagerada de Resina Translúcida', category: 'Hombreras & Brazos', culturalOrigin: 'Pasarelas de Milán', description: 'Elemento arquitectónico que redefine la silueta del portador.' }
    ],
    culturalAccessories: [
      { id: 'ACC_VANG_HEADPIECE', name: 'Tocado Conceptual de Formas Geométricas Flotantes', category: 'Joyería & Cabello', culturalOrigin: 'Diseño Escénico', description: 'Corona escultórica de alambres de titanio y cristales facetados.' },
      { id: 'ACC_VANG_GLASSES', name: 'Gafas Esculturales Monoculares con Lente Reflectante Angular', category: 'Cabeza & Máscara', culturalOrigin: 'Accesorios Futuristas', description: 'Gafas de una sola pieza con corte geométrico no convencional.' }
    ],
    spiritualMotifs: [
      'Icosaedro Tridimensional Flotando en el Espacio',
      'Líneas Asimétricas de Tensión Arquitectónica',
      'Prisma Triangular Descomponiendo la Luz Blanca'
    ],
    silkPatterns: [
      'Tejido Termoformado con Efecto Memoria de Forma',
      'Seda Metálica con Reflejos Holográficos',
      'Neopreno Escultórico de Alta Densidad'
    ],
    jadeColors: [
      { id: 'iridescent_titanium', name: 'Titanio Iridiscente Camaleón', hex: '#8B5CF6', desc: 'Reflejos multicolores según el ángulo de luz' },
      { id: 'pure_matte_white', name: 'Blanco Puro Arquitectónico', hex: '#FFFFFF', desc: 'Minimalismo escultural puro' },
      { id: 'metallic_silver_runway', name: 'Plata Líquida de Espejo', hex: '#CBD5E1', desc: 'Reflexión futurista de alta costura' }
    ],
    weapons: [
      { name: 'Hoja Escultórica de Titanio Facetado con Mango Minimalista', type: 'Arma de Diseño', desc: 'Pieza de arte letal con proporciones matemáticas áureas' }
    ],
    auras: [
      'Refracciones Prismáticas de Arcoíris Geométrico',
      'Líneas de Guía de Perspectiva Holográficas',
      'Sin Aura (Presencia Visual Escultórica Pura)'
    ]
  },

  'Deportivo': {
    styleName: 'Deportivo',
    title: 'Deportivo, Athleisure & Alto Rendimiento',
    tag: '⚡ Performance / Ergonomía / Aerodinámica',
    subtitle: 'Tejidos Compresivos, Calzado de Amortiguación y Ergonomía Total',
    description: 'Prendas ceñidas de compresión muscular, chaquetas cortavientos ultraligeras, zapatillas con amortiguación reactiva, muñequeras absorbentes y smartwatches con telemetría.',
    traditions: [
      {
        id: 'PRO_ATHLETE_ELITE',
        name: 'Atleta de Élite / Campeón de Alto Rendimiento',
        subtitle: 'Velocidad, Fuerza y Aerodinámica Extrema',
        category: 'Deporte & Rendimiento',
        description: 'Traje de compresión anatómica con líneas de tensión biomecánicas, cortavientos técnico con capucha ergonómica, zapatillas de clavos de fibra de carbono y monitor biométrico.',
        iconTag: '🏃 Atleta de Élite',
        suggestedArmor: ['Top de Compresión Biomecánica con Soporte Muscular', 'Mallas Deportivas con Paneles de Absorción de Impactos'],
        suggestedAccessories: ['Smartwatch Táctico con Monitor Cardíaco y GPS', 'Gafas Deportivas Aerodinámicas Polarizadas', 'Cintas de Kinesiología en Articulaciones'],
        suggestedWeapon: 'Bate de Béisbol de Aleación de Titanio / Arco Olímpico',
        suggestedMotif: 'Relámpago de Velocidad & Ondas de Pulso Cardíaco',
        suggestedSilk: 'Spandex Elástico Cuatridireccional y Malla Transpirable',
        suggestedJade: 'Azul Eléctrico Neón',
        suggestedAura: 'Estela de Velocidad & Ondas de Choque Cinéticas'
      }
    ],
    armorPieces: [
      { id: 'ARM_SPORT_TOP', name: 'Camiseta de Compresión Biomecánica con Refuerzos en Hombros', category: 'Armadura Torso', culturalOrigin: 'Laboratorios de Alto Rendimiento', description: 'Favorece la circulación sanguínea y protege de rozaduras.' },
      { id: 'ARM_SPORT_TIGHTS', name: 'Mallas Técnicas con Paneles de Protección en Caderas y Rodillas', category: 'Piernas & Pies', culturalOrigin: 'Atletismo Profesional', description: 'Tejido elástico de alta resistencia a la abrasión con bolsillos termosellados.' }
    ],
    culturalAccessories: [
      { id: 'ACC_SPORT_WATCH', name: 'Reloj Deportivo Inteligente con Monitor de Frecuencia y Oxígeno', category: 'Accesorio Sagrado', culturalOrigin: 'Tecnología Fitness', description: 'Pantalla OLED con datos de rendimiento en tiempo real.' },
      { id: 'ACC_SPORT_GLASSES', name: 'Gafas de Sol Envolventes con Lentes Iridiscentes Antivaho', category: 'Cabeza & Máscara', culturalOrigin: 'Ciclismo de Élite', description: 'Montura ultraligera de policarbonato con sujeción antideslizante.' }
    ],
    spiritualMotifs: [
      'Rayo Dinámico con Líneas de Velocidad',
      'Gráfico de Pulso Cardíaco en Aceleración',
      'Llama Olímpica de la Superación'
    ],
    silkPatterns: [
      'Spandex y Elastano de Compresión 4-Way Stretch',
      'Malla Mesh Transpirable de Secado Instantáneo',
      'Nylon Ultraligero Cortavientos'
    ],
    jadeColors: [
      { id: 'electric_blue', name: 'Azul Eléctrico Rendimiento', hex: '#2563EB', desc: 'Energía activa y concentración' },
      { id: 'neon_lime', name: 'Amarillo Lima Neón', hex: '#A3E635', desc: 'Visibilidad máxima y vitalidad' },
      { id: 'carbon_black_sport', name: 'Negro Carbón Deportivo', hex: '#18181B', desc: 'Elegancia atlética sobria' }
    ],
    weapons: [
      { name: 'Arco Olímpico de Competición con Estabilizadores de Carbono', type: 'Arco de Precisión', desc: 'Precisión milimétrica a larga distancia' },
      { name: 'Bate de Titanio Ultraligero con Empuñadura Grip de Goma', type: 'Arma Contundente', desc: 'Velocidad de swing devastadora' }
    ],
    auras: [
      'Estela de Viento y Distorsión de Velocidad Cinética',
      'Sin Aura (Rendimiento Físico Puro)'
    ]
  },

  'Urbano Moderno': {
    styleName: 'Urbano Moderno',
    title: 'Urbano Moderno, Streetwear & Cultura de Ciudad',
    tag: '🏙️ Streetwear / Skater / Casual Chic',
    subtitle: 'Chaquetas Bomber, Denim Envejecido, Sneakers de Colección y Gorras',
    description: 'Sudaderas oversized con capucha, chaquetas vaqueras con parches, pantalones vaqueros rotos o chinos holgados, gorras snapback, cadenas de eslabones y auriculares over-ear.',
    traditions: [
      {
        id: 'STREET_TRENDSETTER',
        name: 'Trendsetter Urbano / Skater de Metrópolis',
        subtitle: 'Estilo de Calle, Libertad y Cultura Contemporánea',
        category: 'Streetwear & Ciudad',
        description: 'Chaqueta bomber de satén con parches, sudadera con capucha debajo, vaqueros anchos desgastados, sneakers de edición limitada y cadena de plata al cuello.',
        iconTag: '🛹 Streetwear',
        suggestedArmor: ['Chaqueta Bomber Acolchada con Forro Naranja y Parches', 'Chaleco Acolchado Puffer Ligero con Cremallera'],
        suggestedAccessories: ['Gorra Snapback con Visera Plana y Logotipo Bordado', 'Auriculares de Diadema Inalámbricos con Cancelación de Ruido', 'Cadena de Eslabones Cubanos de Plata en el Cuello'],
        suggestedWeapon: 'Tabla de Skate Reforzada con Ejes de Titanio / Spray de Grafiti',
        suggestedMotif: 'Grafiti Callejero & Letras en Bomba',
        suggestedSilk: 'Algodón Pesado Heavyweight y Denim Lavado a la Piedra',
        suggestedJade: 'Plata Urbana Pulida',
        suggestedAura: 'Vapor de Bocas de Riego & Luces de Neón de la Ciudad'
      }
    ],
    armorPieces: [
      { id: 'ARM_URB_BOMBER', name: 'Chaqueta Bomber de Nylon Acolchado con Bolsillo en Manga', category: 'Armadura Torso', culturalOrigin: 'Streetwear Clásico', description: 'Protección cómoda contra el frío urbano con cremalleras metálicas robustas.' },
      { id: 'ARM_URB_HOODIE', name: 'Sudadera Oversized de Algodón Pesado de 450 GSM', category: 'Armadura Torso', culturalOrigin: 'Cultura Urbana', description: 'Prenda confortable con bolsillo canguro y capucha de doble forro.' }
    ],
    culturalAccessories: [
      { id: 'ACC_URB_HEADPHONES', name: 'Auriculares Over-Ear Inalámbricos de Alta Fidelidad', category: 'Accesorio Sagrado', culturalOrigin: 'Audio Urbano', description: 'Aislamiento sonoro para sumergirse en la música mientras se recorre la metrópoli.' },
      { id: 'ACC_URB_CHAIN', name: 'Cadena de Eslabones Cubanos de Plata con Dije Urbano', category: 'Joyería & Cabello', culturalOrigin: 'Joyería Callejera', description: 'Collar pesado de eslabones pulidos que aporta presencia visual.' }
    ],
    spiritualMotifs: [
      'Grafiti Tagging con Spray de Pintura',
      'Horizonte de Rascacielos de Metrópolis Nocturna',
      'Casete Retro y Auriculares Cruzados'
    ],
    silkPatterns: [
      'Denim Lavado a la Piedra con Rotos Artesanales',
      'Algodón Peinado Francés Terry Suave',
      'Nylon Satinado de Bomber'
    ],
    jadeColors: [
      { id: 'urban_silver', name: 'Plata Brillante Callejera', hex: '#94A3B8', desc: 'Joyas y cadenas de plata maciza' },
      { id: 'matte_black_denim', name: 'Negro Denim Lavado', hex: '#1E293B', desc: 'El básico imprescindible de la ciudad' },
      { id: 'varsity_red', name: 'Rojo Universitario Varsity', hex: '#DC2626', desc: 'Contraste en chaquetas y parches' }
    ],
    weapons: [
      { name: 'Tabla de Skate con Tabla de Arce Canadiense y Ejes Reforzados', type: 'Arma Contundente / Transporte', desc: 'Movilidad ágil y golpe contundente en defensa propia' },
      { name: 'Bote de Spray de Grafiti con Boquilla de Presión Rápida', type: 'Herramienta de Distracción', desc: 'Ciega temporalmente y marca objetivos' }
    ],
    auras: [
      'Reflejos de Luces de Tráfico y Farolas de Neón en el Asfalto Húmedo',
      'Sin Aura (Vida Urbana Cotidiana y Realista)'
    ]
  },

  'Minimalista': {
    styleName: 'Minimalista',
    title: 'Minimalista, Zen & Arquitectura Pura',
    tag: '⚪ Zen / Monocromo / Piel Pura',
    subtitle: 'Líneas Puras, Ausencia de Ornamento Superfluo y Paz Visual',
    description: 'Prendas con cortes geométricos limpios, sin botones visibles, paletas monocromáticas de blanco, crudo y gris, tejidos de lino y algodón puro y joyas geométricas sutiles.',
    traditions: [
      {
        id: 'ZEN_ARCHITECT',
        name: 'Arquitecto Zen / Esteta del Vacío',
        subtitle: 'Menos es Más: Perfección en la Simplicidad',
        category: 'Zen & Minimalismo',
        description: 'Túnica o camisa de lino crudo de corte recto, pantalón de pinzas de caída fluida, sandalias de cuero fino y anillo geométrico de plata pulida.',
        iconTag: '⚪ Zen Puro',
        suggestedArmor: ['Túnica de Lino Crudo con Cierre Oculto y Cuello Mao', 'Chaleco Recto Monocromático sin Costuras Visibles'],
        suggestedAccessories: ['Anillo de Banda Ancha de Plata Mate sin Grabados', 'Bolso Tote de Lona Japonesa con Asas Ocultas', 'Colgante de Círculo Ensō en Cerámica Blanca'],
        suggestedWeapon: 'Vara Recta de Bambú Pulido con Remate de Plata',
        suggestedMotif: 'Círculo Ensō de Tinta Negra & Línea Recta Infinita',
        suggestedSilk: 'Lino Japonés Lavado y Algodón Pima Monocromo',
        suggestedJade: 'Cerámica Blanca Nieve Mate',
        suggestedAura: 'Luz Blanca Difusa y Silencio Absoluto'
      }
    ],
    armorPieces: [
      { id: 'ARM_MIN_TUNIC', name: 'Túnica de Lino Puro con Costuras Interiores Ocultas', category: 'Armadura Torso', culturalOrigin: 'Diseño Zen Japonés', description: 'Pureza de forma que permite respirar a la piel y calma la mente.' }
    ],
    culturalAccessories: [
      { id: 'ACC_MIN_RING', name: 'Anillo de Banda Lisa en Plata 925 con Acabado Arenado', category: 'Joyería & Cabello', culturalOrigin: 'Joyería Minimalista', description: 'Belleza elemental sin piedras ni inscripciones.' }
    ],
    spiritualMotifs: [
      'Círculo Ensō Trazado de un Solo Trazo de Pincel',
      'Línea Horizontal del Horizonte Calmo',
      'Piedra de Río Pulida en Equilibrio Zen'
    ],
    silkPatterns: [
      'Lino Orgánico de Caída Natural sin Tintes Químicos',
      'Algodón Japonés de Hilado Lento'
    ],
    jadeColors: [
      { id: 'snow_white_zen', name: 'Blanco Nieve / Papel Washi', hex: '#F8FAFC', desc: 'Luz y pureza del vacío' },
      { id: 'stone_grey_zen', name: 'Gris Piedra de Río', hex: '#64748B', desc: 'Neutralidad y equilibrio sereno' }
    ],
    weapons: [
      { name: 'Vara de Madera de Fresno Pulida al Aceite Natural', type: 'Arma Contundente Simple', desc: 'Simplicidad perfecta para defensa sin ostentación' }
    ],
    auras: [
      'Aura de Calma Zen y Luz Blanca Difusa',
      'Sin Aura (Simplicidad y Realismo Serena)'
    ]
  },

  'Romántico / Boudoir': {
    styleName: 'Romántico / Boudoir',
    title: 'Romántico, Boudoir & Romance Nupcial',
    tag: '💐 Boudoir / Bridal / Romance / Sensual',
    subtitle: 'Encajes Florales de Chantilly, Sedas Nupciales, Lazos y Transparencias Vaporosas',
    description: 'Babydolls de tul translúcido, peignoirs de satén con ribetes de plumas, corsés nupciales de varillas visibles, negligés de seda y gasa, ligueros bordados y joyas corporales de perlas y rubíes.',
    traditions: [
      {
        id: 'BRIDAL_BOUDOIR_ROYALE',
        name: 'Boudoir Nupcial / Novia Eterna',
        subtitle: 'Satén Nupcial Marfil, Copas de Encaje y Velo Vaporoso',
        category: 'Romance Nupcial',
        description: 'Corsé nupcial semitransparente con copas balconette, falda de tul abierta al frente, peignoir de satén con ribete de plumas de marabú, velo de novia corto con corona de flores y medias de seda blanca con ligas de encaje.',
        iconTag: '💍 Bridal Royale',
        suggestedArmor: ['Vestido de Novia Erótico con Faldón Abierto', 'Corsé Bustier de Encaje de Chantilly'],
        suggestedAccessories: ['Velo Nupcial Romántico de Novia con Corona de Flores', 'Medias Nupciales de Seda Blanca Bordada', 'Sandalias Nupciales Románticas con Cintas de Satén'],
        suggestedWeapon: 'Cetro Nupcial de Cristal de Cuarzo Rosa con Cinta de Raso',
        suggestedMotif: 'Anillo de Bodas Entrelazado con Rosa Blanca y Cinta de Satén',
        suggestedSilk: 'Tul Nupcial Translúcido y Satén Líquido Marfil',
        suggestedJade: 'Blanco Nupcial Perla & Oro Rosa Champagne',
        suggestedAura: 'Destellos de Luz Dorada Cálida y Pétalos Blancos Flotantes'
      },
      {
        id: 'SCARLET_ROMANCE_COVENANT',
        name: 'Romance Carmesí Dinástico / Boudoir de Seda',
        subtitle: 'Seda Oriental Translúcida, Aberturas Extremas y Cadenas Doradas',
        category: 'Romance Oriental & Sensual',
        description: 'Micro qipao de gasa translúcida con escote gota en el busto y aberturas hasta la cintura, negligé de seda con ribetes dorados, orejitas suaves con lazos y cascabeles y cadenas de cintura de oro puro.',
        iconTag: '🦊 Scarlet Covenant',
        suggestedArmor: ['Micro Qipao / Cheongsam Erótico con Aberturas Extremas', 'Kimono / Haori Erótico de Seda Translúcida'],
        suggestedAccessories: ['Diadema de Orejas Kemono con Lazos y Campanillas', 'Cadena Erótica de Caderas con Cascabeles de Oro', 'Tacones Lace-up de Tiras Cruzadas hasta la Rodilla'],
        suggestedWeapon: 'Abanico de Cuchillas Doradas de Fénix Carmesí',
        suggestedMotif: 'Flor de Loto Carmesí con Dragón Dorado Entrelazado',
        suggestedSilk: 'Gasa de Seda Translúcida con Bordados de Hilos de Oro',
        suggestedJade: 'Rojo Escarlata Sangre de Loto & Oro Imperial',
        suggestedAura: 'Pétalos de Flor de Cerezo Brillantes y Campanas Tintineantes'
      },
      {
        id: 'SWEET_GOTHIC_BOUDOIR',
        name: 'Boudoir Gótico / Muñeca Victoriana Enamorada',
        subtitle: 'Terciopelo Oscuro, Encaje Negro y Camafeos de Amor Eterno',
        category: 'Dark Romance & Boudoir Gótico',
        description: 'Corsé ajustado de terciopelo con ribete de encaje floral, babydoll de tul negro transparente con lazos carmesí, gargantilla con corazón de rubí y medias con costura trasera y ligas de cuero fino.',
        iconTag: '🖤 Gothic Boudoir',
        suggestedArmor: ['Top Corsé Bustier de Encaje con Varillas Vistas', 'Peignoir Romántico de Tul y Encaje'],
        suggestedAccessories: ['Gargantilla Romántica de Encaje con Corazón de Rubí', 'Medias Translúcidas con Costura Trasera y Corazones', 'Guantes de Encaje Romántico Transparentes'],
        suggestedWeapon: 'Daga Romántica de Filigrana de Plata con Empuñadura de Corazón',
        suggestedMotif: 'Corazón de Filigrana Barroca con Espinas y Rosa Negra',
        suggestedSilk: 'Encaje Negro de Chantilly y Terciopelo Púrpura Nocturno',
        suggestedJade: 'Rubí Corazón Sangrante & Plata de Ley',
        suggestedAura: 'Bruma Violeta Suave con Pétalos de Rosa Oscura'
      }
    ],
    armorPieces: [
      { id: 'ARM_ROM_CORSET', name: 'Corsé Nupcial Translúcido con Copas Balconette y Encaje de Chantilly', category: 'Armadura Torso', culturalOrigin: 'Boudoir Romance', description: 'Corsetería de alta gama con transparencias de tul y copas armadas.' },
      { id: 'ARM_ROM_BABYDOLL', name: 'Babydoll Nupcial Romántico con Faldón Vaporoso de Tul', category: 'Armadura Torso', culturalOrigin: 'Lencería Nupcial', description: 'Prenda ligera y transparente con volantes y lazos de novia.' },
      { id: 'ARM_ROM_ROBE', name: 'Robe Nupcial de Satén con Ribete de Plumas de Marabú', category: 'Hombreras & Brazos', culturalOrigin: 'Boudoir de Lujo', description: 'Bata larga de satén suave con mangas amplias y ribetes afelpados.' }
    ],
    culturalAccessories: [
      { id: 'ACC_ROM_VEIL', name: 'Velo Nupcial Romántico de Tul con Corona de Flores', category: 'Joyería & Cabello', culturalOrigin: 'Romance Nupcial', description: 'Velo vaporoso transparente que cae delicadamente sobre los hombros.' },
      { id: 'ACC_ROM_CHOKER', name: 'Gargantilla Romántica de Encaje con Corazón de Rubí', category: 'Joyería & Cabello', culturalOrigin: 'Romance Clásico', description: 'Banda de encaje floral con dije en forma de corazón y pequeña perla colgante.' },
      { id: 'ACC_ROM_GARTERS', name: 'Medias de Liga Románticas con Banda de Encaje Ancha', category: 'Accesorio Sagrado', culturalOrigin: 'Lencería Fina', description: 'Medias de seda con banda superior de encaje floral siliconada.' }
    ],
    spiritualMotifs: [
      'Corazón de Filigrana con Rosa Blanca y Cinta de Raso',
      'Anillo de Bodas Entrelazado con Lazo de Satén',
      'Cisnes Blancos Formando un Corazón sobre Aguas Cristalinas',
      'Camafeo Victoriano con Silueta de Amantes'
    ],
    silkPatterns: [
      'Tul Nupcial Marfil Translúcido',
      'Encaje Floral Francés de Chantilly',
      'Satén Nupcial con Brillo Sedoso Líquido',
      'Gasa de Seda Translúcida con Destellos de Purpurina'
    ],
    jadeColors: [
      { id: 'bridal_champagne', name: 'Champagne Nupcial Suave', hex: '#FDF2E9', desc: 'Elegancia, ternura y pureza romántica' },
      { id: 'rose_petal_pink', name: 'Rosa Pétalo Romántico', hex: '#FBCFE8', desc: 'Dulzura, amor y pasión contenida' },
      { id: 'ruby_passion_rom', name: 'Rubí Pasión de Amor', hex: '#BE123C', desc: 'Amor eterno y devoción incondicional' },
      { id: 'ivory_pearl_rom', name: 'Blanco Marfil Perlado', hex: '#FAF5FF', desc: 'Lustre de perlas nupciales' }
    ],
    weapons: [
      { name: 'Cetro Nupcial de Cristal de Cuarzo Rosa con Cinta de Raso', type: 'Cetro Mágico', desc: 'Canalización de encantamientos de atracción y amor' },
      { name: 'Daga de Duelo Romántica con Filigrana de Rosas', type: 'Daga Ornamental', desc: 'Hoja estilizada con empuñadura engastada en rubíes' }
    ],
    auras: [
      'Destellos de Luz Dorada Cálida y Pétalos Blancos Flotantes',
      'Bruma Rosada Suave con Perfume de Rosas y Vainilla',
      'Pétalos de Flor de Cerezo Brillantes y Campanas Tintineantes',
      'Sin Aura (Sensualidad Íntima y Natural)'
    ]
  },

  'Casual': {
    styleName: 'Casual',
    title: 'Casual, Práctico & Diario',
    tag: '☕ Cómodo / Cotidiano / Versátil',
    subtitle: 'Comodidad Funcional, Algodón Suave y Prendas de Uso Diario',
    description: 'Camisetas de algodón suave, cárdigans de punto, vaqueros cómodos, mochilas ligeras, zapatillas canvas y accesorios sencillos para el día a día.',
    traditions: [
      {
        id: 'EVERYDAY_ADVENTURER',
        name: 'Aventurero Cotidiano / Trotamundos Urbano',
        subtitle: 'Versatilidad, Confort y Frescura Diaria',
        category: 'Estilo Diario',
        description: 'Chaqueta vaquera suave, camiseta de algodón orgánico, mochila de tela y reloj sencillo de esfera limpia.',
        iconTag: '☕ Casual',
        suggestedArmor: ['Chaqueta Cazadora Vaquera con Forro de Borreguito', 'Cárdigan de Punto Grueso con Botones de Madera'],
        suggestedAccessories: ['Mochila de Lona Ligera con Compartimento para Termo', 'Reloj de Pulsera Analógico con Correa de Tela', 'Gafas de Sol Clásicas Wayfarer'],
        suggestedWeapon: 'Navaja Suiza Multiusos con Bloqueo de Hoja',
        suggestedMotif: 'Brújula Sencilla de Trazo Fino & Hoja de Café',
        suggestedSilk: 'Algodón Peinado 100% Orgánico y Punto de Lana',
        suggestedJade: 'Acero Inoxidable Mate',
        suggestedAura: 'Resplandor Cálido de Café de Mañana'
      }
    ],
    armorPieces: [
      { id: 'ARM_CAS_JACKET', name: 'Cazadora de Cuero Sintético Suave o Denim con Bolsillos Prácticos', category: 'Armadura Torso', culturalOrigin: 'Moda Cotidiana', description: 'Protección ligera para el día a día.' }
    ],
    culturalAccessories: [
      { id: 'ACC_CAS_WATCH', name: 'Reloj Analógico Diario con Correa de Cuero o Nylon', category: 'Accesorio Sagrado', culturalOrigin: 'Uso Diario', description: 'Control de tiempo fiable y discreto.' }
    ],
    spiritualMotifs: [
      'Taza de Café con Voluta de Vapor',
      'Brújula Sencilla de Exploración Cotidiana'
    ],
    silkPatterns: [
      'Algodón Suave Preencogido',
      'Punto de Lana Transpirable'
    ],
    jadeColors: [
      { id: 'warm_beige', name: 'Beige Cálido y Tostado', hex: '#D97706', desc: 'Comodidad y calidez hogareña' },
      { id: 'classic_denim_blue', name: 'Azul Denim Clásico', hex: '#2563EB', desc: 'Versatilidad de uso diario' }
    ],
    weapons: [
      { name: 'Navaja de Bolsillo Clásica con Cachas de Madera', type: 'Herramienta de Uso Diario', desc: 'Práctica para tareas cotidianas y defensa de emergencia' }
    ],
    auras: [
      'Sin Aura (Aspecto Natural y Espontáneo)'
    ]
  }
};

export function getStyleThematicPackage(styleName?: string): StyleThematicDataPackage {
  if (!styleName) return ALL_STYLE_THEMATIC_DATA['Fantasía Oriental'];
  if (ALL_STYLE_THEMATIC_DATA[styleName]) return ALL_STYLE_THEMATIC_DATA[styleName];
  
  // Try partial or case-insensitive matching
  const lower = styleName.toLowerCase().trim();
  const keys = Object.keys(ALL_STYLE_THEMATIC_DATA);
  const found = keys.find(k => k.toLowerCase() === lower || k.toLowerCase().includes(lower) || lower.includes(k.toLowerCase()));
  if (found) return ALL_STYLE_THEMATIC_DATA[found];
  
  return ALL_STYLE_THEMATIC_DATA['Fantasía Oriental'] || ALL_STYLE_THEMATIC_DATA['Fantasía Tradicional'];
}
