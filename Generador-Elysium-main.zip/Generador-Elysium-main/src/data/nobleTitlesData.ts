export interface NobleTitleOption {
  id: string;
  name: string;
  maleTitle: string;
  femaleTitle: string;
  neutralTitle: string;
  rankCategory: 'Alta Nobleza Soberana' | 'Nobleza Titulada Clásica' | 'Dignidad Feudal & Cortesana';
  precedenceLevel: number;
  treatment: string;
  heraldicCoronet: string;
  description: string;
  suggestedFiefTypes: string[];
  suggestedPiece: string;
  fiefExamples: string[];
}

export const NOBLE_TITLES_CATALOG: NobleTitleOption[] = [
  {
    id: 'archiduque',
    name: 'Archiduque / Archiduquesa',
    maleTitle: 'Archiduque',
    femaleTitle: 'Archiduquesa',
    neutralTitle: 'Archiduque / Archiduquesa',
    rankCategory: 'Alta Nobleza Soberana',
    precedenceLevel: 1,
    treatment: 'Su Alteza Imperial y Real',
    heraldicCoronet: 'Corona imperial archiducal de ocho florones con arco cerrado y orbe crucífero',
    description: 'Soberanía de sangre imperial por encima de los duques ordinarios, señorío sobre archiducados históricos y representación dinástica suprema.',
    suggestedFiefTypes: ['Archiducado', 'Principado Hereditario'],
    suggestedPiece: 'P1.1 Tiara de Filigrana de Oro con Gemas Finas',
    fiefExamples: ['de Austria Mayor', 'de las Tierras del Sol', 'de Valgrave Imperial', 'de Corona Alta']
  },
  {
    id: 'gran_duque',
    name: 'Gran Duque / Gran Duquesa',
    maleTitle: 'Gran Duque',
    femaleTitle: 'Gran Duquesa',
    neutralTitle: 'Gran Duque / Gran Duquesa',
    rankCategory: 'Alta Nobleza Soberana',
    precedenceLevel: 2,
    treatment: 'Su Alteza Real',
    heraldicCoronet: 'Corona gran ducal con bonete de terciopelo carmesí y florones enjoyados',
    description: 'Príncipe o soberano regente de un Gran Ducado autónomo, dotado de prerrogativas regias, consejo de estado y guardia ducal.',
    suggestedFiefTypes: ['Gran Ducado', 'Dominio Ducal Autónomo'],
    suggestedPiece: 'P1.1 Tiara de Filigrana de Oro con Gemas Finas',
    fiefExamples: ['de Lunaria', 'de Rosavalle', 'de las Marcas Plateadas', 'de Monteclaro']
  },
  {
    id: 'duque',
    name: 'Duque / Duquesa',
    maleTitle: 'Duque',
    femaleTitle: 'Duquesa',
    neutralTitle: 'Duque / Duquesa',
    rankCategory: 'Nobleza Titulada Clásica',
    precedenceLevel: 3,
    treatment: 'Su Gracia / Excelentísimo/a Señor/a',
    heraldicCoronet: 'Corona de oro puro engastada con ocho florones en forma de hojas de acanto',
    description: 'El rango más distinguido de la nobleza titulada. Gobierna grandes provincias feudales con mando de huestes, vasallos y corte ducal propia.',
    suggestedFiefTypes: ['Ducado', 'Señorío Mayor'],
    suggestedPiece: 'P1.1 Tiara de Filigrana de Oro con Gemas Finas',
    fiefExamples: ['de Valgrave', 'de las Tierras Altas', 'de Oromar', 'de Sommerguard']
  },
  {
    id: 'marques',
    name: 'Marqués / Marquesa',
    maleTitle: 'Marqués',
    femaleTitle: 'Marquesa',
    neutralTitle: 'Marqués / Marquesa',
    rankCategory: 'Nobleza Titulada Clásica',
    precedenceLevel: 4,
    treatment: 'Ilustrísimo/a Señor/a',
    heraldicCoronet: 'Corona de cuatro florones de hojas alternados con cuatro perlas alzadas',
    description: 'Gobernante militar y político de una Marca o provincia fronteriza del reino, responsable de defender los confines ante amenazas externas.',
    suggestedFiefTypes: ['Marquesado', 'Marca Fronteriza', 'Bastión de la Frontera'],
    suggestedPiece: 'P1.4 Diadema Heráldica con Blasón Nobiliario',
    fiefExamples: ['de la Frontera Plateada', 'del Paso de Hierro', 'de las Cumbres', 'de Vientofrío']
  },
  {
    id: 'conde',
    name: 'Conde / Condesa',
    maleTitle: 'Conde',
    femaleTitle: 'Condesa',
    neutralTitle: 'Conde / Condesa',
    rankCategory: 'Nobleza Titulada Clásica',
    precedenceLevel: 5,
    treatment: 'Ilustrísimo/a Señor/a',
    heraldicCoronet: 'Corona circular de oro con dieciocho perlas alzadas sobre puntas de filigrana',
    description: 'Señorío territorial tradicional sobre un condado. Máxima autoridad judicial, recaudadora y feudal de villas, castillos y tierras fértiles.',
    suggestedFiefTypes: ['Condado', 'Tierras Condales', 'Comarca Señorial'],
    suggestedPiece: 'P1.2 Sombrero de Terciopelo con Pluma de Pavo Real y Broche de Oro',
    fiefExamples: ['de Rosavalle', 'de Valdorada', 'de Monteverde', 'de Robleblanco']
  },
  {
    id: 'vizconde',
    name: 'Vizconde / Vizcondesa',
    maleTitle: 'Vizconde',
    femaleTitle: 'Vizcondesa',
    neutralTitle: 'Vizconde / Vizcondesa',
    rankCategory: 'Nobleza Titulada Clásica',
    precedenceLevel: 6,
    treatment: 'Ilustre Señor/a',
    heraldicCoronet: 'Corona de oro con cuatro grandes perlas sobre puntas elevadas',
    description: 'Antiguo vicario o lugarteniente de gran condado transformado en dignidad hereditaria propia, con castillo solariego y tierras patrimoniales.',
    suggestedFiefTypes: ['Vizcondado', 'Señorío de Valle', 'Solar Histórico'],
    suggestedPiece: 'P1.3 Tocado de Seda con Redecilla de Perlas',
    fiefExamples: ['de Canto Claro', 'de la Rivera Serena', 'de Alborada', 'de Peñanoble']
  },
  {
    id: 'baron',
    name: 'Barón / Baronesa',
    maleTitle: 'Barón',
    femaleTitle: 'Baronesa',
    neutralTitle: 'Barón / Baronesa',
    rankCategory: 'Nobleza Titulada Clásica',
    precedenceLevel: 7,
    treatment: 'Noble Señoría',
    heraldicCoronet: 'Diadema de oro rodeada por una faja de perlas finas entrelazadas',
    description: 'Titular directo de una baronía feudal, con baluarte o torreón de linaje y jurisdicción directa sobre sus aldeas vasallas.',
    suggestedFiefTypes: ['Baronía', 'Feudo Directo', 'Fuerte Solariego'],
    suggestedPiece: 'P1.4 Diadema Heráldica con Blasón Nobiliario',
    fiefExamples: ['de Rocaverde', 'de Fuenteblanca', 'de los Robles', 'de Colina Serena']
  },
  {
    id: 'lord_lady',
    name: 'Lord / Lady (Par del Reino)',
    maleTitle: 'Lord',
    femaleTitle: 'Lady',
    neutralTitle: 'Lord / Lady',
    rankCategory: 'Dignidad Feudal & Cortesana',
    precedenceLevel: 8,
    treatment: 'Mi Lord / Mi Lady / Su Señoría',
    heraldicCoronet: 'Anillo de sello dinástico y manto forrado en armiño con broche nobiliario',
    description: 'Dignidad aristocrática de alto prestigio con asiento en la cámara de los pares y consejo consultivo directo ante la corona.',
    suggestedFiefTypes: ['Mansión Señorial', 'Dominio de la Corte', 'Heredad Familiar'],
    suggestedPiece: 'P1.5 Monóculo de Oro con Cadena Fina de Eslabones',
    fiefExamples: ['de la Casa Solaris', 'de Ravenswood', 'de Highgarden', 'de Winterstone']
  },
  {
    id: 'patricio',
    name: 'Patricio / Dama de Alta Estirpe',
    maleTitle: 'Patricio',
    femaleTitle: 'Dama Patricia',
    neutralTitle: 'Patricio / Dama de Alta Estirpe',
    rankCategory: 'Dignidad Feudal & Cortesana',
    precedenceLevel: 9,
    treatment: 'Venerable Señoría',
    heraldicCoronet: 'Medallón cívico de oro macizo y broche senatorial de nácar',
    description: 'Nobleza patricia y oligárquica de grandes ciudades libres, gremios magnates y senados metropolitanos de linaje mercantil.',
    suggestedFiefTypes: ['Palacio Urbano', 'Gran Senado Cívico', 'Emporio Patriarcal'],
    suggestedPiece: 'P1.5 Monóculo de Oro con Cadena Fina de Eslabones',
    fiefExamples: ['del Gran Senado', 'de la Ciudad del Puerto', 'de la Casa del Nácar', 'de la Vía Áurea']
  },
  {
    id: 'castellano',
    name: 'Señor / Señora Feudal (Castellano/a)',
    maleTitle: 'Señor Feudal / Castellano',
    femaleTitle: 'Señora Feudal / Castellana',
    neutralTitle: 'Señor/a Feudal (Castellano/a)',
    rankCategory: 'Dignidad Feudal & Cortesana',
    precedenceLevel: 10,
    treatment: 'Noble Señor / Señora',
    heraldicCoronet: 'Llaves de oro del castillo y tahalí heráldico con blasón en relieve',
    description: 'Guardián y administrador señorial de una fortaleza inexpugnable, con mando sobre guarniciones de mesnada y peajes del valle.',
    suggestedFiefTypes: ['Castillo Baluarte', 'Señorío Territorial', 'Torreón Guardián'],
    suggestedPiece: 'P1.4 Diadema Heráldica con Blasón Nobiliario',
    fiefExamples: ['del Valle de la Luna', 'del Risco Gris', 'de la Fortaleza del Viento', 'de Aldea Real']
  },
  {
    id: 'hidalgo',
    name: 'Hidalgo / Dama de Linaje Antiguo',
    maleTitle: 'Hidalgo',
    femaleTitle: 'Hidalga / Dama de Linaje',
    neutralTitle: 'Hidalgo / Dama de Linaje Antiguo',
    rankCategory: 'Dignidad Feudal & Cortesana',
    precedenceLevel: 11,
    treatment: 'Don / Doña / Noble Sangre',
    heraldicCoronet: 'Blasón familiar grabado en el estoque y carta de ejecutoría de nobleza',
    description: 'Nobleza de sangre ancestral libre de tributos, poseedor de casa solariega, árbol genealógico probado y código de honor intachable.',
    suggestedFiefTypes: ['Casa Solariega', 'Hidalguía de Sangre', 'Heredad Ancestral'],
    suggestedPiece: 'P1.2 Sombrero de Terciopelo con Pluma de Pavo Real y Broche de Oro',
    fiefExamples: ['de Sangre Azul', 'de la Casa Antigua', 'del Solar de Piedra', 'de Alcázar']
  }
];

export const NOBLE_FIEF_SUGGESTIONS = [
  'de Valgrave',
  'de Rosavalle',
  'de las Tierras Altas',
  'de la Casa Solaris',
  'de las Marcas Plateadas',
  'de Monteclaro',
  'de Oromar',
  'de Lunaria',
  'de Ravenswood',
  'del Ducado del Viento',
  'de Sommerguard',
  'de Robleblanco'
];
