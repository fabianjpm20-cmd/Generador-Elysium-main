export interface CoverageZoneCategory {
  id: string;
  categoryName: string;
  iconName?: string;
  zones: string[];
}

export interface CoveragePreset {
  id: string;
  name: string;
  description: string;
  icon: string;
  zones: string[];
  style: string;
  details: string;
}

export const COVERAGE_ZONES_BY_CATEGORY: CoverageZoneCategory[] = [
  {
    id: 'cabeza_cuello',
    categoryName: 'Cabeza, Rostro & Cuello',
    zones: [
      'Cabeza y Rostro Frontal',
      'Cuello y Garganta',
      'Nuca y Vértebras Cervicales',
      'Orejas y Zonas Temporales',
      'Mandíbula y Mentón'
    ]
  },
  {
    id: 'torso_tronco',
    categoryName: 'Torso, Pecho & Tronco',
    zones: [
      'Clavículas y Hombros',
      'Pecho / Busto Frontal',
      'Torso y Pectoral Completo',
      'Espalda Alta y Omóplatos',
      'Espalda Baja y Zona Lumbar',
      'Costados y Flancos Torácicos',
      'Cintura y Abdomen'
    ]
  },
  {
    id: 'pelvis_caderas',
    categoryName: 'Pelvis, Caderas & Glúteos',
    zones: [
      'Pretina / Cintura Pélvica',
      'Caderas y Flancos Pélvicos',
      'Pelvis y Zona Inguinal',
      'Zona Glútea e Isquiones',
      'Cóccix y Base Sacra'
    ]
  },
  {
    id: 'brazos_manos',
    categoryName: 'Brazos, Articulaciones & Manos',
    zones: [
      'Hombros y Articulaciones Deltoides',
      'Brazos y Bíceps',
      'Codos y Articulaciones de Brazo',
      'Antebrazos y Muñecas',
      'Manos y Palmas',
      'Dedos y Nudillos'
    ]
  },
  {
    id: 'piernas_pies',
    categoryName: 'Piernas, Rodillas & Pies',
    zones: [
      'Muslos / Zona Femoral',
      'Rodillas y Rótulas Articulares',
      'Pantorrillas y Espinillas Tibiales',
      'Tobillos y Tendones de Aquiles',
      'Pies y Empeine',
      'Plantas y Talones'
    ]
  },
  {
    id: 'auras_manto',
    categoryName: 'Auras, Manto & Cobertura Especial',
    zones: [
      'Aura Periférica Envolvente (0–30 cm del cuerpo)',
      'Velo / Manto Flotante Suspendido',
      'Capa de Blindaje Cinético Externo',
      'Campo de Energía Espiritual / Chackras',
      'Halo / Proyección Craneal',
      'Base y Envergadura de Alas',
      'Base y Longitud de Cola'
    ]
  }
];

export const ALL_COVERAGE_ZONES: string[] = COVERAGE_ZONES_BY_CATEGORY.flatMap(c => c.zones);

export const COVERAGE_ADJUSTMENT_STYLES: string[] = [
  'Segunda Piel / Compresión Anatómica Ceñida',
  'Ajuste Ergonómico Táctico con Puntos Articulados',
  'Corte Estructurado Regular / Balance Equilibrado',
  'Cobertura Holgada / Caída Libre Fluida',
  'Cobertura Total Hermética / Sellado Blindado Completo',
  'Cobertura Parcial Estratégica / Puntos Vitales Blindados',
  'Cobertura Asimétrica Focalizada (Flanco Dominante)',
  'Cobertura Minimalista / Silueta Despejada',
  'Manto Místico / Velo Etéreo Translúcido',
  'Blindaje Pesado Superpuesto / Multicapa Modular'
];

export const VITAL_COVERAGE_ZONES: string[] = [
  'Cabeza y Rostro Frontal',
  'Cuello y Garganta',
  'Torso y Pectoral Completo',
  'Espalda Alta y Omóplatos',
  'Cintura y Abdomen',
  'Pelvis y Zona Inguinal'
];

export const COVERAGE_PRESETS: CoveragePreset[] = [
  {
    id: 'vanguardia_blindada',
    name: 'Vanguardia Blindada',
    description: 'Protección integral hermética en órganos vitales y grandes grupos musculares.',
    icon: 'Shield',
    zones: [
      'Torso y Pectoral Completo',
      'Clavículas y Hombros',
      'Espalda Alta y Omóplatos',
      'Muslos / Zona Femoral',
      'Rodillas y Rótulas Articulares',
      'Cuello y Garganta'
    ],
    style: 'Cobertura Total Hermética / Sellado Blindado Completo',
    details: 'Refuerzos de placas compuestas en caja torácica y articulaciones selladas.'
  },
  {
    id: 'infiltracion_sigilo',
    name: 'Infiltración & Sigilo',
    description: 'Compresión ceñida anatómica sin ruido de fricción para maniobras acrobáticas.',
    icon: 'Zap',
    zones: [
      'Torso y Pectoral Completo',
      'Antebrazos y Muñecas',
      'Cintura y Abdomen',
      'Muslos / Zona Femoral',
      'Tobillos y Tendones de Aquiles'
    ],
    style: 'Segunda Piel / Compresión Anatómica Ceñida',
    details: 'Tejido fonoabsorbente con bandas elásticas en muñecas y tobillos.'
  },
  {
    id: 'manto_arcano',
    name: 'Manto Místico Arcano',
    description: 'Envoltorio etéreo suspendido que canaliza la barrera protectora del personaje.',
    icon: 'Sparkles',
    zones: [
      'Aura Periférica Envolvente (0–30 cm del cuerpo)',
      'Velo / Manto Flotante Suspendido',
      'Cuello y Garganta',
      'Manos y Palmas'
    ],
    style: 'Manto Místico / Velo Etéreo Translúcido',
    details: 'Gradiente de resplandor astral que disipa impactos mágicos directos.'
  },
  {
    id: 'tactico_articulado',
    name: 'Táctico Urbano / Articulado',
    description: 'Modular con puntos de pivote reforzados para portar equipo y reaccionar con rapidez.',
    icon: 'Compass',
    zones: [
      'Torso y Pectoral Completo',
      'Costados y Flancos Torácicos',
      'Codos y Articulaciones de Brazo',
      'Antebrazos y Muñecas',
      'Pantorrillas y Espinillas Tibiales'
    ],
    style: 'Ajuste Ergonómico Táctico con Puntos Articulados',
    details: 'Costuras reforzadas con pasadores modulares y ventilación axilar.'
  },
  {
    id: 'gala_noble',
    name: 'Cortesano & Distinción Noble',
    description: 'Líneas estructuradas elegantes con drapeados medidos que proyectan estatus.',
    icon: 'Award',
    zones: [
      'Cuello y Garganta',
      'Clavículas y Hombros',
      'Pecho / Busto Frontal',
      'Cintura y Abdomen',
      'Caderas y Flancos Pélvicos'
    ],
    style: 'Corte Estructurado Regular / Balance Equilibrado',
    details: 'Entallado suave con forro interior de seda y caída sin arrugas.'
  },
  {
    id: 'explorador_asimetrico',
    name: 'Tirador / Explorador Asimétrico',
    description: 'Protección reforzada en el lado hábil y libertad completa en el brazo de tiro.',
    icon: 'Crosshair',
    zones: [
      'Hombros y Articulaciones Deltoides',
      'Pecho / Busto Frontal',
      'Antebrazos y Muñecas',
      'Rodillas y Rótulas Articulares',
      'Tobillos y Tendones de Aquiles'
    ],
    style: 'Cobertura Parcial Estratégica / Puntos Vitales Blindados',
    details: 'Hombrera de apoyo asimétrica y rodillera acolchada para disparos en tierra.'
  },
  {
    id: 'acrobata_minimal',
    name: 'Libertad / Acróbata Minimal',
    description: 'Cobertura despejada en puntos de anclaje para máxima flexibilidad motriz.',
    icon: 'Flame',
    zones: [
      'Pecho / Busto Frontal',
      'Cintura y Abdomen',
      'Manos y Palmas',
      'Pies y Empeine'
    ],
    style: 'Cobertura Minimalista / Silueta Despejada',
    details: 'Ribetes elásticos anti-deslizantes en bordes anatómicos.'
  }
];
