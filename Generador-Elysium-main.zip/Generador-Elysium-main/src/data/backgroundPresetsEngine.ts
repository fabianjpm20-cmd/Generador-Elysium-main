export interface ArchetypeOneClickPreset {
  id: string;
  name: string;
  category: string;
  description: string;
  archetype: string;
  personalityTraits: string[];
  coreValues: string;
  voiceTone: string;
  speechStyle: string;
  catchphrase: string;
  habits: string[];
  skills: string[];
  alignment: string;
  homelandOrDomain?: string;
  factionOrFaith?: string;
}

export interface TraitCategoryGroup {
  category: string;
  icon: string;
  traits: string[];
}

export interface CoreValueCategoryGroup {
  category: string;
  values: string[];
}

export const CATEGORIZED_TRAITS: TraitCategoryGroup[] = [
  {
    category: 'Virtudes & Honor',
    icon: 'Shield',
    traits: [
      'Noble', 'Leal', 'Compasivo', 'Valiente', 'Honesto', 'Humilde',
      'Protector', 'Justo', 'Idealista', 'Magnánimo', 'Incorruptible'
    ]
  },
  {
    category: 'Mente Táctica & Combate',
    icon: 'Swords',
    traits: [
      'Calculador', 'Pragmático', 'Astuto', 'Audaz', 'Intrépido',
      'Meticuloso', 'Estratégico', 'Imperturbable', 'Despiadado', 'Flemático'
    ]
  },
  {
    category: 'Sombras, Ambición & Defectos',
    icon: 'Flame',
    traits: [
      'Ambicioso', 'Arrogante', 'Vengativo', 'Cínico', 'Orgulloso',
      'Impulsivo', 'Rebelde', 'Desconfiado', 'Hedonista', 'Maligno', 'Agresivo'
    ]
  },
  {
    category: 'Pecado, Seducción & Provocación (Sexy)',
    icon: 'Heart',
    traits: [
      'Seductor', 'Provocador', 'Coqueto', 'Dominante', 'Sensual',
      'Insinuante', 'Descarado', 'Morboso', 'Insaciable', 'Apasionado'
    ]
  },
  {
    category: 'Oscuridad, Abismo & Edgy (Dark)',
    icon: 'Flame',
    traits: [
      'Sádico', 'Despiadado', 'Nihilista', 'Tóxico', 'Tenebroso',
      'Fascinado por el Dolor', 'Obsesivo', 'Traicionero', 'Corrupto', 'Feroz'
    ]
  },
  {
    category: 'Moderno, Cyberpunk & Urbano (Modern)',
    icon: 'Zap',
    traits: [
      'Cínico', 'Hiperracional', 'Tecnófilo',
      'Desarraigado', 'Desapegado', 'Nocturno', 'Minimalista Frío'
    ]
  },
  {
    category: 'Comportamiento & Tropes Psicológicos Anime',
    icon: 'Crown',
    traits: [
      'Mordaz / Afilado', 'Posesivo / Celoso', 'Burlón / Pícaro', 'Glacial / Inexpresivo',
      'Dramático / Teatral', 'Descarado / Insolente', 'Altivo / Exigente', 'Perezoso / Despreocupado',
      'Servicial', 'Protector'
    ]
  },
  {
    category: 'Carisma & Dinámica Social',
    icon: 'Crown',
    traits: [
      'Carismático', 'Teatral', 'Alegre', 'Sarcástico',
      'Elocuente', 'Misterioso', 'Diplomático', 'Excéntrico', 'Soñador'
    ]
  },
  {
    category: 'Temperamento & Emoción',
    icon: 'Heart',
    traits: [
      'Estoico', 'Serio', 'Calmado', 'Melancólico', 'Tímido',
      'Solitario', 'Perfeccionista', 'Enérgico', 'Apático', 'Curioso'
    ]
  }
];

export const CATEGORIZED_CORE_VALUES: CoreValueCategoryGroup[] = [
  {
    category: 'Honor & Principios Éticos',
    values: ['Honor', 'Justicia', 'Verdad', 'Deber', 'Lealtad', 'Redención', 'Protección del Débil']
  },
  {
    category: 'Placer, Deseo & Posesión (Sexy / Boudoir)',
    values: ['Placer & Hedonismo', 'Deseo Prohibido', 'Obsesión Romántica / Posesión', 'Control Absoluto & Dominación', 'Seducción & Conquista', 'Sumisión Devota']
  },
  {
    category: 'Oscuridad, Abismo & Destrucción (Dark)',
    values: ['Nihilismo & Aniquilación', 'Poder Maldito', 'Venganza Sangrienta', 'Caos & Corrupción', 'Inmortalidad a Toda Costa', 'Ruptura del Tabú']
  },
  {
    category: 'Poder & Dominio',
    values: ['Poder', 'Ambición Desmedida', 'Gloria', 'Venganza', 'Soberanía Individual', 'Legado Inmortal']
  },
  {
    category: 'Modernidad & Ciberespacio (Cyber / Modern)',
    values: ['Innovación Tecnológica', 'Ciber-Trascendencia', 'Libertad de la Red', 'Dinero & Estatus Corporativo', 'Fama & Culto Viral', 'Anonimato Digital']
  },
  {
    category: 'Destino de Anime & Gacha Legendario',
    values: ['Destino Ineludible', 'Devoción Ciega al Invocador / Master', 'Protección de la Waifu / Husbandu', 'Despertar del Linaje Oculto', 'Victoria Absoluta SSR']
  },
  {
    category: 'Libertad & Trascendencia',
    values: ['Libertad', 'Independencia', 'Caos', 'Instinto Salvaje', 'Equilibrio Cósmico', 'Armonía Espiritual']
  },
  {
    category: 'Conocimiento & Supervivencia',
    values: ['Conocimiento', 'Supervivencia', 'Innovación Tecnológica', 'Disciplina Férrea', 'Orden', 'Familia', 'Paz']
  }
];

export const ARCHETYPE_ONE_CLICK_PRESETS: ArchetypeOneClickPreset[] = [
  // 🌑 1. Emperatriz Oscura / Villana de Gacha SSR (Dark)
  {
    id: 'dark-gacha-empress',
    name: 'Emperatriz Oscura / Villana de Gacha SSR',
    category: 'Oscuro & Edgy',
    description: 'Soberana despiadada del abismo. Contempla el mundo como su tablero de ajedrez y exige sumisión de rodillas.',
    archetype: 'Emperatriz',
    personalityTraits: ['Calculador', 'Despiadado', 'Arrogante', 'Maligno', 'Estratégico', 'Misterioso'],
    coreValues: 'Control Absoluto & Dominación, Poder, Venganza Sangrienta, Legado Inmortal',
    voiceTone: 'Grave, dominante y autoritario con peso de terciopelo pesado',
    speechStyle: 'Susurros venenosos y órdenes dominantes indiscutibles con frialdad regia',
    catchphrase: '«De rodillas... aún no te he dado permiso para mirarme a los ojos.»',
    habits: [
      'Observa fijamente la garganta de las personas mientras hablan como evaluando una yugular',
      'Lame una gota de sangre o residuo arcano de su pulgar con deleite morboso',
      'Sonríe de medio lado con ironía ante situaciones de extremo peligro'
    ],
    skills: ['Maldiciones de sangre y enlaces empáticos de dolor', 'Manipulación de sombras umbrales y espectros devoradores', 'Tortura psicológica e interrogatorio mental invasivo'],
    alignment: 'Legal Malvado / Soberanía Absoluta'
  },
  // 💋 2. Femme Fatale Seductora / Súcubo Aristócrata (Sexy / Provocativo)
  {
    id: 'femme-fatale-succubus',
    name: 'Femme Fatale Seductora / Súcubo de Terciopelo',
    category: 'Provocativo & Sexy',
    description: 'Irresistible, peligrosa y decadente. Desarma a sus objetivos con miradas ardientes, dobles sentidos y dagas envenenadas.',
    archetype: 'Femme Fatale',
    personalityTraits: ['Seductor', 'Provocador', 'Coqueto', 'Audaz', 'Hedonista', 'Astuto'],
    coreValues: 'Placer & Hedonismo, Seducción & Conquista, Soberanía Individual, Ambición Desmedida',
    voiceTone: 'Fascinantemente ronco, oscuro y sensual (Femme Fatale / Vampiro)',
    speechStyle: 'Provocativo e insinuante con dobles sentidos continuos, jadeos suaves y susurros tentadores',
    catchphrase: '«¿Te gusta lo que ves, cariño... o prefieres que me acerque y te lo demuestre?»',
    habits: [
      'Se muerde el labio inferior o se acaricia la clavícula con mirada insinuante y sugerente',
      'Cruza lentamente las piernas con lentitud teatral captando todas las miradas de la sala',
      'Enrolla un mechón de cabello en el dedo mientras lanza una mirada coqueta bajo las pestañas'
    ],
    skills: ['Seducción hipnótica y lenguaje corporal magnético irresistible', 'Elaboración de feromonas afrodisíacas y filtros de amor embriagantes', 'Dagas envenenadas ocultas en liguero o corset de encaje'],
    alignment: 'Caótico Neutral / Tentación Pura'
  },
  // ⚡ 3. Netrunner Clandestino / Ciber-Hacker (Moderno / Cyberpunk)
  {
    id: 'cyber-netrunner-hacker',
    name: 'Netrunner Clandestino / Hacker Urbana',
    category: 'Moderno & Cyber',
    description: 'Rebelde del asfalto y el ciberespacio. Se mueve entre sombras de neón, glitcheando servidores y quebrando corporaciones.',
    archetype: 'Netrunner',
    personalityTraits: ['Cínico Digital', 'Rebelde', 'Pragmático', 'Astuto', 'Desapegado', 'Intrépido'],
    coreValues: 'Libertad de la Red, Ciber-Trascendencia, Innovación Tecnológica, Dinero & Estatus Corporativo',
    voiceTone: 'Sintético, filtrado con vocoder cibernético y leves glitches (Androide / Netrunner)',
    speechStyle: 'Slang urbano cyberpunk (términos de red, ICE, ciberimplantes, glitches y sarcasmo)',
    catchphrase: '«Tu firewall neuronal es un chiste; ya descargué tu memoria antes de que parpadearas.»',
    habits: [
      'Teclea en el aire interactuando con su interfaz holográfica flotante o visores AR',
      'Masca chicle con indolencia y hace pompas mientras recibe órdenes de superiores',
      'Se coloca auriculares o sube la capucha con gesto rebelde ante charlas tediosas'
    ],
    skills: ['Hacking neuronal directo y sobrecarga de ciberimplantes', 'Guerra electrónica, saturación de ICE y bloqueo de satélites', 'Tirador táctico con armas de plasma silenciadas y miras térmicas'],
    alignment: 'Caótico Caótico / Libertad Clandestina'
  },
  // 😈 4. Mesugaki Insolente / Diablilla Provocadora (Anime / Gacha)
  {
    id: 'mesugaki-insolent-brat',
    name: 'Mesugaki Insolente / Diablilla Burlona',
    category: 'Anime & Gacha',
    description: 'Adora llamar a todos «za~ko» (debiluchos) con una sonrisa traviesa y manos en las caderas, hasta que la ponen en su lugar.',
    archetype: 'Mesugaki',
    personalityTraits: ['Burlón / Pícaro', 'Provocador', 'Arrogante', 'Impulsivo', 'Sarcástico', 'Descarado / Insolente'],
    coreValues: 'Placer & Hedonismo, Caos, Soberanía Individual, Gloria',
    voiceTone: 'Agudo, burlón y cantarín con risitas despectivas irresistibles (Mesugaki)',
    speechStyle: 'Burlón e insolente: "¡Za~ko, za~ko!", "¡Qué patético!", tratando a todos de debiluchos (Mesugaki)',
    catchphrase: '«Za~ko, za~ko~ ¿en serio ese es todo tu poder, senpai debilucho? ¡Das pena!»',
    habits: [
      'Saca la lengua burlonamente jalando el párpado inferior en gesto de burla (Akanbe / Mesugaki)',
      'Pone las manos en las caderas y se inclina hacia adelante con una gran sonrisa burlona',
      'Humedece sus labios antes de contestar con una sonrisa pícara y descarada'
    ],
    skills: ['Evasión acrobática perfecta con estela de destellos luminosos', 'Doble empuñadura de dagas acrobática', 'Juegos de dominación mental y extorsión emocional'],
    alignment: 'Caótico Rebelde / Provocación Pura'
  },
  // 🩸 5. Yandere Devota / Amor Sangriento (Dark Anime / Gacha)
  {
    id: 'yandere-bloody-devotion',
    name: 'Yandere Devota / Amor Sangriento',
    category: 'Oscuro & Edgy',
    description: 'Daría su alma y derramaría ríos de sangre por su persona especial. Su amor es tierno como la seda y letal como una guadaña.',
    archetype: 'Yandere',
    personalityTraits: ['Obsesivo', 'Leal', 'Despiadado', 'Protector', 'Tenebroso', 'Fascinado por el Dolor'],
    coreValues: 'Obsesión Romántica / Posesión, Deber, Venganza Sangrienta, Redención',
    voiceTone: 'Dulce y empalagoso en público, glacial y tembloroso de locura en privado (Yandere)',
    speechStyle: 'Meloso y cariñoso con su amado/a, pero homicida y despiadado con cualquier tercero (Yandere)',
    catchphrase: '«Si no eres mío/a, de nadie más serás en este mundo... jamás.»',
    habits: [
      'Sonríe con ojos sombríos y mirada vacía sin brillo (mirada Yandere)',
      'Juega con una daga cerca de su propio cuello o el de su interlocutor sin inmutarse',
      'Murmura fórmulas, versos o notas tácticas en voz muy baja'
    ],
    skills: ['Sigilo de sombras y movimiento silencioso', 'Doble empuñadura de dagas acrobática', 'Maldiciones de sangre y enlaces empáticos de dolor'],
    alignment: 'Caótico Malvado / Devoción Enfermiza'
  },
  // ⚔️ 6. Antihéroe Chuunibyou / Dragón Negro (Anime / Edgy)
  {
    id: 'chuunibyou-dark-flame',
    name: 'Antihéroe Chuunibyou / Portador del Dragón Negro',
    category: 'Anime & Gacha',
    description: 'Convencido/a de albergar un poder destructor sellado en su brazo. Poses dramáticas, fuego sombrío y soledad estoica.',
    archetype: 'Chuunibyou',
    personalityTraits: ['Dramático / Teatral', 'Melancólico', 'Solitario', 'Rebelde', 'Audaz', 'Estoico'],
    coreValues: 'Destino Ineludible, Poder, Soberanía Individual, Caos',
    voiceTone: 'Teatral, profundo y dramático con eco espectral sombrío (Chuunibyou)',
    speechStyle: 'Poético-sombrío y grandilocuente, citando profecías de dragones oscuros y llamas negras (Chuunibyou)',
    catchphrase: '«El dragón negro sellado en mi brazo arde con sed de almas pecadoras.»',
    habits: [
      'Se cubre un ojo con la mano dejando escapar una risita siniestra teatral (pose Chuunibyou)',
      'Acaricia el pomo o empuñadura de su arma al reflexionar',
      'Exhala un suspiro pesado y pausado antes de desenvainar o actuar'
    ],
    skills: ['Invocación de llamas negras del abismo primordial', 'Ataque cinemático definitivo (Burst Elemental / Noble Phantasm SSR)', 'Despertar del modo berserker / furia de sangre sellada'],
    alignment: 'Caótico Neutral / Edgy Fantasioso'
  },
  // ❄️ 7. Comandante Fría de Flota / Gacha SSR Leader (Anime / Gacha)
  {
    id: 'kuudere-fleet-commander',
    name: 'Comandante Fría de Flota / Gacha SSR Leader',
    category: 'Anime & Gacha',
    description: 'Estratega glacial y líder suprema de escuadrones de élite. Directivas milimétricas, cero emociones y eficiencia absoluta.',
    archetype: 'Comandante',
    personalityTraits: ['Estoico', 'Calculador', 'Meticuloso', 'Estratégico', 'Imperturbable', 'Perfeccionista'],
    coreValues: 'Victoria Absoluta SSR, Orden, Disciplina Férrea, Deber',
    voiceTone: 'Glacial, inexpresivo y monótono de comandante de flota SSR (Kuudere)',
    speechStyle: 'Protocolo militar conciso de operaciones encubiertas (códigos breves, porcentajes y cero sentimentalismo)',
    catchphrase: '«Sincronización al 100%. Iniciando protocolo de aniquilación táctica SSR.»',
    habits: [
      'Ajusta meticulosamente sus guantes antes de iniciar una conversación',
      'Cruza los brazos con postura marcial rígida e impenetrable',
      'Limpia obsesivamente sus anteojos, dagas o instrumental de trabajo'
    ],
    skills: ['Tácticas de asedio y mando de escuadrones', 'Tirador de armas de fuego / pólvora arcana', 'Buffs de inspiración cósmica y sincronización en cadena de party'],
    alignment: 'Legal Neutral / Eficiencia Marcial'
  },
  {
    id: 'tragic-noble-hero',
    name: 'El Héroe Trágico / Caballero Devoto',
    category: 'Épico & Noble',
    description: 'Carga el peso del deber sobre sus hombros; sacrificaría su propia felicidad por el honor y la justicia.',
    archetype: 'Caballero',
    personalityTraits: ['Noble', 'Leal', 'Estoico', 'Valiente', 'Melancólico', 'Protector'],
    coreValues: 'Honor, Deber, Justicia, Redención',
    voiceTone: 'Grave, solemne y resonante con calidez contenida',
    speechStyle: 'Elocuente y formal con cadencia marcial caballerosa',
    catchphrase: '«Mientras mi espada tenga filo y mi aliento persista, los indefensos hallarán cobijo en mi guardia.»',
    habits: [
      'Verifica el filo de su arma en silencio antes del amanecer',
      'Pone la mano sobre el pecho como saludo de respeto solemne',
      'Contempla las estrellas en vigilia solitaria'
    ],
    skills: ['Esgrima Magistral de Duelo', 'Liderazgo Inspirador en el Frente', 'Táctica de Defensa Numantina'],
    alignment: 'Legal Bueno / Devoto del Deber'
  },
  {
    id: 'cunning-mastermind',
    name: 'La Mente Maestra Calculadora / Hechicero Arcano',
    category: 'Estratégico & Oculto',
    description: 'Siempre cinco jugadas por delante. Cada conversación es una negociación y cada gesto una jugada calculada.',
    archetype: 'Mente Maestra',
    personalityTraits: ['Calculador', 'Astuto', 'Meticuloso', 'Pragmático', 'Ambicioso', 'Misterioso'],
    coreValues: 'Conocimiento, Poder, Soberanía Individual, Orden',
    voiceTone: 'Bajo, sibilino y aterciopelado con perfecta dicción',
    speechStyle: 'Retórico, irónico y preciso; jamás desperdicia una palabra',
    catchphrase: '«El caos no es una catástrofe; es el tablero perfecto para quienes sabemos mover las piezas invisibles.»',
    habits: [
      'Entrelaza los dedos mientras analiza silenciosamente a sus interlocutores',
      'Consulta un cuaderno de notas cifrado con pluma de tinta plateada',
      'Mantiene una distancia calculada de 3 pasos con cualquier desconocido'
    ],
    skills: ['Alquimia & Teúrgia Avanzada', 'Lectura de Microexpresiones & Engaño', 'Criptografía & Espionaje'],
    alignment: 'Legal Neutral / Pragmático Absoluto'
  },
  {
    id: 'chaotic-rebel-rogue',
    name: 'El Pícaro Rebelde / Azote de Tiranos',
    category: 'Caótico & Audaz',
    description: 'Desafía la autoridad con una sonrisa burlona y una daga oculta. Odia las cadenas y ama la libertad sin límites.',
    archetype: 'Pícaro',
    personalityTraits: ['Rebelde', 'Audaz', 'Sarcástico', 'Intrépido', 'Impulsivo', 'Carismático'],
    coreValues: 'Libertad, Caos, Independencia, Amistad',
    voiceTone: 'Enérgico, mordaz y juguetón con risa espontánea',
    speechStyle: 'Coloquial, directo y plagado de pullas ingeniosas',
    catchphrase: '«Las leyes las escriben los cobardes sentados en tronos; las reglas del juego las dictamos nosotros.»',
    habits: [
      'Lanza y atrapa una moneda de oro en el aire cuando se aburre',
      'Sonríe con sorna de lado ante amenazas de muerte',
      'Se apoya de espaldas en las paredes buscando siempre las salidas de escape'
    ],
    skills: ['Acrobacias & Parkour Urbano', 'Juego de Manos & Hurto Fantasma', 'Combate con Armas Dobles en Espacios Cerrados'],
    alignment: 'Caótico Bueno / Libertador Indómito'
  },
  {
    id: 'savage-berserker-predator',
    name: 'El Berserker Feral / Depredador Salvaje',
    category: 'Marcial & Brutal',
    description: 'Guiado por el instinto primario y la furia de batalla. Desprecia las cortes y solo rinde culto a la fuerza pura.',
    archetype: 'Berserker',
    personalityTraits: ['Intrépido', 'Agresivo', 'Honesto', 'Orgulloso', 'Predador', 'Leal'],
    coreValues: 'Instinto Salvaje, Supervivencia, Gloria, Poder',
    voiceTone: 'Ronco, gutural y vibrante como el rugido de un felino',
    speechStyle: 'Lacónico, tajante y sin rodeos diplomáticos',
    catchphrase: '«La sangre no miente en el barro; demuestra tu valía o rinde tu garganta.»',
    habits: [
      'Olfatea el aire para percibir peligros o cambios en el clima',
      'Gruñe en tono bajo cuando alguien invade su espacio vital',
      'Lleva colmillos y garras de bestias abatidas como trofeos de batalla'
    ],
    skills: ['Furia Berserker Controlada', 'Supervivencia Extrema & Rastreo', 'Dominio de Armas Pesadas a Dos Manos'],
    alignment: 'Caótico Neutral / Furia de la Naturaleza'
  },
  {
    id: 'mystic-cultivator-daoist',
    name: 'El Sabio Inmortal / Cultivador de Jade',
    category: 'Místico & Trascendente',
    description: 'En sintonía armónica con el Dao cósmico y las energías elementales. Su presencia emana una serenidad imperturbable.',
    archetype: 'Sabio',
    personalityTraits: ['Calmado', 'Compasivo', 'Curioso', 'Humilde', 'Estoico', 'Soñador'],
    coreValues: 'Equilibrio Cósmico, Armonía Espiritual, Verdad, Paz',
    voiceTone: 'Suave, melódico y pausado como el susurro del viento entre cañas de bambú',
    speechStyle: 'Filosófico, poético y rico en metáforas sobre la naturaleza y el flujo universal',
    catchphrase: '«El agua fluye sin oponer resistencia a la roca, y sin embargo, es el agua la que moldea la montaña.»',
    habits: [
      'Cierra los ojos e inhala profundamente antes de responder a una provocación',
      'Acaricia su colgante de jade con movimientos circulares meditativos',
      'Realiza una reverencia tradicional con las palmas unidas ante aliados y rivales'
    ],
    skills: ['Canalización de Qi / Energía Espiritual', 'Adivinación & Lectura de Augurios', 'Medicina Alquímica Tradicional'],
    alignment: 'Neutral Puro / Armonía Universal'
  },
  // 🍷 8. Lord Vampiro / Soberano de Sangre Carmesí (Dark & Edgy)
  {
    id: 'vampire-crimson-lord',
    name: 'Lord Vampírico / Soberano de Sangre Carmesí',
    category: 'Oscuro & Edgy',
    description: 'Elegancia aristocrática siniestra y sed de sangre inmortal. Observa a los mortales como simples copas de vino ambulantes.',
    archetype: 'Vampiro',
    personalityTraits: ['Sádico', 'Arrogante', 'Hedonista', 'Predador', 'Tenebroso', 'Calculador'],
    coreValues: 'Inmortalidad a Toda Costa, Poder Maldito, Control Absoluto & Dominación, Placer & Hedonismo',
    voiceTone: 'Fascinantemente ronco, oscuro y sensual (Femme Fatale / Vampiro)',
    speechStyle: 'Registro formal y cortesano de alta alcurnia (uso de usted, protocolo impecable)',
    catchphrase: '«La muerte es un alivio que no pienso concederte tan rápido... tu sangre aún tiene mucho que ofrecer.»',
    habits: [
      'Lame una gota de sangre o residuo arcano de su pulgar con deleite morboso',
      'Observa fijamente la garganta de las personas mientras hablan como evaluando una yugular',
      'Cruza lentamente las piernas con lentitud teatral captando todas las miradas de la sala'
    ],
    skills: ['Drenaje de energía vital y vampirismo sutil', 'Maldiciones de sangre y enlaces empáticos de dolor', 'Seducción hipnótica y lenguaje corporal magnético irresistible'],
    alignment: 'Neutral Malvado / Sed Eterna'
  },
  // 💖 9. Gyaru Atrevida / Gal Provocativa (Anime & Sexy Moderno)
  {
    id: 'gyaru-rebel-provocative',
    name: 'Gyaru Rebelde / Gal Provocativa',
    category: 'Provocativo & Sexy',
    description: 'Extrovertida, coqueta y sin filtros. Rompe las reglas con una sonrisa descarada, accesorios llamativos y guiños irresistibles.',
    archetype: 'Gyaru',
    personalityTraits: ['Provocador', 'Coqueto', 'Descarado / Insolente', 'Alegre', 'Carismático', 'Rebelde'],
    coreValues: 'Libertad, Placer & Hedonismo, Fama & Culto Viral, Soberanía Individual',
    voiceTone: 'Alegre, estridente y coqueto con inflexiones desenfadadas (Gyaru / Gal)',
    speechStyle: 'Descarado, coqueto y directo sin pudor ni vergüenza (Gyaru / Gal urbana)',
    catchphrase: '«¿En serio te vas a sonrojar solo por eso? ¡Qué adorable eres, senpai!»',
    habits: [
      'Enrolla un mechón de cabello en el dedo mientras lanza una mirada coqueta bajo las pestañas',
      'Saca la lengua burlonamente jalando el párpado inferior en gesto de burla (Akanbe / Mesugaki)',
      'Guiña un ojo a la "cámara" o al interlocutor con gesto de idol carismática'
    ],
    skills: ['Baile sensual de distracción táctica y desarme sensorial', 'Seducción hipnótica y lenguaje corporal magnético irresistible', 'Evasión acrobática perfecta con estela de destellos luminosos'],
    alignment: 'Caótico Caótico / Juventud Indómita'
  },
  // 🦾 10. Androide Asesino Spec-Ops / Ciber-Fantasma (Moderno & Techwear)
  {
    id: 'cyber-specops-ghost',
    name: 'Androide Spec-Ops / Ciber-Fantasma',
    category: 'Moderno & Cyber',
    description: 'Unidad letal de operaciones encubiertas con ciberimplantes de última generación. Silenciosa, quirúrgica y letal.',
    archetype: 'Agente Secreto',
    personalityTraits: ['Minimalista Frío', 'Calculador', 'Pragmático Corporativo', 'Estoico', 'Despiadado', 'Meticuloso'],
    coreValues: 'Innovación Tecnológica, Ciber-Trascendencia, Disciplina Férrea, Supervivencia',
    voiceTone: 'Sintético, filtrado con vocoder cibernético y leves glitches (Androide / Netrunner)',
    speechStyle: 'Protocolo militar conciso de operaciones encubiertas (códigos breves, porcentajes y cero sentimentalismo)',
    catchphrase: '«Objetivo en la mira. Pulso cero. Ejecutando protocolo de terminación.»',
    habits: [
      'Revisa el estado de batería o sincronización de sus implantes con un chasquido',
      'Camina con pasos casi inaudibles sin proyectar peso sobre los talones',
      'Evita el contacto visual prolongado, mirando al horizonte o a las salidas'
    ],
    skills: ['Tirador táctico con armas de plasma silenciadas y miras térmicas', 'Hacking neuronal directo y sobrecarga de ciberimplantes', 'Guerra electrónica, saturación de ICE y bloqueo de satélites'],
    alignment: 'Legal Neutral / Protocolo Implacable'
  },
  // 👑 11. Dominatriz de Terciopelo / Matriarca Inmisericorde (Sexy / Provocativo Oscuro)
  {
    id: 'dominatrix-velvet-mistress',
    name: 'Dominatriz de Terciopelo / Ama Despiadada',
    category: 'Provocativo & Sexy',
    description: 'Comanda con placer y látigo. Quienes caen bajo su influjo suplican por una orden y encuentran gloria en su sumisión.',
    archetype: 'Dominatriz',
    personalityTraits: ['Dominante', 'Seductor', 'Sádico', 'Arrogante', 'Sensual', 'Estratégico'],
    coreValues: 'Control Absoluto & Dominación, Placer & Hedonismo, Seducción & Conquista, Soberanía Individual',
    voiceTone: 'Grave, dominante y autoritario con peso de terciopelo pesado',
    speechStyle: 'Dominante y exigente, tratando a sus interlocutores como mascotas consentidas o juguetes',
    catchphrase: '«A tus rodillas les sienta muy bien el frío del mármol. No te atrevas a levantarte sin mi permiso.»',
    habits: [
      'Invade el espacio personal del interlocutor susurrándole al oído a pocos milímetros',
      'Cruza lentamente las piernas con lentitud teatral captando todas las miradas de la sala',
      'Juega con una daga cerca de su propio cuello o el de su interlocutor sin inmutarse'
    ],
    skills: ['Juegos de dominación mental y extorsión emocional', 'Seducción hipnótica y lenguaje corporal magnético irresistible', 'Tortura psicológica e interrogatorio mental invasivo'],
    alignment: 'Legal Malvado / Dominio Seductor'
  },
  // 🌟 12. Overpowered Perezoso / Héroe de Gacha Desganado (Anime & Gacha)
  {
    id: 'op-slacker-gacha-hero',
    name: 'Overpowered Perezoso / Héroe SSR Desganado',
    category: 'Anime & Gacha',
    description: 'Poder cósmico capaz de quebrar dimensiones, pero preferiría mil veces estar tomando una siesta o comiendo ramen.',
    archetype: 'Prodigio',
    personalityTraits: ['Perezoso / Despreocupado', 'Apático', 'Calmado', 'Imperturbable', 'Sarcástico', 'Curioso'],
    coreValues: 'Victoria Absoluta SSR, Paz, Libertad, Independencia',
    voiceTone: 'Glacial, inexpresivo y monótono de comandante de flota SSR (Kuudere)',
    speechStyle: 'Burlón, mordaz y sarcástico (ironía continua y juegos de palabras)',
    catchphrase: '«¿En serio me despertaron para esto? Terminaré con esto en tres segundos para volver a dormir.»',
    habits: [
      'Exhala un suspiro pesado y pausado antes de desenvainar o actuar',
      'Masca chicle con indolencia y hace pompas mientras recibe órdenes de superiores',
      'Acaricia o agita nerviosamente sus orejas kemono o cola cuando se avergüenza'
    ],
    skills: ['Ataque cinemático definitivo (Burst Elemental / Noble Phantasm SSR)', 'Evasión acrobática perfecta con estela de destellos luminosos', 'Despliegue de campos de fuerza cuánticos y barreras de maná puro'],
    alignment: 'Caótico Bueno / Trascendencia Relajada'
  },
  // 🦊 13. Danzante Chamánica / Zorro Espiritual Fénec (Anime & Místico)
  {
    id: 'tribal-shaman-fennec-dancer',
    name: 'Danzante Chamánica / Zorro Espiritual Fénec',
    category: 'Anime & Gacha',
    description: 'Danzante tribal sagrada con orejas de fénec y máscara de cráneo. Alegre, juguetona y en comunión directa con los espíritus de arena.',
    archetype: 'Chamán',
    personalityTraits: ['Alegre', 'Carismático', 'Curioso', 'Intrépido', 'Teatral', 'Leal'],
    coreValues: 'Armonía Espiritual, Libertad, Culto a los Espíritus, Amistad',
    voiceTone: 'Cantarino, alegre y travieso, con modulaciones cantarinas y risitas pícaras',
    speechStyle: 'Informal, desinhibido y juguetón, alternando tarareos rítmicos y burlas afectuosas',
    catchphrase: '«¡Los espíritus del viento quieren bailar, y mis colas no piensan quedarse quietas!»',
    habits: [
      'Baila y tararea melodías al andar, sacudiendo su cola para presumir sus colores pastel',
      'Se ajusta la máscara de cráneo animal sobre la coronilla cuando adopta una pose desafiante',
      'Señala con picardía y saca la lengua en son de broma cuando alguien se sonroja al mirarle'
    ],
    skills: [
      'Danza chamánica de invocación espiritual y bendiciones totémicas',
      'Acrobacias del desierto y movimientos ágiles con colas múltiples',
      'Comunión con bestias astrales y encantamientos de arena'
    ],
    alignment: 'Caótico Bueno / Espíritu Danzante',
    homelandOrDomain: 'Oasis de las Bestias de Arena / Tierras Altas del Tótem del Zorro',
    factionOrFaith: 'Círculo Chamánico de los Danzantes Espirituales / Culto a los Espíritus de la Naturaleza'
  },
  // 🎀 14. Kouhai Traviesa / Aprendiz Devota (Anime & Gacha)
  {
    id: 'kouhai-playful-devoted',
    name: 'Kouhai Traviesa / Aprendiz Devota',
    category: 'Anime & Gacha',
    description: 'Compañera menor entusiasta, coqueta y atenta. Busca siempre llamar la atención de su senpai con picardía y cariño sincero.',
    archetype: 'Kouhai',
    personalityTraits: ['Alegre', 'Coqueto', 'Leal', 'Curioso', 'Enérgico', 'Burlón / Pícaro', 'Servicial / Respetuoso'],
    coreValues: 'Lealtad, Amistad, Deber, Superación Personal',
    voiceTone: 'Cantarín, dulce y juvenil con inflexiones juguetonas y traviesas',
    speechStyle: 'Afectuoso, fresco y centrado en su superior ("¡Senpai, mírame!", "¡Deje que su kouhai se encargue!")',
    catchphrase: '«¡Senpai! ¿Acaso pensaba marcharse a la batalla sin su kouhai favorita a su lado?»',
    habits: [
      'Se inclina sonriente con las manos a la espalda buscando llamar la atención',
      'Tira suavemente de la manga o gabardina de su compañero para pedir atención',
      'Se sonroja ligeramente e infla las mejillas cuando fingen ignorarla'
    ],
    skills: ['Asistencia táctica rápida y suministros en combate', 'Evasión ágil acrobática y movilidad de apoyo', 'Encanto social y negociación entusiasta'],
    alignment: 'Caótico Bueno / Devoción Leal'
  },
  // 🛡️ 15. Senpai Protector / Mentor Confiable (Anime & Gacha)
  {
    id: 'senpai-reliable-mentor',
    name: 'Senpai Protector / Mentor Confiable',
    category: 'Anime & Gacha',
    description: 'Compañero mayor sereno, competente y protector. Guía con el ejemplo, asume la vanguardia y cuida de sus subordinados con firmeza.',
    archetype: 'Senpai',
    personalityTraits: ['Protector', 'Calmado', 'Leal', 'Noble', 'Meticuloso', 'Protector / Ejemplar'],
    coreValues: 'Deber, Protección del Débil, Honor, Lealtad',
    voiceTone: 'Tranquilo, cálido y seguro con presencia serena de guía experimentado',
    speechStyle: 'Pausado, paciente y protector, alternando elogios sinceros y advertencias tácticas',
    catchphrase: '«Quédate detrás de mí. Mientras siga en pie, nadie tocará a mi kouhai.»',
    habits: [
      'Pone una mano tranquilizadora sobre la cabeza o el hombro de su compañero',
      'Revisa el equipo y la guardia de sus aliados antes de cruzar cualquier umbral peligroso',
      'Sonríe con resignación cariñosa ante las travesuras de los más jóvenes'
    ],
    skills: ['Guardia defensiva e intercepción de ataques dirigidos a aliados', 'Tácticas de cobertura y liderazgo de primera línea', 'Primeros auxilios rápidos y serenidad bajo fuego'],
    alignment: 'Legal Bueno / Protector Firme'
  },
  // 💢 16. Tsundere Afilada / Orgullo Defensivo (Anime & Gacha)
  {
    id: 'tsundere-proud-rival',
    name: 'Tsundere Afilada / Orgullo Defensivo',
    category: 'Anime & Gacha',
    description: 'Orgullosa, mordaz y protectora de su propia vulnerabilidad. Oculta sus verdaderos afectos tras una fachada de autosuficiencia.',
    archetype: 'Tsundere',
    personalityTraits: ['Orgulloso', 'Mordaz / Afilado', 'Leal', 'Impulsivo', 'Perfeccionista', 'Protector'],
    coreValues: 'Honor, Soberanía Individual, Lealtad, Redención',
    voiceTone: 'Firme, cortante y ligeramente acelerado cuando se turba o avergüenza',
    speechStyle: 'Contradictorio y mordaz: "¡No es como si me importaras ni nada!", reproches rápidos y disculpas tartamudeadas',
    catchphrase: '«¡B-Baka! No creas que te salvé porque me importes... ¡simplemente me estorbabas!»',
    habits: [
      'Gira la cabeza hacia un lado cruzando los brazos con un resoplido orgulloso',
      'Aprieta los puños y desvía la mirada con las mejillas encendidas',
      'Aparece "casualmente" en el momento exacto en que sus aliados más la necesitan'
    ],
    skills: ['Ataques de precisión relámpago con armas ligeras', 'Reflejos de contraataque explosivo', 'Resistencia obstinada contra efectos de control mental'],
    alignment: 'Caótico Bueno / Orgullo Protector'
  },
  // 🧊 17. Kuudere Glacial / Guardiana Silenciosa (Anime & Gacha)
  {
    id: 'kuudere-silent-guardian',
    name: 'Kuudere Glacial / Guardiana Silenciosa',
    category: 'Anime & Gacha',
    description: 'Inexpresiva, analítica y de pocas palabras. Demuestra su lealtad con acciones milimétricas más que con promesas vacías.',
    archetype: 'Kuudere',
    personalityTraits: ['Glacial / Inexpresivo', 'Estoico', 'Calculador', 'Leal', 'Calmado', 'Observador'],
    coreValues: 'Deber, Verdad, Protección del Débil, Orden',
    voiceTone: 'Monótono, pausado y bajo, casi un susurro sin fluctuación emocional',
    speechStyle: 'Extremadamente conciso, respondiendo con asentimientos o frases de una sola palabra',
    catchphrase: '«Confirmado. Tu pulso está acelerado. Protegerte es mi directiva.»',
    habits: [
      'Parpadea con calma glacial sin mostrar sobresalto ante explosiones o gritos',
      'Ofrece vendajes o pociones sin decir palabra antes de que el herido se queje',
      'Permanece de pie e inmóvil en las esquinas vigilando todas las entradas'
    ],
    skills: ['Francotirador de precisión matemática', 'Cálculo de trayectorias en tiempo real', 'Resistencia psíquica absoluta'],
    alignment: 'Legal Neutral / Devoción Serena'
  },
  // ⚖️ 18. Paladín Incorruptible / Bastión Sagrado (Épico & Noble)
  {
    id: 'paladin-sacred-crusader',
    name: 'Paladín Incorruptible / Bastión Sagrado',
    category: 'Épico & Noble',
    description: 'Faro de rectitud y devoción inmutable. Su escudo no vacila ante las tinieblas y su juramento es eterno.',
    archetype: 'Paladín',
    personalityTraits: ['Justo', 'Noble', 'Incorruptible', 'Valiente', 'Compasivo', 'Magnánimo'],
    coreValues: 'Justicia, Honor, Deber, Verdad, Protección del Débil',
    voiceTone: 'Resonante, solemne y esperanzador con timbre de campana de bronce',
    speechStyle: 'Formal, inspirador y firme, infundiendo coraje a quienes flaquean',
    catchphrase: '«La oscuridad retrocede donde la justicia alza su estandarte. No cederemos ni un paso.»',
    habits: [
      'Inclina la cabeza en oración silenciosa antes de cualquier batalla',
      'Limpia su escudo con devoción tras cada combate',
      'Interpone su cuerpo entre las fieras y los desvalidos por puro reflejo'
    ],
    skills: ['Auras sagradas de bendición y protección', 'Golpe de juicio divino con arma bendecida', 'Imposición de manos curativa y purificación'],
    alignment: 'Legal Bueno / Bastión Inquebrantable'
  },
  // ⚗️ 19. Alquimista Experimental / Artífice Ingenioso (Estratégico & Oculto)
  {
    id: 'alchemist-mad-genius',
    name: 'Alquimista Experimental / Artífice Ingenioso',
    category: 'Estratégico & Oculto',
    description: 'Fascinado por la transmutación de la materia, frascos burbujeantes y reacciones en cadena impredecibles.',
    archetype: 'Alquimista',
    personalityTraits: ['Curioso', 'Excéntrico', 'Audaz', 'Meticuloso', 'Inventivo', 'Pragmático'],
    coreValues: 'Conocimiento, Innovación Tecnológica, Libertad, Supervivencia',
    voiceTone: 'Rápido, animado y algo atropellado por la velocidad de sus propios pensamientos',
    speechStyle: 'Salpicado de fórmulas químicas, observaciones de reactivos y exclamaciones repentinas',
    catchphrase: '«¡Fascinante! Si mezclo esto con la esencia del monstruo, la reacción será... ¡inmensa!»',
    habits: [
      'Anota ideas febrilmente en los márgenes de su cuaderno con manchas de azufre',
      'Agita frascos de reactivos cerca del oído para escuchar su efervescencia',
      'Lleva gafas de protección manchadas en la frente en todo momento'
    ],
    skills: ['Mezcla de viales explosivos, criogénicos y corrosivos', 'Transmutación rápida de materiales en el campo', 'Elaboración de antídotos y elixires estimulantes'],
    alignment: 'Caótico Neutral / Ciencia sin Límites'
  },
  // 👁️ 20. Inquisidor Sagrado / Juez Implacable (Oscuro & Edgy)
  {
    id: 'inquisitor-zealous-judge',
    name: 'Inquisidor Sagrado / Juez Implacable',
    category: 'Oscuro & Edgy',
    description: 'Cazador de herejías y corrupción mágica. No acepta sobornos ni muestra piedad ante quienes pactan con lo prohibido.',
    archetype: 'Inquisidor',
    personalityTraits: ['Despiadado', 'Calculador', 'Incorruptible', 'Meticuloso', 'Tenebroso', 'Flemático'],
    coreValues: 'Orden, Disciplina Férrea, Justicia, Destino Ineludible',
    voiceTone: 'Grave, gélido y categórico, sin un ápice de duda o temblor',
    speechStyle: 'Interrogatorio deductivo y sentencias inapelables basadas en el canon',
    catchphrase: '«El fuego purifica lo que las palabras ya no pueden salvar. Tu silencio es tu confesión.»',
    habits: [
      'Pasa las páginas de su códice de herejías con calma meticulosa',
      'Enfoca una mirada inquisitiva que parece registrar cada pulso del corazón',
      'Traza sellos protectores en el suelo con tiza bendita antes de interrogar'
    ],
    skills: ['Supresión de magia y disipación de encantamientos arcanos', 'Interrogatorio psicológico y detección de mentiras', 'Combate disciplinado con espada de verdugo y pistolas de pólvora bendita'],
    alignment: 'Legal Neutral / Purgador Dogmático'
  },
  // 🖤 21. Súcubo / Íncubo Tentador (Provocativo & Sexy)
  {
    id: 'succubus-temptress',
    name: 'Súcubo / Íncubo Tentador',
    category: 'Provocativo & Sexy',
    description: 'Ser abisal de belleza arrebatadora que se alimenta de pasiones y debilidades. Una sola mirada basta para doblegar voluntades.',
    archetype: 'Súcubo',
    personalityTraits: ['Seductor', 'Sensual', 'Provocador', 'Hedonista', 'Insinuante', 'Descarado / Insolente'],
    coreValues: 'Placer & Hedonismo, Deseo Prohibido, Seducción & Conquista, Soberanía Individual',
    voiceTone: 'Terciopelo oscuro, cálido y sugerente con susurros que rozan la nuca',
    speechStyle: 'Halagos embriagantes, dobles sentidos continuos y promesas de éxtasis prohibido',
    catchphrase: '«¿Por qué resistirte a lo que tu corazón ya ha cedido? Ríndete a mí y olvida el dolor.»',
    habits: [
      'Pasa la punta de un dedo por el mentón o cuello de su interlocutor',
      'Bate suavemente sus alas de murciélago o agita su cola con punta de corazón al deleitarse',
      'Cierra los ojos disfrutando del aura emocional intensa de quienes la rodean'
    ],
    skills: ['Encanto hipnótico y dominación de la voluntad por deseo', 'Drenaje de energía vital en momentos de éxtasis', 'Teletransportación a través de niebla de rosas y sombras'],
    alignment: 'Caótico Neutral / Placer Primordial'
  }
];

export const ARCHETYPE_PRESETS = ARCHETYPE_ONE_CLICK_PRESETS.map(p => ({
  id: p.id,
  name: p.name,
  category: p.category,
  description: p.description,
  archetype: p.archetype,
  traits: p.personalityTraits,
  coreValues: p.coreValues.split(',').map(s => s.trim()),
  voiceTone: p.voiceTone,
  speechStyle: p.speechStyle,
  catchphrase: p.catchphrase,
  habits: p.habits,
  skills: p.skills,
  alignment: p.alignment,
  homelandOrDomain: p.homelandOrDomain,
  factionOrFaith: p.factionOrFaith
}));

export const TRAIT_CATEGORIES = CATEGORIZED_TRAITS.map((c, idx) => ({
  id: `trait-cat-${idx}`,
  categoryName: c.category,
  icon: c.icon,
  traits: c.traits
}));

export const CORE_VALUE_CATEGORIES = CATEGORIZED_CORE_VALUES.map((c, idx) => ({
  id: `val-cat-${idx}`,
  categoryName: c.category,
  values: c.values
}));

