import { WorldPlace, WorldFaction, WorldLaw, WorldBuildingConfig, SimpleAmbientNPC } from '../types';

export const DEFAULT_FACTIONS: WorldFaction[] = [
  {
    id: 'FAC-01',
    name: 'Guardia del Velo Dorado',
    ideology: 'Protección férrea de las tradiciones del desierto, devoción al honor y custodia de los santuarios.',
    emblemIcon: 'Shield',
    color: '#D4AF37',
    reputationWithPlayer: 'Amistosa',
    description: 'Guerreros y místicas con armaduras de orfebrería y ropajes dorados que velan por la paz de las rutas de caravanas.',
    activeEnemies: ['FAC-03']
  },
  {
    id: 'FAC-02',
    name: 'Consorcio de las Especias Astrales',
    ideology: 'Comercio libre, diplomacia pragmática, búsqueda de reliquias arcanas y placer mundano.',
    emblemIcon: 'Gem',
    color: '#38BDF8',
    reputationWithPlayer: 'Neutral',
    description: 'Comerciantes acaudalados que dominan bazares, casas de té y puertos fluviales del imperio.',
    activeEnemies: []
  },
  {
    id: 'FAC-03',
    name: 'Culto de la Luna Negra',
    ideology: 'Ruptura de los votos sagrados, magia sombría prohibida y caída de los templos de orfebrería.',
    emblemIcon: 'Flame',
    color: '#E11D48',
    reputationWithPlayer: 'Hostil',
    description: 'Fanáticos y asesinos que acechan bajo las dunas durante las noches sin luna.',
    activeEnemies: ['FAC-01', 'FAC-02']
  }
];

export const DEFAULT_WORLD_LAWS: WorldLaw[] = [
  {
    id: 'LAW-01',
    title: 'Tregua Sagrada del Oasis',
    description: 'Cualquier acto de agresión con armas en las aguas sagradas acarrea el destierro o combate a muerte de los guardianes.',
    impactTag: 'combat',
    modifierDescription: 'La violencia espontánea reduce la confianza de los Agentes en -30 y activa a los centinelas.',
    isActive: true
  },
  {
    id: 'LAW-02',
    title: 'Cortesía de los Velos y Saludos',
    description: 'Iniciar una conversación con reverencia y cortesía despierta la simpatía de las danzarinas y nobles.',
    impactTag: 'social',
    modifierDescription: 'Los elogios bien intencionados otorgan +25% de Afecto adicional a los Agentes Lite.',
    isActive: true
  },
  {
    id: 'LAW-03',
    title: 'Pacto de Reciprocidad Íntima',
    description: 'El tacto o caricias consensuadas requieren primero ganarse la confianza (>40) antes de ser toleradas sin resistencia.',
    impactTag: 'intimacy',
    modifierDescription: 'Los toques a zonas erógenas con baja confianza disparan una respuesta de orgullo o repliegue defensivo.',
    isActive: true
  },
  {
    id: 'LAW-04',
    title: 'Decreto de la Esencia Mística',
    description: 'La energía astral fluye libremente, permitiendo que las artes curativas y hechizos de defensa no consuman fatiga en santuarios.',
    impactTag: 'magic',
    modifierDescription: 'En zonas de Templo u Oasis, el costo de SP en combate se reduce a la mitad.',
    isActive: true
  }
];

export const DEFAULT_PLACES: WorldPlace[] = [
  {
    id: 'LOC-01',
    name: 'Oasis Sagrado de Al-Zahra',
    version: 'v1.1',
    linkedWorldId: 'WORLD-ELYSIUM-01',
    // 1. Identidad, Ubicación y Atmósfera
    geographicContext: 'Asentamiento aislado',
    rhythmOrVibes: ['Tranquilo', 'Vigilado'],
    region: 'Desierto de las Cenizas Doradas',
    environmentType: 'Oasis',
    dangerLevel: 'Seguro',
    dominantFactionId: 'FAC-01',
    atmosphere: 'Aguas cristalinas reflejando las estrellas, brisa cálida perfumada con incienso de loto y palmeras susurrantes.',
    description: 'Un refugio milenario protegido por la Guardia del Velo donde caravanas, danzarinas y místicos conviven en armonía.',

    // 2. Arquitectura y Materialidad
    constructionStyle: 'Tradicional',
    materials: ['Piedra', 'Madera', 'Vidrio', 'Materiales fantásticos'],
    condition: 'Conservado',

    // 3. Ecosistema Urbano y Servicios
    criticalPointsOfInterest: [
      {
        id: 'POI-01',
        name: 'Manantial del Loto Dorado',
        type: 'Fuente sagrada',
        function: 'Purificación espiritual y sanación de viajeros',
        owner: 'Alta Sacerdotisa Zehra',
        location: 'Centro neurálgico del oasis',
        description: 'Estanque de aguas termales cristalinas donde brotan lotos de pétalos dorados luminiscentes.',
        importance: 'Crítica'
      },
      {
        id: 'POI-02',
        name: 'Pabellón de Reposo de Terciopelo',
        type: 'Albergue y casa de té',
        function: 'Hospedaje de caravanas y descanso diplomático',
        owner: 'Karim el Hospitalario',
        location: 'Ribera occidental',
        description: 'Estructura abierta techada con seda carmesí, alfombras de lana gruesa y narguiles aromáticos.',
        importance: 'Media'
      },
      {
        id: 'POI-03',
        name: 'Altar del Espejo Astral',
        type: 'Santuario',
        function: 'Adivinación, meditación y comunión cósmica',
        owner: 'Guardia del Velo Dorado',
        location: 'Terraza alta de arenisca',
        description: 'Monolito de cuarzo tallado con runas que resuenan ante la presencia de almas afines.',
        importance: 'Alta'
      },
      {
        id: 'POI-04',
        name: 'Boticaria de Bálsamos del Velo',
        type: 'Comercio',
        function: 'Venta de ungüentos curativos y elixires afrodisíacos',
        owner: 'Marta la Alquimista',
        location: 'Entrada este junto a las palmeras',
        description: 'Estanterías de cedro cargadas de redomas de vidrio tintado con esencias del desierto.',
        importance: 'Media'
      }
    ],
    convergenceZones: [
      {
        id: 'ZONE-01',
        name: 'Plaza de los Velos y Narguiles',
        type: 'Plaza',
        schedule: 'Atardecer y noche profunda',
        npcDensity: 'Media',
        frequentEvents: 'Danzas rituales con fuego, intercambio de historias y música de laúd.',
        securityLevel: 'Vigilancia militar',
        associatedCharacters: ['Danzarinas del Sol', 'Centinelas del Velo', 'Peregrinos']
      },
      {
        id: 'ZONE-02',
        name: 'Callejón de los Susurros de Arena',
        type: 'Callejón',
        schedule: 'Medianoche',
        npcDensity: 'Baja',
        frequentEvents: 'Citas clandestinas, pactos de gremio y comercio de reliquias.',
        securityLevel: 'Medio',
        associatedCharacters: ['Contrabandistas', 'Eruditos errantes']
      },
      {
        id: 'ZONE-03',
        name: 'Terraza de las Palmeras',
        type: 'Patio',
        schedule: 'Todo el día',
        npcDensity: 'Media',
        frequentEvents: 'Baños de sol, meditación y juego de ajedrez solar.',
        securityLevel: 'Alto',
        associatedCharacters: ['Nobles de paso', 'Sacerdotisas']
      }
    ],
    cultureAndSecurity: {
      authority: 'Milicia',
      surveillance: 'Alta',
      socialConduct: ['Hospitalidad', 'Solidaridad', 'Desconfianza']
    },

    // 4. Vivienda Específica
    hasHousing: true,
    housing: {
      buildingType: 'Residencia',
      levels: [
        {
          levelNumber: 0,
          levelName: 'NIVEL 0 — ACCESO',
          rooms: [
            {
              id: 'ROOM-01',
              name: 'Zaguán de Bienvenida',
              function: 'Recepción y descalzador ritual',
              location: 'Entrada principal',
              furniture: ['Bancas de piedra pulida', 'Aguamanil de latón'],
              objects: ['Sandalias de seda', 'Farol de aceite perfumado'],
              accesses: ['Puerta exterior del patio', 'Escalera al Nivel 1'],
              associatedCharacters: ['Guardias de portal'],
              description: 'Espacio fresco con fuentes de agua de rosas para lavar los pies del viajero.'
            }
          ]
        },
        {
          levelNumber: 1,
          levelName: 'NIVEL 1 — ÁREAS SOCIALES',
          rooms: [
            {
              id: 'ROOM-02',
              name: 'Salón de Divanes y Especias',
              function: 'Reunión social, té y diálogo',
              location: 'Planta central',
              furniture: ['Diván circular de terciopelo', 'Mesa baja de cobre repujado'],
              objects: ['Juegos de té de plata', 'Almohadones bordados'],
              accesses: ['Zaguán', 'Balcón del este', 'Escalera al Nivel 2'],
              associatedCharacters: ['Anfitriona', 'Invitados'],
              description: 'Gran estancia ventilada con celosías de madera que filtran la luz solar.'
            }
          ]
        },
        {
          levelNumber: 2,
          levelName: 'NIVEL 2 — ÁREAS PRIVADAS',
          rooms: [
            {
              id: 'ROOM-03',
              name: 'Dormitorio Principal de la Compañera',
              function: 'Descanso íntimo y reposo',
              location: 'Segundo piso · derecha',
              furniture: ['Cama con dosel de gasa transparente', 'Tocador de madera noble', 'Espejo de cuerpo entero'],
              objects: ['Frascos de perfume', 'Ropajes de repuesto', 'Cofre de joyas'],
              accesses: ['Pasillo privado', 'Baño en suite', 'Terraza privada'],
              associatedCharacters: ['Agente Lite / Protagonista'],
              description: 'Habitación íntima y acogedora con vistas panorámicas a las dunas y aroma a mirra.'
            },
            {
              id: 'ROOM-04',
              name: 'Baño de Pétalos',
              function: 'Aseo personal y baño de inmersión',
              location: 'Segundo piso · izquierda',
              furniture: ['Bañera de mosaico turquesa', 'Estante de aceites'],
              objects: ['Esponjas marinas', 'Toallas tibias de algodón'],
              accesses: ['Dormitorio Principal'],
              associatedCharacters: ['Agente'],
              description: 'Espacio cálido con agua tibia canalizada del manantial y pétalos de rosa flotantes.'
            }
          ]
        },
        {
          levelNumber: 3,
          levelName: 'NIVEL 3 — EXTERIOR',
          rooms: [
            {
              id: 'ROOM-05',
              name: 'Azotea del Observatorio Estelar',
              function: 'Contemplación nocturna y vigilia',
              location: 'Cima de la residencia',
              furniture: ['Diván bajo de cuero', 'Telescopio de latón'],
              objects: ['Cartas estelares', 'Manta de lana bordada'],
              accesses: ['Escalera de caracol'],
              associatedCharacters: ['Astrónomos'],
              description: 'Plataforma a cielo abierto bajo la cúpula de estrellas del desierto.'
            }
          ]
        }
      ],
      exteriorsAndConnectivity: ['Patios', 'Balcones', 'Escaleras', 'Terrazas', 'Pasadizos']
    },

    // 5. Elementos Únicos
    uniqueElements: [
      {
        id: 'UNIQ-01',
        name: 'Reloj de Arena Astral',
        type: 'MECANISMO',
        description: 'Mecanismo esférico de latón suspendido en el aire que mide los ciclos estelares con arena luminiscente.',
        behavior: 'Emite un sutil tañido armónico a la medianoche y reacciona al estado emocional del entorno.',
        importance: 'Elemento ambiental y ritual'
      },
      {
        id: 'UNIQ-02',
        name: 'Halcón de Ojos de Ámbar',
        type: 'ANIMAL',
        description: 'Halcón del desierto con plumaje blanco y mirada inteligente que reposa en el dosel de la terraza.',
        behavior: 'Advierte con un chillido suave si se aproximan extraños o si se alza una tempestad de arena.',
        importance: 'Centinela vivo'
      }
    ],

    pointsOfInterest: ['Manantial del Loto Dorado', 'Pabellón de Reposo de Terciopelo', 'Altar del Espejo Astral', 'Boticaria de Bálsamos del Velo'],
    ambientColorTheme: 'from-amber-900/40 via-amber-950/30 to-black',
    createdAt: '2026-09-01'
  },
  {
    id: 'LOC-02',
    name: 'Palacio de los Cien Arcos',
    version: 'v1.0',
    linkedWorldId: 'WORLD-ELYSIUM-01',
    geographicContext: 'Distrito urbano',
    rhythmOrVibes: ['Frenético', 'Tenso', 'Vigilado'],
    region: 'Metrópolis Flotante de Qamar',
    environmentType: 'Palacio',
    dangerLevel: 'Neutral',
    dominantFactionId: 'FAC-02',
    atmosphere: 'Mármol blanco pulido, fuentes cantarinas de vino especiado y murmullos de cortesanos con ropajes translúcidos.',
    description: 'La sede del poder político y los banquetes nocturnos, donde cada susurro puede sellar un pacto o quebrar una alianza.',
    constructionStyle: 'Contemporáneo',
    materials: ['Piedra', 'Vidrio', 'Metal'],
    condition: 'Nuevo',
    criticalPointsOfInterest: [
      {
        id: 'POI-05',
        name: 'Cámara de las Delicias',
        type: 'Salón de banquetes',
        function: 'Festines reales y entretenimiento cortesano',
        owner: 'Gran Chambelán',
        location: 'Ala norte del palacio',
        description: 'Mesa imperial con viandas exóticas y orquesta de cítaras.',
        importance: 'Alta'
      },
      {
        id: 'POI-06',
        name: 'Jardín de los Susurros',
        type: 'Jardín interior',
        function: 'Encuentros diplomáticos discretos',
        owner: 'Consorcio de las Especias',
        location: 'Patio central',
        description: 'Laberinto de jazmines y fuentes cantoras que camuflan conversaciones secretas.',
        importance: 'Media'
      },
      {
        id: 'POI-07',
        name: 'Balcón de la Luna Llena',
        type: 'Mirador',
        function: 'Proclamaciones y romance nocturno',
        owner: 'Familia Real',
        location: 'Piso superior',
        description: 'Balustrada de alabastro sobre la ciudad iluminada.',
        importance: 'Baja'
      }
    ],
    convergenceZones: [
      {
        id: 'ZONE-04',
        name: 'Gran Galería de Arcos',
        type: 'Mercado',
        schedule: 'Tardes y noches de gala',
        npcDensity: 'Alta',
        frequentEvents: 'Desfiles diplomáticos, subastas de joyas y bailes de máscaras.',
        securityLevel: 'Vigilancia militar',
        associatedCharacters: ['Embajadores', 'Nobles cortesanos', 'Guardias de alabastro']
      }
    ],
    cultureAndSecurity: {
      authority: 'Gobierno',
      surveillance: 'Extrema',
      socialConduct: ['Competencia', 'Hospitalidad', 'Desconfianza']
    },
    hasHousing: false,
    uniqueElements: [
      {
        id: 'UNIQ-03',
        name: 'Fuente de Vino Astral',
        type: 'ANOMALÍA',
        description: 'Fuente esculpida en malaquita que mana vino aromático sin agotar jamás su caudal.',
        behavior: 'Despierta euforia y sinceridad desinhibida en quienes beben de sus copas.',
        importance: 'Atracción cortesana'
      }
    ],
    pointsOfInterest: ['Cámara de las Delicias', 'Jardín de los Susurros', 'Balcón de la Luna Llena'],
    ambientColorTheme: 'from-indigo-950/50 via-purple-950/30 to-black',
    createdAt: '2026-09-02'
  },
  {
    id: 'LOC-03',
    name: 'Ruinas de la Cripta de Jade',
    version: 'v1.0',
    linkedWorldId: 'WORLD-ELYSIUM-01',
    geographicContext: 'Zona fronteriza',
    rhythmOrVibes: ['Tenso', 'Caótico', 'Aislado'],
    region: 'Desfiladero de los Condenados',
    environmentType: 'Ruinas',
    dangerLevel: 'Hostil',
    dominantFactionId: 'FAC-03',
    atmosphere: 'Paredes agrietadas cubiertas de jeroglíficos resplandecientes, ecos de cánticos oscuros y arena helada.',
    description: 'Antiguo mausoleo sepultado por una tormenta de arena milenaria, habitado por acólitos oscuros y bestias guardianas.',
    constructionStyle: 'Brutalismo',
    materials: ['Piedra', 'Metal', 'Materiales fantásticos'],
    condition: 'Deteriorado',
    criticalPointsOfInterest: [
      {
        id: 'POI-08',
        name: 'Sarcófago de la Reina Olvidada',
        type: 'Monumento fúnebre',
        function: 'Foco de poder arcano y maldiciones',
        owner: 'Sombra Ancestral',
        location: 'Cámara más profunda',
        description: 'Ataúd colosal de jade oscuro sellado con cadenas encantadas.',
        importance: 'Crítica'
      }
    ],
    cultureAndSecurity: {
      authority: 'Organización criminal',
      surveillance: 'Media',
      socialConduct: ['Miedo', 'Desconfianza']
    },
    hasHousing: false,
    uniqueElements: [
      {
        id: 'UNIQ-04',
        name: 'Eco de Canto Fúnebre',
        type: 'EVENTO PERMANENTE',
        description: 'Murmullo rítmico que parece susurrar el nombre verdadero de quien ingresa sin protección astral.',
        behavior: 'Provoca temblores e impone penalizaciones a la concentración mágica.',
        importance: 'Amenaza ambiental'
      }
    ],
    pointsOfInterest: ['Sarcófago de la Reina Olvidada', 'Cámara de las Ofrendas de Jade', 'Abismo de las Sombras'],
    ambientColorTheme: 'from-emerald-950/50 via-slate-950/60 to-black',
    createdAt: '2026-09-03'
  },
  {
    id: 'LOC-04',
    name: 'Taberna del Escorpión de Rubí',
    version: 'v1.0',
    linkedWorldId: 'WORLD-ELYSIUM-01',
    geographicContext: 'Distrito urbano',
    rhythmOrVibes: ['Caótico', 'Frenético'],
    region: 'Bazar Subterráneo de Nube de Oro',
    environmentType: 'Taberna',
    dangerLevel: 'Neutral',
    dominantFactionId: 'FAC-02',
    atmosphere: 'Luz tenue de faroles carmesí, humo aromático de tabaco especiado y risas de mercenarios celebrando botines.',
    description: 'Punto de encuentro clandestino de contrabandistas, aventureros de alquiler y amantes furtivos.',
    constructionStyle: 'Rústico',
    materials: ['Madera', 'Ladrillo', 'Metal'],
    condition: 'Usado',
    criticalPointsOfInterest: [
      {
        id: 'POI-09',
        name: 'Barra del Escorpión',
        type: 'Punto de abastecimiento',
        function: 'Venta de licores raros y compra de rumores',
        owner: 'Viejo Barik',
        location: 'Frente al salón',
        description: 'Barra de roble con marcas de cuchillos y botellas de aguardiente de dátil.',
        importance: 'Alta'
      }
    ],
    cultureAndSecurity: {
      authority: 'Comunidad',
      surveillance: 'Baja',
      socialConduct: ['Indiferencia', 'Competencia', 'Hospitalidad']
    },
    hasHousing: false,
    uniqueElements: [],
    pointsOfInterest: ['Mesa de Juegos de Azar', 'Privado del Escorpión', 'Barra de Licores Astrales'],
    ambientColorTheme: 'from-rose-950/40 via-amber-950/20 to-black',
    createdAt: '2026-09-04'
  }
];

export const DEFAULT_WORLDBUILDING: WorldBuildingConfig = {
  id: 'WORLD-ELYSIUM-01',
  worldName: 'Elysium: El Imperio del Sol y las Arenas',
  version: 'v1.1',
  eraOrTone: 'Fantasía Oriental Mística, Romance & Aventura',
  magicLevel: 'Alta',

  // 01 Historia del Mundo
  history: {
    origin: 'Nacido tras el Cataclismo Solar, cuando las deidades astrales fundieron el firmamento y las arenas, legando oasis de agua viva a los linajes benditos.',
    eras: '1. Era de la Luz Primordial • 2. Era de las Dunas Doradas • 3. Era de los Pactos Velados (Época Actual)',
    keyEvents: [
      'Descubrimiento del Manantial del Loto en Al-Zahra',
      'Firma de la Tregua de los Cuatro Oasis',
      'Establecimiento de las Casas Nobles de Seda y Acero'
    ],
    wars: ['Guerra de los Eclipses contra las Huestes de la Luna Negra'],
    catastrophes: ['La Gran Tormenta de Cristal que sepultó la Ciudadela Vieja'],
    politicalChanges: ['Establecimiento del Protectorado de la Guardia del Velo Dorado'],
    fundamentalEvents: ['Pacto de Reciprocidad de Hospitalidad en todas las tierras sagradas']
  },

  // 02 Geografía
  geographyHierarchy: {
    continents: ['Aethelgard', 'Solsticia'],
    countries: ['Imperio de las Arenas', 'Dominio de Qamar', 'Confederación Fluvial'],
    regions: ['Desierto de las Cenizas Doradas', 'Costa del Nácar', 'Valle de los Miradores'],
    cities: ['Metrópolis Flotante de Qamar', 'Ciudadela del Sol', 'Oasis de Al-Zahra'],
    climates: ['Desértico cálido con noches gélidas', 'Oasis templado con brisa perfumada'],
    resources: ['Especias astrales', 'Lotos dorados', 'Cuarzo de resonancia', 'Seda de duna'],
    specialZones: ['Manantiales Sagrados', 'Criptas Selladas de Jade', 'Torreones Flotantes'],
    hierarchy: [
      {
        continent: 'Aethelgard',
        country: 'Imperio de las Arenas',
        region: 'Desierto de las Cenizas Doradas',
        city: 'Ciudadela del Sol',
        district: 'Tierras Altas de las Palmeras',
        placeName: 'Oasis Sagrado de Al-Zahra'
      }
    ]
  },

  // 03 Política
  politics: {
    governments: ['Monarquía Teocrática Constitucional', 'Consejo Oligárquico de Comerciantes'],
    factions: DEFAULT_FACTIONS,
    organizations: ['Gremio de Alquimistas de la Rosa', 'Hermandad de los Halconeros del Alba'],
    relationships: [
      {
        id: 'REL-01',
        factionAId: 'FAC-01',
        factionBId: 'FAC-02',
        status: 'Alianza',
        notes: 'Comercio garantizado a cambio de escolta armada en las rutas caravaneras.'
      },
      {
        id: 'REL-02',
        factionAId: 'FAC-01',
        factionBId: 'FAC-03',
        status: 'Hostil',
        notes: 'Conflicto religioso abierto por la custodia de los santuarios de orfebrería.'
      },
      {
        id: 'REL-03',
        factionAId: 'FAC-02',
        factionBId: 'FAC-03',
        status: 'Rival',
        notes: 'Disputa clandestina de contrabando y rutas negras en los bazares subterráneos.'
      }
    ],
    conflicts: ['Incursiones de asaltantes de la Luna Negra', 'Tensión arancelaria entre gremios'],
    hierarchies: ['Alta Sacerdotisa / Emir', 'Comandantes de la Guardia', 'Cortesanos y Maestros de Gremio', 'Ciudadanos e Iniciados']
  },

  // 04 Economía
  economy: {
    currency: 'Dinar Solar (oro) • Dracma Lunar (plata) • Granos de Cobre de Oasis',
    resources: ['Agua sagrada purificada', 'Lotos curativos', 'Telas de seda astral', 'Aceite de ámbar'],
    trade: 'Caravanas terrestres con dromedarios blindados y barcazas flotantes fluviales.',
    markets: ['Gran Bazar de Qamar', 'Zoco de las Especias de Al-Zahra'],
    keyGoods: ['Elixires de rejuvenecimiento', 'Hojas de acero damasquino', 'Perlas del desierto'],
    scarcity: ['Agua dulce sin bendecir', 'Madera pesada de construcción', 'Hielo'],
    wealth: 'Concentrada en los Grandes Gremios Mercantiles y Templos de la Guardia',
    systems: ['Mercantilismo proteccionista con aranceles religiosos exentos en días sagrados']
  },

  // 05 Religión / Cultura
  religionAndCulture: {
    isApplicable: true,
    religions: ['Fe del Sol Radiante y los Siete Astros', 'Culto de los Ancestros de la Brisa'],
    traditions: ['Ofrenda matutina de flores de loto en las aguas sagradas', 'Baile de bienvenida con velos de seda'],
    customs: ['Descalzarse antes de pisar alfombras de pelo de camello', 'Compartir té con dátiles antes de negociar'],
    festivities: ['Noche del Loto Ardiente', 'Solsticio de las Cien Luces'],
    taboos: ['Derramar sangre en aguas consagradas', 'Desenfundar armas sin reverencia previa'],
    values: ['Hospitalidad sagrada', 'Honor inquebrantable', 'Lealtad a la palabra empeñada'],
    culturalNorms: ['El anfitrión asume la seguridad física de sus huéspedes hasta el amanecer']
  },

  // 06 Tecnología
  technology: {
    level: 'Medieval',
    allowedTech: ['Orfebrería arcana', 'Relojería hidráulica de precisión', 'Alquimia de destilación'],
    forbiddenTech: ['Armas de pólvora destructiva no consagradas', 'Máquinas de vapor contaminantes']
  },

  // 07 Magia
  magicSystem: {
    hasMagic: true,
    source: 'Resonancia con las corrientes estelares y el manantial sagrado de los oasis.',
    rules: [
      'Toda hechicería requiere canalización consciente y gasta Esencia / SP.',
      'La magia curativa florece en santuarios; la violencia mágica deja huellas perceptibles.'
    ],
    limitations: ['Inoperante en zonas consagradas a la anulación mágica o bajo sellos de plomo arcano'],
    cost: 'Desgaste físico (SP), fatiga mental y riesgo de resonancia si se sobrecarga el núcleo',
    users: 'Sacerdotisas del Velo, Danzarinas Místicas, Alquimistas y Hechiceros iniciados',
    types: ['Magia de Arena y Velo', 'Hechicería Curativa Astral', 'Ilusiones de Espejismo', 'Fuego Sagrado'],
    effects: ['Curación de heridas críticas', 'Creación de barreras protectoras', 'Encantamiento de armas'],
    restrictions: ['Prohibida la nigromancia profana y la dominación forzada de la voluntad ajena']
  },

  // 08 Reglas Físicas
  physicalRules: {
    gravity: 'Física natural constante, con suspensión o levitación leve en santuarios energéticos.',
    biology: 'Los seres vivos se alimentan, sienten dolor, placer y fatiga; requieren descanso y agua.',
    healing: 'Las heridas sanan por reposo y cuidados médicos, acelerables por artes arcanas.',
    death: 'La muerte corporal es definitiva e irreversible, salvo por milagros cósmicos de costo equivalente.',
    travel: 'Las distancias requieren monturas, carruajes o navegación a vela; no hay teletransporte masivo instantáneo.',
    time: 'Ciclo continuo de día y noche de 24 horas estelares con estaciones climáticas bien definidas.',
    space: 'Tridimensional euclidiano, con ciertas criptas que albergan cámaras dimensionales plegadas.',
    energy: 'La energía no se destruye, se transmuta en calor, luz o esencia espiritual.',
    supernaturalPhenomena: 'Tormentas de arena con chispas de plasma estelar en las noches de luna llena.'
  },

  // 09 Reglas Sociales
  socialRules: {
    hierarchies: 'Respeto al linaje familiar, a la jerarquía sacerdotal y al mérito marcial probado.',
    customs: 'El intercambio de presentes sella la confianza; rechazar una copa de té ofrecida es afrenta grave.',
    familyRelations: 'Los clanes protegen a sus miembros; el agravio a uno es venganza para la familia.',
    socialNorms: 'Las cortesías y el trato reverente abren puertas antes que las amenazas.',
    acceptedBehaviors: ['Comercio leal', 'Defensa del indefenso', 'Amor y devoción sincera'],
    rejectedBehaviors: ['Traición al anfitrión', 'Hurto en templos', 'Cobardía en juramentos'],
    protocols: ['Reverencia con la palma sobre el pecho al dirigirse a superiores'],
    socialRoles: ['Danzarina Mística', 'Centinela', 'Erudito', 'Comerciante', 'Sacerdotisa']
  },

  // 10 Leyes Especiales
  specialLaws: [
    {
      id: 'LAW-01',
      title: 'Tregua Sagrada del Oasis',
      scope: 'Toda la cuenca del Oasis Sagrado de Al-Zahra y sus pabellones',
      condition: 'Cualquier acto de hostilidad con armas blancas o conjuros ofensivos',
      effect: 'Destierro inmediato, pérdida de hospitalidad y ataque letal de los centinelas',
      exceptions: 'Duelo ritual de honor previamente santificado por la Alta Sacerdotisa',
      isActive: true
    },
    {
      id: 'LAW-02',
      title: 'Cortesía de los Velos y Saludos',
      scope: 'Distritos urbanos, palacios y recintos sagrados',
      condition: 'Iniciar la conversación con reverencia y respeto formal',
      effect: 'Otorga +25% de simpatía y afinidad inmediata al interactuar con Agentes Lite',
      exceptions: 'Encuentros en zonas salvajes o combate abierto',
      isActive: true
    },
    {
      id: 'LAW-03',
      title: 'Pacto de Reciprocidad Íntima',
      scope: 'Todas las relaciones interpersonales y salas de aposentos',
      condition: 'Contacto físico o caricias en zonas íntimas o erógenas',
      effect: 'Requiere confianza consolidada (>40) para ser correspondida sin rubor o resistencia',
      exceptions: 'Vínculos devocionales de sumisión voluntaria previamente consagrados',
      isActive: true
    },
    {
      id: 'LAW-04',
      title: 'Decreto de la Esencia Mística',
      scope: 'Santuarios, templos y fuentes consagradas',
      condition: 'Canalización de conjuros curativos o de bendición',
      effect: 'El coste de Esencia (SP) se reduce a la mitad y se anula la fatiga mental',
      exceptions: 'Hechicería de sangre o conjuros oscuros proscritos',
      isActive: true
    }
  ],

  // 11 Canon
  canon: {
    characters: ['Alta Sacerdotisa Zehra', 'Comandante Tariq de la Guardia del Velo'],
    facts: ['El Oasis de Al-Zahra jamás se ha secado en cuatro milenios documentados.'],
    relationships: ['La Guardia del Velo Dorado es la protectora jurada del Manantial del Loto.'],
    places: ['Oasis Sagrado de Al-Zahra', 'Palacio de los Cien Arcos', 'Ruinas de Jade'],
    events: ['El Gran Pacto de los Oasis que puso fin a la Guerra de las Sombras'],
    rules: ['Nadie puede reclamar propiedad exclusiva sobre el agua que brota del manantial sagrado.'],
    historicalData: ['Registros estelares inscritos en los monolitos de cuarzo de la terraza alta.']
  },

  // 12 Restricciones Narrativas
  narrativeRestrictions: {
    forbiddenTech: ['Teléfonos móviles', 'Armas de fuego automáticas', 'Computadoras electrónicas'],
    unauthorizedCharacters: ['Dioses omnipotentes descendiendo físicamente sin justificación'],
    incompatibleEvents: ['Destrucción súbita del oasis sin causa justificada', 'Cambios unilaterales en la personalidad de los NPCs'],
    arbitraryRuleChanges: ['Ignorar la tregua del oasis sin desencadenar la reacción armada de la guardia']
  },

  factions: DEFAULT_FACTIONS,
  laws: DEFAULT_WORLD_LAWS
};

export const generateSimpleNpcsForPlace = (place: WorldPlace, density: 'none' | 'few' | 'moderate' | 'crowd'): SimpleAmbientNPC[] => {
  if (density === 'none') return [];
  
  const count = density === 'few' ? 2 : density === 'moderate' ? 4 : 8;
  const pool: { name: string; role: string; disposition: SimpleAmbientNPC['disposition']; dialogue: string }[] = [
    { name: 'Rashid', role: 'Centinela del Velo', disposition: 'Vigilante', dialogue: 'El oasis es sagrado; mantén tu espada envainada o responderás ante la Guardia.' },
    { name: 'Kira', role: 'Sirvienta de Terciopelo', disposition: 'Amistoso', dialogue: '¿Deseas vino de dátiles fresco o agua de rosas para refrescarte?' },
    { name: 'Barik', role: 'Mercader de Seda', disposition: 'Curioso', dialogue: 'Traigo telas tejidas con hilo de plata del norte... ¿te interesa negociar?' },
    { name: 'Amira', role: 'Danzarina Novicia', disposition: 'Amistoso', dialogue: 'El ensayo de esta noche será bajo la luz del orbe lunar.' },
    { name: 'Zahir', role: 'Erudito Errante', disposition: 'Neutral', dialogue: 'Las arenas guardan secretos más antiguos que cualquiera de nuestros reyes.' },
    { name: 'Sombra Encapuchada', role: 'Espía Silencioso', disposition: 'Hostil', dialogue: 'Te observo desde la penumbra. No des un paso en falso.' },
    { name: 'Nadia', role: 'Perfumista del Bazar', disposition: 'Amistoso', dialogue: 'Unas gotas de esencia de jazmín nocturno despiertan el deseo en cualquier corazón.' },
    { name: 'Malik', role: 'Veterano de Caravana', disposition: 'Neutral', dialogue: 'Una tormenta de polvo se avecina por el este. Es mejor no alejarse del campamento.' }
  ];

  return pool.slice(0, count).map((item, idx) => ({
    id: `ambient-npc-${idx + 1}`,
    name: item.name,
    role: item.role,
    disposition: item.disposition,
    snippetDialogue: item.dialogue
  }));
};
