import { ROLES_CATALOG, VISUAL_STYLES } from '../data';

// ============================================================================
// 1. SUB-ESTILOS COMPATIBLES & FUSIÓN ESTÉTICA
// ============================================================================

export interface SubStyleOption {
  id: string;
  name: string;
  fusedTitle: string;
  synergyDescription: string;
  suggestedMaterials: string[];
  suggestedFinishes: string[];
  colorAccents: { id: string; name: string; hex: string }[];
  styleTags: string[];
}

export interface StyleFusionResult {
  mainStyle: string;
  subStyle?: string;
  fusedTitle: string;
  description: string;
  materials: string[];
  finishes: string[];
  colorPalette: { id: string; name: string; hex: string }[];
  isPure: boolean;
}

// Curated synergy matrix for visual styles
export const STYLE_SYNERGY_MATRIX: Record<string, Record<string, Omit<SubStyleOption, 'id' | 'name'>>> = {
  'Gótico': {
    'Elegante': {
      fusedTitle: 'Gótico Aristocrático / Dark Elegance',
      synergyDescription: 'Terciopelos oscuros de alta alcurnia, encajes de chantilly, filigranas de plata noble, corsetería victoriana y joyería de granates o rubí profundo.',
      suggestedMaterials: ['MAT05 - Terciopelo', 'MAT08 - Encaje', 'MAT04 - Seda', 'MAT07 - Cuero'],
      suggestedFinishes: ['FIN02 - Satinado', 'FIN01 - Mate', 'FIN05 - Pulido'],
      colorAccents: [
        { id: 'negro_ebano', name: 'Negro Ébano / Terciopelo', hex: '#0D0E12' },
        { id: 'borgoña_noble', name: 'Borgoña / Vino Real', hex: '#651224' },
        { id: 'plata_antigua', name: 'Plata Envejecida / Platino', hex: '#CBD5E1' }
      ],
      styleTags: ['Aristocrático', 'Siniestro', 'Barroco', 'Alta Costura']
    },
    'Cyberpunk': {
      fusedTitle: 'Cybergoth / Dark Electro-Vamp',
      synergyDescription: 'Fusión de estética gótica con fibras de PVC reflectivas, cables de neón carmesí o violeta, implantes cibernéticos oscurecidos y botas de plataforma industrial.',
      suggestedMaterials: ['MAT10 - PVC', 'MAT07 - Cuero', 'MAT05 - Terciopelo', 'MAT09 - Metal'],
      suggestedFinishes: ['FIN07 - Metalizado', 'FIN03 - Brillante', 'FIN01 - Mate'],
      colorAccents: [
        { id: 'vantablack', name: 'Negro Vantablack', hex: '#050507' },
        { id: 'neon_magenta', name: 'Magenta / Neón Umbral', hex: '#E11D48' },
        { id: 'violeta_cibernetico', name: 'Violeta Eléctrico', hex: '#8B5CF6' }
      ],
      styleTags: ['Industrial', 'Neón Oscuro', 'Futurismo Siniestro', 'Respiradores']
    },
    'Fantasía Tradicional': {
      fusedTitle: 'Dark Fantasy / Fantasía Siniestra',
      synergyDescription: 'Mantos oscuros rasgados, armaduras de hierro ennegrecido forjadas con runas profanas, velos fúnebres y adornos de calaveras y gemas amatista.',
      suggestedMaterials: ['MAT05 - Terciopelo', 'MAT07 - Cuero', 'MAT09 - Metal', 'MAT02 - Lino'],
      suggestedFinishes: ['FIN06 - Desgastado', 'FIN01 - Mate', 'FIN08 - Craquelado'],
      colorAccents: [
        { id: 'hierro_negro', name: 'Hierro Negro / Ceniza', hex: '#1E2229' },
        { id: 'purpura_nigromante', name: 'Púrpura Profundo', hex: '#581C87' },
        { id: 'plata_lunar', name: 'Plata Lunar Pálida', hex: '#94A3B8' }
      ],
      styleTags: ['Épico Sombrío', 'Forja Umbral', 'Grimorios', 'Rúnico']
    },
    'Fantasía Oriental': {
      fusedTitle: 'Dark Wuxia / Yōkai Imperial',
      synergyDescription: 'Hanfu y kimonos de seda negra y laca carmesí, motivos de cuervos y crisantemos marchitos, máscaras de oni oscuras y adornos de jade negro.',
      suggestedMaterials: ['MAT04 - Seda', 'MAT05 - Terciopelo', 'MAT07 - Cuero', 'MAT09 - Metal'],
      suggestedFinishes: ['FIN02 - Satinado', 'FIN05 - Pulido', 'FIN01 - Mate'],
      colorAccents: [
        { id: 'seda_negra', name: 'Seda Negra Profunda', hex: '#121318' },
        { id: 'laca_carmesi', name: 'Laca Roja Carmesí', hex: '#991B1B' },
        { id: 'jade_oscuro', name: 'Jade Abisal / Obsidiana', hex: '#064E3B' }
      ],
      styleTags: ['Wuxia Oscuro', 'Yōkai', 'Telas Orientales', 'Laca & Oro']
    },
    'Sexy / Provocativo': {
      fusedTitle: 'Gothic Fetish / Seductora Nocturna',
      synergyDescription: 'Corsetería ceñida con ballenas de acero, encajes translúcidos en escotes y aberturas, arneses de cuero pulido, medias de red y collares con relicario.',
      suggestedMaterials: ['MAT08 - Encaje', 'MAT07 - Cuero', 'MAT10 - PVC', 'MAT05 - Terciopelo'],
      suggestedFinishes: ['FIN03 - Brillante', 'FIN02 - Satinado', 'FIN01 - Mate'],
      colorAccents: [
        { id: 'negro_charol', name: 'Negro Charol / Vinilo', hex: '#0B0B0E' },
        { id: 'rojo_sangre', name: 'Rojo Sangre / Rubí', hex: '#B91C1C' },
        { id: 'purpura_seductor', name: 'Púrpura Seductor', hex: '#6B21A8' }
      ],
      styleTags: ['Provocativo', 'Ceñido', 'Corsetería', 'Transparencias']
    },
    'Steampunk': {
      fusedTitle: 'Gothic Victorian Industrial',
      synergyDescription: 'Corsés de cuero negro con herrajes de bronce oxidado, encajes teñidos de humo, lentes victorianos oscuros y engranajes con filigrana funeraria.',
      suggestedMaterials: ['MAT07 - Cuero', 'MAT05 - Terciopelo', 'MAT09 - Metal', 'MAT08 - Encaje'],
      suggestedFinishes: ['FIN06 - Desgastado', 'FIN01 - Mate', 'FIN05 - Pulido'],
      colorAccents: [
        { id: 'bronce_oscuro', name: 'Bronce Oscuro / Pátina', hex: '#78350F' },
        { id: 'negro_ceniza', name: 'Negro Ceniza Industrial', hex: '#1C1917' },
        { id: 'burdeos_victoriano', name: 'Burdeos Victoriano', hex: '#7F1D1D' }
      ],
      styleTags: ['Victoriano', 'Industrial', 'Latón & Humo', 'Mecánica Fúnebre']
    },
    'Techwear': {
      fusedTitle: 'Shadow Tech / Infiltrador Sombrío',
      synergyDescription: 'Tejidos técnicos impermeables Vantablack, correas de sujeción tácticas no reflectivas, mascarilla respiradora ergonómica y cortes angulares anatómicos.',
      suggestedMaterials: ['MAT10 - PVC', 'MAT06 - Denim', 'MAT07 - Cuero'],
      suggestedFinishes: ['FIN01 - Mate', 'FIN06 - Desgastado'],
      colorAccents: [
        { id: 'vantablack_mate', name: 'Negro Carbono Puro', hex: '#0F172A' },
        { id: 'gris_grafito', name: 'Gris Grafito Táctico', hex: '#334155' },
        { id: 'carmesi_sigiloso', name: 'Carmesí Subterráneo', hex: '#991B1B' }
      ],
      styleTags: ['Táctico', 'Sigilo', 'Cinchas Tácticas', 'Modular']
    }
  },
  'Cyberpunk': {
    'Techwear': {
      fusedTitle: 'Cyber-Tactical / Spec-Ops 2099',
      synergyDescription: 'Cinchas tácticas modulares con hebillas magnéticas fidlock, membranas hidrófugas con ribetes luminosos y placas blindadas de fibra de carbono.',
      suggestedMaterials: ['MAT10 - PVC', 'MAT06 - Denim', 'MAT07 - Cuero', 'MAT09 - Metal'],
      suggestedFinishes: ['FIN01 - Mate', 'FIN07 - Metalizado', 'FIN03 - Brillante'],
      colorAccents: [
        { id: 'cian_neon', name: 'Cian Neón Eléctrico', hex: '#06B6D4' },
        { id: 'negro_táctico', name: 'Negro Táctico 2.0', hex: '#0F172A' },
        { id: 'amarillo_alerta', name: 'Amarillo Neón de Advertencia', hex: '#FACC15' }
      ],
      styleTags: ['Modular', 'Fidlock', 'Hologramas', 'Kevlar & Fibras']
    },
    'Fantasía Oriental': {
      fusedTitle: 'Neo-Edo / Cyber-Samurái & Yakuza',
      synergyDescription: 'Kimonos acortados y haori técnicos con pantallas flexibles, katanas de filo térmico iónico, tatuajes dérmicos LED y tabi futuristas.',
      suggestedMaterials: ['MAT04 - Seda', 'MAT10 - PVC', 'MAT07 - Cuero', 'MAT09 - Metal'],
      suggestedFinishes: ['FIN07 - Metalizado', 'FIN02 - Satinado', 'FIN03 - Brillante'],
      colorAccents: [
        { id: 'rojo_laser', name: 'Rojo Láser Neón', hex: '#EF4444' },
        { id: 'oro_holografico', name: 'Oro Cibernético / Ámbar', hex: '#F59E0B' },
        { id: 'negro_seda_sintetica', name: 'Negro Seda Sintética', hex: '#111827' }
      ],
      styleTags: ['Cyber-Yakuza', 'Haori LED', 'Katana Térmica', 'Neo-Shinjuku']
    },
    'Elegante': {
      fusedTitle: 'Cyber-Luxury / Alta Sociedad Megacorp',
      synergyDescription: 'Trajes de sastrería de nanofibra reflectiva, vestidos con caídas de luz de fibra óptica, joyería biónica de platino y monóculos de interfaz dorada.',
      suggestedMaterials: ['MAT04 - Seda', 'MAT10 - PVC', 'MAT05 - Terciopelo'],
      suggestedFinishes: ['FIN05 - Pulido', 'FIN07 - Metalizado', 'FIN02 - Satinado'],
      colorAccents: [
        { id: 'platino_futuro', name: 'Platino Biónico', hex: '#E2E8F0' },
        { id: 'azul_corp', name: 'Azul Zafiro Corporativo', hex: '#1E40AF' },
        { id: 'oro_champan', name: 'Oro Champán Brillante', hex: '#FDE047' }
      ],
      styleTags: ['Ejecutivo Megacorp', 'Nanofibra', 'Fibra Óptica', 'Lujo Biónico']
    },
    'Gótico': {
      fusedTitle: 'Cybergoth / Underground Rave',
      synergyDescription: 'Dreadlocks sintéticos de neón, arneses de vinilo negro, máscaras antigás cromadas y luces estroboscópicas integradas en las articulaciones.',
      suggestedMaterials: ['MAT10 - PVC', 'MAT07 - Cuero', 'MAT05 - Terciopelo'],
      suggestedFinishes: ['FIN03 - Brillante', 'FIN07 - Metalizado', 'FIN01 - Mate'],
      colorAccents: [
        { id: 'magenta_acido', name: 'Magenta Ácido', hex: '#EC4899' },
        { id: 'verde_toxico', name: 'Verde Tóxico / Radiación', hex: '#22C55E' },
        { id: 'negro_asfalto', name: 'Negro Asfalto', hex: '#09090B' }
      ],
      styleTags: ['Rave', 'Vinilo', 'Cables Neón', 'Underground']
    },
    'Militar': {
      fusedTitle: 'Cibermilitar / Soldado de Élite Aumentado',
      synergyDescription: 'Armaduras exoesqueletadas reforzadas, visores tácticos de datos HUD, cascos de combate sellados y camuflaje óptico activo.',
      suggestedMaterials: ['MAT07 - Cuero', 'MAT09 - Metal', 'MAT10 - PVC', 'MAT06 - Denim'],
      suggestedFinishes: ['FIN01 - Mate', 'FIN07 - Metalizado', 'FIN06 - Desgastado'],
      colorAccents: [
        { id: 'verde_militar_ciber', name: 'Verde Oliva Ciber', hex: '#15803D' },
        { id: 'gris_blindaje', name: 'Gris Blindaje Acorazado', hex: '#475569' },
        { id: 'naranja_hud', name: 'Naranja Alerta HUD', hex: '#F97316' }
      ],
      styleTags: ['Exoesqueleto', 'HUD Táctico', 'Camuflaje Activo', 'Balística']
    },
    'Vanguardista / Haute Couture': {
      fusedTitle: 'Cyber-Couture / Moda Holográfica 3D',
      synergyDescription: 'Siluetas geométricas asimétricas que proyectan volumetría flotante, telas con sensores biomecánicos y vestidos de cristal líquido interactivo.',
      suggestedMaterials: ['MAT10 - PVC', 'MAT04 - Seda', 'MAT09 - Metal'],
      suggestedFinishes: ['FIN07 - Metalizado', 'FIN03 - Brillante', 'FIN05 - Pulido'],
      colorAccents: [
        { id: 'cromo_liquido', name: 'Cromo Líquido / Iridiscente', hex: '#CBD5E1' },
        { id: 'violeta_cuantico', name: 'Violeta Cuántico', hex: '#7C3AED' },
        { id: 'turquesa_holograma', name: 'Turquesa Holográfico', hex: '#2DD4BF' }
      ],
      styleTags: ['Holografía', 'Geometría 3D', 'Cristal Líquido', 'Editorial']
    }
  },
  'Elegante': {
    'Fantasía Tradicional': {
      fusedTitle: 'Alta Corte Imperial / Nobleza Legendaria',
      synergyDescription: 'Vestiduras de corte con capas de brocado bordado en hilo de oro, coronas y tiaras de filigrana élfica, capas con cola y cuellos de encaje regio.',
      suggestedMaterials: ['MAT04 - Seda', 'MAT05 - Terciopelo', 'MAT08 - Encaje', 'MAT01 - Algodón'],
      suggestedFinishes: ['FIN02 - Satinado', 'FIN05 - Pulido', 'FIN07 - Metalizado'],
      colorAccents: [
        { id: 'azul_real', name: 'Azul Real Imperial', hex: '#1D4ED8' },
        { id: 'oro_solar', name: 'Oro Imperial / Ámbar', hex: '#F59E0B' },
        { id: 'blanco_niveo', name: 'Blanco Armiño Puro', hex: '#FFFFFF' }
      ],
      styleTags: ['Brocado', 'Tiara Real', 'Capas con Cola', 'Filigrana Élfica']
    },
    'Fantasía Oriental': {
      fusedTitle: 'Corte Dinástica de Seda & Jade',
      synergyDescription: 'Hanfu imperial de doce capas de gasa de seda, horquillas buyao doradas con borlas colgantes, fajas obi de brocado y pendientes de jade imperial pulido.',
      suggestedMaterials: ['MAT04 - Seda', 'MAT02 - Lino', 'MAT05 - Terciopelo'],
      suggestedFinishes: ['FIN02 - Satinado', 'FIN05 - Pulido'],
      colorAccents: [
        { id: 'jade_imperial', name: 'Verde Jade Imperial', hex: '#059669' },
        { id: 'rojo_cinabrio', name: 'Rojo Cinabrio Dinástico', hex: '#DC2626' },
        { id: 'oro_dinastia', name: 'Oro Ancestral Pulido', hex: '#F59E0B' }
      ],
      styleTags: ['Hanfu Imperial', 'Horquillas Buyao', 'Jade Noble', 'Doce Capas']
    },
    'Sexy / Provocativo': {
      fusedTitle: 'Femme Fatale / Glamour de Alta Costura',
      synergyDescription: 'Vestidos de noche con abertura profunda hasta el muslo, escotes descubiertos en espalda, transparencias de tul bordado y tacones stiletto afilados.',
      suggestedMaterials: ['MAT04 - Seda', 'MAT08 - Encaje', 'MAT05 - Terciopelo'],
      suggestedFinishes: ['FIN02 - Satinado', 'FIN03 - Brillante'],
      colorAccents: [
        { id: 'carmesi_pasion', name: 'Rojo Carmesí Pasión', hex: '#DC2626' },
        { id: 'negro_noche', name: 'Negro Noche Satinado', hex: '#0F172A' },
        { id: 'champan_seda', name: 'Champán de Seda', hex: '#FEF08A' }
      ],
      styleTags: ['Abertura Muslo', 'Escote Espalda', 'Stiletto', 'Tul']
    },
    'Militar': {
      fusedTitle: 'Gala Militar / Guardia de Honor',
      synergyDescription: 'Casacas militares con botonadura dorada cruzada, charreteras de flecos de oro, bandas ceremoniales al pecho, guantes blancos de piel y botas de montar relucientes.',
      suggestedMaterials: ['MAT01 - Algodón', 'MAT05 - Terciopelo', 'MAT07 - Cuero'],
      suggestedFinishes: ['FIN05 - Pulido', 'FIN02 - Satinado', 'FIN01 - Mate'],
      colorAccents: [
        { id: 'azul_marina', name: 'Azul Marino de Oficial', hex: '#1E3A8A' },
        { id: 'blanco_gala', name: 'Blanco Ceremonial', hex: '#F8FAFC' },
        { id: 'oro_charretera', name: 'Oro de Charreteras', hex: '#D97706' }
      ],
      styleTags: ['Charreteras', 'Botonadura Doble', 'Bandas de Rango', 'Bota de Montar']
    },
    'Minimalista': {
      fusedTitle: 'Quiet Luxury / Elegancia Arquitectónica',
      synergyDescription: 'Líneas puras y depuradas sin logotipos ni ornamentos superfluos, caída impecable de sastrería artesanal, cachemira de tonos neutros y proporciones doradas.',
      suggestedMaterials: ['MAT01 - Algodón', 'MAT04 - Seda', 'MAT03 - Lana'],
      suggestedFinishes: ['FIN01 - Mate', 'FIN02 - Satinado'],
      colorAccents: [
        { id: 'marfil_calido', name: 'Blanco Marfil Cálido', hex: '#F5F5F4' },
        { id: 'camel_noble', name: 'Camel / Arena Suave', hex: '#D6D3D1' },
        { id: 'carbon_suave', name: 'Carbón Suave', hex: '#292524' }
      ],
      styleTags: ['Old Money', 'Líneas Puras', 'Sastrería Invisible', 'Tonos Neutros']
    }
  },
  'Fantasía Tradicional': {
    'Fantasía Oriental': {
      fusedTitle: 'Fantasía Transcontinental / Épica de la Ruta de la Seda',
      synergyDescription: 'Cotas de malla con incrustaciones de láminas orientales, túnicas de seda bajo mantos de piel nórdica, katanas templadas con forja élfica y joyería de lapislázuli y jade.',
      suggestedMaterials: ['MAT04 - Seda', 'MAT07 - Cuero', 'MAT09 - Metal', 'MAT05 - Terciopelo'],
      suggestedFinishes: ['FIN02 - Satinado', 'FIN05 - Pulido', 'FIN07 - Metalizado'],
      colorAccents: [
        { id: 'zafiro_profundo', name: 'Azul Zafiro / Noche', hex: '#1E3A8A' },
        { id: 'oro_elfico', name: 'Oro Élfico Radiante', hex: '#F59E0B' },
        { id: 'verde_jade', name: 'Verde Jade Legendario', hex: '#059669' }
      ],
      styleTags: ['Transcontinental', 'Seda & Mithril', 'Runas & Sellos', 'Cosmopolita']
    },
    'Gótico': {
      fusedTitle: 'Grimdark Fantasy / Fantasía de las Sombras',
      synergyDescription: 'Acero renegrido mellado por batallas, capas rasgadas de piel de lobo negro, medallones de deidades olvidadas y vendas ensangrentadas entre placas defensivas.',
      suggestedMaterials: ['MAT07 - Cuero', 'MAT09 - Metal', 'MAT05 - Terciopelo'],
      suggestedFinishes: ['FIN06 - Desgastado', 'FIN01 - Mate'],
      colorAccents: [
        { id: 'acero_oscuro', name: 'Acero Ennegrecido', hex: '#1E293B' },
        { id: 'rojo_oxido', name: 'Rojo Óxido / Carmesí Seco', hex: '#991B1B' },
        { id: 'hueso_antiguo', name: 'Hueso Antiguo / Ceniza', hex: '#E2E8F0' }
      ],
      styleTags: ['Grimdark', 'Batalla Brutal', 'Pieles de Bestia', 'Acero Mellado']
    },
    'Militar': {
      fusedTitle: 'Legión Feudal / Guardia de la Corona',
      synergyDescription: 'Uniformes militares estructurados con tabardos heráldicos, corazas pulidas con emblemas del reino, guardabrazos de cuero de combate y botas con espuelas de bronce.',
      suggestedMaterials: ['MAT09 - Metal', 'MAT07 - Cuero', 'MAT01 - Algodón'],
      suggestedFinishes: ['FIN05 - Pulido', 'FIN01 - Mate'],
      colorAccents: [
        { id: 'azul_heraldico', name: 'Azul Heráldico', hex: '#2563EB' },
        { id: 'plata_pulida', name: 'Plata de Caballero', hex: '#CBD5E1' },
        { id: 'dorado_emblema', name: 'Oro de Emblema', hex: '#D97706' }
      ],
      styleTags: ['Tabardo', 'Heráldica', 'Legión', 'Escudo de Armas']
    },
    'Steampunk': {
      fusedTitle: 'Arcanopunk / Magitek Medieval',
      synergyDescription: 'Armaduras de placas alimentadas por viales de maná brillante, conductos de cobre que canalizan energía elemental y armas arcanas con mecanismos de relojería.',
      suggestedMaterials: ['MAT09 - Metal', 'MAT07 - Cuero', 'MAT04 - Seda'],
      suggestedFinishes: ['FIN05 - Pulido', 'FIN07 - Metalizado', 'FIN06 - Desgastado'],
      colorAccents: [
        { id: 'cobre_magitek', name: 'Cobre Brillante Magitek', hex: '#B45309' },
        { id: 'azul_mana', name: 'Azul Maná Luminiscente', hex: '#38BDF8' },
        { id: 'cuero_bronceado', name: 'Cuero Bronceado', hex: '#78350F' }
      ],
      styleTags: ['Magitek', 'Relojería Mágica', 'Viales de Maná', 'Cobre Arcano']
    }
  },
  'Fantasía Oriental': {
    'Militar': {
      fusedTitle: 'Shogunato Marcial / Guardia Dinástica',
      synergyDescription: 'Armadura samurái de láminas de laca cosidas con seda roja, jinbaori bordado con el blasón militar, máscara menpo intimidante y botas jikatabi reforzadas.',
      suggestedMaterials: ['MAT09 - Metal', 'MAT04 - Seda', 'MAT07 - Cuero'],
      suggestedFinishes: ['FIN05 - Pulido', 'FIN01 - Mate', 'FIN02 - Satinado'],
      colorAccents: [
        { id: 'rojo_shogunato', name: 'Rojo Carmesí Shogun', hex: '#DC2626' },
        { id: 'negro_laca', name: 'Negro Laca de Armadura', hex: '#0A0A0C' },
        { id: 'oro_kamon', name: 'Oro de Kamon Militar', hex: '#F59E0B' }
      ],
      styleTags: ['Menpo', 'Jinbaori', 'Láminas Samurái', 'Kamon']
    },
    'Kawaii / Lindo': {
      fusedTitle: 'Wa Lolita / Sacerdotisa Dulce de los Cerezos',
      synergyDescription: 'Kimonos acampanados con volantes de encaje dulce, estampados de pétalos de sakura y conejos lunares, lazos gigantes obi con campanas suzu y geta adornadas.',
      suggestedMaterials: ['MAT04 - Seda', 'MAT01 - Algodón', 'MAT08 - Encaje'],
      suggestedFinishes: ['FIN02 - Satinado', 'FIN01 - Mate'],
      colorAccents: [
        { id: 'rosa_sakura', name: 'Rosa Flor de Cerezo', hex: '#F472B6' },
        { id: 'blanco_perla', name: 'Blanco Perla de Arroz', hex: '#FFFFFF' },
        { id: 'rojo_torii', name: 'Rojo Bermellón Torii', hex: '#EF4444' }
      ],
      styleTags: ['Wa Lolita', 'Sakura', 'Lazos Grandes', 'Campanillas Suzu']
    },
    'Steampunk': {
      fusedTitle: 'Taisho Steam / Relojería de Kioto',
      synergyDescription: 'Hakama tradicional combinada con botas victorianas con cordones, sombreros de copa sobre peinados orientales y katanas con vaina mecanizada de vapor.',
      suggestedMaterials: ['MAT04 - Seda', 'MAT07 - Cuero', 'MAT09 - Metal'],
      suggestedFinishes: ['FIN06 - Desgastado', 'FIN02 - Satinado', 'FIN05 - Pulido'],
      colorAccents: [
        { id: 'laton_oriental', name: 'Latón de Relojería', hex: '#D97706' },
        { id: 'azul_indigo', name: 'Azul Índigo Tradicional', hex: '#1E3A8A' },
        { id: 'cuero_madera', name: 'Cuero Marrón Castaño', hex: '#78350F' }
      ],
      styleTags: ['Era Taisho', 'Hakama & Botas', 'Engranajes Kioto', 'Mecánica Oriental']
    }
  },
  'Steampunk': {
    'Militar': {
      fusedTitle: 'Guardia Diésel / Cuerpo Acorazado de Vapor',
      synergyDescription: 'Gabardinas de cuero pesado con hombreras de cobre reforzado, respiradores de filtro de carbón, cinturones con cartucheras de bronce y botas con blindaje de latón.',
      suggestedMaterials: ['MAT07 - Cuero', 'MAT09 - Metal', 'MAT06 - Denim'],
      suggestedFinishes: ['FIN06 - Desgastado', 'FIN05 - Pulido'],
      colorAccents: [
        { id: 'bronce_militar', name: 'Bronce Acorazado', hex: '#92400E' },
        { id: 'verde_trinchera', name: 'Verde Trinchera Vapor', hex: '#166534' },
        { id: 'cuero_ahumado', name: 'Cuero Ahumado', hex: '#451A03' }
      ],
      styleTags: ['Diésel', 'Vapor Pesado', 'Cartucheras Bronce', 'Respirador']
    },
    'Elegante': {
      fusedTitle: 'Aristocracia Victoriana a Vapor / Lord Inventor',
      synergyDescription: 'Chalecos de brocado de seda con cadenas de reloj de bolsillo de oro, sombreros de copa con gafas de aumento biseladas, bastones con catalizadores mecánicos y levitas entalladas.',
      suggestedMaterials: ['MAT04 - Seda', 'MAT05 - Terciopelo', 'MAT09 - Metal', 'MAT07 - Cuero'],
      suggestedFinishes: ['FIN05 - Pulido', 'FIN02 - Satinado'],
      colorAccents: [
        { id: 'oro_victoriano', name: 'Oro Victoriano Pulido', hex: '#F59E0B' },
        { id: 'borgoña_terciopelo', name: 'Borgoña Terciopelo', hex: '#881337' },
        { id: 'bronce_noble', name: 'Bronce Noble', hex: '#B45309' }
      ],
      styleTags: ['Reloj de Bolsillo', 'Levita', 'Gafas Biseladas', 'Brocado']
    }
  },
  'Militar': {
    'Techwear': {
      fusedTitle: 'Spec-Ops Moderno / Táctico Urbano',
      synergyDescription: 'Uniformes de camuflaje digital con bolsillos modulares MOLLE, chalecos portaplacas de perfil bajo, coderas y rodilleras integradas y botas tácticas antideslizantes.',
      suggestedMaterials: ['MAT06 - Denim', 'MAT10 - PVC', 'MAT07 - Cuero'],
      suggestedFinishes: ['FIN01 - Mate', 'FIN06 - Desgastado'],
      colorAccents: [
        { id: 'gris_asfalto', name: 'Gris Táctico Urbano', hex: '#475569' },
        { id: 'negro_operativo', name: 'Negro Operativo', hex: '#0F172A' },
        { id: 'oliva_camuflaje', name: 'Verde Oliva Militar', hex: '#15803D' }
      ],
      styleTags: ['MOLLE', 'Portaplacas', 'Camuflaje Digital', 'Spec-Ops']
    },
    'Rústico / Superviviente': {
      fusedTitle: 'Guerrillero Veterano / Superviviente Táctico',
      synergyDescription: 'Prendas militares desgastadas y remendadas con alambre y cuero, ponchos impermeables rasgados, vendajes en muñecas y accesorios de supervivencia de campaña.',
      suggestedMaterials: ['MAT06 - Denim', 'MAT07 - Cuero', 'MAT01 - Algodón'],
      suggestedFinishes: ['FIN06 - Desgastado', 'FIN01 - Mate'],
      colorAccents: [
        { id: 'marron_barro', name: 'Marrón Tierra / Barro', hex: '#78350F' },
        { id: 'verde_selva', name: 'Verde Selva Curtido', hex: '#14532D' },
        { id: 'caqui_desierto', name: 'Caqui Desierto', hex: '#A8A29E' }
      ],
      styleTags: ['Guerrilla', 'Remiendos', 'Supervivencia', 'Poncho']
    }
  },
  'Kawaii / Lindo': {
    'Gótico': {
      fusedTitle: 'Gothic Lolita / Pastel Goth',
      synergyDescription: 'Vestidos victorianos de corte muñeca en tonos lavanda o negro azabache, cruces barrocas, murciélagos de felpa, lazos oscuros y zapatos mary jane de plataforma.',
      suggestedMaterials: ['MAT08 - Encaje', 'MAT05 - Terciopelo', 'MAT01 - Algodón'],
      suggestedFinishes: ['FIN01 - Mate', 'FIN02 - Satinado'],
      colorAccents: [
        { id: 'lavanda_pastel', name: 'Lavanda Pastel', hex: '#DDD6FE' },
        { id: 'negro_lolita', name: 'Negro Muñeca', hex: '#18181B' },
        { id: 'rosa_claro', name: 'Rosa Pastel Pálido', hex: '#FBCFE8' }
      ],
      styleTags: ['Gothic Lolita', 'Mary Jane', 'Lazos de Encaje', 'Pastel Goth']
    },
    'Cyberpunk': {
      fusedTitle: 'Cyber-Pop / Idol Harajuku Neón',
      synergyDescription: 'Faldas plisadas holográficas, auriculares con orejitas LED luminiscentes, calentadores de piernas de vinilo brillante y accesorios kawaii con interfaz digital.',
      suggestedMaterials: ['MAT10 - PVC', 'MAT01 - Algodón', 'MAT04 - Seda'],
      suggestedFinishes: ['FIN03 - Brillante', 'FIN07 - Metalizado'],
      colorAccents: [
        { id: 'cian_kawaii', name: 'Cian Pastel Eléctrico', hex: '#22D3EE' },
        { id: 'rosa_chicle', name: 'Rosa Chicle Neón', hex: '#F43F5E' },
        { id: 'amarillo_pop', name: 'Amarillo Pastel Brillante', hex: '#FDE047' }
      ],
      styleTags: ['Harajuku', 'Orejitas LED', 'Holográfico', 'Idol Neón']
    }
  },
  'Sexy / Provocativo': {
    'Cyberpunk': {
      fusedTitle: 'Urban Street Pin-up / Techwear Provocativo',
      synergyDescription: 'Micro chaquetas cropped sobre el busto, tops underboob asimétricos con cremallera, arneses de cinchas elásticas, micro shorts con argollas O-ring, medias asimétricas con ligas al muslo y botines de plataforma.',
      suggestedMaterials: ['MAT10 - PVC', 'MAT07 - Cuero', 'MAT06 - Denim', 'MAT04 - Seda'],
      suggestedFinishes: ['FIN03 - Brillante', 'FIN01 - Mate', 'FIN07 - Metalizado'],
      colorAccents: [
        { id: 'amarillo_neon', name: 'Amarillo Neón / Asfalto', hex: '#EAB308' },
        { id: 'negro_carbono', name: 'Negro Mate Táctico', hex: '#0F172A' },
        { id: 'magenta_cyber', name: 'Magenta / Neón Provocativo', hex: '#F43F5E' }
      ],
      styleTags: ['Urban Pin-up', 'Underboob', 'Micro Chaqueta', 'Ligas Asimétricas', 'Arnés Urbano']
    },
    'Fantasía Oriental': {
      fusedTitle: 'Kemono Boudoir / Romance Oriental',
      synergyDescription: 'Micro qipaos y cheongsams de seda translúcida con aberturas extremas en caderas, escotes gota en el pecho, fajas obi con hilos de oro, orejitas y colas kemono con campanillas doradas y cadenas de cuerpo.',
      suggestedMaterials: ['MAT04 - Seda', 'MAT08 - Encaje', 'MAT05 - Terciopelo', 'MAT09 - Metal'],
      suggestedFinishes: ['FIN02 - Satinado', 'FIN03 - Brillante', 'FIN05 - Pulido'],
      colorAccents: [
        { id: 'rojo_escarlata', name: 'Rojo Escarlata / Sangre de Loto', hex: '#DC2626' },
        { id: 'oro_dinastico', name: 'Oro Dinástico Pulido', hex: '#F59E0B' },
        { id: 'seda_blanca', name: 'Blanco Nieve Translúcido', hex: '#F8FAFC' }
      ],
      styleTags: ['Boudoir Oriental', 'Micro Qipao', 'Kemono Sensual', 'Cadenas de Oro', 'Abertura Extrema']
    },
    'Fantasía Tradicional': {
      fusedTitle: 'Dark Fantasy Erotic Valkyrie / Bondage Táctico',
      synergyDescription: 'Micro placas de armadura pulida sobre lencería y bodysuits de látex o cuero líquido, arneses bondage con anillas O-ring, gargantillas con correa, medias de látex sobre el muslo y estoques enjoyados.',
      suggestedMaterials: ['MAT07 - Cuero', 'MAT10 - PVC', 'MAT09 - Metal', 'MAT08 - Encaje'],
      suggestedFinishes: ['FIN03 - Brillante', 'FIN05 - Pulido', 'FIN01 - Mate'],
      colorAccents: [
        { id: 'negro_latex', name: 'Negro Látex Espejo', hex: '#09090B' },
        { id: 'plata_mithril', name: 'Plata Pulida de Valkiria', hex: '#E2E8F0' },
        { id: 'carmesi_abismo', name: 'Carmesí Abisal', hex: '#991B1B' }
      ],
      styleTags: ['Dark Valkyrie', 'Bodysuit Látex', 'Arnés Bondage', 'Micro Armadura', 'Tacón Aguja']
    },
    'Elegante': {
      fusedTitle: 'Lencería Nupcial de Gala / Romance Nocturno',
      synergyDescription: 'Corsés de satén marfil con varillas vistas, vestidos de novia transparentes con faldón de tul abierto, peignoirs de seda con ribetes de plumas, medias de liga bordadas y velos cortos de encaje de Chantilly.',
      suggestedMaterials: ['MAT04 - Seda', 'MAT08 - Encaje', 'MAT05 - Terciopelo'],
      suggestedFinishes: ['FIN02 - Satinado', 'FIN01 - Mate', 'FIN03 - Brillante'],
      colorAccents: [
        { id: 'blanco_nupcial', name: 'Blanco Nupcial Perla', hex: '#FFFFFF' },
        { id: 'oro_rosa', name: 'Oro Rosa / Champagne', hex: '#FB7185' },
        { id: 'negro_nocturno', name: 'Negro Encaje de Noche', hex: '#18181B' }
      ],
      styleTags: ['Bridal Romance', 'Corsé Nupcial', 'Velo Translúcido', 'Plumas de Marabú', 'Lencería de Gala']
    },
    'Gótico': {
      fusedTitle: 'Gothic Fetish / Succubus Eterna',
      synergyDescription: 'Corsetería ceñida con ballenas de acero, encajes translúcidos en escotes y aberturas, arneses de cuero pulido, medias de red con strass, colas de diablesa con lazada y gargantillas con relicario de rubí.',
      suggestedMaterials: ['MAT08 - Encaje', 'MAT07 - Cuero', 'MAT10 - PVC', 'MAT05 - Terciopelo'],
      suggestedFinishes: ['FIN03 - Brillante', 'FIN02 - Satinado', 'FIN01 - Mate'],
      colorAccents: [
        { id: 'negro_charol', name: 'Negro Charol / Vinilo', hex: '#0B0B0E' },
        { id: 'rojo_sangre', name: 'Rojo Sangre / Rubí', hex: '#B91C1C' },
        { id: 'purpura_succubus', name: 'Púrpura Seductor Oscuro', hex: '#581C87' }
      ],
      styleTags: ['Succubus', 'Gothic Fetish', 'Corsetería', 'Transparencias', 'Strass']
    },
    'Militar': {
      fusedTitle: 'Spec-Ops Provocativa / Agente Táctica Sensual',
      synergyDescription: 'Uniformes tácticos entallados con micro shorts de camuflaje, tops de compresión con cremallera abierta, ligueros con pistoleras Kydex, correajes cruzados y botas militares de tacón.',
      suggestedMaterials: ['MAT07 - Cuero', 'MAT06 - Denim', 'MAT10 - PVC'],
      suggestedFinishes: ['FIN01 - Mate', 'FIN03 - Brillante'],
      colorAccents: [
        { id: 'oliva_tactico', name: 'Verde Oliva Operativo', hex: '#166534' },
        { id: 'negro_sigilo', name: 'Negro Sigilo', hex: '#0F172A' },
        { id: 'carmesi_alerta', name: 'Rojo Alerta Operativa', hex: '#DC2626' }
      ],
      styleTags: ['Táctico Sensual', 'Pistolera Liguero', 'Top Cremallera', 'Spec-Ops']
    },
    'Kawaii / Lindo': {
      fusedTitle: 'Sweet Romance / Conejita & Idol Provocativa',
      synergyDescription: 'Bunny suits de satén brillante con orejitas suaves, lazos gigantes en la espalda, cuellos con pajarita, faldas de volantes cortas y medias hasta el muslo con corazones.',
      suggestedMaterials: ['MAT04 - Seda', 'MAT08 - Encaje', 'MAT01 - Algodón'],
      suggestedFinishes: ['FIN02 - Satinado', 'FIN03 - Brillante'],
      colorAccents: [
        { id: 'rosa_pastel', name: 'Rosa Pastel Seductor', hex: '#F472B6' },
        { id: 'blanco_algodon', name: 'Blanco Nácar Dulce', hex: '#FFFFFF' },
        { id: 'negro_bunny', name: 'Negro Satinado Bunny', hex: '#18181B' }
      ],
      styleTags: ['Bunny Suit', 'Sweet Romance', 'Orejas Conejita', 'Lazos Satinados']
    }
  }
};

/**
 * Returns the list of curated compatible sub-styles for a given main style.
 */
export function getCompatibleSubStyles(mainStyle: string): SubStyleOption[] {
  const specificSynergies = STYLE_SYNERGY_MATRIX[mainStyle] || {};
  const curatedKeys = Object.keys(specificSynergies);

  const curatedOptions: SubStyleOption[] = curatedKeys.map(subKey => {
    const data = specificSynergies[subKey];
    return {
      id: subKey,
      name: subKey,
      ...data
    };
  });

  // Also include remaining styles with generic auto-generated fusion
  VISUAL_STYLES.forEach(otherStyle => {
    if (otherStyle !== mainStyle && !curatedKeys.includes(otherStyle)) {
      curatedOptions.push({
        id: otherStyle,
        name: otherStyle,
        fusedTitle: `${mainStyle} con matices ${otherStyle}`,
        synergyDescription: `Combinación estética que toma la estructura base de ${mainStyle} enriquecida con acentos y texturas de ${otherStyle}.`,
        suggestedMaterials: ['MAT04 - Seda', 'MAT07 - Cuero', 'MAT01 - Algodón'],
        suggestedFinishes: ['FIN02 - Satinado', 'FIN01 - Mate'],
        colorAccents: [
          { id: 'primario', name: 'Acento Principal', hex: '#C9A050' },
          { id: 'secundario', name: 'Acento Secundario', hex: '#1A1C22' }
        ],
        styleTags: ['Fusión Armónica', 'Híbrido']
      });
    }
  });

  return curatedOptions;
}

/**
 * Computes full style fusion object given main and optional sub-style.
 */
export function computeStyleFusion(mainStyle: string, subStyle?: string): StyleFusionResult {
  if (!subStyle || subStyle === 'Puro' || subStyle === 'Ninguno' || subStyle === mainStyle) {
    return {
      mainStyle,
      fusedTitle: `${mainStyle} Puro`,
      description: `Estética ${mainStyle} tradicional sin moduladores secundarios añadidos.`,
      materials: ['MAT04 - Seda', 'MAT07 - Cuero', 'MAT01 - Algodón'],
      finishes: ['FIN02 - Satinado', 'FIN01 - Mate'],
      colorPalette: [
        { id: 'oro', name: 'Dorado Canónico', hex: '#C9A050' },
        { id: 'oscuro', name: 'Base Oscura', hex: '#15171C' }
      ],
      isPure: true
    };
  }

  const specific = STYLE_SYNERGY_MATRIX[mainStyle]?.[subStyle];
  if (specific) {
    return {
      mainStyle,
      subStyle,
      fusedTitle: specific.fusedTitle,
      description: specific.synergyDescription,
      materials: specific.suggestedMaterials,
      finishes: specific.suggestedFinishes,
      colorPalette: specific.colorAccents,
      isPure: false
    };
  }

  return {
    mainStyle,
    subStyle,
    fusedTitle: `${mainStyle} + ${subStyle}`,
    description: `Fusión de la base de ${mainStyle} con toques estilísticos y detalles de ${subStyle}.`,
    materials: ['MAT04 - Seda', 'MAT07 - Cuero'],
    finishes: ['FIN02 - Satinado', 'FIN01 - Mate'],
    colorPalette: [
      { id: 'color_fusion_1', name: 'Color Primario Fusión', hex: '#C9A050' },
      { id: 'color_fusion_2', name: 'Color Secundario Fusión', hex: '#1E293B' }
    ],
    isPure: false
  };
}

// ============================================================================
// 2. SUB-ROLES COMPATIBLES & ROLES HÍBRIDOS (MODIFICADORES DE ROL)
// ============================================================================

export interface SubRoleOption {
  id: string;
  name: string;
  hybridTitle: string;
  synergyDescription: string;
  recommendedWeapons: string[];
  recommendedArmors: string[];
  signatureItems: string[];
  archetypeModifier?: string;
  synergyTags: string[];
}

export interface RoleHybridResult {
  mainRole: string;
  subRole?: string;
  hybridTitle: string;
  description: string;
  primaryCategory: string;
  combinedWeapons: string[];
  combinedPieces: string[];
  signatureItems: string[];
  isPure: boolean;
}

// Curated hybrid titles and descriptions for role combinations
export const HYBRID_ROLE_MATRIX: Record<string, Record<string, Omit<SubRoleOption, 'id' | 'name'>>> = {
  // Nobleza / Princesa / Aristocracia
  'Noble': {
    'B1 Berserker': {
      hybridTitle: 'Noble en Furia / Aristócrata Berserker',
      synergyDescription: 'Noble de alta cuna que desciende al frenesí del combate salvaje. Viste ropajes aristocráticos de seda reforzados con pieles nobles, empuñando armas pesadas con gracia sanguinaria.',
      recommendedWeapons: ['W8 Hacha guerra', 'W3 Espada larga / Mandoble', 'W13 Látigo'],
      recommendedArmors: ['P2.2 Coraza de Placas', 'P1.2 Corona Imperial / Tiara Nobiliaria', 'P3.4 Manto Pesado de Pieles Nórdico'],
      signatureItems: ['Sello de linaje con muescas de batalla', 'Tiara noble mellada', 'Frascos de furia destilada'],
      synergyTags: ['Noble Salvaje', 'Furia de Sangre Azul', 'Elegancia Brutal']
    },
    'B2 Caballero de Placas': {
      hybridTitle: 'Noble Caballero / Señor/a de Placas',
      synergyDescription: 'Aristócrata de armas que lidera en primera línea con armadura de acero pulido y blasones cincelados en oro, uniendo autoridad feudal y maestría marcial.',
      recommendedWeapons: ['W1 Espada recta', 'W10 Alabarda', 'W12 Estoque / Ropera'],
      recommendedArmors: ['P2.2 Coraza de Placas', 'P1.2 Corona Imperial / Tiara Nobiliaria', 'P3.3 Espaldares Blindados con Hombreras de Rango'],
      signatureItems: ['Estandarte heráldico de guerra', 'Sello nobiliario de mando', 'Guantelete de juramento'],
      synergyTags: ['Liderazgo Feudal', 'Honor Marcial', 'Placas Heráldicas']
    },
    'F6 Caballero Errante': {
      hybridTitle: 'Noble Peregrino / Justiciero de Linaje',
      synergyDescription: 'Noble que recorre los caminos de incógnito protegiendo a los indefensos, combinando prendas de viaje de calidad con un estoque de familia oculto.',
      recommendedWeapons: ['W12 Estoque / Ropera', 'W1 Espada recta', 'W4 Espada corta'],
      recommendedArmors: ['P2.4 Jubón de Duelista Acolchado', 'P3.2 Capa Corta de Duelista al Hombro', 'P1.2 Corona Imperial / Tiara Nobiliaria'],
      signatureItems: ['Medallón de identidad oculta', 'Diario de viaje nobiliario', 'Salvaconducto con sello de lacre'],
      synergyTags: ['Incógnito', 'Honor del Camino', 'Justicia Nobiliaria']
    },
    'C1 Hechicero Clásico': {
      hybridTitle: 'Noble Arcano / Archimago de Sangre Azul',
      synergyDescription: 'Aristócrata instruido en las más altas escuelas arcanas imperiales, combinando túnicas de terciopelo con grimorios de herencia dinástica.',
      recommendedWeapons: ['W20 Bastón / Catalizador', 'W12 Estoque / Ropera'],
      recommendedArmors: ['P2.5 Toga Ceremonial de la Alta Corte', 'P1.6 Diadema Arcana con Gema Focal'],
      signatureItems: ['Grimorio encuadernado en terciopelo y oro', 'Anillo catalizador de dinastía'],
      synergyTags: ['Magia Aristocrática', 'Erudición de Corte', 'Linaje Arcano']
    },
    'G8 Asesino de Alquiler': {
      hybridTitle: 'Noble de la Sombra / Aristócrata Venenista',
      synergyDescription: 'Figura cortesana que resuelve disputas de poder mediante venenos en copas de cristal, abanicos afilados y estiletes ocultos en las mangas de terciopelo.',
      recommendedWeapons: ['W6 Daga', 'W12 Estoque / Ropera', 'W22 Arma arrojadiza'],
      recommendedArmors: ['P2.5 Toga Ceremonial de la Alta Corte', 'P1.2 Corona Imperial / Tiara Nobiliaria', 'P4.6 Muñequeras de Esgrima Reforzadas'],
      signatureItems: ['Frasco de veneno disimulado en anillo', 'Abanico con varillas de acero afiladas', 'Lista de rivales de la corte'],
      synergyTags: ['Intriga Cortesana', 'Veneno de Seda', 'Duelo Silencioso']
    }
  },
  'F1 Aristócrata de Corte': {
    'B1 Berserker': {
      hybridTitle: 'Princesa Bárbara / Noble Berserker',
      synergyDescription: 'Noble de alta alcurnia que desciende al frenesí del combate salvaje. Viste ropajes aristocráticos rasgados reforzados con pieles de bestia, empuñando armas pesadas con gracia sanguinaria.',
      recommendedWeapons: ['W8 Hacha guerra', 'W3 Espada larga / Mandoble', 'W13 Látigo'],
      recommendedArmors: ['P2.2 Coraza de Placas', 'P1.2 Corona Imperial / Tiara Nobiliaria', 'P3.4 Manto Pesado de Pieles Nórdico'],
      signatureItems: ['Sello de linaje bárbaro ensangrentado', 'Tiara real mellada en batalla', 'Frascos de furia destilada'],
      synergyTags: ['Noble Salvaje', 'Furia Regia', 'Contraste Elegante-Brutal']
    },
    'B2 Caballero de Placas': {
      hybridTitle: 'Princesa Caballero / Dama de Placas',
      synergyDescription: 'Miembro de la realeza que comanda el frente de batalla blindada en acero pulido con filigranas de oro, uniendo la autoridad política con la maestría marcial inquebrantable.',
      recommendedWeapons: ['W1 Espada recta', 'W10 Alabarda', 'W12 Estoque / Ropera'],
      recommendedArmors: ['P2.2 Coraza de Placas', 'P1.2 Corona Imperial / Tiara Nobiliaria', 'P3.3 Espaldares Blindados con Hombreras de Rango'],
      signatureItems: ['Estandarte dinástico de guerra', 'Sello real de mando', 'Guantelete de juramento'],
      synergyTags: ['Liderazgo Regio', 'Honor Marcial', 'Placas de Oro']
    },
    'F6 Caballero Errante': {
      hybridTitle: 'Princesa Peregrina / Doncella del Camino',
      synergyDescription: 'Noble que ha renunciado temporalmente al trono para viajar de incógnito impartiendo justicia, mezclando ropas finas de viaje con una espada de linaje oculta.',
      recommendedWeapons: ['W12 Estoque / Ropera', 'W1 Espada recta', 'W4 Espada corta'],
      recommendedArmors: ['P2.4 Jubón de Duelista Acolchado', 'P3.2 Capa Corta de Duelista al Hombro', 'P1.2 Corona Imperial / Tiara Nobiliaria'],
      signatureItems: ['Medallón de identidad oculta', 'Diario de viaje diplomático', 'Salvaconducto real'],
      synergyTags: ['Incógnito', 'Justicia Nobiliaria', 'Aventura']
    },
    'C3 Nigromante': {
      hybridTitle: 'Aristócrata de la Cripta / Reina de las Sombras',
      synergyDescription: 'Gobernante imperial versada en las artes prohibidas de la no-muerte. Utiliza espectros y sirvientes cadavéricos como corte personal y diplomáticos forzados.',
      recommendedWeapons: ['W20 Bastón / Catalizador', 'W6 Daga', 'W12 Estoque / Ropera'],
      recommendedArmors: ['P2.5 Toga Ceremonial de la Alta Corte', 'P1.2 Corona Imperial / Tiara Nobiliaria', 'P3.1 Manto Mágico Bordado de Seda Arcana'],
      signatureItems: ['Cáliz de almas cautivas', 'Grimorio nobiliario encadenado', 'Anillo de sello nigromántico'],
      synergyTags: ['Corte Espectral', 'Nigromancia Política', 'Aristocracia Siniestra']
    },
    'G8 Asesino de Alquiler': {
      hybridTitle: 'Princesa Venenista / Dama Letal de la Corte',
      synergyDescription: 'Heredera noble maestra en el espionaje cortesano, puñales ocultos en abanicos y venenos indetectables servidos en copas de plata.',
      recommendedWeapons: ['W6 Daga', 'W12 Estoque / Ropera', 'W22 Arma arrojadiza'],
      recommendedArmors: ['P2.5 Toga Ceremonial de la Alta Corte', 'P1.2 Corona Imperial / Tiara Nobiliaria', 'P4.6 Muñequeras de Esgrima Reforzadas'],
      signatureItems: ['Frasco de veneno en anillo secreto', 'Abanico con filo de acero', 'Lista de objetivos políticos'],
      synergyTags: ['Veneno Cortesano', 'Daga Oculta', 'Intriga Letal']
    }
  },

  // F8 Princesa / Príncipe
  'F8 Princesa / Príncipe': {
    'B1 Berserker': {
      hybridTitle: 'Príncipe / Princesa Bárbaro/a de Guerra Salvaje',
      synergyDescription: 'Heredero/a al trono templado/a en el frenesí y la brutalidad del frente de batalla, combinando corona regia con pieles de depredador y hacha pesada.',
      recommendedWeapons: ['W8 Hacha guerra', 'W3 Espada larga / Mandoble'],
      recommendedArmors: ['P2.2 Coraza de Placas', 'P1.2 Corona Imperial / Tiara Nobiliaria'],
      signatureItems: ['Corona de hierro y colmillos', 'Hacha de herencia bárbara'],
      synergyTags: ['Furia Real', 'Conquistador']
    },
    'B2 Caballero de Placas': {
      hybridTitle: 'Príncipe / Princesa Caballero / Comandante de la Corona',
      synergyDescription: 'Comandante real blindado/a en placas completas de acero y oro que lidera la vanguardia de las legiones imperiales.',
      recommendedWeapons: ['W1 Espada recta', 'W9 Lanza'],
      recommendedArmors: ['P2.2 Coraza de Placas', 'P1.3 Yelmo Abierto / Celada de Caballero'],
      signatureItems: ['Sello de mando de la Legión', 'Capa heráldica de gala'],
      synergyTags: ['Vanguardia', 'Honor']
    },
    'C1 Hechicero Clásico': {
      hybridTitle: 'Príncipe / Princesa Arcano/a / Soberano/a de la Magia',
      synergyDescription: 'Heredero/a versado/a en la alta hechicería que canaliza la magia imperial a través de su espada-catalizador.',
      recommendedWeapons: ['W20 Bastón / Catalizador', 'W12 Estoque / Ropera'],
      recommendedArmors: ['P2.5 Toga Ceremonial de la Alta Corte', 'P1.6 Diadema Arcana con Gema Focal'],
      signatureItems: ['Grimorio real de dinastía', 'Cetro de mando arcano'],
      synergyTags: ['Magia Real', 'Erudición']
    }
  },

  // F9 Rey / Emperador
  'F9 Rey / Emperador': {
    'B1 Berserker': {
      hybridTitle: 'Rey Conquistador / Señor de la Guerra Supremo',
      synergyDescription: 'Monarca colosal curtido en mil batallas sangrientas que empuña la maza imperial junto a una corona enjoyada bañada en oro.',
      recommendedWeapons: ['W8 Hacha guerra', 'W3 Espada larga / Mandoble'],
      recommendedArmors: ['P2.2 Coraza de Placas', 'P1.1 Gran Corona Imperial'],
      signatureItems: ['Gran Cetro de Guerra', 'Manto de Piel de Dragón Imperial'],
      synergyTags: ['Soberanía Marcial', 'Terror Bélico']
    },
    'B2 Caballero de Placas': {
      hybridTitle: 'Emperador Santo / Gran Mariscal del Trono',
      synergyDescription: 'Soberano absoluto enfundado en armadura de oro batido bendecida por el sumo pontífice, liderando la gran cruzada.',
      recommendedWeapons: ['W1 Espada recta', 'W9 Lanza'],
      recommendedArmors: ['P2.4 Coraza Ceremonial de Oro Batido', 'P1.1 Corona Imperial de Oro'],
      signatureItems: ['Orbe Sagrado del Imperio', 'Estandarte Dorado de la Victoria'],
      synergyTags: ['Imperio', 'Cruzada']
    },
    'C1 Hechicero Clásico': {
      hybridTitle: 'Emperador Archimago / Soberano del Nexo Arcano',
      synergyDescription: 'Rey hechicero absoluto cuyos decretos manipulan las leyes del tejido de la realidad y el destino.',
      recommendedWeapons: ['W20 Bastón / Catalizador', 'W12 Estoque / Ropera'],
      recommendedArmors: ['P2.1 Jubón de Terciopelo Púrpura con Hilo de Oro', 'P1.1 Corona Imperial'],
      signatureItems: ['Tomo Supremo de Decretos Arcanos', 'Cetro Orbe de Cristal de Vacío'],
      synergyTags: ['Soberanía Arcana', 'Decreto Mágico']
    }
  },

  // F8 Príncipe Heredero
  'F8 Príncipe Heredero': {
    'B1 Berserker': {
      hybridTitle: 'Príncipe Bárbaro / Señor de la Guerra Salvaje',
      synergyDescription: 'Heredero al trono templado en el frenesí y la brutalidad del frente de batalla, combinando corona regia con pieles de depredador y hacha pesada.',
      recommendedWeapons: ['W8 Hacha guerra', 'W3 Espada larga / Mandoble'],
      recommendedArmors: ['P2.2 Coraza de Placas', 'P1.2 Corona Imperial / Tiara Nobiliaria'],
      signatureItems: ['Corona de hierro y colmillos', 'Hacha de herencia bárbara'],
      synergyTags: ['Furia Real', 'Conquistador']
    },
    'B2 Caballero de Placas': {
      hybridTitle: 'Príncipe Caballero / Comandante de la Corona',
      synergyDescription: 'Comandante real blindado en placas completas de acero y oro que lidera a la vanguardia de las legiones imperiales.',
      recommendedWeapons: ['W1 Espada recta', 'W9 Lanza'],
      recommendedArmors: ['P2.2 Coraza de Placas', 'P1.3 Yelmo Abierto / Celada de Caballero'],
      signatureItems: ['Sello de mando de la Legión', 'Capa heráldica de gala'],
      synergyTags: ['Vanguardia', 'Honor']
    },
    'C1 Hechicero Clásico': {
      hybridTitle: 'Príncipe Arcano / Soberano de la Magia',
      synergyDescription: 'Heredero versado en la alta hechicería que canaliza la magia imperial a través de su espada-catalizador.',
      recommendedWeapons: ['W20 Bastón / Catalizador', 'W12 Estoque / Ropera'],
      recommendedArmors: ['P2.5 Toga Ceremonial de la Alta Corte', 'P1.6 Diadema Arcana con Gema Focal'],
      signatureItems: ['Grimorio real de dinastía', 'Cetro de mando arcano'],
      synergyTags: ['Magia Real', 'Erudición']
    }
  },

  // Maid de Mansión
  'A1 Maid de Mansión': {
    'G8 Asesino de Alquiler': {
      hybridTitle: 'Maid Asesina / Doncella de las Sombras',
      synergyDescription: 'Sirvienta impecable con cofia y delantal almidonado que oculta dagas arrojadizas y alambres de garrote bajo sus faldas para eliminar intrusos sin una gota de sangre en el suelo.',
      recommendedWeapons: ['W6 Daga', 'W22 Arma arrojadiza', 'W13 Látigo'],
      recommendedArmors: ['P2.7 Mandil Reforzado de Herrero / Alquimista', 'P1.1 Capucha de Infiltrador / Sigilo'],
      signatureItems: ['Bandeja de plata arrojadiza', 'Set de cuchillos de servicio afilados como navajas', 'Alambre de estrangulamiento de seda'],
      synergyTags: ['Sigilo Pulcro', 'Daga bajo el Delantal', 'Letal y Educada']
    },
    'G5 Sombra': {
      hybridTitle: 'Maid Infiltradora / Ojo del Amo',
      synergyDescription: 'Especialista en recopilación de información y sigilo que limpia la mansión mientras escucha todas las conversaciones y neutraliza amenazas silenciosamente.',
      recommendedWeapons: ['W6 Daga', 'W16 Ballesta'],
      recommendedArmors: ['P1.1 Capucha de Infiltrador / Sigilo', 'P4.2 Brazales de Cuero Tachonado'],
      signatureItems: ['Gafas de visión nocturna', 'Diario de secretos de la casa'],
      synergyTags: ['Infiltración', 'Oído Fino', 'Discreción']
    },
    'B1 Berserker': {
      hybridTitle: 'Maid Berserker / Doncella Feroz',
      synergyDescription: 'Doncella de modales gentiles que al romperse su compostura (o al ensuciarse el suelo) desata una fuerza hercúlea descomunal empuñando fregonas reforzadas de acero o hachas de batalla.',
      recommendedWeapons: ['W8 Hacha guerra', 'W11 Maza / Martillo', 'W3 Espada larga / Mandoble'],
      recommendedArmors: ['P2.7 Mandil Reforzado de Herrero / Alquimista', 'P4.4 Manoplas de Combate Pesadas'],
      signatureItems: ['Fregona con núcleo de acero macizo', 'Cofia manchada de furia', 'Campanilla de servicio doblada por la fuerza'],
      synergyTags: ['Fuerza Monstruosa', 'Contraste Tierno-Brutal', 'Protección del Amo']
    },
    'C4 Mago de Batalla': {
      hybridTitle: 'Maid Arcana / Doncella de Combate Mágico',
      synergyDescription: 'Sirvienta que utiliza escudos mágicos y proyectiles de energía para proteger la mansión y ejecutar tareas domésticas con magia cinética.',
      recommendedWeapons: ['W20 Bastón / Catalizador', 'W4 Espada corta'],
      recommendedArmors: ['P1.6 Diadema Arcana con Gema Focal', 'P2.1 Hábito / Túnica Arcana Rúnica'],
      signatureItems: ['Escoba encantada voladora', 'Plumero de viento elemental'],
      synergyTags: ['Magia Doméstica', 'Escudos de Maná', 'Elegancia']
    },
    'B3 Duelista': {
      hybridTitle: 'Maid Guardaespaldas / Doncella de Esgrima',
      synergyDescription: 'Sirvienta personal y escolta de esgrima que defiende a su señor con un estoque oculto en el bastón de servicio o bajo el delantal.',
      recommendedWeapons: ['W12 Estoque / Ropera', 'W4 Espada corta'],
      recommendedArmors: ['P2.4 Jubón de Duelista Acolchado', 'P4.6 Muñequeras de Esgrima Reforzadas'],
      signatureItems: ['Estoque con guarnición de plata', 'Reloj de bolsillo de servicio'],
      synergyTags: ['Esgrima', 'Lealtad Absoluta', 'Escolta']
    }
  },

  // E3 Paladín
  'E3 Paladín': {
    'C3 Nigromante': {
      hybridTitle: 'Paladín Caído / Caballero del Ocaso',
      synergyDescription: 'Antiguo guerrero de la luz sagrada que ha abrazado las artes oscuras para lograr una justicia implacable, blandiendo llamas negras y levantando a los caídos como cruzados espectrales.',
      recommendedWeapons: ['W3 Espada larga / Mandoble', 'W20 Bastón / Catalizador', 'W11 Maza / Martillo'],
      recommendedArmors: ['P2.2 Coraza de Placas', 'P3.3 Espaldares Blindados con Hombreras de Rango', 'P1.3 Yelmo Abierto / Celada de Caballero'],
      signatureItems: ['Símbolo sagrado profanado / agrietado', 'Relicario de cenizas benditas y almas', 'Tomo de oraciones del ocaso'],
      synergyTags: ['Luz Caída', 'Llamas Negras', 'Cruzada Espectral']
    },
    'B1 Berserker': {
      hybridTitle: 'Cruzado de la Furia / Vengador Sagrado',
      synergyDescription: 'Paladín que canaliza el celo religioso en una ira santa destructiva, destrozando las líneas enemigas sin retroceder jamás.',
      recommendedWeapons: ['W8 Hacha guerra', 'W11 Maza / Martillo', 'W3 Espada larga / Mandoble'],
      recommendedArmors: ['P2.2 Coraza de Placas', 'P4.1 Guanteletes de Placas Articulados'],
      signatureItems: ['Cinto de flagelación sagrado', 'Inciensario de combate'],
      synergyTags: ['Celo Sangriento', 'Furia Santa', 'Inquebrantable']
    },
    'D5 Tirador de Élite': {
      hybridTitle: 'Inquisidor Balístico / Cazador Sagrado',
      synergyDescription: 'Guerrero de la fe que purga el mal a distancia mediante ballestas benditas y armas de fuego cargadas con proyectiles de plata bendecida.',
      recommendedWeapons: ['W16 Ballesta', 'W18 Arma fuego antigua', 'W19 Arma fuego moderna'],
      recommendedArmors: ['P2.8 Gambesón Táctico Reforzado', 'P3.2 Capa Corta de Duelista al Hombro'],
      signatureItems: ['Balas de plata con runas benditas', 'Agua bendita concentrada'],
      synergyTags: ['Fuego Purificador', 'Puntería Santa', 'Caza de Herejes']
    }
  },

  // C5 Alquimista
  'C5 Alquimista': {
    'D5 Tirador de Élite': {
      hybridTitle: 'Pistolero Alquímico / Artificiero Balístico',
      synergyDescription: 'Científico de combate que dispara munición química elemental (ácido, fuego griego, congelación criogénica y niebla cegadora) con armas personalizadas.',
      recommendedWeapons: ['W18 Arma fuego antigua', 'W19 Arma fuego moderna', 'W17 Pistola arco'],
      recommendedArmors: ['P2.7 Mandil Reforzado de Herrero / Alquimista', 'P1.7 Monóculo de Artificiero / Escáner Óptico', 'P5.5 Cinturón Alquímico con Frascos y Viales'],
      signatureItems: ['Cinturón con 12 viales de mezcla rápida', 'Gafas de protección química', 'Matraz dosificador balístico'],
      synergyTags: ['Balística Química', 'Fuego Griego', 'Frascos Reactivos']
    },
    'B1 Berserker': {
      hybridTitle: 'Mutágeno Berserker / Químico Monstruoso',
      synergyDescription: 'Alquimista que ingiere sus propios cócteles mutagénicos para transformar su cuerpo en una bestia de masa muscular y resistencia sobrehumana en combate.',
      recommendedWeapons: ['W21 Guantelete armado', 'W11 Maza / Martillo'],
      recommendedArmors: ['P2.7 Mandil Reforzado de Herrero / Alquimista', 'P4.4 Manoplas de Combate Pesadas'],
      signatureItems: ['Inyector automático en el brazo', 'Viales de mutágeno inestable'],
      synergyTags: ['Mutación', 'Fuerza Química', 'Científico Salvaje']
    },
    'C3 Nigromante': {
      hybridTitle: 'Biotécnico Necrótico / Alquimista de Plaga',
      synergyDescription: 'Investigador que combina la química orgánica con la reanimación cadavérica para crear constructos de carne y virus alquímicos.',
      recommendedWeapons: ['W20 Bastón / Catalizador', 'W6 Daga'],
      recommendedArmors: ['P2.7 Mandil Reforzado de Herrero / Alquimista', 'P1.5 Máscara Táctica / Respirador Cyberpunk'],
      signatureItems: ['Frascos de miasma necrótico', 'Escalpelo alquímico'],
      synergyTags: ['Biotecnología', 'Constructos', 'Plaga']
    }
  },

  // Ent5 Ídolo / Cantante
  'Ent5 Ídolo / Cantante': {
    'C1 Hechicero Clásico': {
      hybridTitle: 'Mahou Shoujo / Idol Mágica de Batalla',
      synergyDescription: 'Artista y estrella de escenario que canaliza la hechicería a través de su voz y micrófono-varita, transformando los conciertos en batallas deslumbrantes de luz y maná.',
      recommendedWeapons: ['W20 Bastón / Catalizador', 'W22 Arma arrojadiza'],
      recommendedArmors: ['P1.6 Diadema Arcana con Gema Focal', 'P3.1 Manto Mágico Bordado de Seda Arcana'],
      signatureItems: ['Micrófono varita estelar', 'Luces de escenario flotantes', 'Diadema con gema luminosa'],
      synergyTags: ['Canto Mágico', 'Mahou Shoujo', 'Luces de Escenario']
    },
    'G8 Asesino de Alquiler': {
      hybridTitle: 'Idol Letal / Diva Mortal Encubierta',
      synergyDescription: 'Superestrella admirada por miles que utiliza sus giras internacionales como tapadera perfecta para misiones de asesinato de alto rango.',
      recommendedWeapons: ['W6 Daga', 'W17 Pistola arco', 'W22 Arma arrojadiza'],
      recommendedArmors: ['P4.6 Muñequeras de Esgrima Reforzadas', 'P1.5 Máscara Táctica / Respirador Cyberpunk'],
      signatureItems: ['Micrófono con cuchilla oculta', 'Gafas de sol con HUD de objetivos'],
      synergyTags: ['Doble Vida', 'Fama y Sombras', 'Asesina Glamurosa']
    }
  },

  // B5 Samurái Pesado
  'B5 Samurái Pesado': {
    'G1 Sicario de Gremio': {
      hybridTitle: 'Ronin Renegado / Asesino del Shogunato',
      synergyDescription: 'Guerrero samurái sin amo que ha dejado el código bushido por el pragmatismo del asesinato a sueldo, combinando el desenvaine iaido con técnicas ninjutsu oscuras.',
      recommendedWeapons: ['W5 Katana', 'W6 Daga', 'W22 Arma arrojadiza'],
      recommendedArmors: ['P2.2 Coraza de Placas', 'P1.1 Capucha de Infiltrador / Sigilo', 'P5.6 Faldón Táctico Blindado / Jinbaori'],
      signatureItems: ['Máscara menpo de oni negro', 'Kopis de veneno para la hoja', 'Monedas de sangre de contrato'],
      synergyTags: ['Ronin', 'Iaido Sombrío', 'Sin Amo']
    },
    'C2 Elementalista': {
      hybridTitle: 'Kenshi Elemental / Samurái de la Tempestad',
      synergyDescription: 'Maestro de la espada que imbuye su katana con relámpagos, fuego o viento cortante para ejecutar tajos que parten el aire a distancia.',
      recommendedWeapons: ['W5 Katana', 'W20 Bastón / Catalizador'],
      recommendedArmors: ['P2.2 Coraza de Placas', 'P3.1 Manto Mágico Bordado de Seda Arcana'],
      signatureItems: ['Vaina con runas de viento y rayo', 'Fajín de seda elemental'],
      synergyTags: ['Corte de Viento', 'Katana Eléctrica', 'Maestro del Acero']
    }
  },

  // A7 Erudito
  'A7 Erudito': {
    'D1 Pícaro Urbano': {
      hybridTitle: 'Arqueólogo Aventurero / Saqueador de Tumbas',
      synergyDescription: 'Investigador de reliquias arcanas que explora ruinas olvidadas y esquiva trampas mortales con agilidad de pícaro y conocimiento enciclopédico de trampas y lenguas muertas.',
      recommendedWeapons: ['W13 Látigo', 'W18 Arma fuego antigua', 'W6 Daga'],
      recommendedArmors: ['P2.8 Gambesón Táctico Reforzado', 'P3.2 Capa Corta de Duelista al Hombro', 'P5.2 Cinturón de Armas con Fundas Tácticas'],
      signatureItems: ['Diario de expedición con bocetos', 'Látigo de cuero trenzado', 'Brújula arqueológica de reliquias'],
      synergyTags: ['Aventura', 'Reliquias', 'Descifrador de Trampas']
    }
  },

  // Civil Genérico
  'Civil Genérico': {
    'B1 Berserker': {
      hybridTitle: 'Miliciano Rebelde / Campesino en Furia',
      synergyDescription: 'Civil común forzado a levantarse en armas tras perderlo todo, luchando con una ferocidad incontrolable usando herramientas de labranza adaptadas.',
      recommendedWeapons: ['W8 Hacha guerra', 'W11 Maza / Martillo', 'W9 Lanza'],
      recommendedArmors: ['P2.8 Gambesón Táctico Reforzado', 'P4.2 Brazales de Cuero Tachonado'],
      signatureItems: ['Horca o hacha de leñador reforzada', 'Pañuelo de rebelión'],
      synergyTags: ['Rebelde', 'Superviviente', 'Pueblo en Armas']
    },
    'D1 Pícaro Urbano': {
      hybridTitle: 'Bribón Callejero / Buscavidas',
      synergyDescription: 'Habitante común de los barrios bajos que sobrevive mediante el hurto menor, el contrabando y un conocimiento profundo de los callejones.',
      recommendedWeapons: ['W6 Daga', 'W4 Espada corta'],
      recommendedArmors: ['P2.8 Gambesón Táctico Reforzado', 'P1.1 Capucha de Infiltrador / Sigilo'],
      signatureItems: ['Juego de ganzúas casero', 'Bolsa con monedas falsas'],
      synergyTags: ['Callejero', 'Supervivencia Urbana', 'Astuto']
    }
  }
};

/**
 * Returns the list of curated compatible sub-roles for a given canonical main role.
 */
export function getCompatibleSubRoles(mainRole: string): SubRoleOption[] {
  const specificHybrids = HYBRID_ROLE_MATRIX[mainRole] || {};
  const curatedKeys = Object.keys(specificHybrids);

  const curatedOptions: SubRoleOption[] = curatedKeys.map(subKey => {
    const data = specificHybrids[subKey];
    return {
      id: subKey,
      name: subKey,
      ...data
    };
  });

  // Flatten all available canonical roles to offer as general modifiers
  const allRolesFlat = ROLES_CATALOG.flatMap(cat => cat.roles);

  allRolesFlat.forEach(otherRole => {
    if (otherRole !== mainRole && !curatedKeys.includes(otherRole)) {
      // Generate clean dynamic title
      const cleanMain = mainRole.replace(/^[A-G]\d*\s*/, '').trim();
      const cleanSub = otherRole.replace(/^[A-G]\d*\s*/, '').trim();

      curatedOptions.push({
        id: otherRole,
        name: otherRole,
        hybridTitle: `${cleanMain} / Modificador ${cleanSub}`,
        synergyDescription: `Identidad híbrida que combina las responsabilidades y posición de ${cleanMain} con las habilidades y pertrechos de ${cleanSub}.`,
        recommendedWeapons: ['W1 Espada recta', 'W6 Daga'],
        recommendedArmors: ['P2.4 Jubón de Duelista Acolchado'],
        signatureItems: [`Pertrechos combinados de ${cleanMain} y ${cleanSub}`],
        synergyTags: ['Rol Híbrido', 'Multiclase']
      });
    }
  });

  return curatedOptions;
}

/**
 * Computes full role hybrid object given main role and optional sub-role.
 */
export function computeRoleHybrid(mainRole: string, subRole?: string, customTitleOverride?: string): RoleHybridResult {
  const cleanMain = mainRole.replace(/^[A-G]\d*\s*/, '').trim();

  if (!subRole || subRole === 'Puro' || subRole === 'Ninguno' || subRole === mainRole) {
    return {
      mainRole,
      hybridTitle: cleanMain,
      description: `Identidad de rol puro sin modificadores secundarios de clase o especialización.`,
      primaryCategory: 'Canónico',
      combinedWeapons: [],
      combinedPieces: [],
      signatureItems: [],
      isPure: true
    };
  }

  const cleanSub = subRole.replace(/^[A-G]\d*\s*/, '').trim();
  const specific = HYBRID_ROLE_MATRIX[mainRole]?.[subRole];

  if (specific) {
    return {
      mainRole,
      subRole,
      hybridTitle: customTitleOverride && customTitleOverride.trim() ? customTitleOverride.trim() : specific.hybridTitle,
      description: specific.synergyDescription,
      primaryCategory: 'Híbrido Específico',
      combinedWeapons: specific.recommendedWeapons,
      combinedPieces: specific.recommendedArmors,
      signatureItems: specific.signatureItems,
      isPure: false
    };
  }

  // Dynamic automatic fusion
  const dynamicTitle = customTitleOverride && customTitleOverride.trim() 
    ? customTitleOverride.trim() 
    : `${cleanMain} - ${cleanSub}`;

  return {
    mainRole,
    subRole,
    hybridTitle: dynamicTitle,
    description: `Personaje con base de ${cleanMain} modificado con entrenamiento y pertrechos de ${cleanSub}.`,
    primaryCategory: 'Híbrido Compuesto',
    combinedWeapons: ['W1 Espada recta', 'W6 Daga'],
    combinedPieces: ['P2.4 Jubón de Duelista Acolchado'],
    signatureItems: [`Equipo combinado de ${cleanMain} y ${cleanSub}`],
    isPure: false
  };
}
