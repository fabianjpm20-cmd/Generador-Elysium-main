/**
 * WARDROBE & ACCESSORY CONTEXTUAL OPTION ENGINE
 * 
 * Generates independent, context-aware configuration options for any garment,
 * armor piece, shoe, lingerie, or accessory based on:
 * 1. What it is (Item type, archetype, function)
 * 2. Where it is located on the body (Anatomy, coverage)
 * 3. What shape / silhouette it has (Cuts, structural variants)
 * 4. How it is worn and fastened (Closures, drops, straps, bands)
 * 5. Its physical finish, details, and exact detail anchor points.
 */

import { SHOE_SOLES, SHOE_HEELS } from '../data';

export interface WardrobeOptionsSuite {
  cut: string[];
  length: string[];
  sleeve: string[];
  material: string[];
  finish: string[];
  details: string[];
  variation: string[];
  layer: string[];
  location: string[];
  locationMap: Record<string, string[]>;
  pattern: string[];
  emblem: string[];
  vfx: string[];
  neckline: string[];
  gemTypes: string[];
  engravings: string[];
  sizeScales: string[];
  fitStyles: string[];
  accessoryStyles: string[];
  shoeSoles?: string[];
  shoeHeels?: string[];
}

// ----------------------------------------------------------------------------
// UNIVERSAL ACCESSORY DATA SETS (Simple, Direct & Context-Accurate)
// ----------------------------------------------------------------------------

export const ACCESSORY_MATERIALS_FINE = [
  'Oro amarillo',
  'Oro blanco',
  'Oro rosa',
  'Plata',
  'Platino',
  'Titanio',
  'Bronce',
  'Latón',
  'Acero',
  'Jade',
  'Obsidiana',
  'Nácar',
  'Madera',
  'Cristal',
  'Resina'
];

export const ACCESSORY_MATERIALS_BAGS = [
  'Cuero',
  'Lona',
  'Nylon',
  'Terciopelo',
  'Denim',
  'PVC',
  'Vinilo',
  'Seda',
  'Cota de malla'
];

export const ACCESSORY_MATERIALS_HEAD = [
  'Fieltro',
  'Paja',
  'Cuero',
  'Oro',
  'Plata',
  'Latón',
  'Terciopelo',
  'Seda',
  'Tul',
  'Madera',
  'PVC'
];

export const ACCESSORY_MATERIALS_GLOVES = [
  'Cuero',
  'Terciopelo',
  'Encaje',
  'Seda',
  'Satén',
  'Malla',
  'Tul',
  'Látex',
  'Vinilo',
  'Algodón',
  'Malla de acero'
];

export const ACCESSORY_MATERIALS_BELTS = [
  'Cuero',
  'Cadena metálica',
  'Seda',
  'Cuerda',
  'Nylon',
  'Malla de placas'
];

export const ACCESSORY_FINISHES_JEWELRY = [
  'Pulido espejo',
  'Mate satinado',
  'Martillado',
  'Envejecido',
  'Pavonado',
  'Filigrana',
  'Esmaltado',
  'Diamantado'
];

export const ACCESSORY_FINISHES_LEATHER_FABRIC = [
  'Mate',
  'Satinado',
  'Encerado',
  'Charol',
  'Desgastado',
  'Repujado',
  'Acolchado',
  'Metalizado'
];

export const ACCESSORY_GEM_TYPES_ENGINE = [
  'Sin gema',
  'Diamante',
  'Rubí',
  'Zafiro',
  'Esmeralda',
  'Amatista',
  'Ópalo',
  'Perla',
  'Piedra lunar',
  'Topacio',
  'Aguamarina',
  'Ojo de tigre',
  'Granate',
  'Obsidiana',
  'Jade'
];

export const ACCESSORY_ENGRAVINGS_ENGINE = [
  'Sin Grabado / Liso Pulido',
  'Filigrana Floral Barroca',
  'Runas Nórdicas / Arcanas',
  'Glifos Cyberpunk / Circuitos',
  'Nudos Celtas Entrelazados',
  'Relieve Heráldico / Blasón Real',
  'Patrón Geométrico Art Déco',
  'Inscripción Oculta en Latín / Élfico',
  'Motivo de Dragón / Bestia Esculpida',
  'Greca Griega Ornamental'
];

export const ACCESSORY_SIZE_SCALES_ENGINE = [
  'Mini / Discreto (Sutil y Delgado)',
  'Fino / Elegante',
  'Estándar Equilibrado',
  'Mediano / Destacado',
  'Grande / Statement (Pieza Central)',
  'Extra Grande / Escultórico y Pesado'
];

export const ACCESSORY_FIT_STYLES_ENGINE = [
  'Ceñido / Pegado a la piel',
  'Con holgura natural y cómoda',
  'Colgante / Caída libre y fluida',
  'Escalonado en cascada',
  'Envolvente de múltiples vueltas',
  'Asimétrico / Cruzado diagonal'
];

// ----------------------------------------------------------------------------
// MAIN OPTION GENERATION ENGINE
// ----------------------------------------------------------------------------

export function getWardrobeOptions(
  categoryId: string,
  itemId: string = '',
  itemName: string = '',
  currentDetail: string[] = []
): WardrobeOptionsSuite {
  const nameLow = (itemName || '').toLowerCase();
  const idLow = (itemId || '').toLowerCase();

  // Primary archetype detection
  const isArmor = nameLow.includes('armadura') || nameLow.includes('coraza') || nameLow.includes('peto') || nameLow.includes('yelmo') || nameLow.includes('hombrera') || nameLow.includes('greba') || nameLow.includes('guantelete') || nameLow.includes('cota de malla') || nameLow.includes('brigandina') || nameLow.includes('loriga') || nameLow.includes('espalder') || nameLow.includes('codal') || nameLow.includes('muslera') || nameLow.includes('gorjal') || nameLow.includes('blindaje') || nameLow.includes('placas');
  const isAcc = categoryId === 'B5';
  const isShoes = categoryId === 'B4' || nameLow.includes('bota') || nameLow.includes('botín') || nameLow.includes('zapato') || nameLow.includes('tacón') || nameLow.includes('sandalia') || nameLow.includes('zapatilla') || nameLow.includes('mocasín') || nameLow.includes('zueco') || nameLow.includes('descalzo') || nameLow.includes('sneaker');
  const isSocks = categoryId === 'B3-C' || (categoryId !== 'B3-D' && (nameLow.includes('media') || nameLow.includes('calcet') || nameLow.includes('pantimedia') || nameLow.includes('calza') || nameLow.includes('legging') || nameLow.includes('fishnet') || nameLow.includes('ligas') || nameLow.includes('vendaje')));
  const isBra = categoryId === 'B3-A' || nameLow.includes('bra') || nameLow.includes('sostén') || nameLow.includes('bralette') || nameLow.includes('balconette') || nameLow.includes('bandeau') || nameLow.includes('push-up');
  const isPanties = categoryId === 'B3-B' || nameLow.includes('panty') || nameLow.includes('panties') || nameLow.includes('tanga') || nameLow.includes('g-string') || nameLow.includes('brief') || nameLow.includes('bikini') || nameLow.includes('tap pants') || nameLow.includes('crotch');
  const isDress = categoryId === 'B0' || nameLow.includes('vestido') || nameLow.includes('jumpsuit') || nameLow.includes('bodycon') || nameLow.includes('monos') || nameLow.includes('leotardo') || nameLow.includes('unitardo') || nameLow.includes('qipao') || nameLow.includes('cheongsam') || nameLow.includes('kimono') || nameLow.includes('yukata') || nameLow.includes('túnica');
  const isJacket = (categoryId === 'B12' || categoryId === 'B12-A') || nameLow.includes('chaqueta') || nameLow.includes('abrigo') || nameLow.includes('blazer') || nameLow.includes('cardigan') || nameLow.includes('gabardina') || nameLow.includes('parka') || nameLow.includes('topcoat') || nameLow.includes('tailcoat') || nameLow.includes('bolero') || nameLow.includes('bomber') || nameLow.includes('biker') || nameLow.includes('trench') || nameLow.includes('capa') || nameLow.includes('pelerina') || nameLow.includes('sobretodo') || nameLow.includes('capota') || nameLow.includes('levita') || nameLow.includes('frac') || nameLow.includes('chaleco') || nameLow.includes('waistcoat') || nameLow.includes('vest');
  const isVest = isJacket && (nameLow.includes('chaleco') || nameLow.includes('waistcoat') || nameLow.includes('vest'));
  const isHoodie = nameLow.includes('hoodie') || nameLow.includes('sudadera') || nameLow.includes('capucha') || nameLow.includes('capota');
  const isBottom = (categoryId === 'B2') || (!isDress && (nameLow.includes('pantalón') || nameLow.includes('jeans') || nameLow.includes('falda') || nameLow.includes('shorts') || nameLow.includes('bermuda') || nameLow.includes('hakama') || nameLow.includes('tutú') || nameLow.includes('kilt') || nameLow.includes('faldón') || nameLow.includes('culotte') || nameLow.includes('jogger')));
  const isTop = (categoryId === 'B1' || categoryId === 'B3-D') || (!isDress && !isJacket && !isBottom && !isBra && !isPanties && !isSocks && !isShoes && !isAcc);
  const isSarashi = nameLow.includes('sarashi') || (categoryId === 'B3-D' && (nameLow.includes('venda') || nameLow.includes('wrap')));

  // Sub-Accessory classifications with independent logic
  const isRing = isAcc && (nameLow.includes('anillo') || nameLow.includes('sortija') || nameLow.includes('ban zhi') || nameLow.includes('alianza') || nameLow.includes('garra de anillo') || nameLow.includes('sello heráldico'));
  const isBag = isAcc && (nameLow.includes('bolso') || nameLow.includes('mochila') || nameLow.includes('bandolera') || nameLow.includes('clutch') || nameLow.includes('alforja') || nameLow.includes('riñonera') || nameLow.includes('cartera') || nameLow.includes('morral') || nameLow.includes('pouch') || nameLow.includes('maletín') || nameLow.includes('frasco') || nameLow.includes('vial') || nameLow.includes('abanico') || nameLow.includes('paraguas') || nameLow.includes('sombrilla') || nameLow.includes('reloj de bolsillo') || nameLow.includes('peluche') || nameLow.includes('muñeco'));
  const isEarring = isAcc && (nameLow.includes('arete') || nameLow.includes('pendiente') || nameLow.includes('ear cuff') || nameLow.includes('aro de oreja') || nameLow.includes('hélix') || nameLow.includes('expansor') || nameLow.includes('broquel') || nameLow.includes('candelabro'));
  const isNeckAccessory = isAcc && (nameLow.includes('collar') || nameLow.includes('gargantilla') || nameLow.includes('choker') || nameLow.includes('corbata') || nameLow.includes('moño') || nameLow.includes('pañuelo') || nameLow.includes('bufanda') || nameLow.includes('colgante') || nameLow.includes('perlas') || nameLow.includes('ascot') || nameLow.includes('gorguera') || nameLow.includes('pajarita') || nameLow.includes('torq') || nameLow.includes('pectoral') || nameLow.includes('regalia'));
  const isHeadAccessory = isAcc && (nameLow.includes('sombrero') || nameLow.includes('gorra') || nameLow.includes('boina') || nameLow.includes('diadema') || nameLow.includes('tocado') || nameLow.includes('capucha') || nameLow.includes('casco') || nameLow.includes('corona') || nameLow.includes('tiara') || nameLow.includes('cinta para el pelo') || nameLow.includes('pasador') || nameLow.includes('headset') || nameLow.includes('cuerno') || nameLow.includes('velo') || nameLow.includes('kanzashi') || nameLow.includes('beanie') || nameLow.includes('eboshi') || nameLow.includes('douli') || nameLow.includes('kasa') || nameLow.includes('horquilla') || nameLow.includes('clip') || nameLow.includes('barrette'));
  const isFaceAccessory = isAcc && (nameLow.includes('gafas') || nameLow.includes('monóculo') || nameLow.includes('parche') || nameLow.includes('máscara') || nameLow.includes('antifaz') || nameLow.includes('visor') || nameLow.includes('piercing') || nameLow.includes('septum') || nameLow.includes('nostril') || nameLow.includes('labret') || nameLow.includes('ceja') || nameLow.includes('labio'));
  const isGloveAccessory = isAcc && (nameLow.includes('guante') || nameLow.includes('miton') || nameLow.includes('manopla') || nameLow.includes('brazalet') || nameLow.includes('pulsera') || nameLow.includes('muñequera') || nameLow.includes('manga desprendida') || nameLow.includes('grillete') || nameLow.includes('garra') || nameLow.includes('kote') || nameLow.includes('biguan') || nameLow.includes('manguito'));
  const isBeltAccessory = isAcc && (nameLow.includes('cinturón') || nameLow.includes('arnés') || nameLow.includes('faja') || nameLow.includes('cadena para pantalón') || nameLow.includes('cadena para bolsillo') || nameLow.includes('ligas') || nameLow.includes('garters') || nameLow.includes('obi') || nameLow.includes('tahalí') || nameLow.includes('cadena de cadera') || nameLow.includes('body chain') || nameLow.includes('charretera') || nameLow.includes('bandolera de munición') || nameLow.includes('kuadai'));
  const isMysticAccessory = isAcc && (nameLow.includes('amuleto') || nameLow.includes('talismán') || nameLow.includes('rosario') || nameLow.includes('reliquia') || nameLow.includes('grilletes') || nameLow.includes('orbe'));

  // Lower body sub-distinctions
  const isSkirt = isBottom && (nameLow.includes('falda') || nameLow.includes('kilt') || nameLow.includes('tutú') || nameLow.includes('faldón') || nameLow.includes('pareo') || nameLow.includes('faldellín') || nameLow.includes('taparrabos'));
  const isPants = isBottom && (nameLow.includes('pantalón') || nameLow.includes('jeans') || nameLow.includes('cargo') || nameLow.includes('palazzo') || nameLow.includes('leggings') || nameLow.includes('jogger') || nameLow.includes('hakama') || nameLow.includes('sweatpants'));
  const isShorts = isBottom && (nameLow.includes('shorts') || nameLow.includes('bermuda') || nameLow.includes('hot pants') || nameLow.includes('culotte'));

  // Footwear sub-distinctions
  const isBoots = isShoes && (nameLow.includes('bota') || nameLow.includes('botín') || nameLow.includes('borceguí'));
  const isHeels = isShoes && (nameLow.includes('tacón') || nameLow.includes('stiletto') || nameLow.includes('pumps') || nameLow.includes('plataforma'));
  const isSandals = isShoes && (nameLow.includes('sandalia') || nameLow.includes('ojotas') || nameLow.includes('alpargata') || nameLow.includes('geta') || nameLow.includes('waraji'));
  const isSneakers = isShoes && (nameLow.includes('zapatilla') || nameLow.includes('sneaker') || nameLow.includes('deportiv'));

  // --------------------------------------------------------------------------
  // 1. CUT / SHAPE / BODY FIT / SILHOUETTE (Pure Anatomical & Silhouette Descriptors)
  // --------------------------------------------------------------------------
  let cut: string[] = [
    'Ceñido Anatómico / Segunda Piel',
    'Entallado al Contorno (Slim Fit)',
    'Estructurado con Varillas y Pinzas',
    'Corte Recto Clásico (Regular Fit)',
    'Holgado Relajado (Relaxed Fit)',
    'Oversize Caído (Boxy Fit)',
    'Fluido con Drapeado Suave',
    'Drapeado Griego/Desértico de Gasa Fluida Translúcida',
    'Cruzado Envolvente con Ajuste Lateral',
    'Compresión Elástica Anatómica',
    'Asimétrico Desestructurado'
  ];

  if (isSarashi) {
    cut = [
      'Vendaje Compresivo Cruzado en X sobre Pecho y Hombros (Criss-Cross Chest Wrap)',
      'Vendaje Cruzado Estándar Ajustado al Busto',
      'Vendaje Asimétrico de Combate con Hombro Descubierto',
      'Bandas Compresivas Horizontales Ceñidas (Bandeau Wrap)',
      'Vendaje Tradicional Sarashi con Remate en Espalda',
      'Vendaje Ceñido de Alta Compresión Anatómica'
    ];
  } else if (isRing) {
    cut = [
      'Banda Fina Clásica (1-2mm)',
      'Solitario con Engaste en Garra',
      'Sello Heráldico / Signet Ring',
      'Articulado de Dedo Completo',
      'De Falange / Midi-Ring',
      'Corona / Tiara Esculpida',
      'Banda Ancha con Grabados / Runas',
      'Con Garra Metálica Afilada',
      'Doble Aro Conectado por Cadena Fina'
    ];
  } else if (isBag) {
    cut = [
      'De Expedición con Múltiples Compartimentos',
      'Cruzado con Correa Diagonal',
      'Amplio de Hombro con Asas Largas',
      'Rígido de Mano Compacto',
      'De Cintura Compacto',
      'Doble de Cadera con Cartucheras',
      'Rústico con Solapa y Hebilla',
      'Caja Rígida Estructurada',
      'Porta-Viales / Frascos Alquímicos'
    ];
  } else if (isEarring) {
    cut = [
      'Botón / Broquel Solitario (Stud)',
      'Aros Circulares Clásicos',
      'Colgante en Lágrima / Gota Fluida',
      'Largo en Cascada / Candelabro',
      'Trepador de Cartílago (Ear Cuff)',
      'Cadena Conectora Lóbulo a Hélix',
      'Asimétrico de Statement',
      'Túnel / Expansor Metálico Pulido',
      'Con Pluma / Borla Colgante'
    ];
  } else if (isNeckAccessory) {
    cut = [
      'Ceñido al Cuello (Gargantilla)',
      'Clavicular con Colgante Central',
      'Al Escote Medio (Matiné)',
      'Largo / Multicapa Colgante',
      'Plisado con Volantes en Cuello',
      'Nudo Frontal Estilizado',
      'Lazo Ceremonial Elegante',
      'Anudado Envolvente al Cuello',
      'Aro Rígido de Metal Esculpido (Torq)'
    ];
  } else if (isHeadAccessory) {
    cut = [
      'De Ala Ancha Rígida',
      'Plano e Inclinado Artístico',
      'Cilíndrico Alto con Copa Recta',
      'Con Visera Rígida Frontal',
      'Corona / Tiara Esculpida con Puntas',
      'Diadema Ceñida con Apliques',
      'Cónico Tradicional de Paja / Bambú',
      'Capucha Amplia Envolvente',
      'Horquilla / Pasador Ornamentado'
    ];
  } else if (isFaceAccessory) {
    cut = [
      'Montura Cat-Eye Alzada',
      'Montura Redonda Clásica',
      'Montura Fina Metálica de Doble Puente',
      'Visor Envolvente Cyberpunk con Pantalla HUD',
      'Montura Rectangular Minimalista',
      'Lente Circular Único con Cadena',
      'Antifaz Calado Ceñido al Rostro',
      'Máscara Facial Completa Envolvente',
      'Piercing Decorativo Ceñido'
    ];
  } else if (isGloveAccessory) {
    cut = [
      'Segunda Piel Ceñida al Brazo hasta el Codo',
      'Ajuste con Cordones y Hebillas en Antebrazo',
      'Ceñido Corto a la Muñeca',
      'Estructura Rígida Articulada Esculpida',
      'Ajuste Rígido Tubular al Antebrazo',
      'Banda Ajustada con Tachuelas',
      'Malla Calada Ceñida a la Mano',
      'Manga Desprendida Elástica Suave'
    ];
  } else if (isBeltAccessory) {
    cut = [
      'Ceñido Firme a la Cintura con Hebilla Metálica',
      'Banda Ancha Ceñida Multivuelta',
      'Tiras Cruzadas Ceñidas en X / Y al Pecho',
      'Banda Ancha Estructurada con Varillas',
      'Caída Holgada Inclinada a la Cadera',
      'Doble Correa con Cartucheras y Ligas',
      'Banda Cruzada Diagonal sobre el Torso',
      'Cadenas Múltiples Flotantes a la Cadera'
    ];
  } else if (isMysticAccessory) {
    cut = [
      'Flotante Suspendido en Aura',
      'Grabado con Piedra Rúnica',
      'Cuentas Enlazadas Colgantes',
      'Eslabones Rotos Arcanos',
      'Orbe Giratorio Flotante'
    ];
  } else if (isArmor) {
    cut = [
      'Anatómica Esculpida Moldeada al Torso',
      'Ceñida de Placas Articuladas Ergonómicas',
      'Estructurada Rígida Pesada',
      'Entallada Ligera y Flexible',
      'Malla Articulada Ceñida al Cuerpo',
      'Modular con Correas de Ajuste',
      'Escamas Segmentadas Superpuestas'
    ];
  } else if (isSkirt) {
    cut = [
      'Tubo Ultra Ceñida a las Curvas',
      'Corte en A (Evasé) Entallada a la Cintura',
      'Vuelo Circular Amplio Continuo',
      'Plisada con Tablas Estructuradas',
      'Ceñida en Caderas con Vuelo Inferior (Sirena)',
      'Cruzada Envolvente con Abertura Lateral',
      'Faldón Envolvente Drapeado Asimétrico con Abertura Frontal/Lateral',
      'Drapeado Griego/Desértico de Gasa Fluida Translúcida',
      'Corte Recto Clásico con Abertura Posterior',
      'Asimétrica con Picos y Caída Irregular',
      'Abombada Escultórica con Volumen Inferior'
    ];
  } else if (isPants) {
    cut = [
      'Ultra Ceñido Segunda Piel (Skinny Fit)',
      'Entallado Estilizado (Slim Fit)',
      'Corte Recto Clásico (Regular Fit)',
      'Sartorial con Pinzas y Pliegue Central',
      'Ceñido en Muslo y Acampanado en Bajos (Bootcut)',
      'Pernera Extra Ancha y Fluida (Wide Leg)',
      'Holgado Ergonómico con Fuelle Articulado',
      'Oversize Descolgado Amplio (Slouchy Fit)',
      'Ajustado con Puños Elásticos en Tobillo',
      'Plisado Amplio con Pliegues Profundos'
    ];
  } else if (isShorts) {
    cut = [
      'Ultra Corto Ceñido Anatómico',
      'Entallado al Contorno Muscular',
      'Corte Recto Clásico Regular',
      'Sartorial con Pinzas de Cintura',
      'Holgado Relajado con Bolsillos Laterales',
      'Compresión Elástica Anatómica',
      'Fluido con Cintura Elástica Fruncida'
    ];
  } else if (isSocks) {
    cut = [
      'Segunda Piel Ultra Elástica y Adherente',
      'Compresión Graduada Modeladora',
      'Ceñido con Banda Superior Autofijable de Silicona',
      'Sujeción con Tirantes Tensores',
      'Suelto con Pliegues Caídos Acordeón',
      'Malla Calada Elástica Ceñida'
    ];
  } else if (isBra) {
    cut = [
      'Ceñido con Realce y Copas Anatómicas',
      'Estructurado con Aros y Borde Superior Recto',
      'Triangular Suave Sin Varillas',
      'Bandeau / Sin Tirantes de Compresión Elástica',
      'Estructurado con Varillas Verticales de Soporte',
      'Compresión Firme de Alta Sujeción',
      'Cruzado Ceñido al Cuello (Halter)',
      'Escotado Anatómico de Media Copa'
    ];
  } else if (isPanties) {
    cut = [
      'Corte Mínimo con Tiras Finas Laterales',
      'Cobertura Mínima Posterior (Hilo Dental)',
      'Corte Curvo Anatómico de Tiro Medio',
      'Cobertura Completa Clásica de Tiro Medio',
      'Tiro Alto Modelador sobre el Ombligo',
      'Cobertura Envolvente con Pernera Corta',
      'Tiras Elásticas Cruzadas Decorativas',
      'Ajuste Recto Elástico Anatómico'
    ];
  } else if (isShoes) {
    if (isBoots) {
      cut = [
        'Caña Alta Ceñida a la Pierna y Muslo',
        'Caña Media Entallada con Cremallera',
        'Ajuste Elástico al Tobillo',
        'Ajuste Firme con Cordones Cruzados',
        'Caña Ancha con Pliegues Caídos',
        'Estructurado Rígido con Suela Gruesa Reforzada'
      ];
    } else if (isHeels) {
      cut = [
        'Puntera Afilada Esculpida al Empeine',
        'Ajuste con Tira Fina al Tobillo',
        'Ajuste Cerrado Clásico al Empeine',
        'Ajuste con Tiras y Hebillas de Sujeción',
        'Destalonado con Sujeción Frontal'
      ];
    } else if (isSandals) {
      cut = [
        'Tiras Cruzadas Ceñidas a la Pierna',
        'Tiras Minimalistas Ceñidas al Empeine',
        'Ajuste con Cintas de Raso Anudadas',
        'Tira Interdigital Anatómica',
        'Tiras Anchas Acolchadas Cruzadas'
      ];
    } else if (isSneakers) {
      cut = [
        'Ajuste Anatómico Elástico al Pie',
        'Caña Alta con Sujeción Reforzada al Tobillo',
        'Ajuste Clásico con Cordones Ceñidos',
        'Suela Elevada con Estructura Rígida Reforzada',
        'Ajuste Elástico Directo Sin Cordones'
      ];
    } else {
      cut = [
        'Entallado Anatómico Ceñido al Pie',
        'Ajuste con Cordones Cruzados',
        'Estructurado Rígido con Refuerzo',
        'Puntera Afilada Esculpida',
        'Puntera Redonda Clásica',
        'Ajuste Elástico Sin Cierres'
      ];
    }
  } else if (isDress) {
    cut = [
      'Ceñido Anatómico / Segunda Piel',
      'Entallado en Torso con Caída en A (Evasé)',
      'Abertura Lateral Alta al Muslo con Costura Invisible y Cola Fluida',
      'Drapeado Griego/Desértico de Gasa Fluida Translúcida',
      'Ceñido a Caderas con Vuelo Inferior (Sirena)',
      'Estructurado con Costuras Verticales de Realce',
      'Corte Imperio Ceñido Bajo el Busto',
      'Corte Recto Vertical Continuo (Tubo / Columna)',
      'Cruzado Envolvente con Lazada Lateral',
      'Entallado en Cintura con Falda de Gran Vuelo',
      'Holgado Relajado de Caída Continua',
      'Drapeado Escultórico Ajustado al Busto y Cadera'
    ];
  } else if (isJacket) {
    if (isVest) {
      cut = [
        'Entallado Sastorial a la Cintura con Pinzas (Slim Fit)',
        'Estructurado Rígido con Botonadura Frontal',
        'Cruzado Clásico de Doble Botonadura',
        'Corte Recto Clásico de Sastrería (Regular Fit)',
        'Ceñido Corto al Torso (Cropped Fit)',
        'Holgado Relajado sin Entallar',
        'Asimétrico con Picos Delanteros Pronunciados'
      ];
    } else {
      cut = [
        'Entallado al Torso y Cintura (Slim Fit)',
        'Estructurado Rígido con Hombreras Marcadas',
        'Ceñido Corto al Pecho (Cropped Fit)',
        'Corte Recto Clásico (Regular Fit)',
        'Oversize Amplio con Hombros Caídos',
        'Porte Caído de Hombros (Off-the-Shoulder / Drop-Shoulder)',
        'Cruzado Envolvente con Cinturón de Ajuste',
        'Abullonado con Elásticos en Cintura y Puños',
        'Holgado con Caída Fluida Flotante',
        'Asimétrico Cruzado Ceñido'
      ];
    }
  } else if (isTop) {
    cut = [
      'Ceñido Anatómico / Segunda Piel',
      'Entallado al Contorno (Slim Fit)',
      'Estructurado con Varillas y Pinzas',
      'Corte Recto Clásico (Regular Fit)',
      'Holgado Relajado (Relaxed / Loose Fit)',
      'Oversize Caído (Boxy Fit)',
      'Fluido con Drapeado Suave',
      'Cruzado Envolvente con Ajuste Lateral',
      'Compresión Elástica Anatómica',
      'Asimétrico Desestructurado'
    ];
  }

  // --------------------------------------------------------------------------
  // 2. LENGTH / PROPORTION / SCALE / HEIGHT
  // --------------------------------------------------------------------------
  let length: string[] = ['A la Cintura', 'A la Cadera', 'Asimétrico'];

  if (isRing) {
    length = [
      'Banda Ultrafina (1.5mm - Muy Sutil)',
      'Banda Estándar (3mm - Clásica)',
      'Banda Ancha (6-8mm - Notoria)',
      'Escudo Frontal Grande (15mm)',
      'Articulado de Dedo Entero (40-50mm)'
    ];
  } else if (isBag) {
    length = [
      'Micro / Compacto (Mano o Riñonera)',
      'Pequeño (Capacidad Esenciales)',
      'Mediano (Uso Diario / 10-15 Litros)',
      'Grande / Mochila de Carga (25-35 Litros)',
      'Extra Grande (Expedición / Viaje Táctico)'
    ];
  } else if (isEarring) {
    length = [
      'Pegado al Lóbulo (Stud / Botón 5-8mm)',
      'Corto / A la Mandíbula (15-25mm)',
      'Medio / Caída al Cuello (40-60mm)',
      'Largo / Rozando la Clavícula (80-100mm)',
      'Extra Largo / Sobre el Hombro (120mm+)'
    ];
  } else if (isNeckAccessory) {
    length = [
      'Ceñido al Cuello (Choker / Gargantilla 32-36cm)',
      'A la Clavícula (Princesa 42-45cm)',
      'Al Escote Central (Matiné 50-55cm)',
      'Al Esternón / Bajo Pecho (Ópera 70-80cm)',
      'Largo / Hasta el Ombligo (Cuerda 90-100cm)'
    ];
  } else if (isHeadAccessory) {
    length = [
      'Corona Baja / Discreta',
      'Corona Media Estándar',
      'Corona Alta / Tiara Real Esculpida',
      'Ala Corta (5cm - Fedora / Trilby)',
      'Ala Ancha (12-15cm - Sombrero de Sol / Pamela)',
      'Capucha Corta al Cuello',
      'Capucha Larga con Caída a la Espalda'
    ];
  } else if (isFaceAccessory) {
    length = [
      'Montura Fina / Compacta',
      'Montura Mediana Regular',
      'Montura Oversize / Pantalla Completa',
      'Monóculo con Cadena de 30cm',
      'Máscara de Medio Rostro (Antifaz)',
      'Máscara de Rostro Completo'
    ];
  } else if (isGloveAccessory) {
    length = [
      'A la Muñeca (Corto 18-20cm)',
      'Medio Antebrazo (28-30cm)',
      'Hasta el Codo (Ópera 45-50cm)',
      'Brazo Completo / Sobre el Codo (60-65cm)'
    ];
  } else if (isBeltAccessory) {
    length = [
      'Fino (1.5-2cm - Sutil y Elegante)',
      'Medio (3.5-4cm - Clásico de Trabilla)',
      'Ancho (6-8cm - Fajín Estructurado)',
      'Extra Ancho (12-15cm - Tipo Corsé)',
      'Largo con Caída Libre / Extremo Colgante'
    ];
  } else if (isSkirt) {
    length = [
      'Micro (Bajo los Glúteos - 28cm)',
      'Mini (Medio Muslo - 40cm)',
      'Sobre la Rodilla (50cm)',
      'A la Rodilla (60cm)',
      'Midi (Media Pantorrilla - 75cm)',
      'Maxi (Al Tobillo - 95cm)',
      'Larga al Suelo / Con Cola Ceremonial'
    ];
  } else if (isPants) {
    length = [
      'Bajo la Rodilla (Capri / Pirata)',
      'Tobillero / Cropped (Sobre el Tobillo)',
      'Estándar (Cubriendo el Empeine)',
      'Largo Slouchy (Arrastrando sobre el Calzado)'
    ];
  } else if (isShorts) {
    length = [
      'Línea Glútea (Micro Short)',
      'Muslo Superior (Corto)',
      'Medio Muslo (Regular)',
      'Sobre la Rodilla (Ciclista)',
      'Hasta la Rodilla (Bermuda)'
    ];
  } else if (isSocks) {
    length = [
      'Al Tobillo (Tobillero Invisible / Corto)',
      'Media Pantorrilla (Crew Clásico)',
      'Bajo la Rodilla (Knee-High)',
      'Sobre la Rodilla (Over-the-Knee)',
      'Muslo Alto (Thigh-High con Borde de Silicona)',
      'Pantimedias Completas (Hasta la Cintura)'
    ];
  } else if (isBra) {
    length = [
      'Micro Demi (Apenas Cubre Pezón)',
      'Media Copa Clásica',
      'Copa Completa',
      'Longline (Banda Ancha hasta las Costillas)',
      'Corsé Underbust (Hasta la Cintura)'
    ];
  } else if (isPanties) {
    length = [
      'Línea Inguinal (Micro Tanga / G-String)',
      'Tiro Bajo a las Caderas',
      'Tiro Medio Clásico',
      'Tiro Alto sobre el Ombligo (Vintage)'
    ];
  } else if (isShoes) {
    if (isBoots) {
      length = [
        'Bajo el Tobillo (Corte Bajo)',
        'Al Tobillo (Botín 15cm)',
        'Media Caña / Pantorrilla (25cm)',
        'Caña Alta Bajo Rodilla (40cm)',
        'Sobre la Rodilla / Muslo Alto (55-65cm)'
      ];
    } else if (isHeels) {
      length = [
        'Suela Plana / Sin Tacón (1-2cm)',
        'Tacón Bajo Cómodo (3-4cm)',
        'Tacón Medio Clásico (6-8cm)',
        'Tacón Alto Stiletto (10-12cm)',
        'Plataforma Extrema (15cm+)'
      ];
    } else {
      length = [
        'Suela Plana Minimalista',
        'Suela Media Confort',
        'Plataforma Gruesa Chunky (4-6cm)',
        'Tacón Cuña Elevado'
      ];
    }
  } else if (isDress) {
    length = [
      'Micro (Bajo los Glúteos)',
      'Mini (Medio Muslo)',
      'Sobre la Rodilla',
      'A la Rodilla',
      'Midi (Media Pantorrilla)',
      'Maxi (Al Tobillo)',
      'Hasta el Suelo con Cola Flotante'
    ];
  } else if (isJacket) {
    if (isVest) {
      length = [
        'A la Cintura Natural',
        'A la Cadera (Estándar de Sastrería)',
        'Bajo la Cadera / Tres Cuartos',
        'Crop sobre el Ombligo',
        'Largo Asimétrico con Picos'
      ];
    } else {
      length = [
        'Bolero / Torera (Bajo el Pecho)',
        'A la Cintura (Chaqueta Crop)',
        'A la Cadera (Blazer Regular)',
        'Medio Muslo (Tres Cuartos / Parka)',
        'A la Rodilla (Trench / Abrigo Clásico)',
        'Al Suelo / Con Cola (Levita / Capa Maxi)'
      ];
    }
  } else if (isTop) {
    length = [
      'Ultra Crop (Bajo el Busto)',
      'Crop Top (Sobre el Ombligo)',
      'A la Cintura Natural',
      'A la Cadera (Estándar)',
      'Bajo la Cadera (Túnica Larga)',
      'Asimétrico con Caída Lateral'
    ];
  }

  // --------------------------------------------------------------------------
  // 3. SLEEVES (Only relevant garments)
  // --------------------------------------------------------------------------
  let sleeve: string[] = [];
  if (isVest) {
    sleeve = [
      'Sin Mangas (Corte Sisa Clásico)',
      'Sin Mangas con Hombreras Marcadas',
      'Sin Mangas con Sisas Escotadas',
      'Tirantes Anchos de Chaleco',
      'Sin Mangas con Ribete Estructurado'
    ];
  } else if (isTop || isDress || isJacket) {
    sleeve = [
      'Sin mangas / Tirantes Finos',
      'Tirantes Gruesos / Sisa Americana',
      'Sin Mangas con Chales de Gasa Flotantes Suspendidos',
      'Manguitos Grabados con Brazalete de Bíceps',
      'Manga Corta Clásica',
      'Manga 3/4 Francesa',
      'Manga Larga Ceñida con Puños',
      'Mangas Poeta / Obispo Desprendidas con Puños de Volantes Elásticos',
      'Manga Abullonada / Poeta Romántica',
      'Manga Acampanada / Campana Fluida',
      'Manga Murciélago / Kimono Tradicional',
      'Hombros Descubiertos (Cold-Shoulder)',
      'Manga Asimétrica (Un Solo Brazo)',
      'Mangas Desprendidas / Manguitos Aislados',
      'Guanteletes / Mangas de Ópera Integradas',
      'Mangas Translúcidas de Gasa Flotante'
    ];
  }

  // --------------------------------------------------------------------------
  // 4. NECKLINE / COLLAR (Pure Geometric & Anatomical Descriptors)
  // --------------------------------------------------------------------------
  let neckline: string[] = [];
  if (isVest) {
    neckline = [
      'Cuello en V Profundo',
      'Solapa de Muesca Clásica',
      'Solapa en Pico Alzada',
      'Cuello Mao / Mandarín Vertical',
      'Escote Profundo en U',
      'Cuello Doblado Clásico con Solapas',
      'Cuello Alto / Cisne Ceñido'
    ];
  } else if (isTop || isDress || isJacket || isBra || isNeckAccessory) {
    neckline = [
      'Escote Keyhole / Lágrima Central con Ribete Fruncido de Volantes',
      'Cuello Halter Cruzado con Espalda Descubierta y Cadenas Doradas',
      'Pectoral Rígido de Regalia con Placas Articuladas',
      'Cuello Doblado Clásico con Solapas',
      'Cuello en V Profundo',
      'Cuello Redondo Clásico',
      'Cuello Alto / Cisne Ceñido',
      'Cuello Mao / Mandarín Vertical',
      'Escote Corazón',
      'Escote Barco (Hombro a Hombro)',
      'Hombros Descubiertos',
      'Escote Cuadrado',
      'Escote Profundo en U',
      'Abertura en Gota Central (Keyhole)',
      'Escote Inferior Expuesto (Underboob)',
      'Abertura Ovalada en Pecho',
      'Tiras Cruzadas en Busto (Strappy)',
      'Cuello Halter con Anilla Central',
      'Escote Ilusión con Malla Transparente',
      'Espalda Abierta Extrema y Descubierta',
      'Solapa de Muesca Clásica',
      'Solapa en Pico Alzada',
      'Gorguera Plisada de Volantes',
      'Capucha Amplia Integrada',
      'Sin Tirantes / Sin Cuello (Strapless)'
    ];
  }

  // --------------------------------------------------------------------------
  // 5. MATERIAL (Tailored by category & item physical nature)
  // --------------------------------------------------------------------------
  let material: string[] = ['Algodón', 'Lino', 'Seda', 'Lana', 'Cuero', 'Denim', 'Terciopelo', 'Encaje', 'PVC', 'Sintético'];

  if (isArmor) {
    material = [
      'Acero',
      'Acero templado',
      'Hierro negro',
      'Mithril',
      'Madera',
      'PVC',
      'Titanio',
      'Cota de malla',
      'Quitina',
      'Bronce'
    ];
  } else if (isRing || isEarring || isMysticAccessory) {
    material = ACCESSORY_MATERIALS_FINE;
  } else if (isBag) {
    material = ACCESSORY_MATERIALS_BAGS;
  } else if (isHeadAccessory) {
    material = ACCESSORY_MATERIALS_HEAD;
  } else if (isGloveAccessory) {
    material = ACCESSORY_MATERIALS_GLOVES;
  } else if (isBeltAccessory) {
    material = ACCESSORY_MATERIALS_BELTS;
  } else if (isFaceAccessory) {
    material = [
      'Acetato',
      'Titanio',
      'Latón',
      'Bronce',
      'Oro',
      'Plata',
      'Porcelana',
      'Cuero',
      'Resina',
      'Acero'
    ];
  } else if (isNeckAccessory) {
    material = [
      'Oro',
      'Plata',
      'Cuero',
      'Seda',
      'Terciopelo',
      'Perlas',
      'Jade',
      'Encaje',
      'Acero'
    ];
  } else if (isShoes) {
    material = [
      'Cuero',
      'Charol',
      'Gamuza',
      'Lona',
      'Goma',
      'Madera',
      'Satén',
      'PVC',
      'Acero'
    ];
  } else if (isSocks) {
    material = [
      'Nylon',
      'Microfibra',
      'Malla de red',
      'Encaje',
      'Algodón',
      'Lana',
      'Seda',
      'Látex',
      'Vinilo',
      'Tul'
    ];
  } else if (isBra || isPanties) {
    material = [
      'Encaje',
      'Tul',
      'Gasa',
      'Seda',
      'Satén',
      'Látex',
      'Vinilo',
      'Microfibra',
      'Algodón',
      'Terciopelo',
      'Malla de red',
      'Metal'
    ];
  } else if (isSkirt) {
    material = [
      'Lana',
      'Denim',
      'Seda',
      'Algodón',
      'Lino',
      'Terciopelo',
      'Satén',
      'Tul',
      'Encaje',
      'Charol',
      'Cuero',
      'Látex',
      'Vinilo',
      'PVC'
    ];
  } else if (isPants) {
    material = [
      'Denim',
      'Algodón',
      'Lana',
      'Cuero',
      'Charol',
      'Látex',
      'Vinilo',
      'Lino',
      'Pana',
      'Sintético',
      'Spandex',
      'PVC'
    ];
  } else if (isJacket) {
    if (isVest) {
      material = [
        'Lana fría sastorial',
        'Tweed',
        'Terciopelo',
        'Seda brocada',
        'Brocado jacquard',
        'Algodón piqué',
        'Cuero fino',
        'Lino estructurado',
        'Satén',
        'Pana'
      ];
    } else {
      material = [
        'Cuero',
        'Charol',
        'Lana',
        'Tweed',
        'Gabardina',
        'Algodón',
        'Denim',
        'Terciopelo',
        'Piel sintética',
        'Nylon',
        'Gasa',
        'Tul',
        'PVC',
        'Vinilo'
      ];
    }
  } else if (isDress) {
    material = [
      'Seda',
      'Satén',
      'Encaje',
      'Gasa',
      'Tul',
      'Látex',
      'Vinilo',
      'Lana',
      'Algodón',
      'Lino',
      'Terciopelo',
      'Cuero',
      'Charol',
      'Denim',
      'Malla',
      'PVC'
    ];
  } else if (isTop) {
    material = [
      'Algodón',
      'Seda',
      'Gasa',
      'Tul',
      'Encaje',
      'Satén',
      'Látex',
      'Vinilo',
      'Punto',
      'Lino',
      'Lana',
      'Terciopelo',
      'Denim',
      'Cuero',
      'Malla',
      'PVC'
    ];
  }

  // --------------------------------------------------------------------------
  // 6. FINISH
  // --------------------------------------------------------------------------
  let finish: string[] = ['Mate', 'Satinado', 'Brillante', 'Pulido espejo', 'Desgastado', 'Metalizado', 'Translúcido / Transparente', 'Charol líquido'];

  if (isArmor) {
    finish = ['Mate', 'Pulido espejo', 'Pavonado', 'Bruñido', 'Desgastado', 'Martillado', 'Filigrana', 'Esmaltado'];
  } else if (isRing || isEarring || isMysticAccessory) {
    finish = ACCESSORY_FINISHES_JEWELRY;
  } else if (isBag || isBeltAccessory) {
    finish = ACCESSORY_FINISHES_LEATHER_FABRIC;
  } else if (isShoes) {
    finish = ['Mate', 'Charol brillante', 'Gamuza aterciopelada', 'Desgastado', 'Pátina artesanal', 'Goma mate', 'Látex espejo'];
  } else if (isSocks) {
    finish = ['Mate opaco', 'Satinado', 'Transparente / Sheer', 'Red calada', 'Vinilo brillante', 'Punto canalé', 'Efecto rasgado / Battle damaged'];
  } else if (isBra || isPanties) {
    finish = ['Satinado', 'Transparente / Sheer', 'Encaje en relieve', 'Mate sin costuras', 'Vinilo brillante / Látex', 'Bordado metálico', 'Efecto mojado'];
  }

  // --------------------------------------------------------------------------
  // 7. DETAILS (Item-specific Physical Craft)
  // --------------------------------------------------------------------------
  let details: string[] = [
    'Carrera de Botones', 'Bordados', 'Costuras', 'Cinturones', 'Pliegues', 'Transparencias / Tela Translúcida', 'Encajes', 'Lazos', 'Cintas', 'Hebillas', 'Parches',
    'Escote Keyhole / Lágrima Central con Ribete Fruncido de Volantes',
    'Mangas Poeta / Obispo Desprendidas con Puños de Volantes Elásticos',
    'Cremallera Metálica Expuesta en Espalda Completa',
    'Abertura Lateral Alta al Muslo con Costura Invisible y Cola Fluida',
    'Drapeado Griego/Desértico de Gasa Fluida Translúcida',
    'Incrustaciones de Cabujones de Piedra preciosa Pulida',
    'Chales de Gasa Flotantes Suspendidos de los Brazaletes',
    'Cremalleras Expuestas', 'Bolsillos Tácticos', 'Aberturas / Cortes (Cut-outs)', 'Cordones / Corsetería', 'Lentejuelas / Pedrería', 'Flecos', 'Cadenas Colgantes', 'Remaches', 'Minimalista'
  ];

  if (isRing) {
    details = [
      'Gema Solitaria en Garra Alta',
      'Pavé de Micro-diamantes en la Banda',
      'Grabado Rúnico / Blasón Esculpido',
      'Filigrana Barroca Calada',
      'Cadena Fina de Conexión a Pulsera',
      'Relieve Esculpido (Dragón / Calavera)',
      'Esmalte al Fuego de Color',
      'Piedras Laterales en Baguette',
      'Sin Adornos / Liso Minimalista'
    ];
  } else if (isBag) {
    details = [
      'Peluche de Compañía Estilo Conejo Patchwork (Ojos de Botón y Orejas Caídas)',
      'Lazos y Listones de Raso Colgantes',
      'Ribete de Peluche Esponjoso con Pompones',
      'Hebillas Metálicas Pesadas de Cierre',
      'Cremalleras Expuestas con Tiradores de Cuero',
      'Bolsillos Cargo Tácticos Exteriores',
      'Cadenas Metálicas y Mosquetones de Anclaje',
      'Transparencias / Tela Translúcida',
      'Minimalista'
    ];
  } else if (isEarring) {
    details = [
      'Gema Solitaria Colgante en Garra',
      'Filigrana Calada Barroca',
      'Perla de Gota Natural Lustrada',
      'Cadenillas Finas Oscilantes',
      'Dije / Amuleto Pequeño Colgante',
      'Plumas / Borlas de Seda Colgantes',
      'Micro-tachuelas Metálicas en Borde',
      'Ear Cuff con Garra de Sujeción',
      'Minimalista'
    ];
  } else if (isNeckAccessory) {
    details = [
      'Incrustaciones de Cabujones de Piedra preciosa Pulida',
      'Placas de Metal Articuladas de Regalia con Lágrimas Colgantes',
      'Colgante Central con Gema Engarzada',
      'Argolla Frontal Metálica (O-Ring)',
      'Nudo Windsor con Pasador de Corbata Joya',
      'Cadenas Colgantes en Cascada sobre el Pecho',
      'Lazo de Cinta de Raso en la Nuca',
      'Lazo Negro de Satén con Caídas Largas',
      'Hilera de Perlas Calibradas',
      'Broche Joya / Cameo Vintage',
      'Tachuelas y Remaches en Gargantilla',
      'Transparencias / Tela Translúcida',
      'Minimalista'
    ];
  } else if (isHeadAccessory) {
    details = [
      'Tocado de Cadenas Finas en Coronilla con Cabujón en Frente y Velo de Gasa',
      'Incrustaciones de Cabujones de Piedra preciosa Pulida',
      'Orejas de Conejo Caídas con Lazos de Raso',
      'Orejas de Gato / Conejita de Peluche con Cascabeles',
      'Pasadores y Horquillas en Cruz («X») de Cintas Pastel',
      'Lazos Grandes de Raso / Listones Laterales',
      'Ribete de Peluche Acolchado con Pompones',
      'Banda de Cinta de Raso con Hebilla',
      'Velo de Malla Corto sobre los Ojos (Birdcage)',
      'Gemas Engastadas en Corona / Tiara',
      'Cráneo Animal Óseo con Cuernos Curvados y Marcas de Pintura Ritual',
      'Cuerdas Sagradas Trenzadas con Borlas de Seda y Cascabeles Tintineantes',
      'Transparencias / Tela Translúcida',
      'Minimalista'
    ];
  } else if (isFaceAccessory) {
    details = [
      'Velo de Gasa Facial Translúcido (Nariz y Boca Cubiertas)',
      'Lentes Polarizadas con Degradado de Color',
      'Montura con Filigrana Grabada en Relieve',
      'Cadena Metálica Sujetadora Colgante',
      'Luces LED / Display HUD Cyberpunk',
      'Ribetes Metálicos Dorados en Patillas',
      'Lazos de Seda para Atar la Máscara',
      'Gemas / Micro-diamantes en Bordes',
      'Marcas Rituales Pintadas en la Máscara',
      'Transparencias / Tela Translúcida',
      'Minimalista'
    ];
  } else if (isGloveAccessory) {
    details = [
      'Chales de Gasa Flotantes Suspendidos de los Brazaletes',
      'Incrustaciones de Cabujones de Piedra preciosa Pulida',
      'Brazalete de Bíceps con Manguitos Grabados de Metal Bruñido',
      'Hilera de Botoncitos de Perla en Muñeca',
      'Costuras de Tres Nervios Clásicos en Dorso',
      'Placas Metálicas y Remaches en Nudillos',
      'Lazado de Cordones Entrelazados en Antebrazo',
      'Borde Superior de Encaje o Pelaje',
      'Abertura Cut-Out en el Dorso de la Mano',
      'Garras Metálicas en las Puntas de los Dedos',
      'Vendas de Tela Rústica Bajo Muñequeras de Cuero con Hebillas',
      'Mangas Flotantes Desmontables (Detached Sleeves) con Borlas y Lazada',
      'Argollas Metálicas en Bíceps con Cintas Colgantes',
      'Transparencias / Tela Translúcida',
      'Minimalista'
    ];
  } else if (isBeltAccessory) {
    details = [
      'Cinturón Ceremonial de Cadenas Escalonadas con Broche y Dijes de Hojas',
      'Incrustaciones de Cabujones de Piedra preciosa Pulida',
      'Drapeado Griego/Desértico de Gasa Fluida Translúcida',
      'Ligas con Broches de Conejito / Motivos Kawaii',
      'Lazos y Listones de Raso Colgantes en Caderas',
      'Ribete de Peluche / Encaje en la Pretina',
      'Faldellín / Taparrabos Tribal con Tiras Descubiertas y Cuerdas Anudadas',
      'Láminas de Escamas de Cuero / Metal Superpuestas',
      'Hebilla Esculpida / Grabada con Relieve',
      'Argollas Metálicas Grandes (O-Rings / D-Rings)',
      'Cadenas Colgantes Cruzadas en Caderas',
      'Tirantes de Ligas con Enganches Metálicos',
      'Colgantes de Hueso Tallado, Borlas y Abalorios Tribales',
      'Transparencias / Tela Translúcida',
      'Minimalista'
    ];
  } else if (isSkirt) {
    details = [
      'Faldón Envolvente Asimétrico con Pliegues Fluidos y Abertura',
      'Drapeado Griego/Desértico de Gasa Fluida Translúcida',
      'Incrustaciones de Cabujones de Piedra preciosa Pulida',
      'Abertura Lateral Alta al Muslo con Costura Invisible y Cola Fluida',
      'Cremallera Metálica Expuesta en Espalda Completa',
      'Lazos de Raso y Listones en la Pretina',
      'Ribete Inferior de Peluche Blanco / Borreguito Esponjoso',
      'Puntilla de Encaje Calado con Volantes',
      'Tablas Plisadas Definidas y Prensadas',
      'Tiras Laterales Pélvicas (Cutout Hip Straps)',
      'Cuerdas Anudadas, Borlas y Abalorios Tribales',
      'Abertura Lateral Alta (Slit) al Muslo',
      'Cadenas Colgantes de Cintura a Cadera',
      'Bolsillos Ocultos en las Costuras',
      'Transparencias / Tela Translúcida',
      'Minimalista'
    ];
  } else if (isPants) {
    details = [
      'Aberturas Pélvicas en Caderas (Hip Cut-Outs) y Cordón en Lazo',
      'Estampado de Huellitas Felinas en Blanco',
      'Franjas de Tigre Urbanas en Pierna',
      'Bolsillos Cargo con Fuelle y Solapa en Muslos',
      'Costuras y Pespuntes Dobles Reforzados',
      'Roturas / Rasgados con Hilos Expuestos en Rodillas',
      'Arnés de Doble Correa de Cuero con Hebillas Metálicas en Muslos',
      'Ribete de Piel de Lobo / Bestia en el Borde de la Pretina',
      'Costuras Reforzadas de Combate en Entrepierna y Rodillas',
      'Cremalleras en los Bajos / Tobillos',
      'Cadena Metálica de Bolsillo a Trabilla',
      'Raya Central Planchada / Pinzas Sastoriales',
      'Bragueta con Hilera de Botones Vistos',
      'Cinturón Táctico con Hebilla Cobra',
      'Transparencias / Tela Translúcida',
      'Minimalista'
    ];
  } else if (isSocks) {
    details = [
      'Lazos y Listones de Raso en Borde Superior',
      'Ribete de Peluche Esponjoso / Borreguito en Puño',
      'Estampados Pastel Kawaii (Fresas / Estrellas / Cruces)',
      'Borde Superior de Encaje Ancho con Volantes',
      'Diseño Stirrup (Talón y Dedos al Descubierto) con Ribete Pastel',
      'Costura Posterior Vertical (Vintage Pin-Up)',
      'Ligas Integradas con Broches Metálicos o de Conejito',
      'Trama de Red (Fishnet) Fina / Mediana',
      'Fruncido Slouchy Arrugado en Tobillos',
      'Transparencias / Tela Translúcida',
      'Minimalista'
    ];
  } else if (isBra || isPanties) {
    details = [
      'Lazo Central de Raso en Escote / Cintura',
      'Tiras Multi-correa (Strappy / Jaula)',
      'Ribetes Festoneados de Encaje Francés',
      'Transparencias de Malla / Tul en Paneles',
      'Transparencias / Tela Translúcida',
      'Ballenas y Varillas de Soporte',
      'Argollas Metálicas Doradas / Plateadas en Tirantes',
      'Aberturas Cut-Out en Busto o Caderas',
      'Cierre Frontal de Botones o Broche Metálico',
      'Ligas Integradas para Medias',
      'Minimalista'
    ];
  } else if (isShoes) {
    details = [
      'Ribete de Peluche Blanco / Borreguito en la Caña',
      'Lazada Frontal Cruzada con Listones o Cintas de Raso',
      'Lazos Grandes de Raso en el Tobillo',
      'Plataforma Dentada Chunky Track',
      'Cordones Frontales Cruzados con Ojetes Metálicos',
      'Hebillas Múltiples de Cuero con Tachuelas',
      'Cadenas Decorativas Colgantes en Empeine',
      'Tiras Cruzadas Anudadas al Tobillo / Gemelo (Estilo Sandalia Tribal)',
      'Tobilleras con Garras y Dientes de Bestia Tallados',
      'Transparencias / Tela Translúcida',
      'Minimalista'
    ];
  } else if (isHoodie) {
    details = [
      'Capucha con Orejas Largas de Conejo Caídas',
      'Capucha con Orejas de Gato / Osito de Peluche',
      'Ribete de Peluche Blanco / Borreguito Esponjoso en Capucha y Puños',
      'Pompones Esponjosos en los Extremos de los Cordones',
      'Lazos y Listones de Raso Cruzados en Pechera o Mangas',
      'Mangas Extralargas Oversize Cubriendo las Manos',
      'Cuello Camisero con Corbata Fina Asomando',
      'Cuerpo Patchwork con Costuras Vistas Gruesas',
      'Bolsillo Canguro Frontal con Ribete Afelpado',
      'Transparencias / Tela Translúcida',
      'Minimalista'
    ];
  } else if (isJacket) {
    if (isVest) {
      details = [
        'Botonadura Frontal Sastorial con Botones de Cuerno o Nácar',
        'Bolsillos de Vivo / Ojal Finos en Pecho y Costados',
        'Cadena de Reloj Leontina de Oro/Plata Cruzando el Pecho',
        'Trabilla y Hebilla Trasera de Ajuste en Espalda',
        'Solapas de Pico de Satén en Contraste',
        'Bordados de Brocado Heráldico en Pechera',
        'Espalda de Satén o Seda Pura Brillante',
        'Transparencias / Tela Translúcida',
        'Minimalista'
      ];
    } else {
      details = [
        'Capucha con Orejas de Conejo o Felino',
        'Capucha y Cuello con Ribete de Pelo / Borreguito Esponjoso',
        'Lazos y Listones de Raso en Mangas o Cierre',
        'Láminas de Escamas en Hombros y Solapas',
        'Láminas de Escamas de Dragón / Escamas Metálicas Imbricadas',
        'Ribete de Piel Salvaje / Borrego Grisáceo en Sisas y Cuello',
        'Bajo Corto al Busto Dejando Abdomen Totalmente al Descubierto',
        'Pompones Esponjosos Colgantes',
        'Cremallera Diagonal Metálica de Biker',
        'Charreteras con Botón en Hombros',
        'Doble Hilera Militar de Botones Dorados',
        'Solapas Tachonadas con Remaches y Spikes',
        'Cinturón de Cuero Ancho en el Bajo con Hebilla',
        'Bolsillos Cargo con Solapa en Pecho y Mangas',
        'Transparencias / Tela Translúcida',
        'Minimalista'
      ];
    }
  } else if (isDress) {
    details = [
      'Escote Keyhole / Lágrima Central con Ribete Fruncido de Volantes',
      'Mangas Poeta / Obispo Desprendidas con Puños de Volantes Elásticos',
      'Cremallera Metálica Expuesta en Espalda Completa',
      'Abertura Lateral Alta al Muslo con Costura Invisible y Cola Fluida',
      'Drapeado Griego/Desértico de Gasa Fluida Translúcida',
      'Incrustaciones de Cabujones de Piedra preciosa Pulida',
      'Chales de Gasa Flotantes Suspendidos de los Brazaletes',
      'Capucha con Orejas de Conejo / Felino de Peluche',
      'Lazos y Listones de Raso en Escote y Cintura',
      'Lazo Negro de Satén en Escote Victoriano',
      'Ribete de Peluche Blanco Esponjoso en Bajos y Puños',
      'Pompones de Felpa Colgantes',
      'Falda de Capas de Tul con Puntilla de Encaje',
      'Mangas Acampanadas con Lazos',
      'Jabot de Volantes en Escote Central',
      'Transparencias / Tela Translúcida',
      'Minimalista'
    ];
  } else if (isTop) {
    if (isSarashi) {
      details = [
        'Tiras Cruzadas sobre Ambos Hombros y Torso (Criss-Cross Wrap)',
        'Extremos Deshilachados / Rasgados de Batalla',
        'Bordes Reforzados con Doble Costura Oculta',
        'Sellos Rúnicos / Kanji Escritos con Tinta en las Vendas',
        'Nudos Planos de Fijación Laterales',
        'Bajo Corto al Busto Dejando Abdomen Totalmente al Descubierto',
        'Transparencias / Tela Translúcida',
        'Minimalista / Vendaje Limpio y Pulcro'
      ];
    } else {
      details = [
        'Drapeado Griego/Desértico de Gasa Fluida Translúcida',
        'Incrustaciones de Cabujones de Piedra preciosa Pulida',
        'Chales de Gasa Flotantes Suspendidos de los Brazaletes',
        'Espalda Descubierta con Cadenas Doradas Cruzadas',
        'Escote Keyhole / Lágrima Central con Ribete Fruncido de Volantes',
        'Mangas Poeta / Obispo Desprendidas con Puños de Volantes Elásticos',
        'Cremallera Metálica Expuesta en Espalda Completa',
        'Lazos y Listones de Raso Cruzados en Pechera',
        'Lazo Negro de Satén en Cuello o Escote',
        'Ribete de Peluche Suave en Cuello y Puños',
        'Láminas de Escamas de Dragón / Escamas Metálicas Imbricadas',
        'Ribete de Piel Salvaje / Borrego Grisáceo en Sisas y Cuello',
        'Bajo Corto al Busto Dejando Abdomen Totalmente al Descubierto',
        'Capucha Integrada con Orejitas de Peluche',
        'Pompones Colgantes en Escote',
        'Cuello Camisero con Corbata Fina en Contraste',
        'Jabot de Volantes en Escote Central',
        'Ballenas de Corsé con Lazado Trasero',
        'Láminas de Escamas Metálicas o Cuero Superpuestas',
        'Carrera de Botones Forrados en Pechera',
        'Aberturas Cut-Out en Clavícula / Hombros',
        'Transparencias / Tela Translúcida',
        'Minimalista'
      ];
    }
  }

  // --------------------------------------------------------------------------
  // 8. VARIATION
  // --------------------------------------------------------------------------
  let variation: string[] = ['Simétrica', 'Asimétrica', 'Desgastada', 'Desmechada', 'Degradada', 'Drapeada', 'Plisada'];
  if (isRing || isEarring) {
    variation = ['Clásica / Pura', 'Asimétrica / Vanguardista', 'Vintage / Envejecida', 'Minimalista Pulida', 'Ornamental Barroca'];
  } else if (isBag) {
    variation = ['Estructurada / Rígida', 'Blanda / Slouchy', 'Modular / Táctica', 'Compacta Plegable', 'Vintage con Pátina'];
  } else if (isShoes) {
    variation = ['Estándar Pulido', 'Urbano Moderno', 'Táctico Militar', 'Gótico / Biker', 'Formal de Etiqueta', 'Fantasía Ceremonial'];
  }

  // --------------------------------------------------------------------------
  // 9. LAYER (Anatomical Depth)
  // --------------------------------------------------------------------------
  let layer: string[] = ['Base', 'Intermedia', 'Exterior', 'Accesorio sobrepuesto'];
  if (isRing || isEarring || isFaceAccessory || isHeadAccessory || isMysticAccessory) {
    layer = ['Accesorio Fino Sobrepuesto', 'Joyería Principal', 'Ornamento de Rostro / Cabeza'];
  } else if (isBag) {
    layer = ['Accesorio de Carga Exterior', 'Contenedor Portado'];
  } else if (isGloveAccessory || isBeltAccessory || isNeckAccessory) {
    layer = ['Accesorio Ajustado', 'Accesorio Sobrepuesto', 'Arnés / Estructura'];
  } else if (isBra || isPanties || isSocks || categoryId === 'B3-D') {
    layer = ['Interior Íntima', 'Base Ligera / Segunda Piel'];
  } else if (isShoes) {
    layer = ['Calzado Base', 'Calzado Exterior Pesado'];
  } else if (isJacket) {
    if (isVest) {
      layer = ['Intermedia / Sobre Camisa', 'Exterior Ligera', 'Capa Sobrepuesta'];
    } else {
      layer = ['Exterior Ligera', 'Exterior Pesada / Abrigo', 'Capa Sobrepuesta'];
    }
  } else if (isDress) {
    layer = ['Prenda Única / Capa Base', 'Capa Principal'];
  } else if (isBottom) {
    layer = ['Prenda Inferior Base', 'Prenda Inferior Sobrepuesta'];
  }

  // --------------------------------------------------------------------------
  // 10. LOCATION (Anatomical Placement on Body)
  // --------------------------------------------------------------------------
  let location: string[] = [];
  if (isRing) {
    location = [
      'Dedo Anular (Clásico)',
      'Dedo Índice (Sello / Poder)',
      'Dedo Pulgar (Arquería / Ban Zhi)',
      'Dedo Meñique',
      'Falange Media (Midi-Ring)',
      'Dedo Corazón',
      'Múltiples Dedos (Set Coordinado)'
    ];
  } else if (isBag) {
    location = [
      'Cruzado al Pecho (Bandolera)',
      'Colgado al Hombro',
      'A la Espalda (Mochila / Doble Asa)',
      'Ajustado a la Cintura / Cadera',
      'En la Mano por el Asa',
      'En el Antebrazo / Codo'
    ];
  } else if (isEarring) {
    location = [
      'Ambos Lóbulos (Simétrico)',
      'Solo Lóbulo Derecho',
      'Solo Lóbulo Izquierdo',
      'Cartílago Superior / Hélix',
      'Trago / Antitrago',
      'Cadena Conectada de Lóbulo a Cartílago'
    ];
  } else if (isNeckAccessory) {
    location = [
      'Cuello Frontal Ceñido',
      'Base del Cuello / Clavículas',
      'Pecho Superior / Escote',
      'Nuca / Cierre Posterior',
      'Hombros y Escote'
    ];
  } else if (isHeadAccessory) {
    location = [
      'Corona / Parte Superior de la Cabeza',
      'Frente / Visera sobre los Ojos',
      'Ala Exterior del Sombrero',
      'Costado Derecho del Cabello',
      'Costado Izquierdo del Cabello',
      'Nuca / Parte Trasera'
    ];
  } else if (isFaceAccessory) {
    location = [
      'Ojos / Frente (Uso Activo)',
      'Puente de la Nariz',
      'Sobre la Frente / Levantado',
      'Colgado al Cuello con Cadena',
      'Lateral de la Cabeza (Máscara Inclinada)',
      'Labio / Ceja / Nariz (Piercing)'
    ];
  } else if (isGloveAccessory) {
    location = [
      'Manos y Dedos Completos',
      'Dorso de la Mano y Nudillos',
      'Muñeca y Antebrazo',
      'Hasta el Codo / Brazo Completo'
    ];
  } else if (isBeltAccessory) {
    location = [
      'Cintura Frontal Natural',
      'Caderas Laterales / Tiro Bajo',
      'Espalda Baja / Ajuste Posterior',
      'Pecho Cruzado (Arnés)',
      'Muslos Superiores (Ligas)'
    ];
  } else if (isMysticAccessory) {
    location = [
      'Flotando sobre el Hombro',
      'Colgando al Pecho',
      'Suspendido en la Cintura',
      'Flotando en la Mano',
      'Orbitando el Cuerpo'
    ];
  } else if (isSkirt) {
    location = [
      'Cintura Alta / Pretina',
      'Caderas y Muslos',
      'Línea de la Rodilla',
      'Pantorrilla (Largo Midi)',
      'Dobladillo / Borde Inferior',
      'Abertura Lateral / Frontal'
    ];
  } else if (isPants) {
    location = [
      'Pretina / Cintura Frontal',
      'Caderas y Glúteos',
      'Muslos Frontales y Laterales',
      'Rodillas',
      'Pantorrillas / Gemelos',
      'Puños / Dobladillo en Tobillo'
    ];
  } else if (isSocks) {
    location = [
      'Muslos Altos (Borde de Liga)',
      'Rodillas y Pantorrillas',
      'Tobillos y Empeine',
      'Planta y Talón del Pie',
      'Piernas Completas (Pantimedias)'
    ];
  } else if (isBra) {
    location = [
      'Copas / Busto Frontal',
      'Bajo Busto (Banda de Soporte)',
      'Tirantes en Hombros',
      'Escote Central',
      'Laterales del Torso',
      'Espalda (Cierre)'
    ];
  } else if (isPanties) {
    location = [
      'Cintura Frontal',
      'Caderas Laterales / Tiras',
      'Zona Pélvica Frontal',
      'Glúteos / Cobertura Trasera',
      'Línea de la Ingle'
    ];
  } else if (isShoes) {
    location = [
      'Puntera del Calzado',
      'Empeine / Zona de Cordones',
      'Talón y Contrafuerte',
      'Tobillos y Caña',
      'Suela y Plataforma / Tacón'
    ];
  } else if (isDress) {
    location = [
      'Corpiño / Pecho',
      'Cintura y Caderas',
      'Falda Frontal',
      'Abertura Lateral',
      'Mangas y Hombros',
      'Cola Trasera'
    ];
  } else if (isJacket) {
    location = [
      'Torso Completo',
      'Hombros y Solapas',
      'Mangas y Puños',
      'Pecho Izquierdo (Insignia)',
      'Espalda Completa',
      'Cintura / Faldón Inferior'
    ];
  } else if (isTop) {
    location = [
      'Pecho / Busto Frontal',
      'Cuello y Escote',
      'Hombros y Clavícula',
      'Mangas y Puños',
      'Cintura y Abdomen',
      'Espalda'
    ];
  }

  // --------------------------------------------------------------------------
  // 11. DETAIL LOCATION MAP (Exact Position Anchors per Specific Detail)
  // --------------------------------------------------------------------------
  const locationMap: Record<string, string[]> = {};

  for (const effDetail of details) {
    let locs: string[] = [];

    if (effDetail.includes('Keyhole') || effDetail.includes('Lágrima Central')) {
      locs = ['Pechera Central con Abertura Lágrima', 'Escote Frontal Superior', 'Cuello y Escote'];
    } else if (effDetail.includes('Transparencia') || effDetail.includes('Translúcid') || effDetail.includes('Gasa') || effDetail.includes('Tul')) {
      locs = isShoes
        ? ['Tiras y Empeine', 'Inserciones Laterales de Malla', 'Tacón Translúcido de Lucita / Acrílico', 'Puntera Translúcida']
        : isDress
        ? ['Escote y Clavícula', 'Mangas Completas', 'Espalda', 'Paneles Laterales de Cintura', 'Sobrefalda Flotante', 'Abertura de Falda']
        : isTop
        ? ['Mangas y Hombros', 'Escote y Pechera', 'Espalda Completa', 'Laterales del Torso', 'Abdomen']
        : isJacket
        ? ['Mangas de Organza', 'Espalda Translúcida', 'Sobrecapa Caída', 'Solapas']
        : isSkirt
        ? ['Sobrefalda Flotante', 'Paneles Laterales', 'Volante Inferior', 'Capa Superior de Tul']
        : isPants
        ? ['Paneles Laterales en Muslos', 'Pernera Inferior Translúcida', 'Aberturas Pélvicas']
        : isSocks
        ? ['Caña Completa (Pantimedias)', 'Empeine y Tobillo', 'Muslo Superior']
        : isBra || isPanties
        ? ['Copas Balconette', 'Paneles Laterales', 'Pechera Central', 'Glúteos y Caderas']
        : isAcc
        ? ['Velo Flotante', 'Cintas Caídas', 'Chales de Muñeca', 'Bufanda / Foulard']
        : ['Paneles Laterales', 'Hombros y Escote', 'Mangas', 'Espalda', 'Bordes y Dobladillos'];
    } else if (effDetail.includes('Drapeado Griego') || effDetail.includes('Desértico') || effDetail.includes('Gasa Fluida')) {
      locs = isSkirt || isBottom
        ? ['Caderas y Caída Envolvente de la Falda', 'Pliegues Frontales de la Falda', 'Abertura Frontal/Lateral']
        : isTop || isDress
        ? ['Pecho Cruzado y Clavículas', 'Torso Frontal y Escote', 'Caída Fluida sobre Costados']
        : ['Cuerpo Principal de la Prenda', 'Pliegues Frontales'];
    } else if (effDetail.includes('Cabujones') || effDetail.includes('Piedra preciosa Pulida') || effDetail.includes('Cabujón')) {
      locs = isNeckAccessory
        ? ['Centro del Pectoral de Regalia', 'Placas Articuladas sobre Clavículas', 'Gargantilla Frontal']
        : isBeltAccessory
        ? ['Medallón Central de la Faja Pélvica', 'Broches Laterales en Cadera', 'Engastes en Cadenas']
        : isHeadAccessory
        ? ['Cabujón Central en la Frente', 'Engastes en Cadenas sobre Coronilla']
        : isGloveAccessory
        ? ['Brazalete de Bíceps', 'Manguitos Grabados de Antebrazo', 'Engastes Interconectados']
        : ['Pechera Central y Escote', 'Laterales de Cintura y Caderas', 'Broches Principales'];
    } else if (effDetail.includes('Chales de Gasa') || effDetail.includes('Suspendidos de los Brazaletes') || effDetail.includes('Chales')) {
      locs = ['Suspendidos de los Brazaletes de Bíceps', 'Laterales de los Brazos Ondulando al Aire', 'Antebrazos y Manos'];
    } else if (effDetail.includes('Pectoral Rígido') || effDetail.includes('Placas de Metal Articuladas')) {
      locs = ['Gargantilla y Base del Cuello', 'Clavículas y Escote Superior', 'Lágrimas Colgantes sobre Pecho'];
    } else if (effDetail.includes('Tocado de Cadenas') || effDetail.includes('Velo de Gasa Facial')) {
      locs = ['Coronilla y Cadenas Entrelazadas', 'Frente sobre el Entrecejo', 'Velo Translúcido sobre Nariz y Boca'];
    } else if (effDetail.includes('Cinturón Ceremonial') || effDetail.includes('Cadenas Escalonadas con Broche')) {
      locs = ['Banda Pélvica y Cintura Baja', 'Hileras de Cadenas Colgantes en Caderas', 'Dijes de Hojas sobre Muslos'];
    } else if (effDetail.includes('Manguitos Grabados') || effDetail.includes('Brazalete de Bíceps')) {
      locs = ['Bíceps Superior', 'Antebrazo Completo', 'Anillos Interconectados en Mano'];
    } else if (effDetail.includes('Faldón Envolvente') || effDetail.includes('Envolvente')) {
      locs = ['Caderas y Pretina Pélvica', 'Abertura Frontal/Lateral al Muslo', 'Caída Fluida Asimétrica'];
    } else if (effDetail.includes('Espalda Descubierta con Cadenas')) {
      locs = ['Línea Central de la Espalda', 'Omóplatos y Cintura Posterior', 'Cadenas Doradas Cruzadas'];
    } else if (effDetail.includes('Mangas Poeta') || effDetail.includes('Obispo') || effDetail.includes('Desprendidas')) {
      locs = ['Brazos Completos / Mangas Desprendidas', 'Puños de las Mangas con Volantes', 'Antebrazos y Muñecas'];
    } else if (effDetail.includes('Cremallera Metálica Expuesta') || effDetail.includes('Espalda Completa')) {
      locs = ['Línea Central de la Espalda Completa', 'Espalda desde Cuello hasta Cadera', 'Cierre Posterior'];
    } else if (effDetail.includes('Abertura Lateral Alta') || effDetail.includes('Costura Invisible') || effDetail.includes('Cola Fluida')) {
      locs = ['Lateral Izquierdo Alto del Muslo', 'Lateral Derecho Alto del Muslo', 'Falda con Caída a la Cola'];
    } else if (effDetail.includes('Orejas') || effDetail.includes('Capucha con Orejas')) {
      locs = ['Cúspide de la Capucha (Superiores)', 'Laterales Caídos de la Capucha', 'Diadema / Tocado Superior'];
    } else if (effDetail.includes('Peluche') || effDetail.includes('Borreguito') || effDetail.includes('Borrego') || effDetail.includes('Piel')) {
      locs = isShoes
        ? ['Borde Superior de la Caña', 'Lengüeta y Empeine']
        : isPants
        ? ['Borde de la Pretina de la Cintura', 'Borde de los Bajos / Tobillos']
        : ['Borde de las Sisas de los Hombros y Cuello', 'Cuello y Escote', 'Borde de la Capucha', 'Puños de las Mangas', 'Borde Inferior / Dobladillo'];
    } else if (effDetail.includes('Pompones')) {
      locs = ['Extremos de Cordones de la Capucha', 'Costados / Cordones Colgantes', 'Dobladillo Inferior'];
    } else if (effDetail.includes('Lazos') || effDetail.includes('Listones') || effDetail.includes('Lazo')) {
      if (isSocks) {
        locs = ['Borde Superior Exterior del Muslo', 'Parte Posterior del Muslo', 'Tobillo Frontal'];
      } else if (isShoes) {
        locs = ['Lazada Frontal en Empeine', 'Tobillos / Caña Trasera'];
      } else if (isSkirt || isBottom) {
        locs = ['Centro de la Pretina Frontal', 'Laterales de las Caderas', 'Abertura de la Falda'];
      } else if (isBeltAccessory) {
        locs = ['Laterales de las Caderas', 'Broches de Ligas de Muslo', 'Centro Pélvico Frontal'];
      } else if (isHeadAccessory) {
        locs = ['Laterales del Cabello (Twin Tails)', 'Banda de la Diadema', 'Laterales de la Cabeza'];
      } else {
        locs = ['Escote Frontal / Pechera', 'Puños de las Mangas', 'Borde de la Capucha', 'Espalda Cruzada'];
      }
    } else if (effDetail.includes('Escamas')) {
      locs = ['Superficie Frontal del Pecho / Busto Completo', 'Hombros y Pechera Frontal', 'Flancos de la Cadera', 'Paneles de Protección Frontal', 'Hombreras'];
    } else if (effDetail.includes('Bajo Corto al Busto')) {
      locs = ['Borde Inferior / Bajo Busto Dejando Abdomen Totalmente al Descubierto', 'Línea Bajo Busto Frontal'];
    } else if (effDetail.includes('Arnés de Doble Correa') || effDetail.includes('Correa')) {
      locs = isPants ? ['Laterales y Frontal de Ambos Muslos', 'Pretina de Cintura', 'Laterales de las Caderas'] : ['Muslos Frontales y Laterales', 'Pretina de Cintura'];
    } else if (effDetail.includes('Vendas de Tela Rústica') || effDetail.includes('Vendas')) {
      locs = ['Antebrazo Completo y Muñecas Bajo Muñequeras', 'Dorso de la Mano y Nudillos', 'Muñecas y Manos'];
    } else if (effDetail.includes('Costuras Reforzadas de Combate')) {
      locs = ['Entrepierna y Ambas Rodillas', 'Costuras Laterales y Dobladillo', 'Muslos Frontales'];
    } else if (effDetail.includes('Broches') || effDetail.includes('Conejito')) {
      locs = ['Broches Frontales en Ligas de Muslo', 'Herrajes Laterales en Caderas', 'Centro del Escote'];
    } else if (effDetail.includes('Corbata') || effDetail.includes('Camisero')) {
      locs = ['Bajo la Abertura del Cuello', 'Escote Frontal Central'];
    } else if (effDetail.includes('Mangas Extralargas')) {
      locs = ['Puños Caídos Cubriendo las Manos'];
    } else if (effDetail.includes('Patchwork') || effDetail.includes('Costuras Vistas')) {
      locs = ['Cuerpo Completo de la Prenda', 'Ensambles y Costuras Exteriores'];
    } else if (effDetail.includes('Estampados') || effDetail.includes('Fresas')) {
      locs = ['Panel Frontal del Muslo', 'Lateral Exterior de la Pierna', 'Pecho / Frente'];
    } else if (effDetail.includes('Plataforma')) {
      locs = ['Suela Completa y Cerco', 'Base Dentada Track'];
    } else if (effDetail.includes('Tiras Laterales') || effDetail.includes('Taparrabos') || effDetail.includes('Faldellín')) {
      locs = ['Flancos Pélvicos Descubiertos', 'Laterales de Cadera (Hip Straps)', 'Centro Pélvico Frontal'];
    } else if (effDetail.includes('Cuerdas Anudadas') || effDetail.includes('Abalorios Tribales')) {
      locs = ['Colgando sobre Cadera Lateral', 'Pretina de Cintura', 'Dobladillo Inferior'];
    } else if (isRing) {
      if (effDetail.includes('Gema') || effDetail.includes('Solitaria')) {
        locs = ['Chatón Central Superior', 'Engaste Elevado en Corona', 'Laterales de la Piedra'];
      } else if (effDetail.includes('Pavé') || effDetail.includes('Micro-diamantes')) {
        locs = ['A lo Largo de Toda la Banda', 'Rodeando la Gema Central (Halo)', 'Laterales del Chatón'];
      } else if (effDetail.includes('Grabado') || effDetail.includes('Rúnico') || effDetail.includes('Blasón')) {
        locs = ['Superficie del Sello Frontal', 'Cara Exterior de la Banda', 'Cara Interior Oculta (Secreto)'];
      } else if (effDetail.includes('Cadena')) {
        locs = ['Unión de Anillo a Pulsera de Muñeca', 'Conexión entre Dos Dedos Contiguos'];
      } else {
        locs = ['Banda Central', 'Borde Superior', 'Borde Inferior', 'Cara Frontal'];
      }
    } else if (isBag) {
      if (effDetail.includes('Hebillas') || effDetail.includes('Cierre')) {
        locs = ['Solapa Frontal Central', 'Correas de Ajuste Lateral', 'Anclaje de Asas de Hombro'];
      } else if (effDetail.includes('Cremalleras')) {
        locs = ['Abertura Principal Superior', 'Bolsillo Frontal Horizontal', 'Bolsillos Laterales', 'Bolsillo Antirrobo en Espalda'];
      } else if (effDetail.includes('Bolsillos') || effDetail.includes('Cargo')) {
        locs = ['Frontal Principal con Fuelle', 'Laterales para Viales/Botellas', 'Solapa Exterior'];
      } else if (effDetail.includes('Tachuelas') || effDetail.includes('Remaches')) {
        locs = ['Cuatro Esquinas Reforzadas', 'Puntos de Tensión en Asas', 'Borde Perimetral de la Solapa'];
      } else if (effDetail.includes('Cadenas') || effDetail.includes('Mosquetones')) {
        locs = ['Correa Cruzada al Hombro', 'Mosquetón de Cierre Frontal', 'Llavero Colgante Lateral'];
      } else {
        locs = ['Solapa Frontal', 'Bolsillo Principal', 'Asa Superior', 'Correa de Hombro'];
      }
    } else if (isEarring) {
      if (effDetail.includes('Gema') || effDetail.includes('Perla')) {
        locs = ['Centro del Lóbulo', 'Extremo Inferior de la Gota', 'Engaste Superior'];
      } else if (effDetail.includes('Cadenillas') || effDetail.includes('Cascada')) {
        locs = ['Colgando desde el Lóbulo al Cuello', 'Conectando Lóbulo con Cartílago Superior (Hélix)'];
      } else if (effDetail.includes('Filigrana') || effDetail.includes('Ear Cuff')) {
        locs = ['Borde del Cartílago de la Oreja (Hélix)', 'Cuerpo del Aro Principal', 'Trago'];
      } else {
        locs = ['Centro del Lóbulo', 'Borde del Aro', 'Extremo Colgante'];
      }
    } else if (isNeckAccessory) {
      if (effDetail.includes('Colgante') || effDetail.includes('Argolla') || effDetail.includes('Broche')) {
        locs = ['Centro Frontal en Escote', 'Garganta / Base del Cuello', 'Esternón'];
      } else if (effDetail.includes('Cadenas') || effDetail.includes('Cascada')) {
        locs = ['Cayendo sobre el Pecho y Busto', 'Espalda / Nuca Colgante'];
      } else if (effDetail.includes('Lazo') || effDetail.includes('Nudo')) {
        locs = ['Nudo Frontal Central', 'Lazada en la Nuca', 'Puntas Colgantes'];
      } else {
        locs = ['Centro Frontal', 'Banda del Cuello', 'Extremos'];
      }
    } else if (isSkirt) {
      if (effDetail.includes('Tablas') || effDetail.includes('Plisada')) {
        locs = ['Toda la Circunferencia de la Falda', 'Panel Frontal', 'Lateral'];
      } else if (effDetail.includes('Abertura') || effDetail.includes('Slit')) {
        locs = ['Lateral Izquierdo Alto (Muslo)', 'Lateral Derecho', 'Frontal Central', 'Doble Abertura Lateral'];
      } else if (effDetail.includes('Botones') || effDetail.includes('Cremalleras')) {
        locs = ['Hilera Central Frontal', 'Costura Lateral con Cremallera', 'Botonadura Lateral'];
      } else if (effDetail.includes('Cinturón') || effDetail.includes('Cadenas')) {
        locs = ['Pretina de la Cintura', 'De Trabilla Delantera a Bolsillo Lateral', 'Colgando sobre Cadera'];
      } else if (effDetail.includes('Encaje') || effDetail.includes('Dobladillo')) {
        locs = ['Borde Inferior Completo', 'Ribete de la Abertura Lateral', 'Borde de la Pretina'];
      } else {
        locs = ['Pretina de la Cintura', 'Dobladillo Inferior', 'Costuras Laterales', 'Abertura'];
      }
    } else if (isPants) {
      if (effDetail.includes('Bolsillos Cargo')) {
        locs = ['Laterales Exteriores de Ambos Muslos', 'Parte Frontal de Pantorrillas'];
      } else if (effDetail.includes('Roturas') || effDetail.includes('Rasgados')) {
        locs = ['Ambas Rodillas', 'Muslo Frontal Izquierdo', 'Muslo Frontal Derecho'];
      } else if (effDetail.includes('Cadenas')) {
        locs = ['De Trabilla Frontal a Bolsillo Trasero', 'Cruzada en el Lateral del Muslo'];
      } else if (effDetail.includes('Cremalleras')) {
        locs = ['Tobillos Exteriores', 'Bolsillos Delanteros con Ribete Metálico'];
      } else if (effDetail.includes('Botones') || effDetail.includes('Bragueta')) {
        locs = ['Tapeta Frontal de Botones Vistos', 'Pretina de Cintura'];
      } else {
        locs = ['Bolsillos Delanteros', 'Bolsillos Traseros', 'Rodillas', 'Dobladillo de Tobillos'];
      }
    } else if (isSocks) {
      if (effDetail.includes('Encaje') || effDetail.includes('Borde')) {
        locs = ['Banda Superior en Muslo Alto', 'Borde Superior Bajo Rodilla'];
      } else if (effDetail.includes('Costura Posterior') || effDetail.includes('Vintage')) {
        locs = ['Línea Vertical Trasera desde el Talón hasta el Muslo'];
      } else if (effDetail.includes('Lazos') || effDetail.includes('Ligas')) {
        locs = ['Borde Superior Exterior del Muslo', 'Parte Posterior del Muslo', 'Tobillo Frontal'];
      } else if (effDetail.includes('Bordado') || effDetail.includes('Floral')) {
        locs = ['Lateral Exterior de la Pantorrilla', 'Empeine y Tobillo', 'Muslo Frontal'];
      } else {
        locs = ['Borde Superior', 'Lateral de la Pierna', 'Tobillo', 'Empeine'];
      }
    } else if (isBra || isPanties) {
      if (effDetail.includes('Lazo') || effDetail.includes('Central')) {
        locs = ['Centro del Escote entre Copas', 'Centro de la Cintura Frontal', 'Caderas Laterales'];
      } else if (effDetail.includes('Tiras') || effDetail.includes('Strappy')) {
        locs = ['Sobre el Escote del Busto', 'Caderas Laterales Dobles', 'Espalda Cruzada'];
      } else if (effDetail.includes('Encaje') || effDetail.includes('Transparencias')) {
        locs = ['Borde Superior de Copas', 'Paneles Laterales', 'Centro Pélvico Frontal', 'Glúteos'];
      } else if (effDetail.includes('Ligas') || effDetail.includes('Argollas')) {
        locs = ['Unión de Tirantes con Copas', 'Tiras de Ligas en Cintura Baja', 'Bajo Busto'];
      } else {
        locs = ['Centro Frontal', 'Borde Superior', 'Laterales', 'Espalda'];
      }
    } else if (isShoes) {
      if (effDetail.includes('Cordones') || effDetail.includes('Ojetes')) {
        locs = ['Empeine Frontal Completo', 'Caña Frontal hasta el Borde Superior', 'Caña Trasera'];
      } else if (effDetail.includes('Hebillas') || effDetail.includes('Tachuelas')) {
        locs = ['Correas sobre el Empeine', 'Correa de Tobillo', 'Caña Lateral Múltiple', 'Talón y Contrafuerte'];
      } else if (effDetail.includes('Puntera') || effDetail.includes('Brogue')) {
        locs = ['Puntera y Casquillo Frontal', 'Borde de la Suela', 'Talón Posterior'];
      } else if (effDetail.includes('Cremallera')) {
        locs = ['Lateral Interior de la Caña', 'Trasera Central del Talón al Borde'];
      } else {
        locs = ['Punta', 'Empeine', 'Talón', 'Caña Lateral', 'Suela'];
      }
    } else if (isJacket) {
      if (effDetail.includes('Cremallera') || effDetail.includes('Diagonal')) {
        locs = ['Cierre Frontal Diagonal Biker', 'Bolsillos en Pecho', 'Puños de las Mangas'];
      } else if (effDetail.includes('Charreteras') || effDetail.includes('Hombros')) {
        locs = ['Ambos Hombros con Botón de Anclaje', 'Solapas Frontales'];
      } else if (effDetail.includes('Botones') || effDetail.includes('Militar')) {
        locs = ['Doble Hilera Cruzada en Pecho', 'Solapa Superior', 'Puños con 3-4 Botones'];
      } else if (effDetail.includes('Cinturón')) {
        locs = ['Pretina del Borde Inferior con Trabillas', 'Cintura Ajustada'];
      } else {
        locs = ['Solapas y Cuello', 'Pecho', 'Mangas y Puños', 'Espalda', 'Borde Inferior'];
      }
    } else if (isTop) {
      if (effDetail.includes('Carrera de Botones') || effDetail.includes('Botones')) {
        locs = ['Tapeta Frontal Completa (Cuello a Cintura)', 'Cuello Mao / Pechera', 'Puños de las Mangas'];
      } else if (effDetail.includes('Jabot') || effDetail.includes('Volantes')) {
        locs = ['Escote Frontal en Cascada', 'Cuello / Gorguera', 'Puños de las Mangas'];
      } else if (effDetail.includes('Corsé') || effDetail.includes('Ballenas')) {
        locs = ['Varillas Verticales en Torso', 'Lazado Trasero Entrelazado en Espalda', 'Copas del Busto'];
      } else {
        locs = ['Pecho / Busto', 'Cuello y Solapas', 'Mangas y Puños', 'Espalda', 'Borde Inferior'];
      }
    } else {
      locs = ['Frontal Principal', 'Bordes y Remates', 'Laterales', 'Puntos de Cierre'];
    }

    if (locs.length > 0) {
      locationMap[effDetail] = locs;
    }
  }

  // --------------------------------------------------------------------------
  // 12. PATTERNS, EMBLEMS & VFX
  // --------------------------------------------------------------------------
  let pattern = ['Liso / Sólido', 'Rayas', 'Cuadros / Tartán', 'Lunares', 'Floral', 'Geométrico', 'Animal Print', 'Logotipo / Texto', 'Camuflaje', 'Degradado / Ombré'];

  let emblem = ['Ninguno', 'Escudo Real / Heráldica', 'Sello Mágico / Runa', 'Logotipo Cyberpunk / Corp', 'Símbolo Religioso / Culto', 'Calavera / Jolly Roger', 'Marca de Bestia / Dragón', 'Bordado Exclusivo / Haute Couture', 'Emblema Militar / Rango'];

  let vfx = ['Ninguno', 'Desgarros / Daño de Batalla', 'Manchas de Sangre / Suciedad', 'Bordes Brillantes / Neón', 'Emanación de Humo / Sombras', 'Tejido Holográfico / Glitch', 'Partículas / Polvo Estelar', 'Envuelto en Llamas / Escarcha', 'Goteo Etéreo', 'Mojado / Empapado'];

  if (isShoes) {
    emblem = ['Ninguno', 'Logo Deportivo / Marca', 'Sello en Suela', 'Insignia Metálica'];
    vfx = ['Ninguno', 'Huellas Ardientes / Mágicas', 'Suela Iluminada (Neón)', 'Manchas de Barro / Sangre', 'Desgastado por el Tiempo'];
  } else if (isAcc) {
    vfx = ['Ninguno', 'Aura Mágica', 'Brillo Pulsante', 'Glitch Digital', 'Goteo Etéreo', 'Oxidado / Corrupto', 'Roto / Dañado'];
  }

  return {
    cut,
    length,
    sleeve,
    material,
    finish,
    details,
    variation,
    layer,
    location,
    locationMap,
    pattern,
    emblem,
    vfx,
    neckline,
    gemTypes: ACCESSORY_GEM_TYPES_ENGINE,
    engravings: ACCESSORY_ENGRAVINGS_ENGINE,
    sizeScales: ACCESSORY_SIZE_SCALES_ENGINE,
    fitStyles: ACCESSORY_FIT_STYLES_ENGINE,
    accessoryStyles: [
      'Fino & Delicado',
      'Grueso & Chunky',
      'Multicapa / Doble',
      'Rígido / Estructurado',
      'Fluido / Colgante',
      'Minimalista Moderno',
      'Vintage / Victoriano',
      'Gótico / Oscuro',
      'Cyberpunk / Táctico',
      'Ornamental / Barroco'
    ],
    shoeSoles: SHOE_SOLES,
    shoeHeels: SHOE_HEELS
  };
}
