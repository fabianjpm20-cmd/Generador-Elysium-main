export interface RoleRelationshipSuggestion {
  targetCharacterName: string;
  relationshipType: string;
  interactionDynamic: string;
  roleHint?: string;
  feelingsTowards?: string;
  opinionOn?: string;
}

export interface RoleBehaviorByRank {
  withAuthority: string;
  withSubordinates: string;
  withPeers?: string;
  withFriends?: string;
  withStrangers: string;
  withEnemies: string;
  withAuthoritySuggestions?: string[];
  withSubordinatesSuggestions?: string[];
  withPeersSuggestions?: string[];
  withFriendsSuggestions?: string[];
  withStrangersSuggestions?: string[];
  withEnemiesSuggestions?: string[];
}

export interface RoleBackgroundProfile {
  roleName: string;
  category: string;
  specializedSkills: string[];
  suggestedRelationships: RoleRelationshipSuggestion[];
  behaviorByRank: RoleBehaviorByRank;
  recommendedVoiceTone: string;
  recommendedSpeechStyle: string;
  catchphrase: string;
  habits: string[];
}

export const CANONICAL_ROLE_BACKGROUND_DATA: Record<string, RoleBackgroundProfile> = {
  // ==========================================
  // CIVILES
  // ==========================================
  'Civil Genérico': {
    roleName: 'Civil Genérico',
    category: 'Civiles',
    specializedSkills: [
      'Negociación vecinal y trueque cotidiano',
      'Conocimiento de calles y rumores locales',
      'Cocina tradicional y conservación de alimentos',
      'Remiendos básicos y mantenimiento hogareño',
      'Sentido común y cautela ante peligros'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Alcalde o Comisario del Pueblo',
        relationshipType: 'Superior / Comandante',
        interactionDynamic: 'Trato respetuoso y humilde; acata normativas locales buscando evitar conflictos.',
        roleHint: 'Figura de Autoridad Local'
      },
      {
        targetCharacterName: 'Comerciante de la Plaza',
        relationshipType: 'Aliado/a de Confianza',
        interactionDynamic: 'Camaradería cordial con charlas amenas y favores cotidianos.',
        roleHint: 'Vecino / Amigo'
      },
      {
        targetCharacterName: 'Recaudador de Tributos',
        relationshipType: 'Rival Jurado / Competidor',
        interactionDynamic: 'Tensión contenida y desconfianza por excesivos impuestos.',
        roleHint: 'Rival Financiero'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Inclinación respetuosa y timidez; habla solo cuando se le solicita para no llamar la atención.',
      withSubordinates: 'Trato cercano, afectuoso y paciente con aprendices y familiares jóvenes.',
      withStrangers: 'Cautela inicial, amabilidad prudente y mirada curiosa ante forasteros armados.',
      withEnemies: 'Evasión inmediata, búsqueda de refugio o mediación pacífica si es acorralado.',
      withAuthoritySuggestions: [
        'Inclinación respetuosa y timidez; habla solo cuando se le solicita para no llamar la atención.',
        'Respeto pragmático buscando salvaguardar su negocio o vivienda de disputas oficiales.'
      ],
      withSubordinatesSuggestions: [
        'Trato cercano, afectuoso y paciente con aprendices y familiares jóvenes.',
        'Guía protectora transmitiendo oficios sencillos y consejos de vida.'
      ],
      withStrangersSuggestions: [
        'Cautela inicial, amabilidad prudente y mirada curiosa ante forasteros armados.',
        'Hospitalidad sencilla ofreciendo asiento y agua mientras evalúa sus intenciones.'
      ],
      withEnemiesSuggestions: [
        'Evasión inmediata, búsqueda de refugio o mediación pacífica si es acorralado.',
        'Defensa desesperada con lo que tenga a mano para proteger su hogar.'
      ]
    },
    recommendedVoiceTone: 'Cálido, paternal y reconfortante',
    recommendedSpeechStyle: 'Coloquial y callejero con jerga gremial o de bajos fondos',
    catchphrase: '«Un día tranquilo de trabajo es la mayor de las bendiciones.»',
    habits: [
      'Acomoda las cosas a su alrededor de manera constante',
      'Saluda con una leve reverencia a cada persona que cruza',
      'Revisa su bolsa de monedas discretamente'
    ]
  },
  'Aldeano': {
    roleName: 'Aldeano',
    category: 'Civiles',
    specializedSkills: [
      'Agricultura, ciclos de siembra y cosecha',
      'Cría de ganado y cuidado animal',
      'Predicción del clima por observación natural',
      'Elaboración de herramientas de labranza',
      'Defensa comunitaria con horcas y garrotes'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Anciano Líder de la Aldea',
        relationshipType: 'Mentor/a & Maestro/a',
        interactionDynamic: 'Veneración por su sabiduría ancestral y obediencia a sus consejos.',
        roleHint: 'Patriarca de la Aldea'
      },
      {
        targetCharacterName: 'Cazador del Bosque',
        relationshipType: 'Aliado/a de Confianza',
        interactionDynamic: 'Intercambio constante de granos por pieles y carne fresca.',
        roleHint: 'Suministrador Comunal'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Sumisión humilde con reverencia campesina y mirada baja ante señores feudales.',
      withSubordinates: 'Fraternidad comunitaria y trabajo hombro con hombro en el campo.',
      withStrangers: 'Mirada recelosa de aldeano, desconfiando de forasteros con armadura brillante.',
      withEnemies: 'Solidaridad gremial y atrincheramiento en el poblado con antorchas y aperos.',
      withAuthoritySuggestions: [
        'Sumisión humilde con reverencia campesina y mirada baja ante señores feudales.',
        'Ruego respetuoso por protección ante asaltantes y bestias.'
      ],
      withSubordinatesSuggestions: [
        'Fraternidad comunitaria y trabajo hombro con hombro en el campo.',
        'Paciencia pedagógica enseñando el laboreo de la tierra.'
      ],
      withStrangersSuggestions: [
        'Mirada recelosa de aldeano, desconfiando de forasteros con armadura brillante.',
        'Curiosidad contenida preguntando discretamente de qué comarca provienen.'
      ],
      withEnemiesSuggestions: [
        'Solidaridad gremial y atrincheramiento en el poblado con antorchas y aperos.',
        'Huida organizada hacia los graneros comunales o bosques circundantes.'
      ]
    },
    recommendedVoiceTone: 'Áspero, curtido y ronco',
    recommendedSpeechStyle: 'Coloquial y callejero con jerga gremial o de bajos fondos',
    catchphrase: '«La tierra no da fruto sin sudor ni paciencia.»',
    habits: [
      'Mira frecuentemente al cielo calculando las horas de luz',
      'Limpia sus manos curtidas en su mandil de trabajo',
      'Se santigua ante los santuarios del camino'
    ]
  },
  'Ciudadano': {
    roleName: 'Ciudadano',
    category: 'Civiles',
    specializedSkills: [
      'Navegación por distritos y callejones urbanos',
      'Leyes cívicas y normativas de impuestos',
      'Conocimiento de tabernas, gremios y mercados',
      'Regateo callejero y compraventa básica',
      'Alfabetización y redacción de peticiones cívicas'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Capitán de la Guardia Urbana',
        relationshipType: 'Superior / Comandante',
        interactionDynamic: 'Cooperación cívica prudente, evitando meterse en líos de patrullas.',
        roleHint: 'Seguridad de Distrito'
      },
      {
        targetCharacterName: 'Tabernero del Distrito',
        relationshipType: 'Aliado/a de Confianza',
        interactionDynamic: 'Confidencias nocturnas sobre eventos políticos y rumores de palacio.',
        roleHint: 'Informante Barrial'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Protocolo cívico educado pero firme en sus derechos estipulados por el fuero urbano.',
      withSubordinates: 'Exigencia de puntualidad y buenas maneras en el bullicio de la ciudad.',
      withStrangers: 'Familiaridad cosmopolita; acostumbra ver toda clase de razas y viajeros.',
      withEnemies: 'Grito de alarma pidiendo auxilio a la guardia o contratación de escoltas.',
      withAuthoritySuggestions: [
        'Protocolo cívico educado pero firme en sus derechos estipulados por el fuero urbano.',
        'Diplomacia cordial utilizando títulos honoríficos apropiados.'
      ],
      withSubordinatesSuggestions: [
        'Exigencia de puntualidad y buenas maneras en el bullicio de la ciudad.',
        'Paternalismo metropolitano compartiendo consejos sobre cómo sobrevivir en la urbe.'
      ],
      withStrangersSuggestions: [
        'Familiaridad cosmopolita; acostumbra ver toda clase de razas y viajeros.',
        'Evaluación rápida de su vestimenta para inferir su clase social.'
      ],
      withEnemiesSuggestions: [
        'Grito de alarma pidiendo auxilio a la guardia o contratación de escoltas.',
        'Evasión entre la multitud aprovechando el laberinto de callejones.'
      ]
    },
    recommendedVoiceTone: 'Juvenil, vibrante y enérgico',
    recommendedSpeechStyle: 'Coloquial y callejero con jerga gremial o de bajos fondos',
    catchphrase: '«En esta ciudad, quien no tiene ojos en la espalda acaba sin monedas.»',
    habits: [
      'Camina a paso ligero esquivando carretas y transeúntes',
      'Toca discretamente el bolsillo interior de su chaqueta',
      'Comenta las últimas proclamas fijadas en las plazas'
    ]
  },
  'Comerciante': {
    roleName: 'Comerciante',
    category: 'Civiles',
    specializedSkills: [
      'Tasación de gemas, sedas, especias y metales',
      'Negociación persuasiva y psicología de ventas',
      'Rutas de caravanas y logística de transporte',
      'Cálculo contable y libros de cuentas',
      'Detección de monedas falsificadas y contrabando'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Líder del Gremio Mercante',
        relationshipType: 'Superior / Comandante',
        interactionDynamic: 'Alabanzas interesadas y cumplimiento estricto de aranceles gremiales.',
        roleHint: 'Maestro Gremial'
      },
      {
        targetCharacterName: 'Guardaespaldas Mercenario',
        relationshipType: 'Protegido/a / Custodiado/a',
        interactionDynamic: 'Puntualidad en los pagos a cambio de protección intransigente en ruta.',
        roleHint: 'Escolta Contratado'
      },
      {
        targetCharacterName: 'Comerciante Rival de la Competencia',
        relationshipType: 'Rival Jurado / Competidor',
        interactionDynamic: 'Sonrisas hipócritas en público y guerra despiadada de precios en privado.',
        roleHint: 'Competidor Mercantil'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Zalamería elocuente, regalos estratégicos y reverencias calculadas para obtener licencias.',
      withSubordinates: 'Supervisión implacable de inventarios con promesas de primas si las ventas prosperan.',
      withStrangers: 'Sonrisa radiante, trato de «distinguido cliente» e identificación instantánea de su presupuesto.',
      withEnemies: 'Bloqueo comercial, monopolio de suministros y contratación de saboteadores discretos.',
      withAuthoritySuggestions: [
        'Zalamería elocuente, regalos estratégicos y reverencias calculadas para obtener licencias.',
        'Presentación impecable de registros contables y pago puntual de diezmos.'
      ],
      withSubordinatesSuggestions: [
        'Supervisión implacable de inventarios con promesas de primas si las ventas prosperan.',
        'Reprimendas calculadas por mermas y elogios ruidosos ante ventas jugosas.'
      ],
      withStrangersSuggestions: [
        'Sonrisa radiante, trato de «distinguido cliente» e identificación instantánea de su presupuesto.',
        'Halagos a su buen gusto para inducir la compra de artículos selectos.'
      ],
      withEnemiesSuggestions: [
        'Bloqueo comercial, monopolio de suministros y contratación de saboteadores discretos.',
        'Frialdad cordial: «Los negocios son negocios, nada personal.»'
      ]
    },
    recommendedVoiceTone: 'Melifluo, seductor y persuasivo',
    recommendedSpeechStyle: 'Técnico, metódico y analítico (orientado a datos, lógica y precisión)',
    catchphrase: '«Todo en esta vida tiene un precio justo; solo hay que saber encontrarlo.»',
    habits: [
      'Juega con una moneda de oro haciéndola girar entre los nudillos',
      'Apunta cada gasto minúsculo en un librito forrado en seda',
      'Sonríe con brillo en los ojos antes de soltar una oferta'
    ]
  },
  'Artesano': {
    roleName: 'Artesano',
    category: 'Civiles',
    specializedSkills: [
      'Herrería, carpintería fina o curtido de pieles',
      'Diseño estructural y grabado en relieve',
      'Mantenimiento de herramientas de precisión',
      'Identificación de pureza de materiales y aleaciones',
      'Creación de piezas personalizadas por encargo'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Maestro de Taller Retirado',
        relationshipType: 'Mentor/a & Maestro/a',
        interactionDynamic: 'Gratitud eterna por las técnicas secretas transmitidas de generación en generación.',
        roleHint: 'Maestro Artesano'
      },
      {
        targetCharacterName: 'Aprendiz de Forja/Taller',
        relationshipType: 'Aprendiz / Pupilo/a',
        interactionDynamic: 'Exigencia rigurosa en los acabados pero cuidado paternal de su formación.',
        roleHint: 'Joven Aprendiz'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Orgullo gremial templado con respeto; defiende el valor de su oficio sin someterse a caprichos absurdos.',
      withSubordinates: 'Paciencia en la enseñanza, corrigiendo la postura de manos y el manejo de herramientas.',
      withStrangers: 'Evaluación rápida de la calidad de sus ropajes y armas antes de entablar conversación.',
      withEnemies: 'Frialdad pétrea; rehusará forjar o reparar cualquier artefacto para sus adversarios.',
      withAuthoritySuggestions: [
        'Orgullo gremial templado con respeto; defiende el valor de su oficio sin someterse a caprichos absurdos.',
        'Presentación técnica minuciosa de las obras encargadas por la corte.'
      ],
      withSubordinatesSuggestions: [
        'Paciencia en la enseñanza, corrigiendo la postura de manos y el manejo de herramientas.',
        'Demostración práctica silenciosa: «Observa el golpe, no el martillo.»'
      ],
      withStrangersSuggestions: [
        'Evaluación rápida de la calidad de sus ropajes y armas antes de entablar conversación.',
        'Trato sobrio y profesional centrado en medidas, materiales y plazos de entrega.'
      ],
      withEnemiesSuggestions: [
        'Frialdad pétrea; rehusará forjar o reparar cualquier artefacto para sus adversarios.',
        'Uso contundente de las herramientas pesadas de taller como armas defensivas.'
      ]
    },
    recommendedVoiceTone: 'Grave, profundo y resonante',
    recommendedSpeechStyle: 'Directo, rudo y sin rodeos (marcial, lacónico, órdenes tajantes)',
    catchphrase: '«El buen trabajo no necesita adornos para demostrar su fuerza.»',
    habits: [
      'Inspecciona las superficies pasando el pulgar para sentir la rugosidad',
      'Se remanga las ropas antes de cualquier tarea manual',
      'Golpea levemente los metales para escuchar el tono de templado'
    ]
  },

  // ==========================================
  // SERVICIO Y ACADEMIA
  // ==========================================
  'A1 Maid de Mansión': {
    roleName: 'A1 Maid de Mansión',
    category: 'Servicio y Academia',
    specializedSkills: [
      'Etiqueta aristocrática y servicio de té imperial',
      'Limpieza impecable y orden métrico de recintos',
      'Sigilo doméstico y discreción ante secretos de estado',
      'Defensa cuerpo a cuerpo con utensilios o armas ocultas',
      'Primeros auxilios y confort para la nobleza'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Amo/a o Señor/a de la Casa',
        relationshipType: 'Superior / Comandante',
        interactionDynamic: 'Devoción incondicional, reverencia perfecta y anticipación a cada uno de sus deseos.',
        roleHint: 'Señor/a de la Mansión'
      },
      {
        targetCharacterName: 'Mayordomo Principal',
        relationshipType: 'Mentor/a & Maestro/a',
        interactionDynamic: 'Disciplina marcial impecable y respeto absoluto por la jerarquía doméstica.',
        roleHint: 'Superior Inmediato'
      },
      {
        targetCharacterName: 'Espía Infiltrado en la Mansión',
        relationshipType: 'Némesis / Enemigo Mortal',
        interactionDynamic: 'Mirada gélida y vigilancia silenciosa tras cada puerta y cortinaje.',
        roleHint: 'Amenaza al Linaje'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Reverencia de 45 grados, mirada baja, tono susurrante y sumisión ejecutiva intachable.',
      withSubordinates: 'Corrección estricta de posturas y modales con una dulzura ligeramente intimidante.',
      withStrangers: 'Cortesía de porcelana; sonrisa impecable pero distancia infranqueable.',
      withEnemies: 'Frialdad letal; eliminará cualquier amenaza para sus señores sin arrugar su cofia.',
      withAuthoritySuggestions: [
        'Reverencia de 45 grados, mirada baja, tono susurrante y sumisión ejecutiva intachable.',
        'Anticipación meticulosa sirviendo antes de que la orden sea siquiera formulada.'
      ],
      withSubordinatesSuggestions: [
        'Corrección estricta de posturas y modales con una dulzura ligeramente intimidante.',
        'Guía rigurosa en el protocolo de servicio de cubertería de plata y té.'
      ],
      withStrangersSuggestions: [
        'Cortesía de porcelana; sonrisa impecable pero distancia infranqueable.',
        'Interrogatorio sutil disfrazado de amable bienvenida mientras evalúa posibles peligros.'
      ],
      withEnemiesSuggestions: [
        'Frialdad letal; eliminará cualquier amenaza para sus señores sin arrugar su cofia.',
        'Mirada inexpresiva mientras desenvaina armas ocultas bajo la falda de volantes.'
      ]
    },
    recommendedVoiceTone: 'Suave, susurrante y aterciopelado',
    recommendedSpeechStyle: 'Registro formal y cortesano de alta alcurnia (uso de usted, protocolo impecable)',
    catchphrase: '«Todo se encuentra dispuesto según vuestra distinguida voluntad.»',
    habits: [
      'Alisa los pliegues de su delantal con ambas manos al terminar de hablar',
      'Inclina la cabeza con sincronización perfecta al recibir una orden',
      'Camina con pasos insonoros deslizándose por las esquinas'
    ]
  },
  'A2 Mayordomo Principal': {
    roleName: 'A2 Mayordomo Principal',
    category: 'Servicio y Academia',
    specializedSkills: [
      'Dirección y protocolo de banquetes y recepciones reales',
      'Gestión de personal de servicio y finanzas domésticas',
      'Sommelier y catador de venenos en vinos nobles',
      'Combate defensivo y desarme con guantes blancos',
      'Custodia de los secretos más oscuros de la dinastía'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Patriarca de la Dinastía',
        relationshipType: 'Superior / Comandante',
        interactionDynamic: 'Lealtad forjada durante décadas; consejero en la sombra de máxima confianza.',
        roleHint: 'Cabeza de Familia'
      },
      {
        targetCharacterName: 'Joven Heredero/a Rebelde',
        relationshipType: 'Protegido/a / Custodiado/a',
        interactionDynamic: 'Paciencia infinita y severidad paternal disimulada bajo estricta cortesía.',
        roleHint: 'Heredero/a al Cargo'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Dignidad aristocrática subordinada, tono solemne y discreción total.',
      withSubordinates: 'Autoridad incuestionable ejercida con un solo arqueo de ceja o chasquido de dedos.',
      withStrangers: 'Filtro infranqueable; analiza linaje, intenciones y modales antes de permitir el paso.',
      withEnemies: 'Desdén refinado; neutraliza amenazas con eficiencia quirúrgica sin elevar la voz.',
      withAuthoritySuggestions: [
        'Dignidad aristocrática subordinada, tono solemne y discreción total.',
        'Consejo prudente susurrado al oído en momentos de vacilación política.'
      ],
      withSubordinatesSuggestions: [
        'Autoridad incuestionable ejercida con un solo arqueo de ceja o chasquido de dedos.',
        'Inspección de guante blanco en busca de la menor mota de polvo o descuido.'
      ],
      withStrangersSuggestions: [
        'Filtro infranqueable; analiza linaje, intenciones y modales antes de permitir el paso.',
        'Cortesía glacial que deja claro quién manda en este palacio.'
      ],
      withEnemiesSuggestions: [
        'Desdén refinado; neutraliza amenazas con eficiencia quirúrgica sin elevar la voz.',
        '«Lamento informarle que su presencia ya no es tolerada en estos terrenos.»'
      ]
    },
    recommendedVoiceTone: 'Grave, profundo y resonante',
    recommendedSpeechStyle: 'Registro formal y cortesano de alta alcurnia (uso de usted, protocolo impecable)',
    catchphrase: '«La discreción y la excelencia no son opciones, sino nuestro deber primordial.»',
    habits: [
      'Ajusta con precisión milimétrica su reloj de bolsillo',
      'Retira pelusas invisibles de la solapa con los guantes inmaculados',
      'Mantiene la espalda perfectamente recta en cualquier circunstancia'
    ]
  },
  'A3 Artificiero': {
    roleName: 'A3 Artificiero',
    category: 'Servicio y Academia',
    specializedSkills: [
      'Mecatrónica de autómatas y prótesis biónicas',
      'Alquimia explosiva y compuestos pirotécnicos',
      'Mantenimiento de catalizadores de éter y núcleos arcanos',
      'Desactivación de trampas mecánicas complejas',
      'Invención de artefactos tácticos experimentales'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Mecenas Financiero / Noble Protector',
        relationshipType: 'Superior / Comandante',
        interactionDynamic: 'Petición constante de presupuesto para nuevos inventos con entusiasmo desbordado.',
        roleHint: 'Financista de Proyectos'
      },
      {
        targetCharacterName: 'Autómata / Creación Biónica Propia',
        relationshipType: 'Protegido/a / Custodiado/a',
        interactionDynamic: 'Cuidado obsesivo como si fuera su propio hijo/a, calibrando cada engranaje.',
        roleHint: 'Obra Maestra Mecánica'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Impaciencia intelectual contenida; prefiere hablar de engranajes que de política aburrida.',
      withSubordinates: 'Instrucciones caóticas llenas de términos técnicos y fórmulas incomprensibles.',
      withStrangers: 'Fascinación por sus prótesis o armaduras, examinándolas sin pedir permiso.',
      withEnemies: 'Curiosidad científica antes de detonar un artilugio experimental en su cara.',
      withAuthoritySuggestions: [
        'Impaciencia intelectual contenida; prefiere hablar de engranajes que de política aburrida.',
        'Demostraciones ruidosas y algo peligrosas para justificar la financiación.'
      ],
      withSubordinatesSuggestions: [
        'Instrucciones caóticas llenas de términos técnicos y fórmulas incomprensibles.',
        'Gritos de advertencia: «¡No toques la palanca roja bajo ninguna circunstancia!»'
      ],
      withStrangersSuggestions: [
        'Fascinación por sus prótesis o armaduras, examinándolas sin pedir permiso.',
        'Ofertas impulsivas de modificar o mejorar su armamento.'
      ],
      withEnemiesSuggestions: [
        'Curiosidad científica antes de detonar un artilugio experimental en su cara.',
        'Risa eufórica al ver funcionar sus trampas de éter presurizado.'
      ]
    },
    recommendedVoiceTone: 'Juvenil, vibrante y enérgico',
    recommendedSpeechStyle: 'Técnico, metódico y analítico (orientado a datos, lógica y precisión)',
    catchphrase: '«Si no hace chispas ni corre el riesgo de explotar, ¡no es un invento digno!»',
    habits: [
      'Limpia sus lentes de aumento constantemente manchadas de hollín',
      'Se guarda tornillos y tuercas sueltas en cualquier bolsillo',
      'Murmura cálculos balísticos mientras gesticula con las manos'
    ]
  },
  'A4 Bibliotecario Arcano': {
    roleName: 'A4 Bibliotecario Arcano',
    category: 'Servicio y Academia',
    specializedSkills: [
      'Catalogación de grimorios prohibidos y tomos antiguos',
      'Traducción de dialectos extintos y runas arcanas',
      'Preservación de pergaminos contra fuego y humedad',
      'Detección de maldiciones latentes en textos sellados',
      'Memoria eidética y localización inmediata de saberes'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Archimago Custodio de la Gran Biblioteca',
        relationshipType: 'Superior / Comandante',
        interactionDynamic: 'Veneración por su sabiduría y debate riguroso sobre interpretaciones arcanas.',
        roleHint: 'Gran Canciller'
      },
      {
        targetCharacterName: 'Estudiante Excéntrico de Magia',
        relationshipType: 'Aprendiz / Pupilo/a',
        interactionDynamic: 'Vigilancia constante para evitar que robe o queme tomos de la sección restringida.',
        roleHint: 'Lector Problemático'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Respeto condicionado al aprecio que demuestren por los libros y la preservación del saber.',
      withSubordinates: 'Chistidos inmediatos para imponer silencio y disciplina absoluta entre los estantes.',
      withStrangers: 'Desconfianza obsesiva ante manos sucias o personas que doblan las esquinas de las páginas.',
      withEnemies: 'Uso de sellos arcanos de contención para sellar a los profanadores entre cadenas mágicas.',
      withAuthoritySuggestions: [
        'Respeto condicionado al aprecio que demuestren por los libros y la preservación del saber.',
        'Discurso erudito citando crónicas históricas para fundamentar decisiones.'
      ],
      withSubordinatesSuggestions: [
        'Chistidos inmediatos para imponer silencio y disciplina absoluta entre los estantes.',
        'Inspección meticulosa del estado de las encuadernaciones devueltas.'
      ],
      withStrangersSuggestions: [
        'Desconfianza obsesiva ante manos sucias o personas que doblan las esquinas de las páginas.',
        'Advertencias severas sobre las consecuencias de alterar el orden alfabético.'
      ],
      withEnemiesSuggestions: [
        'Uso de sellos arcanos de contención para sellar a los profanadores entre cadenas mágicas.',
        '«Habéis perturbado el silencio del santuario; vuestro castigo será eterno.»'
      ]
    },
    recommendedVoiceTone: 'Suave, susurrante y aterciopelado',
    recommendedSpeechStyle: 'Arcaico y poético (retórica shakesperiana o épica antigua)',
    catchphrase: '«El silencio es la antesala de la iluminación; no lo perturbéis con necedades.»',
    habits: [
      'Acomoda sus anteojos en el puente de la nariz con un dedo enguantado',
      'Hace el gesto de silencio con el índice frente a los labios',
      'Huele las páginas de un libro recién abierto con deleite'
    ]
  },
  'A7 Erudito': {
    roleName: 'A7 Erudito',
    category: 'Servicio y Academia',
    specializedSkills: [
      'Investigación histórica, dinastías y heráldica',
      'Astronomía, astrología y cartografía de constelaciones',
      'Lógica formal, filosofía y retórica de debate',
      'Análisis de artefactos arqueológicos y reliquias',
      'Redacción de tratados académicos y crónicas'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Rector de la Real Academia',
        relationshipType: 'Superior / Comandante',
        interactionDynamic: 'Defensa apasionada de sus tesis y rivalidad por la cátedra de investigación.',
        roleHint: 'Rector Académico'
      },
      {
        targetCharacterName: 'Explorador / Arqueólogo de Campo',
        relationshipType: 'Aliado/a de Confianza',
        interactionDynamic: 'Financiación de expediciones a cambio de tablillas y reliquias intactas.',
        roleHint: 'Proveedor de Reliquias'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Disertaciones extensas y pedagógicas, olvidando que a los gobernantes les aburre la teoría.',
      withSubordinates: 'Exigencia de rigor científico y citas bibliográficas rigurosas.',
      withStrangers: 'Interés antropológico, anotando sus modismos y dialectos en su cuaderno.',
      withEnemies: 'Demostración de su ignorancia mediante lógica implacable antes de emplear magia defensiva.',
      withAuthoritySuggestions: [
        'Disertaciones extensas y pedagógicas, olvidando que a los gobernantes les aburre la teoría.',
        'Presentación de informes densos con notas al pie y análisis comparativos.'
      ],
      withSubordinatesSuggestions: [
        'Exigencia de rigor científico y citas bibliográficas rigurosas.',
        'Correcciones constantes con tinta roja sobre cualquier borrador.'
      ],
      withStrangersSuggestions: [
        'Interés antropológico, anotando sus modismos y dialectos en su cuaderno.',
        'Preguntas insistentes sobre las leyendas de su tierra natal.'
      ],
      withEnemiesSuggestions: [
        'Demostración de su ignorancia mediante lógica implacable antes de emplear magia defensiva.',
        '«Vuestra postura carece de fundamento epistemológico y vuestra derrota es matemáticamente inevitable.»'
      ]
    },
    recommendedVoiceTone: 'Metálico / Sintético con leve eco digital o biónico',
    recommendedSpeechStyle: 'Técnico, metódico y analítico (orientado a datos, lógica y precisión)',
    catchphrase: '«Los datos y la historia no mienten; los hombres ignorantes, sí.»',
    habits: [
      'Toma notas constantes en un pequeño cuaderno de cuero desgastado',
      'Frunce el ceño analizando las paradojas de cualquier afirmación',
      'Sostiene su barbilla mientras mira al vacío meditando'
    ]
  },

  // ==========================================
  // MARCIAL Y COMBATE PESADO
  // ==========================================
  'B1 Berserker': {
    roleName: 'B1 Berserker',
    category: 'Marcial y Combate Pesado',
    specializedSkills: [
      'Furia salvaje y trance berserk que anula el dolor',
      'Maestría brutal con hachas gigantes y mandobles',
      'Supervivencia en tundras heladas y caza de megafauna',
      'Gritos de guerra ensordecedores e intimidación masiva',
      'Ruptura de escudos, defensas y armaduras pesadas'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Chamán de la Tribu Nórdica',
        relationshipType: 'Mentor/a & Maestro/a',
        interactionDynamic: 'Respeto reverente hacia los espíritus que guían su frenesí sagrado.',
        roleHint: 'Líder Espiritual Tribal'
      },
      {
        targetCharacterName: 'Guerrero Rival del Clan Enemigo',
        relationshipType: 'Rival Jurado / Competidor',
        interactionDynamic: 'Sed insaciable de cruzar filos en el campo de honor hasta que solo uno quede en pie.',
        roleHint: 'Némesis de Sangre'
      },
      {
        targetCharacterName: 'Curandero/a que atiende sus heridas',
        relationshipType: 'Aliado/a de Confianza',
        interactionDynamic: 'Paciencia inusual y docilidad contenida mientras cosen sus desgarros de batalla.',
        roleHint: 'Sanador/a de Confianza'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Solo respeta la fuerza bruta; desafiará a cualquier líder débil a un combate a muerte.',
      withSubordinates: 'Camaradería ruda, palmadas que rompen espaldas y desafíos de pulsos con hidromiel.',
      withStrangers: 'Gruñidos de advertencia y evaluación de su masa muscular con mirada predadora.',
      withEnemies: 'Carga frenética implacable con risotadas salvajes y embates demoledores.',
      withAuthoritySuggestions: [
        'Solo respeta la fuerza bruta; desafiará a cualquier líder débil a un combate a muerte.',
        'Inclinación de cabeza seca ante generales que hayan derramado sangre en primera línea.'
      ],
      withSubordinatesSuggestions: [
        'Camaradería ruda, palmadas que rompen espaldas y desafíos de pulsos con hidromiel.',
        'Exhortación al valor: «¡Si temes sangrar, vete a llorar con las ovejas!»'
      ],
      withStrangersSuggestions: [
        'Gruñidos de advertencia y evaluación de su masa muscular con mirada predadora.',
        'Provocaciones directas para medir su temple antes de ofrecerles bebida.'
      ],
      withEnemiesSuggestions: [
        'Carga frenética implacable con risotadas salvajes y embates demoledores.',
        'Grito visceral desgarrador mientras desmiembra las líneas enemigas.'
      ]
    },
    recommendedVoiceTone: 'Gutural y amenazante',
    recommendedSpeechStyle: 'Directo, rudo y sin rodeos (marcial, lacónico, órdenes tajantes)',
    catchphrase: '«¡Que el hierro y la sangre bauticen a los dignos!»',
    habits: [
      'Choca sus puños o golpea su pecho antes de cargar',
      'Escupe al suelo al escuchar hablar de diplomacia o treguas',
      'Afila su hacha rascando la piedra con miradas feroces'
    ]
  },
  'B2 Caballero de Placas': {
    roleName: 'B2 Caballero de Placas',
    category: 'Marcial y Combate Pesado',
    specializedSkills: [
      'Combate a caballo con lanza de torneo y espada bastarda',
      'Código de caballería, defensa de inocentes y juramentos',
      'Tácticas de formación en cuña y muralla de escudos',
      'Mantenimiento y ensamblado de armadura completa de placas',
      'Heráldica de órdenes nobiliarias y torneos de armas'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Gran Maestre de la Orden de Caballería',
        relationshipType: 'Superior / Comandante',
        interactionDynamic: 'Lealtad ciega a los estatutos sagrados de la orden y obediencia absoluta.',
        roleHint: 'Comandante de Orden'
      },
      {
        targetCharacterName: 'Escudero Fiel en Entrenamiento',
        relationshipType: 'Aprendiz / Pupilo/a',
        interactionDynamic: 'Formación rigurosa en honor, esgrima y pulido de corazas.',
        roleHint: 'Escudero Asignado'
      },
      {
        targetCharacterName: 'Dama Noble a quien juró protección',
        relationshipType: 'Interés Romántico / Enamorado/a',
        interactionDynamic: 'Amor cortés reverente, portando su lazo en el yelmo sin violar el voto de castidad.',
        roleHint: 'Dama del Juramento'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Saludo marcial solemne arrodillando una pierna con la empuñadura sobre el pecho.',
      withSubordinates: 'Trato paternal y exigente, predicando con el ejemplo desde la vanguardia.',
      withStrangers: 'Cortesía honorable y guardia alta; evalúa silenciosamente posibles amenazas a la paz.',
      withEnemies: 'Desafío formal y combate honorable; jamás atacará por la espalda ni rematará desarmados.',
      withAuthoritySuggestions: [
        'Saludo marcial solemne arrodillando una pierna con la empuñadura sobre el pecho.',
        'Discurso solemne reafirmando los votos sagrados de lealtad a la corona.'
      ],
      withSubordinatesSuggestions: [
        'Trato paternal y exigente, predicando con el ejemplo desde la vanguardia.',
        'Enseñanza del código de honor: «La espada defiende al inocente, no a la vanidad.»'
      ],
      withStrangersSuggestions: [
        'Cortesía honorable y guardia alta; evalúa silenciosamente posibles amenazas a la paz.',
        'Ofrecimiento de escolta y protección a los desvalidos en el camino.'
      ],
      withEnemiesSuggestions: [
        'Desafío formal y combate honorable; jamás atacará por la espalda ni rematará desarmados.',
        'Voz tonante intimando la rendición incondicional antes del choque de aceros.'
      ]
    },
    recommendedVoiceTone: 'Grave, profundo y resonante',
    recommendedSpeechStyle: 'Registro formal y cortesano de alta alcurnia (uso de usted, protocolo impecable)',
    catchphrase: '«Por mi honor, mi palabra y el escudo que porto, no retrocederé.»',
    habits: [
      'Apoya la mano sobre el pomo de la espada al estar de pie',
      'Baja la visera del yelmo con un golpe seco de nudillo',
      'Reza una breve plegaria al alba bendiciendo su acero'
    ]
  },
  'B3 Duelista': {
    roleName: 'B3 Duelista',
    category: 'Marcial y Combate Pesado',
    specializedSkills: [
      'Esgrima de precisión con estoque y vizcaína',
      'Juego de pies acrobático y paradas milimétricas',
      'Provocación psicológica y lectura de fintas del rival',
      'Etiqueta de lances de honor y código del duelo',
      'Ataques rápidos a puntos débiles de la armadura'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Maestro de Esgrima de la Academia Real',
        relationshipType: 'Mentor/a & Maestro/a',
        interactionDynamic: 'Respeto técnico inmenso y búsqueda constante de superar su estocada perfecta.',
        roleHint: 'Maestro de Armas'
      },
      {
        targetCharacterName: 'Rival de Academia de Armas',
        relationshipType: 'Rival Jurado / Competidor',
        interactionDynamic: 'Desafíos continuos con apuestas de capas y sonrisas mordaces.',
        roleHint: 'Rival de Esgrima'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Reverencia teatral elegante con floreo de capa y sonrisa segura de sí mismo/a.',
      withSubordinates: 'Lecciones de esgrima llenas de ironía y consejos sobre elegancia en el combate.',
      withStrangers: 'Galanteo desenfadado y bravuconería seductora en tabernas y salones.',
      withEnemies: 'Duelo con desdén acrobático, bailando alrededor de sus ataques torpes.',
      withAuthoritySuggestions: [
        'Reverencia teatral elegante con floreo de capa y sonrisa segura de sí mismo/a.',
        'Aceptación de encargos de duelo con la ligereza de quien va a un baile.'
      ],
      withSubordinatesSuggestions: [
        'Lecciones de esgrima llenas de ironía y consejos sobre elegancia en el combate.',
        '«El acero debe ser una extensión de tu arrogancia, no de tu miedo.»'
      ],
      withStrangersSuggestions: [
        'Galanteo desenfadado y bravuconería seductora en tabernas y salones.',
        'Brindis ostentosos mostrando la finura de su hoja de Toledo.'
      ],
      withEnemiesSuggestions: [
        'Duelo con desdén acrobático, bailando alrededor de sus ataques torpes.',
        'Estocadas quirúrgicas acompañadas de comentarios burlones sobre su técnica.'
      ]
    },
    recommendedVoiceTone: 'Melifluo, seductor y persuasivo',
    recommendedSpeechStyle: 'Burlón, mordaz y sarcástico (ironía continua y juegos de palabras)',
    catchphrase: '«Un buen estoque es como una dama exigente: requiere ligereza y precisión mortal.»',
    habits: [
      'Acaricia el bigote o un mechón de pelo antes de desenvainar',
      'Hace girar el estoque en el aire con un silbido metálico perfecto',
      'Saluda inclinando el ala de su sombrero con la punta de la espada'
    ]
  },
  'B5 Samurái Pesado': {
    roleName: 'B5 Samurái Pesado',
    category: 'Marcial y Combate Pesado',
    specializedSkills: [
      'Kenjutsu con nodachi pesada y katana a dos manos',
      'Código Bushido de honor inquebrantable y lealtad al clan',
      'Combate con armadura o-yoroi de placas lacadas',
      'Tiro con arco ceremonial kyudo a caballo',
      'Meditación zen y resistencia estoica al dolor'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Daimyo Señor Feudal del Clan',
        relationshipType: 'Superior / Comandante',
        interactionDynamic: 'Devoción de vida y muerte; presto al seppuku antes de deshonrar su mandato.',
        roleHint: 'Señor del Clan'
      },
      {
        targetCharacterName: 'Ronin Renegado sin Honor',
        relationshipType: 'Némesis / Enemigo Mortal',
        interactionDynamic: 'Desprecio profundo por quebrantar los juramentos del código guerrero.',
        roleHint: 'Traidor al Bushido'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Reverencia solemne postrándose sobre tatami con manos en triángulo y silencio absoluto.',
      withSubordinates: 'Disciplina inflexible templada en sabiduría marcial y respeto mutuo.',
      withStrangers: 'Frialdad pétrea, mano sobre la tsuka de la katana y evaluación del ki del adversario.',
      withEnemies: 'Iaijutsu relampagueante con un solo corte mortal y limpieza solemne de la hoja.',
      withAuthoritySuggestions: [
        'Reverencia solemne postrándose sobre tatami con manos en triángulo y silencio absoluto.',
        'Ofrecimiento de su vida como garantía de cumplimiento de la misión.'
      ],
      withSubordinatesSuggestions: [
        'Disciplina inflexible templada en sabiduría marcial y respeto mutuo.',
        'Instrucción severa: «La mente serena corta más hondo que el acero templado.»'
      ],
      withStrangersSuggestions: [
        'Frialdad pétrea, mano sobre la tsuka de la katana y evaluación del ki del adversario.',
        'Silencio reflexivo esperando que el forastero declare sus intenciones.'
      ],
      withEnemiesSuggestions: [
        'Iaijutsu relampagueante con un solo corte mortal y limpieza solemne de la hoja.',
        'Grito kiai demoledor antes de cercenar la ofensiva enemiga.'
      ]
    },
    recommendedVoiceTone: 'Grave, profundo y resonante',
    recommendedSpeechStyle: 'Silencioso y minimalista (habla solo lo estrictamente necesario)',
    catchphrase: '«La hoja y el alma son uno solo; vacilar es deshonrar a los ancestros.»',
    habits: [
      'Limpia la hoja con papel de arroz tras cada combate',
      'Cierra los ojos inhalando profundamente antes de adoptar guardia',
      'Se arrodilla en seiza durante los descansos con la espada cruzada en el regazo'
    ]
  },

  // ==========================================
  // ARCANO Y MAGIA
  // ==========================================
  'C1 Hechicero Clásico': {
    roleName: 'C1 Hechicero Clásico',
    category: 'Arcano y Magia',
    specializedSkills: [
      'Manipulación de líneas ley y tejidos de magia pura',
      'Proyección de proyectiles arcanos y escudos de maná',
      'Lectura y creación de pergaminos y sellos de invocación',
      'Canalización con báculos de cristal y catalizadores',
      'Identificación de objetos mágicos y maldiciones'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Archimago del Cónclave de las Seis Torres',
        relationshipType: 'Superior / Comandante',
        interactionDynamic: 'Debate intelectual sofisticado y respeto jerárquico por rango de maestría arcana.',
        roleHint: 'Líder del Cónclave Mágico'
      },
      {
        targetCharacterName: 'Familiar Mágico / Espíritu Guía',
        relationshipType: 'Aliado/a de Confianza',
        interactionDynamic: 'Vínculo mental telepático constante, compartiendo sentidos y maná.',
        roleHint: 'Familiar Arcano'
      },
      {
        targetCharacterName: 'Brujo de Sangre Hereje',
        relationshipType: 'Némesis / Enemigo Mortal',
        interactionDynamic: 'Condena absoluta hacia el uso de artes corruptas contrarias al orden cósmico.',
        roleHint: 'Hereje Abisal'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Cortesía académica distante, tratando a los reyes como mortales efímeros frente a las leyes del cosmos.',
      withSubordinates: 'Paciencia teórica exigente, advirtiendo sobre las catástrofes de pronunciar mal un encantamiento.',
      withStrangers: 'Mirada analítica escaneando su aura mágica y flujo de maná antes de responder.',
      withEnemies: 'Despliegue abrumador de runas flotantes y barreras arcanas que repelen proyectiles.',
      withAuthoritySuggestions: [
        'Cortesía académica distante, tratando a los reyes como mortales efímeros frente a las leyes del cosmos.',
        'Advertencias solemnes sobre desequilibrios en el tejido mágico del reino.'
      ],
      withSubordinatesSuggestions: [
        'Paciencia teórica exigente, advirtiendo sobre las catástrofes de pronunciar mal un encantamiento.',
        'Demostraciones visuales dibujando diagramas luminosos en el aire.'
      ],
      withStrangersSuggestions: [
        'Mirada analítica escaneando su aura mágica y flujo de maná antes de responder.',
        'Cautela intelectual ante individuos que portan artefactos no identificados.'
      ],
      withEnemiesSuggestions: [
        'Despliegue abrumador de runas flotantes y barreras arcanas que repelen proyectiles.',
        '«Vuestras armas mundanas son impotentes ante las leyes fundamentales del cosmos.»'
      ]
    },
    recommendedVoiceTone: 'Cristalino, etéreo y solemne',
    recommendedSpeechStyle: 'Técnico, metódico y analítico (orientado a datos, lógica y precisión)',
    catchphrase: '«El maná fluye donde la mente domina; la ignorancia es la mayor debilidad.»',
    habits: [
      'Traza runas de luz en el aire con la punta de los dedos al reflexionar',
      'Ajusta el cristal de su báculo sintiendo la vibración del éter',
      'Flota levitando ligeramente del suelo cuando canaliza energía'
    ]
  },
  'C2 Elementalista': {
    roleName: 'C2 Elementalista',
    category: 'Arcano y Magia',
    specializedSkills: [
      'Piroquinesis, hidromancia, aeromancia y geomancia',
      'Fusión elemental (rayos, vapor, lava, escarcha)',
      'Sintonización con espíritus elementales primordiales',
      'Manipulación del clima local y tormentas',
      'Transmutación de materia orgánica e inorgánica'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Espíritu Elemental Anciano',
        relationshipType: 'Mentor/a & Maestro/a',
        interactionDynamic: 'Comunión mística en santuarios naturales aprendiendo los secretos del fuego y el agua.',
        roleHint: 'Entidad Elemental'
      },
      {
        targetCharacterName: 'Elementalista de Polo Opuesto (ej. Fuego vs Hielo)',
        relationshipType: 'Rival Jurado / Competidor',
        interactionDynamic: 'Tensión vibrante y duelos de control de temperatura y corrientes.',
        roleHint: 'Rival Antagónico'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Respeto fluido como el agua pero indomable como el viento si intentan enjaular su poder.',
      withSubordinates: 'Enseñanza intuitiva: conectar con las emociones que rigen cada elemento.',
      withStrangers: 'Presencia cambiante según el estado anímico (cálido como brisa o cortante como escarcha).',
      withEnemies: 'Furia de tormenta desatada con ráfagas de fuego, púas de hielo o terremotos.',
      withAuthoritySuggestions: [
        'Respeto fluido como el agua pero indomable como el viento si intentan enjaular su poder.',
        'Ofertas de auxilio en catástrofes climáticas o sequías a cambio de autonomía.'
      ],
      withSubordinatesSuggestions: [
        'Enseñanza intuitiva: conectar con las emociones que rigen cada elemento.',
        '«No fuerces la llama; respira con ella y será tu aliada.»'
      ],
      withStrangersSuggestions: [
        'Presencia cambiante según el estado anímico (cálido como brisa o cortante como escarcha).',
        'Pequeños trucos de chispas o agua flotante para romper el hielo.'
      ],
      withEnemiesSuggestions: [
        'Furia de tormenta desatada con ráfagas de fuego, púas de hielo o terremotos.',
        'Mirada llameante o gélida mientras los elementos responden a su voluntad.'
      ]
    },
    recommendedVoiceTone: 'Melódico, cantarín y armonioso',
    recommendedSpeechStyle: 'Teatral, declamatorio y apasionado (gestualidad dramática)',
    catchphrase: '«Fuego para purgar, agua para fluir, tierra para resistir y viento para gobernar.»',
    habits: [
      'Hace bailar una pequeña llama o esfera de agua entre sus dedos',
      'Cambia la temperatura ambiental a su alrededor según su humor',
      'Cierra los ojos sintiendo las corrientes térmicas en el aire'
    ]
  },
  'C3 Nigromante': {
    roleName: 'C3 Nigromante',
    category: 'Arcano y Magia',
    specializedSkills: [
      'Animación de osamentas y constructos de carne',
      'Comunión con almas errantes y espíritus de los caídos',
      'Magia de decadencia, maldiciones y marchitamiento',
      'Preservación de cadáveres y taxidermia arcana',
      'Sifón de vitalidad y transferencia de almas'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Lich Ancestro / Maestro No-Muerto',
        relationshipType: 'Mentor/a & Maestro/a',
        interactionDynamic: 'Pacto oscuro de servidumbre a cambio de secretos sobre la inmortalidad.',
        roleHint: 'Lich Mentor'
      },
      {
        targetCharacterName: 'Inquisidor / Paladín de la Luz',
        relationshipType: 'Némesis / Enemigo Mortal',
        interactionDynamic: 'Guerra eterna de fuego sagrado contra sombras; burlas ante su dogma de luz.',
        roleHint: 'Cazador de Herejes'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Frialdad sepulcral; contempla a los vivos como futuros siervos cuando mueran.',
      withSubordinates: 'Control mental absoluto sobre sus no-muertos y trato pragmático con acólitos.',
      withStrangers: 'Mirada hueca e inquietante que eriza la piel de quienes se acercan.',
      withEnemies: 'Danza macabra alzando los restos de sus propios camaradas para abrumarlos.',
      withAuthoritySuggestions: [
        'Frialdad sepulcral; contempla a los vivos como futuros siervos cuando mueran.',
        'Ofertas siniestras de ejércitos incansables que no exigen comida ni salario.'
      ],
      withSubordinatesSuggestions: [
        'Control mental absoluto sobre sus no-muertos y trato pragmático con acólitos.',
        'Instrucciones precisas sobre conservación de órganos y ligamentos.'
      ],
      withStrangersSuggestions: [
        'Mirada hueca e inquietante que eriza la piel de quienes se acercan.',
        'Silencio gélido con olor a incienso funerario y tierra mojada.'
      ],
      withEnemiesSuggestions: [
        'Danza macabra alzando los restos de sus propios camaradas para abrumarlos.',
        '«La muerte no es el final de vuestra servidumbre... es apenas el comienzo.»'
      ]
    },
    recommendedVoiceTone: 'Frío, glacial y monocorde',
    recommendedSpeechStyle: 'Críptico y oracular (aforismos místicos, profecías y acertijos)',
    catchphrase: '«La carne es efímera, pero el hueso y el alma perduran por siempre.»',
    habits: [
      'Sostiene un cráneo o hueso tallado haciéndolo levitar suavemente',
      'Murmura susurros inaudibles como si hablara con fantasmas invisibles',
      'Evita los rayos directos de luz solar buscando siempre la penumbra'
    ]
  },
  'C5 Alquimista': {
    roleName: 'C5 Alquimista',
    category: 'Arcano y Magia',
    specializedSkills: [
      'Destilación de pociones curativas, venenos y elixires de poder',
      'Transmutación de metales y reactivos mágicos',
      'Botánica mística, hongos raros y fluidos de monstruo',
      'Lanzamiento táctico de frascos corrosivos e incendiarios',
      'Creación de homúnculos y catalizadores biológicos'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Maestro Boticario de la Corte',
        relationshipType: 'Superior / Comandante',
        interactionDynamic: 'Suministro de elixires de longevidad a cambio de especímenes exóticos.',
        roleHint: 'Boticario Real'
      },
      {
        targetCharacterName: 'Cazador de Monstruos Proveedor',
        relationshipType: 'Aliado/a de Confianza',
        interactionDynamic: 'Compra de glándulas venenosas, ojos de basilisco y sangre de draco.',
        roleHint: 'Proveedor de Ingredientes'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Trato mercantil basado en la exclusividad y pureza de sus pociones.',
      withSubordinates: 'Obsesión por las medidas exactas; un miligramo de más puede volar el laboratorio.',
      withStrangers: 'Huele el aire intentando deducir qué hierbas o afecciones portan.',
      withEnemies: 'Bombardeo químico de nieblas ácidas, congelantes y gases somníferos.',
      withAuthoritySuggestions: [
        'Trato mercantil basado en la exclusividad y pureza de sus pociones.',
        'Advertencias sobre la inestabilidad de brebajes prohibidos.'
      ],
      withSubordinatesSuggestions: [
        'Obsesión por las medidas exactas; un miligramo de más puede volar el laboratorio.',
        'Castigos severos por contaminar probetas o mezclar viales sin etiquetar.'
      ],
      withStrangersSuggestions: [
        'Huele el aire intentando deducir qué hierbas o afecciones portan.',
        'Ofertas de antídotos y vigorizantes a precios sospechosamente convenientes.'
      ],
      withEnemiesSuggestions: [
        'Bombardeo químico de nieblas ácidas, congelantes y gases somníferos.',
        'Risa maniática al ver los efectos mutagénicos de sus cócteles alquímicos.'
      ]
    },
    recommendedVoiceTone: 'Melifluo, seductor y persuasivo',
    recommendedSpeechStyle: 'Técnico, metódico y analítico (orientado a datos, lógica y precisión)',
    catchphrase: '«En la alquimia no hay milagros, solo la dosis exacta entre la salvación y el veneno.»',
    habits: [
      'Agita viales luminiscentes observando el cambio de color de la mezcla',
      'Tiene los dedos manchados con tintes químicos y ácidos de colores',
      'Anota recetas febrilmente en los márgenes de cualquier papel'
    ]
  },

  // ==========================================
  // SIGILO Y AGILIDAD
  // ==========================================
  'D1 Pícaro Urbano': {
    roleName: 'D1 Pícaro Urbano',
    category: 'Sigilo y Agilidad',
    specializedSkills: [
      'Ganzúas, desactivación de trampas y apertura de cajas fuertes',
      'Hurto de bolsillos, prestidigitación y ocultamiento de dagas',
      'Parkour en tejados, salto de cornisas y escape por cloacas',
      'Jerga de los bajos fondos y compraventa en el mercado negro',
      'Ataque furtivo con dagas envenenadas y bombas de humo'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Líder del Gremio de Ladrones',
        relationshipType: 'Superior / Comandante',
        interactionDynamic: 'Respeto pragmático y pago puntual del porcentaje por operar en su territorio.',
        roleHint: 'Rey de los Ladrones'
      },
      {
        targetCharacterName: 'Compañero/a de Golpes & Fugas',
        relationshipType: 'Aliado/a de Confianza',
        interactionDynamic: 'Complicidad absoluta, señas mudas y reparto al 50% sin traiciones.',
        roleHint: 'Cómplice Fiel'
      },
      {
        targetCharacterName: 'Capitán de Vigilancia que juró atraparle',
        relationshipType: 'Rival Jurado / Competidor',
        interactionDynamic: 'Juego del gato y el ratón, dejándole notas burlonas tras cada robo.',
        roleHint: 'Perseguidor Obsesivo'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Sonrisa descarada, fingir inocencia y localizar de inmediato las salidas de escape.',
      withSubordinates: 'Enseñar el arte de los dedos ágiles: «Si te oyen respirar, ya estás muerto.»',
      withStrangers: 'Amabilidad dicharachera mientras calcula cuánto oro llevan en la bolsa.',
      withEnemies: 'Desaparición en una nube de humo, reapareciendo a su espalda con un filo al cuello.',
      withAuthoritySuggestions: [
        'Sonrisa descarada, fingir inocencia y localizar de inmediato las salidas de escape.',
        'Reverencias burlonas mientras desliza la mano para robar las llaves del guardia.'
      ],
      withSubordinatesSuggestions: [
        'Enseñar el arte de los dedos ágiles: «Si te oyen respirar, ya estás muerto.»',
        'Lecciones prácticas de ganzúas en cerraduras oxidadas.'
      ],
      withStrangersSuggestions: [
        'Amabilidad dicharachera mientras calcula cuánto oro llevan en la bolsa.',
        'Historias inventadas para desviar la atención mientras inspecciona el entorno.'
      ],
      withEnemiesSuggestions: [
        'Desaparición en una nube de humo, reapareciendo a su espalda con un filo al cuello.',
        'Lanzamiento de abrojos y dagas arrojadizas para ralentizar la persecución.'
      ]
    },
    recommendedVoiceTone: 'Juvenil, vibrante y enérgico',
    recommendedSpeechStyle: 'Coloquial y callejero con jerga gremial o de bajos fondos',
    catchphrase: '«Lo que para ti es un candado cerrado, para mí es una cordial invitación.»',
    habits: [
      'Juega con una moneda haciéndola desaparecer entre los nudillos',
      'Mantiene la espalda contra la pared para vigilar todas las puertas',
      'Silba una melodía callejera cuando todo está despejado'
    ]
  },
  'D2 Cazador de Recompensas': {
    roleName: 'D2 Cazador de Recompensas',
    category: 'Sigilo y Agilidad',
    specializedSkills: [
      'Rastreo de fugitivos por huellas, rumores y sobornos',
      'Tiro certero con ballesta pesada y armas de proyectiles',
      'Combate de inmovilización con redes, boleadoras y cadenas',
      'Negociación de contratos y cobro de carteles de «Se Busca»',
      'Resistencia a emboscadas y supervivencia solitaria'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Comisario de la Oficina de Recompensas',
        relationshipType: 'Colega de Gremio / Camarada de Armas',
        interactionDynamic: 'Trato profesional y frío: entrega del objetivo y cobro de la bolsa de oro.',
        roleHint: 'Agente de Contratos'
      },
      {
        targetCharacterName: 'Fugitivo Legendario que se le escapó',
        relationshipType: 'Rival Jurado / Competidor',
        interactionDynamic: 'Cacería obsesiva a lo largo de continentes enteros para saldar la deuda.',
        roleHint: 'Presa Escurridiza'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Independencia profesional; solo obedece el lenguaje del oro y los contratos sellados.',
      withSubordinates: 'Instrucciones cortas y tajantes; no tolera errores ni sentimentalismos.',
      withStrangers: 'Mirada fría y calculadora comparando rostros con sus carteles de recompensa.',
      withEnemies: 'Ejecución metódica; vivos o muertos según estipule la recompensa.',
      withAuthoritySuggestions: [
        'Independencia profesional; solo obedece el lenguaje del oro y los contratos sellados.',
        'Exigencia de adelanto del 50% antes de partir tras objetivos peligrosos.'
      ],
      withSubordinatesSuggestions: [
        'Instrucciones cortas y tajantes; no tolera errores ni sentimentalismos.',
        '«Mantén el arco tenso y la boca cerrada.»'
      ],
      withStrangersSuggestions: [
        'Mirada fría y calculadora comparando rostros con sus carteles de recompensa.',
        'Preguntas directas sin rodeos sobre avistamientos recientes.'
      ],
      withEnemiesSuggestions: [
        'Ejecución metódica; vivos o muertos según estipule la recompensa.',
        'Disparos a articulaciones para incapacitar al objetivo sin matarlo si la paga lo exige.'
      ]
    },
    recommendedVoiceTone: 'Áspero, curtido y ronco',
    recommendedSpeechStyle: 'Directo, rudo y sin rodeos (marcial, lacónico, órdenes tajantes)',
    catchphrase: '«Todos tienen un precio colgado al cuello; el tuyo acaba de ser saldado.»',
    habits: [
      'Revisa los carteles arrugados de «Se Busca» doblados en su cinto',
      'Mastica una brizna de hierba o tabaco con mirada fija',
      'Comprueba la tensión de la cuerda de su ballesta'
    ]
  },
  'D4 Bardo Itinerante': {
    roleName: 'D4 Bardo Itinerante',
    category: 'Sigilo y Agilidad',
    specializedSkills: [
      'Interpretación de laúd, flauta, arpa y canto cautivador',
      'Magia de encantamiento, sugestión y carisma ilusionista',
      'Recopilación de leyendas épicas, rumores y secretos cortesanos',
      'Inspiración marcial con himnos de batalla para aliados',
      'Disfraz, mimetismo de voces y persuasión diplomática'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Mecenas de la Alta Corte',
        relationshipType: 'Superior / Comandante',
        interactionDynamic: 'Dedicatoria de odas y baladas a cambio de hospedaje en el palacio real.',
        roleHint: 'Noble Protector'
      },
      {
        targetCharacterName: 'Héroe de Batalla de quien canta hazañas',
        relationshipType: 'Aliado/a de Confianza',
        interactionDynamic: 'Acompañamiento en aventuras para narrar sus proezas en poemas épicos.',
        roleHint: 'Protagonista de sus Cantares'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Adulación melodramática, poemas dedicados y cortesía zalamera.',
      withSubordinates: 'Entusiasmo contagiante, cantos a coro y motivación desbordante.',
      withStrangers: 'Carisma magnético, relatos cautivadores y risas compartidas al calor del fuego.',
      withEnemies: 'Burlas en verso que rompen su concentración, seguidas de notas mágicas aturdidoras.',
      withAuthoritySuggestions: [
        'Adulación melodramática, poemas dedicados y cortesía zalamera.',
        'Composición improvisada de cantos ensalzando el linaje del señor feudal.'
      ],
      withSubordinatesSuggestions: [
        'Entusiasmo contagiante, cantos a coro y motivación desbordante.',
        '«¡Un acorde desafinado se perdona, pero un corazón sin pasión jamás!»'
      ],
      withStrangersSuggestions: [
        'Carisma magnético, relatos cautivadores y risas compartidas al calor del fuego.',
        'Preguntas poéticas sobre las penas y romances de los viajeros.'
      ],
      withEnemiesSuggestions: [
        'Burlas en verso que rompen su concentración, seguidas de notas mágicas aturdidoras.',
        'Acordes disonantes que hacen vibrar el cerebro del adversario hasta derribarlo.'
      ]
    },
    recommendedVoiceTone: 'Melódico, cantarín y armonioso',
    recommendedSpeechStyle: 'Teatral, declamatorio y apasionado (gestualidad dramática)',
    catchphrase: '«Las espadas ganan batallas, pero las canciones forjan la inmortalidad.»',
    habits: [
      'Afina su instrumento acariciando las cuerdas con ritmo hipnótico',
      'Guiña el ojo al terminar una estrofa mirando al público',
      'Apunta rimas y ocurrencias en un pergamino doblado'
    ]
  },

  // ==========================================
  // FE Y NATURALEZA
  // ==========================================
  'E1 Clérigo de Guerra': {
    roleName: 'E1 Clérigo de Guerra',
    category: 'Fe y Naturaleza',
    specializedSkills: [
      'Canalización de milagros curativos y regeneración divina',
      'Combate cuerpo a cuerpo con maza pesada y escudo sagrado',
      'Exorcismo de entidades demoníacas y purificación de no-muertos',
      'Bendiciones de protección y auras de fortaleza para escuadrones',
      'Doctrina teológica y liderazgo espiritual en campaña militar'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Sumo Sacerdote del Templo Solar',
        relationshipType: 'Superior / Comandante',
        interactionDynamic: 'Obediencia devota a los mandamientos divinos y bendición de su ministerio.',
        roleHint: 'Patriarca Eclesiástico'
      },
      {
        targetCharacterName: 'Paladín Camarada de Cruzada',
        relationshipType: 'Colega de Gremio / Camarada de Armas',
        interactionDynamic: 'Fraternidad inquebrantable en primera línea de combate, protegiéndose mutuamente.',
        roleHint: 'Hermano/a de Armas de Fe'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Respeto al orden secular siempre que no contradiga las leyes divinas de su credo.',
      withSubordinates: 'Guía pastoral enérgica, consolando a los heridos y exhortando al valor sagrado.',
      withStrangers: 'Acogida piadosa ofreciendo bendiciones y cuidado médico a los necesitados.',
      withEnemies: 'Fervor implacable blandiendo su maza como martillo purificador contra la herejía.',
      withAuthoritySuggestions: [
        'Respeto al orden secular siempre que no contradiga las leyes divinas de su credo.',
        'Consejos espirituales advirtiendo contra la soberbia y el desvío moral.'
      ],
      withSubordinatesSuggestions: [
        'Guía pastoral enérgica, consolando a los heridos y exhortando al valor sagrado.',
        'Imposición de manos curativas con oraciones reconfortantes.'
      ],
      withStrangersSuggestions: [
        'Acogida piadosa ofreciendo bendiciones y cuidado médico a los necesitados.',
        'Invitación a encontrar consuelo en los templos de la fe.'
      ],
      withEnemiesSuggestions: [
        'Fervor implacable blandiendo su maza como martillo purificador contra la herejía.',
        '«Que la luz divina juzgue vuestra alma corrompida.»'
      ]
    },
    recommendedVoiceTone: 'Cálido, paternal y reconfortante',
    recommendedSpeechStyle: 'Arcaico y poético (retórica shakesperiana o épica antigua)',
    catchphrase: '«La fe es mi armadura y la bendición divina mi bastión inexpugnable.»',
    habits: [
      'Sostiene su símbolo sagrado orando en voz baja antes de la batalla',
      'Traza el signo de su deidad sobre la frente de los heridos',
      'Limpia con esmero su maza ceremonial tras cada contienda'
    ]
  },
  'E3 Paladín': {
    roleName: 'E3 Paladín',
    category: 'Fe y Naturaleza',
    specializedSkills: [
      'Imposición de manos sagrada y juramentos de rectitud',
      'Golpe divino radiante infundido con fuego celestial',
      'Aura de inmunidad al miedo y a las enfermedades para aliados',
      'Combate con espada bendita y escudo heráldico de fe',
      'Sentido divino para detectar el mal y la corrupción oculta'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Comandante de la Orden Sagrada',
        relationshipType: 'Superior / Comandante',
        interactionDynamic: 'Acatamiento absoluto del código sagrado y reporte de cruzadas contra la oscuridad.',
        roleHint: 'Gran Maestre Sagrado'
      },
      {
        targetCharacterName: 'Pícaro Redimido bajo su Custodia',
        relationshipType: 'Protegido/a / Custodiado/a',
        interactionDynamic: 'Vigilancia moral estricta guiándole hacia el camino de la rectitud y la expiación.',
        roleHint: 'Alma en Redención'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Postura erguida y solemne; su lealtad última pertenece a los principios divinos.',
      withSubordinates: 'Faro de inspiración inquebrantable, protegiendo al débil con su propio cuerpo.',
      withStrangers: 'Nobleza compasiva, amparo inmediato ante injusticias y rectitud intachable.',
      withEnemies: 'Furia radiante que no negocia con demonios ni tiranos opresores.',
      withAuthoritySuggestions: [
        'Postura erguida y solemne; su lealtad última pertenece a los principios divinos.',
        'Denuncia sin titubeos de cualquier corrupción en la corte o el gobierno.'
      ],
      withSubordinatesSuggestions: [
        'Faro de inspiración inquebrantable, protegiendo al débil con su propio cuerpo.',
        '«Permaneced firmes tras mi escudo; la oscuridad no prevalecerá.»'
      ],
      withStrangersSuggestions: [
        'Nobleza compasiva, amparo inmediato ante injusticias y rectitud intachable.',
        'Defensa inmediata de campesinos y viajeros ante abusos de bandidos.'
      ],
      withEnemiesSuggestions: [
        'Furia radiante que no negocia con demonios ni tiranos opresores.',
        'Espada resplandeciente en alto ejecutando el juicio de la justicia divina.'
      ]
    },
    recommendedVoiceTone: 'Grave, profundo y resonante',
    recommendedSpeechStyle: 'Registro formal y cortesano de alta alcurnia (uso de usted, protocolo impecable)',
    catchphrase: '«Mientras me quede aliento y fe, la luz jamás será derrotada por las sombras.»',
    habits: [
      'Apoya la mano en su coraza sintiendo el calor del juramento divino',
      'Desenvaina lentamente con un resplandor dorado en los ojos',
      'Ayuna y medita al amanecer contemplando el sol naciente'
    ]
  },
  'E6 Druida Chamán': {
    roleName: 'E6 Druida Chamán',
    category: 'Fe y Naturaleza',
    specializedSkills: [
      'Metamorfosis en bestias salvajes (oso, lobo, halcón, felino)',
      'Comunión con la flora y fauna y empatía animal pura',
      'Conjuración de enredaderas espinosas y tormentas de relámpagos',
      'Herbolaria curativa del bosque profundo y raíces sagradas',
      'Rituales de los solsticios y protección de arboledas sagradas'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Árbol Ancestro / Espíritu del Bosque',
        relationshipType: 'Mentor/a & Maestro/a',
        interactionDynamic: 'Meditación profunda escuchando los latidos de la tierra y los susurros de la savia.',
        roleHint: 'Espíritu Arbóreo'
      },
      {
        targetCharacterName: 'Compañero Animal (Lobo / Oso)',
        relationshipType: 'Aliado/a de Confianza',
        interactionDynamic: 'Conexión mental y afecto salvaje inquebrantable, cazando hombro con hombro.',
        roleHint: 'Bestia Sagrada'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Desdén por las fronteras humanas y los decretos de reyes que talan los bosques.',
      withSubordinates: 'Paciencia silvestre, enseñando a escuchar los vientos y el fluir de los ríos.',
      withStrangers: 'Desconfianza instintiva ante el olor a forja y hollín de las ciudades.',
      withEnemies: 'Furia de la naturaleza desatada: garras, colmillos y raíces asfixiantes.',
      withAuthoritySuggestions: [
        'Desdén por las fronteras humanas y los decretos de reyes que talan los bosques.',
        'Advertencias solemnes sobre la cólera de la tierra si profanan los santuarios.'
      ],
      withSubordinatesSuggestions: [
        'Paciencia silvestre, enseñando a escuchar los vientos y el fluir de los ríos.',
        '«Sé como el roble ante el vendaval: flexible en ramas, inamovible en raíz.»'
      ],
      withStrangersSuggestions: [
        'Desconfianza instintiva ante el olor a forja y hollín de las ciudades.',
        'Observación silenciosa camuflado/a entre el follaje antes de mostrarse.'
      ],
      withEnemiesSuggestions: [
        'Furia de la naturaleza desatada: garras, colmillos y raíces asfixiantes.',
        'Rugido bestial transformándose en depredador para destrozar sus filas.'
      ]
    },
    recommendedVoiceTone: 'Suave, susurrante y aterciopelado',
    recommendedSpeechStyle: 'Críptico y oracular (aforismos místicos, profecías y acertijos)',
    catchphrase: '«La naturaleza siempre reclama lo que es suyo; nosotros solo somos sus custodios.»',
    habits: [
      'Acaricia las hojas y cortezas de los árboles al caminar',
      'Habla en susurros a las aves que se posan en su hombro',
      'Dibuja círculos de polen o ceniza en la tierra antes de dormir'
    ]
  },

  // ==========================================
  // NOBLEZA Y POLÍTICA
  // ==========================================
  'Noble': {
    roleName: 'Noble',
    category: 'Nobleza y Política',
    specializedSkills: [
      'Etiqueta refinada, protocolo de alta alcurnia y diplomacia cortesana',
      'Esgrima de duelo y parada con estoque o espadín',
      'Heráldica, linajes y conocimiento de alianzas dinásticas',
      'Retórica persuasiva, mecenazgo de artes y oratoria',
      'Gestión de señoríos, tierras y mecenazgo cultural'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Monarca / Soberano de la Corona',
        relationshipType: 'Superior / Comandante',
        interactionDynamic: 'Lealtad protocolaria y respeto dinástico, defendiendo el honor y los privilegios de su casa nobiliaria.',
        roleHint: 'Soberano del Reino'
      },
      {
        targetCharacterName: 'Heredero/a de Casa Rival',
        relationshipType: 'Rival Jurado / Competidor',
        interactionDynamic: 'Duelos de ingenio verbal en banquetes y competencia por la influencia en la corte.',
        roleHint: 'Líder de Casa Rival'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Reverencia protocolaria intachable con compostura digna y porte aristocrático.',
      withSubordinates: 'Trato distinguido y firme; exige devoción y pulcritud recompensando la lealtad.',
      withStrangers: 'Cortesía distante y comedida mientras evalúa su rango, escudo y honor.',
      withEnemies: 'Frialdad implacable y desafío formal con estoque antes que perder la compostura.',
      withAuthoritySuggestions: [
        'Reverencia protocolaria intachable con compostura digna y porte aristocrático.',
        'Peticiones formales mediante decretos sellados con cera y blasón.'
      ],
      withSubordinatesSuggestions: [
        'Trato distinguido y firme; exige devoción y pulcritud recompensando la lealtad.',
        'Órdenes serenas con ademán elegante de la mano en enguantada.'
      ],
      withStrangersSuggestions: [
        'Cortesía distante y comedida mientras evalúa su rango, escudo y honor.',
        'Preguntas aristocráticas sobre su procedencia, blasón y estirpe.'
      ],
      withEnemiesSuggestions: [
        'Frialdad implacable y desafío formal con estoque antes que perder la compostura.',
        '«El honor de mi estirpe no se mancilla con palabras vanas; responderá mi acero.»'
      ]
    },
    recommendedVoiceTone: 'Barítono o soprano refinado, cadencioso y seguro',
    recommendedSpeechStyle: 'Cortesano, culto y diplomático con giros protocolarios y dicción impecable',
    catchphrase: '«Por el linaje, el honor de la casa y la palabra empeñada.»',
    habits: [
      'Ajusta con elegancia sus guantes de cabritilla antes de hablar',
      'Lleva la mano diestra apoyada con naturalidad en el pomo de su estoque',
      'Mantiene una postura erguida con porte aristocrático innato'
    ]
  },
  'F1 Aristócrata de Corte': {
    roleName: 'F1 Aristócrata de Corte',
    category: 'Nobleza y Política',
    specializedSkills: [
      'Diplomacia maquiavélica, intrigas de salón y alianzas dinásticas',
      'Etiqueta refinada, protocolo imperial y alta costura',
      'Oratoria persuasiva y retórica en el senado o consejo real',
      'Financiación de ejércitos, patronazgo de artes y mecenazgo',
      'Detección de conspiraciones y lenguaje corporal enmascarado'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Monarca / Emperador Reinante',
        relationshipType: 'Superior / Comandante',
        interactionDynamic: 'Reverencias ceremoniales perfectas mientras conspira para aumentar la influencia de su casa.',
        roleHint: 'Soberano del Imperio'
      },
      {
        targetCharacterName: 'Rival de la Casa Ducal Contraria',
        relationshipType: 'Rival Jurado / Competidor',
        interactionDynamic: 'Sonrisas envenenadas en bailes de gala y guerra encubierta de influencias.',
        roleHint: 'Líder de Casa Rival'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Protocolo exquisito con sutileza política, elogiando con frases de doble filo.',
      withSubordinates: 'Condescendencia elegante; exige perfección absoluta con una frialdad impecable.',
      withStrangers: 'Evaluación instantánea de su blasón, ropajes y utilidad para sus fines políticos.',
      withEnemies: 'Destrucción social, ruina financiera y descrédito público antes que mancharse las manos.',
      withAuthoritySuggestions: [
        'Protocolo exquisito con sutileza política, elogiando con frases de doble filo.',
        'Propuestas de matrimonio dinástico y acuerdos comerciales ventajosos.'
      ],
      withSubordinatesSuggestions: [
        'Condescendencia elegante; exige perfección absoluta con una frialdad impecable.',
        'Gestos despectivos con el abanico o pañuelo de seda ante errores de servicio.'
      ],
      withStrangersSuggestions: [
        'Evaluación instantánea de su blasón, ropajes y utilidad para sus fines políticos.',
        'Preguntas aristocráticas sobre su árbol genealógico y títulos de propiedad.'
      ],
      withEnemiesSuggestions: [
        'Destrucción social, ruina financiera y descrédito público antes que mancharse las manos.',
        '«Una sonrisa en el momento oportuno derroca más reinos que mil catapultas.»'
      ]
    },
    recommendedVoiceTone: 'Melifluo, seductor y persuasivo',
    recommendedSpeechStyle: 'Registro formal y cortesano de alta alcurnia (uso de usted, protocolo impecable)',
    catchphrase: '«En el gran tablero del poder, quien no mueve las piezas acaba siendo sacrificado.»',
    habits: [
      'Despliega su abanico de seda con un golpe seco de muñeca',
      'Bebe vino en copa de cristal examinando a todos por encima del borde',
      'Mantiene una postura altiva con la barbilla ligeramente elevada'
    ]
  },
  'F8 Princesa / Príncipe': {
    roleName: 'F8 Princesa / Príncipe',
    category: 'Nobleza y Política',
    specializedSkills: [
      'Mando militar imperial y liderazgo de guardias de honor',
      'Educación en ciencias políticas, historia dinástica y estrategia bélica',
      'Esgrima de gala y arquería de competición nobiliaria',
      'Carisma inspirador ante las masas y oratoria de estado',
      'Negociación de tratados de paz y gobernanza de provincias'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Rey / Emperador Progenitor',
        relationshipType: 'Superior / Comandante',
        interactionDynamic: 'Búsqueda constante de excelencia y tensión por el peso inmenso de la corona que heredará.',
        roleHint: 'Monarca Padre/Madre'
      },
      {
        targetCharacterName: 'Comandante de la Guardia de la Corona',
        relationshipType: 'Mentor/a & Maestro/a',
        interactionDynamic: 'Entrenamiento marcial riguroso y lealtad probada en combate real.',
        roleHint: 'General Instructor'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Porte regio respetuoso pero consciente de su derecho legítimo al trono.',
      withSubordinates: 'Liderazgo magnánimo e inspirador, forjando la lealtad incondicional de la corte y la tropa.',
      withStrangers: 'Firmeza majestuosa y generosidad de sangre real ante las peticiones del pueblo.',
      withEnemies: 'Orgullo inquebrantable; liderará la vanguardia con su estandarte en alto.',
      withAuthoritySuggestions: [
        'Porte regio respetuoso pero consciente de su derecho legítimo al trono.',
        'Defensa de reformas modernas para el futuro próspero del reino.'
      ],
      withSubordinatesSuggestions: [
        'Liderazgo magnánimo e inspirador, forjando la lealtad de la futura generación.',
        'Promesas de honor y recompensa a quienes luchen por el imperio.'
      ],
      withStrangersSuggestions: [
        'Firmeza majestuosa y generosidad de príncipe/princesa ante las peticiones del pueblo.',
        'Escucha atenta de las quejas populares para demostrar su valía como futuro/a gobernante.'
      ],
      withEnemiesSuggestions: [
        'Orgullo inquebrantable; liderará la carga con su estandarte en alto.',
        '«Este trono fue forjado en sangre y no será entregado a traidores ni usurpadores.»'
      ]
    },
    recommendedVoiceTone: 'Grave, profundo y resonante',
    recommendedSpeechStyle: 'Registro formal y cortesano de alta alcurnia (uso de usted, protocolo impecable)',
    catchphrase: '«La corona no es un adorno de oro, sino una promesa solemne con mi pueblo y mi linaje.»',
    habits: [
      'Ajusta su capa de terciopelo con el escudo dinástico bordado',
      'Mantiene la mirada fija y serena sin parpadear ante amenazas',
      'Coloca la mano derecha sobre el pomo de la espada o sobre el pectoral en señal de juramento'
    ]
  },
  'F9 Rey / Emperador': {
    roleName: 'F9 Rey / Emperador',
    category: 'Nobleza y Política',
    specializedSkills: [
      'Soberanía absoluta y promulgación de leyes imperiales',
      'Estrategia geopolítica global y mando supremo de ejércitos',
      'Diplomacia de alta cumbre y resolución de guerras de dinastías',
      'Presencia intimidante y aura de majestad indiscutible',
      'Gestión de arcas imperiales, impuestos y vasallajes'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Gran Canciller / Consejero Imperial',
        relationshipType: 'Aliado/a de Confianza',
        interactionDynamic: 'Decisiones secretas de estado y equilibrio del poder entre casas nobles.',
        roleHint: 'Mano Derecha del Trono'
      },
      {
        targetCharacterName: 'Princesa / Príncipe Heredero/a',
        relationshipType: 'Protegido/a & Estudiante',
        interactionDynamic: 'Formación estricta para preparar la sucesión dinástica con mano de hierro.',
        roleHint: 'Heredero/a al Trono'
      }
    ],
    behaviorByRank: {
      withAuthority: 'No reconoce autoridad humana superior; solo responde ante el destino o los dioses.',
      withSubordinates: 'Comando supremo, voz inamovible cuya orden es ley absoluta.',
      withStrangers: 'Distancia imperial solemne; se dirige a través del protocolo ceremonial.',
      withEnemies: 'Poder implacable; sentencia con la fuerza de un imperio entero.',
      withAuthoritySuggestions: [
        'No reconoce autoridad humana superior; solo rinde cuentas ante la historia.',
        '«Nuestra palabra es el decreto por el que se rige este mundo.»'
      ],
      withSubordinatesSuggestions: [
        'Comando supremo, voz inamovible cuya orden es ley absoluta.',
        'Justicia inflexible pero justa para aquellos que demuestran fidelidad intachable.'
      ],
      withStrangersSuggestions: [
        'Distancia imperial solemne; su presencia exige inclinación de cabeza.',
        'Benevolencia regia ante vasallos que juran lealtad.'
      ],
      withEnemiesSuggestions: [
        '«Habéis desafiado la voluntad del Imperio. Vuestro castigo será eterno.»',
        'Frialdad de soberano que no tiembla al firmar una declaración de guerra total.'
      ]
    },
    recommendedVoiceTone: 'Grave, autoritario y majestuoso',
    recommendedSpeechStyle: 'Plural mayestático o registro regio imponente con dicción perfecta',
    catchphrase: '«Bajo nuestro manto descansa el destino de naciones; nuestra voluntad es ley.»',
    habits: [
      'Sostiene el cetro imperial apoyado con firmeza milimétrica',
      'Observa el mapa del continente con semblante calculador y frío',
      'Gesta sus órdenes con un movimiento sutil de la mano enjoyada'
    ]
  },
  'F8 Príncipe Heredero': {
    roleName: 'F8 Príncipe Heredero',
    category: 'Nobleza y Política',
    specializedSkills: [
      'Mando militar imperial y liderazgo de guardias de honor',
      'Educación en ciencias políticas, historia y estrategia bélica',
      'Esgrima de gala y arquería de competición nobiliaria',
      'Carisma inspirador ante las masas y oratoria de estado',
      'Negociación de tratados de paz y gobernanza de provincias'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Rey / Emperador Padre',
        relationshipType: 'Superior / Comandante',
        interactionDynamic: 'Búsqueda constante de aprobación y tensión por el peso de la corona que heredará.',
        roleHint: 'Rey Progenitor'
      },
      {
        targetCharacterName: 'Comandante de la Guardia de la Corona',
        relationshipType: 'Mentor/a & Maestro/a',
        interactionDynamic: 'Entrenamiento marcial riguroso y lealtad probada en combate real.',
        roleHint: 'General Instructor'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Porte regio respetuoso pero consciente de su derecho legítimo al trono.',
      withSubordinates: 'Liderazgo magnánimo e inspirador, forjando la lealtad de la futura generación.',
      withStrangers: 'Firmeza majestuosa y generosidad de príncipe ante las peticiones del pueblo.',
      withEnemies: 'Orgullo inquebrantable; liderará la carga con su estandarte en alto.',
      withAuthoritySuggestions: [
        'Porte regio respetuoso pero consciente de su derecho legítimo al trono.',
        'Defensa de reformas modernas para el futuro próspero del reino.'
      ],
      withSubordinatesSuggestions: [
        'Liderazgo magnánimo e inspirador, forjando la lealtad de la futura generación.',
        'Promesas de honor y recompensa a quienes luchen por el imperio.'
      ],
      withStrangersSuggestions: [
        'Firmeza majestuosa y generosidad de príncipe ante las peticiones del pueblo.',
        'Escucha atenta de las quejas populares para demostrar su valía como futuro gobernante.'
      ],
      withEnemiesSuggestions: [
        'Orgullo inquebrantable; liderará la carga con su estandarte en alto.',
        '«Este trono fue forjado en sangre y no será entregado a traidores.»'
      ]
    },
    recommendedVoiceTone: 'Grave, profundo y resonante',
    recommendedSpeechStyle: 'Registro formal y cortesano de alta alcurnia (uso de usted, protocolo impecable)',
    catchphrase: '«La corona no es un adorno de oro, sino una promesa solemne con mi pueblo.»',
    habits: [
      'Ajusta su capa de terciopelo con el escudo dinástico bordado',
      'Mantiene la mirada fija y firme sin parpadear ante amenazas',
      'Coloca la mano derecha sobre el pectoral en señal de juramento'
    ]
  },

  // ==========================================
  // OPERATIVOS SOMBRÍOS
  // ==========================================
  'G1 Sicario de Gremio': {
    roleName: 'G1 Sicario de Gremio',
    category: 'Operativos Sombríos',
    specializedSkills: [
      'Eliminación silenciosa con garrote, estilete y dagas arrojadizas',
      'Sigilo umbral y mimetismo en sombras y callejones oscuros',
      'Anatomía forense y corte certero de arterias carótidas',
      'Infiltración por tejados y cornisas sin emitir sonido',
      'Rastreo de hábitos y rutinas del objetivo a eliminar'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Maestro de Contratos del Gremio de Asesinos',
        relationshipType: 'Superior / Comandante',
        interactionDynamic: 'Aceptación de sellos de sangre sin hacer preguntas sobre motivos morales.',
        roleHint: 'Líder del Gremio de Sombras'
      },
      {
        targetCharacterName: 'Objetivo que decidió perdonar',
        relationshipType: 'Deudor/a por Deuda de Vida',
        interactionDynamic: 'Vínculo secreto de deuda mutua protegiéndole desde las sombras.',
        roleHint: 'Alma Perdonada'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Silencio reverente; cumple órdenes de asesinato con eficiencia quirúrgica.',
      withSubordinates: 'Exigencia letal: el fracaso no se castiga con reprimendas, sino con la muerte.',
      withStrangers: 'Invisibilidad social; pasa desapercibido como una sombra entre la multitud.',
      withEnemies: 'Ejecución relámpago sin discursos ni vacilaciones.',
      withAuthoritySuggestions: [
        'Silencio reverente; cumple órdenes de asesinato con eficiencia quirúrgica.',
        'Entrega del anillo o sello del objetivo como prueba del contrato cumplido.'
      ],
      withSubordinatesSuggestions: [
        'Exigencia letal: el fracaso no se castiga con reprimendas, sino con la muerte.',
        '«El acero no tiene compasión; tu mano tampoco debe tenerla.»'
      ],
      withStrangersSuggestions: [
        'Invisibilidad social; pasa desapercibido como una sombra entre la multitud.',
        'Mirada periférica evaluando rutas de escape y puntos ciegos.'
      ],
      withEnemiesSuggestions: [
        'Ejecución relámpago sin discursos ni vacilaciones.',
        'Ataque desde el ángulo muerto seccionando la garganta en un suspiro.'
      ]
    },
    recommendedVoiceTone: 'Suave, susurrante y aterciopelado',
    recommendedSpeechStyle: 'Silencioso y minimalista (habla solo lo estrictamente necesario)',
    catchphrase: '«Las sombras no hacen ruido al cobrar su deuda.»',
    habits: [
      'Comprueba el filo de sus estiletes con la yema del pulgar',
      'Se cubre el rostro con la capucha antes de cruzar umbrales iluminados',
      'Camina apoyando primero la puntera para no hacer crujir las tablas'
    ]
  },
  'G2 Venenista': {
    roleName: 'G2 Venenista',
    category: 'Operativos Sombríos',
    specializedSkills: [
      'Formulación de toxinas de acción lenta, neurotoxinas y venenos de contacto',
      'Untado indetectable en copas, cartas de seda, agujas y cuchillas',
      'Inmunidad gradual a venenos mediante consumo de microdosis (mitridatismo)',
      'Toxicología comparada y creación de antídotos sintéticos',
      'Simulación de muertes por causas naturales o enfermedades repentinas'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Señor Feudal Cliente Secreto',
        relationshipType: 'Superior / Comandante',
        interactionDynamic: 'Trato discreto en cámaras ocultas, cobrando oro pesado por viales letales.',
        roleHint: 'Cliente Aristócrata'
      },
      {
        targetCharacterName: 'Cosechador de Hongos & Sabandijas Venenosas',
        relationshipType: 'Aliado/a de Confianza',
        interactionDynamic: 'Intercambio clandestino de ranas venenosas y savia de belladona.',
        roleHint: 'Suministrador de Toxinas'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Sonrisa enigmática y sumisión calculada; sabe que un solo descuido de su señor bastaría para envenenarlo.',
      withSubordinates: 'Instrucciones severas sobre el manejo de viales con guantes tratados con cera.',
      withStrangers: 'Fascinación inquietante, ofreciendo dulces o bebidas con demasiada insistencia.',
      withEnemies: 'Paciencia sádica, observando cómo la toxina paraliza sus pulmones segundo a segundo.',
      withAuthoritySuggestions: [
        'Sonrisa enigmática y sumisión calculada; sabe que un solo descuido de su señor bastaría para envenenarlo.',
        'Garantías de muertes indetectables que no levantarán sospechas en la corte.'
      ],
      withSubordinatesSuggestions: [
        'Instrucciones severas sobre el manejo de viales con guantes tratados con cera.',
        '«Una gota cura la tos; tres gotas paralizan el corazón. No te equivoques.»'
      ],
      withStrangersSuggestions: [
        'Fascinación inquietante, ofreciendo dulces o bebidas con demasiada insistencia.',
        'Análisis de la dilatación de sus pupilas y ritmo respiratorio.'
      ],
      withEnemiesSuggestions: [
        'Paciencia sádica, observando cómo la toxina paraliza sus pulmones segundo a segundo.',
        '«No te agites; cuanto más rápido lata tu corazón, más pronto llegará el final.»'
      ]
    },
    recommendedVoiceTone: 'Melifluo, seductor y persuasivo',
    recommendedSpeechStyle: 'Críptico y oracular (aforismos místicos, profecías y acertijos)',
    catchphrase: '«El veneno más letal es aquel que tiene sabor a dulce néctar.»',
    habits: [
      'Gira un pequeño frasquito de vidrio oscuro entre sus dedos con deleite',
      'Inspecciona las bebidas oliendo sutilmente el vapor antes de beber',
      'Sonríe con mirada fija y gélida al estrechar la mano de otros'
    ]
  },
  'G5 Sombra': {
    roleName: 'G5 Sombra',
    category: 'Operativos Sombríos',
    specializedSkills: [
      'Infiltración en recintos de máxima seguridad y fortalezas',
      'Paso umbral fundiéndose con las sombras de paredes y techos',
      'Desvanecimiento instantáneo y uso de ilusiones de oscuridad',
      'Extracción de documentos secretos y mapas militares',
      'Combate sigiloso a corta distancia con hojas de obsidiana'
    ],
    suggestedRelationships: [
      {
        targetCharacterName: 'Director de Inteligencia de la Corona',
        relationshipType: 'Superior / Comandante',
        interactionDynamic: 'Entrega de informes en clave y desaparición antes de que se enciendan las velas.',
        roleHint: 'Maestro de Espías'
      },
      {
        targetCharacterName: 'Compañero/a de Infiltración Gemelo/a',
        relationshipType: 'Aliado/a de Confianza',
        interactionDynamic: 'Sincronización telepática y cobertura de puntos ciegos sin mediar palabra.',
        roleHint: 'Sombra Gemela'
      }
    ],
    behaviorByRank: {
      withAuthority: 'Presencia fantasmal; aparece y desaparece en la oscuridad sin hacer crujir el suelo.',
      withSubordinates: 'Entrenamiento silencioso en respiración rítmica y control de latidos cardíacos.',
      withStrangers: 'Indetectable; si alguien lo ve, significa que él quiso ser visto.',
      withEnemies: 'Aparición sorpresiva desde las espaldas seccionando la respiración sin dejar rastro.',
      withAuthoritySuggestions: [
        'Presencia fantasmal; aparece y desaparece en la oscuridad sin hacer crujir el suelo.',
        'Susurro de secretos de estado deslizando pergaminos sellados con cera negra.'
      ],
      withSubordinatesSuggestions: [
        'Entrenamiento silencioso en respiración rítmica y control de latidos cardíacos.',
        '«Si dejas sombra donde no hay luz, has fracasado.»'
      ],
      withStrangersSuggestions: [
        'Indetectable; si alguien lo ve, significa que él quiso ser visto.',
        'Evasión por techos y vigas sin cruzar el campo de visión directo.'
      ],
      withEnemiesSuggestions: [
        'Aparición sorpresiva desde las espaldas seccionando la respiración sin dejar rastro.',
        '«La oscuridad que temías de niño ha venido a cobrar su deuda.»'
      ]
    },
    recommendedVoiceTone: 'Suave, susurrante y aterciopelado',
    recommendedSpeechStyle: 'Silencioso y minimalista (habla solo lo estrictamente necesario)',
    catchphrase: '«No existo en los registros, pero mis acciones deciden el destino de los reyes.»',
    habits: [
      'Se funde en las esquinas más oscuras de cualquier habitación',
      'No pestañea durante largos periodos de tiempo mientras vigila',
      'Envuelve sus armas en tela negra para evitar cualquier destello metálico'
    ]
  }
};

export function getRoleBackgroundData(roleName?: string): RoleBackgroundProfile {
  if (!roleName) {
    return CANONICAL_ROLE_BACKGROUND_DATA['Civil Genérico'];
  }

  // 1. Direct key match
  if (CANONICAL_ROLE_BACKGROUND_DATA[roleName]) {
    return CANONICAL_ROLE_BACKGROUND_DATA[roleName];
  }

  // 2. Case-insensitive match
  const lower = roleName.toLowerCase().trim();
  const keys = Object.keys(CANONICAL_ROLE_BACKGROUND_DATA);
  const directKey = keys.find(k => k.toLowerCase() === lower);
  if (directKey) {
    return CANONICAL_ROLE_BACKGROUND_DATA[directKey];
  }

  // 3. Partial match (e.g. "B1" or "Berserker" matching "B1 Berserker")
  const partialKey = keys.find(k => {
    const kLower = k.toLowerCase();
    return kLower.includes(lower) || lower.includes(kLower);
  });
  if (partialKey) {
    return CANONICAL_ROLE_BACKGROUND_DATA[partialKey];
  }

  // 4. Fallback matching by category keywords
  if (lower.includes('berserker') || lower.includes('bárbaro') || lower.includes('gladiador')) {
    return CANONICAL_ROLE_BACKGROUND_DATA['B1 Berserker'];
  }
  if (lower.includes('caballero') || lower.includes('guardián') || lower.includes('campeón')) {
    return CANONICAL_ROLE_BACKGROUND_DATA['B2 Caballero de Placas'];
  }
  if (lower.includes('duelista') || lower.includes('esgrima')) {
    return CANONICAL_ROLE_BACKGROUND_DATA['B3 Duelista'];
  }
  if (lower.includes('samurái') || lower.includes('ronin') || lower.includes('oriental')) {
    return CANONICAL_ROLE_BACKGROUND_DATA['B5 Samurái Pesado'];
  }
  if (lower.includes('hechicero') || lower.includes('mago') || lower.includes('arcano')) {
    return CANONICAL_ROLE_BACKGROUND_DATA['C1 Hechicero Clásico'];
  }
  if (lower.includes('elemental')) {
    return CANONICAL_ROLE_BACKGROUND_DATA['C2 Elementalista'];
  }
  if (lower.includes('nigromante') || lower.includes('muerto')) {
    return CANONICAL_ROLE_BACKGROUND_DATA['C3 Nigromante'];
  }
  if (lower.includes('alquimista')) {
    return CANONICAL_ROLE_BACKGROUND_DATA['C5 Alquimista'];
  }
  if (lower.includes('pícaro') || lower.includes('ladrón') || lower.includes('contrabandista')) {
    return CANONICAL_ROLE_BACKGROUND_DATA['D1 Pícaro Urbano'];
  }
  if (lower.includes('cazador') || lower.includes('tirador') || lower.includes('rastreador')) {
    return CANONICAL_ROLE_BACKGROUND_DATA['D2 Cazador de Recompensas'];
  }
  if (lower.includes('bardo') || lower.includes('músico') || lower.includes('cantante') || lower.includes('ídolo')) {
    return CANONICAL_ROLE_BACKGROUND_DATA['D4 Bardo Itinerante'];
  }
  if (lower.includes('clérigo') || lower.includes('sacerdotisa') || lower.includes('monje') || lower.includes('curandero')) {
    return CANONICAL_ROLE_BACKGROUND_DATA['E1 Clérigo de Guerra'];
  }
  if (lower.includes('paladín') || lower.includes('inquisidor')) {
    return CANONICAL_ROLE_BACKGROUND_DATA['E3 Paladín'];
  }
  if (lower.includes('druida') || lower.includes('chamán')) {
    return CANONICAL_ROLE_BACKGROUND_DATA['E6 Druida Chamán'];
  }
  if (lower.includes('aristócrata') || lower.includes('diplomático') || lower.includes('noble') || lower.includes('consejero')) {
    return CANONICAL_ROLE_BACKGROUND_DATA['F1 Aristócrata de Corte'];
  }
  if (lower.includes('príncipe') || lower.includes('rey') || lower.includes('señor de la guerra')) {
    return CANONICAL_ROLE_BACKGROUND_DATA['F8 Príncipe Heredero'];
  }
  if (lower.includes('sicario') || lower.includes('asesino') || lower.includes('ejecutor')) {
    return CANONICAL_ROLE_BACKGROUND_DATA['G1 Sicario de Gremio'];
  }
  if (lower.includes('venenista')) {
    return CANONICAL_ROLE_BACKGROUND_DATA['G2 Venenista'];
  }
  if (lower.includes('sombra') || lower.includes('infiltrador') || lower.includes('ninja')) {
    return CANONICAL_ROLE_BACKGROUND_DATA['G5 Sombra'];
  }
  if (lower.includes('maid') || lower.includes('sirviente') || lower.includes('esclavo')) {
    return CANONICAL_ROLE_BACKGROUND_DATA['A1 Maid de Mansión'];
  }
  if (lower.includes('mayordomo')) {
    return CANONICAL_ROLE_BACKGROUND_DATA['A2 Mayordomo Principal'];
  }
  if (lower.includes('artificiero') || lower.includes('mecánico')) {
    return CANONICAL_ROLE_BACKGROUND_DATA['A3 Artificiero'];
  }
  if (lower.includes('bibliotecario')) {
    return CANONICAL_ROLE_BACKGROUND_DATA['A4 Bibliotecario Arcano'];
  }
  if (lower.includes('erudito') || lower.includes('aprendiz') || lower.includes('academia')) {
    return CANONICAL_ROLE_BACKGROUND_DATA['A7 Erudito'];
  }

  // Final fallback
  return CANONICAL_ROLE_BACKGROUND_DATA['Civil Genérico'];
}
