import { CharacterState } from '../types';

export interface BodyPreset {
  id: string;
  name: string;
  category: string;
  description: string;
  anatomy: Partial<CharacterState['anatomy']>;
}

export interface FacialPreset {
  id: string;
  name: string;
  category: string;
  description: string;
  facial: Partial<CharacterState['facial']>;
}

export interface HairPreset {
  id: string;
  name: string;
  category: string;
  description: string;
  hair: Partial<CharacterState['hair']>;
}

export interface AppendicesPreset {
  id: string;
  name: string;
  category: string;
  description: string;
  appendices: Partial<CharacterState['appendices']>;
}

export const BODY_PRESETS: BodyPreset[] = [
  {
    id: 'heroic-athletic',
    name: 'Atleta Heroico / Guerrero Ágil',
    category: 'Humanoide Estándar',
    description: 'Proporciones atléticas equilibradas, hombros definidos, cintura estrecha y musculatura tonificada.',
    anatomy: {
      complexion: 'Atlética / Tonificada',
      height: 'Alta (180 - 188 cm)',
      breastDevelopment: 'C Senos Medianos / Pechos Equilibrados / Copa B-C',
      waist: 'Cintura Estrecha / Atlética en V',
      glutes: 'Firmes y Tonificados',
      thighs: 'Muslos Definidos y Fuertes'
    }
  },
  {
    id: 'colossal-titan',
    name: 'Coloso / Titán Berserker',
    category: 'Imponente / Pesado',
    description: 'Estatura masiva, hombros anchos colosales, caja torácica poderosa y fuerza bruta visible.',
    anatomy: {
      complexion: 'Musculosa Masiva / Titán',
      height: 'Gigante (205 - 220 cm+)',
      breastDevelopment: 'D Senos Prominentes / Pechos Voluminosos / Copa D',
      waist: 'Cintura Ancha / Centro de Gravedad Fuerte',
      glutes: 'Musculosos y Potentes',
      thighs: 'Muslos Masivos Columnas'
    }
  },
  {
    id: 'hourglass-voluptuous',
    name: 'Reloj de Arena Voluptuosa',
    category: 'Curvilíneo / Escultural',
    description: 'Silueta escultural con marcada diferencia entre cintura estrecha, busto pleno y caderas prominentes.',
    anatomy: {
      complexion: 'Curvilínea / Reloj de Arena Marcado',
      height: 'Media (165 - 172 cm)',
      breastDevelopment: 'E Senos Abundantes / Pechos Enormes / Copa DD-E',
      waist: 'Cintura de Avispa Hiper-Estrecha',
      glutes: 'Voluptuosos / Curvas Prominentes',
      thighs: 'Muslos Curvilíneos / Plenos'
    }
  },
  {
    id: 'slender-elven',
    name: 'Grácil Élfico / Silueta Esbelta',
    category: 'Elegante / Ligero',
    description: 'Líneas finas, elongadas y gráciles. Cintura delicada, postura etérea y porte aristocrático.',
    anatomy: {
      complexion: 'Delgada Grácil / Esbelta',
      height: 'Alta Estilizada (185 - 192 cm)',
      breastDevelopment: 'B Senos Pequeños / Pechos Discretos / Copa A',
      waist: 'Cintura Fina / Delicada',
      glutes: 'Atléticos Sutiles',
      thighs: 'Piernas Largas y Esbeltas'
    }
  },
  {
    id: 'agile-assassin',
    name: 'Acróbata / Asesino Veloz',
    category: 'Compacto / Veloz',
    description: 'Bajo centro de gravedad, cuerpo compacto y fibroso optimizado para el sigilo y la acrobacia.',
    anatomy: {
      complexion: 'Fibrosa Compacta / Ágil',
      height: 'Baja-Media (158 - 165 cm)',
      breastDevelopment: 'A Senos Planos / Pechos Incipientes / Copa AA',
      waist: 'Cintura Flexible y Estrecha',
      glutes: 'Compactos / Propulsores',
      thighs: 'Muslos Rápidos y Tonificados'
    }
  },
  {
    id: 'plasmoid-slime',
    name: 'Plasmoide / Slime Traslúcido',
    category: 'Entidad Especial',
    description: 'Cuerpo de gel viscoso moldeable con núcleo vital visible en el pecho y piel gelatinosa luminosa.',
    anatomy: {
      lowerBodyStructure: 'Slime / Gelatinoso que gotea y se expande en la base',
      chestCore: 'Núcleo de Cristal Arcano Palpitante con Energía Esmeralda',
      skinColor: 'Gelatinosa Traslúcida Cian / Aguamarina Luminosa',
      complexion: 'Delgada Grácil / Esbelta'
    }
  },
  {
    id: 'serpentine-lamia',
    name: 'Lamia / Gorgona Serpentina',
    category: 'Quimera Mitológica',
    description: 'Torso humanoide que se funde en una poderosa cola serpentina de escamas brillantes de 4 metros.',
    anatomy: {
      lowerBodyStructure: 'Lamia / Cola de Serpiente Escamosa de 4 metros',
      skinColor: 'Escamas Tornasoladas Esmeralda y Marfil',
      breastDevelopment: 'D Senos Prominentes / Pechos Voluminosos / Copa D',
      waist: 'Cintura de Avispa Marcada'
    }
  }
];

export const FACIAL_PRESETS: FacialPreset[] = [
  {
    id: 'elven-aristocrat',
    name: 'Aristócrata Élfico de Alto Linaje',
    category: 'Nobleza & Magia',
    description: 'Rostro afilado con pómulos prominentes, ojos almendrados con delineado fino y porte distante.',
    facial: {
      headShape: 'Ovalada Afilada / Élfica',
      headWidth: 'Estrecha / Rostro Fino',
      boneStructure: 'Pómulos Altos Esculpidos y Mandíbula Definida',
      eyesCategory: 'A - Ojos Almendrados',
      eyesSubtype: 'A1 - Almendrado Clásico Afilado',
      eyeliner: 'Cat Eye Alado Sofisticado',
      shadow: 'Sombra Ahumada Perlada',
      expression: 'Serena / Mirada Penetrante Aristocrática',
      nose: 'Griega Recta Perfilada',
      lips: 'Finos Elegantes con Arco de Cupido Marcado',
      teeth: 'Dientes Perfectos Alineados',
      mouthCorners: 'Ligeramente Elevadas / Media Sonrisa Misteriosa',
      mouthTexture: 'Satinado Natural',
      earsBase: 'Élficas Largas Puntiagudas',
      earsLength: 'Largas hacia Atrás (15-20cm)'
    }
  },
  {
    id: 'vampiric-gothic',
    name: 'Seductor Vampírico / Gótico Oscuro',
    category: 'Oscuro & Sobrenatural',
    description: 'Ojos penetrantes con sombra carmesí ahumada, colmillos alargados, tez pálida y labios carmesí brillante.',
    facial: {
      headShape: 'Triangular Invertido Afilado',
      boneStructure: 'Estructura Ósea Pronunciada / Cadavérica Elegante',
      eyesCategory: 'D - Ojos Felinos / Mirada Depredadora',
      eyesSubtype: 'D1 - Ojo Felino Rasgado con Pupila Vertical',
      eyeliner: 'Delineado Grueso Gótico / Kohl Oscuro',
      shadow: 'Sombra Borgoña / Carmesí Sangre con Degradado Negro',
      scleraColor: 'Esclerótica Negra Abisal con Iris Carmesí Brillante',
      expression: 'Sonrisa Burlona Depredadora / Confianza Absoluta',
      nose: 'Aguileña Fina / Aristocrática',
      lips: 'Carnosos con Contorno Definido',
      teeth: 'Colmillos Superiores Vampíricos Alargados Afilados',
      mouthCorners: 'Comisuras Afiladas',
      mouthTexture: 'Brillo Gloss Sangriento Jugoso',
      earsBase: 'Puntiagudas Cortas Vampíricas'
    }
  },
  {
    id: 'hardened-warrior',
    name: 'Guerrero Veterano de Mil Batallas',
    category: 'Militar & Marcial',
    description: 'Mandíbula cuadrada robusta, cejas densas, mirada firme inquebrantable y barba recortada.',
    facial: {
      headShape: 'Cuadrada Mandíbula Fuerte',
      headWidth: 'Ancha / Robusta',
      boneStructure: 'Mandíbula de Hierro y Pómulos Curtidos',
      eyesCategory: 'E - Ojos Encapotados / Mirada Firme',
      eyeliner: 'Sin Delineado / Natural Marcial',
      shadow: 'Sombreado Natural de Fatiga / Batalla',
      expression: 'Severa / Firmeza Inquebrantable',
      nose: 'Romana con Puente Fuerte',
      lips: 'Firmes y Rectos',
      teeth: 'Dientes Fuertes con Muesca de Combate',
      facialHair: 'Barba Corta Perfilada y Recortada',
      facialHairColor: 'Castaño Oscuro con Mechones Plateados / Canosos'
    }
  },
  {
    id: 'xianxia-jade',
    name: 'Inmortal de Jade / Cultivador Xianxia',
    category: 'Oriental & Místico',
    description: 'Rostro sereno impecable como el jade tallado, ojos fénix rasgados y belleza trascendente.',
    facial: {
      headShape: 'Ovalada Suave / Semilla de Melón',
      boneStructure: 'Rasgos de Porcelana Suaves sin Imperfecciones',
      eyesCategory: 'C - Ojos Rasgados / Ojos Fénix Orientales',
      eyesSubtype: 'C1 - Ojos Danfeng Fénix Ascendentes',
      eyeliner: 'Línea Roja Carmesí Tradicional en Rabillo Exterior',
      shadow: 'Sombra Rosa Melocotón Suave en Párpado Superior',
      expression: 'Paz Trascendente / Ojos que Contemplan el Dao',
      nose: 'Nariz Fina y Recta como Bambú',
      lips: 'Labios de Cerezo con Tinte Central en Degradé (Bitten Lip)',
      mouthTexture: 'Mate Aterciopelado',
      earsBase: 'Humanas Proporcionadas'
    }
  }
];

export const HAIR_PRESETS: HairPreset[] = [
  {
    id: 'noble-flowing-mane',
    name: 'Melena Imperial Larga y Sedosa',
    category: 'Elegante',
    description: 'Cabello lacio hasta la cadera, brillante como la seda, con partido al centro y caída impecable.',
    hair: {
      texture: 'Lacio Sedoso Impecable',
      length: 'Hasta la Cadera (80-90cm)',
      cut: 'Corte Recto con Capas Suaves Inferiores',
      part: 'Partido al Centro Clásico',
      bangs: 'Mechones Largos Laterales Enmarcando el Rostro',
      style: 'Suelto Flotante con Movimiento Eólico',
      hairColor: 'Negro Azabache con Reflejos Azul Noche'
    }
  },
  {
    id: 'viking-warrior-braids',
    name: 'Trenzas de Batalla Nórdicas con Anillos',
    category: 'Guerrero & Épico',
    description: 'Trenzas laterales holandesas entrelazadas con anillos metálicos y coleta central densa.',
    hair: {
      texture: 'Ondulado Grueso / Rebelde',
      length: 'Hasta el Pecho / Omóplatos',
      cut: 'Undercut Lateral Rapado con Corona Larga',
      style: 'Trenzas Vikingas Múltiples con Cuentas y Anillos Rúnicos',
      hairColor: 'Rubio Ceniza / Platino Nórdico'
    }
  },
  {
    id: 'ronin-high-ponytail',
    name: 'Coleta Alta de Samurái / Ronin',
    category: 'Oriental & Marcial',
    description: 'Cabello recogido en coleta alta tensada con lazo de cuero y mechones sueltos rebeldes.',
    hair: {
      texture: 'Lacio Grueso',
      length: 'Hasta los Hombros / Espalda Media',
      cut: 'Despuntado Desfilado',
      style: 'Coleta Alta Tensada con Nudo de Batalla',
      bangs: 'Flequillo Lateral Desfilado al Ojo',
      hairColor: 'Negro Cuervo Profundo'
    }
  },
  {
    id: 'elemental-flame-hair',
    name: 'Cabello de Fuego Viviente / Plasma Ígneo',
    category: 'Elemental / Mágico',
    description: 'Melena compuesta de llamas doradas y carmesí palpitantes con chispas ardientes flotantes.',
    hair: {
      texture: 'Ondas de Fuego Fluido',
      length: 'Hasta la Cintura Flotante',
      style: 'Melena Eterna Antigravitatoria con Chispas Ígneas',
      hairElemental: 'Fuego Vivo Ardiente con Llamas Carmesí y Chispas Doradas',
      hairColor: 'Degradado Fuego (Rojo Rubí a Dorado Solar Radiante)'
    }
  },
  {
    id: 'cyberpunk-neon-bob',
    name: 'Bob Asimétrico Neón Cyberpunk',
    category: 'Futurista & Cyberpunk',
    description: 'Corte asimétrico afilado con mechas holográficas reactivas a la luz y rapado lateral.',
    hair: {
      texture: 'Lacio Afilado Estructurado',
      length: 'Corto Asimétrico (Mandíbula a Cuello)',
      cut: 'Bob Asimétrico Afilado con Undercut',
      bangs: 'Flequillo Recto Micro-Bang Futurista',
      hairColor: 'Cian Neón Eléctrico con Puntas Magenta Reactivo'
    }
  }
];

export const APPENDICES_PRESETS: AppendicesPreset[] = [
  {
    id: 'ancestral-dragon',
    name: 'Dragón Imperial Ancestral',
    category: 'Dracónico & Épico',
    description: 'Cuernos curvados imponentes, alas membranosas dracónicas, cola acorazada y escamas en pómulos y brazos.',
    appendices: {
      hornsForm: 'Curvados hacia Atrás / Corona Dracónica',
      hornsLength: 'Grandes e Imponentes (30-40cm)',
      hornsThickness: 'Gruesos con Textura de Cresta Anillada',
      hornsPosition: 'Laterales de la Frente / Sienes',
      wingsType: 'Alas Dracónicas Membranosas con Garras en los Codos',
      wingsSize: 'Grandes / Envergadura de 3.5 Metros',
      wingsPosition: 'Espalda Media / Omóplatos',
      tailsType: 'Cola Dracónica Escamosa con Espinas Dorsales y Punta Acorazada',
      tailsLength: 'Larga y Fuerte (1.8 Metros)',
      skinAndMarks: 'Escamas de Dragón en Pómulos, Hombros y Antebrazos',
      scaleLocations: ['Pómulos y Sienes', 'Hombros y Clavículas', 'Antebrazos y Manos', 'Columna Vertebral']
    }
  },
  {
    id: 'abyssal-succubus',
    name: 'Súcubo / Íncubo Abisal',
    category: 'Demoníaco & Seductor',
    description: 'Cuernos curvados oscuros pulidos, alas de murciélago elegantes y cola delgada con punta en flecha / pica.',
    appendices: {
      hornsForm: 'Espirales Demoníacos / Pulidos como Obsidiana',
      hornsLength: 'Medios Elegantes (20cm)',
      hornsThickness: 'Finos a Medios con Puntas Afiladas',
      hornsPosition: 'Parte Superior de la Frente',
      wingsType: 'Alas de Murciélago Membranosas Finas',
      wingsSize: 'Medianas Plegables',
      wingsPosition: 'Espalda Alta',
      tailsType: 'Cola Delgada y Flexible con Punta de Flecha / Corazón Afilado',
      tailsLength: 'Larga y Sinuosa (1.5 Metros)',
      skinAndMarks: 'Piel de Porcelana Pálida con Tatuajes Rúnicos Carmesí'
    }
  },
  {
    id: 'celestial-seraph',
    name: 'Serafín Celestial Divino',
    category: 'Angélico & Sagrado',
    description: 'Seis alas emplumadas de blancura pura con filamentos dorados que emanan partículas de luz.',
    appendices: {
      hornsForm: 'Ninguno',
      wingsType: 'Alas Emplumadas Divinas de Serafín con Plumas Blancas y Filamentos de Oro',
      wingsSize: 'Colosales / Triple Par de Alas de 4 Metros',
      wingsPosition: 'Espalda Completa (Alta, Media y Baja)',
      tailsType: 'Ninguna',
      skinAndMarks: 'Sellos Sagrados Dorados en Frente y Pecho'
    }
  },
  {
    id: 'mystic-kitsune',
    name: 'Kitsune Místico de Nueve Colas',
    category: 'Kemono & Bestia Espiritual',
    description: 'Orejas de zorro esponjosas con pelaje interno blanco y nueve colas voluptuosas de fuego fatuo.',
    appendices: {
      hornsForm: 'Ninguno',
      wingsType: 'Ninguna',
      tailsType: 'Nueve Colas de Zorro Espirituales con Puntas de Fuego Azul / Blanco',
      tailsLength: 'Voluptuosas y Largas (1.6 Metros)',
      skinAndMarks: 'Marcas Faciales de Zorro Carmesí en Mejillas y Frente'
    }
  },
  {
    id: 'sylvan-faun',
    name: 'Fauno / Caprinae de los Bosques',
    category: 'Férico & Silvano',
    description: 'Cuernos de carnero anillados, cuello cubierto de lana suave, orejas caídas y patas caprinas con pezuñas.',
    appendices: {
      hornsForm: 'Espirales de Carnero Alrededor de las Orejas',
      hornsLength: 'Grandes Espirales',
      hornsThickness: 'Gruesos Anillados',
      hornsPosition: 'Laterales de la Cabeza',
      wingsType: 'Ninguna',
      tailsType: 'Cola Corta Esponjosa de Ciervo / Cabra',
      tailsLength: 'Corta (15cm)',
      skinAndMarks: 'Peceras y Marcas Naturales de Corteza'
    }
  }
];
