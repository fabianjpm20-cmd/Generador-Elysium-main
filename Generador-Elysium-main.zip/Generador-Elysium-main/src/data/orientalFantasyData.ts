export interface OrientalTradition {
  id: string;
  name: string;
  subtitle: string;
  category: string;
  description: string;
  iconTag: string;
  suggestedArmor: string[];
  suggestedAccessories: string[];
  suggestedWeapon: string;
  suggestedMotif: string;
  suggestedSilk: string;
  suggestedJade: string;
  suggestedAura: string;
}

export interface OrientalPieceOption {
  id: string;
  name: string;
  category: 'Armadura Torso' | 'Hombreras & Brazos' | 'Cabeza & Máscara' | 'Piernas & Pies' | 'Accesorio Sagrado' | 'Joyería & Cabello' | 'Prenda Flotante';
  culturalOrigin: string;
  description: string;
  icon?: string;
}

export const ORIENTAL_TRADITIONS: OrientalTradition[] = [
  {
    id: 'XIANXIA',
    name: 'Xianxia / Cultivador Inmortal Taoísta',
    subtitle: 'Arquetipo de Ascensión Celestial',
    category: 'Místico & Daoísta',
    description: 'Túnicas de seda flotante de múltiples capas con mangas anchas, horquillas de jade pulido, talismanes flotantes y espada voladora espiritual.',
    iconTag: '☯️ Dao / Xianxia',
    suggestedArmor: ['Peto Shanwenjia Ligero de Escamas de Montaña', 'Faja Kuadai con Placas de Jade Blanco Hetian'],
    suggestedAccessories: ['Horquilla Zan de Jade con Borlas de Seda', 'Colgante de Jade Espiritual y Nudo Infinito Chino', 'Talismanes Ofuda / Taoístas Flotantes', 'Calabaza Hulu de Elixir de Inmortalidad'],
    suggestedWeapon: 'Espada Jian Recta de Doble Filo con Borla Sagrada',
    suggestedMotif: 'Nubes Celestiales Taoístas & Loto de Nácar',
    suggestedSilk: 'Gasa Translúcida Multicapa con Hilos de Plata',
    suggestedJade: 'Jade Hetian Blanco Puro',
    suggestedAura: 'Qi Espiritual Dorado & Hojas de Loto Luminosas'
  },
  {
    id: 'WUXIA',
    name: 'Wuxia / Espadachín Errante (Jianghu)',
    subtitle: 'Héroe Solitario de los Caminos',
    category: 'Marcial & Aventura',
    description: 'Sombrero cónico douli de bambú con velo de gasa oscura, brazales de cuero reforzado, faja ancha de tela, calabaza de vino al cinto y letal espada jian o sable dao.',
    iconTag: '⚔️ Jianghu / Wuxia',
    suggestedArmor: ['Jubón de Cuero Reforzado y Seda Oscura', 'Brazales de Cuero de Bambú y Metal Lacado (Biguan)'],
    suggestedAccessories: ['Sombrero Douli / Kasa de Paja con Velo de Gasa Flotante', 'Pipa Larga Tradicional de Latón y Ébano (Yandai)', 'Calabaza Hulu de Elixir / Vino de Jianghu'],
    suggestedWeapon: 'Sable Curvo Dao / Jian con Empuñadura Encordada',
    suggestedMotif: 'Bambú y Flor de Ciruelo en la Nieve',
    suggestedSilk: 'Sarga Negra Mate y Algodón Reforzado',
    suggestedJade: 'Jade Negro Ébano',
    suggestedAura: 'Niebla de Tinta / Suibokuga Mística'
  },
  {
    id: 'IMPERIAL_GUARD',
    name: 'Guardia Imperial / Dinastía Celestial',
    subtitle: 'Élite Marcial de la Ciudad Prohibida',
    category: 'Militar Dinástico',
    description: 'Imponente armadura lamelar dorada y escarlata, hombreras con cabezas de león o dragón, capa escarlata forrada y sable imperial de mando.',
    iconTag: '🐉 Dinastía Imperial',
    suggestedArmor: ['Armadura Lamelar Shanwenjia (Escamas de Montaña)', 'Hombreras de Cabeza de Dragón Dorado (Longlin)', 'Peto Brigantina Dingjia Tachonado de Bronce', 'Grebas Dingjia Reforzadas'],
    suggestedAccessories: ['Faja Kuadai con Placas de Jade Blanco Hetian', 'Capa Imperial Escarlata de Seda Pesada', 'Anillo de Pulgar de Jade para Arquero (Ban Zhi)'],
    suggestedWeapon: 'Lanza Guandao de Dragón Imperial',
    suggestedMotif: 'Dragón Celestial Dorado de Cinco Garras',
    suggestedSilk: 'Brocado Imperial con Hilos de Oro Puro',
    suggestedJade: 'Jade Verde Esmeralda Imperial',
    suggestedAura: 'Resplandor Solar Imperial y Cenizas de Dragón'
  },
  {
    id: 'SAMURAI_MYSTIC',
    name: 'Samurái / Místico Sengoku',
    subtitle: 'Honor, Acero Plegado y Deber Ancestral',
    category: 'Marcial de Élite',
    description: 'Armadura tradicional dō lacada en negro y bermellón, hombreras sode articuladas con cordones de seda, máscara demoníaca menpo y katana forjada.',
    iconTag: '🏯 Sengoku / Bushido',
    suggestedArmor: ['Coraza Dō Lacada en Negro y Bermellón', 'Hombreras Lamelares Sode con Cordaje de Seda', 'Máscara Facial Demoníaca Menpo', 'Espinilleras Suneate con Placas de Hierro'],
    suggestedAccessories: ['Abanico de Guerra Tessen / Gunbai de Acero y Oro', 'Cordón Trenzado Odoshi de Seda Carmesí', 'Mon con Escudo de Clan Familiar'],
    suggestedWeapon: 'Katana Forjada en Acero Plegado Tamahagane',
    suggestedMotif: 'Flor de Cerezo y Ondas de Agua (Seigaiha)',
    suggestedSilk: 'Seda Pesada con Tejido Chirimen',
    suggestedJade: 'Jade Rojo Sangre / Laca Bermellón',
    suggestedAura: 'Flores de Cerezo Iluminadas y Chispas de Acero'
  },
  {
    id: 'ONMYOJI_SHINTO',
    name: 'Onmyoji / Hechicero Shintoísta',
    subtitle: 'Maestro del Yin-Yang y los Espíritus Shikigami',
    category: 'Mágico & Espiritual',
    description: 'Túnica blanca sacerdotal kariginu, sombrero alto eboshi negro, abanico ceremonial sensu, talismanes espirituales de papel y sellos bagua flotantes.',
    iconTag: '⛩️ Onmyodo / Shinto',
    suggestedArmor: ['Manto Ceremonial Kariginu con Cordones Trenzados', 'Hakama Sacerdotal Escarlata de Seda'],
    suggestedAccessories: ['Talismanes Ofuda / Taoístas Flotantes', 'Abanico Ceremonial Sensu con Pintura Dorada', 'Campanilla Ritual Fengling / Suzu con Cascabel de Bronce', 'Espejo Sagrado de Bronce Protector'],
    suggestedWeapon: 'Báculo Monacal Khakkhara con Anillos Sonoros',
    suggestedMotif: 'Sello Yin-Yang Bagua y Estrellas Pentagrámicas',
    suggestedSilk: 'Seda Blanca Sagrada Inmaculada',
    suggestedJade: 'Jade Lavanda Místico',
    suggestedAura: 'Aura Relampagueante Azur y Papeles Shikigami'
  },
  {
    id: 'SHINOBI_SHADOW',
    name: 'Shinobi / Asesino de las Sombras',
    subtitle: 'Sigilo Nocturno y Letalidad Ancestral',
    category: 'Sigilo & Espionaje',
    description: 'Traje shinobi shozoku ceñido de seda oscura reflectora de luz de luna, máscara facial de tela, muñequeras kyahan con compartimentos y kunai ocultos.',
    iconTag: '🌑 Shinobi / Ninjutsu',
    suggestedArmor: ['Chaleco Táctico Shinobi Acolchado Antiestocadas', 'Protectores de Antebrazo y Espinillas Kyahan'],
    suggestedAccessories: ['Máscara Mengu de Sigilo', 'Vendas de Seda Negra en Manos y Tobillos', 'Bolsas Ocultas para Shuriken y Polvo Ciego'],
    suggestedWeapon: 'Doble Ninjato Curvo y Agujas Voladoras Emeici',
    suggestedMotif: 'Loto Negro y Creciente Lunar',
    suggestedSilk: 'Seda Negra de Absorción de Luz',
    suggestedJade: 'Jade Negro Ébano',
    suggestedAura: 'Niebla Nocturna de Sombras y Humo de Tinta'
  },
  {
    id: 'CELESTIAL_HANFU',
    name: 'Corte Celestial / Hanfu Místico',
    subtitle: 'Gracia Divina, Realeza de las Alturas',
    category: 'Alta Nobleza Mística',
    description: 'Suntuoso vestido Hanfu de capas translúcidas superpuestas, mangas anchas de agua ondulantes, capa flotante pibo, tiara fénix de filigrana dorada y gemas de jade.',
    iconTag: '🦚 Hanfu Celestial',
    suggestedArmor: ['Corsé de Seda Estructurado con Bordados de Fénix', 'Fajín Ancho Kuadai con Borlas de Perlas'],
    suggestedAccessories: ['Tiara Fénix de Filigrana Dorada con Borlas (Fengguan)', 'Horquilla Zan de Jade con Borlas de Seda', 'Capa Flotante Pibo / Hagoromo de Hilos Celestiales', 'Colgante de Jade Espiritual y Nudo Infinito Chino'],
    suggestedWeapon: 'Cítara Guqin Encantada con Sonidos de Dragón',
    suggestedMotif: 'Fénix Inmortal Carmesí (Fenghuang)',
    suggestedSilk: 'Seda Damascada con Lotos Flotantes y Bordados de Oro',
    suggestedJade: 'Jade Hetian Blanco con Perlas de Río',
    suggestedAura: 'Resplandor Iridiscente y Pétalos de Ciruelo Flotantes'
  }
];

export const ORIENTAL_ARMOR_PIECES: OrientalPieceOption[] = [
  {
    id: 'ARM_SHANWENJIA',
    name: 'Peto Shanwenjia (Escamas de Montaña)',
    category: 'Armadura Torso',
    culturalOrigin: 'China Tang / Song',
    description: 'Armadura icónica formada por placas metálicas entrelazadas con forma de estrella de tres puntas que forman una cota impenetrable y flexible.'
  },
  {
    id: 'ARM_DO_LACQUER',
    name: 'Coraza Dō Lacada en Negro y Bermellón',
    category: 'Armadura Torso',
    culturalOrigin: 'Japón Sengoku / Edo',
    description: 'Coraza de placas de acero endurecido y cuero recubierta de laca pulida protectora, atada con cordones de seda colorida odoshi.'
  },
  {
    id: 'ARM_DINGJIA',
    name: 'Peto Brigantina Dingjia Tachonado de Bronce',
    category: 'Armadura Torso',
    culturalOrigin: 'China Ming / Qing',
    description: 'Chaqueta de seda pesada o terciopelo con placas de metal remachadas por dentro, mostrando filas de tachones dorados en el exterior.'
  },
  {
    id: 'ARM_DRAGON_SHOULDERS',
    name: 'Hombreras de Cabeza de Dragón Dorado (Longlin)',
    category: 'Hombreras & Brazos',
    culturalOrigin: 'Mitología Dinástica',
    description: 'Hombreras esculpidas con fauces de dragón dorado de cuyas bocas surgen placas de escamas metálicas superpuestas.'
  },
  {
    id: 'ARM_SODE',
    name: 'Hombreras Lamelares Sode con Cordaje de Seda',
    category: 'Hombreras & Brazos',
    culturalOrigin: 'Japón Tradicional',
    description: 'Grandes placas defensivas rectangulares de láminas de hierro atadas con cordoncillos de seda, protegiendo los hombros durante el combate.'
  },
  {
    id: 'ARM_BIGUAN_BRACERS',
    name: 'Brazales de Cuero de Bambú y Metal Lacado (Biguan / Kote)',
    category: 'Hombreras & Brazos',
    culturalOrigin: 'China / Japón',
    description: 'Brazales reforzados con placas metálicas y varillas de bambú endurecido, grabados con motivos de nubes o kanjis de protección.'
  },
  {
    id: 'ARM_MENPO_MASK',
    name: 'Máscara Facial Demoníaca Menpo / Gui Mian',
    category: 'Cabeza & Máscara',
    culturalOrigin: 'Japón / China Mística',
    description: 'Media máscara de hierro lacado con expresión de ogro demoníaco (Oni / Yaoguai), con bigotes de cerdas y protector de garganta.'
  },
  {
    id: 'ARM_KABUTO_HELM',
    name: 'Yelmo Kabuto con Maedate de Media Luna Dorada',
    category: 'Cabeza & Máscara',
    culturalOrigin: 'Japón Samurai',
    description: 'Casco de múltiples placas remachadas con cresta ornamental de luna creciente de latón pulido y protector de nuca shikoro.'
  },
  {
    id: 'ARM_SUNEATE_GREAVES',
    name: 'Espinilleras Suneate con Placas de Hierro y Seda',
    category: 'Piernas & Pies',
    culturalOrigin: 'Japón Tradicional',
    description: 'Grebas formadas por láminas verticales de acero unidas por malla de hierro sobre un forro de tela bordada, atadas con tiras de cuero.'
  },
  {
    id: 'ARM_KUADAI_BELT',
    name: 'Faja Kuadai con Placas de Jade Blanco Hetian',
    category: 'Armadura Torso',
    culturalOrigin: 'China Dinástica',
    description: 'Cinturón ceremonial de cuero forrado de seda con placas rectangulares de auténtico jade blanco tallado que denotan alto rango.'
  }
];

export const ORIENTAL_CULTURAL_ACCESSORIES: OrientalPieceOption[] = [
  {
    id: 'ACC_DOULI_HAT',
    name: 'Sombrero Douli / Kasa de Paja con Velo de Gasa Flotante',
    category: 'Cabeza & Máscara',
    culturalOrigin: 'Tradición Jianghu / Wuxia',
    description: 'Sombrero cónico tejido de bambú del cual cuelga un velo translúcido de gasa negra o blanca que oculta la mirada y protege de la intemperie.'
  },
  {
    id: 'ACC_ZAN_HAIRPIN',
    name: 'Horquilla Zan / Kanzashi de Jade y Borlas de Seda',
    category: 'Joyería & Cabello',
    culturalOrigin: 'Corte Imperial Hanfu',
    description: 'Elegante horquilla de jade blanco tallado con motivos florales, de la que cuelgan finas cadenas de oro y borlas de seda teñida.'
  },
  {
    id: 'ACC_JADE_PENDANT',
    name: 'Colgante de Jade Espiritual y Nudo Infinito Chino',
    category: 'Accesorio Sagrado',
    culturalOrigin: 'Tradición Taoísta',
    description: 'Medallón circular Bi de jade puro suspendido por un elaborado cordón rojo trenzado en nudo de la buena fortuna y borla caída.'
  },
  {
    id: 'ACC_WAR_FAN',
    name: 'Abanico de Guerra Tessen / Sensu de Pan de Oro',
    category: 'Accesorio Sagrado',
    culturalOrigin: 'Corte & Estrategia Marcial',
    description: 'Abanico plegable con varillas exteriores de acero afilado y tela de seda pintada a mano con caligrafía o dragones sobre pan de oro.'
  },
  {
    id: 'ACC_TALISMANS_OFUDA',
    name: 'Talismanes Ofuda / Taoístas de Purificación Flotantes',
    category: 'Accesorio Sagrado',
    culturalOrigin: 'Daoísmo & Onmyodo',
    description: 'Tiras de papel amarillo sagrado escritas con tinta bermellón de cinabrio que canalizan encantamientos de sellado y protección espiritual.'
  },
  {
    id: 'ACC_KISERU_PIPE',
    name: 'Pipa Larga Tradicional de Latón y Ébano (Kiseru / Yandai)',
    category: 'Accesorio Sagrado',
    culturalOrigin: 'Cultura Clásica Oriental',
    description: 'Pipa esbelta con cazoleta y boquilla de latón dorado labrado unidas por un tubo de madera oscura de ébano pulido.'
  },
  {
    id: 'ACC_HULU_GOURD',
    name: 'Calabaza Hulu de Elixir Espiritual y Cintas Escarlata',
    category: 'Accesorio Sagrado',
    culturalOrigin: 'Xianxia / Wuxia',
    description: 'Calabaza seca natural pulida y lacada, atada a la cintura con un cordón escarlata, utilizada para contener vino medicinal o píldoras de cultivo.'
  },
  {
    id: 'ACC_PIBO_CLOAK',
    name: 'Capa Pibo / Hagoromo de Seda Celestial Flotante',
    category: 'Prenda Flotante',
    culturalOrigin: 'Mitología Celestial / Hanfu',
    description: 'Estola larga y etérea de gasa translúcida que flota grácilmente alrededor de los hombros y brazos del personaje, emulando hadas inmortales.'
  },
  {
    id: 'ACC_HEADBAND_TAO',
    name: 'Cinta Frontal de Cultivador con Nubes Sagradas',
    category: 'Joyería & Cabello',
    culturalOrigin: 'Sectas de Cultivo Xianxia',
    description: 'Cinta de seda inmaculada con una placa de jade en el centro grabada con nubes celestiales, símbolo de pureza y linaje inmortal.'
  },
  {
    id: 'ACC_THUMB_RING',
    name: 'Anillo de Pulgar de Jade para Arquero (Ban Zhi)',
    category: 'Joyería & Cabello',
    culturalOrigin: 'Nobleza y Arquería Dinástica',
    description: 'Anillo cilíndrico grueso de jade translúcido usado en el pulgar para liberar la cuerda del arco compuesto con precisión milimétrica.'
  },
  {
    id: 'ACC_FENGLING_BELL',
    name: 'Campanilla Ritual Fengling / Suzu con Cascabel de Bronce',
    category: 'Accesorio Sagrado',
    culturalOrigin: 'Templos y Santuarios',
    description: 'Pequeña campanilla de bronce afinada para emitir un tañido melodioso que ahuyenta a los malos espíritus con el viento.'
  },
  {
    id: 'ACC_BAGUA_MIRROR',
    name: 'Espejo Bagua de Bronce Protector y Símbolos de los Ocho Trigramas',
    category: 'Accesorio Sagrado',
    culturalOrigin: 'Daoísmo Tradicional',
    description: 'Espejo cóncavo octogonal de bronce grabado con los ocho trigramas que desvía la energía negativa (Sha Qi).'
  }
];

export const ORIENTAL_SPIRITUAL_MOTIFS = [
  'Dragón Celestial Dorado (Lóng / Ryū)',
  'Fénix Inmortal Carmesí (Fenghuang / Suzaku)',
  'Tigre Blanco del Viento Otoñal (Baihu / Byakko)',
  'Tortuga Negra y Serpiente Espiritual (Xuanwu / Genbu)',
  'Flor de Loto Sagrada de Nácar Flotante',
  'Nubes Celestiales Taoístas & Viento Divino',
  'Sello Yin-Yang Bagua con Trigramas Sagrados',
  'Bambú Verdeante & Flor de Ciruelo en la Nieve',
  'Carpa Koi Ascendiendo la Cascada del Dragón',
  'Flores de Cerezo Sakura Iluminadas por la Luna'
];

export const ORIENTAL_SILK_PATTERNS = [
  'Brocado Imperial con Hilos de Oro Puro y Dragones',
  'Seda Damascada con Flores de Loto Flotantes',
  'Gasa Translúcida Multicapa con Hilos de Plata',
  'Sarga Negra Mate con Motivos Geométricos Ocultos',
  'Seda Carmesí con Patrón Tradicional de Olas (Seigaiha)',
  'Seda Chirimen con Textura Ondulada de Gran Caída',
  'Lino Crudo Rústico con Teñido de Añil (Shibori)'
];

export const ORIENTAL_JADE_COLORS = [
  { id: 'hetian_white', name: 'Jade blanco', hex: '#F0FDF4', desc: 'Virtud suprema e inmortalidad' },
  { id: 'imperial_emerald', name: 'Jade verde', hex: '#059669', desc: 'Nobleza y vitalidad' },
  { id: 'black_ebony', name: 'Jade negro', hex: '#18181B', desc: 'Protección y sigilo' },
  { id: 'lavender_mystic', name: 'Jade lavanda', hex: '#C084FC', desc: 'Conexión astral y magia' },
  { id: 'blood_red', name: 'Jade rojo', hex: '#DC2626', desc: 'Fuerza marcial y energía' }
];

export const ORIENTAL_WEAPONS = [
  { name: 'Espada Recta Jian de Doble Filo con Borla Sagrada', type: 'Espada', desc: 'El caballero de las armas, ligera y precisa con borla estabilizadora' },
  { name: 'Sable Curvo Dao con Hoja Ancha Forjada', type: 'Sable', desc: 'El general de las armas, demoledor en cortes fluidos' },
  { name: 'Katana Forjada en Acero Plegado Tamahagane', type: 'Sable', desc: 'Filo curvado perfecto pulido al espejo con línea hamon visible' },
  { name: 'Lanza Guandao con Cuchilla de Dragón Pesada', type: 'Arma de Asta', desc: 'Gran cuchilla curva montada sobre asta de madera férrea' },
  { name: 'Lanza Naginata con Hoja Curva y Protector Tsuba', type: 'Arma de Asta', desc: 'Elegante y veloz arma de asta para barridos letales' },
  { name: 'Cítara Guqin Encantada con Cuerdas de Seda Mágicas', type: 'Instrumento Marcial', desc: 'Proyecta ondas de choque sónicas y cortes de energía Qi' },
  { name: 'Arco Asimétrico Yumi / Daqiu de Bambú y Cuerno', type: 'Arma a Distancia', desc: 'Largo alcance y tremenda potencia de penetración' },
  { name: 'Doble Dagas Emeici / Agujas Voladoras Acupunturales', type: 'Arma Oculta', desc: 'Armas de rotación rápida y punzones perfora-armaduras' },
  { name: 'Báculo Monacal Khakkhara con Anillos de Bronce', type: 'Báculo', desc: 'Báculo sagrado cuyos aros tintinean alertando a los espíritus' }
];

export const ORIENTAL_AURAS = [
  'Qi Espiritual Dorado & Hojas de Loto Luminosas',
  'Niebla de Tinta / Suibokuga Flotante con Caracteres Antiguos',
  'Fuego de Fénix Carmesí & Cenizas Chispeantes',
  'Aura Relampagueante Azur del Dragón del Trueno',
  'Flores de Cerezo Iluminadas Flotando en el Viento',
  'Viento Helado de Jade & Escarcha de Nieve',
  'Niebla de Sombra Oscura con Reflejos Lunares',
  'Sin Aura (Aspecto Natural Puramente Físico)'
];
