export interface WeaponDetailConfig {
  bladeOrHeadTypes: string[];
  guardStyles: string[];
  gripStyles: string[];
  pommelOrBaseStyles: string[];
  enchantmentsOrAuras: string[];
  scabbardOrCarryingPlacements: string[];
  materials: string[];
  finishes: string[];
}

export interface ArmorPieceOptionGroup {
  slot: 'P1' | 'P2' | 'P3' | 'P4' | 'P5' | 'P6' | 'P7';
  slotName: string;
  lengths: string[];
  materials: string[];
  finishes: string[];
  detailLocations: string[];
  suggestedDetails: string[];
}

export const ARMOR_SLOT_CONFIGS: Record<'P1' | 'P2' | 'P3' | 'P4' | 'P5' | 'P6' | 'P7', ArmorPieceOptionGroup> = {
  P1: {
    slot: 'P1',
    slotName: 'Cabeza, Rostro & Cuello (Cascos, Coronas, Máscaras, Diademas, Capuchas)',
    lengths: [
      'Tiara / Diadema de Frente',
      'Corona Imperial con Puntas',
      'Máscara Facial Completa / Visor',
      'Antifaz / Media Máscara',
      'Casco Completo con Visera',
      'Celada Abierta de Batalla',
      'Capucha con Caída al Pecho',
      'Gargantilla / Collar al Cuello'
    ],
    materials: [
      'Oro',
      'Plata',
      'Acero',
      'Titanio',
      'Seda',
      'Terciopelo',
      'Cuero',
      'Obsidiana',
      'Jade',
      'PVC'
    ],
    finishes: [
      'Pulido espejo',
      'Mate satinado',
      'Filigrana',
      'Desgastado',
      'Esmaltado',
      'Luminiscente'
    ],
    detailLocations: [
      'Frente Central / Tercer Ojo',
      'Borde y Ribete Perimetral',
      'Laterales de las Sienes / Orejeras',
      'Visera y Ranura Ocular',
      'Puntas de Corona / Cresta Superior',
      'Protector de Barbilla y Mandíbula',
      'Gorguera / Cuello Inferior'
    ],
    suggestedDetails: [
      'Gema central engarzada',
      'Plumas heráldicas en la cresta',
      'Grabado de runas de protección',
      'Filigrana de espirales vegetales',
      'Visor holográfico HUD',
      'Cotas de malla colgantes en la nuca',
      'Relieve heráldico en el frontal'
    ]
  },
  P2: {
    slot: 'P2',
    slotName: 'Torso & Pecho (Corazas, Pecheras, Jubones, Corseletes, Túnicas de Mago)',
    lengths: [
      'Pechera Corta Torácica',
      'Coraza Completa Frontal y Dorsal',
      'Jubón Entallado a la Cintura',
      'Túnica hasta los Tobillos',
      'Corselete Ajustado con Cordones',
      'Arnés Táctico Modular',
      'Cota de Malla a la Cadera'
    ],
    materials: [
      'Acero',
      'Mithril',
      'Plata',
      'Titanio',
      'Cuero',
      'Seda',
      'Malla de acero',
      'PVC'
    ],
    finishes: [
      'Bruñido',
      'Pavonado mate',
      'Pulido espejo',
      'Encerado',
      'Iridiscente',
      'Martillado'
    ],
    detailLocations: [
      'Pectoral Izquierdo (Sobre el Corazón)',
      'Pechera Central y Esternón',
      'Costillas y Flancos Laterales',
      'Escote y Borde de Clavícula',
      'Línea de Abdomen / Faldilla',
      'Costuras de Refuerzo y Placas Solapadas'
    ],
    suggestedDetails: [
      'Emblema heráldico grabado en el pecho',
      'Láminas de escamas de dragón / escamas metálicas imbricadas',
      'Ribete de piel salvaje / borrego en sisas y cuello',
      'Remaches y tachuelas de bronce',
      'Conductos de refrigeración luminiscentes',
      'Costuras reforzadas con hilo de plata',
      'Placas articuladas solapadas',
      'Rebordes festoneados con motivos florales',
      'Correajes de cuero cruzados con hebillas'
    ]
  },
  P3: {
    slot: 'P3',
    slotName: 'Hombros, Brazos & Manos (Hombreras, Brazales, Guanteletes, Manguitos)',
    lengths: [
      'Hombreras Articuladas de 3 Láminas',
      'Guanteletes con Dedos Articulados',
      'Brazales de Antebrazo',
      'Manguitos de Seda Flotantes',
      'Hombreras Maxi con Puntas',
      'Mitones de Cuero sin Dedos',
      'Protectores de Codo'
    ],
    materials: [
      'Acero',
      'Cuero',
      'Titanio',
      'Malla de plata',
      'Seda',
      'Obsidiana',
      'Bronce',
      'PVC'
    ],
    finishes: [
      'Pulido brillante',
      'Cuero desgastado',
      'Mate',
      'Cromado',
      'Esmaltado'
    ],
    detailLocations: [
      'Cúpula de la Hombrera',
      'Láminas Escalonadas Inferiores',
      'Dorso de la Mano / Nudillos de Guantelete',
      'Antebrazo Exterior',
      'Codo y Articulación',
      'Muñeca y Puño Cerrado'
    ],
    suggestedDetails: [
      'Vendas de tela rústica bajo muñequeras de cuero con hebillas',
      'Púas defensivas cónicas en los nudillos',
      'Grabado rúnico en el antebrazo',
      'Hebillas dobles ajustables con remaches',
      'Emblema o relieve en la hombrera',
      'Reloj o comunicador táctico en la muñeca',
      'Bordes ribeteados en piel'
    ]
  },
  P4: {
    slot: 'P4',
    slotName: 'Cintura & Cinto (Cinturones, Fajas, Obi, Tahalí, Arneses, Cartucheras)',
    lengths: [
      'Cinturón Ancho de Cuero Doble Hebilla',
      'Faja / Obi Tradicional de 4 Vueltas',
      'Tahalí Cruzado de Pecho a Cintura',
      'Cinto Táctico con Bolsillos',
      'Cinturón Metálico con Placas',
      'Fajín de Seda con Caída Lateral'
    ],
    materials: [
      'Cuero',
      'Seda',
      'Latón',
      'Bronce',
      'Nylon',
      'Oro',
      'Plata',
      'Metal'
    ],
    finishes: [
      'Satinado',
      'Cepillado',
      'Envejecido',
      'Jacquard brillante',
      'Mate'
    ],
    detailLocations: [
      'Hebilla Central Frontal',
      'Lateral Izquierdo (Anclaje de Vaina)',
      'Lateral Derecho (Bolsa de Pociones / Munición)',
      'Espalda / Cierre Posterior',
      'Extremos Colgantes del Fajín / Lazo',
      'Guías y Pasadores de Cinto'
    ],
    suggestedDetails: [
      'Hebilla ornamental con gema tallada',
      'Anillas D y mosquetones de sujeción',
      'Bolsillo de cuero para viales alquímicos',
      'Nudo ornamental con borla roja',
      'Colgante de jade con cordón trenzado',
      'Cartuchera para dagas arrojadizas'
    ]
  },
  P5: {
    slot: 'P5',
    slotName: 'Piernas & Faldón (Grebas, Quijotes, Pantalón Blindado, Faldón de Placas, Hakama)',
    lengths: [
      'Faldón de Malla y Cuero a la Rodilla',
      'Quijotes Articulados (Muslo y Rodilla)',
      'Pantalón Táctico Blindado Entallado',
      'Hakama Plisado Tradicional al Suelo',
      'Falda de Placas Segmentadas',
      'Calzas Reforzadas con Malla'
    ],
    materials: [
      'Acero',
      'Cuero',
      'Kevlar',
      'Seda',
      'Malla de acero',
      'Lana',
      'Denim'
    ],
    finishes: [
      'Bruñido',
      'Pavonado',
      'Mate',
      'Encerado'
    ],
    detailLocations: [
      'Rodillera / Guarda de Rodilla',
      'Muslo Frontal y Lateral',
      'Láminas Inferiores del Faldón',
      'Costuras Exteriores de Pierna',
      'Bolsillos Cargo Tácticos'
    ],
    suggestedDetails: [
      'Arnés de doble correa de cuero con hebillas metálicas en muslos',
      'Ribete de piel de lobo / bestia en el borde de la pretina',
      'Costuras reforzadas de combate en entrepierna y rodillas',
      'Guarda de rodilla con forma de relieve',
      'Refuerzos acolchados en rombos',
      'Bolsillos utilitarios con cremalleras',
      'Aberturas laterales forradas en terciopelo',
      'Pliegues planchados con ribetes de contraste'
    ]
  },
  P6: {
    slot: 'P6',
    slotName: 'Pies & Calzado (Botas de Combate, Sabatons, Sandalias Acorazadas, Geta, Borceguíes)',
    lengths: [
      'Botas Altas de Montar a la Rodilla',
      'Sabatons Articulados de Acero',
      'Botines Cortos Tácticos Tobilleros',
      'Sandalias de Cuero con Greba Integrada',
      'Geta de Madera Lacada con Cintas',
      'Botas Musleras al Muslo Medio'
    ],
    materials: [
      'Cuero',
      'Acero',
      'Goma',
      'Madera',
      'Gamuza',
      'Charol'
    ],
    finishes: [
      'Charol brillante',
      'Mate',
      'Envejecido',
      'Lacado'
    ],
    detailLocations: [
      'Puntera y Empeine',
      'Caña Frontal y Espinilla',
      'Talón y Contrafuerte Reforzado',
      'Cremallera / Carrera de Cordones Lateral',
      'Hebillas de Ajuste en Tobillo y Pantorrilla',
      'Suela y Borde Dentado'
    ],
    suggestedDetails: [
      'Puntera de acero con grabado decorativo',
      'Espuelas doradas desmontables en los talones',
      'Cordones resistentes con pasadores metálicos',
      'Placa espinillera con emblema en relieve',
      'Suela con dibujo de tracción profunda'
    ]
  },
  P7: {
    slot: 'P7',
    slotName: 'Capa, Manto, Alas Mecánicas & Accesorios Sagrados (Manto Real, Halo Flotante, Aura)',
    lengths: [
      'Capa Corta de Hombro Asimétrica',
      'Capa Clásica de Viaje a la Pantorrilla',
      'Manto Real con Cola al Suelo',
      'Chal / Cinta Flotante Pibo / Hagoromo',
      'Alas Mecánicas / Propulsores Desplegables',
      'Estandarte de Batalla a la Espalda'
    ],
    materials: [
      'Terciopelo',
      'Lana',
      'Gasa',
      'Seda',
      'Fibra de carbono',
      'Piel sintética',
      'Malla'
    ],
    finishes: [
      'Satinado',
      'Tornasolado',
      'Desgastado',
      'Mate'
    ],
    detailLocations: [
      'Broche de Cierre en Hombros / Pecho',
      'Borde Inferior y Dobladillo',
      'Espalda Central / Escudo Bordado',
      'Cuello y Forro Interior',
      'Articulaciones de Alas / Vértices de Estandarte'
    ],
    suggestedDetails: [
      'Broche fíbula de oro con forma heráldica',
      'Bordado heráldico en hilo de oro en la espalda',
      'Capucha amplia integrada con ribete',
      'Borde inferior festoneado con borlas',
      'Inscripción de runas luminosas en el borde'
    ]
  }
};

/**
 * Returns customized weapon configuration based on the weapon name/type.
 */
export function getWeaponContextualConfig(weaponName: string): WeaponDetailConfig {
  const wLower = weaponName.toLowerCase();

  // 1. ESPADAS / MANDOBLES / KATANAS / ROPERAS
  if (wLower.includes('espada') || wLower.includes('mandoble') || wLower.includes('colosal') || wLower.includes('katana') || wLower.includes('florete') || wLower.includes('ropera') || wLower.includes('sable') || wLower.includes('espadón') || wLower.includes('claymore') || wLower.includes('cimitarra') || wLower.includes('tachi')) {
    return {
      bladeOrHeadTypes: [
        'Filo Ancho con Muescas de Batalla (Mandoble Descomunal)',
        'Hoja Recta de Doble Filo Clásica',
        'Hoja Ancha de Mandoble con Acanaladura Central',
        'Hoja Curva Katana con Línea Hamon Ondulada',
        'Hoja Estrecha de Estoque / Ropera Triangular',
        'Hoja Curva de Cimitarra con Punta Ensanchada',
        'Hoja Flamígera / Ondulada Flamberge'
      ],
      guardStyles: [
        'Guarda Cruzada de Acero Macizo Esculpido',
        'Guarda Cruzada Recta de Acero con Gavilanes Dorados',
        'Tsuba Circular Tradicional con Grabado Calado',
        'Cazoleta / Cesta Protectora de Duelo',
        'Guarda con Alas de Dragón Desplegadas',
        'Guarda Minimalista Táctica Integrada'
      ],
      gripStyles: [
        'Empuñadura Larga Envuelta en Cuero Reforzado (Dos Manos)',
        'Empuñadura de Madera Forrada en Cuero Negro Trenzado con Alambre',
        'Piel de Raya Samegawa con Cordón de Seda Tsukamaki',
        'Empuñadura de Hueso de Dragón Tallado',
        'Empuñadura Anatómica de Polímero Ergonómico',
        'Empuñadura a Dos Manos Extra-Larga (40cm)'
      ],
      pommelOrBaseStyles: [
        'Pomo Octogonal Macizo de Acero Contrapeso',
        'Pomo Esférico con Gema Zafiro / Rubí Engarzada',
        'Kashira Metálica de Dragón / Fénix',
        'Pomo en Forma de Calavera / Emblema',
        'Sin Pomo / Remate Afilado Rompecascos'
      ],
      enchantmentsOrAuras: [
        'Filo Afilado Natural sin Encantamiento Visible',
        'Llamas Carmesí Ígneas que Arden a lo Largo del Filo',
        'Escarcha Glacial Cristalina que Emite Vapor Frío',
        'Rayos Voltaicos Azules que Chisporrotean en la Hoja',
        'Aura Umbría de Oscuridad y Humo Negro Vacío',
        'Resplandor Dorado Solar Sagrado con Luz Divina',
        'Runas Rúnicas Grabadas que Palpitan en Cian Neón'
      ],
      scabbardOrCarryingPlacements: [
        'Portado al Hombro o Espalda con Tahalí Grueso de Cuero',
        'Vaina de Cuero Rígido a la Cadera Izquierda',
        'Vaina Lacada en Negro Brillante con Cordón Sageo',
        'Tahalí Cruzado a la Espalda con Desenvaine Rápido',
        'Vaina de Madera Forrada en Terciopelo con Contera de Oro',
        'Sujeción Magnética en Arnés Táctico'
      ],
      materials: [
        'Acero forjado macizo',
        'Acero Damasco',
        'Mithril',
        'Acero',
        'Hierro',
        'Titanio',
        'Obsidiana'
      ],
      finishes: [
        'Muescas y Desgaste de Batalla Heroico',
        'Pulido Espejo con Reflejo Impecable',
        'Acabado Pavonado Negro Antirreflejante',
        'Patrón de Damasco Ondulado Muy Visible',
        'Filo Afilado como Navaja con Brillo Plateado'
      ]
    };
  }

  // 2. DAGAS / PUÑALES / KUNAI / KARAMBIT
  if (wLower.includes('daga') || wLower.includes('puñal') || wLower.includes('cuchillo') || wLower.includes('kunai') || wLower.includes('karambit') || wLower.includes('estilete') || wLower.includes('tanto')) {
    return {
      bladeOrHeadTypes: [
        'Hoja Doble Filo Daga de Parada',
        'Hoja Curva Karambit en Garra con Anillo de Retención',
        'Estilete Triangular Perforador de Armaduras',
        'Tanto Japonés con Punta Geométrica Yokote',
        'Hoja Ondulada Kris con Canal de Veneno'
      ],
      guardStyles: [
        'Guarda Corta Curvada hacia Delante',
        'Guarda Redonda Habaki Estrecha',
        'Sin Guarda / Diseño Monolítico Enterizo'
      ],
      gripStyles: [
        'Cuero Encordado Antideslizante',
        'Cachas de Micarta / Fibra de Carbono con Remaches',
        'Madera de Ébano Pulida',
        'Anillo de Retención Táctico en el Meñique'
      ],
      pommelOrBaseStyles: [
        'Punta Rompe-Cristales / Rompe-Cráneos',
        'Pomo Plano Discreto para Ocultación',
        'Anillo Táctico para Giro Rápido'
      ],
      enchantmentsOrAuras: [
        'Recubrimiento de Veneno Esmeralda Goteante',
        'Velo de Sombras Silenciador de Movimiento',
        'Filo Sangriento Carmesí con Brillo Rúnico',
        'Resplandor Gélido Letal'
      ],
      scabbardOrCarryingPlacements: [
        'Funda Oculta en la Bota Derecha',
        'Funda Horizontal en la Parte Baja de la Espalda (Scout Carry)',
        'Funda de Pecho en Tahalí / Arnés',
        'Funda de Antebrazo Oculta bajo la Manga',
        'Funda de Cintura con Clip Rápido'
      ],
      materials: [
        'Acero',
        'Titanio',
        'Obsidiana',
        'Metal'
      ],
      finishes: [
        'Negro Cerakote Mate Táctico',
        'Pátina Ácida Lavada a la Piedra (Stonewash)',
        'Pulido a Mano con Filo Microscópico'
      ]
    };
  }

  // 3. ARCOS / BALLESTAS / ARMAS A DISTANCIA
  if (wLower.includes('arco') || wLower.includes('ballesta') || wLower.includes('cerbatana') || wLower.includes('tirachinas')) {
    return {
      bladeOrHeadTypes: [
        'Palas Recurvas Dobles de Gran Tensión',
        'Arco Largo Clásico de Madera Maciza (1.9 Metros)',
        'Arco Compuesto con Poleas Mecánicas de Precisión',
        'Ballesta de Repetición con Cargador Superior',
        'Arco de Energía de Haces de Plasma'
      ],
      guardStyles: [
        'Empuñadura Central Ergonómica con Reposaflechas de Cerda',
        'Cureña de Ballesta de Madera de Nogal Tallada',
        'Mira Holográfica / Visor Óptico Iluminado'
      ],
      gripStyles: [
        'Cuero Suave Acolchado con Absorción de Vibración',
        'Madera con Grabados Antideslizantes',
        'Empuñadura de Polímero Texturizado'
      ],
      pommelOrBaseStyles: [
        'Puntas de Pala Reforzadas con Cuerno de Ciervo / Metal',
        'Culata Ajustable de Ballesta con Almohadilla'
      ],
      enchantmentsOrAuras: [
        'Cuerda Imbuida de Viento que Acelera los Proyectiles a Velocidad Sónica',
        'Flechas de Fuego que se Generan Mágicamente al Tensar',
        'Encanto de Puntería Guiada por Estrellas',
        'Flechas de Hielo Paralizante'
      ],
      scabbardOrCarryingPlacements: [
        'Carcaj de Espalda con 24 Flechas de Plumas de Águila',
        'Carcaj de Cadera Rápido con Flechas Especiales',
        'Arco Colgado al Hombro con Funda Impermeable',
        'Sujeción en la Mochila Táctica'
      ],
      materials: [
        'Madera',
        'Fibra de carbono',
        'Titanio'
      ],
      finishes: [
        'Barniz Natural Satén con Vetas Nobles',
        'Camuflaje Forestal Mate / Negro Nocturno',
        'Laca Negra Tradicional Japonesa Yumi'
      ]
    };
  }

  // 4. BÁCULOS / VARITAS / GRIMORIOS / ORBES
  if (wLower.includes('báculo') || wLower.includes('vara') || wLower.includes('varita') || wLower.includes('grimorio') || wLower.includes('orbe') || wLower.includes('cetro') || wLower.includes('tomo') || wLower.includes('libro')) {
    return {
      bladeOrHeadTypes: [
        'Orbe de Cristal de Cuarzo Mágico Flotante en la Cima',
        'Calavera de Dragón Miniatura con Ojos de Rubí',
        'Círculo Solar con Cintas Flotantes y Campanillas',
        'Cúmulo de Cristales Arcanos en Bruto sin Tallar',
        'Grimorio Encuadernado en Cuero de Quimera con Cadenas de Plata',
        'Esfera de Fuego Fatuo Sellada en Jaula de Filigrana'
      ],
      guardStyles: [
        'Anillos Rúnicos que Giran en Levitación Alrededor del Foco',
        'Garras Metálicas de Águila que Sujetan el Cristal',
        'Candado Mágico con Ojo Central Animado (Grimorio)'
      ],
      gripStyles: [
        'Madera Retorcida de Roble Ancestral con Vetas de Oro',
        'Asta de Metal Forjado con Envoltura de Seda Rúnica',
        'Empuñadura de Varita de Marfil Tallado con Espirales'
      ],
      pommelOrBaseStyles: [
        'Contera Metálica Afilada para Clavar en Tierra',
        'Cristal de Resonancia Menor en la Base',
        'Borla de Hilos de Seda con Talismanes de Papel (Ofuda)'
      ],
      enchantmentsOrAuras: [
        'Aura Pulsante de Energía Cósmica / Polvo de Estrellas',
        'Rayos Arcanos Violetas que Saltan entre los Cristales',
        'Humo de Sombras Eternas que Brota de la Punta',
        'Partículas Sagradas Doradas que Curan a los Aliados',
        'Llamas Azules que No Queman pero Iluminan la Verdad'
      ],
      scabbardOrCarryingPlacements: [
        'Portado Directamente en la Mano Derecha',
        'Funda de Cuero a la Espalda con Anclaje Rápido',
        'Grimorio Flotante que Sigue al Portador por Magia',
        'Tahalí Lateral para Grimorio con Cierre de Hebilla'
      ],
      materials: [
        'Madera',
        'Cristal',
        'Plata',
        'Cuero'
      ],
      finishes: [
        'Madera Encerada al Aceite con Brillo Cálido',
        'Cristal Facetado con Destellos Prisma',
        'Metal Envejecido Sagrado'
      ]
    };
  }

  // 5. ESCUDOS / PAVÉS / RODELAS
  if (wLower.includes('escudo') || wLower.includes('rodela') || wLower.includes('pavés') || wLower.includes('targe')) {
    return {
      bladeOrHeadTypes: [
        'Escudo Cometa / Lágrima Medieval Completo',
        'Rodela Redonda de Duelo con Umbo Puntiagudo',
        'Pavés Torre de Asedio Cuadrangular Masivo',
        'Escudo Triangular de Cruzado con Blasón',
        'Barrera de Energía Holográfica Desplegable'
      ],
      guardStyles: [
        'Umbo Central de Acero de 15cm',
        'Borde de Escudo Reforzado con Pletina de Bronce',
        'Púa Central Ofensiva de Derribo'
      ],
      gripStyles: [
        'Brazo Sujeto con Correas Enapuladas y Asa de Cuero Acolchada',
        'Empuñadura Central de Barra con Guantelete',
        'Arnés de Espalda para Transporte en Marcha'
      ],
      pommelOrBaseStyles: [
        'Canto Inferior Reforzado para Apoyar en Suelo',
        'Punta Inferior Metálica Rompe-Pies'
      ],
      enchantmentsOrAuras: [
        'Campo de Fuerza Repulsor que Desvía Proyectiles',
        'Resplandor Sagrado que Ciegan a Atacantes al Bloquear',
        'Absorción Elemental que Canaliza el Fuego en Contraataque'
      ],
      scabbardOrCarryingPlacements: [
        'Portado en el Brazo Izquierdo',
        'Fijado a la Espalda con Correa Cruzada de Liberación Rápida'
      ],
      materials: [
        'Madera',
        'Cuero',
        'Acero',
        'Mithril'
      ],
      finishes: [
        'Pintura Heráldica con Blasón Pintado a Mano',
        'Metal Bruñido con Relieves de Oro',
        'Desgaste Severo de Flechas y Golpes de Hacha'
      ]
    };
  }

  // 6. LANZAS / ALABARDAS / GUADAÑAS / HACHAS / MAZAS
  if (wLower.includes('lanza') || wLower.includes('alabarda') || wLower.includes('guadaña') || wLower.includes('hacha') || wLower.includes('maza') || wLower.includes('martillo') || wLower.includes('tridente') || wLower.includes('pica') || wLower.includes('naginata') || wLower.includes('glaive')) {
    return {
      bladeOrHeadTypes: [
        'Punta de Lanza de Hoja de Sauce Forjada',
        'Cabeza de Alabarda con Hacha, Púa y Gancho de Caballería',
        'Cuchilla Curva de Guadaña Segadora Afilada al Interior',
        'Cabeza de Hacha de Guerra de Doble Filo Gigante',
        'Maza de Cabeza Estrellada con Bridas de Acero',
        'Martillo de Guerra con Cabeza Cuadrada y Púa de Pico de Cuervo'
      ],
      guardStyles: [
        'Guardamanos de Disco Metálico en el Asta',
        'Cintas y Borlas de Crin de Caballo / Seda Roja Antisalpicaduras',
        'Refuerzo de Flejes de Acero (Langets) en los Primeros 50cm'
      ],
      gripStyles: [
        'Asta de Madera de Fresno Gruesa Encerada',
        'Secciones con Envoltura de Cuero para Agarre Seguro',
        'Asta Enteriza de Metal Hueco Reforzado'
      ],
      pommelOrBaseStyles: [
        'Regatón / Contera Metálica Inferior Puntiaguda para Clavar en Suelo',
        'Contrapeso Esférico de Plomo / Bronce en la Base'
      ],
      enchantmentsOrAuras: [
        'Ondas de Choque Sísmicas en Cada Impacto Contra el Suelo',
        'Filo Aéreo Cortante que Extiende el Alcance del Golpe 1 Metro',
        'Llamas de Ira que Cubren la Cabeza del Arma',
        'Rayo que Cae sobre el Arma al Alzarla al Cielo'
      ],
      scabbardOrCarryingPlacements: [
        'Portado en Dos Manos / Apoyado en el Hombro',
        'Funda de Cuero para la Cuchilla / Cabeza',
        'Sujeción en la Silla de Montar del Caballo / Montura'
      ],
      materials: [
        'Madera',
        'Acero',
        'Bronce',
        'Hueso'
      ],
      finishes: [
        'Asta Ennegrecida al Fuego y Aceitada',
        'Metal Forjado en Bruto con Marcas de Yunque',
        'Cuchilla Afilada con Espejo Pulido'
      ]
    };
  }

  // 7. ARMAS DE FUEGO / PISTOLAS / RIFLES / CAÑONES
  if (wLower.includes('pistola') || wLower.includes('rifle') || wLower.includes('mosquete') || wLower.includes('cañón') || wLower.includes('escopeta') || wLower.includes('revólver') || wLower.includes('blaster')) {
    return {
      bladeOrHeadTypes: [
        'Cañón Estriado de Acero de Damasco de Precisión',
        'Doble Cañón Superpuesto con Boca Ensanchada',
        'Cañón de Plasma Térmico con Disipadores de Calor',
        'Boca con Supresor / Silenciador Integrado',
        'Cañón Largo de Francotirador con Freno de Boca'
      ],
      guardStyles: [
        'Guardamonte de Latón Grabado con Gatillo Suave',
        'Protector Térmico de Manos Ranurado',
        'Riel Táctico con Linterna y Láser'
      ],
      gripStyles: [
        'Cacha de Madera de Nogal Pulida con Incrustaciones de Plata',
        'Empuñadura de Polímero Ergonómico con Textura Antideslizante',
        'Culata Esquelética Plegable de Aluminio'
      ],
      pommelOrBaseStyles: [
        'Culata con Almohadilla de Goma Antirretroceso',
        'Remate Metálico con Anilla para Cordón de Retención'
      ],
      enchantmentsOrAuras: [
        'Munición Rúnica que Explota en Fragmentos Mágicos',
        'Disparos Silenciosos con Trazadores de Plasma Azul',
        'Proyectiles Perforantes de Éter'
      ],
      scabbardOrCarryingPlacements: [
        'Holster / Pistolera de Cuero Rápida a la Cadera',
        'Pistolera Sobrecintura en Pecho / Arnés Táctico',
        'Correa Portafusa de 2 Puntos Cruzada al Pecho'
      ],
      materials: [
        'Acero',
        'Madera',
        'Aluminio',
        'Polímero'
      ],
      finishes: [
        'Pavonado Negro Profundo Brillante',
        'Grabado Floral Clásico en la Báscula de Latón',
        'Acabado Táctico Cerakote FDE / Camo'
      ]
    };
  }

  // DEFAULT / UTENSILIOS GENÉRICOS
  return {
    bladeOrHeadTypes: ['Forma Estándar Funcional', 'Diseño Reforzado', 'Versión Ceremonial Grabada'],
    guardStyles: ['Protección Básica', 'Sin Guarda', 'Detalles Ornamentales'],
    gripStyles: ['Cuero Encordado', 'Madera Pulida', 'Metal Texturizado'],
    pommelOrBaseStyles: ['Remate Metálico', 'Contrapeso Simple', 'Anilla de Colgar'],
    enchantmentsOrAuras: ['Sin Encantamiento', 'Resplandor Mágico Suave', 'Aura Elemental'],
    scabbardOrCarryingPlacements: ['Funda de Cuero a la Cintura', 'Guardado en Mochila', 'Colgado al Cinto'],
    materials: ['Acero', 'Cuero', 'Madera', 'Bronce'],
    finishes: ['Satinado Natural', 'Bruñido', 'Envejecido de Uso']
  };
}

export const ARMOR_SLOT_GROUPS = Object.values(ARMOR_SLOT_CONFIGS);

export function getArmorSlotOptionConfig(slotId: 'P1' | 'P2' | 'P3' | 'P4' | 'P5' | 'P6' | 'P7'): ArmorPieceOptionGroup {
  return ARMOR_SLOT_CONFIGS[slotId] || ARMOR_SLOT_CONFIGS.P2;
}

export const WEAPON_CUSTOMIZATION_GROUPS = [
  'Filo Biselado Espejo',
  'Runas Grabadas en la Hoja',
  'Guarda en Cruz Ornamentada',
  'Pomo con Piedra de Poder',
  'Empuñadura de Cuero Encordado',
  'Aura Elemental Ardiente',
  'Vaina de Madera Lacada',
  'Funda con Broches de Cuero'
];

export const CONTAINER_CUSTOMIZATION_GROUPS = [
  'Hebillas de Bronce Antiguo',
  'Costuras Reforzadas de Hilo Encerado',
  'Bolsillo Oculto Interior',
  'Correa Cruzada Ajustable',
  'Cierre de Cordón con Borla',
  'Remaches de Acero Templado',
  'Emblema de Gremio Grabado'
];

