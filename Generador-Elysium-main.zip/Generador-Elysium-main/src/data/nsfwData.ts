export interface NsfwOptionItem {
  id: string;
  name: string;
  description: string;
  colorHex?: string;
}

export const AREOLA_COLORS: NsfwOptionItem[] = [
  { id: 'AC1', name: 'Rosa Pálido / Pétalo de Cerezo', description: 'Tono rosado translúcido muy suave y delicado.', colorHex: '#E8A3B8' },
  { id: 'AC2', name: 'Rosa Coral Cálido', description: 'Tono coral rosáceo con matices melocotón.', colorHex: '#D97373' },
  { id: 'AC3', name: 'Marrón Claro / Miel Canela', description: 'Tono café con leche claro y dorado natural.', colorHex: '#A06E50' },
  { id: 'AC4', name: 'Marrón Oscuro / Chocolate Profundo', description: 'Pigmentación oscura profunda y aterciopelada.', colorHex: '#523425' },
  { id: 'AC5', name: 'Lavanda / Malva Fantasía', description: 'Tinte sutilmente violáceo para razas feéricas o demoníacas.', colorHex: '#B28CB8' },
  { id: 'AC6', name: 'Borgoña / Carmesí Intenso', description: 'Matiz rubí apasionado de alta vascularización.', colorHex: '#80283A' }
];

export const AREOLA_SIZES: NsfwOptionItem[] = [
  { id: 'AS1', name: 'Pequeñas y Discretas (Petite)', description: 'Diámetro reducido, apenas delimitando la base del pezón.' },
  { id: 'AS2', name: 'Medianas Clásicas (Equilibradas)', description: 'Proporción armoniosa y natural respecto al busto.' },
  { id: 'AS3', name: 'Amplias y Marcadas (Generosas)', description: 'Diámetro amplio con bordes difuminados y sensuales.' },
  { id: 'AS4', name: 'Esculpidas en Flor / Onduladas', description: 'Bordes levemente festoneados o irregulares de fantasía.' }
];

export const NIPPLE_TYPES: NsfwOptionItem[] = [
  { id: 'NT1', name: 'Cónicos Erectos y Turgentes', description: 'Prominentes y reactivos al menor roce o frío.' },
  { id: 'NT2', name: 'Redondeados Suaves (Alineados)', description: 'Descansan al ras de la areola hasta ser estimulados.' },
  { id: 'NT3', name: 'Invertidos / Tímidos', description: 'Retraídos naturalmente, emergen únicamente con caricias y calor.' },
  { id: 'NT4', name: 'Perforados con Joyería / Aros', description: 'Adornados con pequeños aros de plata, oro o cadenas colgantes.' }
];

export const PUBIC_HAIR_STYLES: NsfwOptionItem[] = [
  { id: 'PH1', name: 'Depilación Total / Piel de Seda Lisa', description: 'Completamente suave y pulcra sin vello corporal.' },
  { id: 'PH2', name: 'Línea Vertical Fina (Tira de Aterrizaje)', description: 'Elegante franja recortada y estilizada.' },
  { id: 'PH3', name: 'Triángulo Clásico Pequeño y Pulcro', description: 'Bordes recortados minuciosamente en forma triangular.' },
  { id: 'PH4', name: 'Natural Suave y Ralo', description: 'Vello fino y tenue sin recortar de aspecto inocente.' },
  { id: 'PH5', name: 'Forma de Corazón Estilizado', description: 'Diseño decorativo coqueto sobre el monte de Venus.' }
];

export const BODY_SENSITIVITIES: NsfwOptionItem[] = [
  { id: 'BS1', name: 'Nuca y Lóbulo de las Orejas', description: 'Estremecimiento inmediato ante susurros, respiración cálida o roces de labios.' },
  { id: 'BS2', name: 'Clavículas y Garganta', description: 'Piel hipersensible al contacto de dedos, collares fríos o besos suaves.' },
  { id: 'BS3', name: 'Puntas del Pecho y Senos', description: 'Reacción eréctil veloz y jadeos con caricias circulares o presión ligera.' },
  { id: 'BS4', name: 'Curvatura Lumbar y Espalda Baja', description: 'Arqueo instintivo de la cadera ante caricias firmes descendentes.' },
  { id: 'BS5', name: 'Cara Interna de los Muslos', description: 'Zona de guardia íntima; estremecimientos y cierre o apertura involuntaria de piernas.' },
  { id: 'BS6', name: 'Caderas y Huesos Ilíacos', description: 'Hipersensibilidad al agarre firme con ambas manos.' }
];

export interface GenitalOptionItem extends NsfwOptionItem {
  category: 'Femenino' | 'Masculino' | 'Fantasía / Andrógino';
}

export const GENITAL_TYPES: GenitalOptionItem[] = [
  // Femeninos
  {
    id: 'GT_FEM_1',
    name: 'Vulva Carnosa Delicada (Labios Recogidos)',
    category: 'Femenino',
    description: 'Morfología recogida y discreta con monte de Venus suave y hendidura tersa y cerrada.'
  },
  {
    id: 'GT_FEM_2',
    name: 'Vulva Prominente con Labios Suaves (Pétalos Definidos)',
    category: 'Femenino',
    description: 'Labios menores visibles de textura aterciopelada y contornos carnosos bien definidos.'
  },
  {
    id: 'GT_FEM_3',
    name: 'Hendidura Estilizada Tersa (Línea Fina y Tersa)',
    category: 'Femenino',
    description: 'Anatomía compacta y firme de gran pulcritud con suave turgencia en el pubis.'
  },
  {
    id: 'GT_FEM_4',
    name: 'Vulva Turgente Hipersensible (Alta Reactividad)',
    category: 'Femenino',
    description: 'Capuchón y clítoris prominentes de vascularización sensible y rápida humectación eréctil.'
  },

  // Masculinos
  {
    id: 'GT_MASC_1',
    name: 'Falo Proporcionado Estilizado (Armonía Clásica)',
    category: 'Masculino',
    description: 'Morfología equilibrada y pulcra con glande cónico definido y silueta anatómica natural.'
  },
  {
    id: 'GT_MASC_2',
    name: 'Falo Robusto y Vascularizado (Firmeza Atlética)',
    category: 'Masculino',
    description: 'Silueta densa con relieve vascular bien marcado y glande ancho de borde pronunciado.'
  },
  {
    id: 'GT_MASC_3',
    name: 'Falo Grueso y Prominente (Volumen Imponente)',
    category: 'Masculino',
    description: 'Cuerpo cavernoso denso de base sólida, gran calibre y glande acampanado.'
  },
  {
    id: 'GT_MASC_4',
    name: 'Falo Alargado y Esbelto (Sensibilidad Fina)',
    category: 'Masculino',
    description: 'Líneas longitudinales esbeltas y elegantes con prepucio retráctil suave y sensible.'
  },

  // Fantasía / Andrógino / Híbrido
  {
    id: 'GT_HYB_1',
    name: 'Genitales Duales Andróginos (Hermafrodita Armónico)',
    category: 'Fantasía / Andrógino',
    description: 'Conjunción armónica de hendidura suave con falo estilizado o clítoris hiperdesarrollado.'
  },
  {
    id: 'GT_HYB_2',
    name: 'Falo con Bulbo Nodal Bestial / Dracónico',
    category: 'Fantasía / Andrógino',
    description: 'Engrosamiento basal en bulbo/nudo con suaves crestas carnales anatómicas de raza bestial.'
  },
  {
    id: 'GT_HYB_3',
    name: 'Genitales Rúnicos Bioluminiscentes (Feérico / Elemental)',
    category: 'Fantasía / Andrógino',
    description: 'Tegumento íntimo con tenues vetas rúnicas fluorescentes o pulso de maná carnal.'
  },
  {
    id: 'GT_HYB_4',
    name: 'Morfología Exótica Tentacular / Demoníaca',
    category: 'Fantasía / Andrógino',
    description: 'Textura suavemente acostillada con micro-ventosas o relieves espinosos eréctiles inofensivos.'
  }
];

export const GENITAL_SIZES: NsfwOptionItem[] = [
  { id: 'GS1', name: 'Discreto / Proporción Fina', description: 'Dimensiones recogidas, compactas y sutiles en reposo.' },
  { id: 'GS2', name: 'Mediano Clásico (Armónico)', description: 'Proporción equilibrada y natural en sintonía con la complexión corporal.' },
  { id: 'GS3', name: 'Bien Desarrollado / Sensual', description: 'Volumen generoso, prominente y de presencia visual destacada.' },
  { id: 'GS4', name: 'Grande / Imponente', description: 'Dimensiones excepcionales y calibre llamativo de impacto directo.' }
];

export const GENITAL_DETAILS: NsfwOptionItem[] = [
  { id: 'GD1', name: 'Natural Puro (Rosado / Tono Carnal Suave)', description: 'Coloración natural homogénea de gran lozanía y suavidad.' },
  { id: 'GD2', name: 'Pigmentación Bicolor / Degradado Sensual', description: 'Matices más oscuros o sonrosados en bordes y zonas erógenas.' },
  { id: 'GD3', name: 'Clítoris / Glande Hipersensible Reactivo', description: 'Reacción inmediata al roce con turgencia eréctil acelerada.' },
  { id: 'GD4', name: 'Piercing Íntimo / Joyería de Oro o Plata', description: 'Perforación ornamental elegante (aro pélvico, frenum o campana).' },
  { id: 'GD5', name: 'Marca / Tatuaje Rúnico en Bajo Vientre', description: 'Sello erógeno dibujado sobre el pubis o monte de Venus.' },
  { id: 'GD6', name: 'Tersura Humectada / Secreción Natural Abundante', description: 'Sensación de calidez y lubricación natural constante.' },
  { id: 'GD7', name: 'Castrado (Sin escroto, sin testículos)', description: 'Ausencia total de testículos y escroto; zona perineal lisa o suturada con pulcritud anatómica.' },
  { id: 'GD8', name: 'Impotencia (Falo flácido / Incapaz de erección)', description: 'Incapacidad de rigidez eréctil; se mantiene enteramente flácido, suave y dúctil ante cualquier estímulo.' },
  { id: 'GD9', name: 'Ano-Vaginal (Ano con función vaginal/reproductiva: el recto funciona como canal vaginal que conecta con un útero y ovarios funcionales)', description: 'El conducto anal asume función vaginal completa con capacidad de dilatación receptiva, lubricación interna y conexión directa a matriz reproductiva fértil.' }
];

export const INTIMATE_PERSONALITIES: NsfwOptionItem[] = [
  { id: 'IP1', name: 'Sumisa Devota & Complaciente', description: 'Desea agradar incondicionalmente, obedece órdenes con sonrojo devoto y entrega absoluta.' },
  { id: 'IP2', name: 'Tsundere Apasionada & Defensiva', description: 'Finge desagrado o indignación inicial para ocultar su intenso deseo y vulnerabilidad.' },
  { id: 'IP3', name: 'Dominante Seductora & Controladora', description: 'Disfruta provocar, marcar el ritmo de la interacción y ver al usuario perder la compostura.' },
  { id: 'IP4', name: 'Tímida Curiosa & Inocente', description: 'Experimenta sensaciones nuevas con asombro, pudor extremo, caricias cautelosas y sonrojos profundos.' },
  { id: 'IP5', name: 'Cortesana Noble & Exigente', description: 'Requiere devoción, adulación y caricias refinadas antes de bajar la guardia y entregarse.' },
  { id: 'IP6', name: 'Juguetona Provocadora & Traviesa', description: 'Bromea, desafía al usuario, finge escapar y disfruta el coqueteo pícaro y físico.' }
];

export const EXPLICIT_LINGERIE_OPTIONS: NsfwOptionItem[] = [
  { id: 'EL1', name: 'Sarashi Translúcido de Gasa Desértica', description: 'Bandas cruzadas de tela casi transparente que transparentan la silueta de los pezones.' },
  { id: 'EL2', name: 'Pezoneras Metálicas de Filigrana con Cadenillas', description: 'Copas mínimas de oro o plata grabada con dijes oscilantes sobre el busto desnudo.' },
  { id: 'EL3', name: 'Conjunto Strappy con Correas Pélvicas Cruzadas', description: 'Arnés de tiras elásticas de satén que enmarcan caderas, cintura y escote descubierto.' },
  { id: 'EL4', name: 'Babydoll de Encaje de Malla Abierta', description: 'Camisón vaporoso corto con aberturas estratégicas y transparencias totales.' },
  { id: 'EL5', name: 'Arnés de Cuero Fino con Argollas Doradas (Harness)', description: 'Tiras de cuero bruñido con herrajes que abrazan el torso y los muslos.' },
  { id: 'EL6', name: 'Desnudez Totalmente Descubierta', description: 'Sin ninguna prenda ni lencería; anatomía completa expuesta al natural.' }
];
