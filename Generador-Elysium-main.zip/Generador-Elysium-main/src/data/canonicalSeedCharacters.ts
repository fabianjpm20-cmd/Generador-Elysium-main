import { SavedCharacterEntry } from '../types';

export const NATIVE_SEED_CHARACTERS: SavedCharacterEntry[] = [
  // -------------------------------------------------------------
  // 1. GO PIP - Pícaro Ingeniero & Explorador de las Dunas
  // -------------------------------------------------------------
  {
    id: 'char-seed-go-pip',
    savedAt: new Date(Date.now() - 86400000 * 3).toISOString(),
    updatedAt: new Date(Date.now() - 86400000 * 1).toISOString(),
    variantGroupId: 'group-go-pip',
    variantLabel: 'Base',
    state: {
      id: 'char-seed-go-pip',
      variantGroupId: 'group-go-pip',
      variantLabel: 'Base',
      name: 'Go pip',
      personality: 'Vivaz, Ingenioso, Curioso y Astuto',
      personalityTraits: ['Curioso', 'Leal', 'Ingenioso', 'Impredecible'],
      archetype: 'Pícaro Inventor & Explorador Ágil',
      raceGroup: 'GRUPO 2: HUMANODES BRUTOS',
      raceId: '2.3',
      raceName: 'Goblins (Homo goblinus)',
      subtype: 'Artificiero & Bribón de las Dunas',
      anatomy: {
        sexBase: '1 Hombre',
        age: '3 Juventud (18-25 años)',
        complexion: '1 Delgado / Esbelto',
        height: 'A Muy Bajo / Petite (< 1.45 m)',
        breastDevelopment: 'A Senos Planos / Pechos Incipientes / Copa AA',
        waist: '1 Muy Estrecha / Diminuta',
        glutes: '2 Ligeros',
        thighs: '2 Ágiles / Delgados',
        skinColor: 'Piel Cobriza Verdosa con Matices Ámbar',
        lowerBodyStructure: 'Bípedo Humanoide Estándar'
      },
      facial: {
        headShape: 'Triangular Fina',
        headWidth: 'Fina / Esbelta',
        boneStructure: 'Angulosa y Pícara',
        eyeColor: 'Ámbar Dorado Luminiscente',
        eyesCategory: 'C Grandes / Curiosos',
        eyesSubtype: 'C2 Ojo Vivaz',
        eyeliner: 'DEL1 Delgado',
        shadow: 'SOM0 Sin sombra',
        expression: 'EXP2 Sonrisa Traviesa',
        iris: '6 Cristalino',
        nose: '7 Corta / Puntiaguda',
        lips: 'A2 Finos',
        mouthExp: 'E2 Pícara / Sonriente',
        mouthSpecial: 'Colmillos pequeños afilados',
        teeth: 'B2 Colmillos Caninos Destacados',
        mouthCorners: 'COM1 Elevadas',
        mouthTexture: 'TEX1 Mate',
        earsBase: 'E03 Puntiagudas marcadas (Grandes)',
        earsLength: 'EL3 10–15 cm',
        kemonoEars: 'Ninguno'
      },
      hair: {
        texture: '3 Rizado / Rebelde',
        length: '2 Corto (Alborotado)',
        cut: 'Despeinado con mechones rebeldes',
        part: '3 Libre',
        bangs: 'Mechón frontal rebelde',
        style: 'HST08 Mechones al Viento',
        hairColor: 'Castaño Cobrizo Ceniza'
      },
      appendices: {
        hornsForm: 'Ninguno',
        hornsLength: 'HL1 0-10 cm',
        hornsThickness: 'G3 Medio',
        hornsPosition: 'P1 Frontales',
        wingsSize: 'S2 Medio',
        wingsPosition: 'P1 Espalda Alta',
        wingsType: 'Ninguno',
        tailsType: 'Ninguno',
        tailsLength: 'L2 Corta',
        skinAndMarks: 'T1 Piel Lisa con pequeñas pecas solares',
        scaleLocations: [],
        markTypes: ['M2 Tatuaje Tribal / Geométrico'],
        markLocations: { 'M2 Tatuaje Tribal / Geométrico': ['ANTEBRAZO DERECHO'] },
        markShapes: { 'M2 Tatuaje Tribal / Geométrico': 'Símbolo del Engranaje de las Arenas' },
        markColors: { 'M2 Tatuaje Tribal / Geométrico': 'C2 Cian Luminoso / Turquesa' },
        antennaeType: 'Ninguna',
        extraEyes: 'Ninguno (2 Ojos Estándar)',
        extraArms: 'Ninguno (2 Brazos Estándar)',
        specialLimbs: 'Ninguna (Extremidades Orgánicas Estándar)',
        lowerBodyStructure: 'Bípedo Humanoide Estándar'
      },
      wardrobes: [
        {
          id: 'w-gopip-01',
          categoryId: 'B0',
          name: 'Chaleco de Artificiero con Multibolsillos y Bombachos de Lino',
          cut: 'Holgado Ágil',
          length: 'Cintura',
          sleeve: 'Sin Mangas',
          material: 'Cuero curtido suave y lino transpirable del desierto',
          color: 'Cuero Canela, Arena y Bronce',
          finish: 'Rústico flexible',
          details: ['Cartucheras de cerrajería en el cinto', 'Gafas de artificiero de latón en la frente'],
          variation: 'Atuendo de Infiltración y Taller',
          layer: 'Base',
          location: ['TORSO / PECHO', 'CINTURA'],
          pattern: 'Liso',
          neckline: 'Cuello en V',
          emblem: 'Engranaje Alado',
          detailLocations: {},
          patternDetail: "",
          vfx: "Ninguno",
        }
      ],
      role: 'Pícaro Ingeniero & Guía Subterráneo',
      styleVisual: 'Fantasía Alquímica & Steampunk del Desierto',
      armor: {
        type: 'Peto Ligero de Cuero Curtido con Refuerzos de Bronce',
        pieces: ['Protector pectoral ligero', 'Guanteletes de dedos libres', 'Gafas de latón'],
        material: 'Cuero endurecido y bronce antiguo',
        finish: 'Pátina envejecida'
      },
      equipment: {
        weapons: ['Ballesta de muñeca mecánica de repetición', 'Dagas gemelas de filo serrado'],
        weaponGrips: ['Cuero grabado antideslizante'],
        bags: ['Morral bandolera de artificiero con compartimentos acolchados'],
        bagSizes: ['Mediana'],
        bagClosures: ['Hebillas de clic rápido'],
        items: ['Ganzúas de precisión de aleación astral', 'Bomba de humo de arena cegadora', 'Monocular telescópico']
      },
      background: {
        relationships: [
          {
            id: 'rel-gopip-valentin',
            targetCharacterName: 'Valentín Montclair',
            relationshipType: 'Aliado y Benefactor',
            interactionDynamic: 'Valentín confía en la pericia de Go pip para cerrajería confidencial e infiltración; Go pip adora las golosinas de la corte y los acertijos mecánicos.',
            feelingsTowards: 'Aprecio sincero por ser de los pocos nobles que lo trata con respeto y generosidad.',
            opinionOn: '«El señorito Montclair habla bonito y huele a jazmín caro, pero cuando las cosas arden sabe exactamente qué cables cortar.»'
          },
          {
            id: 'rel-gopip-xander',
            targetCharacterName: 'Xander Vaelith',
            relationshipType: 'Compañero Táctico',
            interactionDynamic: 'Go pip desbarata los esquemas rígidos de Xander con improvisaciones caóticas pero salvadoras.',
            feelingsTowards: 'Respeto marcial matizado con burlas amistosas por su extrema seriedad.',
            opinionOn: '«Xander calcula veinte pasos adelante; yo me deslizo por la rendija y le abro el portón.»'
          }
        ],
        backstory: 'Nacido en los túneles y zocos subterráneos del gran desierto, Go pip aprendió desde pequeño a desarmar trampas de ruinas arcanas y reparar autómatas antiguos. Su rapidez mental y dedos ágiles lo convirtieron en el infiltrador e inventor más codiciado del Oasis.',
        motivation: 'Descubrir los secretos mecánicos de las civilizaciones arcanas y construir el autómata volador definitivo.',
        coreValues: 'Libertad, Lealtad Incondicional, Ingenio y Curiosidad',
        advancedCustomization: {
          voiceTone: 'Agudo, rápido, rítmico y lleno de entusiasmo chispeante',
          speechStyle: 'Coloquial, mordaz, lleno de jerga mecánica y apodos afectuosos',
          catchphrasesOrIdioms: '«¡Dame dos alambres y un resorte y te abro cualquier bóveda imperial!»',
          skills: [
            'Cerrajería y desactivación de trampas arcanas',
            'Ingeniería de artefactos y balística ligera',
            'Acrobacias y sigilo en entornos urbanos',
            'Tasación de chatarra mágica y reliquias'
          ],
          habitsAndMannerisms: [
            'Juguetea constantemente con una tuerca de bronce entre los nudillos',
            'Entrecierra un ojo como si estuviera midiendo distancias con una mira telescópica'
          ],
          specificInteractions: {
            withAuthority: 'Irreverencia divertida con reverencias exageradas y sonrisa socarrona.',
            withSubordinates: 'Trato fraternal, compartiendo repuestos y bocadillos.',
            withStrangers: 'Curiosidad descarada mientras evalúa qué llevan en los bolsillos.',
            withEnemies: 'Burlas acrobáticas combinadas con bombas de humo y cerrojos saboteados.'
          }
        }
      },
      liteAgent: {
        isLiteAgent: true,
        motivations: ['Desactivar cualquier trampa antes de que salte', 'Conseguir componentes arcanos raros'],
        allegianceFactionId: 'Gremio de Artificieros de las Dunas',
        greatestFear: 'Quedar atrapado en una jaula sin herramientas ni luz',
        moralAlignment: 'Caótico Bueno',
        interactionRole: 'Pícaro & Artificiero',
        combatStats: {
          maxHp: 115,
          currentHp: 115,
          maxSp: 105,
          currentSp: 105,
          attack: 29,
          defense: 21,
          agility: 42,
          specialSkillName: 'Granada Cegadora de Destello Férico',
          specialSkillDescription: 'Detona un artefacto que ciega al objetivo por 2 turnos y facilita una retirada estratégica instantánea.'
        }
      },
      validationLogs: []
    }
  },

  // -------------------------------------------------------------
  // 2. XANDER VAELITH - Estratega Táctico & Mediador
  // -------------------------------------------------------------
  {
    id: 'char-seed-xander-vaelith',
    savedAt: new Date(Date.now() - 86400000 * 3).toISOString(),
    updatedAt: new Date(Date.now() - 86400000 * 1).toISOString(),
    variantGroupId: 'group-xander-vaelith',
    variantLabel: 'Base',
    state: {
      id: 'char-seed-xander-vaelith',
      variantGroupId: 'group-xander-vaelith',
      variantLabel: 'Base',
      name: 'Xander Vaelith',
      personality: 'Sereno, Calculador, Observador y Leal a sus Principios',
      personalityTraits: ['Pragmático', 'Vigilante', 'Noble', 'Estoico'],
      archetype: 'Estratega de Élite & Mediador Táctico',
      raceGroup: 'GRUPO 1: HUMANODES SABIOS',
      raceId: '1.1',
      raceName: 'Humanos (Homo sapiens)',
      subtype: 'Comandante de la Orden de la Balanza Astral',
      anatomy: {
        sexBase: '1 Hombre',
        age: '4 Madurez Temprana (26-35 años)',
        complexion: '3 Musculoso Atlético',
        height: 'D Alto (1.80 m – 1.95 m)',
        breastDevelopment: 'A Senos Planos / Pechos Incipientes / Copa AA',
        waist: '3 Media / Equilibrada',
        glutes: '3 Moderados',
        thighs: '4 Robustos / Musculosos',
        skinColor: 'Piel Tostada por el Sol del Desierto',
        lowerBodyStructure: 'Bípedo Humanoide Estándar'
      },
      facial: {
        headShape: 'Cuadrada / Mandíbula Marcada',
        headWidth: 'Media / Fuerte',
        boneStructure: 'Marcada / Aristocrática Marcial',
        eyeColor: 'Gris Acero / Azul Tormenta',
        eyesCategory: 'A Filosos / Afilados',
        eyesSubtype: 'A3 Foco Concentrado',
        eyeliner: 'DEL1 Delgado',
        shadow: 'SOM1 Sombra Suave',
        expression: 'EXP1 Neutral',
        iris: '1 Humano',
        nose: '1 Recta / Clásica',
        lips: 'A3 Medios',
        mouthExp: 'E3 Seria / Recta',
        mouthSpecial: 'Ninguna',
        teeth: 'B1 Normales',
        mouthCorners: 'COM2 Neutras',
        mouthTexture: 'TEX1 Mate',
        earsBase: 'E01 Normales',
        earsLength: 'EL1 0–5 cm',
        kemonoEars: 'Ninguno'
      },
      hair: {
        texture: '1 Liso / Lacio',
        length: '2 Corto (Nuca)',
        cut: '4 Recto con rapado marcial',
        part: '2 Lateral Izquierdo',
        bangs: '1 Sin Flequillo',
        style: 'HST00 Peinado hacia atrás sobrio',
        hairColor: 'Negro Grafito con destellos plateados'
      },
      appendices: {
        hornsForm: 'Ninguno',
        hornsLength: 'HL1 0-10 cm',
        hornsThickness: 'G3 Medio',
        hornsPosition: 'P1 Frontales',
        wingsSize: 'S2 Medio',
        wingsPosition: 'P1 Espalda Alta',
        wingsType: 'Ninguno',
        tailsType: 'Ninguno',
        tailsLength: 'L2 Corta',
        skinAndMarks: 'T1 Piel Lisa',
        scaleLocations: [],
        markTypes: ['M5 Cicatriz de Batalla / Quemadura'],
        markLocations: { 'M5 Cicatriz de Batalla / Quemadura': ['HOMBRO IZQUIERDO'] },
        markShapes: { 'M5 Cicatriz de Batalla / Quemadura': 'Impacto de filo cruzado' },
        markColors: { 'M5 Cicatriz de Batalla / Quemadura': 'C1 Tono Rosáceo / Cicatriz' },
        antennaeType: 'Ninguna',
        extraEyes: 'Ninguno (2 Ojos Estándar)',
        extraArms: 'Ninguno (2 Brazos Estándar)',
        specialLimbs: 'Ninguna (Extremidades Orgánicas Estándar)',
        lowerBodyStructure: 'Bípedo Humanoide Estándar'
      },
      wardrobes: [
        {
          id: 'w-xander-01',
          categoryId: 'B0',
          name: 'Capa de la Balanza Astral y Ropaje de Comandante Táctico',
          cut: 'Ajustado Marcial con Capa',
          length: 'Rodilla',
          sleeve: 'Manga Larga Reforzada',
          material: 'Cuero de medianoche, paño de lana fina y acero damasquino',
          color: 'Azul Nocturno, Acero Pulido y Zafiro',
          finish: 'Satinado resistente',
          details: ['Capa con forro de estrellas bordadas', 'Fíbula de plata en hombro derecho'],
          variation: 'Uniforme de Campaña y Consejo',
          layer: 'Base',
          location: ['TORSO / PECHO', 'ESPALDA'],
          pattern: 'Liso con remates heráldicos',
          neckline: 'Cuello alto cerrado',
          emblem: 'Balanza Astral de Tres Platillos',
          detailLocations: {},
          patternDetail: "",
          vfx: "Ninguno",
        }
      ],
      role: 'Estratega Táctico & Mediador',
      styleVisual: 'Fantasía Heroica Imperial & Vanguardia Marcial',
      armor: {
        type: 'Coraza de Acero Adamantino con Remates de Zafiro',
        pieces: [
          'Peto de acero templado con grabado de la balanza',
          'Hombreras articuladas con zafiros estelares',
          'Brazales de protección y guanteletes de parada',
          'Grebas completas con refuerzo de rodilla'
        ],
        material: 'Acero adamantino y zafiro pulido',
        finish: 'Pulido espejo con tratamiento anticorrosión'
      },
      equipment: {
        weapons: ['Hoja Damasquina de filo estelar', 'Daga de Parada con guarda ancha'],
        weaponGrips: ['Cuero trenzado con pomo de zafiro'],
        bags: ['Morral táctico de campaña'],
        bagSizes: ['Mediana'],
        bagClosures: ['Cierre de latón con sello de la orden'],
        items: [
          'Mapa cartográfico detallado del Oasis y las ruinas',
          'Poción de vigor concentrado',
          'Brújula estelar de orientación astral',
          'Catalejo de campaña plegable'
        ]
      },
      background: {
        relationships: [
          {
            id: 'rel-xander-valentin',
            targetCharacterName: 'Valentín Montclair',
            relationshipType: 'Aliado de Confianza y Contraparte Diplomática',
            interactionDynamic: 'Valentín maneja las intrigas de salón y el protocolo; Xander garantiza la seguridad táctica y evalúa riesgos con pragmatismo implacable.',
            feelingsTowards: 'Profundo respeto por su agudeza mental, aun cuando le desconcierta su inclinación al lujo cortesano.',
            opinionOn: '«Montclair nunca da un paso en falso en el ajedrez cortesano. Mientras su brújula moral apunte al bienestar de nuestra gente, tiene mi espada.»'
          },
          {
            id: 'rel-xander-gopip',
            targetCharacterName: 'Go pip',
            relationshipType: 'Subordinado Audaz / Explorador Invaluable',
            interactionDynamic: 'Mantiene a raya la impulsividad de Go pip canalizando su ingenio hacia objetivos tácticos concretos.',
            feelingsTowards: 'Paternal camaradería y admiración sincera por su valentía.',
            opinionOn: '«Es ruidoso e impredecible, pero jamás he visto a nadie desactivar un glifo arcano tan rápido en pleno combate.»'
          }
        ],
        backstory: 'Comandante condecorado de la Orden de la Balanza Astral, Xander fue formado desde temprana edad para resolver crisis bélicas y forjar tratados donde otros solo ven devastación. Tras liderar la pacificación del Paso Oriental, fue asignado al Palacio del Oasis como estratega y garante militar del pacto.',
        motivation: 'Salvaguardar el equilibrio de los reinos y desentrañar los códices del Pneuma para evitar una guerra total.',
        coreValues: 'Honor, Deber, Verdad y Disciplina',
        advancedCustomization: {
          voiceTone: 'Grave, firme, solemne y pausado',
          speechStyle: 'Directo, formal, analítico y preciso (órdenes claras y argumentación impecable)',
          catchphrasesOrIdioms: '«El valor sin estrategia no es heroísmo; es mera negligencia.»',
          skills: [
            'Tácticas de asedio y coordinación de escuadrones',
            'Esgrima de contraataque y tajo espejado',
            'Lectura topográfica y cartografía militar',
            'Psicología de combate y arbitraje neutral'
          ],
          habitsAndMannerisms: [
            'Inspecciona el filo de su hoja damasquina antes de cada despliegue',
            'Mantiene una postura erguida con las manos a la espalda al escuchar informes'
          ],
          specificInteractions: {
            withAuthority: 'Saludo militar intachable, expresando desacuerdos solo en privado y con alternativas fundamentadas.',
            withSubordinates: 'Firmeza justa, exigiendo excelencia pero anteponiendo la vida de sus tropas a cualquier gloria personal.',
            withStrangers: 'Evaluación serena y neutral; cortesía distante hasta confirmar intenciones.',
            withEnemies: 'Determinación de acero sin odio visceral; neutralización quirúrgica y eficiente.'
          }
        }
      },
      liteAgent: {
        isLiteAgent: true,
        motivations: ['Salvaguardar el equilibrio de los reinos', 'Desentrañar los códices del Pneuma'],
        allegianceFactionId: 'Orden de la Balanza Astral',
        greatestFear: 'El fracaso táctico que condene a sus compañeros',
        moralAlignment: 'Devoto Protector',
        interactionRole: 'Estratega Táctico & Mediador',
        combatStats: {
          maxHp: 216,
          currentHp: 216,
          maxSp: 120,
          currentSp: 120,
          attack: 34,
          defense: 28,
          agility: 30,
          specialSkillName: 'Tajo Espejado de la Balanza',
          specialSkillDescription: 'Ejecuta un contragolpe coordinado que desvía el impacto rival y restituye 30 de Pneuma al usuario.'
        }
      },
      validationLogs: []
    }
  },

  // -------------------------------------------------------------
  // 3. VALENTÍN MONTCLAIR (BASE) - Noble Diplomático & Agente Lite
  // -------------------------------------------------------------
  {
    id: 'char-seed-valentin-base',
    savedAt: new Date(Date.now() - 86400000 * 3).toISOString(),
    updatedAt: new Date(Date.now() - 86400000 * 1).toISOString(),
    variantGroupId: 'group-valentin-montclair',
    variantLabel: 'Base',
    state: {
      id: 'char-seed-valentin-base',
      variantGroupId: 'group-valentin-montclair',
      variantLabel: 'Base',
      name: 'Valentín Montclair',
      personality: 'Refinado, Analítico, Complaciente pero con Astucia Cortesana',
      personalityTraits: ['Elocuente', 'Astuto', 'Galante', 'Observador'],
      archetype: 'Noble Diplomático & Agente Lite de la Corte',
      raceGroup: 'GRUPO 1: HUMANODES SABIOS',
      raceId: '1.1',
      raceName: 'Humanos (Homo sapiens)',
      subtype: 'Heredero y Canciller del Oasis',
      anatomy: {
        sexBase: '1 Hombre',
        age: '4 Madurez Temprana (26-35 años)',
        complexion: '2 Esbelto / Estandar',
        height: 'C Normal / Estándar (1.60 m – 1.80 m)',
        breastDevelopment: 'A Senos Planos / Pechos Incipientes / Copa AA',
        waist: '2 Estrecha / Definida',
        glutes: '3 Moderados',
        thighs: '3 Medios / Equilibrados',
        skinColor: 'Piel Pálida de Porcelana con Matiz Cálido',
        lowerBodyStructure: 'Bípedo Humanoide Estándar'
      },
      facial: {
        headShape: 'Ovalada Delicada',
        headWidth: 'Media / Fina',
        boneStructure: 'Fina / Aristocrática',
        eyeColor: 'Verde Esmeralda Profundo con Destellos Dorados',
        eyesCategory: 'A Filosos / Afilados',
        eyesSubtype: 'A2 Mirada Penetrante',
        eyeliner: 'DEL1 Delgado',
        shadow: 'SOM1 Sombra Suave',
        expression: 'EXP3 Sonrisa Enigmática',
        iris: '1 Humano',
        nose: '1 Recta / Clásica',
        lips: 'A3 Medios',
        mouthExp: 'E1 Sonriente / Amable',
        mouthSpecial: 'Ninguna',
        teeth: 'B1 Normales',
        mouthCorners: 'COM1 Ligeramente Elevadas',
        mouthTexture: 'TEX2 Satinado Suave',
        earsBase: 'E01 Normales',
        earsLength: 'EL1 0–5 cm',
        kemonoEars: 'Ninguno'
      },
      hair: {
        texture: '2 Ondulado',
        length: '3 Medio (Hombros)',
        cut: '4 Recto con capas fluidas',
        part: '2 Lateral Izquierdo',
        bangs: '1 Sin Flequillo',
        style: 'HST06 Semirrecogido con pasador de plata y zafiro',
        hairColor: 'Castaño Ceniza Profundo / Ébano Sedoso'
      },
      appendices: {
        hornsForm: 'Ninguno',
        hornsLength: 'HL1 0-10 cm',
        hornsThickness: 'G3 Medio',
        hornsPosition: 'P1 Frontales',
        wingsSize: 'S2 Medio',
        wingsPosition: 'P1 Espalda Alta',
        wingsType: 'Ninguno',
        tailsType: 'Ninguno',
        tailsLength: 'L2 Corta',
        skinAndMarks: 'T1 Piel Lisa',
        scaleLocations: [],
        markTypes: ['M4 Marca de Nacimiento Distintiva'],
        markLocations: { 'M4 Marca de Nacimiento Distintiva': ['CLAVÍCULA DERECHA'] },
        markShapes: { 'M4 Marca de Nacimiento Distintiva': 'Creciente lunar estilizado de la Casa Montclair' },
        markColors: { 'M4 Marca de Nacimiento Distintiva': 'C1 Tono Rosáceo / Cicatriz' },
        antennaeType: 'Ninguna',
        extraEyes: 'Ninguno (2 Ojos Estándar)',
        extraArms: 'Ninguno (2 Brazos Estándar)',
        specialLimbs: 'Ninguna (Extremidades Orgánicas Estándar)',
        lowerBodyStructure: 'Bípedo Humanoide Estándar'
      },
      wardrobes: [
        {
          id: 'w-valentin-01',
          categoryId: 'B0',
          name: 'Jubón de Gala de Terciopelo Azul Petróleo y Oro',
          cut: 'Ajustado Aristocrático',
          length: 'Cadera',
          sleeve: 'Manga Larga Acampanada con encajes de plata',
          material: 'Seda de Damasco y Terciopelo Imperial',
          color: 'Azul Petróleo, Oro Viejo y Blanco Marfil',
          finish: 'Satinado de Lujo',
          details: ['Bordados de filigrana con rosas y pavos reales', 'Botones de zafiro engarzado'],
          variation: 'Traje Diplomático de Corte',
          layer: 'Base',
          location: ['TORSO / PECHO'],
          pattern: 'Filigrana',
          neckline: 'Cuello alto con chorrera de encaje',
          emblem: 'Sello de la Casa Montclair',
          detailLocations: {},
          patternDetail: "",
          vfx: "Ninguno",
        }
      ],
      role: 'Noble Diplomático & Agente Lite',
      styleVisual: 'Barroco de Fantasía & Corte del Oasis',
      armor: {
        type: 'Jubón Acorazado con Mallas de Plata y Brigantina Oculta',
        pieces: ['Peto interior de malla élfica ultraligera', 'Guanteletes de ante suave con refuerzo en nudillos'],
        material: 'Seda reforzada, mithril y cuero flexible',
        finish: 'Incrustaciones discretas'
      },
      equipment: {
        weapons: ['Estoque de Gala con pomo enjoyado de zafiro', 'Daga oculta de empuñadura de nácar'],
        weaponGrips: ['Hilo de plata trenzado con pomo balanceado'],
        bags: ['Limosnera de seda bordada con cordón de oro'],
        bagSizes: ['Pequeña'],
        bagClosures: ['Broche de cera ceremonial'],
        items: [
          'Sello de cera personal de la Casa Montclair',
          'Perfume de jazmín y sándalo en frasco de cristal tallado',
          'Bolsa de florines de oro acuñados',
          'Abanico cortesano con mensaje cifrado'
        ]
      },
      background: {
        relationships: [
          {
            id: 'rel-valentin-xander',
            targetCharacterName: 'Xander Vaelith',
            relationshipType: 'Aliado Estratégico y Protector',
            interactionDynamic: 'Confianza absoluta forjada en crisis palaciegas; Valentín valora la honestidad directa de Xander en un mar de aduladores.',
            feelingsTowards: 'Admiración fraternal y deuda de honor.',
            opinionOn: '«Xander es el pilar de roca en mitad de la tormenta política; cuando él está en la sala, las intrigas se vuelven predecibles.»'
          },
          {
            id: 'rel-valentin-gopip',
            targetCharacterName: 'Go pip',
            relationshipType: 'Agente Secreto y Protegido',
            interactionDynamic: 'Valentín patrocina los inventos de Go pip a cambio de información exclusiva y llaves maestras.',
            feelingsTowards: 'Afecto genuino y diversión ante su frescura irreverente.',
            opinionOn: '«Ese pequeño duende tiene más lealtad en un dedo que la mitad de los senadores del consejo juntos.»'
          },
          {
            id: 'rel-valentin-past',
            targetCharacterName: 'Valentín Montclair (Pasado / Aprendiz Diplomático)',
            relationshipType: 'Versión Alterna: Pasado',
            interactionDynamic: 'Rememoración nostálgica de sus primeros días de idealismo cortesano.',
            feelingsTowards: 'Ternura protectora hacia sus antiguos sueños.',
            opinionOn: '«Aún creía que una sonrisa sincera bastaba para sellar un tratado; pronto aprenderá el peso de una corona de palabras.»'
          },
          {
            id: 'rel-valentin-future',
            targetCharacterName: 'Valentín Montclair (Futuro / Patriarca y Gran Canciller)',
            relationshipType: 'Versión Alterna: Futuro',
            interactionDynamic: 'Reflejo del destino inexorable donde la diplomacia se convierte en poder supremo.',
            feelingsTowards: 'Respeto reverente ante su serenidad solemne.',
            opinionOn: '«En sus ojos veo el precio pagado: cada alianza consolidada dejó una cicatriz invisible en su corazón.»'
          }
        ],
        backstory: 'Heredero de la prominente Casa Montclair del Oasis, Valentín dominó desde su adolescencia el delicado arte de la retórica, la negociación y la etiqueta noble. Bajo su apariencia de dandy refinado y complaciente, opera como la mente maestra que salvaguarda la independencia del palacio frente a las ambiciones imperiales.',
        motivation: 'Establecer alianzas estratégicas perdurables y preservar la paz y prosperidad en el Oasis.',
        coreValues: 'Diplomacia, Elegancia, Tradición y Hospitalidad',
        advancedCustomization: {
          voiceTone: 'Melifluo, aterciopelado, seductor y persuasivo',
          speechStyle: 'Registro formal cortesano de altísima alcurnia (ironía sutil, cortesía impecable, uso exquisito del usted)',
          catchphrasesOrIdioms: '«En la corte, mi estimado amigo, el veneno más letal se sirve siempre en copa de cristal fino.»',
          skills: [
            'Oratoria persuasiva y negociación diplomática',
            'Esgrima de duelo con estoque y parada con capa',
            'Descifrado de códigos e intriga cortesana',
            'Etiqueta aristocrática y cata de elixires'
          ],
          habitsAndMannerisms: [
            'Ajusta el puño de encaje de su jubón mientras mide la reacción de su interlocutor',
            'Sostiene su copa de vino contemplando los reflejos de la luz antes de responder'
          ],
          specificInteractions: {
            withAuthority: 'Reverencia protocolaria perfecta, adulación medida pero con postura inquebrantable en cláusulas críticas.',
            withSubordinates: 'Generosidad aristocrática y protección benevolente a cambio de lealtad y discreción.',
            withStrangers: 'Hospitalidad deslumbrante mientras analiza hasta el último parpadeo y acento.',
            withEnemies: 'Sonrisa gélida e impecable mientras orquesta su jaque mate político sin derramar una sola lágrima.'
          }
        }
      },
      liteAgent: {
        isLiteAgent: true,
        motivations: ['Establecer alianzas estratégicas', 'Preservar la paz en el Oasis'],
        allegianceFactionId: 'Casa Montclair del Oasis',
        greatestFear: 'La ruina de su casa noble y la pérdida de prestigio cortesano',
        moralAlignment: 'Neutral Bondadoso',
        interactionRole: 'Diplomático & Consejero',
        combatStats: {
          maxHp: 140,
          currentHp: 140,
          maxSp: 90,
          currentSp: 90,
          attack: 26,
          defense: 24,
          agility: 32,
          specialSkillName: 'Danza del Velo Astral',
          specialSkillDescription: 'Maniobra defensiva cortesana que confunde al oponente, reduce su resistencia y otorga ventaja de iniciativa.'
        }
      },
      validationLogs: []
    }
  },

  // -------------------------------------------------------------
  // 4. VALENTÍN MONTCLAIR (PASADO) - Aprendiz Diplomático
  // -------------------------------------------------------------
  {
    id: 'char-seed-valentin-past',
    savedAt: new Date(Date.now() - 86400000 * 3).toISOString(),
    updatedAt: new Date(Date.now() - 86400000 * 1).toISOString(),
    variantGroupId: 'group-valentin-montclair',
    variantLabel: 'Pasado',
    baseCharacterId: 'char-seed-valentin-base',
    state: {
      id: 'char-seed-valentin-past',
      variantGroupId: 'group-valentin-montclair',
      variantLabel: 'Pasado',
      baseCharacterId: 'char-seed-valentin-base',
      name: 'Valentín Montclair (Pasado / Aprendiz Diplomático)',
      personality: 'Idealista, Curioso, Observador y Apasionado',
      personalityTraits: ['Curioso', 'Idealista', 'Entusiasta', 'Cortés'],
      archetype: 'Joven Heredero & Erudito Diplomático en Ciernes',
      raceGroup: 'GRUPO 1: HUMANODES SABIOS',
      raceId: '1.1',
      raceName: 'Humanos (Homo sapiens)',
      subtype: 'Cadete de la Cancillería del Oasis',
      anatomy: {
        sexBase: '1 Hombre',
        age: '3 Juventud (18-25 años)',
        complexion: '2 Esbelto / Estandar',
        height: 'C Normal / Estándar (1.60 m – 1.80 m)',
        breastDevelopment: 'A Senos Planos / Pechos Incipientes / Copa AA',
        waist: '2 Estrecha / Definida',
        glutes: '2 Ligeros',
        thighs: '3 Medios / Equilibrados',
        skinColor: 'Piel Clara Juvenil',
        lowerBodyStructure: 'Bípedo Humanoide Estándar'
      },
      facial: {
        headShape: 'Ovalada Delicada',
        headWidth: 'Fina / Esbelta',
        boneStructure: 'Fina Juvenil',
        eyeColor: 'Verde Esmeralda Brillante',
        eyesCategory: 'A Filosos / Afilados',
        eyesSubtype: 'A1 Almendrado Clásico',
        eyeliner: 'DEL1 Delgado',
        shadow: 'SOM0 Sin sombra',
        expression: 'EXP2 Sonrisa Curiosa',
        iris: '1 Humano',
        nose: '1 Recta / Clásica',
        lips: 'A3 Medios',
        mouthExp: 'E1 Sonriente',
        mouthSpecial: 'Ninguna',
        teeth: 'B1 Normales',
        mouthCorners: 'COM1 Elevadas',
        mouthTexture: 'TEX1 Mate',
        earsBase: 'E01 Normales',
        earsLength: 'EL1 0–5 cm',
        kemonoEars: 'Ninguno'
      },
      hair: {
        texture: '2 Ondulado',
        length: '2 Corto (Nuca)',
        cut: '4 Recto juvenil',
        part: '2 Lateral Izquierdo',
        bangs: '1 Sin Flequillo',
        style: 'HST00 Cabello suelto juvenil',
        hairColor: 'Castaño Cálido Brillante'
      },
      appendices: {
        hornsForm: 'Ninguno',
        hornsLength: 'HL1 0-10 cm',
        hornsThickness: 'G3 Medio',
        hornsPosition: 'P1 Frontales',
        wingsSize: 'S2 Medio',
        wingsPosition: 'P1 Espalda Alta',
        wingsType: 'Ninguno',
        tailsType: 'Ninguno',
        tailsLength: 'L2 Corta',
        skinAndMarks: 'T1 Piel Lisa',
        scaleLocations: [],
        markTypes: [],
        markLocations: {},
        markShapes: {},
        markColors: {},
        antennaeType: 'Ninguna',
        extraEyes: 'Ninguno (2 Ojos Estándar)',
        extraArms: 'Ninguno (2 Brazos Estándar)',
        specialLimbs: 'Ninguna (Extremidades Orgánicas Estándar)',
        lowerBodyStructure: 'Bípedo Humanoide Estándar'
      },
      wardrobes: [
        {
          id: 'w-valentin-past-01',
          categoryId: 'B0',
          name: 'Jubón de Lino y Plata de la Academia Diplomática',
          cut: 'Juvenil Académico',
          length: 'Cintura',
          sleeve: 'Manga Larga con Puños de Lino',
          material: 'Lino fino bordado con filamentos de plata',
          color: 'Blanco Nieve, Plata y Azul Celeste',
          finish: 'Satinado suave',
          details: ['Broche de aprendiz en solapa', 'Bolsillo interior para pluma y cuadernillo'],
          variation: 'Uniforme de Cadete',
          layer: 'Base',
          location: ['TORSO / PECHO'],
          pattern: 'Liso',
          neckline: 'Cuello mao sutil',
          emblem: 'Blasón Juvenil de los Montclair',
          detailLocations: {},
          patternDetail: "",
          vfx: "Ninguno",
        }
      ],
      role: 'Joven Cadete & Aprendiz Diplomático',
      styleVisual: 'Corte Académica & Romanticismo Clásico',
      armor: {
        type: 'Corselete Ligero de Cuero de Duelo',
        pieces: ['Chaleco de cuero acolchado para esgrima', 'Guantelete de esgrima de ante'],
        material: 'Cuero suave y lino reforzado',
        finish: 'Mate flexible'
      },
      equipment: {
        weapons: ['Espadín de práctica con botón de seguridad', 'Daga de gala'],
        weaponGrips: ['Cuero crudo con alambre de cobre'],
        bags: ['Morral escolar de cuero repujado'],
        bagSizes: ['Mediana'],
        bagClosures: ['Hebilla de latón'],
        items: [
          'Cuaderno encuadernado en piel con apuntes de derecho internacional',
          'Pluma de ganso y tintero de viaje sellado',
          'Medallón de la Casa Montclair'
        ]
      },
      background: {
        relationships: [
          {
            id: 'rel-valentin-past-to-base',
            targetCharacterName: 'Valentín Montclair',
            relationshipType: 'Versión Alterna: Futuro',
            interactionDynamic: 'Admiración absoluta ante la maestría y el porte que alcanzará en sus años adultos.',
            feelingsTowards: 'Asombro reverencial y deseo de estar a la altura del porvenir.',
            opinionOn: '«¿Realmente llegaré a hablar con esa soltura frente a los reyes? Prometo no defraudar nuestro nombre.»'
          }
        ],
        backstory: 'En sus primeros años en la academia de la corte del Oasis, Valentín deslumbraba a sus mentores con una memoria prodigiosa para los tratados arcaicos y su facilidad para descifrar lenguas antiguas.',
        motivation: 'Demostrar que el conocimiento y las palabras justas pueden prevenir tragedias antes de que empiece la batalla.',
        coreValues: 'Conocimiento, Honor, Idealismo y Deber',
        advancedCustomization: {
          voiceTone: 'Claro, enérgico, juvenil y educado',
          speechStyle: 'Formal académico con destellos de entusiasmo apasionado por la historia',
          catchphrasesOrIdioms: '«Todo conflicto nace de un malentendido gramatical o de una promesa rota.»',
          skills: [
            'Historia comparada y jurisprudencia del Oasis',
            'Esgrima básica de florete',
            'Traducción de pergaminos arcaicos',
            'Retórica y debate formal'
          ],
          habitsAndMannerisms: [
            'Anota mentalmente cada palabra poco común que escucha',
            'Se inclina con reverencia escolar antes de formular una pregunta'
          ],
          specificInteractions: {
            withAuthority: 'Respeto reverente y puntualidad absoluta.',
            withSubordinates: 'Compañerismo entusiasta con otros aprendices.',
            withStrangers: 'Curiosidad inocente pero con exquisita educación.',
            withEnemies: 'Firmeza nerviosa pero decidida a no ceder en sus principios.'
          }
        }
      },
      liteAgent: {
        isLiteAgent: true,
        motivations: ['Aprender los secretos de la diplomacia', 'Enorgullecer a su linaje'],
        allegianceFactionId: 'Casa Montclair del Oasis',
        greatestFear: 'Cometer una falta protocolaria que humille a su familia',
        moralAlignment: 'Leal Bueno',
        interactionRole: 'Erudito & Aprendiz',
        combatStats: {
          maxHp: 110,
          currentHp: 110,
          maxSp: 80,
          currentSp: 80,
          attack: 20,
          defense: 18,
          agility: 28,
          specialSkillName: 'Parada del Novicio',
          specialSkillDescription: 'Desvía un ataque físico y otorga un análisis inmediato de la debilidad rival.'
        }
      },
      validationLogs: []
    }
  },

  // -------------------------------------------------------------
  // 5. VALENTÍN MONTCLAIR (FUTURO) - Patriarca y Gran Canciller
  // -------------------------------------------------------------
  {
    id: 'char-seed-valentin-future',
    savedAt: new Date(Date.now() - 86400000 * 3).toISOString(),
    updatedAt: new Date(Date.now() - 86400000 * 1).toISOString(),
    variantGroupId: 'group-valentin-montclair',
    variantLabel: 'Futuro',
    baseCharacterId: 'char-seed-valentin-base',
    state: {
      id: 'char-seed-valentin-future',
      variantGroupId: 'group-valentin-montclair',
      variantLabel: 'Futuro',
      baseCharacterId: 'char-seed-valentin-base',
      name: 'Valentín Montclair (Futuro / Patriarca y Gran Canciller)',
      personality: 'Soberano, Inescrutable, Estratega Magistral y Protector Férreo',
      personalityTraits: ['Magnánimo', 'Calculador', 'Inescrutable', 'Soberano'],
      archetype: 'Gran Canciller & Patriarca de la Dinastía',
      raceGroup: 'GRUPO 1: HUMANODES SABIOS',
      raceId: '1.1',
      raceName: 'Humanos (Homo sapiens)',
      subtype: 'Soberano Regente del Gran Consejo del Oasis',
      anatomy: {
        sexBase: '1 Hombre',
        age: '4 Adulto Maduro (36-50 años)',
        complexion: '3 Musculoso Atlético / Porte Solemne',
        height: 'C Normal / Estándar (1.60 m – 1.80 m)',
        breastDevelopment: 'A Senos Planos / Pechos Incipientes / Copa AA',
        waist: '3 Media / Equilibrada',
        glutes: '3 Moderados',
        thighs: '3 Medios / Equilibrados',
        skinColor: 'Piel Pálida Noble con Leve Bronceado Distinguido',
        lowerBodyStructure: 'Bípedo Humanoide Estándar'
      },
      facial: {
        headShape: 'Ovalada con Rasgos Esculpidos',
        headWidth: 'Media / Equilibrada',
        boneStructure: 'Fina / Aristocrática Imperecedera',
        eyeColor: 'Verde Esmeralda Profundo con Reflejo Estelar',
        eyesCategory: 'A Filosos / Afilados',
        eyesSubtype: 'A3 Foco Concentrado',
        eyeliner: 'DEL1 Delgado',
        shadow: 'SOM1 Sombra Suave',
        expression: 'EXP1 Neutral Soberana',
        iris: '6 Cristalino',
        nose: '1 Recta / Clásica',
        lips: 'A3 Medios',
        mouthExp: 'E3 Seria / Recta',
        mouthSpecial: 'Ninguna',
        teeth: 'B1 Normales',
        mouthCorners: 'COM2 Neutras',
        mouthTexture: 'TEX1 Mate',
        earsBase: 'E01 Normales',
        earsLength: 'EL1 0–5 cm',
        kemonoEars: 'Ninguno',
        facialHair: 'Perilla aristocrática corta y pulcra',
        facialHairColor: 'Castaño Oscuro con Finas Hebras Plateadas'
      },
      hair: {
        texture: '2 Ondulado',
        length: '3 Medio (Hombros)',
        cut: '4 Recto señorial',
        part: '2 Lateral Izquierdo',
        bangs: '1 Sin Flequillo',
        style: 'HST06 Recogido señorial con horquilla de oro ducal',
        hairColor: 'Castaño Oscuro Ceniza con Canas Nobles en las Sienes'
      },
      appendices: {
        hornsForm: 'Ninguno',
        hornsLength: 'HL1 0-10 cm',
        hornsThickness: 'G3 Medio',
        hornsPosition: 'P1 Frontales',
        wingsSize: 'S2 Medio',
        wingsPosition: 'P1 Espalda Alta',
        wingsType: 'Ninguno',
        tailsType: 'Ninguno',
        tailsLength: 'L2 Corta',
        skinAndMarks: 'T1 Piel Lisa',
        scaleLocations: [],
        markTypes: ['M3 Marca Rúnica Arcana'],
        markLocations: { 'M3 Marca Rúnica Arcana': ['CUELLO / GARGANTA'] },
        markShapes: { 'M3 Marca Rúnica Arcana': 'Sello Rúnico de la Paz Perpetua' },
        markColors: { 'M3 Marca Rúnica Arcana': 'C3 Dorado Luminoso / Oro' },
        antennaeType: 'Ninguna',
        extraEyes: 'Ninguno (2 Ojos Estándar)',
        extraArms: 'Ninguno (2 Brazos Estándar)',
        specialLimbs: 'Ninguna (Extremidades Orgánicas Estándar)',
        lowerBodyStructure: 'Bípedo Humanoide Estándar'
      },
      wardrobes: [
        {
          id: 'w-valentin-fut-01',
          categoryId: 'B0',
          name: 'Manto Regio de Gran Canciller en Terciopelo Abisal y Oro',
          cut: 'Ajustado Majestuoso con Cola',
          length: 'Suelo con arrastre señorial',
          sleeve: 'Manga Larga de Soberano con forro de armiño',
          material: 'Terciopelo abisal, seda dorada y filamentos astrales',
          color: 'Negro Abisal, Oro Imperial y Verde Esmeralda',
          finish: 'Satinado de Gran Señorío',
          details: ['Cadena de oro macizo del Gran Canciller', 'Broche de esmeralda estrella'],
          variation: 'Ropaje de Soberano del Oasis',
          layer: 'Exterior',
          location: ['TORSO / PECHO', 'ESPALDA'],
          pattern: 'Filigrana',
          neckline: 'Cuello alto señorial',
          emblem: 'Rosa Dorada Coronada',
          detailLocations: {},
          patternDetail: "",
          vfx: "Ninguno",
        }
      ],
      role: 'Gran Canciller & Patriarca Supremo del Oasis',
      styleVisual: 'Gótico Imperial & Soberanía del Oasis',
      armor: {
        type: 'Coraza Oculta de Placas de Platino y Runas Mentales',
        pieces: ['Peto interior de platino forjado en frío', 'Guanteletes ceremoniales de filigrana'],
        material: 'Platino arcano y seda blindada',
        finish: 'Brillante enjoyado'
      },
      equipment: {
        weapons: ['Cetro de Canciller con Hoja de Estoque Oculta', 'Daga de Platino con Sello Dinástico'],
        weaponGrips: ['Oro trenzado con incrustaciones de zafiro'],
        bags: ['Cofrecillo extradimensional de documentos de estado'],
        bagSizes: ['Pequeña'],
        bagClosures: ['Sello de sangre místico y llave de platino'],
        items: [
          'Anillo con el Sello Imperial del Oasis',
          'Tratado de Paz Unificada de los Tres Reinos',
          'Orbe de comunicación psíquica'
        ]
      },
      background: {
        relationships: [
          {
            id: 'rel-valentin-fut-to-base',
            targetCharacterName: 'Valentín Montclair',
            relationshipType: 'Versión Alterna: Pasado / Origen',
            interactionDynamic: 'Guía solemne y protectora para asegurar que los sacrificios del camino valgan la pena.',
            feelingsTowards: 'Afecto templado por la experiencia de décadas de gobierno.',
            opinionOn: '«Sé que aún dudas si podrás mantener tus manos limpias; el tiempo te enseñará que la paz de millones bien vale tus noches de insomnio.»'
          },
          {
            id: 'rel-valentin-fut-xander',
            targetCharacterName: 'Xander Vaelith',
            relationshipType: 'Hermano de Juramento y Comandante Supremo',
            interactionDynamic: 'Comunión inquebrantable tras superar tres guerras y refundar el reino juntos.',
            feelingsTowards: 'Hermandad forjada en el fuego de la historia.',
            opinionOn: '«Xander es mi escudo y la mitad de mi alma política; sin él, este trono solo sería una tumba dorada.»'
          }
        ],
        backstory: 'Tras décadas de magistral timón diplomático y desactivar el Cataclismo de las Arenas, Valentín fue investido Gran Canciller vitalicio y Patriarca indiscutible del Oasis, forjando la era de mayor prosperidad y equilibrio en la historia de los reinos.',
        motivation: 'Garantizar la inmortalidad del legado del Oasis y proteger a las futuras generaciones contra la discordia.',
        coreValues: 'Soberanía, Justicia Magna, Protección del Linaje y Paz Duradera',
        advancedCustomization: {
          voiceTone: 'Grave, sereno, resonante y de autoridad absoluta',
          speechStyle: 'Discurso imperial medido y pausado, donde cada silencio pesa más que mil discursos',
          catchphrasesOrIdioms: '«Los imperios se desmoronan por la soberbia de sus ejércitos; el nuestro prevalecerá por la templanza de su palabra.»',
          skills: [
            'Gobierno supremo y geopolítica intercontinental',
            'Maestría en esgrima de gala perfeccionada',
            'Lectura de mentes e intenciones sutiles',
            'Alta magia de protección y sellos de pacto'
          ],
          habitsAndMannerisms: [
            'Observa en silencio absoluto durante varios segundos antes de emitir un veredicto',
            'Gira lentamente el anillo del sello imperial al escuchar deliberaciones'
          ],
          specificInteractions: {
            withAuthority: 'No reconoce ninguna autoridad terrenal superior a su propio pacto unificado.',
            withSubordinates: 'Exige excelencia absoluta, protegiendo con celo implacable a quienes le son leales.',
            withStrangers: 'Frialdad majestuosa e inescrutable.',
            withEnemies: 'Aniquilación estratégica calculada sin desperdiciar un solo movimiento ni pronunciar una injuria.'
          }
        }
      },
      liteAgent: {
        isLiteAgent: true,
        motivations: ['Mantener la paz unificada', 'Consolidar la dinastía'],
        allegianceFactionId: 'Gran Consejo del Oasis',
        greatestFear: 'Que una discordia civil destruya el pacto que le costó una vida entera forjar',
        moralAlignment: 'Leal Bondadoso',
        interactionRole: 'Gran Canciller & Patriarca',
        combatStats: {
          maxHp: 185,
          currentHp: 185,
          maxSp: 140,
          currentSp: 140,
          attack: 32,
          defense: 30,
          agility: 30,
          specialSkillName: 'Decreto Soberano del Gran Canciller',
          specialSkillDescription: 'Impone una presencia magnánima que paraliza a los adversarios y restituye 40 SP a todo el destacamento.'
        }
      },
      validationLogs: []
    }
  },

  // -------------------------------------------------------------
  // 6. VALENTÍN MONTCLAIR (ROL/VESTUARIO) - Maestro Duelista de Gala
  // -------------------------------------------------------------
  {
    id: 'char-seed-valentin-outfit',
    savedAt: new Date(Date.now() - 86400000 * 3).toISOString(),
    updatedAt: new Date(Date.now() - 86400000 * 1).toISOString(),
    variantGroupId: 'group-valentin-montclair',
    variantLabel: 'Rol/Vestuario',
    baseCharacterId: 'char-seed-valentin-base',
    state: {
      id: 'char-seed-valentin-outfit',
      variantGroupId: 'group-valentin-montclair',
      variantLabel: 'Rol/Vestuario',
      baseCharacterId: 'char-seed-valentin-base',
      name: 'Valentín Montclair (Rol/Vestuario: Maestro Duelista de Gala)',
      personality: 'Galante, Audaz, Certero y Letal',
      personalityTraits: ['Audaz', 'Caballeroso', 'Letal', 'Carismático'],
      archetype: 'Maestro Espadachín de la Rosa & Campeón de Honor',
      raceGroup: 'GRUPO 1: HUMANODES SABIOS',
      raceId: '1.1',
      raceName: 'Humanos (Homo sapiens)',
      subtype: 'Campeón de Duelo de la Flor de Plata',
      anatomy: {
        sexBase: '1 Hombre',
        age: '4 Madurez Temprana (26-35 años)',
        complexion: '3 Musculoso Atlético',
        height: 'C Normal / Estándar (1.60 m – 1.80 m)',
        breastDevelopment: 'A Senos Planos / Pechos Incipientes / Copa AA',
        waist: '2 Estrecha / Definida',
        glutes: '3 Moderados',
        thighs: '3 Medios / Equilibrados',
        skinColor: 'Piel Pálida de Porcelana',
        lowerBodyStructure: 'Bípedo Humanoide Estándar'
      },
      facial: {
        headShape: 'Ovalada Delicada',
        headWidth: 'Fina / Esbelta',
        boneStructure: 'Fina / Aristocrática',
        eyeColor: 'Verde Esmeralda Eléctrico',
        eyesCategory: 'A Filosos / Afilados',
        eyesSubtype: 'A3 Foco Concentrado',
        eyeliner: 'DEL2 Medio',
        shadow: 'SOM1 Sombra Suave',
        expression: 'EXP3 Sonrisa Retadora',
        iris: '1 Humano',
        nose: '1 Recta / Clásica',
        lips: 'A3 Medios',
        mouthExp: 'E2 Sonrisa Confiada',
        mouthSpecial: 'Ninguna',
        teeth: 'B1 Normales',
        mouthCorners: 'COM1 Elevadas',
        mouthTexture: 'TEX1 Mate',
        earsBase: 'E01 Normales',
        earsLength: 'EL1 0–5 cm',
        kemonoEars: 'Ninguno'
      },
      hair: {
        texture: '2 Ondulado',
        length: '3 Medio (Hombros)',
        cut: '4 Recto esgrimista',
        part: '2 Lateral Izquierdo',
        bangs: '1 Sin Flequillo',
        style: 'HST02 Coleta Baja de Esgrimista con cinta de seda negra',
        hairColor: 'Negro Ébano Profundo'
      },
      appendices: {
        hornsForm: 'Ninguno',
        hornsLength: 'HL1 0-10 cm',
        hornsThickness: 'G3 Medio',
        hornsPosition: 'P1 Frontales',
        wingsSize: 'S2 Medio',
        wingsPosition: 'P1 Espalda Alta',
        wingsType: 'Ninguno',
        tailsType: 'Ninguno',
        tailsLength: 'L2 Corta',
        skinAndMarks: 'T1 Piel Lisa',
        scaleLocations: [],
        markTypes: ['M5 Cicatriz de Batalla / Quemadura'],
        markLocations: { 'M5 Cicatriz de Batalla / Quemadura': ['PECHO / TÓRAX'] },
        markShapes: { 'M5 Cicatriz de Batalla / Quemadura': 'Rozadura fina de estoque cruzado' },
        markColors: { 'M5 Cicatriz de Batalla / Quemadura': 'C1 Tono Rosáceo / Cicatriz' },
        antennaeType: 'Ninguna',
        extraEyes: 'Ninguno (2 Ojos Estándar)',
        extraArms: 'Ninguno (2 Brazos Estándar)',
        specialLimbs: 'Ninguna (Extremidades Orgánicas Estándar)',
        lowerBodyStructure: 'Bípedo Humanoide Estándar'
      },
      wardrobes: [
        {
          id: 'w-valentin-outfit-01',
          categoryId: 'B0',
          name: 'Jubón de Cuero de Medianoche y Capa Corta de Duelo Carmesí',
          cut: 'Ajustado Marcial de Esgrima',
          length: 'Cintura',
          sleeve: 'Manga Larga de Ante con Remaches de Plata',
          material: 'Cuero de medianoche, terciopelo carmesí y malla de plata',
          color: 'Negro Azabache, Carmesí Oscuro y Plata Bruñida',
          finish: 'Satinado resistente antideslumbrante',
          details: ['Placas de brigantina cosidas al pecho', 'Guanteletes de parada de ante'],
          variation: 'Uniforme de Duelo de Honor',
          layer: 'Base',
          location: ['TORSO / PECHO', 'ESPALDA'],
          pattern: 'Liso con bordado de flor de plata',
          neckline: 'Cuello alto con bufanda de seda negra',
          emblem: 'Espada y Rosa Plateada',
          detailLocations: {},
          patternDetail: "",
          vfx: "Ninguno",
        }
      ],
      role: 'Maestro Duelista de Gala & Campeón de Honor',
      styleVisual: 'Barroco Marcial & Esgrima Romántica',
      armor: {
        type: 'Armadura Ligera de Brigantina Flexible y Malla Élfica de Duelo',
        pieces: [
          'Pechera de cuero endurecido con filigrana de plata',
          'Brazalete de parada en antebrazo izquierdo',
          'Grebas ligeras de ante y acero'
        ],
        material: 'Mithril y cuero de medianoche',
        finish: 'Satinado oscuro antideslumbrante'
      },
      equipment: {
        weapons: ['Estoque Magistral "Viento del Oasis"', 'Daga de Parada con gavilanes curvados'],
        weaponGrips: ['Cuero negro con refuerzo de plata'],
        bags: ['Cinturón de combate con estuche para dagas'],
        bagSizes: ['Pequeña'],
        bagClosures: ['Hebilla de plata labrada'],
        items: [
          'Antifaz de terciopelo para bailes de máscaras',
          'Frasco de sales aromáticas estimulantes',
          'Pañuelo de seda perfumado con las iniciales VM'
        ]
      },
      background: {
        relationships: [
          {
            id: 'rel-valentin-outfit-to-base',
            targetCharacterName: 'Valentín Montclair',
            relationshipType: 'Versión Alterna: Rol/Vestuario',
            interactionDynamic: 'La manifestación marcial donde la retórica cede su lugar al filo del acero.',
            feelingsTowards: 'Complicidad entre la elegancia cortesana y el honor de las armas.',
            opinionOn: '«Cuando las palabras ya no alcanzan para defender la verdad o proteger a un inocente, mi estoque habla sin titubear.»'
          },
          {
            id: 'rel-valentin-outfit-xander',
            targetCharacterName: 'Xander Vaelith',
            relationshipType: 'Rival Amistoso en el Círculo de Armas',
            interactionDynamic: 'Duelos de práctica constantes donde la esgrima ágil de Valentín desafía la pesada defensa de Xander.',
            feelingsTowards: 'Respeto marcial inquebrantable.',
            opinionOn: '«Xander dice que mi juego de pies es demasiado vistoso; curiosamente, nunca logra tocarme con su espada pesada.»'
          }
        ],
        backstory: 'En los salones nocturnos donde los agravios no pueden ventilarse ante los tribunales públicos, Valentín desciende a los círculos de honor bajo máscara para defender a los desfavorecidos y saldar afrentas a punta de estoque con destreza deslumbrante.',
        motivation: 'Demostrar que la belleza y el arte de la esgrima pueden imponer justicia donde la diplomacia calla.',
        coreValues: 'Honor de Caballero, Destreza Inmaculada, Protección del Inocente',
        advancedCustomization: {
          voiceTone: 'Galante, desafiante, lírico y seductor',
          speechStyle: 'Provocador pero con exquisita cortesía de duelista',
          catchphrasesOrIdioms: '«Un paso en falso y su capa estará arruinada, caballero. Prepárese a saludar al suelo.»',
          skills: [
            'Esgrima suprema de parada y estocada',
            'Acrobacias de combate con capa de esgrima',
            'Desarme en un solo tiempo de compás',
            'Movimiento en sombras de mascarada'
          ],
          habitsAndMannerisms: [
            'Acaricia el pomo de su estoque al evaluar la postura de su oponente',
            'Se ajusta los guantes de ante antes de desenvainar'
          ],
          specificInteractions: {
            withAuthority: 'Reverencia desafiante pero respetuosa de las leyes del duelo.',
            withSubordinates: 'Generosidad de maestro, enseñando fintas y paradas.',
            withStrangers: 'Sonrisa enigmática tras su antifaz.',
            withEnemies: 'Precisión implacable que busca el desarme antes que la muerte innecesaria.'
          }
        }
      },
      liteAgent: {
        isLiteAgent: true,
        motivations: ['Defender el honor con la espada', 'Perfeccionar la estocada impecable'],
        allegianceFactionId: 'Orden de la Flor de Plata',
        greatestFear: 'Ser vencido por un golpe deshonroso',
        moralAlignment: 'Caótico Bueno',
        interactionRole: 'Maestro Duelista',
        combatStats: {
          maxHp: 155,
          currentHp: 155,
          maxSp: 110,
          currentSp: 110,
          attack: 38,
          defense: 22,
          agility: 40,
          specialSkillName: 'Estocada de la Rosa Plateada',
          specialSkillDescription: 'Ejecuta una finta deslumbrante seguida de una estocada triple que ignora el 50% de la armadura rival.'
        }
      },
      validationLogs: []
    }
  }
];
