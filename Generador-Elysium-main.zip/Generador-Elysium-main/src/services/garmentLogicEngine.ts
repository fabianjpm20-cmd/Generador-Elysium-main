// =======================================================================
// GARMENT LOGIC ENGINE & INTELLIGENT COMPATIBILITY SERVICE (ESTADO 3 & 4)
// =======================================================================
// Motor cognitivo de indumentaria, accesorios y prendas de rol:
// - Comprende ontología profunda:
//   * ¿Qué es? (Definición ontológica y material)
//   * ¿Qué significa? (Simbolismo social, estatus, registro de porte)
//   * ¿Qué función cumple? (Mecánica, climática, estética o táctica)
//   * ¿Dónde y en qué parte del cuerpo se viste o usa? (Anatomía exacta)
//   * ¿Cómo se viste o usa? (Mecanismo de colocación, cierres, tensión)
//   * ¿Cuáles son las partes que componen esa prenda/accesorio?
//   * ¿Qué formas de usarse tiene esa prenda/accesorio? (Modos de porte)
// - Proporciona descripciones semánticas de efecto e influencia en el personaje.
// - Modula y filtra contextualmente:
//   * Estampados, bordados y diseños gráficos compatibles y sus ubicaciones reales.
//   * Detalles, adornos y aplicaciones compatibles y sus posiciones de uso específicas.
// - Excluye incoherencias anatómicas y evita redundancias o duplicados.
// =======================================================================

export type BodyRegionType =
  | 'head'
  | 'face'
  | 'neck'
  | 'torso_upper'
  | 'torso_full'
  | 'waist_pelvis'
  | 'legs'
  | 'feet'
  | 'arms_hands'
  | 'back_shoulders'
  | 'full_body';

export interface GarmentAnatomyProfile {
  id: string;
  name: string;
  category: string;
  whatIs: string;
  whatMeans: string;
  functionAndMeaning: string;
  effectAndInfluence: string;
  anatomicalPlacement: string;
  bodyRegion: BodyRegionType;
  howWorn: string;
  componentParts: string[];
  wearingStyles: string[];
  compatiblePrintTypes: string[];
  specificPrintLocations: string[];
  compatibleDetails: string[];
  specificDetailLocations: Record<string, string[]>;
}

export interface DetailLogicMeta {
  name: string;
  whatIs: string;
  whatMeans: string;
  functionAndMeaning: string;
  howApplied: string;
}

// -----------------------------------------------------------------------
// DICCIONARIO ONTOLÓGICO DE DETALLES, APLICACIONES & ADORNOS
// -----------------------------------------------------------------------
export const DETAIL_LOGIC_REGISTRY: Record<string, DetailLogicMeta> = {
  'Carrera de Botones': {
    name: 'Carrera de Botones',
    whatIs: 'Hilera secuencial longitudinal de botones (nácar, asta, hueso o metal forjado) alineados a lo largo de una tapeta reforzada.',
    whatMeans: 'Proyecta orden simétrico, elegancia sastorial sobria y disciplina formal de etiqueta o uniforme.',
    functionAndMeaning: 'Cierre mecánico continuo que distribuye de manera homogénea la tensión del tejido en el torso o puños.',
    howApplied: 'Ojales ribeteados a pespunte en un ala y botones cosidos con cabo de hilo de torzal en la tapeta opuesta.'
  },
  'Hebillas Metálicas': {
    name: 'Hebillas Metálicas',
    whatIs: 'Herrajes articulados de ajuste en aleaciones de bronce, acero templado, latón o plata envejecida.',
    whatMeans: 'Denota preparación para el viaje, combate activo, utilitarismo táctico o porte marcial imponente.',
    functionAndMeaning: 'Función mecánica de cierre rápido, tensado milimétrico y ceñido ergonómico sobre puntos anatómicos.',
    howApplied: 'Remachadas o cosidas mediante presillas sobre correas de cuero curtido o loneta reforzada.'
  },
  'Bordados en Hilo de Oro': {
    name: 'Bordados en Hilo de Oro',
    whatIs: 'Filamentos áureos o canutillos de oro fino bordados a mano sobre tafetán, terciopelo o paño de lana.',
    whatMeans: 'Símbolo de realeza, nobleza dinástica, consagración sacra o riqueza cortesana indiscutible.',
    functionAndMeaning: 'Acentúa los bordes visuales y jerarquiza la silueta con destellos lumínicos ante la luz.',
    howApplied: 'Puntadas ornamentales en relieve (punto de cadeneta o relleno) aplicadas en solapas, puños y pecheras.'
  },
  'Remaches y Tachuelas': {
    name: 'Remaches y Tachuelas',
    whatIs: 'Pequeñas piezas metálicas convexas, cónicas o piramidales de fijación por presión.',
    whatMeans: 'Proyecta carácter rudo, rebeldía, resistencia acorazada y estética combativa.',
    functionAndMeaning: 'Refuerzo estructural anti-desgarro en costuras sometidas a fatiga mecánica y deflexión de impactos leves.',
    howApplied: 'Insertados a presión y remachados con contrachapa en puntos de tensión de cuero o denim denso.'
  },
  'Cintas de Ajuste y Lazos': {
    name: 'Cintas de Ajuste y Lazos',
    whatIs: 'Tiras entrelazadas de satén, seda cruda o tirillas de cuero pasadas a través de ojetes reforzados.',
    whatMeans: 'Evoca romanticismo, delicadeza sensual, enigma y cuidado minucioso en la preparación personal.',
    functionAndMeaning: 'Permite regular la tensión perimetral y modular la compresión anatómica a gusto del usuario.',
    howApplied: 'Cruzadas en zigzag o lazo decorativo sobre corsetería, costados, escotes o pantorrillas.'
  },
  'Encaje y Blondas Finas': {
    name: 'Encaje y Blondas Finas',
    whatIs: 'Tejido calado ornamental translúcido elaborado en bolillos o aguja con motivos botánicos y florales.',
    whatMeans: 'Representa sofisticación aristocrática, pureza estética, feminidad refinada y elegancia palaciega.',
    functionAndMeaning: 'Aporta ligereza visual, suaviza la transición de los bordes con la piel y enriquece la textura.',
    howApplied: 'Superpuesto en ribetes festoneados de escotes, dobladillos, puños o bajo faldas.'
  },
  'Bolsillos Militares Cargo': {
    name: 'Bolsillos Militares Cargo',
    whatIs: 'Compartimentos de fuelle con solapa abatible reforzada y cierre de botón, broche de presión o hebilla.',
    whatMeans: 'Pragmatismo, autosuficiencia, preparación expedicionaria y funcionalidad táctica.',
    functionAndMeaning: 'Almacenamiento accesible de suministros, munición, cartografía o herramientas sin entorpecer el movimiento.',
    howApplied: 'Cosidos con doble pespunte sobre los laterales de muslos, costados del torso o mangas.'
  },
  'Broches Gemados': {
    name: 'Broches Gemados',
    whatIs: 'Engarces de orfebrería con cabujones o piedras preciosas pulidas (rubí, zafiro, jade, amatista, ópalo).',
    whatMeans: 'Foco focal de dignidad, herencia familiar mágica, canalización de maná o alianza dinástica.',
    functionAndMeaning: 'Anclaje central de capas, estolas o mantos; concentrador de poder místico o joyel decorativo.',
    howApplied: 'Fijados con alfiler de seguridad de resorte o tornillo de pasador en el cuello, pechera o hombros.'
  },
  'Forro Interior de Seda': {
    name: 'Forro Interior de Seda',
    whatIs: 'Capa textil interna continua y satinada confeccionada en seda natural en tono coordinado o contraste.',
    whatMeans: 'Lujo oculto e intimista perceptible solo en el movimiento del usuario.',
    functionAndMeaning: 'Facilita el deslizamiento ergonómico sobre otras prendas, reduce la fricción y optimiza el confort térmico.',
    howApplied: 'Cosido a doble vuelta invisible entre el paño exterior y el cuerpo interior de la prenda.'
  },
  'Aberturas Laterales con Botonería': {
    name: 'Aberturas Laterales con Botonería',
    whatIs: 'Ranuras funcionales verticales a lo largo de las costuras laterales provistas de botonería funcional.',
    whatMeans: 'Dinamismo marcial, porte ecuestre y versatilidad de movimiento sin sacrificar pudor formal.',
    functionAndMeaning: 'Permite desabrochar la prenda para montar a caballo, zancada de combate o ventilación corporal.',
    howApplied: 'Incorporadas en la costura lateral desde el muslo o cadera hasta el dobladillo inferior.'
  },
  'Hombreras Acolchadas Estructuradas': {
    name: 'Hombreras Acolchadas Estructuradas',
    whatIs: 'Rellenos anatómicos termoformados de guata o fieltro denso integrados en la coronilla de la sisa.',
    whatMeans: 'Imprime porte marcial, autoridad dominante, postura erguida y confianza inquebrantable.',
    functionAndMeaning: 'Amplía y cuadra visualmente la línea clavicular compensando la proporción del torso y cabeza.',
    howApplied: 'Fijadas en el vértice de la sisa entre el paño exterior y el forro superior.'
  },
  'Puntera y Talonera Metálica': {
    name: 'Puntera y Talonera Metálica',
    whatIs: 'Casquillos cóncavos de aleación metálica pulida, pavonada o repujada montados en el calzado.',
    whatMeans: 'Dureza implacable, preparación para terrenos hostiles y combate cuerpo a cuerpo.',
    functionAndMeaning: 'Protección absoluta de falanges y talón contra impactos mecánicos; añade letalidad a las patadas.',
    howApplied: 'Embutidas, remachadas y claveteadas directamente sobre la horma y la vira de la suela.'
  },
  'Suela Antideslizante Acanalada': {
    name: 'Suela Antideslizante Acanalada',
    whatIs: 'Base de pisada en caucho vulcanizado o cuero denso labrado con orugas multidireccionales profundas.',
    whatMeans: 'Firmeza táctica, adaptación a expedición y estabilidad en cualquier terreno agreste.',
    functionAndMeaning: 'Tracción extrema sobre barro, piedra mojada, nieve o cubiertas de embarcaciones.',
    howApplied: 'Cosida mediante puntada Goodyear impermeable directamente a la palmilla del calzado.'
  },
  'Cadenillas de Oro Colgantes': {
    name: 'Cadenillas de Oro Colgantes',
    whatIs: 'Eslabones diminutos diamantados suspendidos en festón que oscilan libremente con el andar.',
    whatMeans: 'Suntuosidad cortesana, movimiento hipnótico, magnetismo sensual y riqueza ostensible.',
    functionAndMeaning: 'Aportan brillo dinámico y sonido sutil armonioso al compás del paso del portador.',
    howApplied: 'Ancladas entre dos broches joyel en la cintura, pechera, hombros o dobladillos.'
  },
  'Charreteras Militares con Flecos': {
    name: 'Charreteras Militares con Flecos',
    whatIs: 'Planchas acolchadas rígidas decoradas con canelón de oro, plata o seda con flecos colgantes en hombros.',
    whatMeans: 'Alta jerarquía militar, mando supremo de regimiento o dignidad imperial.',
    functionAndMeaning: 'Define el rango del oficial y resguarda la articulación del hombro de golpes descendentes de filo.',
    howApplied: 'Abotonadas mediante presilla de hombro con botón de regimiento heráldico.'
  },
  'Escote Keyhole / Lágrima Central': {
    name: 'Escote Keyhole / Lágrima Central',
    whatIs: 'Abertura anatómica en forma de lágrima o cerradura recortada en el centro de la pechera.',
    whatMeans: 'Elegancia sugerente, sensualidad calculada y modernidad vanguardista.',
    functionAndMeaning: 'Expone un fragmento de piel o clavícula mientras mantiene la sujeción del cuello y hombros.',
    howApplied: 'Recorte ribeteado con bies elástico o festoneado de volantes fruncidos.'
  },
  'Mangas Poeta / Obispo Desprendidas': {
    name: 'Mangas Poeta / Obispo Desprendidas',
    whatIs: 'Mangas amplias y vaporosas de caída fluida con elástico en bíceps y puños fruncidos tipo volantes.',
    whatMeans: 'Romanticismo clásico, gracia etérea y libertad de movimiento lírica.',
    functionAndMeaning: 'Otorga gran volumen visual en brazos manteniendo los hombros y axilas frescos y desahogados.',
    howApplied: 'Sujetas al brazo mediante bandas elásticas de seda o lazadas decorativas independientes del torso.'
  },
  'Cremallera Metálica Expuesta': {
    name: 'Cremallera Metálica Expuesta',
    whatIs: 'Cierre dentado continuo de latón o acero visto en toda la longitud dorsal o frontal.',
    whatMeans: 'Estética moderna, audaz, tecnológica o gótico-industrial impecable.',
    functionAndMeaning: 'Puesta y retiro ultra-rápido con ajuste milimétrico continuo al cuerpo.',
    howApplied: 'Cosida a la vista con pespunte en contraste sobre las costuras centrales del tejido.'
  },
  'Abertura Lateral Alta al Muslo': {
    name: 'Abertura Lateral Alta al Muslo',
    whatIs: 'Corte vertical limpio en la falda o túnica que asciende desde el bajo hasta el muslo superior.',
    whatMeans: 'Sensualidad dominante, osadía cortesana y descaro refinado.',
    functionAndMeaning: 'Permite zancadas amplias, saltos y patadas sin la resistencia del tejido largo.',
    howApplied: 'Rematada con costura invisible o refuerzo de cinta interior para evitar desgarros superiores.'
  },
  'Drapeado Griego/Desértico de Gasa': {
    name: 'Drapeado Griego/Desértico de Gasa',
    whatIs: 'Pliegues sinuosos continuos de tela translúcida que caen en ondas suaves cruzadas sobre el cuerpo.',
    whatMeans: 'Connotación mística, pureza deífica, nobleza clásica de corte helénico o nómada aristócrata.',
    functionAndMeaning: 'Modula la silueta con sombras y transparencias envolventes sin añadir peso material.',
    howApplied: 'Fijado mediante frunces manuales y anclado a broches o costuras estratégicas de la cintura.'
  },
  'Incrustaciones de Cabujones': {
    name: 'Incrustaciones de Cabujones',
    whatIs: 'Piedras semipreciosas de corte convexo sin facetas engastadas en biseles metálicos sobre el tejido.',
    whatMeans: 'Conexión con artes arcanas, linaje elemental o veneración religiosa.',
    functionAndMeaning: 'Puntos focales de refracción de luz o contenedores de encantamientos pasivos.',
    howApplied: 'Engastadas con garras metálicas remachadas a través del tejido o cuero base.'
  },
  'Costuras Reforzadas de Combate': {
    name: 'Costuras Reforzadas de Combate',
    whatIs: 'Puntadas dobles o triples con hilo de lino encerado o kevlar en todas las uniones clave.',
    whatMeans: 'Resistencia absoluta ante el desgaste rudo, supervivencia y durabilidad.',
    functionAndMeaning: 'Impide roturas por tensión en flexiones violentas de rodillas, codos y entrepierna.',
    howApplied: 'Ejecutadas con pespunte doble paralelo y cinta de refuerzo interior de espiguilla.'
  },
  'Ballenas y Varillas de Soporte': {
    name: 'Ballenas y Varillas de Soporte',
    whatIs: 'Láminas rígidas pero elásticas de acero flexible o material sintético insertadas verticalmente.',
    whatMeans: 'Porte inquebrantable, estilización de la cintura y disciplina corporal rigurosa.',
    functionAndMeaning: 'Mantienen el tejido liso sin arrugas, comprimen el abdomen y realzan el busto.',
    howApplied: 'Canalizadas dentro de vainas cosidas en las costuras verticales del torso.'
  },
  'Tiras Multi-correa (Strappy / Jaula)': {
    name: 'Tiras Multi-correa (Strappy / Jaula)',
    whatIs: 'Entramado geométrico de tiras elásticas satinadas o de cuero que dibujan patrones sobre la piel.',
    whatMeans: 'Audacia visual, sensualidad vanguardista y provocación geométrica.',
    functionAndMeaning: 'Sujeción anatómica sin cobertura textil continua, revelando la silueta.',
    howApplied: 'Unidas con anillas metálicas y distribuidas simétricamente sobre el escote, caderas o espalda.'
  },
  'Plataforma Dentada Chunky Track': {
    name: 'Plataforma Dentada Chunky Track',
    whatIs: 'Bloque inferior de suela sobreelevada con hendiduras profundas de patrón agresivo.',
    whatMeans: 'Impronta urbana, gótica pesada, altura imponente y pisada demoledora.',
    functionAndMeaning: 'Eleva la estatura del portador varios centímetros aislando el pie del frío y lodo.',
    howApplied: 'Termofusionada y atornillada a la entresuela con refuerzo perimetral.'
  },
  'Velo de Gasa Facial Translúcido': {
    name: 'Velo de Gasa Facial Translúcido',
    whatIs: 'Lámina vaporosa semitransparente que cubre desde el caballete nasal hasta la base del cuello.',
    whatMeans: 'Misterio impenetrable, recato ceremonial, discreción cortesana o aura exótica.',
    functionAndMeaning: 'Protege contra polvo del desierto y oculta la identidad sin obstruir la respiración.',
    howApplied: 'Sujeto detrás de las orejas o anudado a la diadema en la parte posterior de la cabeza.'
  },
  'Filigrana Barroca Calada': {
    name: 'Filigrana Barroca Calada',
    whatIs: 'Entramado ornamental de finos hilos metálicos curvados creando encajes de plata o bronce.',
    whatMeans: 'Máxima destreza orfebre, herencia histórica y belleza artesanal milimétrica.',
    functionAndMeaning: 'Aligera el peso del accesorio sin perder resistencia estructural ni impacto visual.',
    howApplied: 'Soldada en caliente sobre los engastes principales o marcos exteriores.'
  },
  'Gema Solitaria en Garra Alta': {
    name: 'Gema Solitaria en Garra Alta',
    whatIs: 'Piedra de talla brillante sostenida por 4 o 6 garras metálicas elevadas sobre la banda.',
    whatMeans: 'Compromiso eterno, pureza, singularidad y distinción ineludible.',
    functionAndMeaning: 'Maximiza la entrada de luz por todos los ángulos de la gema para un brillo deslumbrante.',
    howApplied: 'Engastada a mano y asegurada doblando los extremos de las garras sobre el filetín.'
  },
  'Cráneo Animal Óseo con Marcas': {
    name: 'Cráneo Animal Óseo con Marcas',
    whatIs: 'Cráneo pulido de ave, lobo o carnero adornado con runas o pigmentos rituales ocres y carmesí.',
    whatMeans: 'Pacto chamánico, comunión con las bestias salvajes, nigromancia o veneración tribal.',
    functionAndMeaning: 'Canalizador de energías naturales y amuleto totémico de intimidación.',
    howApplied: 'Engarzado en correas de cuero crudo o insertado como pieza frontal en tocados y cinturones.'
  },
  'Luces LED / Display HUD Cyberpunk': {
    name: 'Luces LED / Display HUD Cyberpunk',
    whatIs: 'Emisores de luz electroluminiscente o micropantalla digital integrada en la montura.',
    whatMeans: 'Avanzada tecnología cibernética, conexión a redes neuronales y operatividad nocturna.',
    functionAndMeaning: 'Proyecta datos biométricos, telemetría o miras de escaneo en la retina del usuario.',
    howApplied: 'Embebido en resinas transparentes o monturas de policarbonato con microbaterías.'
  }
};

// -----------------------------------------------------------------------
// PERFILES ARQUETÍPICOS DEL MOTOR LÓGICO
// -----------------------------------------------------------------------
const EXTENDED_PROFILES: Record<string, GarmentAnatomyProfile> = {
  // 1. TORSO EXTERIOR: CHAQUETAS / BLÉISERES
  jacket: {
    id: 'jacket',
    name: 'Chaqueta / Bléiser Entallado',
    category: 'Torso Superior Exterior',
    whatIs: 'Prenda exterior estructurada para el torso superior, con sisa ajustada, solapas marcadas y cierre central o cruzado.',
    whatMeans: 'Proyecta compostura formal, autoridad marcial o elegancia profesional según su confección y remates.',
    functionAndMeaning: 'Proporciona abrigo moderado, resguardo térmico y cuadra ergonómicamente la postura del portador.',
    effectAndInfluence: 'Enfoca la atención en la amplitud de hombros y el porte del pecho, estilizando el talle y acentuando la cintura.',
    anatomicalPlacement: 'Cubre hombros, pecho, omóplatos y brazos hasta las muñecas; concluye en la cintura anatómica o cadera alta.',
    bodyRegion: 'torso_upper',
    howWorn: 'Se introduce por los brazos y se asegura al frente mediante botonadura simple/doble, cremallera o hebillas.',
    componentParts: ['Solapas y cuello', 'Pechera frontal', 'Espalda / Canesú', 'Mangas y puños', 'Dobladillo inferior', 'Bolsillos frontales'],
    wearingStyles: [
      'Abotonada ceñida (Formal / Marcial)',
      'Desabrochada y abierta (Casual / En movimiento)',
      'Apoyada sobre los hombros sin meter brazos (Capa aristocrática)',
      'Mangas arremangadas hacia el antebrazo (Pragmático)'
    ],
    compatiblePrintTypes: [
      'Bordado Heráldico / Emblema',
      'Patrón Ornamental / Damasco',
      'Caligrafía / Runas Antiguas',
      'Parche Táctico / Militar',
      'Sello Mágico / Glifo Arcano'
    ],
    specificPrintLocations: [
      'Pechera izquierda (Sobre el corazón)',
      'Espalda completa (Central dorsal)',
      'Solapas y cuello',
      'Manga exterior / Hombro',
      'Borde del dobladillo inferior'
    ],
    compatibleDetails: [
      'Carrera de Botones',
      'Hebillas Metálicas',
      'Bordados en Hilo de Oro',
      'Remaches y Tachuelas',
      'Hombreras Acolchadas Estructuradas',
      'Forro Interior de Seda',
      'Charreteras Militares con Flecos',
      'Cremallera Metálica Expuesta',
      'Bolsillos Militares Cargo'
    ],
    specificDetailLocations: {
      'Carrera de Botones': ['Tapeta frontal central', 'Puños de ambas mangas'],
      'Hebillas Metálicas': ['Cuello / Garganta', 'Cintura lateral', 'Puños'],
      'Bordados en Hilo de Oro': ['Solapas y bordes frontales', 'Puños', 'Espalda alta'],
      'Remaches y Tachuelas': ['Hombreras', 'Costuras de las mangas', 'Bolsillos'],
      'Hombreras Acolchadas Estructuradas': ['Vértice de hombros izquierdo y derecho'],
      'Forro Interior de Seda': ['Interior visible al abrir', 'Reverso de solapas'],
      'Charreteras Militares con Flecos': ['Vértice de ambos hombros'],
      'Cremallera Metálica Expuesta': ['Cierre frontal central', 'Bolsillos en pecho'],
      'Bolsillos Militares Cargo': ['Costados del torso', 'Brazos superiores']
    }
  },

  // 2. CAPAS / ABRIGOS LARGOS
  coat: {
    id: 'coat',
    name: 'Abrigo Largo / Capa Envolvente',
    category: 'Prenda Envolvente / Abrigo Largo',
    whatIs: 'Prenda envolvente de gran longitud confeccionada en paños pesados, terciopelo o cueros nobles con amplio vuelo.',
    whatMeans: 'Denota distinción señorial, misterio insondable, estatus expedicionario o investidura mágica mayor.',
    functionAndMeaning: 'Resguarda contra el viento gélido, lluvias y miradas indiscretas, permitiendo ocultar armamento u objetos personales.',
    effectAndInfluence: 'Alarga monumentalmente la silueta; el ondear de sus faldones genera dramatismo cinético y autoridad visual.',
    anatomicalPlacement: 'Abarca desde la nuca y hombros hasta la media pantorrilla o los talones envolviendo la totalidad del cuerpo.',
    bodyRegion: 'torso_full',
    howWorn: 'Se posa sobre los hombros y se sujeta en el cuello mediante broche joyel, presilla de cuero o ceñidor en la cintura.',
    componentParts: ['Cuello alto / Capucha', 'Cúpula de hombros', 'Cuerpo principal anterior y posterior', 'Faldones de vuelo', 'Mangas amplias', 'Cinturón ceñidor'],
    wearingStyles: [
      'Totalmente cerrado y ceñido con cinturón',
      'Abierto al frente mostrando el atuendo interior',
      'Semi-abrochado solo en el cuello',
      'Tirado sobre un solo hombro con caída asimétrica'
    ],
    compatiblePrintTypes: [
      'Patrón Ornamental / Damasco',
      'Bordado Heráldico / Emblema',
      'Sello Mágico / Glifo Arcano',
      'Estampado Degradado Místico',
      'Caligrafía / Runas Antiguas'
    ],
    specificPrintLocations: [
      'Faldones inferiores (Vuelo perimetral)',
      'Espalda dorsal amplia',
      'Cuello / Capucha exterior',
      'Bordes verticales delanteros',
      'Solapas caídas'
    ],
    compatibleDetails: [
      'Bordados en Hilo de Oro',
      'Broches Gemados',
      'Forro Interior de Seda',
      'Hebillas Metálicas',
      'Aberturas Laterales con Botonería',
      'Hombreras Acolchadas Estructuradas',
      'Carrera de Botones'
    ],
    specificDetailLocations: {
      'Bordados en Hilo de Oro': ['Ribete perimetral inferior', 'Solapas y cuello', 'Canesú de la espalda'],
      'Broches Gemados': ['Garganta / Cierre frontal del cuello', 'Vértice del hombro derecho'],
      'Forro Interior de Seda': ['Interior de faldones visible al andar', 'Interior de capucha'],
      'Hebillas Metálicas': ['Cinturón central', 'Trabillas de mangas', 'Garganta'],
      'Aberturas Laterales con Botonería': ['Costuras laterales para cabalgadura'],
      'Hombreras Acolchadas Estructuradas': ['Cúpula de ambos hombros'],
      'Carrera de Botones': ['Hilera vertical frontal completa']
    }
  },

  // 3. CAMISA / BLUSA / TOP
  shirt: {
    id: 'shirt',
    name: 'Camisa / Blusa Textil',
    category: 'Torso Superior Base',
    whatIs: 'Prenda ligera de primera capa sobre el torso confeccionada en algodón fino, lino, seda o tafetán suave.',
    whatMeans: 'Define la base del registro estético (pulcritud noble, desenfado aventurero o sensualidad delicada).',
    functionAndMeaning: 'Contacto directo con la piel, absorbe transpiración y sirve de base anatómica para chaquetas o corsets.',
    effectAndInfluence: 'Suaviza el contorno de la clavícula y torso, permitiendo jugar con transparencias o escotes dinámicos.',
    anatomicalPlacement: 'Se ajusta al cuello, clavículas, pecho, costados y brazos, rematando en la pretina o sobre las caderas.',
    bodyRegion: 'torso_upper',
    howWorn: 'Se viste introduciendo los brazos y cabeza, abotonándose al frente o anudándose mediante lazos.',
    componentParts: ['Cuello (mao, camisero o en V)', 'Pechera frontal', 'Mangas y puños', 'Espalda', 'Faldón inferior'],
    wearingStyles: [
      'Fajada prolijamente dentro del pantalón o falda',
      'Suelta y holgada por fuera de la cintura',
      'Primeros botones desabrochados (Desenfadado)',
      'Mangas arremangadas hasta los codos',
      'Con un hombro caído al descubierto'
    ],
    compatiblePrintTypes: [
      'Serigrafía Gráfica Central',
      'Patrón Ornamental / Damasco',
      'Bordado Heráldico / Emblema',
      'Sello Mágico / Glifo Arcano'
    ],
    specificPrintLocations: [
      'Pechera central',
      'Pecho izquierdo sobre el corazón',
      'Puños y cuello',
      'Mangas exteriores'
    ],
    compatibleDetails: [
      'Carrera de Botones',
      'Encaje y Blondas Finas',
      'Bordados en Hilo de Oro',
      'Cintas de Ajuste y Lazos',
      'Escote Keyhole / Lágrima Central',
      'Mangas Poeta / Obispo Desprendidas'
    ],
    specificDetailLocations: {
      'Carrera de Botones': ['Tapeta frontal central', 'Puños'],
      'Encaje y Blondas Finas': ['Ribete del cuello', 'Puños fruncidos', 'Plastrón frontal'],
      'Bordados en Hilo de Oro': ['Puntas del cuello', 'Tapeta frontal'],
      'Cintas de Ajuste y Lazos': ['Escote frontal cruzado', 'Cierre de puños'],
      'Escote Keyhole / Lágrima Central': ['Pechera superior sobre el busto'],
      'Mangas Poeta / Obispo Desprendidas': ['Brazos completos']
    }
  },

  // 4. CORSET / BUSTIER
  corset: {
    id: 'corset',
    name: 'Corset / Ceñidor Estructurado',
    category: 'Torso Estructurado & Moldeador',
    whatIs: 'Prenda técnica reforzada con varillas verticales rígidas, diseñada para comprimir la cintura y realzar el busto.',
    whatMeans: 'Seducción irresistible, alta etiqueta cortesana, estilización de reloj de arena y disciplina corporal.',
    functionAndMeaning: 'Modela mecánicamente la silueta reduciendo el diámetro de la cintura y forzando postura erguida impecable.',
    effectAndInfluence: 'Produce un pronunciado contraste visual entre caderas y cintura, realzando el escote con máxima sensualidad.',
    anatomicalPlacement: 'Se ciñe firmemente desde la base del pecho (o cubriéndolo) hasta las crestas ilíacas de la pelvis.',
    bodyRegion: 'torso_upper',
    howWorn: 'Se ajusta alrededor del torso mediante busk metálico frontal y lazada posterior cruzada tensada a mano.',
    componentParts: ['Busk / Cierres frontales', 'Paneles de compresión laterales', 'Vainas de varillas', 'Lazada posterior', 'Ribetes perimetrales'],
    wearingStyles: [
      'Ajuste rígido de compresión total',
      'Superpuesto elegantemente sobre blusa o vestido',
      'Uso directo contra la piel (Íntimo)',
      'Lazadas traseras relajadas con lazo largo colgante'
    ],
    compatiblePrintTypes: [
      'Patrón Ornamental / Damasco',
      'Bordado Heráldico / Emblema',
      'Sello Mágico / Glifo Arcano'
    ],
    specificPrintLocations: [
      'Paneles frontales gemelos',
      'Costados anatómicos',
      'Borde superior del escote',
      'Faldoncillo inferior sobre la cadera'
    ],
    compatibleDetails: [
      'Cintas de Ajuste y Lazos',
      'Ballenas y Varillas de Soporte',
      'Bordados en Hilo de Oro',
      'Encaje y Blondas Finas',
      'Hebillas Metálicas',
      'Cadenillas de Oro Colgantes'
    ],
    specificDetailLocations: {
      'Cintas de Ajuste y Lazos': ['Espalda posterior cruzada', 'Costados'],
      'Ballenas y Varillas de Soporte': ['Estructura vertical interna'],
      'Bordados en Hilo de Oro': ['Varillas verticales exteriores', 'Pechera'],
      'Encaje y Blondas Finas': ['Ribete superior del busto', 'Borde inferior'],
      'Hebillas Metálicas': ['Cierres mecánicos frontales'],
      'Cadenillas de Oro Colgantes': ['Caída sobre las caderas']
    }
  },

  // 5. VESTIDO COMPLETO / HANFU / KIMONO
  dress: {
    id: 'dress',
    name: 'Vestido Integral / Túnica Talaria',
    category: 'Cuerpo Completo / Vestido',
    whatIs: 'Prenda unificada que cubre torso, caderas y desciende por las piernas en una silueta armónica continua.',
    whatMeans: 'Gracia señorial, feminidad soberana, esplendor ceremonial o encanto de sacerdotisa mágica.',
    functionAndMeaning: 'Viste el cuerpo en una sola pieza de alta coherencia estética, permitiendo juegos de caída textil y vuelo.',
    effectAndInfluence: 'Armoniza las proporciones corporales, disimula o realza curvas según el corte y confiere elegancia etérea.',
    anatomicalPlacement: 'Desde los hombros y clavícula descendiendo ininterrumpidamente hasta las rodillas, pantorrillas o el suelo.',
    bodyRegion: 'full_body',
    howWorn: 'Se introduce por los hombros o cabeza, ciñéndose en la cintura con fajín, cremallera invisible o lazada.',
    componentParts: ['Corpiño superior', 'Escote y tirantes/mangas', 'Cintura y fajín', 'Falda de vuelo', 'Dobladillo inferior', 'Cola / Caída trasera'],
    wearingStyles: [
      'Caída recta y fluida natural',
      'Con cola extendida para paso solemne',
      'Con abertura lateral sensual abierta para zancada',
      'Con sobrefalda translúcida superpuesta'
    ],
    compatiblePrintTypes: [
      'Patrón Ornamental / Damasco',
      'Bordado Heráldico / Emblema',
      'Estampado Degradado Místico',
      'Caligrafía / Runas Antiguas',
      'Sello Mágico / Glifo Arcano'
    ],
    specificPrintLocations: [
      'Falda completa (Borde inferior perimetral)',
      'Pechera y corpiño frontal',
      'Espalda superior',
      'Mangas flotantes',
      'Panel central de la túnica'
    ],
    compatibleDetails: [
      'Abertura Lateral Alta al Muslo',
      'Drapeado Griego/Desértico de Gasa',
      'Encaje y Blondas Finas',
      'Bordados en Hilo de Oro',
      'Incrustaciones de Cabujones',
      'Cadenillas de Oro Colgantes',
      'Cremallera Metálica Expuesta'
    ],
    specificDetailLocations: {
      'Abertura Lateral Alta al Muslo': ['Costura lateral del muslo izquierdo/derecho'],
      'Drapeado Griego/Desértico de Gasa': ['Busto cruzado', 'Sobrefalda'],
      'Encaje y Blondas Finas': ['Ribete del escote', 'Dobladillo del suelo', 'Puños'],
      'Bordados en Hilo de Oro': ['Pechera frontal', 'Ribete del dobladillo'],
      'Incrustaciones de Cabujones': ['Cintura / Pretina joyel', 'Escote central'],
      'Cadenillas de Oro Colgantes': ['Caída lateral en caderas'],
      'Cremallera Metálica Expuesta': ['Espalda dorsal completa']
    }
  },

  // 6. PANTALONES / CALZAS
  pants: {
    id: 'pants',
    name: 'Pantalones / Calzas Bifurcadas',
    category: 'Prenda Inferior Bifurcada',
    whatIs: 'Prenda dividida que envuelve cintura, pelvis y cada pierna de manera individual hasta el tobillo.',
    whatMeans: 'Agilidad dinámica, practicidad combativa, autosuficiencia expedicionaria y modernidad activa.',
    functionAndMeaning: 'Protege las extremidades inferiores contra abrasión, espinas y roces, facilitando la carrera y el combate.',
    effectAndInfluence: 'Estiliza la longitud de las piernas, define la musculatura de muslos y gemelos, y afianza el centro de gravedad.',
    anatomicalPlacement: 'Desde la cintura o crestas ilíacas descendiendo por muslos, rodillas y pantorrillas hasta los tobillos.',
    bodyRegion: 'legs',
    howWorn: 'Introduciendo las piernas por las perneras y asegurando la pretina con botón, cremallera, cordón o cinturón.',
    componentParts: ['Pretina y trabillas', 'Tiro y bragueta', 'Perneras (muslos y pantorrillas)', 'Bolsillos laterales/traseros', 'Bajos o dobladillos'],
    wearingStyles: [
      'Bajos introducidos dentro de las botas (Estilo expedición/militar)',
      'Caída recta descansando sobre el empeine del calzado',
      'Arremangado informal por encima del tobillo',
      'Ceñido tipo segunda piel elástica'
    ],
    compatiblePrintTypes: [
      'Parche Táctico / Militar',
      'Patrón Ornamental / Damasco',
      'Franjas Deportivas / Tácticas',
      'Sello Mágico / Glifo Arcano'
    ],
    specificPrintLocations: [
      'Lateral exterior del muslo derecho/izquierdo',
      'Bolsillo trasero',
      'Pretina posterior',
      'Dobladillo del tobillo'
    ],
    compatibleDetails: [
      'Bolsillos Militares Cargo',
      'Hebillas Metálicas',
      'Remaches y Tachuelas',
      'Costuras Reforzadas de Combate',
      'Cintas de Ajuste y Lazos',
      'Carrera de Botones'
    ],
    specificDetailLocations: {
      'Bolsillos Militares Cargo': ['Muslos exteriores', 'Pantorrillas laterales'],
      'Hebillas Metálicas': ['Correas de muslos', 'Pretina de cintura'],
      'Remaches y Tachuelas': ['Bordes de bolsillos', 'Franjas laterales'],
      'Costuras Reforzadas de Combate': ['Entrepierna', 'Rodillas reforzadas'],
      'Cintas de Ajuste y Lazos': ['Dobladillo inferior de tobillos'],
      'Carrera de Botones': ['Bragueta frontal vista']
    }
  },

  // 7. FALDA / POLLERA
  skirt: {
    id: 'skirt',
    name: 'Falda / Pollerín con Vuelo',
    category: 'Prenda Inferior Envolvente',
    whatIs: 'Prenda continua no bifurcada que cuelga suspendida de la cintura o caderas cubriendo muslos o piernas.',
    whatMeans: 'Elegancia femenina clásica, libertad motriz, distinción cortesana o encanto juvenil según su longitud.',
    functionAndMeaning: 'Permite ventilación óptima y libertad irrestricta de zancada con oscilación estética de tejido.',
    effectAndInfluence: 'Acentúa el movimiento de las caderas al desplazarse; sus pliegues o vuelo generan dinamismo visual cautivador.',
    anatomicalPlacement: 'Desde la cintura anatómica o cadera descendiendo hacia muslos (mini), rodillas (midi) o tobillos (maxi).',
    bodyRegion: 'waist_pelvis',
    howWorn: 'Fijada en la cintura mediante pretina ajustada con cremallera lateral oculta, elástico o cinturón decorativo.',
    componentParts: ['Pretina / Cinturilla', 'Cuerpo principal de tela', 'Pliegues / Tablas plisadas', 'Dobladillo perimetral'],
    wearingStyles: [
      'Vuelo natural suelto',
      'Pliegues tableados rígidos de academia',
      'Con abertura lateral sensual abierta',
      'Con cancán o enaguas que inflan el volumen'
    ],
    compatiblePrintTypes: [
      'Patrón Ornamental / Damasco',
      'Bordado Heráldico / Emblema',
      'Estampado Degradado Místico',
      'Caligrafía / Runas Antiguas'
    ],
    specificPrintLocations: [
      'Cinturilla frontal',
      'Borde perimetral del dobladillo inferior',
      'Pliegues frontales',
      'Lateral de la abertura'
    ],
    compatibleDetails: [
      'Encaje y Blondas Finas',
      'Bordados en Hilo de Oro',
      'Cadenillas de Oro Colgantes',
      'Abertura Lateral Alta al Muslo',
      'Lazos y Listones de Raso'
    ],
    specificDetailLocations: {
      'Encaje y Blondas Finas': ['Dobladillo inferior en cascada', 'Capa sobrepuesta'],
      'Bordados en Hilo de Oro': ['Franja del dobladillo', 'Pretina frontal'],
      'Cadenillas de Oro Colgantes': ['Caída libre desde la cintura a cadera'],
      'Abertura Lateral Alta al Muslo': ['Muslo izquierdo / derecho'],
      'Lazos y Listones de Raso': ['Pretina frontal o lateral']
    }
  },

  // 8. CALZADO: BOTAS
  boots: {
    id: 'boots',
    name: 'Botas Altas / Borceguíes de Combate',
    category: 'Calzado Protector Alto',
    whatIs: 'Calzado estructurado con caña ascendente que envuelve pie, tobillo y se eleva por la pantorrilla o muslo.',
    whatMeans: 'Porte imbatible, temple militar, preparación para travesías hostiles y seguridad implacable.',
    functionAndMeaning: 'Ancla la pisada, protege contra torceduras de tobillo, frío, agua, barro e impactos en combate.',
    effectAndInfluence: 'Alarga y tonifica visualmente las piernas, afianza la postura marcial y confiere peso firme a la pisada.',
    anatomicalPlacement: 'Cubre completamente planta, empeine, talón, tobillo y espinilla hasta la rodilla o muslo.',
    bodyRegion: 'feet',
    howWorn: 'Se calzan por el pie y se aseguran mediante cordones pasados por ojetes/ganchos, cremallera interior o hebillas.',
    componentParts: ['Suela y tacón', 'Puntera y empeine', 'Caña ascendente', 'Lengüeta acolchada', 'Contrafuerte del talón', 'Herrajes de cierre'],
    wearingStyles: [
      'Cordones atados firmes y ceñidos al milímetro',
      'Caña vuelta hacia abajo mostrando forro interior (Estilo bucanero)',
      'Hebillas relajadas semiabiertas (Casual aventurero)',
      'Pantalón embutido prolijamente dentro de la caña'
    ],
    compatiblePrintTypes: [
      'Grabado Rúnico en Cuero',
      'Emblema Metálico en Relieve',
      'Parche Táctico / Militar'
    ],
    specificPrintLocations: [
      'Caña lateral exterior',
      'Lengüeta frontal superior',
      'Contrafuerte del talón',
      'Empeine superior'
    ],
    compatibleDetails: [
      'Puntera y Talonera Metálica',
      'Suela Antideslizante Acanalada',
      'Hebillas Metálicas',
      'Remaches y Tachuelas',
      'Plataforma Dentada Chunky Track'
    ],
    specificDetailLocations: {
      'Puntera y Talonera Metálica': ['Punta delantera del pie', 'Contrafuerte del talón'],
      'Suela Antideslizante Acanalada': ['Base completa de la pisada'],
      'Hebillas Metálicas': ['Correas sobre empeine', 'Caña alta superior'],
      'Remaches y Tachuelas': ['Líneas de refuerzo lateral', 'Ribete de la vira'],
      'Plataforma Dentada Chunky Track': ['Entresuela y piso de suela']
    }
  },

  // 9. CALZADO: ZAPATOS / TACONES / SANDALIAS
  shoes: {
    id: 'shoes',
    name: 'Zapatos de Vestir / Tacones Elegantes',
    category: 'Calzado Ligero / Etiqueta',
    whatIs: 'Calzado bajo que cubre el pie hasta la altura del tobillo, con horma fina, tacón estilizado o suela plana pulida.',
    whatMeans: 'Sofisticación urbana, porte cortesano exquisito, distinción y esmero estético.',
    functionAndMeaning: 'Proporciona protección ligera a la planta del pie optimizando la ligereza y la estética del paso.',
    effectAndInfluence: 'Arquea el empeine, eleva los glúteos y gemelos afinando la línea de las piernas con sensualidad.',
    anatomicalPlacement: 'Abarca la planta, dedos, empeine y talón del pie sin sobrepasar los maléolos del tobillo.',
    bodyRegion: 'feet',
    howWorn: 'Se calza directamente mediante hebilla fina al tobillo, cordón encerado clásico o diseño slip-on.',
    componentParts: ['Pala delantera', 'Empeine', 'Talón', 'Tacón / Tapeta', 'Suela de cuero', 'Tiras de ajuste'],
    wearingStyles: [
      'Calce clásico directo',
      'Con tiras cruzadas atadas al tobillo (Estilo romano/bailarina)',
      'Tacón fino de aguja para salón',
      'Suela plana de descanso'
    ],
    compatiblePrintTypes: [
      'Patrón Ornamental / Damasco',
      'Emblema Metálico en Relieve'
    ],
    specificPrintLocations: [
      'Pala delantera sobre los dedos',
      'Lateral del tacón',
      'Plantilla interior visible'
    ],
    compatibleDetails: [
      'Hebillas Metálicas',
      'Incrustaciones de Cabujones',
      'Encaje y Blondas Finas',
      'Lazos y Listones de Raso'
    ],
    specificDetailLocations: {
      'Hebillas Metálicas': ['Tira del empeine o tobillo'],
      'Incrustaciones de Cabujones': ['Centro de la pala delantera'],
      'Encaje y Blondas Finas': ['Ribete perimetral de la embocadura'],
      'Lazos y Listones de Raso': ['Talón posterior o tobillo']
    }
  },

  // 10. ACCESORIO: JOYERÍA / COLLAR / GARGANTE
  accessory_jewelry: {
    id: 'accessory_jewelry',
    name: 'Gargantilla / Collar Joyel',
    category: 'Orfebrería / Accesorio de Cuello',
    whatIs: 'Pieza focal ornamental de metales preciosos (oro, plata, platino) engarzada con gemas y dijes simbólicos.',
    whatMeans: 'Nobleza, distinción hereditaria, poder taumatúrgico, consagración sacramental o prenda de amantes.',
    functionAndMeaning: 'Atrae la mirada al cuello y escote; puede albergar encantamientos pasivos de protección o foco mágico.',
    effectAndInfluence: 'Ilumina el rostro con destellos metálicos y realza la silueta de la garganta y clavículas.',
    anatomicalPlacement: 'Se ciñe alrededor del cuello (gargantilla/choker) o descansa sobre las clavículas y el pecho superior (collar).',
    bodyRegion: 'neck',
    howWorn: 'Asegurado en la nuca mediante cierre de mosquetón, pasador magnético o lazo de terciopelo anudado.',
    componentParts: ['Cadena o gargantilla base', 'Engarce principal / Bisel', 'Gema central / Cabujón', 'Dije o gota oscilante', 'Cierre dorsal'],
    wearingStyles: [
      'Ajuste ceñido a la garganta (Choker gótico/cortesano)',
      'Colgante largo en caída oscilante sobre el escote',
      'Múltiples vueltas escalonadas en cascada'
    ],
    compatiblePrintTypes: [
      'Grabado Rúnico en Cuero',
      'Emblema Metálico en Relieve',
      'Sello Mágico / Glifo Arcano'
    ],
    specificPrintLocations: [
      'Superficie del colgante central',
      'Aro metálico perimetral',
      'Reverso del amuleto'
    ],
    compatibleDetails: [
      'Broches Gemados',
      'Cadenillas de Oro Colgantes',
      'Incrustaciones de Cabujones',
      'Filigrana Barroca Calada'
    ],
    specificDetailLocations: {
      'Broches Gemados': ['Pieza focal central delantera'],
      'Cadenillas de Oro Colgantes': ['Caída libre en festón bajo el colgante'],
      'Incrustaciones de Cabujones': ['Engaste central de la joya'],
      'Filigrana Barroca Calada': ['Cuerpo perimetral del collar']
    }
  },

  // 11. ACCESORIO: ANILLO / SORTIJA
  accessory_ring: {
    id: 'accessory_ring',
    name: 'Anillo / Sortija de Poder',
    category: 'Joyería Fina de Manos',
    whatIs: 'Aro metálico forjado en metales nobles con chatón esculpido, gema engastada o sellos heráldicos.',
    whatMeans: 'Autoridad dinástica, estatus de nobleza, alianza con entidades sobrenaturales o maestría arcana.',
    functionAndMeaning: 'Canalizador directo de conjuros manuales y distintivo de rango para sellar cera o decretos.',
    effectAndInfluence: 'Enfoca la mirada en la delicadeza y gesticulación de los dedos al invocar hechizos o blandir armas.',
    anatomicalPlacement: 'Se porta en los dedos de las manos (anular, índice, pulgar o falanges medias).',
    bodyRegion: 'arms_hands',
    howWorn: 'Deslizado por la falange del dedo elegido hasta asentar firmemente en la base articular.',
    componentParts: ['Brazo o aro del anillo', 'Chatón / Cabeza superior', 'Engaste de garras/bisel', 'Gema solitaria / Sello'],
    wearingStyles: [
      'Porte solitario en dedo anular (Clásico)',
      'Sello de mando en dedo índice o pulgar',
      'Juego coordinado en múltiples falanges (Midi-rings)'
    ],
    compatiblePrintTypes: [
      'Grabado Rúnico en Cuero',
      'Emblema Metálico en Relieve',
      'Sello Mágico / Glifo Arcano'
    ],
    specificPrintLocations: [
      'Chatón central superior',
      'Banda exterior del aro',
      'Interior del anillo (Inscripción oculta)'
    ],
    compatibleDetails: [
      'Gema Solitaria en Garra Alta',
      'Incrustaciones de Cabujones',
      'Filigrana Barroca Calada'
    ],
    specificDetailLocations: {
      'Gema Solitaria en Garra Alta': ['Cima del chatón'],
      'Incrustaciones de Cabujones': ['Cabeza del anillo'],
      'Filigrana Barroca Calada': ['Banda lateral del aro']
    }
  },

  // 12. ACCESORIO: CABEZA (TIARA / SOMBRERO / CORONA)
  accessory_head: {
    id: 'accessory_head',
    name: 'Tocado / Tiara / Corona / Sombrero',
    category: 'Accesorio Cefálico / Coronación',
    whatIs: 'Estructura cefálica confeccionada en metales esculpidos, fieltro, paja fina o flores preservadas.',
    whatMeans: 'Soberanía, intelecto preclaro, noble cuna, sacerdocio o carisma inigualable.',
    functionAndMeaning: 'Distintivo de estatus visible desde largas distancias; resguardo solar o soporte de velos.',
    effectAndInfluence: 'Enmarca la mirada, corona la melena y eleva visualmente la estatura dando presencia de monarca.',
    anatomicalPlacement: 'Asienta sobre la coronilla, sienes o frente de la cabeza.',
    bodyRegion: 'head',
    howWorn: 'Sostenido por gravedad anatómica, pasadores invisibles en el cabello o cinta bajo la barbilla.',
    componentParts: ['Aro base / Corona', 'Puntas o crestas elevadas', 'Ala protectora (en sombreros)', 'Gemas frontales', 'Sujeción de nuca'],
    wearingStyles: [
      'Asentado centrado y solemne',
      'Inclinado pícaramente hacia un costado',
      'Sobre la frente en arco descendente (Diadema)',
      'Acompañado de velo translúcido hacia la espalda'
    ],
    compatiblePrintTypes: [
      'Emblema Metálico en Relieve',
      'Patrón Ornamental / Damasco',
      'Sello Mágico / Glifo Arcano'
    ],
    specificPrintLocations: [
      'Frontal central de la diadema/corona',
      'Cinta perimetral del sombrero',
      'Ala exterior'
    ],
    compatibleDetails: [
      'Broches Gemados',
      'Incrustaciones de Cabujones',
      'Filigrana Barroca Calada',
      'Cadenillas de Oro Colgantes'
    ],
    specificDetailLocations: {
      'Broches Gemados': ['Frontal en la frente'],
      'Incrustaciones de Cabujones': ['Crestas superiores'],
      'Filigrana Barroca Calada': ['Cuerpo completo de la tiara'],
      'Cadenillas de Oro Colgantes': ['Caída lateral sobre las sienes y mejillas']
    }
  },

  // 13. ACCESORIO: ROSTRO (MÁSCARA / GAFAS)
  accessory_face: {
    id: 'accessory_face',
    name: 'Máscara Facial / Antifaz / Lentes',
    category: 'Accesorio Facial / Máscara',
    whatIs: 'Pieza esculpida en porcelana, cuero repujado, oro o titanio que cubre total o parcialmente el rostro.',
    whatMeans: 'Anonimato misterioso, alter ego enigmático, solemnidad festiva de carnaval o letalidad de verdugo.',
    functionAndMeaning: 'Oculta la verdadera identidad, protege los ojos contra destellos y potencia la intimidación psicológica.',
    effectAndInfluence: 'Focaliza toda la atención en los ojos y boca del personaje, creando una atmósfera de suspenso magnético.',
    anatomicalPlacement: 'Se amolda sobre la nariz, pómulos, cuencas oculares y/o mandíbula.',
    bodyRegion: 'face',
    howWorn: 'Fijada mediante cintas de raso anudadas en la nuca, elástico reforzado o varilla lateral sostenida en mano.',
    componentParts: ['Visor ocular / Cuencas', 'Puente nasal', 'Mejillas / Pómulos', 'Cintas de atadura dorsal'],
    wearingStyles: [
      'Uso activo frontal completo',
      'Levantada sobre la frente (En reposo)',
      'Inclinada al costado de la cabeza (Estilo kitsune festivo)',
      'Sostenida en la mano por varilla fina'
    ],
    compatiblePrintTypes: [
      'Caligrafía / Runas Antiguas',
      'Sello Mágico / Glifo Arcano',
      'Patrón Ornamental / Damasco'
    ],
    specificPrintLocations: [
      'Frente de la máscara',
      'Mejillas / Pómulos laterales',
      'Borde superior sobre los ojos'
    ],
    compatibleDetails: [
      'Velo de Gasa Facial Translúcido',
      'Incrustaciones de Cabujones',
      'Filigrana Barroca Calada',
      'Luces LED / Display HUD Cyberpunk'
    ],
    specificDetailLocations: {
      'Velo de Gasa Facial Translúcido': ['Borde inferior de la máscara cubriendo cuello'],
      'Incrustaciones de Cabujones': ['Tercer ojo en la frente', 'Pómulos'],
      'Filigrana Barroca Calada': ['Contorno de las cuencas oculares'],
      'Luces LED / Display HUD Cyberpunk': ['Visor ocular y líneas de circuito']
    }
  },

  // 14. GUANTES / GUANTELETES
  gloves: {
    id: 'gloves',
    name: 'Guantes de Conducción / Manoplas',
    category: 'Protección de Manos & Antebrazos',
    whatIs: 'Prenda anatómica ceñida que cubre dedos, palma y muñeca, confeccionada en cuero, satén o mallas reforzadas.',
    whatMeans: 'Pulcritud cortesana impecable, destreza de esgrimista, sigilo táctico o contención de poder mágico.',
    functionAndMeaning: 'Mejora el agarre en empuñaduras de armas, evita huellas, aísla del frío y protege de rozaduras.',
    effectAndInfluence: 'Acentúa la precisión gestual y la letalidad de las manos, proyectando elegancia fría y control.',
    anatomicalPlacement: 'Envuelve manos, dedos y muñecas, extendiéndose en versiones largas hasta el codo o axila.',
    bodyRegion: 'arms_hands',
    howWorn: 'Se calzan introduciendo cada dedo y se ajustan con cremallera, botoncitos de perla o correa de hebilla en la muñeca.',
    componentParts: ['Fundas de dedos', 'Dorso de la mano', 'Palma reforzada', 'Boca del guante / Manguito de muñeca'],
    wearingStyles: [
      'Guante completo ajustado a la piel',
      'Mitones sin dedos (Fingerless táctico)',
      'Manguito doblado hacia afuera en la muñeca',
      'Un solo guante en la mano diestra de tiro'
    ],
    compatiblePrintTypes: [
      'Sello Mágico / Glifo Arcano',
      'Parche Táctico / Militar',
      'Patrón Ornamental / Damasco'
    ],
    specificPrintLocations: [
      'Dorso de la mano',
      'Manguito del antebrazo',
      'Falange del pulgar'
    ],
    compatibleDetails: [
      'Remaches y Tachuelas',
      'Hebillas Metálicas',
      'Bordados en Hilo de Oro',
      'Costuras Reforzadas de Combate'
    ],
    specificDetailLocations: {
      'Remaches y Tachuelas': ['Nudillos en el dorso', 'Muñequera'],
      'Hebillas Metálicas': ['Cierre de ajuste en muñeca'],
      'Bordados en Hilo de Oro': ['Dorso de la mano en arabescos'],
      'Costuras Reforzadas de Combate': ['Palma y unión de dedos']
    }
  },

  // 15. LENCERÍA ÍNTIMA / SUJETADOR & BRAGAS
  lingerie: {
    id: 'lingerie',
    name: 'Lencería Fina / Ropa Íntima Sensual',
    category: 'Prenda Íntima de Primera Piel',
    whatIs: 'Indumentaria delicada de confección seductora elaborada en satén, encaje chantilly, seda o tul translúcido.',
    whatMeans: 'Máxima intimidad, erotismo refinado, vulnerabilidad compartida y devoción sensual.',
    functionAndMeaning: 'Contacto íntimo con las zonas más sensibles de la anatomía, esculpiendo suavemente los senos y la pelvis.',
    effectAndInfluence: 'Realza voluptuosamente las curvas carnales, atrayendo la atención a senos, caderas y vientre.',
    anatomicalPlacement: 'Amoldada directamente sobre los pechos, el monte de Venus, las crestas ilíacas y los glúteos.',
    bodyRegion: 'waist_pelvis',
    howWorn: 'Mediante corchetes traseros o delanteros, tirantes elásticos regulables o lazos laterales desatables.',
    componentParts: ['Copas / Banda torácica', 'Tirantes elásticos', 'Puente central', 'Paneles de cadera', 'Refuerzo de algodón íntimo'],
    wearingStyles: [
      'Ajuste íntimo ceñido directo',
      'Semi-descubierto con tirantes asomando bajo prenda exterior',
      'Lazos laterales desatados con caída relajada'
    ],
    compatiblePrintTypes: [
      'Patrón Ornamental / Damasco',
      'Sello Mágico / Glifo Arcano'
    ],
    specificPrintLocations: [
      'Copa izquierda sobre el seno',
      'Panel frontal del pubis',
      'Tiras elásticas de cadera'
    ],
    compatibleDetails: [
      'Encaje y Blondas Finas',
      'Cintas de Ajuste y Lazos',
      'Tiras Multi-correa (Strappy / Jaula)',
      'Cadenillas de Oro Colgantes'
    ],
    specificDetailLocations: {
      'Encaje y Blondas Finas': ['Ribete superior de las copas', 'Borde de caderas'],
      'Cintas de Ajuste y Lazos': ['Lazo central entre senos', 'Costados de cadera'],
      'Tiras Multi-correa (Strappy / Jaula)': ['Sobre el escote', 'Caderas laterales'],
      'Cadenillas de Oro Colgantes': ['Caída entre senos', 'Puente pélvico']
    }
  },

  // 16. ARMADURA: PETO / CORAZA DE PLACAS
  armor_cuirass: {
    id: 'armor_cuirass',
    name: 'Coraza de Placas / Peto de Acero',
    category: 'Blindaje de Torso & Placas',
    whatIs: 'Pieza defensiva rígida forjada en acero templado, bronce bruñido o mithril que protege el tórax y órganos vitales.',
    whatMeans: 'Indestructibilidad, heroísmo bélico, lealtad al estandarte y valor de vanguardia en primera línea de choque.',
    functionAndMeaning: 'Deflecta estocadas de filo, flechas y golpes contundentes preservando el corazón y pulmones del combatiente.',
    effectAndInfluence: 'Otorga una presencia masiva e imponente, ensancha el pecho y refleja destellos metálicos cegadores.',
    anatomicalPlacement: 'Cubre todo el esternón, caja torácica, abdomen y espalda superior (espaldar acoplado).',
    bodyRegion: 'torso_upper',
    howWorn: 'Se ensambla uniendo peto y espaldar mediante correas de cuero y hebillas sobre los hombros y costados.',
    componentParts: ['Peto frontal', 'Espaldar dorsal', 'Borde de cuello / Gola', 'Faldoncillo de láminas / Faulds', 'Correas laterales'],
    wearingStyles: [
      'Ajuste hermético sobre jubón acolchado (Modo combate)',
      'Sin espaldar para mayor ligereza frontal',
      'Peto con grabado heráldico ceremonial reluciente'
    ],
    compatiblePrintTypes: [
      'Bordado Heráldico / Emblema',
      'Sello Mágico / Glifo Arcano',
      'Caligrafía / Runas Antiguas',
      'Emblema Metálico en Relieve'
    ],
    specificPrintLocations: [
      'Centro del peto sobre el corazón',
      'Canesú dorsal del espaldar',
      'Borde inferior de las láminas'
    ],
    compatibleDetails: [
      'Hebillas Metálicas',
      'Remaches y Tachuelas',
      'Bordados en Hilo de Oro',
      'Incrustaciones de Cabujones'
    ],
    specificDetailLocations: {
      'Hebillas Metálicas': ['Correas de hombro', 'Costados laterales'],
      'Remaches y Tachuelas': ['Uniones articuladas de placas', 'Ribete perimetral'],
      'Bordados en Hilo de Oro': ['Acolchado perimetral de cuero'],
      'Incrustaciones de Cabujones': ['Centro del blasón frontal']
    }
  }
};

// -----------------------------------------------------------------------
// CLASIFICADOR INTELIGENTE POR NOMBRE Y CATEGORÍA
// -----------------------------------------------------------------------
export const resolveGarmentProfile = (
  garmentName: string,
  categoryId: string = '',
  accessorySubcat?: string
): GarmentAnatomyProfile => {
  const nameLow = (garmentName || '').toLowerCase();
  const cat = (categoryId || '').toUpperCase();

  let profileKey = 'jacket';

  // Armaduras
  if (nameLow.includes('peto') || nameLow.includes('coraza') || nameLow.includes('cuirass') || nameLow.includes('brigantina') || nameLow.includes('loriga') || cat === 'ROLE_ARMOR' || cat === 'P1') {
    profileKey = 'armor_cuirass';
  } else if (nameLow.includes('anillo') || nameLow.includes('sortija') || nameLow.includes('sello') || nameLow.includes('ring')) {
    profileKey = 'accessory_ring';
  } else if (cat === 'B4' || nameLow.includes('bota') || nameLow.includes('borceguí') || nameLow.includes('calzado militar') || nameLow.includes('botín')) {
    profileKey = 'boots';
  } else if (nameLow.includes('zapato') || nameLow.includes('tacón') || nameLow.includes('sandalia') || nameLow.includes('mocasín') || nameLow.includes('zapatilla')) {
    profileKey = 'shoes';
  } else if (nameLow.includes('sombrero') || nameLow.includes('tiara') || nameLow.includes('corona') || nameLow.includes('diadema') || nameLow.includes('gorro') || nameLow.includes('tocado') || (cat === 'B5' && (accessorySubcat === 'Cabeza' || nameLow.includes('cabeza')))) {
    profileKey = 'accessory_head';
  } else if (nameLow.includes('máscara') || nameLow.includes('antifaz') || nameLow.includes('gafas') || nameLow.includes('lentes') || nameLow.includes('visor') || (cat === 'B5' && accessorySubcat === 'Rostro')) {
    profileKey = 'accessory_face';
  } else if (nameLow.includes('collar') || nameLow.includes('gargantilla') || nameLow.includes('choker') || nameLow.includes('colgante') || nameLow.includes('amuleto') || nameLow.includes('joyel') || (cat === 'B5' && accessorySubcat === 'Cuello')) {
    profileKey = 'accessory_jewelry';
  } else if (nameLow.includes('guante') || nameLow.includes('manopla') || nameLow.includes('mitón') || nameLow.includes('manguito') || nameLow.includes('muñequera') || (cat === 'B5' && accessorySubcat === 'Brazos')) {
    profileKey = 'gloves';
  } else if (nameLow.includes('corset') || nameLow.includes('corsé') || nameLow.includes('bustier') || nameLow.includes('corselete') || nameLow.includes('ceñidor') || nameLow.includes('fajín rígido')) {
    profileKey = 'corset';
  } else if (nameLow.includes('vestido') || nameLow.includes('hanfu') || nameLow.includes('kimono') || nameLow.includes('qipao') || nameLow.includes('túnica talar') || nameLow.includes('robe') || cat === 'B0') {
    profileKey = 'dress';
  } else if (nameLow.includes('abrigo') || nameLow.includes('capa') || nameLow.includes('manto') || nameLow.includes('sobretodo') || nameLow.includes('gabardina') || nameLow.includes('levita') || cat === 'B12') {
    profileKey = 'coat';
  } else if (nameLow.includes('falda') || nameLow.includes('pollera') || nameLow.includes('minifalda') || nameLow.includes('kilt') || nameLow.includes('pareo')) {
    profileKey = 'skirt';
  } else if (nameLow.includes('pantalón') || nameLow.includes('pantalon') || nameLow.includes('calzas') || nameLow.includes('jeans') || nameLow.includes('short') || nameLow.includes('bombacho') || nameLow.includes('mallas') || nameLow.includes('legging') || cat === 'B2') {
    profileKey = 'pants';
  } else if (nameLow.includes('camisa') || nameLow.includes('blusa') || nameLow.includes('camiseta') || nameLow.includes('remera') || nameLow.includes('top') || nameLow.includes('camisola') || cat === 'B1') {
    profileKey = 'shirt';
  } else if (cat.startsWith('B3') || nameLow.includes('sostén') || nameLow.includes('bra') || nameLow.includes('braga') || nameLow.includes('tanga') || nameLow.includes('lencería') || nameLow.includes('calzón') || nameLow.includes('boxer') || nameLow.includes('slip')) {
    profileKey = 'lingerie';
  } else {
    // Fallbacks por categorías
    if (cat === 'B0') profileKey = 'dress';
    else if (cat === 'B1') profileKey = 'shirt';
    else if (cat === 'B2') profileKey = 'pants';
    else if (cat === 'B3' || cat === 'B6') profileKey = 'lingerie';
    else if (cat === 'B4') profileKey = 'boots';
    else if (cat === 'B5') profileKey = 'accessory_jewelry';
    else if (cat === 'B12') profileKey = 'coat';
    else profileKey = 'jacket';
  }

  const base = EXTENDED_PROFILES[profileKey] || EXTENDED_PROFILES.jacket;

  return {
    ...base,
    name: garmentName || base.name
  };
};

// -----------------------------------------------------------------------
// SERVICIO DE FILTRADO Y VALIDACIÓN INTELIGENTE
// -----------------------------------------------------------------------
export class GarmentLogicService {
  /**
   * Obtiene la ontología completa y perfil anatómico de una prenda o accesorio.
   */
  static getProfile(garmentName: string, categoryId: string = '', accessorySubcat?: string): GarmentAnatomyProfile {
    return resolveGarmentProfile(garmentName, categoryId, accessorySubcat);
  }

  /**
   * Retorna las formas de usarse (modos de porte) disponibles para la prenda.
   */
  static getWearingStyles(garmentName: string, categoryId: string = ''): string[] {
    const profile = resolveGarmentProfile(garmentName, categoryId);
    return profile.wearingStyles || ['Ajuste clásico natural'];
  }

  /**
   * Retorna las partes componentes de la prenda.
   */
  static getComponentParts(garmentName: string, categoryId: string = ''): string[] {
    const profile = resolveGarmentProfile(garmentName, categoryId);
    return profile.componentParts || ['Cuerpo principal'];
  }

  /**
   * Filtra los estampados y diseños gráficos compatibles con la prenda.
   */
  static filterCompatiblePrints(garmentName: string, categoryId: string, allPrintTypes: string[]): string[] {
    const profile = resolveGarmentProfile(garmentName, categoryId);
    if (!profile.compatiblePrintTypes || profile.compatiblePrintTypes.length === 0) {
      return allPrintTypes;
    }
    const filtered = allPrintTypes.filter(pt =>
      profile.compatiblePrintTypes.some(cp =>
        pt.toLowerCase().includes(cp.toLowerCase()) || cp.toLowerCase().includes(pt.toLowerCase())
      )
    );
    return filtered.length > 0 ? filtered : allPrintTypes;
  }

  /**
   * Obtiene las ubicaciones anatómicas exactas para estampados en esta prenda específica.
   */
  static getPrintLocationsForGarment(garmentName: string, categoryId: string): string[] {
    const profile = resolveGarmentProfile(garmentName, categoryId);
    return profile.specificPrintLocations || ['Frente Central', 'Espalda', 'Bordes'];
  }

  /**
   * Filtra los detalles, adornos y aplicaciones lógicamente válidos y compatibles con la prenda.
   * Excluye incoherencias (ej. suela de bota en gargantilla) y previene duplicados.
   */
  static filterCompatibleDetails(garmentName: string, categoryId: string, allDetails: string[]): string[] {
    const profile = resolveGarmentProfile(garmentName, categoryId);
    if (!allDetails || allDetails.length === 0) return [];

    // Siempre mantener 'Minimalista' si existe
    const hasMinimalist = allDetails.includes('Minimalista');

    // Filtrar detalles que encajen con la prenda
    const compatibleList = profile.compatibleDetails.map(d => d.toLowerCase());
    
    const matched = allDetails.filter(d => {
      if (d === 'Minimalista') return false;
      const dLow = d.toLowerCase();
      return compatibleList.some(comp => dLow.includes(comp) || comp.includes(dLow));
    });

    // Desduplicar
    const uniqueMatched = Array.from(new Set(matched));

    if (uniqueMatched.length === 0) {
      // Si no hubo coincidencia estricta, entregar los detalles originales no redundantes
      return Array.from(new Set(allDetails));
    }

    return hasMinimalist ? [...uniqueMatched, 'Minimalista'] : uniqueMatched;
  }

  /**
   * Obtiene las posiciones de uso específicas de un detalle en esta prenda.
   */
  static getDetailPositionsForGarment(garmentName: string, categoryId: string, detailName: string): string[] {
    const profile = resolveGarmentProfile(garmentName, categoryId);
    
    // Buscar coincidencia en specificDetailLocations
    for (const [key, positions] of Object.entries(profile.specificDetailLocations)) {
      if (detailName.toLowerCase().includes(key.toLowerCase()) || key.toLowerCase().includes(detailName.toLowerCase())) {
        return positions;
      }
    }

    // Si no está explícitamente mapeado, usar las partes componentes de la prenda
    return profile.componentParts.slice(0, 5);
  }

  /**
   * Consulta el diccionario ontológico de un detalle (qué es, qué significa, qué función cumple, cómo se aplica).
   */
  static getDetailMeta(detailName: string): DetailLogicMeta {
    for (const [key, meta] of Object.entries(DETAIL_LOGIC_REGISTRY)) {
      if (detailName.toLowerCase().includes(key.toLowerCase()) || key.toLowerCase().includes(detailName.toLowerCase())) {
        return meta;
      }
    }
    return {
      name: detailName,
      whatIs: `Elemento de ornamentación y confección artesanal: ${detailName}.`,
      whatMeans: 'Acentúa el carácter individual y el estatus visual del portador.',
      functionAndMeaning: 'Refuerza la jerarquía estética y estructural de la prenda.',
      howApplied: 'Incorporado en los puntos de anclaje y remates principales de la prenda.'
    };
  }

  /**
   * Genera el resumen cognitivo estructurado de una prenda para la ficha de personaje.
   */
  static getGarmentSummary(garmentName: string, categoryId: string): {
    whatIs: string;
    effectAndInfluence: string;
    placement: string;
    howWorn: string;
    parts: string[];
    styles: string[];
  } {
    const profile = resolveGarmentProfile(garmentName, categoryId);
    return {
      whatIs: profile.whatIs,
      effectAndInfluence: profile.effectAndInfluence,
      placement: profile.anatomicalPlacement,
      howWorn: profile.howWorn,
      parts: profile.componentParts,
      styles: profile.wearingStyles
    };
  }
}
