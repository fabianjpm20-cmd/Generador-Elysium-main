/**
 * SvgAssetCatalog - Resource Catalog & Preset Database for SVG Sprites
 * Contains categorized metadata, blueprints, and pre-configured designs
 * directly matching the reference images.
 */

import {
  CharacterSpriteOptions,
  IsometricRoomOptions,
  OverworldMapOptions,
  IsometricProp
} from './svgSpriteService';

export interface AssetResourceItem {
  id: string;
  name: string;
  category: 'character_body' | 'character_clothing' | 'character_headwear' | 'character_weapon' | 'isometric_furniture' | 'isometric_floor' | 'isometric_wall' | 'map_terrain' | 'map_marker';
  description: string;
  tags: string[];
  thumbnailSvg?: string;
  optionsSample: Record<string, any>;
}

export interface CharacterPreset {
  id: string;
  name: string;
  referenceInspiration: string; // e.g. 'Imagen 6: Caballero Gótico con Chistera y Frac'
  description: string;
  category: 'Gótico / Vampírico' | 'Fantasía Medieval' | 'Nobleza / Realeza' | 'Pícaro / Sigilo';
  options: CharacterSpriteOptions;
}

export interface IsometricRoomPreset {
  id: string;
  name: string;
  referenceInspiration: string; // e.g. 'Imagen 1: Game Room Isométrica'
  description: string;
  roomType: 'game_room' | 'office_lounge' | 'hotel_bedroom';
  options: IsometricRoomOptions;
}

export interface OverworldMapPreset {
  id: string;
  name: string;
  referenceInspiration: string; // e.g. 'Imagen 7: Mapa Ilustrado de Tierra y Tesoro'
  description: string;
  options: OverworldMapOptions;
}

// 1. CHARACTER PRESETS (MATCHING IMAGES 2, 3, 6)
export const CHARACTER_PRESETS: CharacterPreset[] = [
  {
    id: 'gothic_lord_gentleman',
    name: 'Lord Vampírico / Aristócrata Gótico',
    referenceInspiration: 'Imagen 6 — Caballero con chistera, frac negro con filigrana dorada, forro púrpura, chorrera de encaje y botas altas',
    description: 'Elegante caballero de porte altivo, chistera alta adornada con orfebrería dorada, frac con botones militares dorados, solapas bordadas, forro de seda púrpura, chorrera de encaje victoriana y botas de montar altas.',
    category: 'Gótico / Vampírico',
    options: {
      seed: 'vampire-lord-aristocrat',
      gender: 'Hombre',
      build: 'Slender',
      skinTone: 'Pálido Vampírico',
      faceStyle: 'Gothic',
      facialMarks: ['Lágrima Gótica'],
      facialHair: 'Ninguno',
      hairStyle: 'Melena Larga Gótica',
      hairColor: '#101116',
      headwear: 'Chistera Gótica con Filigrana',
      innerGarment: 'Chorrera de Encaje & Chaleco',
      outerGarment: 'Frac Gótico con Bordado Dorado & Forro Púrpura',
      beltStyle: 'Cinturón con Hebilla de Oro',
      lowerGarment: 'Pantalón Ajustado de Gala',
      footwear: 'Botas Altas con Ribete Dorado',
      handheldRight: 'Bastón con Empuñadura Dorada',
      handheldLeft: 'Ninguno',
      accessories: ['Guantes Negros de Cuero', 'Gemelos de Oro', 'Broche de Plata']
    }
  },
  {
    id: 'hound_knight_heavy',
    name: 'El Sabueso / Guardia de Acero',
    referenceInspiration: 'Imágenes 2 y 3 — Guerrero fornido con armadura completa de placas de acero, cota de malla y espadón',
    description: 'Caballero pesado con coraza remachada, guardahombros articulados, cota de malla densa y espadón bastardo de acero forjado.',
    category: 'Fantasía Medieval',
    options: {
      seed: 'hound-heavy-knight',
      gender: 'Hombre',
      build: 'Heavy',
      skinTone: 'Trigueño',
      faceStyle: 'Fierce',
      facialMarks: ['Cicatriz Ocular'],
      facialHair: 'Barba Guerrera',
      hairStyle: 'Rizos Rebeldes',
      hairColor: '#5C3826',
      headwear: 'Ninguno',
      innerGarment: 'Cota de Malla',
      outerGarment: 'Peto de Placas de Acero',
      beltStyle: 'Tahali Doble',
      lowerGarment: 'Calzas de Malla',
      footwear: 'Escarpes de Acero',
      handheldRight: 'Espadón Bastardo',
      handheldLeft: 'Ninguno',
      accessories: ['Guantes de Malla']
    }
  },
  {
    id: 'daenerys_silver_queen',
    name: 'Reina de Plata / Khaleesi Imperial',
    referenceInspiration: 'Imágenes 2 y 3 — Dama noble con vestido blanco marfil drapeado y trenzas platinadas',
    description: 'Soberana de porte etéreo con vestido largo drapeado en seda marfil, capa posterior fluida y trenzas regias con reflejos platinados.',
    category: 'Nobleza / Realeza',
    options: {
      seed: 'silver-queen-ivory',
      gender: 'Mujer',
      build: 'Slender',
      skinTone: 'Porcelana',
      faceStyle: 'Noble',
      facialMarks: [],
      facialHair: 'Ninguno',
      hairStyle: 'Trenzas Reales',
      hairColor: '#F5F5FA',
      headwear: 'Corona Real de Oro',
      innerGarment: 'Corsé de Seda',
      outerGarment: 'Vestido Imperial',
      beltStyle: 'Fajín de Seda',
      lowerGarment: 'Falda de Gala de Seda',
      footwear: 'Zapatillas de Seda',
      handheldRight: 'Ninguno',
      handheldLeft: 'Ninguno',
      accessories: ['Broche de Dragón de Plata']
    }
  },
  {
    id: 'jon_snow_night_commander',
    name: 'Comandante del Muro Sombrío',
    referenceInspiration: 'Imagen 2 — Guerrero norteño con pesada capa negra de pieles de lobo y espada con pomo blanco',
    description: 'Vigilante norteño envuelto en un capote grueso de pieles de lobo invernal, jubón acolchado reforzado y espada de acero valyrio.',
    category: 'Fantasía Medieval',
    options: {
      seed: 'night-commander-fur',
      gender: 'Hombre',
      build: 'Athletic',
      skinTone: 'Pálido Vampírico',
      faceStyle: 'Calm',
      facialMarks: [],
      facialHair: 'Barba Corta',
      hairStyle: 'Rizos Rebeldes',
      hairColor: '#121318',
      headwear: 'Ninguno',
      innerGarment: 'Jubón de Cuero',
      outerGarment: 'Capa de Invierno con Pieles',
      beltStyle: 'Tahali Doble',
      lowerGarment: 'Pantalón de Cuero',
      footwear: 'Botas Altas con Ribete Dorado',
      handheldRight: 'Espadón Bastardo',
      handheldLeft: 'Ninguno',
      accessories: ['Cadenas de Lobo de Plata']
    }
  },
  {
    id: 'tyrion_scholar_hand',
    name: 'Mano de la Corona / Sabio Erudito',
    referenceInspiration: 'Imágenes 2 y 3 — Erudito con jubón noble de terciopelo y cáliz dorado',
    description: 'Consejero agudo y estratega, ataviado con jubón bordado con gemas, calzas nobles y cáliz de oro para vino de cosecha.',
    category: 'Nobleza / Realeza',
    options: {
      seed: 'scholar-noble-hand',
      gender: 'Hombre',
      build: 'Petite',
      skinTone: 'Porcelana',
      faceStyle: 'Smirk',
      facialMarks: [],
      facialHair: 'Perilla Van Dyke',
      hairStyle: 'Corto Pulido',
      hairColor: '#E5C158',
      headwear: 'Ninguno',
      innerGarment: 'Jubón de Cuero',
      outerGarment: 'Frac Gótico con Bordado Dorado & Forro Púrpura',
      beltStyle: 'Cinturón con Hebilla de Oro',
      lowerGarment: 'Pantalón Ajustado de Gala',
      footwear: 'Botines Nobles',
      handheldRight: 'Cáliz de Oro',
      handheldLeft: 'Ninguno',
      accessories: ['Prendedor de la Mano de Oro']
    }
  }
];

// 2. ISOMETRIC ROOM PRESETS (MATCHING IMAGES 1, 4, 5)
export const ISOMETRIC_ROOM_PRESETS: IsometricRoomPreset[] = [
  {
    id: 'game_room_arcade_lounge',
    name: 'Sala de Juegos & Recreación Arcade',
    referenceInspiration: 'Imagen 1 — Sala de juegos isométrica con mesa de billar, ping pong, arcade retro, air hockey, futbolín, sofá y plantas',
    description: 'Salón de entretenimiento completo con mesa de billar de tapete verde, mesa de ping pong con red, máquinas arcade retro iluminadas, mesa de tejo/air hockey, futbolín de madera, sofá lounge y mesas de ajedrez.',
    roomType: 'game_room',
    options: {
      seed: 'game-room-lounge-01',
      gridSize: 10,
      floorStyle: 'gaming_carpet',
      wallLeftStyle: 'deep_blue_game',
      wallRightStyle: 'deep_blue_game',
      hasDoor: true,
      hasWallClock: true,
      hasAirConditioner: true,
      props: [
        { id: 'b1', type: 'billiard_table', x: 2, y: 5 },
        { id: 'p1', type: 'ping_pong_table', x: 5, y: 2 },
        { id: 'a1', type: 'arcade_cabinet', x: 0, y: 1 },
        { id: 'a2', type: 'arcade_cabinet', x: 0, y: 3 },
        { id: 'ah1', type: 'air_hockey', x: 1, y: 8 },
        { id: 'fb1', type: 'foosball_table', x: 6, y: 7 },
        { id: 's1', type: 'sofa_leather', x: 8, y: 3 },
        { id: 'ct1', type: 'coffee_table', x: 7, y: 4 },
        { id: 'ch1', type: 'chess_table', x: 8, y: 8 },
        { id: 'pl1', type: 'potted_palm', x: 0, y: 6 },
        { id: 'lp1', type: 'floor_lamp', x: 9, y: 1 }
      ]
    }
  },
  {
    id: 'office_game_breakroom',
    name: 'Oficina Corporativa & Sala de Billar',
    referenceInspiration: 'Imagen 4 — Espacio de trabajo moderno con pared de ladrillo visto, mesa de billar con jugadores, máquina expendedora de café y dispensador de agua',
    description: 'Espacio multifuncional corporativo con pared de acento de ladrillo terracota, mesa de billar con taco y bolas, máquinas expendedoras de café y botanas, dispensador de agua fría y zona de descanso.',
    roomType: 'office_lounge',
    options: {
      seed: 'office-game-room-02',
      gridSize: 10,
      floorStyle: 'office_industrial',
      wallLeftStyle: 'brick_office',
      wallRightStyle: 'glass_office',
      hasDoor: true,
      hasWallClock: true,
      hasAirConditioner: true,
      props: [
        { id: 'b1', type: 'billiard_table', x: 2, y: 4 },
        { id: 'pl1', type: 'billiard_player', x: 1, y: 4 },
        { id: 'vm1', type: 'vending_machine', x: 8, y: 1 },
        { id: 'wc1', type: 'water_cooler', x: 0, y: 7 },
        { id: 's1', type: 'sofa_leather', x: 4, y: 7 },
        { id: 'ct1', type: 'coffee_table', x: 4, y: 8 },
        { id: 'pl2', type: 'potted_palm', x: 0, y: 9 }
      ]
    }
  },
  {
    id: 'hotel_cleaning_suite',
    name: 'Suite de Hotel & Servicio de Limpieza',
    referenceInspiration: 'Imagen 5 — Habitación de hotel con camas gemelas, armario ropero, mesitas, alfombras y mucamas con aspiradora',
    description: 'Habitación amplia con alfombra suave lila, dos camas de hotel con cojines y sábanas blancas inmaculadas, armario ropero de madera noble, mesita de centro, lámparas de noche y personal de servicio.',
    roomType: 'hotel_bedroom',
    options: {
      seed: 'hotel-suite-cleaning-03',
      gridSize: 10,
      floorStyle: 'purple_bedroom_carpet',
      wallLeftStyle: 'lilac_hotel',
      wallRightStyle: 'lilac_hotel',
      hasDoor: true,
      hasWallClock: false,
      hasAirConditioner: true,
      props: [
        { id: 'bed1', type: 'twin_bed', x: 2, y: 2 },
        { id: 'bed2', type: 'twin_bed', x: 6, y: 2 },
        { id: 'ward1', type: 'wardrobe', x: 9, y: 4 },
        { id: 'sofa1', type: 'sofa_leather', x: 4, y: 7 },
        { id: 'ct1', type: 'coffee_table', x: 4, y: 8 },
        { id: 'maid1', type: 'maid_character', x: 3, y: 5 },
        { id: 'palm1', type: 'potted_palm', x: 0, y: 5 },
        { id: 'lamp1', type: 'floor_lamp', x: 8, y: 8 }
      ]
    }
  }
];

// 3. OVERWORLD MAP PRESETS (MATCHING IMAGE 7)
export const OVERWORLD_MAP_PRESETS: OverworldMapPreset[] = [
  {
    id: 'treasure_archipelago',
    name: 'Archipiélago del Tesoro & Costa Dorada',
    referenceInspiration: 'Imagen 7 — Mapa ilustrado de islas con franjas arenosas, curvas de nivel de montaña, bosques frondosos, ríos y cartelas de nombres',
    description: 'Mapa de fantasía con islas paradisíacas, perímetros de arena dorada, terrazas de elevación topográfica en tonos tierra, red de ríos serpenteantes, bosques de robles y pinos, y cartelas de pergamino con nombres de regiones.',
    options: {
      seed: 'treasure-island-gold-coast',
      title: 'ARCHIPIÉLAGO DE LAS MAREAS DORADAS',
      mapStyle: 'treasure_island',
      islandCount: 4,
      includeRivers: true,
      includeForests: true,
      includeElevationContours: true,
      includeRoads: true,
      markers: [
        { id: 'm1', x: 500, y: 380, type: 'capital', name: 'Ciudadela Central' },
        { id: 'm2', x: 260, y: 220, type: 'castle', name: 'Bastión del Viento' },
        { id: 'm3', x: 300, y: 550, type: 'port', name: 'Puerto de la Niebla' },
        { id: 'm4', x: 780, y: 200, type: 'dungeon', name: 'Caverna del Éter' },
        { id: 'm5', x: 680, y: 520, type: 'treasure', name: 'Cofre Olvidado' }
      ]
    }
  },
  {
    id: 'seven_kingdoms_realm',
    name: 'Continente de los Siete Dominios',
    referenceInspiration: 'Imagen 7 adaptada al lore de fantasía medieval y fortalezas señoriales',
    description: 'Gran masa continental dividida en cordilleras, estuarios marítimos y bastiones fortificados unidos por calzadas comerciales y bosques prohibidos.',
    options: {
      seed: 'seven-kingdoms-realm',
      title: 'TIERRAS ALTAS & COSTAS DE HIERRO',
      mapStyle: 'fantasy_parchment',
      islandCount: 3,
      includeRivers: true,
      includeForests: true,
      includeElevationContours: true,
      includeRoads: true,
      markers: [
        { id: 'm1', x: 520, y: 460, type: 'capital', name: 'Trono del Sol' },
        { id: 'm2', x: 250, y: 210, type: 'castle', name: 'Fortaleza del Norte' },
        { id: 'm3', x: 700, y: 540, type: 'port', name: 'Bahía de las Velas' },
        { id: 'm4', x: 320, y: 640, type: 'ruins', name: 'Ruinas de Valyria' }
      ]
    }
  }
];

// 4. RESOURCE CATALOG EXPLORER ITEMS
export const ASSET_CATALOG_ITEMS: AssetResourceItem[] = [
  {
    id: 'asset_gothic_top_hat',
    name: 'Chistera Gótica con Filigrana Dorada',
    category: 'character_headwear',
    description: 'Sombrero de copa alta de terciopelo negro con cresta heráldica y cinta de seda dorada. Directamente extraído de la referencia Imagen 6.',
    tags: ['Gótico', 'Sombrero', 'Oro', 'Aristócrata'],
    optionsSample: { headwear: 'Chistera Gótica con Filigrana' }
  },
  {
    id: 'asset_gothic_tailcoat',
    name: 'Frac Gótico con Bordado Dorado & Forro Púrpura',
    category: 'character_clothing',
    description: 'Frac aristocrático de doble botonadura militar, hombreras con charreteras doradas, bordados en solapas y faldones largos con forro púrpura.',
    tags: ['Frac', 'Gótico', 'Bordado', 'Púrpura'],
    optionsSample: { outerGarment: 'Frac Gótico con Bordado Dorado & Forro Púrpura' }
  },
  {
    id: 'asset_knight_cuirass',
    name: 'Peto de Placas de Acero & Cota de Malla',
    category: 'character_clothing',
    description: 'Coraza forjada con nervadura central, remaches de bronce y hombreras articuladas sobre cota de malla densa (Estilo El Sabueso).',
    tags: ['Armadura', 'Acero', 'Caballero', 'Medieval'],
    optionsSample: { outerGarment: 'Peto de Placas de Acero', innerGarment: 'Cota de Malla' }
  },
  {
    id: 'asset_royal_gown',
    name: 'Vestido Imperial de Seda Marfil',
    category: 'character_clothing',
    description: 'Túnica larga y fluida de corte regio en seda marfil con caída drapeada y espalda descubierta (Estilo Daenerys Targaryen).',
    tags: ['Vestido', 'Seda', 'Reina', 'Elegante'],
    optionsSample: { outerGarment: 'Vestido Imperial', innerGarment: 'Corsé de Seda' }
  },
  {
    id: 'asset_prop_billiard',
    name: 'Mesa de Billar Isométrica',
    category: 'isometric_furniture',
    description: 'Mesa de billar con paño verde esmeralda o carmesí, troneras de cuero negro, marco de madera noble, taco y bolas de juego.',
    tags: ['Billar', 'Juegos', 'Madera', 'Isométrico'],
    optionsSample: { type: 'billiard_table' }
  },
  {
    id: 'asset_prop_pingpong',
    name: 'Mesa de Ping Pong Isométrica',
    category: 'isometric_furniture',
    description: 'Mesa de tenis de mesa con superficie verde reglamentaria, red blanca tensada y paletas roja y negra.',
    tags: ['Ping Pong', 'Deporte', 'Recreación', 'Isométrico'],
    optionsSample: { type: 'ping_pong_table' }
  },
  {
    id: 'asset_prop_arcade',
    name: 'Máquina Arcade Retro Iluminada',
    category: 'isometric_furniture',
    description: 'Gabinete arcade clásico con marquesina superior retroiluminada, pantalla de juego cian fosforescente y panel de mandos con joystick.',
    tags: ['Arcade', 'Retro', 'Gamer', 'Neon'],
    optionsSample: { type: 'arcade_cabinet' }
  },
  {
    id: 'asset_prop_sofa_white',
    name: 'Sofá Modular de Cuero Blanco',
    category: 'isometric_furniture',
    description: 'Sofá contemporáneo de 3 plazas con reposabrazos aerodinámicos y cojines acolchados de líneas limpias.',
    tags: ['Sofá', 'Lounge', 'Moderno', 'Cuero'],
    optionsSample: { type: 'sofa_leather' }
  },
  {
    id: 'asset_map_volcanic_island',
    name: 'Isla Volcánica con Terrazas de Nivel',
    category: 'map_terrain',
    description: 'Masa insular con litoral de arena cálida, llanura verde esmeralda y cumbre marrón con cráter y vertiente fluvial.',
    tags: ['Mapa', 'Isla', 'Topografía', 'Fantasía'],
    optionsSample: { mapStyle: 'treasure_island' }
  },
  {
    id: 'asset_map_parchment_banner',
    name: 'Cartela / Banderola de Pergamino con Nombre',
    category: 'map_marker',
    description: 'Banderola heráldica de pergamino envejecido con tipografía serif grabada para rotulación de provincias y ciudades.',
    tags: ['Marcador', 'Pergamino', 'Heráldica', 'Texto'],
    optionsSample: { type: 'capital' }
  }
];
