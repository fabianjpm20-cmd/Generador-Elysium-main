/**
 * SvgSpriteService - Deterministic SVG Sprite & Asset Management Engine
 * Generates high-detail, deterministic vector sprites for:
 * 1. Characters (Gothic Aristocrat with top hat/tailcoat, Knights, Queens, Rogues, Scholars)
 * 2. Isometric Environments & Rooms (Game room with billiards, ping pong, arcade, sofa, bedrooms, offices)
 * 3. Overworld & Regional Fantasy Maps (Treasure maps, islands, elevation contours, forests, rivers, pins)
 */

export interface CharacterSpriteOptions {
  seed?: string | number;
  gender?: 'Hombre' | 'Mujer' | 'Andrógino';
  build?: 'Standard' | 'Athletic' | 'Slender' | 'Heavy' | 'Petite';
  skinTone?: string; // e.g. 'Pálido Vampírico', 'Porcelana', 'Trigueño', 'Ébano', 'Caminante Blanco'
  faceStyle?: 'Noble' | 'Fierce' | 'Gothic' | 'Smirk' | 'Calm';
  facialMarks?: string[]; // e.g. ['Lágrima Gótica', 'Cicatriz Ocular', 'Marca Sombra']
  facialHair?: string; // e.g. 'Ninguno', 'Barba Corta', 'Perilla Van Dyke', 'Barba Guerrera'
  hairStyle?: string; // e.g. 'Melena Larga Gótica', 'Ondas Nobles', 'Trenzas Reales', 'Corto Pulido', 'Rizos Rebeldes'
  hairColor?: string; // e.g. '#121216', '#E2DCD0', '#6B2B2B', '#8C6239', '#C9A050'
  headwear?: string; // e.g. 'Chistera Gótica con Filigrana', 'Corona Real de Oro', 'Capucha Sombría', 'Ninguno'
  innerGarment?: string; // e.g. 'Chorrera de Encaje & Chaleco', 'Cota de Malla', 'Jubón de Cuero', 'Túnica de Lino', 'Corsé de Seda'
  outerGarment?: string; // e.g. 'Frac Gótico con Bordado Dorado & Forro Púrpura', 'Capa de Invierno con Pieles', 'Peto de Placas de Acero', 'Túnica de Mago', 'Vestido Imperial'
  beltStyle?: string; // e.g. 'Cinturón con Hebilla de Oro', 'Fajín de Seda', 'Tahali Doble', 'Ninguno'
  lowerGarment?: string; // e.g. 'Pantalón Ajustado de Gala', 'Calzas de Malla', 'Falda de Gala de Seda', 'Pantalón de Cuero'
  footwear?: string; // e.g. 'Botas Altas con Ribete Dorado', 'Escarpes de Acero', 'Botines Nobles', 'Zapatillas de Seda'
  handheldRight?: string; // e.g. 'Espadón Bastardo', 'Estoque de Esgrima', 'Cáliz de Oro', 'Bastón con Empuñadura Dorada', 'Ninguno'
  handheldLeft?: string; // e.g. 'Daga Oculta', 'Libro de Hechizos', 'Ninguno'
  accessories?: string[]; // e.g. ['Guantes Negros de Cuero', 'Gemelos de Oro', 'Broche de Plata']
  scale?: number;
  showShadow?: boolean;
  highlightColor?: string;
  theme?: 'dark' | 'light' | 'transparent';
}

export interface IsometricProp {
  id: string;
  type:
    | 'billiard_table'
    | 'ping_pong_table'
    | 'arcade_cabinet'
    | 'foosball_table'
    | 'air_hockey'
    | 'chess_table'
    | 'sofa_leather'
    | 'coffee_table'
    | 'vending_machine'
    | 'water_cooler'
    | 'cubicle_desk'
    | 'twin_bed'
    | 'wardrobe'
    | 'potted_palm'
    | 'floor_lamp'
    | 'tv_stand'
    | 'maid_character'
    | 'billiard_player';
  x: number; // grid coords 0..10
  y: number; // grid coords 0..10
  rotation?: 0 | 90 | 180 | 270;
  color?: string;
  customLabel?: string;
}

export interface IsometricRoomOptions {
  seed?: string | number;
  gridSize?: number; // default 10
  floorStyle?: 'wood_parquet' | 'gaming_carpet' | 'purple_bedroom_carpet' | 'marble_checker' | 'office_industrial';
  wallLeftStyle?: 'lilac_hotel' | 'brick_office' | 'glass_office' | 'deep_blue_game' | 'warm_wood';
  wallRightStyle?: 'lilac_hotel' | 'brick_office' | 'glass_office' | 'deep_blue_game' | 'warm_wood';
  hasDoor?: boolean;
  hasWindow?: boolean;
  hasWallClock?: boolean;
  hasAirConditioner?: boolean;
  hasWallArt?: boolean;
  props?: IsometricProp[];
  lightingMood?: 'daylight' | 'cozy_warm' | 'cyber_neon' | 'gothic_night';
  showGridLines?: boolean;
}

export interface MapMarker {
  id: string;
  x: number; // 0..1000
  y: number; // 0..800
  type: 'capital' | 'castle' | 'port' | 'dungeon' | 'ruins' | 'treasure' | 'pin';
  name: string;
  description?: string;
}

export interface OverworldMapOptions {
  seed?: string | number;
  title?: string;
  mapStyle?: 'fantasy_parchment' | 'treasure_island' | 'emerald_archipelago';
  islandCount?: number;
  includeRivers?: boolean;
  includeForests?: boolean;
  includeElevationContours?: boolean;
  includeRoads?: boolean;
  markers?: MapMarker[];
  waterColor?: string;
  landColor?: string;
}

// PRNG for determinism
function createPrng(seedVal: string | number) {
  let s = 0;
  if (typeof seedVal === 'number') {
    s = seedVal;
  } else {
    for (let i = 0; i < seedVal.length; i++) {
      s = (s << 5) - s + seedVal.charCodeAt(i);
      s |= 0;
    }
  }
  return function () {
    s = (s + 0x6d2b79f5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Helper color palette resolver
export function resolveSkinHex(skinTone?: string): { base: string; shadow: string; highlight: string; blush: string } {
  const s = (skinTone || '').toLowerCase();
  if (s.includes('vampir') || s.includes('pálid') || s.includes('palid')) {
    return { base: '#F3EDE7', shadow: '#D6C8BF', highlight: '#FFFFFF', blush: '#E5A4A4' };
  }
  if (s.includes('caminante') || s.includes('hielo') || s.includes('azul')) {
    return { base: '#CFE2F3', shadow: '#9FC5E8', highlight: '#F0F7FD', blush: '#6FA8DC' };
  }
  if (s.includes('ébano') || s.includes('ebano') || s.includes('oscur') || s.includes('negra')) {
    return { base: '#4E3629', shadow: '#38251B', highlight: '#6B4D3C', blush: '#5E3A2B' };
  }
  if (s.includes('trigueñ') || s.includes('bronce') || s.includes('moren') || s.includes('tan')) {
    return { base: '#C99D7A', shadow: '#A27B5C', highlight: '#DDB594', blush: '#B87258' };
  }
  // Default Porcelana / Fair
  return { base: '#FDEDE2', shadow: '#E2C7B6', highlight: '#FFF7F2', blush: '#F4A9A0' };
}

// Helper hair hex
export function resolveHairHex(hairColor?: string): { main: string; dark: string; light: string } {
  const h = (hairColor || '').toLowerCase();
  if (h.startsWith('#')) {
    return { main: hairColor!, dark: '#111111', light: '#FFFFFF' };
  }
  if (h.includes('blanc') || h.includes('plata') || h.includes('platin')) {
    return { main: '#E8EDF2', dark: '#B0BAC5', light: '#FFFFFF' };
  }
  if (h.includes('rubi') || h.includes('oro') || h.includes('dorad')) {
    return { main: '#E5C158', dark: '#B8902A', light: '#FDF1A9' };
  }
  if (h.includes('rojo') || h.includes('pelirroj') || h.includes('carm')) {
    return { main: '#A8322D', dark: '#6E1B17', light: '#D9534F' };
  }
  if (h.includes('castañ') || h.includes('marr') || h.includes('caf')) {
    return { main: '#5C3826', dark: '#3B2317', light: '#7E513A' };
  }
  // Default dark raven
  return { main: '#1A1C23', dark: '#0C0D11', light: '#353948' };
}

/**
 * =====================================================================
 * 1. CHARACTER DETERMINISTIC SVG GENERATOR
 * Generates clean, crisp vector sprites matching the style in reference images:
 * - Gothic Aristocrat with Top Hat, tailored double-breasted tailcoat, purple lining, gilded trim & riding boots
 * - Daenerys-style royal flowing gown
 * - Hound-style steel plate armor & chainmail
 * - Jon Snow-style black fur mantle & bastard sword
 * - Arya-style agile rogue tunic & rapier
 * - Tyrion-style noble doublet & golden goblet
 * =====================================================================
 */
export function generateCharacterSvg(options: CharacterSpriteOptions = {}): string {
  const seed = options.seed || 'gothic-character-01';
  const prng = createPrng(seed);

  const gender = options.gender || 'Hombre';
  const build = options.build || 'Slender';
  const skin = resolveSkinHex(options.skinTone || 'Pálido Vampírico');
  const hair = resolveHairHex(options.hairColor || '#1A1C23');
  const headwear = options.headwear || 'Chistera Gótica con Filigrana';
  const outerGarment = options.outerGarment || 'Frac Gótico con Bordado Dorado & Forro Púrpura';
  const innerGarment = options.innerGarment || 'Chorrera de Encaje & Chaleco';
  const footwear = options.footwear || 'Botas Altas con Ribete Dorado';
  const handheld = options.handheldRight || 'Ninguno';
  const hairStyle = options.hairStyle || 'Melena Larga Gótica';
  const facialHair = options.facialHair || 'Ninguno';

  const isFemale = gender === 'Mujer';
  const isGothicLord = outerGarment.includes('Frac Gótico') || headwear.includes('Chistera');
  const isKnight = outerGarment.includes('Placas') || innerGarment.includes('Malla');
  const isGown = outerGarment.includes('Vestido') || innerGarment.includes('Corsé');
  const isFurCloak = outerGarment.includes('Pieles') || outerGarment.includes('Invierno');

  // Height & scale adjustments
  const bodyHeight = build === 'Petite' ? 0.88 : build === 'Heavy' ? 1.05 : 1.0;
  const shoulderWidth = isFemale ? 56 : build === 'Heavy' ? 78 : 68;
  const hipWidth = isFemale ? 64 : 54;
  const waistWidth = isFemale ? 42 : 50;

  // Render SVG layers
  return `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 680" width="100%" height="100%" class="select-none">
  <defs>
    <!-- Soft shadow filter -->
    <filter id="charDropShadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="8" stdDeviation="6" flood-color="#000" flood-opacity="0.35" />
    </filter>
    <filter id="goldGlow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="1" stdDeviation="2" flood-color="#D4AF37" flood-opacity="0.6" />
    </filter>

    <!-- Gradients -->
    <linearGradient id="charGroundShadow" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stopColor="#000000" stopOpacity="0.45" />
      <stop offset="100%" stopColor="#000000" stopOpacity="0" />
    </linearGradient>

    <!-- Tailcoat black fabric with subtle sheen -->
    <linearGradient id="gothicFabric" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stopColor="#25272F" />
      <stop offset="50%" stopColor="#181A20" />
      <stop offset="100%" stopColor="#0D0E12" />
    </linearGradient>

    <!-- Purple inner silk lining -->
    <linearGradient id="purpleSilkLining" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stopColor="#4A2552" />
      <stop offset="100%" stopColor="#28132D" />
    </linearGradient>

    <!-- Gold embroidery gradient -->
    <linearGradient id="goldFiligree" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stopColor="#F9E29C" />
      <stop offset="50%" stopColor="#D4AF37" />
      <stop offset="100%" stopColor="#9C761D" />
    </linearGradient>

    <!-- Knight steel armor gradient -->
    <linearGradient id="steelArmor" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stopColor="#A6B0BC" />
      <stop offset="50%" stopColor="#6C7785" />
      <stop offset="100%" stopColor="#444C56" />
    </linearGradient>

    <!-- Royal Gown Ivory White -->
    <linearGradient id="royalIvory" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stopColor="#FFFFFF" />
      <stop offset="60%" stopColor="#EDE8E1" />
      <stop offset="100%" stopColor="#D5CDC2" />
    </linearGradient>

    <!-- Fur mantle gradient -->
    <linearGradient id="furMantle" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stopColor="#2D2F38" />
      <stop offset="100%" stopColor="#14151B" />
    </linearGradient>
  </defs>

  <!-- 1. BASE GROUND SHADOW -->
  ${
    options.showShadow !== false
      ? `<ellipse cx="200" cy="640" rx="90" ry="18" fill="url(#charGroundShadow)" />`
      : ''
  }

  <g id="character-sprite-root" filter="url(#charDropShadow)" transform="scale(1, ${bodyHeight}) translate(0, ${
    (1 - bodyHeight) * 320
  })">

    <!-- 2. BACK CAPE / BACK COAT TAILS (z=1) -->
    ${
      isGothicLord
        ? `
      <!-- Gothic Tailcoat Long Back Skirts with Purple Inner Flaps (Like in reference image 6) -->
      <!-- Left Back Tail -->
      <path d="M 172 370 Q 140 460 110 575 Q 145 565 178 480 Q 182 410 180 370 Z" fill="url(#purpleSilkLining)" />
      <path d="M 166 370 Q 130 465 98 580 Q 140 570 174 482 Q 180 410 178 370 Z" fill="url(#gothicFabric)" stroke="#0B0C10" stroke-width="1.5" />
      <path d="M 100 580 Q 138 570 172 485" stroke="url(#goldFiligree)" stroke-width="2" fill="none" />

      <!-- Right Back Tail -->
      <path d="M 228 370 Q 260 460 290 575 Q 255 565 222 480 Q 218 410 220 370 Z" fill="url(#purpleSilkLining)" />
      <path d="M 234 370 Q 270 465 302 580 Q 260 570 226 482 Q 220 410 222 370 Z" fill="url(#gothicFabric)" stroke="#0B0C10" stroke-width="1.5" />
      <path d="M 300 580 Q 262 570 228 485" stroke="url(#goldFiligree)" stroke-width="2" fill="none" />
    `
        : ''
    }

    ${
      isFurCloak
        ? `
      <!-- Jon Snow Heavy Back Fur Mantle -->
      <path d="M 140 180 Q 110 320 115 570 Q 200 590 285 570 Q 290 320 260 180 Z" fill="url(#furMantle)" stroke="#0E0F14" stroke-width="2" />
    `
        : ''
    }

    ${
      isGown
        ? `
      <!-- Regal Flowing Gown Back Train -->
      <path d="M 165 340 Q 115 480 80 625 Q 200 645 320 625 Q 285 480 235 340 Z" fill="url(#royalIvory)" stroke="#D5CDC2" stroke-width="1.5" />
    `
        : ''
    }

    <!-- 3. BACK HAIR (z=2) -->
    ${
      hairStyle.includes('Larga') || hairStyle.includes('Gótica')
        ? `
      <!-- Long Raven Locks Cascading Behind Shoulders (Image 6 style) -->
      <path d="M 160 120 Q 135 220 145 340 Q 170 310 178 240 Q 165 180 170 140 Z" fill="${hair.dark}" />
      <path d="M 240 120 Q 265 220 255 340 Q 230 310 222 240 Q 235 180 230 140 Z" fill="${hair.dark}" />
      <path d="M 155 120 Q 130 250 140 370 Q 160 350 168 280 Z" fill="${hair.main}" />
      <path d="M 245 120 Q 270 250 260 370 Q 240 350 232 280 Z" fill="${hair.main}" />
    `
        : ''
    }

    <!-- 4. LEGS & LOWER GARMENTS (z=3) -->
    <!-- Left Leg -->
    <g id="left-leg">
      <!-- Thigh -->
      <path d="M 174 380 L 160 480 L 188 480 L 198 380 Z" fill="#15171E" stroke="#0E0F14" stroke-width="1" />
      <!-- High Riding Boot with Gold Buckles and Accents (Image 6) -->
      ${
        footwear.includes('Botas') || footwear.includes('Ribete')
          ? `
        <path d="M 158 475 L 148 560 L 138 610 L 130 626 L 175 626 L 180 575 L 190 475 Z" fill="#121319" stroke="#090A0D" stroke-width="1.5" />
        <!-- Gold knee-high top trim and filigree -->
        <path d="M 158 478 L 190 478 L 184 494 L 164 494 Z" fill="url(#goldFiligree)" />
        <path d="M 174 494 L 174 550" stroke="url(#goldFiligree)" stroke-width="2" />
        <path d="M 164 545 L 184 545" stroke="url(#goldFiligree)" stroke-width="1.5" />
        <!-- Heel / Sole -->
        <path d="M 130 626 L 132 633 L 173 633 L 175 626 Z" fill="#3B2616" />
      `
          : `
        <path d="M 158 475 L 152 560 L 142 615 L 136 626 L 175 626 L 182 575 L 190 475 Z" fill="#3A3D46" stroke="#23262E" stroke-width="1.5" />
      `
      }
    </g>

    <!-- Right Leg -->
    <g id="right-leg">
      <!-- Thigh -->
      <path d="M 202 380 L 212 480 L 240 480 L 226 380 Z" fill="#15171E" stroke="#0E0F14" stroke-width="1" />
      <!-- High Riding Boot with Gold Buckles and Accents (Image 6) -->
      ${
        footwear.includes('Botas') || footwear.includes('Ribete')
          ? `
        <path d="M 210 475 L 220 575 L 225 626 L 270 626 L 262 610 L 252 560 L 242 475 Z" fill="#121319" stroke="#090A0D" stroke-width="1.5" />
        <!-- Gold knee-high top trim and filigree -->
        <path d="M 210 478 L 242 478 L 236 494 L 216 494 Z" fill="url(#goldFiligree)" />
        <path d="M 226 494 L 226 550" stroke="url(#goldFiligree)" stroke-width="2" />
        <path d="M 216 545 L 236 545" stroke="url(#goldFiligree)" stroke-width="1.5" />
        <!-- Heel / Sole -->
        <path d="M 225 626 L 227 633 L 268 633 L 270 626 Z" fill="#3B2616" />
      `
          : `
        <path d="M 210 475 L 218 575 L 225 626 L 264 626 L 258 615 L 248 560 L 242 475 Z" fill="#3A3D46" stroke="#23262E" stroke-width="1.5" />
      `
      }
    </g>

    <!-- 5. TORSO INNER / SHIRT & WAISTCOAT (z=4) -->
    <!-- Torso base silhouette -->
    <path d="M 160 180 L 172 380 L 228 380 L 240 180 Z" fill="#1B1D24" />

    ${
      innerGarment.includes('Chorrera') || isGothicLord
        ? `
      <!-- Gothic Aristocrat Ruffled Lace Cravat / Jabot (Exact image 6 style) -->
      <path d="M 188 165 L 175 220 L 180 270 L 200 290 L 220 270 L 225 220 L 212 165 Z" fill="#FFFFFF" stroke="#D1D5DB" stroke-width="1" />
      <!-- Lace pleats/ruffles layers -->
      <path d="M 180 180 C 190 190, 210 190, 220 180" stroke="#CBD5E1" stroke-width="1.5" fill="none" />
      <path d="M 175 205 C 190 220, 210 220, 225 205" stroke="#CBD5E1" stroke-width="1.5" fill="none" />
      <path d="M 178 235 C 190 250, 210 250, 222 235" stroke="#CBD5E1" stroke-width="1.5" fill="none" />
      <path d="M 185 265 C 195 275, 205 275, 215 265" stroke="#CBD5E1" stroke-width="1.5" fill="none" />
      <!-- Gold Brooch at collar -->
      <circle cx="200" cy="172" r="4.5" fill="url(#goldFiligree)" />
      <circle cx="200" cy="172" r="2" fill="#8B0000" />
    `
        : innerGarment.includes('Malla')
        ? `
      <!-- Chainmail Hauberk -->
      <path d="M 165 180 L 174 370 L 226 370 L 235 180 Z" fill="#4B5563" />
      <!-- Chainmail rings texture -->
      <line x1="170" y1="200" x2="230" y2="200" stroke="#9CA3AF" stroke-dasharray="3,3" stroke-width="1.5" />
      <line x1="170" y1="220" x2="230" y2="220" stroke="#9CA3AF" stroke-dasharray="3,3" stroke-width="1.5" />
      <line x1="172" y1="240" x2="228" y2="240" stroke="#9CA3AF" stroke-dasharray="3,3" stroke-width="1.5" />
      <line x1="174" y1="260" x2="226" y2="260" stroke="#9CA3AF" stroke-dasharray="3,3" stroke-width="1.5" />
    `
        : `
      <!-- Clean Linen Tunic -->
      <path d="M 168 180 L 175 370 L 225 370 L 232 180 Z" fill="#D2C8BA" stroke="#A89F91" stroke-width="1" />
    `
    }

    <!-- 6. OUTERWEAR / GOTHIC TAILCOAT / ARMOR (z=5) -->
    ${
      isGothicLord
        ? `
      <!-- Double-Breasted Tailcoat Front Panels & Lapels with Golden Filigree (Image 6) -->
      <!-- Left Coat Panel -->
      <path d="M 152 185 L 168 280 L 175 385 L 195 385 L 188 280 L 172 185 Z" fill="url(#gothicFabric)" stroke="#090A0D" stroke-width="1.5" />
      <!-- Right Coat Panel (Overlapping Double-Breasted with Gold Buttons) -->
      <path d="M 248 185 L 232 280 L 225 385 L 205 385 L 212 280 L 228 185 Z" fill="url(#gothicFabric)" stroke="#090A0D" stroke-width="1.5" />

      <!-- Ornate Gold Filigree on Lapels & Chest -->
      <path d="M 154 190 Q 170 230 178 300 L 180 375" stroke="url(#goldFiligree)" stroke-width="2" fill="none" />
      <path d="M 246 190 Q 230 230 222 300 L 220 375" stroke="url(#goldFiligree)" stroke-width="2" fill="none" />

      <!-- Gold Double-Breasted Military/Aristocrat Buttons -->
      <circle cx="188" cy="285" r="3" fill="url(#goldFiligree)" />
      <circle cx="212" cy="285" r="3" fill="url(#goldFiligree)" />
      <circle cx="186" cy="310" r="3" fill="url(#goldFiligree)" />
      <circle cx="214" cy="310" r="3" fill="url(#goldFiligree)" />
      <circle cx="184" cy="335" r="3" fill="url(#goldFiligree)" />
      <circle cx="216" cy="335" r="3" fill="url(#goldFiligree)" />

      <!-- Ornate Gold Epaulettes on Shoulders -->
      <g id="epaulette-left">
        <path d="M 146 182 Q 160 176 174 186 L 170 196 Q 158 188 144 194 Z" fill="url(#goldFiligree)" />
        <line x1="148" y1="194" x2="146" y2="204" stroke="url(#goldFiligree)" stroke-width="1.5" />
        <line x1="154" y1="194" x2="152" y2="204" stroke="url(#goldFiligree)" stroke-width="1.5" />
        <line x1="160" y1="194" x2="158" y2="204" stroke="url(#goldFiligree)" stroke-width="1.5" />
      </g>
      <g id="epaulette-right">
        <path d="M 254 182 Q 240 176 226 186 L 230 196 Q 242 188 256 194 Z" fill="url(#goldFiligree)" />
        <line x1="252" y1="194" x2="254" y2="204" stroke="url(#goldFiligree)" stroke-width="1.5" />
        <line x1="246" y1="194" x2="248" y2="204" stroke="url(#goldFiligree)" stroke-width="1.5" />
        <line x1="240" y1="194" x2="242" y2="204" stroke="url(#goldFiligree)" stroke-width="1.5" />
      </g>
    `
        : isKnight
        ? `
      <!-- Full Steel Cuirass with Brass Rivets & Pauldrons -->
      <path d="M 156 185 Q 200 175 244 185 L 235 340 L 165 340 Z" fill="url(#steelArmor)" stroke="#2D3748" stroke-width="2" />
      <!-- Center Breastplate Ridge -->
      <line x1="200" y1="182" x2="200" y2="340" stroke="#CBD5E1" stroke-width="2" />
      <!-- Knight Pauldrons -->
      <path d="M 140 180 Q 155 168 172 182 L 166 215 Q 148 210 136 198 Z" fill="url(#steelArmor)" stroke="#1F2937" stroke-width="1.5" />
      <path d="M 260 180 Q 245 168 228 182 L 234 215 Q 252 210 264 198 Z" fill="url(#steelArmor)" stroke="#1F2937" stroke-width="1.5" />
    `
        : isFurCloak
        ? `
      <!-- Jon Snow Heavy Black Fur Collar / Brigandine -->
      <path d="M 148 180 Q 200 160 252 180 L 245 280 Q 200 295 155 280 Z" fill="#20222A" stroke="#121318" stroke-width="2" />
      <path d="M 140 170 Q 200 190 260 170 Q 275 210 250 225 Q 200 215 150 225 Q 125 210 140 170 Z" fill="url(#furMantle)" />
      <!-- Crossed Leather Belts -->
      <line x1="160" y1="205" x2="240" y2="270" stroke="#5A3A22" stroke-width="5" />
      <line x1="240" y1="205" x2="160" y2="270" stroke="#5A3A22" stroke-width="5" />
    `
        : `
      <!-- Noble Doublet with Belt -->
      <path d="M 158 185 L 168 350 L 232 350 L 242 185 Z" fill="#31221D" stroke="#1D1411" stroke-width="1.5" />
    `
    }

    <!-- 7. ARMS & SLEEVES (z=6) -->
    <!-- Left Arm -->
    <g id="left-arm">
      <path d="M 152 188 L 132 280 L 126 360 L 142 360 L 152 285 L 165 195 Z" fill="url(#gothicFabric)" stroke="#090A0D" stroke-width="1.2" />
      ${
        isGothicLord
          ? `
        <!-- White Ruffled Frill Cuff at Wrist (Image 6) -->
        <path d="M 122 350 Q 134 345 146 350 L 148 368 Q 134 372 120 368 Z" fill="#FFFFFF" stroke="#CBD5E1" stroke-width="1" />
        <path d="M 122 368 L 118 362 Q 134 358 148 362 L 146 368" stroke="url(#goldFiligree)" stroke-width="1.5" fill="none" />
        <!-- Black Leather Glove -->
        <path d="M 124 365 L 120 405 L 140 405 L 144 365 Z" fill="#15171F" stroke="#0A0B0E" stroke-width="1" />
      `
          : `
        <!-- Plain Glove / Hand -->
        <path d="M 124 360 L 120 398 L 138 398 L 142 360 Z" fill="${skin.base}" stroke="${skin.shadow}" stroke-width="1" />
      `
      }
    </g>

    <!-- Right Arm -->
    <g id="right-arm">
      <path d="M 248 188 L 268 280 L 274 360 L 258 360 L 248 285 L 235 195 Z" fill="url(#gothicFabric)" stroke="#090A0D" stroke-width="1.2" />
      ${
        isGothicLord
          ? `
        <!-- White Ruffled Frill Cuff at Wrist (Image 6) -->
        <path d="M 278 350 Q 266 345 254 350 L 252 368 Q 266 372 280 368 Z" fill="#FFFFFF" stroke="#CBD5E1" stroke-width="1" />
        <path d="M 278 368 L 282 362 Q 266 358 252 362 L 254 368" stroke="url(#goldFiligree)" stroke-width="1.5" fill="none" />
        <!-- Black Leather Glove -->
        <path d="M 276 365 L 280 405 L 260 405 L 256 365 Z" fill="#15171F" stroke="#0A0B0E" stroke-width="1" />
      `
          : `
        <!-- Plain Glove / Hand -->
        <path d="M 276 360 L 280 398 L 262 398 L 258 360 Z" fill="${skin.base}" stroke="${skin.shadow}" stroke-width="1" />
      `
      }
    </g>

    <!-- 8. NECK & HEAD (z=7) -->
    <!-- Neck -->
    <path d="M 190 145 L 188 175 L 212 175 L 210 145 Z" fill="${skin.base}" stroke="${skin.shadow}" stroke-width="1" />

    <!-- Head / Face Silhouette -->
    <g id="head-group">
      <!-- Head shape -->
      <path d="M 180 95 Q 170 125 178 145 Q 200 165 222 145 Q 230 125 220 95 Q 200 85 180 95 Z" fill="${skin.base}" stroke="${skin.shadow}" stroke-width="1.2" />

      <!-- Vampiric / Aristocratic Cheek Blush & Shadow -->
      <ellipse cx="182" cy="132" rx="6" ry="3" fill="${skin.blush}" opacity="0.35" />
      <ellipse cx="218" cy="132" rx="6" ry="3" fill="${skin.blush}" opacity="0.35" />

      <!-- Eyes (Crimson / Gothic Pierce) -->
      <g id="eyes">
        <!-- Left Eye -->
        <path d="M 182 118 Q 189 114 195 118 Q 189 122 182 118 Z" fill="#FFFFFF" stroke="#2B2D38" stroke-width="0.8" />
        <circle cx="189" cy="118" r="2.4" fill="${isGothicLord ? '#8B0000' : '#2D3748'}" />
        <circle cx="189" cy="118" r="1.1" fill="#000000" />
        <circle cx="190" cy="117" r="0.6" fill="#FFFFFF" />
        <!-- Brow -->
        <path d="M 180 113 Q 188 111 196 114" stroke="${hair.main}" stroke-width="1.6" fill="none" stroke-linecap="round" />

        <!-- Right Eye -->
        <path d="M 205 118 Q 211 114 218 118 Q 211 122 205 118 Z" fill="#FFFFFF" stroke="#2B2D38" stroke-width="0.8" />
        <circle cx="211" cy="118" r="2.4" fill="${isGothicLord ? '#8B0000' : '#2D3748'}" />
        <circle cx="211" cy="118" r="1.1" fill="#000000" />
        <circle cx="212" cy="117" r="0.6" fill="#FFFFFF" />
        <!-- Brow -->
        <path d="M 204 114 Q 212 111 220 113" stroke="${hair.main}" stroke-width="1.6" fill="none" stroke-linecap="round" />
      </g>

      <!-- Nose -->
      <path d="M 200 118 L 198 130 L 202 131" stroke="${skin.shadow}" stroke-width="1.2" fill="none" stroke-linecap="round" />

      <!-- Lips / Mouth (Crimson Gothic Lips) -->
      <path d="M 193 140 Q 200 138 207 140 Q 200 144 193 140 Z" fill="${isGothicLord ? '#7D1A1A' : skin.blush}" stroke="${skin.shadow}" stroke-width="0.8" />

      <!-- Facial marks (if any) -->
      ${
        options.facialMarks?.includes('Lágrima Gótica')
          ? `
        <path d="M 189 123 Q 188 130 189 135" stroke="#7D1A1A" stroke-width="1.2" fill="none" stroke-linecap="round" />
      `
          : ''
      }
    </g>

    <!-- 9. FRONT HAIR (z=8) -->
    <g id="front-hair">
      ${
        hairStyle.includes('Larga') || hairStyle.includes('Gótica')
          ? `
        <!-- Gothic Parted Long Dark Bangs & Framing Locks (Image 6) -->
        <path d="M 172 95 Q 166 120 168 150 Q 174 140 178 120 Z" fill="${hair.main}" />
        <path d="M 228 95 Q 234 120 232 150 Q 226 140 222 120 Z" fill="${hair.main}" />
        <!-- Center Part -->
        <path d="M 175 92 Q 192 105 186 116 Q 190 102 198 90 Z" fill="${hair.dark}" />
        <path d="M 225 92 Q 208 105 214 116 Q 210 102 202 90 Z" fill="${hair.dark}" />
      `
          : `
        <!-- Short Neat Parted Hair -->
        <path d="M 172 95 Q 190 85 228 95 Q 225 105 215 110 Q 200 100 185 110 Z" fill="${hair.main}" />
      `
      }
    </g>

    <!-- 10. HEADWEAR: GOTHIC TOP HAT / CROWN (z=9) -->
    ${
      headwear.includes('Chistera')
        ? `
      <!-- Gothic Aristocrat Top Hat with Gold Ornament & Band (Exact Image 6) -->
      <g id="gothic-top-hat" filter="url(#goldGlow)">
        <!-- Curved Hat Brim -->
        <path d="M 148 94 Q 200 80 252 94 Q 256 102 248 102 Q 200 92 152 102 Q 144 102 148 94 Z" fill="#14151B" stroke="#0A0B0E" stroke-width="1.5" />
        <!-- Hat Crown Body (Tall & slightly flared) -->
        <path d="M 162 90 L 158 20 Q 200 15 242 20 L 238 90 Q 200 82 162 90 Z" fill="url(#gothicFabric)" stroke="#0A0B0E" stroke-width="1.8" />
        <!-- Hat Silk Ribbon Band -->
        <path d="M 163 88 L 162 76 Q 200 70 238 76 L 237 88 Q 200 80 163 88 Z" fill="#252733" />
        <!-- Ornate Gold Filigree Emblem / Crest Center Front -->
        <path d="M 200 60 L 194 72 L 200 80 L 206 72 Z" fill="url(#goldFiligree)" />
        <path d="M 190 74 Q 200 68 210 74" stroke="url(#goldFiligree)" stroke-width="2" fill="none" />
        <circle cx="200" cy="72" r="2" fill="#8B0000" />
      </g>
    `
        : headwear.includes('Corona')
        ? `
      <!-- Royal Gold Circlet / Crown -->
      <path d="M 172 90 L 176 72 L 186 82 L 200 65 L 214 82 L 224 72 L 228 90 Q 200 84 172 90 Z" fill="url(#goldFiligree)" stroke="#785913" stroke-width="1" />
    `
        : ''
    }

    <!-- 11. WEAPONS / HANDHELD PROPS (z=10) -->
    ${
      handheld.includes('Espadón')
        ? `
      <!-- Greatsword / Bastard Broadsword Resting in Front -->
      <g id="weapon-sword" transform="translate(198, 260)">
        <!-- Blade -->
        <polygon points="-5,40 0,340 5,40" fill="url(#steelArmor)" stroke="#1F2937" stroke-width="1" />
        <!-- Fuller line -->
        <line x1="0" y1="45" x2="0" y2="300" stroke="#E2E8F0" stroke-width="1.2" />
        <!-- Crossguard with Wolf Pommel -->
        <rect x="-26" y="32" width="52" height="7" rx="2" fill="url(#goldFiligree)" stroke="#785913" stroke-width="1" />
        <!-- Grip -->
        <rect x="-3.5" y="0" width="7" height="32" fill="#3E2723" />
        <!-- Pommel -->
        <circle cx="0" cy="-3" r="6" fill="url(#goldFiligree)" />
      </g>
    `
        : handheld.includes('Cáliz')
        ? `
      <!-- Tyrion Golden Wine Goblet -->
      <g id="goblet" transform="translate(118, 380)">
        <path d="M -8,0 Q 0,14 8,0 L 4,14 L 6,24 L -6,24 L -4,14 Z" fill="url(#goldFiligree)" stroke="#785913" stroke-width="1" />
        <ellipse cx="0" cy="0" rx="8" ry="3" fill="#8B0000" />
      </g>
    `
        : handheld.includes('Bastón')
        ? `
      <!-- Gentleman Walking Cane with Gold Head -->
      <g id="cane" transform="translate(278, 395)">
        <line x1="0" y1="0" x2="10" y2="235" stroke="#2B1810" stroke-width="4.5" stroke-linecap="round" />
        <circle cx="0" cy="0" r="7" fill="url(#goldFiligree)" />
        <path d="M 0,-4 Q 6,-10 12,-4" stroke="url(#goldFiligree)" stroke-width="3" fill="none" />
      </g>
    `
        : ''
    }

  </g>
</svg>
  `.trim();
}

export const generateCharacterSpriteSvg = generateCharacterSvg;

/**
 * =====================================================================
 * 2. ISOMETRIC ROOM & SCENARIO DETERMINISTIC SVG GENERATOR
 * Generates rich isometric interiors matching images 1, 4, and 5:
 * - Room with Parquet/Carpet floor and Left/Right corner walls
 * - Billiard Table, Ping Pong Table, Arcade Machines, Air Hockey, Foosball, Chess Table
 * - Sofas, Coffee Tables, Vending Machines, Water Coolers, Desk Cubicles
 * - Hotel Bedroom Beds, Wardrobes, Maid & Player Sprites
 * =====================================================================
 */
export function generateIsometricRoomSvg(options: IsometricRoomOptions = {}): string {
  const gridSize = options.gridSize || 10;
  const tileWidth = 56;
  const tileHeight = 28;
  const originX = 520;
  const originY = 220;

  // Convert (gx, gy) to 2D screen coords
  const toScreen = (gx: number, gy: number, gz: number = 0) => {
    const sx = originX + (gx - gy) * (tileWidth / 2);
    const sy = originY + (gx + gy) * (tileHeight / 2) - gz;
    return { sx, sy };
  };

  // Floor styles
  const floor = options.floorStyle || 'gaming_carpet';
  const wallLeft = options.wallLeftStyle || 'deep_blue_game';
  const wallRight = options.wallRightStyle || 'deep_blue_game';

  // Floor tile colors
  let tileFill1 = '#1C212E';
  let tileFill2 = '#141822';
  let tileBorder = '#2B3347';

  if (floor === 'wood_parquet') {
    tileFill1 = '#B5885C';
    tileFill2 = '#9E744A';
    tileBorder = '#7D5834';
  } else if (floor === 'purple_bedroom_carpet') {
    tileFill1 = '#6E5577';
    tileFill2 = '#5C4465';
    tileBorder = '#4A3452';
  } else if (floor === 'marble_checker') {
    tileFill1 = '#E5E7EB';
    tileFill2 = '#1F2937';
    tileBorder = '#6B7280';
  } else if (floor === 'office_industrial') {
    tileFill1 = '#4B5563';
    tileFill2 = '#374151';
    tileBorder = '#1F2937';
  }

  // Wall colors
  const wallColors: Record<string, { main: string; shade: string; trim: string }> = {
    lilac_hotel: { main: '#E2D4E8', shade: '#C8B5D1', trim: '#FFFFFF' },
    brick_office: { main: '#C4623D', shade: '#A84E2B', trim: '#F3F4F6' },
    deep_blue_game: { main: '#2A3047', shade: '#1D2233', trim: '#D4AF37' },
    warm_wood: { main: '#7D5638', shade: '#634228', trim: '#FBE4C4' },
    glass_office: { main: '#6B90B2', shade: '#4E7394', trim: '#E2E8F0' }
  };

  const leftWallCol = wallColors[wallLeft] || wallColors.deep_blue_game;
  const rightWallCol = wallColors[wallRight] || wallColors.deep_blue_game;

  // Render floor polygons
  let floorSvg = '';
  for (let gy = 0; gy < gridSize; gy++) {
    for (let gx = 0; gx < gridSize; gx++) {
      const { sx, sy } = toScreen(gx, gy);
      const isAlt = (gx + gy) % 2 === 0;
      const fill = isAlt ? tileFill1 : tileFill2;
      const p = `${sx},${sy} ${sx + tileWidth / 2},${sy + tileHeight / 2} ${sx},${sy + tileHeight} ${sx - tileWidth / 2},${sy + tileHeight / 2}`;
      floorSvg += `<polygon points="${p}" fill="${fill}" stroke="${tileBorder}" stroke-width="0.8" />`;
    }
  }

  // Corner walls calculations
  const wallHeight = 190;
  const backCorner = toScreen(0, 0);
  const leftCorner = toScreen(gridSize, 0);
  const rightCorner = toScreen(0, gridSize);
  const bottomCorner = toScreen(gridSize, gridSize);

  // Default props if none provided: generate rich game room or bedroom
  const props: IsometricProp[] = options.props || [
    { id: 'p1', type: 'billiard_table', x: 2, y: 5 },
    { id: 'p2', type: 'ping_pong_table', x: 5, y: 2 },
    { id: 'p3', type: 'arcade_cabinet', x: 0, y: 1 },
    { id: 'p4', type: 'arcade_cabinet', x: 0, y: 3 },
    { id: 'p5', type: 'air_hockey', x: 1, y: 8 },
    { id: 'p6', type: 'foosball_table', x: 6, y: 7 },
    { id: 'p7', type: 'sofa_leather', x: 8, y: 3 },
    { id: 'p8', type: 'coffee_table', x: 7, y: 4 },
    { id: 'p9', type: 'chess_table', x: 8, y: 8 },
    { id: 'p10', type: 'potted_palm', x: 0, y: 6 },
    { id: 'p11', type: 'floor_lamp', x: 9, y: 1 }
  ];

  // Render individual isometric props
  const renderProp = (prop: IsometricProp) => {
    const { sx, sy } = toScreen(prop.x, prop.y);

    switch (prop.type) {
      case 'billiard_table':
        // Classic Green Felt Pool Table with Wood Border (Images 1 & 4)
        return `
        <g id="prop-billiard-${prop.id}" transform="translate(${sx}, ${sy})">
          <!-- Drop shadow -->
          <polygon points="0,15 45,38 0,60 -45,38" fill="#000" opacity="0.3" />
          <!-- Table Legs (4 wooden posts) -->
          <rect x="-38" y="18" width="8" height="24" fill="#422513" stroke="#261206" stroke-width="1" />
          <rect x="30" y="18" width="8" height="24" fill="#422513" stroke="#261206" stroke-width="1" />
          <rect x="-6" y="38" width="8" height="20" fill="#2E180A" stroke="#261206" stroke-width="1" />
          <rect x="-6" y="0" width="8" height="20" fill="#5A341C" stroke="#261206" stroke-width="1" />
          <!-- Table Wood Rim Base -->
          <polygon points="0,-12 48,12 0,36 -48,12" fill="#5A341C" stroke="#3D2110" stroke-width="1.5" />
          <polygon points="-48,12 0,36 0,44 -48,20" fill="#3D2110" />
          <polygon points="0,36 48,12 48,20 0,44" fill="#2A160A" />
          <!-- Green Felt Surface -->
          <polygon points="0,-7 42,14 0,31 -42,14" fill="#1B8045" stroke="#125A30" stroke-width="1" />
          <!-- Corner and Side Pockets -->
          <circle cx="0" cy="-7" r="3" fill="#111" />
          <circle cx="42" cy="14" r="3" fill="#111" />
          <circle cx="0" cy="31" r="3" fill="#111" />
          <circle cx="-42" cy="14" r="3" fill="#111" />
          <!-- Pool Balls (White Cue Ball + Color Cluster) -->
          <circle cx="-15" cy="14" r="2.2" fill="#FFFFFF" stroke="#666" stroke-width="0.5" />
          <circle cx="12" cy="12" r="2" fill="#E53935" />
          <circle cx="16" cy="14" r="2" fill="#FDD835" />
          <circle cx="14" cy="16" r="2" fill="#1E88E5" />
          <circle cx="18" cy="16" r="2" fill="#43A047" />
          <!-- Cue Stick Resting -->
          <line x1="-35" y1="6" x2="35" y2="22" stroke="#F5DEB3" stroke-width="1.5" stroke-linecap="round" />
        </g>
        `;

      case 'ping_pong_table':
        // Table Tennis with Net (Image 1)
        return `
        <g id="prop-pingpong-${prop.id}" transform="translate(${sx}, ${sy})">
          <polygon points="0,15 48,39 0,63 -48,39" fill="#000" opacity="0.25" />
          <!-- Metal frame & legs -->
          <line x1="-36" y1="20" x2="-36" y2="44" stroke="#374151" stroke-width="2.5" />
          <line x1="36" y1="20" x2="36" y2="44" stroke="#374151" stroke-width="2.5" />
          <line x1="0" y1="36" x2="0" y2="52" stroke="#1F2937" stroke-width="2.5" />
          <!-- Green Table Top -->
          <polygon points="0,-10 46,13 0,36 -46,13" fill="#2E7D32" stroke="#1B5E20" stroke-width="1.2" />
          <!-- White Center Line and Border -->
          <line x1="0" y1="-10" x2="0" y2="36" stroke="#FFFFFF" stroke-width="1.2" />
          <line x1="-23" y1="1" x2="23" y2="24" stroke="#FFFFFF" stroke-width="1" />
          <!-- White Net with Posts -->
          <polygon points="-24,-1 24,23 24,15 -24,-9" fill="#FFFFFF" fill-opacity="0.75" stroke="#9E9E9E" stroke-width="0.8" />
          <!-- Paddles (Red & Black) -->
          <circle cx="-14" cy="14" r="3" fill="#D32F2F" />
          <circle cx="18" cy="12" r="3" fill="#212121" />
        </g>
        `;

      case 'arcade_cabinet':
        // Retro Arcade Machine with Glowing Marquee & Screen (Image 1)
        return `
        <g id="prop-arcade-${prop.id}" transform="translate(${sx}, ${sy})">
          <!-- Shadow -->
          <polygon points="0,10 18,19 0,28 -18,19" fill="#000" opacity="0.4" />
          <!-- Left side panel -->
          <polygon points="-16,16 0,24 0,-40 -16,-48" fill="#1565C0" stroke="#0D47A1" stroke-width="1" />
          <!-- Right face & screen -->
          <polygon points="0,24 16,16 16,-48 0,-40" fill="#0D47A1" stroke="#0A2C68" stroke-width="1" />
          <!-- Slanted Screen Bezel -->
          <polygon points="0,-12 14,-19 14,-36 0,-29" fill="#111827" />
          <!-- Glowing Video Game Screen -->
          <polygon points="1,-14 13,-20 13,-34 1,-28" fill="#00E5FF" />
          <circle cx="7" cy="-24" r="2" fill="#FFEB3B" />
          <!-- Glowing Marquee Top -->
          <polygon points="0,-38 15,-45 15,-52 0,-45" fill="#FF1744" stroke="#FFF" stroke-width="0.5" />
          <!-- Control Panel with Joystick & Buttons -->
          <polygon points="0,-2 14,-9 14,-16 0,-9" fill="#212121" />
          <circle cx="6" cy="-11" r="1.5" fill="#F44336" />
          <circle cx="10" cy="-13" r="1.2" fill="#FFEB3B" />
        </g>
        `;

      case 'air_hockey':
        // Glossy Air Hockey Table (Image 1)
        return `
        <g id="prop-airhockey-${prop.id}" transform="translate(${sx}, ${sy})">
          <polygon points="0,15 44,37 0,59 -44,37" fill="#000" opacity="0.3" />
          <!-- Base Legs -->
          <rect x="-34" y="16" width="10" height="24" fill="#263238" />
          <rect x="24" y="16" width="10" height="24" fill="#263238" />
          <!-- Black Table Rim -->
          <polygon points="0,-10 44,12 0,34 -44,12" fill="#37474F" stroke="#212121" stroke-width="1.5" />
          <!-- White Playing Surface -->
          <polygon points="0,-6 40,14 0,30 -40,14" fill="#ECEFF1" stroke="#CFD8DC" stroke-width="1" />
          <!-- Red Rink Markings -->
          <ellipse cx="0" cy="14" rx="8" ry="4" stroke="#E53935" stroke-width="1.2" fill="none" />
          <!-- Pucks & Strikers -->
          <circle cx="-16" cy="10" r="3" fill="#D32F2F" />
          <circle cx="16" cy="18" r="3" fill="#1976D2" />
          <circle cx="2" cy="14" r="1.5" fill="#212121" />
        </g>
        `;

      case 'foosball_table':
        // Table Soccer / Foosball (Image 1)
        return `
        <g id="prop-foosball-${prop.id}" transform="translate(${sx}, ${sy})">
          <polygon points="0,15 36,33 0,51 -36,33" fill="#000" opacity="0.3" />
          <!-- Wooden Legs -->
          <rect x="-28" y="16" width="6" height="22" fill="#8D6E63" />
          <rect x="22" y="16" width="6" height="22" fill="#8D6E63" />
          <!-- Wooden Body -->
          <polygon points="0,-8 36,10 0,28 -36,10" fill="#A1887F" stroke="#5D4037" stroke-width="1.5" />
          <!-- Green Field -->
          <polygon points="0,-4 32,12 0,24 -32,12" fill="#43A047" />
          <!-- Chrome Player Rods -->
          <line x1="-28" y1="2" x2="28" y2="20" stroke="#B0BEC5" stroke-width="1.8" />
          <line x1="-20" y1="6" x2="20" y2="16" stroke="#B0BEC5" stroke-width="1.8" />
          <!-- Tiny Players -->
          <circle cx="-10" cy="8" r="1.8" fill="#E53935" />
          <circle cx="10" cy="14" r="1.8" fill="#1E88E5" />
        </g>
        `;

      case 'sofa_leather':
        // Modern White / Gray Leather Sofa (Image 1 & 4)
        return `
        <g id="prop-sofa-${prop.id}" transform="translate(${sx}, ${sy})">
          <polygon points="0,14 46,37 0,60 -46,37" fill="#000" opacity="0.25" />
          <!-- Backrest -->
          <polygon points="-40,-6 0,-26 40,-6 40,6 0,-14 -40,6" fill="#F5F5F5" stroke="#E0E0E0" stroke-width="1" />
          <!-- Seat Cushion -->
          <polygon points="-40,6 0,-14 40,6 0,26" fill="#FFFFFF" stroke="#E0E0E0" stroke-width="1" />
          <!-- Left Armrest -->
          <polygon points="-44,4 -24,-6 -24,8 -44,18" fill="#E0E0E0" stroke="#BDBDBD" stroke-width="1" />
          <!-- Right Armrest -->
          <polygon points="24,-6 44,4 44,18 24,8" fill="#EEEEEE" stroke="#BDBDBD" stroke-width="1" />
          <!-- Front Face Base -->
          <polygon points="-40,6 0,26 0,34 -40,14" fill="#BDBDBD" />
          <polygon points="0,26 40,6 40,14 0,34" fill="#9E9E9E" />
        </g>
        `;

      case 'coffee_table':
        // Sleek Coffee Table with Laptops & Coffee Cup (Image 1)
        return `
        <g id="prop-coffee-${prop.id}" transform="translate(${sx}, ${sy})">
          <polygon points="0,10 28,24 0,38 -28,24" fill="#000" opacity="0.2" />
          <!-- Chrome Legs -->
          <line x1="-22" y1="12" x2="-22" y2="24" stroke="#9E9E9E" stroke-width="1.5" />
          <line x1="22" y1="12" x2="22" y2="24" stroke="#9E9E9E" stroke-width="1.5" />
          <!-- White Table Surface -->
          <polygon points="0,0 26,13 0,26 -26,13" fill="#FFFFFF" stroke="#E0E0E0" stroke-width="1.2" />
          <!-- Laptop open -->
          <polygon points="-12,8 -4,4 4,8 -4,12" fill="#37474F" />
          <polygon points="-4,4 4,8 4,1 -4,-3" fill="#90CAF9" />
          <!-- Coffee Cup -->
          <circle cx="10" cy="14" r="2.5" fill="#D32F2F" />
          <circle cx="10" cy="14" r="1.5" fill="#3E2723" />
        </g>
        `;

      case 'chess_table':
        // Chess Table with White Modern Chairs (Image 1)
        return `
        <g id="prop-chess-${prop.id}" transform="translate(${sx}, ${sy})">
          <polygon points="0,10 24,22 0,34 -24,22" fill="#000" opacity="0.25" />
          <!-- Table Post & Base -->
          <rect x="-3" y="10" width="6" height="14" fill="#212121" />
          <!-- Dark Wood Square Table -->
          <polygon points="0,-4 22,7 0,18 -22,7" fill="#3E2723" stroke="#1B0000" stroke-width="1.2" />
          <!-- Checkerboard Top -->
          <polygon points="0,-1 16,7 0,15 -16,7" fill="#D7CCC8" stroke="#5D4037" stroke-width="0.8" />
          <!-- Left White Chair -->
          <polygon points="-30,6 -20,1 -20,15 -30,20" fill="#FFFFFF" stroke="#E0E0E0" stroke-width="1" />
          <line x1="-30" y1="20" x2="-30" y2="28" stroke="#424242" stroke-width="1.5" />
          <!-- Right White Chair -->
          <polygon points="20,1 30,6 30,20 20,15" fill="#FAFAFA" stroke="#E0E0E0" stroke-width="1" />
          <line x1="30" y1="20" x2="30" y2="28" stroke="#424242" stroke-width="1.5" />
        </g>
        `;

      case 'vending_machine':
        // Coffee / Snack Vending Machine (Image 4)
        return `
        <g id="prop-vending-${prop.id}" transform="translate(${sx}, ${sy})">
          <polygon points="0,12 18,21 0,30 -18,21" fill="#000" opacity="0.35" />
          <!-- Left side dark panel -->
          <polygon points="-16,14 0,22 0,-54 -16,-62" fill="#2D2B28" stroke="#1A1917" stroke-width="1" />
          <!-- Front face (Glass display & selection panel) -->
          <polygon points="0,22 18,13 18,-63 0,-54" fill="#423E3B" stroke="#1A1917" stroke-width="1" />
          <!-- Illuminated Menu Header -->
          <polygon points="1,-40 16,-47 16,-58 1,-50" fill="#C99757" />
          <circle cx="8" cy="-48" r="3" fill="#FFF" />
          <!-- Dispenser Slot Window -->
          <polygon points="2,14 15,8 15,-6 2,0" fill="#1C1B19" />
          <rect x="5" y="4" width="6" height="4" fill="#FFF" opacity="0.8" />
        </g>
        `;

      case 'water_cooler':
        // Modern Water Dispenser with Blue Bottle (Image 4)
        return `
        <g id="prop-water-${prop.id}" transform="translate(${sx}, ${sy})">
          <polygon points="0,8 10,13 0,18 -10,13" fill="#000" opacity="0.3" />
          <!-- White Stand Base -->
          <polygon points="-8,10 0,14 0,-18 -8,-22" fill="#E0E0E0" />
          <polygon points="0,14 8,10 8,-22 0,-18" fill="#FFFFFF" stroke="#BDBDBD" stroke-width="1" />
          <!-- Blue Water Bottle on Top -->
          <cylinder />
          <path d="M -5,-22 L 5,-22 L 5,-40 Q 0,-44 -5,-40 Z" fill="#29B6F6" fill-opacity="0.8" stroke="#0288D1" stroke-width="1" />
          <!-- Water level line -->
          <ellipse cx="0" cy="-32" rx="4" ry="1.5" fill="#B3E5FC" />
        </g>
        `;

      case 'twin_bed':
        // Hotel Double Bed with Pillows & Duvet (Image 5)
        return `
        <g id="prop-bed-${prop.id}" transform="translate(${sx}, ${sy})">
          <polygon points="0,18 42,39 0,60 -42,39" fill="#000" opacity="0.3" />
          <!-- Wooden Headboard -->
          <polygon points="-40,-4 -10,-19 -10,8 -40,23" fill="#5D4037" stroke="#3E2723" stroke-width="1.2" />
          <!-- Mattress with Navy / Royal Blue Blanket -->
          <polygon points="-36,18 -8,4 34,25 6,39" fill="#1565C0" stroke="#0D47A1" stroke-width="1" />
          <!-- White Folded Top Sheet -->
          <polygon points="-30,15 -4,2 6,7 -20,20" fill="#FFFFFF" />
          <!-- White Plush Pillows -->
          <polygon points="-32,10 -18,3 -12,6 -26,13" fill="#FAFAFA" stroke="#E0E0E0" stroke-width="1" />
          <polygon points="-22,5 -8,-2 -2,1 -16,8" fill="#FAFAFA" stroke="#E0E0E0" stroke-width="1" />
        </g>
        `;

      case 'wardrobe':
        // Tall Double-Door Bedroom Wardrobe (Image 5)
        return `
        <g id="prop-wardrobe-${prop.id}" transform="translate(${sx}, ${sy})">
          <polygon points="0,14 24,26 0,38 -24,26" fill="#000" opacity="0.35" />
          <!-- Left side wall -->
          <polygon points="-22,20 0,31 0,-60 -22,-71" fill="#4E342E" stroke="#3E2723" stroke-width="1.2" />
          <!-- Right side doors with handles -->
          <polygon points="0,31 22,20 22,-71 0,-60" fill="#6D4C41" stroke="#3E2723" stroke-width="1.2" />
          <!-- Center split & brass handles -->
          <line x1="11" y1="25" x2="11" y2="-65" stroke="#3E2723" stroke-width="1" />
          <circle cx="8" cy="-15" r="1.5" fill="#FFD54F" />
          <circle cx="14" cy="-15" r="1.5" fill="#FFD54F" />
        </g>
        `;

      case 'potted_palm':
        // Lush Indoor Palm / Monstera in Ceramic Pot (Image 1 & 5)
        return `
        <g id="prop-palm-${prop.id}" transform="translate(${sx}, ${sy})">
          <ellipse cx="0" cy="12" rx="10" ry="5" fill="#000" opacity="0.3" />
          <!-- Red / White Ceramic Pot -->
          <polygon points="-8,8 0,12 8,8 6,-4 0,-2 -6,-4" fill="#C62828" stroke="#B71C1C" stroke-width="1" />
          <!-- Rich Green Palm Fronds Radiating Out -->
          <path d="M 0,-4 Q -18,-24 -30,-18 Q -16,-10 0,-4" fill="#2E7D32" stroke="#1B5E20" stroke-width="0.8" />
          <path d="M 0,-4 Q 18,-24 30,-18 Q 16,-10 0,-4" fill="#388E3C" stroke="#1B5E20" stroke-width="0.8" />
          <path d="M 0,-4 Q -10,-36 -6,-42 Q -2,-26 0,-4" fill="#43A047" stroke="#1B5E20" stroke-width="0.8" />
          <path d="M 0,-4 Q 12,-34 16,-40 Q 8,-24 0,-4" fill="#4CAF50" stroke="#1B5E20" stroke-width="0.8" />
        </g>
        `;

      case 'floor_lamp':
        // Modern Arching Floor Lamp (Image 1)
        return `
        <g id="prop-lamp-${prop.id}" transform="translate(${sx}, ${sy})">
          <ellipse cx="0" cy="8" rx="8" ry="4" fill="#000" opacity="0.25" />
          <!-- Circular base -->
          <ellipse cx="0" cy="6" rx="6" ry="3" fill="#424242" stroke="#212121" stroke-width="1" />
          <!-- Tall thin chrome pole -->
          <line x1="0" y1="6" x2="0" y2="-44" stroke="#757575" stroke-width="1.8" />
          <!-- White Cone Shade -->
          <polygon points="-8,-44 8,-44 6,-56 -6,-56" fill="#F5F5F5" stroke="#E0E0E0" stroke-width="1" />
          <!-- Light glow -->
          <ellipse cx="0" cy="-44" rx="7" ry="2" fill="#FFF9C4" opacity="0.8" />
        </g>
        `;

      case 'maid_character':
        // Maid Character Cleaning (Image 5)
        return `
        <g id="prop-maid-${prop.id}" transform="translate(${sx}, ${sy})">
          <ellipse cx="0" cy="14" rx="8" ry="4" fill="#000" opacity="0.3" />
          <!-- Maid Uniform: Black Dress with White Apron -->
          <polygon points="-6,10 6,10 4,-6 -4,-6" fill="#1E1E24" />
          <polygon points="-4,10 4,10 3,-2 -3,-2" fill="#FFFFFF" />
          <!-- Head & Headband -->
          <circle cx="0" cy="-12" r="5" fill="#FDEDE2" />
          <path d="M -4,-15 Q 0,-18 4,-15" stroke="#FFFFFF" stroke-width="2" fill="none" />
          <!-- Vacuum Cleaner or Duster in Hand -->
          <line x1="4" y1="2" x2="16" y2="12" stroke="#E53935" stroke-width="2" />
          <rect x="14" y="10" width="8" height="4" rx="2" fill="#424242" />
        </g>
        `;

      case 'billiard_player':
        // Billiard Player Leaning Forward with Cue Stick (Image 4)
        return `
        <g id="prop-player-${prop.id}" transform="translate(${sx}, ${sy})">
          <ellipse cx="0" cy="16" rx="9" ry="4" fill="#000" opacity="0.3" />
          <!-- Trousers & Shoes -->
          <line x1="-3" y1="8" x2="-5" y2="16" stroke="#263238" stroke-width="3" />
          <line x1="3" y1="8" x2="5" y2="16" stroke="#263238" stroke-width="3" />
          <!-- Shirt with Vest Leaning Forward -->
          <polygon points="-6,8 6,8 10,-8 -2,-8" fill="#FFFFFF" stroke="#37474F" stroke-width="1" />
          <polygon points="-2,8 4,8 7,-6 1,-6" fill="#212121" />
          <!-- Head -->
          <circle cx="10" cy="-12" r="4.5" fill="#FDEDE2" />
          <!-- Pool Cue Stick in Hands -->
          <line x1="-12" y1="-2" x2="28" y2="6" stroke="#D7CCC8" stroke-width="1.8" stroke-linecap="round" />
        </g>
        `;

      default:
        return '';
    }
  };

  return `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1040 680" width="100%" height="100%" class="select-none">
  <defs>
    <!-- Background ambiance -->
    <linearGradient id="isoSkyBg" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stopColor="#12151F" />
      <stop offset="100%" stopColor="#0B0C10" />
    </linearGradient>

    <!-- Floor Depth Plinth Gradient -->
    <linearGradient id="plinthGradient" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stopColor="#2A3040" />
      <stop offset="100%" stopColor="#141720" />
    </linearGradient>

    <!-- Wall Accent Brick Pattern (Image 4) -->
    <pattern id="brickPattern" width="24" height="12" patternUnits="userSpaceOnUse">
      <rect width="24" height="12" fill="${leftWallCol.main}" />
      <rect x="0" y="0" width="22" height="5" fill="${leftWallCol.shade}" rx="0.5" />
      <rect x="12" y="6" width="22" height="5" fill="${leftWallCol.shade}" rx="0.5" />
    </pattern>
  </defs>

  <!-- 1. BACKDROP -->
  <rect width="100%" height="100%" fill="url(#isoSkyBg)" />

  <!-- 2. ISOMETRIC ROOM CONTAINER -->
  <g id="iso-room-group">
    
    <!-- 3. ISOMETRIC CORNER WALLS (Left Wall & Right Wall) -->
    <!-- Left Wall (Facing East-South) -->
    <polygon points="${backCorner.sx},${backCorner.sy - wallHeight} ${leftCorner.sx},${leftCorner.sy - wallHeight} ${leftCorner.sx},${leftCorner.sy} ${backCorner.sx},${backCorner.sy}"
      fill="${wallLeft === 'brick_office' ? 'url(#brickPattern)' : leftWallCol.main}"
      stroke="#141720" stroke-width="1.5" />
    <!-- Left Wall Baseboard Trim -->
    <polygon points="${backCorner.sx},${backCorner.sy - 8} ${leftCorner.sx},${leftCorner.sy - 8} ${leftCorner.sx},${leftCorner.sy} ${backCorner.sx},${backCorner.sy}"
      fill="${leftWallCol.trim}" />

    <!-- Right Wall (Facing West-South) -->
    <polygon points="${backCorner.sx},${backCorner.sy - wallHeight} ${rightCorner.sx},${rightCorner.sy - wallHeight} ${rightCorner.sx},${rightCorner.sy} ${backCorner.sx},${backCorner.sy}"
      fill="${rightWallCol.shade}"
      stroke="#141720" stroke-width="1.5" />
    <!-- Right Wall Baseboard Trim -->
    <polygon points="${backCorner.sx},${backCorner.sy - 8} ${rightCorner.sx},${rightCorner.sy - 8} ${rightCorner.sx},${rightCorner.sy} ${backCorner.sx},${backCorner.sy}"
      fill="${rightWallCol.trim}" />

    <!-- Wall Details: Door on Left Wall (Image 1 & 5) -->
    ${
      options.hasDoor !== false
        ? `
      <g id="wall-door" transform="translate(${backCorner.sx + 80}, ${backCorner.sy - 150})">
        <!-- Door Frame -->
        <polygon points="0,-10 50,25 50,145 0,110" fill="#2E1C12" stroke="#1B0F09" stroke-width="1.5" />
        <!-- Door Panel with Inset Panels -->
        <polygon points="4,-6 46,23 46,140 4,110" fill="#5D4037" />
        <polygon points="8,4 42,27 42,70 8,47" fill="#4E342E" stroke="#3E2723" stroke-width="1" />
        <polygon points="8,54 42,77 42,130 8,107" fill="#4E342E" stroke="#3E2723" stroke-width="1" />
        <!-- Brass Door Handle -->
        <circle cx="14" cy="80" r="3" fill="#FFD54F" />
      </g>
    `
        : ''
    }

    <!-- Wall Details: Analog Round Wall Clock (Image 1) -->
    ${
      options.hasWallClock !== false
        ? `
      <g id="wall-clock" transform="translate(${backCorner.sx + 240}, ${backCorner.sy - 120})">
        <ellipse cx="0" cy="0" rx="14" ry="14" fill="#FFFFFF" stroke="#212121" stroke-width="2" />
        <!-- Clock Hour ticks & Hands -->
        <circle cx="0" cy="0" r="1.5" fill="#000" />
        <line x1="0" y1="0" x2="0" y2="-8" stroke="#000" stroke-width="1.5" />
        <line x1="0" y1="0" x2="6" y2="2" stroke="#E53935" stroke-width="1" />
      </g>
    `
        : ''
    }

    <!-- Wall Details: Modern Air Conditioner on Right Wall (Image 5) -->
    ${
      options.hasAirConditioner !== false
        ? `
      <g id="wall-ac" transform="translate(${backCorner.sx - 120}, ${backCorner.sy - 130})">
        <polygon points="0,-8 50,-33 50,-8 0,17" fill="#F5F5F5" stroke="#BDBDBD" stroke-width="1" />
        <line x1="5" y1="12" x2="45" y2="-8" stroke="#9E9E9E" stroke-width="1" />
        <circle cx="42" cy="-12" r="1.5" fill="#4CAF50" />
      </g>
    `
        : ''
    }

    <!-- 4. ISOMETRIC FLOOR TILES -->
    <g id="iso-floor-tiles">
      ${floorSvg}
    </g>

    <!-- 5. FLOOR BASE PLINTH / THICKNESS (Images 1, 4, 5) -->
    <!-- Left Bottom Plinth Face -->
    <polygon points="${leftCorner.sx},${leftCorner.sy} ${bottomCorner.sx},${bottomCorner.sy} ${bottomCorner.sx},${bottomCorner.sy + 18} ${leftCorner.sx},${leftCorner.sy + 18}"
      fill="url(#plinthGradient)" stroke="#0E1017" stroke-width="1.5" />
    <!-- Right Bottom Plinth Face -->
    <polygon points="${bottomCorner.sx},${bottomCorner.sy} ${rightCorner.sx},${rightCorner.sy} ${rightCorner.sx},${rightCorner.sy + 18} ${bottomCorner.sx},${bottomCorner.sy + 18}"
      fill="#1A1E29" stroke="#0E1017" stroke-width="1.5" />

    <!-- 6. SORTED ISOMETRIC PROPS & CHARACTERS (Sorted by screen Y for depth sorting) -->
    <g id="iso-props-container">
      ${props
        .slice()
        .sort((a, b) => a.x + a.y - (b.x + b.y))
        .map(renderProp)
        .join('\n')}
    </g>

  </g>
</svg>
  `.trim();
}

/**
 * =====================================================================
 * 3. OVERWORLD / REGION FANTASY MAP DETERMINISTIC SVG GENERATOR
 * Generates stylized overworld and treasure maps matching Image 7:
 * - Nautical ocean with wave ripples & shoreline foam
 * - Organic islands with sandy coastlines
 * - Topographical elevation contour terraces (brown ridges, sandy shores, lush plains)
 * - Winding rivers and clustered tree/forest sprites
 * - Road networks, red location pins, and decorative banner scrolls
 * =====================================================================
 */
export function generateOverworldMapSvg(options: OverworldMapOptions = {}): string {
  const seed = options.seed || 'fantasy-archipelago-42';
  const prng = createPrng(seed);

  const title = options.title || 'ARCHIPIÉLAGO DE LAS MAREAS DORADAS';
  const markers: MapMarker[] = options.markers || [
    { id: 'm1', x: 500, y: 380, type: 'capital', name: 'Ciudadela Central' },
    { id: 'm2', x: 260, y: 220, type: 'castle', name: 'Bastión del Viento' },
    { id: 'm3', x: 300, y: 550, type: 'port', name: 'Puerto de la Niebla' },
    { id: 'm4', x: 780, y: 200, type: 'dungeon', name: 'Caverna del Éter' },
    { id: 'm5', x: 680, y: 520, type: 'treasure', name: 'Cofre Olvidado' }
  ];

  // Helper for generating organic island shapes
  return `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 800" width="100%" height="100%" class="select-none">
  <defs>
    <!-- Map Canvas Shadow -->
    <filter id="mapShadow" x="-10%" y="-10%" width="120%" height="120%">
      <feDropShadow dx="0" dy="4" stdDeviation="8" flood-color="#000" flood-opacity="0.5" />
    </filter>

    <!-- Ocean Water Gradient -->
    <linearGradient id="oceanGradient" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stopColor="#C9F2FE" />
      <stop offset="50%" stopColor="#B4E9FB" />
      <stop offset="100%" stopColor="#9BDCF2" />
    </linearGradient>

    <!-- Sand Shoreline Gradient -->
    <linearGradient id="sandShore" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stopColor="#F5D09D" />
      <stop offset="100%" stopColor="#E5BA7D" />
    </linearGradient>

    <!-- Grassland Plains Green -->
    <linearGradient id="plainsGreen" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stopColor="#99E265" />
      <stop offset="100%" stopColor="#6BC43B" />
    </linearGradient>

    <!-- Elevation Contour Brown Ridge (Image 7) -->
    <linearGradient id="ridgeBrown" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stopColor="#DCA774" />
      <stop offset="100%" stopColor="#B37D48" />
    </linearGradient>

    <!-- Parchment Banner Gradient -->
    <linearGradient id="bannerParchment" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stopColor="#FBF7EE" />
      <stop offset="50%" stopColor="#EDE3D1" />
      <stop offset="100%" stopColor="#DFD2BA" />
    </linearGradient>
  </defs>

  <!-- 1. OCEAN BACKDROP -->
  <rect width="1000" height="800" fill="url(#oceanGradient)" stroke="#0E1E2E" stroke-width="3" />

  <!-- 2. OCEAN WAVE RIPPLES (Stylized thin lines like in Image 7) -->
  <g id="ocean-ripples" stroke="#68BBD9" stroke-width="1.2" fill="none" opacity="0.6">
    <path d="M 80 120 Q 110 115 140 120" />
    <path d="M 60 140 Q 80 135 100 140" />
    <path d="M 180 80 Q 210 75 240 80" />
    <path d="M 400 100 Q 430 95 460 100" />
    <path d="M 720 120 Q 750 115 780 120" />
    <path d="M 850 80 Q 880 75 910 80" />
    <path d="M 120 400 Q 150 395 180 400" />
    <path d="M 820 420 Q 850 415 880 420" />
    <path d="M 500 720 Q 530 715 560 720" />
    <path d="M 600 740 Q 630 735 660 740" />
  </g>

  <!-- 3. ISLAND 1: NORTHWEST VOLCANIC PEAK (Image 7 style) -->
  <g id="island-nw">
    <!-- Sandy Perimeter / Coastline -->
    <path d="M 180 160 Q 260 90 320 150 Q 360 210 330 290 Q 240 340 180 270 Q 150 210 180 160 Z"
      fill="url(#sandShore)" stroke="#222" stroke-width="2" />
    <!-- Plains Green Inner -->
    <path d="M 195 175 Q 260 120 305 165 Q 340 210 310 270 Q 240 310 195 250 Q 170 210 195 175 Z"
      fill="url(#plainsGreen)" />
    <!-- Brown Elevation Ridge Ring 1 -->
    <path d="M 215 190 Q 260 145 290 180 Q 315 215 295 250 Q 240 280 215 240 Z"
      fill="url(#ridgeBrown)" stroke="#66462C" stroke-width="1.5" />
    <!-- High Peak Summit Crater -->
    <path d="M 235 205 Q 260 175 275 200 Q 285 220 275 235 Q 240 250 235 205 Z"
      fill="#8C5835" />
    <ellipse cx="258" cy="216" rx="10" ry="7" fill="#4A2E1B" />
    <!-- River flowing down west to sea -->
    <path d="M 235 205 Q 210 215 180 200" stroke="#38B6FF" stroke-width="3" fill="none" stroke-linecap="round" />
  </g>

  <!-- 4. ISLAND 2: MAIN CENTRAL EMPIRE CONTINENT (Image 7 style) -->
  <g id="island-central">
    <!-- Sand Outer Shoreline with Bays & Capes -->
    <path d="M 300 440 Q 280 470 310 520 Q 300 620 350 710 Q 450 780 560 760 Q 640 780 720 740 Q 740 680 710 650 Q 740 590 730 520 Q 690 420 670 400 Q 620 360 480 370 Q 360 360 300 440 Z"
      fill="url(#sandShore)" stroke="#111" stroke-width="2.5" />
    <!-- Lush Grassland Fill -->
    <path d="M 320 450 Q 305 480 325 530 Q 320 610 365 690 Q 450 750 550 740 Q 620 750 690 710 Q 710 660 685 630 Q 710 580 705 520 Q 670 435 650 415 Q 600 385 480 390 Q 370 385 320 450 Z"
      fill="url(#plainsGreen)" />

    <!-- Tier 1 Elevation Brown Terrace (Longitudinal Mountain Range) -->
    <path d="M 400 415 Q 490 410 590 415 Q 620 445 610 560 Q 605 660 550 700 Q 480 710 420 660 Q 370 560 400 415 Z"
      fill="url(#ridgeBrown)" stroke="#66462C" stroke-width="2" />
    <!-- Tier 2 High Ridge Contour -->
    <path d="M 430 435 Q 490 430 560 435 Q 580 465 570 550 Q 565 620 520 650 Q 470 660 440 620 Q 410 540 430 435 Z"
      fill="#8C5835" stroke="#4A2E1B" stroke-width="1.8" />
    
    <!-- Central Continental River Network (Image 7) -->
    <path d="M 520 440 Q 470 480 430 490 Q 360 500 305 520" stroke="#38B6FF" stroke-width="3.5" fill="none" stroke-linecap="round" />
    <path d="M 470 480 Q 440 560 380 620 Q 340 640 310 660" stroke="#38B6FF" stroke-width="2.5" fill="none" stroke-linecap="round" />
    <path d="M 540 520 Q 600 560 650 540 Q 700 530 730 520" stroke="#38B6FF" stroke-width="3" fill="none" stroke-linecap="round" />

    <!-- Clustered Tree & Forest Sprites (Image 7 Deciduous & Pine icons) -->
    <g id="forest-clusters">
      <!-- West Forest -->
      <circle cx="360" cy="460" r="10" fill="#2D7A32" stroke="#1B5E20" stroke-width="1" />
      <circle cx="375" cy="455" r="12" fill="#388E3C" stroke="#1B5E20" stroke-width="1" />
      <circle cx="370" cy="470" r="11" fill="#1E6523" stroke="#1B5E20" stroke-width="1" />
      <circle cx="385" cy="465" r="10" fill="#2E7D32" stroke="#1B5E20" stroke-width="1" />

      <!-- Center-South Forest -->
      <circle cx="480" cy="620" r="12" fill="#2D7A32" stroke="#1B5E20" stroke-width="1" />
      <circle cx="495" cy="615" r="14" fill="#388E3C" stroke="#1B5E20" stroke-width="1" />
      <circle cx="490" cy="635" r="11" fill="#1E6523" stroke="#1B5E20" stroke-width="1" />
      <circle cx="510" cy="625" r="13" fill="#2E7D32" stroke="#1B5E20" stroke-width="1" />

      <!-- East Coastal Forest -->
      <circle cx="630" cy="480" r="11" fill="#2D7A32" stroke="#1B5E20" stroke-width="1" />
      <circle cx="645" cy="475" r="13" fill="#388E3C" stroke="#1B5E20" stroke-width="1" />
      <circle cx="640" cy="495" r="10" fill="#1E6523" stroke="#1B5E20" stroke-width="1" />
    </g>

    <!-- Overland Road Networks (Dashed Pink / Tan lines like Image 7) -->
    <path d="M 320 530 Q 380 500 500 480 Q 620 490 680 530" stroke="#D81B60" stroke-width="2" stroke-dasharray="5,4" fill="none" />
    <path d="M 500 480 Q 510 560 500 650 Q 480 700 450 740" stroke="#D81B60" stroke-width="2" stroke-dasharray="5,4" fill="none" />
  </g>

  <!-- 5. SMALL ARCHIPELAGO ISLETS (Northeast, Southwest, East) -->
  <!-- NE Island 1 -->
  <path d="M 520 190 Q 560 170 580 200 Q 550 230 510 210 Z" fill="url(#sandShore)" stroke="#111" stroke-width="1.5" />
  <circle cx="545" cy="198" r="8" fill="#2E7D32" />

  <!-- NE Island 2 (Horseshoe Island) -->
  <path d="M 640 120 Q 710 100 740 150 Q 720 220 660 210 Q 680 160 640 120 Z" fill="url(#sandShore)" stroke="#111" stroke-width="1.8" />
  <path d="M 655 135 Q 700 120 720 155 Q 705 200 670 195 Q 685 160 655 135 Z" fill="url(#plainsGreen)" />
  <circle cx="690" cy="160" r="10" fill="#2E7D32" />
  <circle cx="705" cy="180" r="9" fill="#1B5E20" />

  <!-- SE Small Island -->
  <path d="M 820 400 Q 880 380 890 420 Q 860 460 820 440 Z" fill="url(#sandShore)" stroke="#111" stroke-width="1.5" />
  <circle cx="855" cy="420" r="12" fill="url(#ridgeBrown)" />

  <!-- 6. MAP MARKERS, PINS & BANNER LABELS (Image 7 style) -->
  <g id="map-markers" filter="url(#mapShadow)">
    ${markers
      .map(marker => {
        let pinIcon = '';
        if (marker.type === 'capital') {
          pinIcon = `
          <!-- Golden Capital Castle Pin -->
          <circle cx="0" cy="0" r="14" fill="#D4AF37" stroke="#FFF" stroke-width="2" />
          <polygon points="-6,4 -6,-4 0,-9 6,-4 6,4" fill="#1A1C23" />
          <rect x="-2" y="0" width="4" height="4" fill="#FFF" />
        `;
        } else if (marker.type === 'castle') {
          pinIcon = `
          <!-- Red Castle Pin -->
          <circle cx="0" cy="0" r="12" fill="#E53935" stroke="#FFF" stroke-width="2" />
          <polygon points="-5,3 -5,-3 0,-7 5,-3 5,3" fill="#FFF" />
        `;
        } else if (marker.type === 'port') {
          pinIcon = `
          <!-- Blue Port Anchor Pin -->
          <circle cx="0" cy="0" r="12" fill="#1E88E5" stroke="#FFF" stroke-width="2" />
          <circle cx="0" cy="-3" r="2" fill="#FFF" />
          <line x1="0" y1="-1" x2="0" y2="5" stroke="#FFF" stroke-width="2" />
          <path d="M -4,2 Q 0,6 4,2" stroke="#FFF" stroke-width="2" fill="none" />
        `;
        } else if (marker.type === 'treasure') {
          pinIcon = `
          <!-- Treasure X Mark (Red Cross) -->
          <circle cx="0" cy="0" r="11" fill="#FFB300" stroke="#FFF" stroke-width="2" />
          <line x1="-5" y1="-5" x2="5" y2="5" stroke="#C62828" stroke-width="3" stroke-linecap="round" />
          <line x1="5" y1="-5" x2="-5" y2="5" stroke="#C62828" stroke-width="3" stroke-linecap="round" />
        `;
        } else {
          pinIcon = `
          <!-- Standard Red Location Pin -->
          <circle cx="0" cy="-4" r="7" fill="#E53935" stroke="#FFF" stroke-width="1.5" />
          <polygon points="-5,-4 5,-4 0,7" fill="#E53935" />
          <circle cx="0" cy="-4" r="2.5" fill="#FFF" />
        `;
        }

        return `
      <g id="marker-${marker.id}" transform="translate(${marker.x}, ${marker.y})">
        <!-- Interactive Marker Icon -->
        ${pinIcon}
        <!-- Decorative Name Banner (Image 7 parchment box) -->
        <g transform="translate(0, 20)">
          <rect x="-65" y="-10" width="130" height="20" rx="3" fill="url(#bannerParchment)" stroke="#7A684D" stroke-width="1.2" opacity="0.95" />
          <text x="0" y="4" text-anchor="middle" font-family="'Georgia', serif" font-size="9" font-weight="bold" fill="#2E1C0C" letter-spacing="0.5">
            ${marker.name.toUpperCase()}
          </text>
        </g>
      </g>
      `;
      })
      .join('\n')}
  </g>

  <!-- 7. COMPASS ROSE & MAP FRAME TITLE (Top-Right & Top-Left) -->
  <!-- Ornate Compass Rose -->
  <g id="compass-rose" transform="translate(890, 110)">
    <circle cx="0" cy="0" r="38" fill="#FBF7EE" stroke="#7A684D" stroke-width="1.5" />
    <circle cx="0" cy="0" r="32" stroke="#7A684D" stroke-width="0.8" fill="none" stroke-dasharray="2,2" />
    <!-- Compass Star Points -->
    <polygon points="0,-34 6,-6 0,0" fill="#D32F2F" />
    <polygon points="0,-34 -6,-6 0,0" fill="#7F0000" />
    <polygon points="0,34 6,6 0,0" fill="#5D4037" />
    <polygon points="0,34 -6,6 0,0" fill="#2E1C0C" />
    <polygon points="34,0 6,6 0,0" fill="#5D4037" />
    <polygon points="34,0 6,-6 0,0" fill="#2E1C0C" />
    <polygon points="-34,0 -6,6 0,0" fill="#5D4037" />
    <polygon points="-34,0 -6,-6 0,0" fill="#2E1C0C" />
    <text x="0" y="-38" text-anchor="middle" font-family="'Georgia', serif" font-size="11" font-weight="bold" fill="#D32F2F">N</text>
  </g>

  <!-- Map Title Banner -->
  <g id="map-title-banner" transform="translate(50, 45)">
    <rect x="0" y="0" width="360" height="34" rx="6" fill="#141720" stroke="#D4AF37" stroke-width="1.5" />
    <text x="18" y="22" font-family="'Georgia', serif" font-size="12" font-weight="bold" fill="#D4AF37" letter-spacing="1">
      🗺️ ${title}
    </text>
  </g>
</svg>
  `.trim();
}

/**
 * =====================================================================
 * 4. EXPORT & DOWNLOAD UTILITY FUNCTIONS
 * =====================================================================
 */
export function exportSvgFile(svgContent: string, filename: string = 'sprite_asset.svg'): void {
  const blob = new Blob([svgContent], { type: 'image/svg+xml;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename.endsWith('.svg') ? filename : `${filename}.svg`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function copySvgToClipboard(svgContent: string): Promise<boolean> {
  return navigator.clipboard
    .writeText(svgContent)
    .then(() => true)
    .catch(() => false);
}

export async function exportPngFromSvg(
  svgString: string,
  filename: string = 'sprite_asset.png',
  width: number = 1000,
  height: number = 800
): Promise<string> {
  return new Promise((resolve, reject) => {
    try {
      const blob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Canvas context not available'));
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        URL.revokeObjectURL(url);

        const dataUrl = canvas.toDataURL('image/png');
        const link = document.createElement('a');
        link.href = dataUrl;
        link.download = filename.endsWith('.png') ? filename : `${filename}.png`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        resolve(dataUrl);
      };
      img.onerror = err => {
        URL.revokeObjectURL(url);
        reject(err);
      };
      img.src = url;
    } catch (e) {
      reject(e);
    }
  });
}
