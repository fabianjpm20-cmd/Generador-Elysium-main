export type MainScreen = 'home' | 'library' | 'creation' | 'interaction';

export type AppState = 0 | 1 | 2 | 3 | 4 | 5 | 6;

// ==========================================
// LUGAR / ESCENARIO - FICHA MAESTRA DE AMBIENTE Y VIVIENDA
// ==========================================

export interface CriticalPointOfInterest {
  id: string;
  name: string;
  type: string; // Comercio, Taller, Templo, Puesto de guardia, Fuente, etc.
  function: string; // Función del lugar
  owner: string; // Propietario / Responsable
  location: string; // Ubicación específica dentro del lugar
  description: string;
  importance: 'Baja' | 'Media' | 'Alta' | 'Crítica';
}

export interface ConvergenceZone {
  id: string;
  name: string;
  type: 'Plaza' | 'Callejón' | 'Azotea' | 'Mercado' | 'Estación' | 'Bar' | 'Patio' | 'Parque' | string;
  schedule: string; // Horario de actividad
  npcDensity: 'Nula' | 'Baja' | 'Media' | 'Alta' | 'Frenética';
  frequentEvents: string;
  securityLevel: 'Sin vigilancia' | 'Bajo' | 'Medio' | 'Alto' | 'Vigilancia militar';
  associatedCharacters: string[];
}

export interface HousingRoom {
  id: string;
  name: string;
  function: string;
  location: string;
  furniture: string[];
  objects: string[];
  accesses: string[];
  associatedCharacters: string[];
  description: string;
}

export interface HousingLevel {
  levelNumber: number; // 0, 1, 2, 3
  levelName: string; // NIVEL 0 — ACCESO, NIVEL 1 — ÁREAS SOCIALES, NIVEL 2 — ÁREAS PRIVADAS, NIVEL 3 — EXTERIOR
  rooms: HousingRoom[];
}

export interface HousingConfig {
  buildingType: 'Casa' | 'Departamento' | 'Triplex' | 'Edificio' | 'Búnker' | 'Taller-vivienda' | 'Departamento colmena' | 'Residencia' | string;
  levels: HousingLevel[];
  exteriorsAndConnectivity: string[]; // Terrazas, Balcones, Patios, Escaleras, Pasadizos, etc.
}

export type UniqueElementType = 'OBJETO' | 'ANIMAL' | 'PERSONAJE' | 'ANOMALÍA' | 'MECANISMO' | 'LUGAR' | 'EVENTO PERMANENTE';

export interface UniqueElement {
  id: string;
  name: string;
  type: UniqueElementType;
  description: string;
  behavior: string; // Comportamiento / Efecto ambiental
  importance: string; // Elemento ambiental, Clave de trama, Peligro, etc.
}

export interface WorldPlace {
  id: string;
  name: string;
  version?: string; // v1.0, v1.1, etc.
  linkedWorldId?: string;

  // 1. Identidad, Ubicación y Atmósfera
  geographicContext?: 'Suburbio' | 'Distrito urbano' | 'Distrito industrial' | 'Zona rural' | 'Asentamiento aislado' | 'Zona fronteriza' | string;
  rhythmOrVibes?: string[]; // Frenético, Tranquilo, Estancado, Tenso, Vigilado, Caótico, Aislado
  atmosphere: string;
  description: string;

  // 2. Arquitectura y Materialidad
  constructionStyle?: 'Brutalismo' | 'Modular' | 'Industrial' | 'Tradicional' | 'Contemporáneo' | 'Rústico' | 'Futurista' | 'Mágico' | string;
  materials?: string[]; // Hormigón, Metal, Madera, Piedra, Vidrio, Ladrillo, Sintéticos, Fantásticos
  condition?: 'Nuevo' | 'Conservado' | 'Usado' | 'Deteriorado' | 'Abandonado' | 'En construcción' | string;

  // 3. Ecosistema Urbano y Servicios
  criticalPointsOfInterest?: CriticalPointOfInterest[];
  convergenceZones?: ConvergenceZone[];
  cultureAndSecurity?: {
    authority: 'Gobierno' | 'Policía' | 'Milicia' | 'Organización criminal' | 'Comunidad' | 'Nadie' | string;
    surveillance: 'Nula' | 'Baja' | 'Media' | 'Alta' | 'Extrema';
    socialConduct: string[]; // Hospitalidad, Desconfianza, Miedo, Solidaridad, Indiferencia, Competencia
  };

  // 4. Vivienda Específica
  hasHousing?: boolean;
  housing?: HousingConfig;

  // 5. Elementos Únicos
  uniqueElements?: UniqueElement[];

  // Compatibilidad legacy
  region: string;
  environmentType: 'Oasis' | 'Desierto' | 'Palacio' | 'Ciudadela' | 'Bosque' | 'Mazmorra' | 'Taberna' | 'Ruinas' | 'Templo' | string;
  dangerLevel: 'Seguro' | 'Neutral' | 'Disputado' | 'Hostil' | 'Mortal' | number | string;
  dominantFactionId?: string;
  pointsOfInterest: string[];
  ambientColorTheme: string;
  createdAt: string;
  updatedAt?: string;
}

// ==========================================
// WORLDBUILDING - 12 CATEGORÍAS & REGLAS DE SIMULACIÓN
// ==========================================

export interface WorldFaction {
  id: string;
  name: string;
  ideology: string;
  emblemIcon: string;
  color: string;
  reputationWithPlayer: 'Aliada' | 'Amistosa' | 'Neutral' | 'Desconfiada' | 'Hostil';
  description: string;
  activeEnemies?: string[];
  hierarchy?: string[];
}

export interface FactionRelationship {
  id: string;
  factionAId: string;
  factionBId: string;
  status: 'Hostil' | 'Alianza' | 'Neutral' | 'Rival' | 'Pacto';
  notes?: string;
}

export interface WorldSpecialLaw {
  id: string;
  title: string;
  scope: string; // e.g. "Capital del Reino del Sur"
  condition: string; // e.g. "Portar armas arcanas"
  effect: string; // e.g. "La magia no puede ejecutarse normalmente..."
  exceptions: string; // e.g. "Guardia del Velo Dorado con salvoconducto"
  isActive: boolean;
}

export interface GeographicHierarchyItem {
  continent: string;
  country: string;
  region: string;
  city: string;
  district: string;
  placeName: string;
}

export interface WorldBuildingConfig {
  id?: string;
  worldName: string;
  version?: string;

  // 01 Historia del Mundo
  history?: {
    origin: string;
    eras: string;
    keyEvents: string[];
    wars: string[];
    catastrophes: string[];
    politicalChanges: string[];
    fundamentalEvents: string[];
  };

  // 02 Geografía
  geographyHierarchy?: {
    continents: string[];
    countries: string[];
    regions: string[];
    cities: string[];
    climates: string[];
    resources: string[];
    specialZones: string[];
    hierarchy: GeographicHierarchyItem[];
  };

  // 03 Política
  politics?: {
    governments: string[];
    factions: WorldFaction[];
    organizations: string[];
    relationships: FactionRelationship[];
    conflicts: string[];
    hierarchies: string[];
  };

  // 04 Economía
  economy?: {
    currency: string;
    resources: string[];
    trade: string;
    markets: string[];
    keyGoods: string[];
    scarcity: string[];
    wealth: string;
    systems: string[];
  };

  // 05 Religión / Cultura
  religionAndCulture?: {
    isApplicable: boolean; // NO APLICA toggle
    religions: string[];
    traditions: string[];
    customs: string[];
    festivities: string[];
    taboos: string[];
    values: string[];
    culturalNorms: string[];
  };

  // 06 Tecnología
  technology?: {
    level: 'Primitivo' | 'Medieval' | 'Industrial' | 'Moderno' | 'Futurista' | 'Post-tecnológico' | 'Híbrido';
    allowedTech: string[];
    forbiddenTech: string[];
  };

  // 07 Magia
  magicSystem?: {
    hasMagic: boolean; // ¿Existe magia? SÍ / NO
    source: string;
    rules: string[];
    limitations: string[];
    cost: string;
    users: string;
    types: string[];
    effects: string[];
    restrictions: string[];
  };

  // 08 Reglas Físicas
  physicalRules?: {
    gravity: string;
    biology: string;
    healing: string;
    death: string;
    travel: string;
    time: string;
    space: string;
    energy: string;
    supernaturalPhenomena: string;
  };

  // 09 Reglas Sociales
  socialRules?: {
    hierarchies: string;
    customs: string;
    familyRelations: string;
    socialNorms: string;
    acceptedBehaviors: string[];
    rejectedBehaviors: string[];
    protocols: string[];
    socialRoles: string[];
  };

  // 10 Leyes Especiales
  specialLaws?: WorldSpecialLaw[];

  // 11 Canon
  canon?: {
    characters: string[];
    facts: string[];
    relationships: string[];
    places: string[];
    events: string[];
    rules: string[];
    historicalData: string[];
  };

  // 12 Restricciones Narrativas
  narrativeRestrictions?: {
    forbiddenTech: string[];
    unauthorizedCharacters: string[];
    incompatibleEvents: string[];
    arbitraryRuleChanges: string[];
  };

  // Legacy fields
  eraOrTone: string;
  magicLevel: 'Nula' | 'Baja' | 'Alta' | 'Desbordante';
  factions: WorldFaction[];
  laws: WorldLaw[];
}

export interface WorldLaw {
  id: string;
  title: string;
  description: string;
  impactTag: 'social' | 'intimacy' | 'combat' | 'magic';
  modifierDescription: string;
  isActive: boolean;
}

// ==========================================
// LITE AGENT LOGIC (AGENTE SIMPLE REACTIVO)
// ==========================================

export interface LiteAgentCombatStats {
  maxHp: number;
  currentHp: number;
  maxSp: number;
  currentSp: number;
  attack: number;
  defense: number;
  agility: number;
  specialSkillName: string;
  specialSkillDescription: string;
}

export interface LiteAgentConfig {
  isLiteAgent: boolean;
  motivations: string[];
  allegianceFactionId?: string;
  greatestFear: string;
  moralAlignment?: 'Devoto Protector' | 'Leal Bondadoso' | 'Neutral Bondadoso' | 'Neutral' | 'Neutral Ambicioso' | 'Curioso' | 'Hedonismo' | 'Rebelde' | 'Caótico' | string;
  interactionRole?: string;
  combatStats: LiteAgentCombatStats;
  customReactionRule?: string;
}

// ==========================================
// ENTRENAMIENTO & AUTONOMÍA COGNITIVA (IA & CONCIENCIA)
// ==========================================

export interface CharacterAITrainingConfig {
  autonomyLevel: number; // 0 a 100 (grado de iniciativa y proactividad espontánea)
  somaticAwarenessLevel: 'sutil' | 'inmersivo' | 'agudo'; // Percepción de su cuerpo físico y sensaciones
  wardrobeAndRoleAwareness: boolean; // Conciencia de prendas activas y capacidad de cambio de rol/ropa
  alternateVersionsAwareness: boolean; // Reconocimiento de su pasado, futuro y versiones alternas
  environmentReactivity: 'tranquilo' | 'atento' | 'hipersensible'; // Reacción sensorial al entorno
  trainingDirectives: string[]; // Directivas de conducta y memoria fija inculcadas
  lastTrainedAt?: string;
  trainingNotes?: string;
  testHistory?: Array<{
    timestamp: string;
    prompt: string;
    reply: string;
    innerThought?: string;
    somaticAction?: string;
  }>;
}

// ==========================================
// AMBIENT SIMPLE NPCS (AUTO-GENERADOS)
// ==========================================

export interface SimpleAmbientNPC {
  id: string;
  name: string;
  role: string;
  disposition: 'Amistoso' | 'Neutral' | 'Vigilante' | 'Hostil' | 'Curioso';
  snippetDialogue: string;
}

// ==========================================
// ROLEPLAY & INTERACTION SESSION (PANTALLA 4)
// ==========================================

export type StoryGenre = 'Romance' | 'Aventura' | 'Guerra y Política' | 'Erótico / R+18';
export type StoryDepth = 'Rápido / Informal' | 'Novela Detallada' | 'Simulación Inmersiva';
export type AmbientNpcDensity = 'none' | 'few' | 'moderate' | 'crowd';

export interface CharacterAttributes {
  FUE: number; // Fuerza (1 - 20)
  DES: number; // Destreza (1 - 20)
  CON: number; // Constitución (1 - 20)
  INT: number; // Inteligencia (1 - 20)
  SAB: number; // Sabiduría (1 - 20)
  CAR: number; // Carisma (1 - 20)
}

export interface CharacterDerivedStats {
  CEP: number; // Capacidad de Enfoque Psíquico
  EFC: number; // Eficacia (%)
  RR: number;  // Resistencia a Reacciones
  PV: number;  // Puntos de Vida
  maxPV?: number; // Puntos de Vida Máximos
  PEP: number; // Puntos de Energía / Poder
  maxPEP?: number; // Puntos de Energía Máximos
  CA: number;  // Clase de Armadura
  iniciativa: number;
  velocidad: number;
  proficiencia: number;
  XP: number;
  nivel: number; // 1 - 20
  habilidades: string[];
  hechizos: string[];
  bonificacionesClase?: string;
}

export type SimulationEventCategory =
  | 'Movimiento'
  | 'Ambiente'
  | 'NPC'
  | 'Objeto'
  | 'Diálogo'
  | 'Combate'
  | 'Decisión'
  | 'Consecuencia'
  | 'Cambio de estado'
  | 'Cambio del mundo'
  | 'Sistema';

export interface SimulationEventEntry {
  id: string;
  timestamp: string;
  category: SimulationEventCategory;
  title: string;
  description: string;
  actorName?: string;
  impactNotes?: string;
}

export type ActionAgencyType =
  | 'DIÁLOGO'
  | 'MOVIMIENTO'
  | 'INTERACCIÓN'
  | 'EXAMINAR'
  | 'USAR'
  | 'TOMAR'
  | 'ENTREGAR'
  | 'ATACAR'
  | 'DEFENDER'
  | 'HABILIDAD'
  | 'HECHIZO'
  | 'DECISIÓN'
  | 'COMBINACIÓN'
  | 'OOC';

export type AgencyOutcomeStatus =
  | 'ÉXITO'
  | 'FALLO'
  | 'ÉXITO PARCIAL'
  | 'IMPOSIBLE'
  | 'INTERRUMPIDO'
  | 'CONSECUENCIA';

export interface AgencyResolution {
  inputRaw: string;
  intent: string;
  actionType: ActionAgencyType;
  target?: string;
  isOoc: boolean;
  status: AgencyOutcomeStatus;
  checkAttribute?: 'FUE' | 'DES' | 'CON' | 'INT' | 'SAB' | 'CAR';
  attributeValue?: number;
  roll?: number;
  difficultyDc?: number;
  systemResolution: string; // Determinación del motor (resultado pertenece al sistema, intención al usuario)
  npcReaction?: string;
  consequencesSummary?: string;
}

export interface SavedSessionState {
  id: string;
  savedAt: string;
  sessionTitle: string;
  activePlaceId: string;
  selectedNpcId: string;
  position: string;
  posture: string;
  physicalState: string;
  hour: string;
  weather: string;
  protagonistStats: CharacterDerivedStats;
  protagonistAttributes: CharacterAttributes;
  npcAffection: number;
  npcTrust: number;
  npcMood: string;
  objectsState: Record<string, any>;
  eventLogs: SimulationEventEntry[];
  narrativeContinuity: string;
  pendingEvents: string[];
  isCombatActive: boolean;
}

export interface CombatTurnLog {
  id: string;
  turnNumber: number;
  actorName: string;
  actionName: string;
  detail: string;
  damageOrHeal?: number;
  isCritical?: boolean;
}

export interface RoleplaySessionConfig {
  protagonistName: string;
  protagonistTitle: string;
  protagonistHp: number;
  protagonistMaxHp: number;
  protagonistSp: number;
  protagonistMaxSp: number;
  protagonistRole: string;
  storyGenre: StoryGenre;
  storyDepth: StoryDepth;
  ambientNpcDensity: AmbientNpcDensity;
  battleSystemEnabled: boolean;
  activePlaceId: string;
  selectedNpcId: string;
  secondaryNpcIds: string[];
  isBattleActive: boolean;
  battleTurn: 'player' | 'enemy';
  combatLogs: CombatTurnLog[];
}

export interface NsfwConfig {
  isNsfwEnabled: boolean;
  ageConfirmed: boolean;
  // 2.6 Anatomía Íntima & Parámetros Corporales
  areolaColor?: string;
  areolaSize?: string;
  nippleType?: string;
  pubicHairStyle?: string;
  bodySensitivities?: string[]; // Zonas erógenas
  genitalType?: string; // Morfología y tipo de genitales
  genitalSize?: string; // Tamaño / proporción de genitales
  genitalDetails?: string[] | string; // Particularidades íntimas (tersura, pigmentación, piercings, castrado, impotencia, ano-vaginal)
  explicitLingerie?: string[];
  fetishesAndPreferences?: string[];
  // P5.1 Relaciones & Vínculos con Personajes: Personalidad & Dinámica Íntima
  intimatePersonality?: string; // e.g. "Sumisa devota", "Dominante seductora", "Tsundere apasionada", "Tímida curiosa", "Juguetona provocadora"
}

export interface InteractionLogEntry {
  id: string;
  timestamp: string;
  actor: 'user' | 'character' | 'system';
  text: string;
  actionType?: 'touch' | 'talk' | 'undress' | 'gift' | 'system';
  statDeltas?: {
    affection?: number;
    trust?: number;
    arousal?: number;
    resistance?: number;
  };
}

export interface InteractionStats {
  affection: number; // 0 - 100
  trust: number;     // 0 - 100
  arousal: number;   // 0 - 100
  resistance: number;// 0 - 100
  mood: 'Neutral' | 'Complacido' | 'Sonrojado' | 'Avergonzado' | 'Enfadado' | 'Excitado' | 'Sumiso';
  undressedLayers: string[]; // List of removed clothing layer IDs (e.g. 'B1-33', 'B2-A24', 'B5-H22')
  interactionLog: InteractionLogEntry[];
}

export interface SavedPortrait {
  id: string;
  characterName: string;
  characterRace: string;
  imageUrl: string;
  promptUsed: string;
  negativePrompt: string;
  cfgScale: number;
  sampler: string;
  steps: number;
  modelTarget: string;
  timestamp: string;
  isNsfw: boolean;
}

export interface CharacterRelationship {
  id: string;
  targetCharacterId?: string; // ID de personaje guardado en la biblioteca
  targetCharacterName: string; // Nombre del personaje objetivo
  relationshipType: string; // e.g. Aliado de confianza, Rival jurado, Sirviente → Maestro, etc.
  interactionDynamic: string; // Forma de interactuar y hablarle
  feelingsTowards?: string; // Sentimientos hacia el personaje objetivo (admiración, lealtad, temor, etc.)
  opinionOn?: string; // Opinión sobre el personaje objetivo (pensamiento interno / juicio moral)
}

export interface NarrativeTimelineMilestone {
  id?: string;
  era: 'Pasado' | 'Presente' | 'Futuro' | 'Variante Alterna';
  title: string;
  periodOrAge: string;
  summary: string;
  keyEvents: string[];
  psychologicalEvolution: string;
  roleAndAppearanceNote?: string;
  linkedVariantName?: string;
}

export interface CharacterNarrativeTimeline {
  overview: string;
  thematicArc: string;
  pivotalTurningPoints: string[];
  milestones: NarrativeTimelineMilestone[];
  generatedAt?: string;
  focusMode?: string;
}

export interface AdvancedCustomization {
  voiceTone: string; // Tono y timbre de voz
  speechStyle: string; // Forma de hablar y registro lingüístico
  catchphrasesOrIdioms?: string; // Muletillas o expresiones recurrentes
  skills: string[]; // Habilidades (esgrima, medicina, etiqueta, etc.)
  habitsAndMannerisms: string[]; // Hábitos, manías y tics
  specificInteractions: {
    withAuthority: string; // Trato con superiores y jerarquías
    withSubordinates: string; // Trato con aprendices y subordinados
    withPeers?: string; // Trato con compañeros y personas de igual rango
    withFriends?: string; // Trato con amigos y aliados de confianza
    withStrangers: string; // Trato con desconocidos
    withEnemies: string; // Trato con rivales y enemigos
  };
}

export interface SavedCharacterEntry {
  id: string;
  savedAt: string;
  updatedAt: string;
  thumbnailUrl?: string;
  variantGroupId?: string; // ID único para agrupar todas las versiones alternas de un personaje
  variantLabel?: string; // e.g. 'Base' | 'Rol/Vestuario' | 'Futuro' | 'Pasado' | string
  baseCharacterId?: string; // ID del personaje base original si es una variante
  state: CharacterState;
}

export interface OptionItem {
  id: string;
  code: string;
  name: string;
  description: string;
}

export interface EmblemBuilderConfig {
  symbol?: string; // Main figure or symbol (e.g. Águila bicéfala, Dragón heráldico, Pentagrama arcano, etc.)
  frame?: string; // Frame/shield/seal boundary (e.g. Escudo gótico medieval, Círculo de sello arcano con anillos, etc.)
  motto?: string; // Motto, written text, or inscription on the logo/crest/seal (e.g. "Semper Fidelis", "Astra Inclinant")
  supportOrnaments?: string; // Heraldic supports or decorative ornaments (e.g. Ramas de laurel, Alas desplegadas, etc.)
  description?: string; // Free-form detailed written description of how the logo, seal or crest looks
}

export interface GarmentConfig {
  id: string;
  categoryId: string; // B0, B1, B12, B2, B3, B4, B5
  itemId?: string;
  name: string;
  cut: string;
  length: string;
  sleeve: string;
  material: string;
  color: string;
  finish: string;
  details: string[];
  variation: string;
  layer: string;
  location: string[];
  detailLocations: Record<string, string[]>;
  detailColors?: Record<string, string>;
  pattern: string;
  patternDetail: string;
  // Textile Prints & Stamp System (similar to A.2.4.5)
  printTypes?: string[];
  printShapes?: Record<string, string>;
  printColors?: Record<string, string>;
  printLocations?: Record<string, string[]>;
  printTexts?: Record<string, string>; // Inscribed characters/text for calligraphy/typography/runes/kanjis
  printEmblemConfigs?: Record<string, EmblemBuilderConfig>; // Interactive builder config for heraldry/seals/patches
  neckline: string;
  emblem: string;
  emblemConfig?: EmblemBuilderConfig; // Interactive builder config for garment's emblem
  vfx: string;
  // Wear condition and styling mode
  wearCondition?: string;
  wearStyle?: string;
  culturalTradition?: string;
  // B.4 Footwear customizable properties (Suela y Tacón)
  soleType?: string;
  heelType?: string;
  // B.5 Accessory customizable properties
  accessorySubcategory?: string;
  gemType?: string;
  gemColor?: string;
  engraving?: string;
  engravingText?: string;
  sizeScale?: string;
  fitStyle?: string;
  // Specific Coverage & Body Adjustment Zone properties (unique per garment & accessory)
  coverageZones?: string[];
  coverageStyle?: string;
  coverageDetails?: string;
}

export interface MakeupConfig {
  lipstickStyle: string;
  lipstickColor: string;
  lipstickFinish: string;
  blushStyle: string;
  blushColor: string;
  nailStyle: string;
  nailColor: string;
  nailFinish: string;
  eyeshadowStyle: string;
  eyeshadowColor: string;
  eyelinerStyle: string;
  faceAccent: string;
}

export interface RolePieceDetail {
  id: string;
  name: string;
  category?: string;
  slot?: string;
  color?: string;
  length?: string;
  material?: string;
  finish?: string;
  detailLocation?: string;
  detail?: string;
  description?: string;
  customText?: string; // Inscription or characters on the piece
  emblemConfig?: EmblemBuilderConfig; // Crest / seal / logo builder on the piece
}

export interface EquipmentPieceDetail {
  id: string;
  name: string;
  category: 'weapon' | 'item' | 'bag';
  color?: string;
  material?: string;
  finish?: string;
  sizeOrLength?: string;
  detail?: string;
}

export interface OrientalFantasyConfig {
  tradition?: string;
  armorPieces?: string[];
  culturalAccessories?: string[];
  spiritualMotif?: string;
  silkPattern?: string;
  jadeAccentColor?: string;
  energyAura?: string;
  weaponStyle?: string;
}

export interface CharacterIdentity {
  fullName?: string;
  firstName?: string;
  lastName?: string;
  epithetOrTitle?: string;
  gender?: string;
  race?: string;
  subrace?: string;
  ageYears?: string;
  archetypeRole?: string;
  demeanorOrVibe?: string;
}

export interface CharacterState {
  id?: string;
  avatarImageUrl?: string;
  // Identity & Core Profile
  name: string;
  identity?: CharacterIdentity;
  personality: string;
  personalityTraits: string[];
  archetype: string;

  // State 1
  raceGroup: string;
  raceId: string;
  raceName: string;
  subtype: string;
  subtypeName?: string;
  isHybrid?: boolean;
  secondaryRaceGroup?: string;
  secondaryRaceId?: string;
  secondaryRaceName?: string;
  secondarySubtype?: string;
  secondarySubtypeName?: string;
  hybridDominance?: string;
  hybridFeaturesNote?: string;

  // State 2
  anatomy: {
    sexBase: string;
    age: string;
    complexion: string;
    height: string;
    breastDevelopment: string;
    waist: string;
    glutes: string;
    thighs: string;
    skinColor: string;
    lowerBodyStructure?: string;
    chestCore?: string;
    neckFeature?: string;
  };
  facial: {
    headShape: string;
    headWidth: string;
    boneStructure: string;
    eyeColor: string;
    isHeterochromia?: boolean;
    eyeColorRight?: string;
    pupilShape?: string;
    irisGlow?: boolean;
    eyesCategory: string;
    eyesSubtype: string;
    scleraColor?: string;
    facialMorphology?: string;
    facialHair?: string;
    facialHairColor?: string;
    eyeliner: string;
    shadow: string;
    expression: string;
    iris: string;
    nose: string;
    lips: string;
    mouthExp: string;
    mouthSpecial: string;
    tongueType?: string;
    teeth: string;
    mouthCorners: string;
    mouthTexture: string;
    earsBase: string;
    earsLength: string;
    kemonoEars: string;
  };
  hair: {
    texture: string;
    length: string;
    cut: string;
    part: string;
    bangs: string;
    style: string;
    hairColor: string;
    hairElemental?: string;
  };
  appendices: {
    hornsForm: string;
    hornsLength: string;
    hornsThickness: string;
    hornsPosition: string;
    wingsSize: string;
    wingsPosition: string;
    wingsType: string;
    tailsType: string;
    tailsLength: string;
    skinAndMarks: string;
    scaleLocations: string[];
    markTypes: string[];
    markLocations: Record<string, string[]>;
    markShapes: Record<string, string>;
    markColors: Record<string, string>;
    markSecondaryColors?: Record<string, string>;
    markFinishes?: Record<string, string>;
    markTexts?: Record<string, string>;
    markEmblemConfigs?: Record<string, EmblemBuilderConfig>;
    // Tail coloration and finishes
    tailsColorPrimary?: string;
    tailsColorSecondary?: string;
    tailsFinish?: string;
    // Apéndices y rasgos sobrenaturales / animales adicionales
    clawsType?: string;
    pawPads?: string;
    antennaeType?: string;
    antennaeLength?: string;
    antennaePosition?: string;
    extraEyes?: string;
    extraArms?: string;
    specialLimbs?: string;
    lowerBodyStructure?: string;
  };
  makeup?: MakeupConfig;

  // State 3
  wardrobes: GarmentConfig[];

  // State 4
  role: string;
  subRole?: string;
  hybridRoleTitle?: string;
  nobleTitle?: string;
  nobleHouseOrDomain?: string;
  styleVisual: string;
  subStyleVisual?: string;
  styleFusionTitle?: string;
  armor: {
    type: string;
    pieces: string[];
    material: string;
    finish: string;
    specialType?: string;
    pieceDetails?: Record<string, RolePieceDetail>;
  };
  equipment: {
    weapons: string[];
    weaponGrips: string[];
    bags: string[];
    bagSizes: string[];
    bagClosures: string[];
    items: string[];
    equipmentDetails?: Record<string, EquipmentPieceDetail>;
  };
  orientalFantasy?: OrientalFantasyConfig;

  // State 5
  background: {
    homelandOrDomain?: string;
    factionOrFaith?: string;
    languages?: string[];
    fatalFlawOrVulnerability?: string;
    fatalFlaws?: string[];
    relationships?: CharacterRelationship[];
    backstory: string;
    motivation: string;
    advancedCustomization?: AdvancedCustomization;
    secret?: string;
    coreValues: string;
    narrativeTimeline?: CharacterNarrativeTimeline;
    uniqueDetails?: string[];
    userNarrativeNotes?: string;
  };

  narrativeTimeline?: CharacterNarrativeTimeline;

  // State 6 & 7
  validationLogs: string[];

  // Alternate Versions & Grouping
  variantGroupId?: string;
  variantLabel?: string;
  baseCharacterId?: string;

  // Elysium: Modo R+18 & Simulador de Vínculo
  nsfw?: NsfwConfig;
  interactionStats?: InteractionStats;
  liteAgent?: LiteAgentConfig;
  aiTraining?: CharacterAITrainingConfig;

  // Elysium V1.1 Arquitectura & Relaciones de Objetos
  version?: string; // v1.0, v1.1, etc.
  versionHistory?: Array<{ version: string; date: string; note: string; stateSnapshot?: any }>;
  linkedWorldId?: string;
  linkedPlaceId?: string;
  linkedHousingId?: string;
  linkedFactionId?: string;
  associatedCharacterIds?: string[];
  attributes?: CharacterAttributes;
  derivedStats?: CharacterDerivedStats;
}
