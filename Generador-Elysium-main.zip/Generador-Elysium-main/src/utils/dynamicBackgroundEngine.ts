import { CharacterRelationship, AdvancedCustomization } from '../types';
import { RoleRelationshipSuggestion, RoleBehaviorByRank, getRoleBackgroundData } from '../data/roleBackgroundData';

export interface DynamicModulationResult {
  customSuggestedRelationships: (RoleRelationshipSuggestion & { synergyTags?: string[] })[];
  adaptedRelationships: (RoleRelationshipSuggestion & { synergyTags?: string[] })[];
  adaptedBehaviors: {
    withAuthority: string;
    withPeers: string;
    withFriends: string;
    withSubordinates: string;
    withStrangers: string;
    withEnemies: string;
  };
  behaviorSuggestionsByRank: {
    withAuthority: { text: string; tag: string }[];
    withPeers: { text: string; tag: string }[];
    withFriends: { text: string; tag: string }[];
    withSubordinates: { text: string; tag: string }[];
    withStrangers: { text: string; tag: string }[];
    withEnemies: { text: string; tag: string }[];
  };
  adaptedVoiceTone?: string;
  adaptedSpeechStyle?: string;
  adaptedCatchphrase?: string;
  suggestedCatchphrases: string[];
  suggestedVoiceTones: { tone: string; reason: string }[];
  suggestedSpeechStyles: { style: string; reason: string }[];
  adaptedHabits: string[];
  suggestedHabits: { habit: string; trait: string }[];
  synergisticSkills: { skill: string; reason: string; category: string }[];
  personalitySummary: {
    archetypeTitle: string;
    moralAlignment: string;
    interactionSummary: string;
    keyThemes: string[];
  };
}

/**
 * Normalizes trait and value strings for robust matching.
 */
function hasTrait(traits: string[], pattern: RegExp): boolean {
  return traits.some(t => pattern.test(t));
}

function hasValue(coreValues: string | undefined, pattern: RegExp): boolean {
  if (!coreValues) return false;
  return pattern.test(coreValues);
}

/**
 * Computes a psychological profile summary from selected personality traits and core values.
 */
export function analyzePersonalityAndValues(
  personalityTraits: string[] = [],
  coreValues: string = ''
) {
  const traits = personalityTraits.length > 0 ? personalityTraits : ['Equilibrado'];
  const values = coreValues ? coreValues.split(',').map(s => s.trim()).filter(Boolean) : ['Honor', 'Deber'];

  // Psychological Archetype calculation
  let archetypeTitle = 'Carácter Equilibrado';
  let moralAlignment = 'Neutral / Pragmático';
  let interactionSummary = 'Trato medido y adaptativo.';

  const isNobleComp = hasTrait(traits, /compasivo|noble|protector|humilde|idealista|leal/i) || hasValue(coreValues, /justicia|paz|redención|protección del débil|amistad|familia/i);
  const isDarkArrogant = hasTrait(traits, /arrogante|ambicioso|calculador|maligno|vengativo|cínico/i) || hasValue(coreValues, /poder|venganza|ambición desmedida|caos/i);
  const isRebelChaotic = hasTrait(traits, /rebelde|impulsivo|audaz|intrépido|sarcástico|excéntrico/i) || hasValue(coreValues, /libertad|soberanía individual|caos|independencia/i);
  const isStoicDisciplined = hasTrait(traits, /estoico|serio|perfeccionista|meticuloso|flemático|solitario/i) || hasValue(coreValues, /orden|disciplina férrea|deber|equilibrio cósmico|verdad/i);
  const isCharmingSocial = hasTrait(traits, /carismático|seductor|alegre|hedonista|teatral|soñador/i) || hasValue(coreValues, /gloria|legado inmortal|innovación tecnológica/i);
  
  // Categorías enriquecidas
  const isDarkEdgy = hasTrait(traits, /sádico|despiadado|nihilista|tóxico|tenebroso|dolor|obsesivo|traidor|vampírico|maligno/i) || hasValue(coreValues, /nihilismo|poder maldito|venganza sangrienta|corrupción|inmortalidad|ruptura del tabú/i);
  const isSexyProvocative = hasTrait(traits, /seductor|provocador|coqueto|dominante|sensual|insinuante|descarado|insaciable/i) || hasValue(coreValues, /placer|deseo prohibido|posesión|dominación|seducción|sumisión devota/i);
  const isCyberModern = hasTrait(traits, /cínico digital|pragmático corporativo|hacker|nómada urbano|desapegado/i) || hasValue(coreValues, /ciber|innovación tecnológica|libertad de la red|corporativo|anonimato digital/i);
  const isAnimeGacha = hasTrait(traits, /tsundere|yandere|mesugaki|kuudere|chuunibyou|gyaru|ojou-sama|overpowered/i) || hasValue(coreValues, /destino ineludible|invocador|master|waifu|husbandu|linaje oculto|ssr/i);

  if (isDarkEdgy && isSexyProvocative) {
    archetypeTitle = 'Femme Fatale / Súcubo Aristócrata';
    moralAlignment = 'Caótico Malvado / Placer Prohibido';
    interactionSummary = 'Provocación magnética y peligro letal; desarma a sus presas con caricias de terciopelo y veneno sutil.';
  } else if (isDarkEdgy) {
    archetypeTitle = 'Soberano del Abismo / Antihéroe Oscuro';
    moralAlignment = 'Neutral Malvado / Edgy Implacable';
    interactionSummary = 'Frialdad gélida, desprecio por la debilidad y fascinación por el poder destructivo absoluto.';
  } else if (isSexyProvocative) {
    archetypeTitle = 'Tentador/a Irresistible / Dominatriz';
    moralAlignment = 'Caótico Neutral / Seducción Pura';
    interactionSummary = 'Juego constante de miradas, invasión sensual del espacio personal y control psicológico a través del deseo.';
  } else if (isCyberModern) {
    archetypeTitle = 'Netrunner Urbano / Ciber-Infiltrador';
    moralAlignment = 'Caótico Neutral / Nómada Digital';
    interactionSummary = 'Sarcasmo pragmático, rapidez de reflejos sinápticos y desconfianza absoluta hacia el sistema corporativo.';
  } else if (isAnimeGacha) {
    archetypeTitle = 'Entidad Icónica de Gacha SSR';
    moralAlignment = 'Variable Canónico / Tropes Anime';
    interactionSummary = 'Personalidad vibrante y marcada (Tsundere / Yandere / Mesugaki) con poses dramáticas y devoción extrema.';
  } else if (isNobleComp && isStoicDisciplined) {
    archetypeTitle = 'Guardián del Deber y la Virtud';
    moralAlignment = 'Legal Bueno / Protector Incondicional';
    interactionSummary = 'Serenidad honorable, benevolencia prudente y estricto cumplimiento del deber moral.';
  } else if (isDarkArrogant && isStoicDisciplined) {
    archetypeTitle = 'Estratega Hegemónico';
    moralAlignment = 'Legal Maligno / Pragmático Absoluto';
    interactionSummary = 'Cortesía fría y calculadora; evalúa a los demás como piezas en un tablero de poder.';
  } else if (isRebelChaotic && isNobleComp) {
    archetypeTitle = 'Justiciero Rebelde';
    moralAlignment = 'Caótico Bueno / Libertador';
    interactionSummary = 'Desafío audaz ante tiranías, cercanía cálida con los oprimidos e ironía ante los poderosos.';
  } else if (isDarkArrogant && isRebelChaotic) {
    archetypeTitle = 'Azote Indómito';
    moralAlignment = 'Caótico Maligno / Disyuntivo';
    interactionSummary = 'Impredecible, fiero y altivo; solo respeta el poderío y castiga cualquier muestra de debilidad.';
  } else if (isCharmingSocial) {
    archetypeTitle = 'Figura Magnética e Inspiradora';
    moralAlignment = 'Neutral Bueno / Carismático';
    interactionSummary = 'Presencia deslumbrante, elocuencia seductora y facilidad para crear lealtades y alianzas.';
  } else if (isNobleComp) {
    archetypeTitle = 'Alma Compasiva y Leal';
    moralAlignment = 'Bueno / Empático';
    interactionSummary = 'Empatía transparente, fidelidad a toda prueba y protección instintiva a quienes ama.';
  } else if (isStoicDisciplined) {
    archetypeTitle = 'Pilar Estoico';
    moralAlignment = 'Neutral Puro / Inflexible';
    interactionSummary = 'Laconismo, rigor absoluto, contención emocional y juicio basado en la evidencia.';
  }

  const keyThemes: string[] = [
    ...traits.slice(0, 3).map(t => `Rasgo: ${t}`),
    ...values.slice(0, 2).map(v => `Valor: ${v}`)
  ];

  return {
    archetypeTitle,
    moralAlignment,
    interactionSummary,
    keyThemes
  };
}

/**
 * Returns dynamic suggested feelings towards a target character given the relationship type,
 * archetype, personality traits, and core values.
 */
export function getDynamicFeelingsSuggestions(
  relType: string,
  archetype?: string,
  personalityTraits: string[] = [],
  coreValues: string = ''
): string[] {
  const traits = personalityTraits || [];
  const typeLower = (relType || '').toLowerCase();

  const isServantToMaster = typeLower.includes('sirviente → maestro') || (typeLower.includes('sirviente') && !typeLower.includes('maestro → sirviente'));
  const isMasterToServant = typeLower.includes('maestro → sirviente') || typeLower.includes('amo') || typeLower.includes('señor');
  const isMentorToApprentice = typeLower.includes('mentor') && typeLower.includes('aprendiz') && !typeLower.startsWith('aprendiz');
  const isApprenticeToMentor = typeLower.startsWith('aprendiz');
  const isRival = typeLower.includes('rival') || typeLower.includes('némesis') || typeLower.includes('competidor');
  const isFriendOrPeer = typeLower.includes('amigo') || typeLower.includes('compañero') || typeLower.includes('camarada') || typeLower.includes('igual rango') || typeLower.includes('aliado');
  const isRomantic = typeLower.includes('romántico') || typeLower.includes('enamorado') || typeLower.includes('amante');
  const isVariantRoleOutfit = typeLower.includes('rol/vestuario') || typeLower.includes('rol / vestuario') || typeLower.includes('vestuario');
  const isVariantFuture = typeLower.includes('futuro');
  const isVariantPast = typeLower.includes('pasado');

  const suggestions: string[] = [];

  const mainVal = coreValues ? coreValues.split(',')[0].trim() : 'Honor';

  if (isVariantRoleOutfit) {
    suggestions.push('Fascinación y curiosidad al contemplar su reflejo portando ropajes y armas de otra senda o disciplina.');
    suggestions.push(`Respeto por la versatilidad de su propia esencia adaptada a otro oficio bajo el ideal de ${mainVal}.`);
    suggestions.push('Complicidad instintiva y comparación amigable de técnicas, posturas y atuendo.');
    suggestions.push('Extrañeza al notar cómo un cambio de vestimenta y rol altera la percepción de quienes le rodean.');
  } else if (isVariantFuture) {
    suggestions.push('Asombro reverencial y aprensión ante las cicatrices, sabiduría y peso del destino que porta su yo futuro.');
    suggestions.push(`Determinación férrea de superar las advertencias temporales y forjar su porvenir con ${mainVal}.`);
    suggestions.push('Melancolía y respeto absoluto hacia la madurez y los sacrificios consumados en el porvenir.');
    suggestions.push('Deseo de demostrar que está preparado/a para alcanzar y trascender ese horizonte temporal.');
  } else if (isVariantPast) {
    suggestions.push('Nostalgia agridulce y ternura protectora hacia la inocencia, arrojo y juventud de su yo del pasado.');
    suggestions.push(`Deseo imperioso de guiarle y ahorrarle los errores y dolores para preservar su fe en ${mainVal}.`);
    suggestions.push('Orgullo al recordar la chispa inicial de pasión y pureza que dio origen a su leyenda.');
    suggestions.push('Firmeza pedagógica para templar su ímpetu juvenil sin apagar su determinación intrínseca.');
  } else if (isServantToMaster) {
    if (hasTrait(traits, /leal|protector|noble|compasivo/i)) {
      suggestions.push(`Devoción inquebrantable consagrada al principio de ${mainVal}; daría su vida sin vacilar.`);
      suggestions.push('Afecto filial reverente y profunda gratitud por la confianza depositada en su servicio.');
    }
    if (hasTrait(traits, /arrogante|rebelde|cínico|orgulloso|astuto/i)) {
      suggestions.push('Obediencia impecable en apariencia, pero orgullo contenido y deseo de demostrar su propia valía.');
      suggestions.push('Pacto de mutua conveniencia: respeta su estatus solo mientras sirva a sus propios fines.');
    }
    if (hasTrait(traits, /estoico|meticuloso|serio/i)) {
      suggestions.push('Sumisión profesional milimétrica, priorizando el deber y la discreción absoluta por encima de emociones.');
    }
    suggestions.push('Veneración contenida y celo protector ante cualquier amenaza que ronde a su señor/a.');
  } else if (isMasterToServant) {
    if (hasTrait(traits, /arrogante|calculador|ambicioso|severo/i)) {
      suggestions.push('Condescendencia pragmática: le considera un instrumento valioso cuya lealtad debe ser recompensada con firmeza.');
      suggestions.push('Exigencia de perfección absoluta sin margen de error; castigo severo ante la negligencia.');
    }
    if (hasTrait(traits, /compasivo|noble|protector|humilde/i)) {
      suggestions.push(`Afecto sincero y consideración humana guiada por la ${mainVal}; le trata como a su propia sangre.`);
      suggestions.push('Preocupación protectora por su fatiga e integridad física en momentos de peligro.');
    }
    suggestions.push('Autoridad serena y confianza delegada para asuntos de máxima confidencialidad.');
  } else if (isApprenticeToMentor) {
    if (hasTrait(traits, /rebelde|impulsivo|audaz|intrépido/i)) {
      suggestions.push('Admiración profunda combinada con impaciencia por superar sus límites y recibir su reconocimiento.');
      suggestions.push('Desafío constante a sus dogmas buscando forjar su propio sendero independiente.');
    } else {
      suggestions.push(`Veneración filial y búsqueda continua de sabiduría basada en ${mainVal}.`);
      suggestions.push('Miedo reverente a fallar y a no ser digno/a de portar su legado.');
    }
  } else if (isMentorToApprentice) {
    if (hasTrait(traits, /compasivo|protector|noble/i)) {
      suggestions.push('Paciencia paternal/maternal, orgullo silencioso al ver su evolución y deseo de evitarle sufrimientos.');
    } else if (hasTrait(traits, /exigente|estoico|perfeccionista/i)) {
      suggestions.push('Rigor espartano y disciplina sin concesiones para templar su espíritu ante la dureza del mundo.');
    } else {
      suggestions.push('Orgullo de maestro y vigilancia constante para guiar su potencial en la dirección correcta.');
    }
  } else if (isRival) {
    if (hasTrait(traits, /noble|caballero|leal|estoico/i) || hasValue(coreValues, /honor|justicia/i)) {
      suggestions.push(`Respeto marcial inmenso y honor mutuo; defendería su vida contra cobardes para batirse en un duelo justo.`);
      suggestions.push('Adrenalina electrizante y fascinación táctica cada vez que sus miradas se cruzan.');
    } else if (hasTrait(traits, /vengativo|maligno|arrogante|cínico/i) || hasValue(coreValues, /venganza|poder/i)) {
      suggestions.push('Odio visceral y desprecio implacable; ansias de destruir su reputación y quebrar su orgullo.');
      suggestions.push('Rencor abrasador alimentado por antiguas derrotas que solo su sangre podrá borrar.');
    } else {
      suggestions.push('Competitividad feroz con pullas continuas, pero complicidad tácita en situaciones de supervivencia.');
    }
  } else if (isRomantic) {
    if (hasTrait(traits, /tímido|melancólico|reservado|estoico/i)) {
      suggestions.push('Atracción magnética inconfesable con rubor contenido y celoso pudor emocional.');
    } else if (hasTrait(traits, /seductor|carismático|audaz/i)) {
      suggestions.push('Pasión abierta y juego de seducción con galantería atrevida y protección ferviente.');
    } else {
      suggestions.push(`Ternura profunda, lealtad absoluta y vulnerabilidad emocional consagrada a ${mainVal}.`);
    }
  } else if (isFriendOrPeer) {
    if (hasTrait(traits, /sarcástico|rebelde|alegre/i)) {
      suggestions.push('Camaradería socarrona llena de bromas punzantes, pero dispuesto/a a cruzar el infierno para salvarle.');
    } else {
      suggestions.push(`Fraternidad incondicional, confianza ciega y sincronización marcial forjada en la ${mainVal}.`);
    }
  } else if (typeLower.includes('yandere') || typeLower.includes('obsesión')) {
    suggestions.push('Obsesión posesiva asfixiante: si no puede tenerlo/a en exclusiva, prefiere destruir el mundo entero.');
    suggestions.push('Celo homicida hacia cualquier mirada o roce ajeno dirigido a su persona amada.');
    suggestions.push('Éxtasis sangriento al derramar su propia sangre o la de sus rivales por su devoción.');
  } else if (typeLower.includes('mascota') || typeLower.includes('dominante') || typeLower.includes('verdugo')) {
    suggestions.push('Placer sádico en someter su voluntad y ver cómo acata cada orden con mirada suplicante.');
    suggestions.push('Sumisión devota: siente fascinación por el poder de su amo/a y busca complacerle sin reservas.');
    suggestions.push('Tensión de presa y depredador en un juego psicológico donde las cadenas son irresistibles.');
  } else if (typeLower.includes('placer') || typeLower.includes('súcubo') || typeLower.includes('tensión sexual') || typeLower.includes('cortesana')) {
    suggestions.push('Deseo ardiente y lujuria inconfesada enmascarada tras comentarios mordaces y roces sugerentes.');
    suggestions.push('Fascinación carnal hipnótica: cada encuentro es un pulso sensual cargado de provocación.');
    suggestions.push('Placer en hacerle perder la compostura mediante susurros al oído y miradas bajo las pestañas.');
  } else if (typeLower.includes('netrunner') || typeLower.includes('contrabando') || typeLower.includes('cibernético') || typeLower.includes('fixer')) {
    suggestions.push('Respeto pragmático callejero: la única persona en la megaciudad que jamás le vendería por créditos.');
    suggestions.push('Dependencia operativa sináptica: su interfaz neuronal se siente vacía sin su señal de enlace.');
    suggestions.push('Pacto de lealtad en las sombras del asfalto frente a la opresión corporativa.');
  } else if (typeLower.includes('master') || typeLower.includes('ssr') || typeLower.includes('invocador')) {
    suggestions.push('Devoción absoluta de unidad SSR legendaria: consagrará su poder celestial al servicio de su Master.');
    suggestions.push('Vínculo de maná irrompible sellado por el destino y las estrellas.');
    suggestions.push('Orgullo de guerrero mítico dispuesto a desatar su Burst Definitivo por la victoria de su invocador.');
  } else if (typeLower.includes('mesugaki') || typeLower.includes('senpai') || typeLower.includes('tsundere')) {
    suggestions.push('Burlas incesantes («¡Za~ko!»): deleite travieso en sonrojarle y llamarle debilucho, ocultando cariño.');
    suggestions.push('Tsunderismo en negación: se enfurruña y grita que le estorba, pero no se aparta jamás de su lado.');
    suggestions.push('Provocación descarada combinada con un secreto anhelo de que le dé una palmada en la cabeza.');
  }

  // General fallbacks
  if (suggestions.length < 3) {
    suggestions.push(`Respeto mutuo y pacto tácito de colaboración orientado a defender el valor de ${mainVal}.`);
    suggestions.push('Vigilancia prudente con disposición al diálogo mientras no se traicionen los principios compartidos.');
    suggestions.push('Aprecio sobrio y profesional cimentado en la resolución conjunta de adversidades.');
  }

  return suggestions;
}

/**
 * Returns dynamic suggested internal opinion on target character based on traits and core values.
 */
export function getDynamicOpinionSuggestions(
  relType: string,
  archetype?: string,
  personalityTraits: string[] = [],
  coreValues: string = '',
  targetName?: string
): string[] {
  const tName = targetName?.trim() || 'este personaje';
  const traits = personalityTraits || [];
  const typeLower = (relType || '').toLowerCase();
  const mainVal = coreValues ? coreValues.split(',')[0].trim() : 'la verdad';

  const isServantToMaster = typeLower.includes('sirviente → maestro') || (typeLower.includes('sirviente') && !typeLower.includes('maestro → sirviente'));
  const isMasterToServant = typeLower.includes('maestro → sirviente') || typeLower.includes('amo') || typeLower.includes('señor');
  const isRival = typeLower.includes('rival') || typeLower.includes('némesis');
  const isFriend = typeLower.includes('amigo') || typeLower.includes('compañero') || typeLower.includes('aliado') || typeLower.includes('igual rango');
  const isVariantRoleOutfit = typeLower.includes('rol/vestuario') || typeLower.includes('rol / vestuario') || typeLower.includes('vestuario');
  const isVariantFuture = typeLower.includes('futuro');
  const isVariantPast = typeLower.includes('pasado');

  const opinions: string[] = [];

  if (isVariantRoleOutfit) {
    opinions.push(`«Ver a mi otro yo consagrado/a a ese rol y atuendo me recuerda que la esencia trasciende la forma externa.»`);
    opinions.push(`«Una faceta alternativa de mi propia alma; sus técnicas y ropajes difieren, pero nuestro núcleo de ${mainVal} permanece inalterable.»`);
    opinions.push(`«Porta ese equipamiento con una maestría y aplomo que no puedo evitar admirar con orgullo.»`);
  } else if (isVariantFuture) {
    opinions.push(`«${tName} carga en su mirada el peso de batallas que aún no he librado; no defraudaré el sendero que me aguarda.»`);
    opinions.push(`«Un faro de lo que puedo llegar a ser si mantengo la disciplina y la fidelidad incondicional a ${mainVal}.»`);
    opinions.push(`«Sus advertencias son severas y sombrías, pero forjaré mi propio destino sin sucumbir a sus temores.»`);
  } else if (isVariantPast) {
    opinions.push(`«${tName} aún no conoce la traición ni la pérdida desgarradora; protegeré sus pasos desde las sombras para que conserve su pureza.»`);
    opinions.push(`«Un recordatorio vivo e inspirador de las razones iniciales por las que juré consagrar mi vida a ${mainVal}.»`);
    opinions.push(`«Veo en sus ojos la misma llama indómita que forjó mi presente; su ímpetu merece ser guiado con paciencia.»`);
  } else if (isServantToMaster) {
    opinions.push(`«${tName} encarna el propósito de mi existencia; mientras guíe sus pasos con ${mainVal}, mi brazo jamás vacilará.»`);
    opinions.push(`«Es un/a señor/a de gran visión, pero sus debilidades humanas requieren que yo sea su escudo más impenetrable.»`);
    opinions.push(`«Su autoridad me protege de un mundo hostil; servirle con excelencia es mi mejor garantía de triunfo.»`);
  } else if (isMasterToServant) {
    opinions.push(`«${tName} es la mano invisible que hace posible mi destino; un apoyo leal que cuidaré con la severidad y el honor que merece.»`);
    opinions.push(`«Un colaborador indispensable cuya discreción vale más que cien cofres de oro puro.»`);
    opinions.push(`«Mientras mantenga su lealtad consagrada a ${mainVal}, jamás le faltará mi amparo ni mi espada.»`);
  } else if (isRival) {
    if (hasTrait(traits, /noble|estoico|caballero/i) || hasValue(coreValues, /honor|justicia/i)) {
      opinions.push(`«${tName} es el único oponente digno de mi respeto; enfrentarle es el crisol donde forjo mi propia grandeza.»`);
      opinions.push(`«Nuestras espadas chocan por causas opuestas, pero su integridad marcial honra el campo de batalla.»`);
    } else {
      opinions.push(`«${tName} pagará muy caro su insolencia; su derrota total será el testimonio ineludible de mi superioridad.»`);
      opinions.push(`«Un obstáculo peligroso en mi sendero hacia ${mainVal}; debo neutralizar su influencia sin titubeos.»`);
    }
  } else if (isFriend) {
    opinions.push(`«${tName} es de las contadísimas personas ante quienes no necesito portar máscara ni armadura emocional.»`);
    opinions.push(`«A su lado cualquier tormenta es soportable; compartimos una fe inquebrantable en ${mainVal}.»`);
    opinions.push(`«A veces me desquicia su temperamento, pero no confiaría mi retaguardia a nadie más en este mundo.»`);
  } else if (typeLower.includes('yandere') || typeLower.includes('obsesión')) {
    opinions.push(`«${tName} me pertenece en cuerpo y alma; quien intente apartarle de mi lado terminará enterrado bajo tierra.»`);
    opinions.push(`«Es la luz que me salva y la oscuridad que me consume; su existencia es mi única religión.»`);
    opinions.push(`«Nadie más sabe apreciar lo especial que es; por eso debo protegerle de todas las miradas impuras.»`);
  } else if (typeLower.includes('mascota') || typeLower.includes('dominante') || typeLower.includes('verdugo')) {
    opinions.push(`«${tName} luce fascinante cuando agacha la mirada y reconoce mi autoridad indiscutible.»`);
    opinions.push(`«Un juguete precioso cuyo valor aumenta cuanto más se resiste a admitir cuánto desea obedecer.»`);
    opinions.push(`«Su lealtad se ha forjado a base de disciplina y recompensas exclusivas; no toleraré la menor insolencia.»`);
  } else if (typeLower.includes('placer') || typeLower.includes('súcubo') || typeLower.includes('tensión sexual') || typeLower.includes('cortesana')) {
    opinions.push(`«${tName} intenta fingir frialdad, pero sus latidos desbocados y su respiración entrecortada delatan su debilidad.»`);
    opinions.push(`«Una tentación exquisita a la que resulta delicioso atormentar con caricias y palabras al oído.»`);
    opinions.push(`«Jugar con fuego a su lado es el único vicio que jamás me cansaré de disfrutar.»`);
  } else if (typeLower.includes('netrunner') || typeLower.includes('contrabando') || typeLower.includes('cibernético') || typeLower.includes('fixer')) {
    opinions.push(`«${tName} tiene el mejor pulso de la red; si los agentes corporativos nos pisan los talones, es la única llamada que haría.»`);
    opinions.push(`«En un mundo de cromo falso y traiciones, su palabra callejera vale más que cualquier contrato con megacorpos.»`);
    opinions.push(`«Compartimos demasiados secretos sucios como para no cuidarnos las espaldas en este tiroteo.»`);
  } else if (typeLower.includes('master') || typeLower.includes('ssr') || typeLower.includes('invocador')) {
    opinions.push(`«${tName} es el Master que el destino me otorgó; mi invocación SSR desatará el fin del mundo por su causa.»`);
    opinions.push(`«A veces parece frágil, pero su determinación en batalla despierta cada runa dormida en mi linaje celestial.»`);
    opinions.push(`«Mientras su maná alimente mi núcleo astral, ninguna derrota tocará su estandarte.»`);
  } else if (typeLower.includes('mesugaki') || typeLower.includes('senpai') || typeLower.includes('tsundere')) {
    opinions.push(`«¡${tName} es un/a senpai tan za~ko y torpe! Si no estoy encima burlándome y guiándole, no duraría ni dos días.»`);
    opinions.push(`«Me encanta ver cómo se pone rojo/a de ira cuando le llamo patético/a; ¡su cara de frustración es lo mejor!»`);
    opinions.push(`«¡N-No es como si me importara ${tName}! Solo me aseguro de que nadie más tenga derecho a meterse con él/ella.»`);
  } else {
    opinions.push(`«Un actor crucial en este escenario; su compromiso con ${mainVal} determinará si es un aliado o un adversario.»`);
    opinions.push(`«Alguien de temperamento singular a quien conviene mantener en estrecha observación.»`);
    opinions.push(`«Su temple me inspira a mantenerme firme en mis propias convicciones sin ceder ante la presión.»`);
  }

  return opinions;
}

/**
 * Generates rich archetype-adapted canonical relationships and behaviors based on
 * (Archetype, Personality Traits, Core Values, Role).
 */
export function generateArchetypeAdaptedBackground(
  roleName: string,
  archetype: string,
  personalityTraits: string[] = [],
  coreValues: string = ''
): DynamicModulationResult {
  const baseProfile = getRoleBackgroundData(roleName);
  const traits = personalityTraits.length > 0 ? personalityTraits : ['Equilibrado', 'Leal'];
  const vals = coreValues || 'Honor, Deber y Justicia';
  const valList = vals.split(',').map(s => s.trim()).filter(Boolean);
  const mainVal = valList[0] || 'Honor';
  const secVal = valList[1] || 'Lealtad';

  const isArrogant = hasTrait(traits, /arrogante|orgulloso|altivo|tirano|ambicioso|calculador/i);
  const isCompassionate = hasTrait(traits, /compasivo|noble|protector|bondadoso|amable|humilde/i);
  const isStoic = hasTrait(traits, /estoico|serio|frío|calmado|meticuloso|perfeccionista/i);
  const isSarcastic = hasTrait(traits, /sarcástico|cínico|burlón|rebelde/i);
  const isCharismatic = hasTrait(traits, /carismático|seductor|alegre|teatral|audaz/i);
  const isVengeful = hasTrait(traits, /vengativo|maligno|agresivo|impulsivo/i);
  const isDarkEdgy = hasTrait(traits, /sádico|despiadado|nihilista|tóxico|tenebroso|dolor|obsesivo|traidor|vampírico|maligno/i) || /villana|vampiro|nigromante|corrupto|oscura|abismo|edgy/i.test(archetype);
  const isSexyProvocative = hasTrait(traits, /seductor|provocador|coqueto|dominante|sensual|insinuante|descarado|insaciable/i) || /femme fatale|súcubo|dominatriz|coqueta|mesugaki/i.test(archetype);
  const isCyberModern = hasTrait(traits, /cínico digital|pragmático corporativo|hacker|nómada urbano|desapegado/i) || /netrunner|cyberpunk|spec-ops|streamer/i.test(archetype);
  const isAnimeGacha = hasTrait(traits, /tsundere|yandere|mesugaki|kuudere|chuunibyou|gyaru|ojou-sama|overpowered/i) || /gacha|mesugaki|yandere|chuunibyou|tsundere|kuudere|ssr|villana de gacha|kouhai|senpai/i.test(archetype);
  const isKouhai = /kouhai/i.test(archetype);
  const isSenpai = /senpai/i.test(archetype);

  // 1. DYNAMIC RELATIONSHIPS GENERATION
  const customSuggestedRelationships: (RoleRelationshipSuggestion & { synergyTags?: string[] })[] = [];

  // Kouhai dynamic
  if (isKouhai) {
    customSuggestedRelationships.push({
      targetCharacterName: 'Senpai Admirado/a / Superior Favorito',
      relationshipType: 'Kouhai Consentida/o ↔ Senpai Protector/a',
      interactionDynamic: 'Petición constante de ayuda con sonrisas traviesas, buscando llamar su atención y provocando pucheros fingidos.',
      roleHint: 'Senpai / Modelo a Seguir',
      feelingsTowards: 'Admiración devota y afecto travieso; le encanta ver las reacciones de Senpai cuando le toma por sorpresa.',
      opinionOn: '«¡Senpai siempre finge que le molesto, pero sé que en el fondo no puede apartar los ojos de mí!»',
      synergyTags: ['Kouhai & Senpai', 'Arquetipo: Kouhai', 'Dinámica Escolar/Gremial']
    });
  }

  // Senpai dynamic
  if (isSenpai) {
    customSuggestedRelationships.push({
      targetCharacterName: 'Kouhai Traviesa / Aprendiz a Cargo',
      relationshipType: 'Kouhai Consentida/o ↔ Senpai Protector/a',
      interactionDynamic: 'Suspiros de paciencia fingida ante sus travesuras, corrigiendo sus errores con mirada severa pero manos protectoras.',
      roleHint: 'Kouhai / Menor a Proteger',
      feelingsTowards: 'Responsabilidad inquebrantable y cariño fraternal protector; vigila su bienestar incluso en silencio.',
      opinionOn: '«Es ruidoso/a y revoltoso/a, pero tiene un potencial enorme; es mi deber como Senpai cuidar sus pasos.»',
      synergyTags: ['Kouhai & Senpai', 'Arquetipo: Senpai', 'Guía & Protección']
    });
  }

  // Dark / Sadistic / Obsessive relationship
  if (isDarkEdgy) {
    customSuggestedRelationships.push({
      targetCharacterName: 'Objetivo de Obsesión / Presa Preferida',
      relationshipType: 'Amo/a Dominante ↔ Mascota / Juguete Consentido/a',
      interactionDynamic: 'Mirada posesiva e invasión de su espacio personal, alternando castigos refinados con recompensas exclusivas.',
      roleHint: 'Juguete / Presa Exclusiva',
      feelingsTowards: 'Deseo de posesión absoluta: disfruta viéndole perder el control y doblegarse a su voluntad oscura.',
      opinionOn: '«Nadie más tiene derecho a hacerle sangrar o sonreír; su alma me pertenece por completo.»',
      synergyTags: ['Oscuridad & Posesión', `Rasgo: Sádico/Oscuro`, `Valor: ${mainVal}`]
    });
  }

  // Sexy / Provocative relationship
  if (isSexyProvocative) {
    customSuggestedRelationships.push({
      targetCharacterName: 'Rival Tentador/a con Tensión Prohibida',
      relationshipType: 'Rival Frenemies con Alta Tensión Sexual y Deseo Prohibido',
      interactionDynamic: 'Duelos que parecen danzas eróticas, caricias disimuladas al chocar armas y susurros de doble sentido al oído.',
      roleHint: 'Tentación Prohibida',
      feelingsTowards: 'Atracción magnética irresistible y deleite en ver cómo pierde la compostura ante cada insinuación carnal.',
      opinionOn: '«Finge desdén y rectitud moral, pero sé exactamente qué pensamientos le quitan el sueño cuando estamos a solas.»',
      synergyTags: ['Seducción & Placer', `Rasgo: Provocador/a`, `Valor: Placer/Poder`]
    });
  }

  // Cyber / Modern relationship
  if (isCyberModern) {
    customSuggestedRelationships.push({
      targetCharacterName: 'Operador/a Táctico / Fixer Clandestino',
      relationshipType: 'Netrunner Hacker ↔ Operador Táctico de Enlace en Vivo',
      interactionDynamic: 'Canal de voz encriptado permanente de fondo, advertencias sobre cortafuegos neuronales y humor negro callejero.',
      roleHint: 'Ojos en la Red / Fixer',
      feelingsTowards: 'Confianza de trinchera urbana: la única voz que mantiene anclada su humanidad en la maraña de datos.',
      opinionOn: '«Si la megacorpo nos tiende una emboscada, nos hundiremos quemando servidores juntos con una sonrisa cínica.»',
      synergyTags: ['Ciberespacio & Enlace', `Rasgo: Netrunner`, `Valor: Libertad`]
    });
  }

  // Anime / Gacha relationship
  if (isAnimeGacha) {
    customSuggestedRelationships.push({
      targetCharacterName: 'Master / Invocador/a Legendario/a',
      relationshipType: 'Invocador/a Master ↔ Unidad SSR Devota de Gacha',
      interactionDynamic: 'Acatamiento de comandos de batalla con poses dinámicas espectaculares y devoción incondicional de banner promocional.',
      roleHint: 'Master / Invocador',
      feelingsTowards: 'Fidelidad cósmica sellada por la tirada de invocación; daría cada punto de maná por su victoria absoluta.',
      opinionOn: '«Soy la espada que respondiste al invocar; mientras creas en mí, desataré el poder supremo sobre este mundo.»',
      synergyTags: ['Gacha SSR', `Arquetipo: Legendario`, `Vínculo: Master`]
    });
  }

  // A. Master / Servant Dynamic (Tailored to Role & Traits)
  const isServantRole = /sirviente|maid|mayordomo|guardaespaldas|escudero|asesino|infiltrado/i.test(roleName);
  const isMasterRole = /noble|princesa|aristócrata|rey|reina|comandante|inquisidor|mago de corte|sacerdote/i.test(roleName);

  if (isServantRole || isCompassionate) {
    customSuggestedRelationships.push({
      targetCharacterName: 'Lord / Señora de la Casa Principal',
      relationshipType: 'Sirviente → Maestro (El objetivo es mi Amo / Maestro / Señor)',
      interactionDynamic: isArrogant
        ? 'Reverencia protocolaria impecable, cumpliendo órdenes con altivez contenida y mirada perspicaz.'
        : 'Inclinación reverencial profunda y devoción silenciosa, anticipando sus deseos con solicitud absoluta.',
      roleHint: 'Amo / Señora Principal',
      feelingsTowards: isArrogant
        ? `Lealtad contractual estricta; le sirve con orgullo buscando consolidar su propio prestigio.`
        : `Devoción consagrada y gratitud infinita por guiar su vida bajo los principios de ${mainVal}.`,
      opinionOn: `«Mi vida y mi acero están a su servicio; mientras defienda ${mainVal}, nadie cruzará su umbral.»`,
      synergyTags: [`Rol: ${roleName}`, `Rasgo: ${traits[0] || 'Leal'}`, `Valor: ${mainVal}`]
    });
  }

  if (isMasterRole || isArrogant || isCharismatic) {
    customSuggestedRelationships.push({
      targetCharacterName: 'Mayordomo / Escudero de Confianza',
      relationshipType: 'Maestro → Sirviente (El objetivo es mi Sirviente / Mayordomo / Lacayo)',
      interactionDynamic: isCompassionate
        ? 'Órdenes formuladas con cortesía y tono afectuoso, agradeciendo sus desvelos y cuidando su bienestar.'
        : 'Órdenes tajantes y precisas en voz pausada, esperando excelencia absoluta y discreción inmediata.',
      roleHint: 'Sirviente / Lacayo Personal',
      feelingsTowards: isCompassionate
        ? 'Afecto cercano y consideración protectora como a un miembro entrañable de su propia corte.'
        : 'Aprecio pragmático y exigencia férrea; castigará con dureza a quien intente sobornarle o amedrentarle.',
      opinionOn: `«Un pilar silencioso en quien confío mis secretos más íntimos; su lealtad a ${mainVal} es incalculable.»`,
      synergyTags: [`Rol: ${roleName}`, `Valor: ${mainVal}`, `Rasgo: ${traits[0] || 'Noble'}`]
    });
  }

  // B. Mentor / Apprentice Dynamic
  customSuggestedRelationships.push({
    targetCharacterName: 'Mentor/a Veterano/a del Cónclave',
    relationshipType: 'Mentor/a → Aprendiz (El objetivo es mi Maestro / Mentor)',
    interactionDynamic: isSarcastic
      ? 'Debates afilados y respuestas mordaces durante el adiestramiento, ocultando una profunda admiración filial.'
      : 'Escucha devota con postura marcial y asimilación meticulosa de cada lección táctica.',
    roleHint: 'Guía y Maestro de Vida',
    feelingsTowards: `Veneración reverente y anhelo constante de honrar su enseñanza sobre ${mainVal}.`,
    opinionOn: `«Su ejemplo me enseñó que la fuerza sin ${mainVal} es solo violencia ciega.»`,
    synergyTags: [`Rasgo: ${traits.find(t => /rebelde|sarcástico|noble/i.test(t)) || 'Leal'}`, `Valor: ${mainVal}`]
  });

  // C. Rival / Nemesis Dynamic
  customSuggestedRelationships.push({
    targetCharacterName: 'Campeón/a de la Orden Contraria',
    relationshipType: 'Rival Jurado / Competidor Directo',
    interactionDynamic: (isStoic || isCompassionate)
      ? 'Saludos solemnes de empuñadura antes de cada duelo; combates técnicos sin odio personal pero sin piedad.'
      : 'Provocaciones verbales punzantes, miradas de desafío electrizante y estocadas con intenciones letales.',
    roleHint: 'Némesis en el Campo',
    feelingsTowards: isVengeful
      ? `Rencor implacable por agravios del pasado y obsesión con arrebatarle su gloria ante el mundo.`
      : `Respeto marcial inmenso; considera que su sola presencia es la mayor prueba para su convicción en ${secVal}.`,
    opinionOn: isVengeful
      ? `«Su caída será el testimonio definitivo de mi poderío; ningún pacto salvará su cuello.»`
      : `«Un adversario formidable cuyo temple me obliga a superarme en cada encuentro.»`,
    synergyTags: [`Rasgo: ${isVengeful ? 'Vengativo' : (isStoic ? 'Estoico' : 'Competitivo')}`, `Valor: ${secVal}`]
  });

  // D. Loyal Shield-Brother / Peer Dynamic
  customSuggestedRelationships.push({
    targetCharacterName: 'Compañero/a de Escuadrón de Igual Rango',
    relationshipType: 'Compañero/a de Armas / Igual Rango',
    interactionDynamic: isSarcastic
      ? 'Intercambio constante de pullas mordaces en el campamento, pero coordinación telepática al desenvainar.'
      : 'Camaradería cordial, respeto profesional y cobertura mutua de espaldas en combate cerrado.',
    roleHint: 'Camarada Par',
    feelingsTowards: `Fraternidad indestructible y lealtad absoluta nacida de juramentos compartidos por ${mainVal}.`,
    opinionOn: `«A su lado ninguna batalla parece imposible; confiaría mi vida y mi honor a sus manos sin titubeos.»`,
    synergyTags: [`Rasgo: Camaradería`, `Valor: ${mainVal}`]
  });

  // E. Romantic / Emotional Anchor
  customSuggestedRelationships.push({
    targetCharacterName: 'Vínculo Secreto del Corazón',
    relationshipType: 'Interés Romántico / Vínculo Prohibido',
    interactionDynamic: isStoic
      ? 'Miradas prolongadas y caricias sutiles lejos de los ojos de la corte, manteniendo la compostura en público.'
      : 'Galantería apasionada, sonrisas cómplices y un voto inquebrantable de salvaguardar su destino.',
    roleHint: 'Ancla Emocional Secreta',
    feelingsTowards: `Ternura profunda y anhelo de construir un refugio de paz consagrado al valor de ${secVal}.`,
    opinionOn: `«El recordatorio más puro de por qué empuño las armas y la razón última para regresar con vida.»`,
    synergyTags: [`Rasgo: Afecto Noble`, `Valor: ${secVal}`]
  });

  // 2. DYNAMIC BEHAVIORS MODULATION (6 TIERS)
  let authBehavior = '';
  let peersBehavior = '';
  let friendsBehavior = '';
  let subBehavior = '';
  let strBehavior = '';
  let enmBehavior = '';

  if (isDarkEdgy) {
    authBehavior = `Finge sumisión protocolaria con mirada gélida mientras memoriza sus debilidades para destronarles en el momento oportuno.`;
    peersBehavior = `Trato despectivo y sádico; los considera peones prescindibles y disfruta viendo cómo vacilan bajo presión psicológica.`;
    friendsBehavior = `Posesividad obsesiva y sobreprotectora; quien ose amenazar a su círculo íntimo sufrirá tormentos inimaginables.`;
    subBehavior = `Tiranía implacable y castigo ejemplar ante el menor desliz; gobierna mediante el terror absoluto y la fascinación por el poder.`;
    strBehavior = `Aura intimidante y desinterés helado; evalúa al instante si el recién llegado es una amenaza a erradicar o un sacrificio útil.`;
    enmBehavior = `Crueldad metódica y deleite en su agonía; prolonga el castigo para quebrar su espíritu antes de reclamar su vida.`;
  } else if (isSexyProvocative) {
    authBehavior = `Reverencias con sugerente inclinación y miradas felinas bajo las pestañas, manipulando la vanidad del superior con adulación seductora.`;
    peersBehavior = `Juego continuo de coquetería y pullas con doble sentido; disfruta desestabilizar su concentración y tentar sus límites íntimos.`;
    friendsBehavior = `Afecto descarado con caricias espontáneas y confidencias íntimas sin pudor alguno; lealtad apasionada teñida de picardía.`;
    subBehavior = `Órdenes susurradas con voz dulce pero imperativa, prometiendo recompensas exclusivas a quienes cumplan con sumisa devoción.`;
    strBehavior = `Sonrisa felina irresistible e invasión del espacio personal; desarma cualquier defensa en segundos con su magnetismo carnal.`;
    enmBehavior = `Provocación lasciva en medio del duelo; combate como si fuera una danza erótica letal, burlándose de su incapacidad de resistirse.`;
  } else if (isAnimeGacha) {
    authBehavior = `Acatamiento teatral con poses heroicas de gacha o insolencia infantil de «Za~ko», esperando directrices de su Master con brillo en los ojos.`;
    peersBehavior = `Dinámica clásica de anime: rivalidad tsundere con reproches ruidosos («¡No creas que lo hice por ti!») pero apoyo incondicional.`;
    friendsBehavior = `Devoción absoluta de unidad SSR legendaria; protector/a celoso/a que desatará su máximo poder si tocan a sus camaradas.`;
    subBehavior = `Comportamiento de senpai enérgico o de mesugaki burlona que se mofa de sus errores para empujarles a superarse.`;
    strBehavior = `Presentación extravagante con su título de invocación SSR o pose dramática con mano en el rostro y discurso místico.`;
    enmBehavior = `Discurso dramático previo a su Ultimate Burst: proclama su sentencia y desata su técnica definitiva con efectos cósmicos.`;
  } else if (isCyberModern) {
    authBehavior = `Acatamiento seco y transaccional por canal encriptado; exige los créditos por adelantado y desprecia la burocracia corporativa.`;
    peersBehavior = `Camaradería de asfalto y chips quemados; comunicación por ping neural y reparto equitativo del botín de datos.`;
    friendsBehavior = `Lealtad hermética sin sentimentalismos: si queman tu piso, te abrirá su escondite y sus armas sin hacer preguntas.`;
    subBehavior = `Instrucciones técnicas en jerga ciberpunk; no tolera lentitud de procesamiento ni filtraciones en la red local.`;
    strBehavior = `Escaneo biométrico instantáneo y mano en la funda del arma inteligente; en la megaciudad, todo extraño es un soplón corporativo en potencia.`;
    enmBehavior = `Hackeo neuronal despiadado y sobrecarga de ciberware; fríe sus implantes con un daemon militar mientras les sonríe con cinismo.`;
  } else if (isArrogant) {
    authBehavior = `Cortesía altiva y calculada; solo inclina la cabeza ante quienes demuestran un poder o linaje superior al suyo, guiado por ${mainVal}.`;
    peersBehavior = `Competitividad constante y tono desafiante; trata a sus pares como rivales a superar más que como iguales.`;
    friendsBehavior = `Lealtad feroz pero condescendiente; jamás muestra debilidad ante ellos pero los defenderá con implacable furia.`;
    subBehavior = `Exigencia implacable y disciplina tajante; no tolera errores ni titubeos, premiando solo la eficiencia absoluta.`;
    strBehavior = `Mirada distante y desdeñosa; evalúa el rango, riqueza o peligro potencial antes de dignarse a entablar conversación.`;
    enmBehavior = `Desprecio total y burla refinada; les recuerda su inferioridad en cada cruce de acero sin perder la compostura.`;
  } else if (isCompassionate) {
    authBehavior = `Respeto diplomático sincero, pero con la entereza moral de alzar la voz si las órdenes impartidas atentan contra ${mainVal} o los inocentes.`;
    peersBehavior = `Camaradería cálida, espíritu colaborativo y generosidad; siempre dispuesto/a a compartir honores y escuchar consejos.`;
    friendsBehavior = `Afecto desbordante, confidencias sin secretos y protección incondicional; antepone la seguridad de sus amigos a su propia vida.`;
    subBehavior = `Paciencia pedagógica y cuidado paternal/maternal; enseña con el ejemplo, alienta el crecimiento y protege sus derechos.`;
    strBehavior = `Hospitalidad abierta, tono afable y disposición altruista a brindar auxilio si percibe necesidad o injusticia.`;
    enmBehavior = `Firmeza inflexible en combate para neutralizar la amenaza, pero ofreciendo rendición honorable antes del golpe final.`;
  } else if (isStoic) {
    authBehavior = `Inclinación protocolaria milimétrica y laconismo absoluto; ejecuta directrices con rigor marcial sin emitir quejas ni emociones superfluas.`;
    peersBehavior = `Silencio cómplice y respeto profesional; pocas palabras y máxima efectividad táctica coordinada de igual a igual.`;
    friendsBehavior = `Calidez silenciosa y gestos prácticos de lealtad; demuestra su aprecio mediante actos de protección meticulosa más que con discursos.`;
    subBehavior = `Instrucciones claras, precisas y metódicas con corrección serena; espera autonomía, concentración y apego al deber (${mainVal}).`;
    strBehavior = `Neutralidad impasible y vigilancia constante; analiza puntos de apoyo y armas sin parpadear manteniendo una distancia prudente.`;
    enmBehavior = `Frialdad quirúrgica y letalidad silenciosa; combate sin odio personal pero sin titubeos hasta neutralizar la amenaza por completo.`;
  } else if (isSarcastic) {
    authBehavior = `Reverencias teatralmente exageradas con ironía sutil en cada réplica, rozando con ingenio el límite de la insubordinación aceptable.`;
    peersBehavior = `Intercambio incesante de pullas agudas y apuestas absurdas durante situaciones de alto riesgo, aliviando la tensión con humor negro.`;
    friendsBehavior = `Bromas mordaces pero lealtad a toda prueba; es capaz de insultarte con afecto mientras venda tus heridas mortales.`;
    subBehavior = `Comentarios mordaces sobre sus tropiezos seguidos de consejos prácticos sorprendentemente lúcidos y certeros.`;
    strBehavior = `Preguntas punzantes con sonrisa enigmática para desarmar falsedades y evaluar intenciones ocultas en segundos.`;
    enmBehavior = `Risa socarrona y provocaciones mordaces durante el choque de armas para hacerles perder los estribos y cometer errores fatales.`;
  } else if (isCharismatic) {
    authBehavior = `Elocuencia persuasiva y reverencia galante; sabe ganarse el favor de sus superiores mediante halagos diplomáticos bien medidos.`;
    peersBehavior = `Espíritu festivo y liderazgo natural; une al grupo con anécdotas inspiradoras y genera una atmósfera de camaradería vibrante.`;
    friendsBehavior = `Abrazos efusivos, lealtad apasionada y confidencias compartidas en torno a una copa o un fuego de campamento.`;
    subBehavior = `Inspirador y motivador; alienta su valentía haciéndoles sentir que forman parte de una hazaña legendaria guiada por ${mainVal}.`;
    strBehavior = `Sonrisa magnética y labia envolvente; entabla conversación con facilidad y desarma cualquier recelo en pocos minutos.`;
    enmBehavior = `Duelo con teatralidad y elegancia; combate con estilo deslumbrante buscando que su victoria sea recordada como una obra de arte.`;
  } else {
    // Balanced Fallback
    authBehavior = `Trato protocolario respetuoso y acatamiento disciplinado fundamentado en la búsqueda de ${mainVal}.`;
    peersBehavior = `Cooperación equitativa, respeto mutuo y debate sincero de estrategias de igual a igual.`;
    friendsBehavior = `Confianza sincera, apoyo emocional y compromiso inquebrantable en momentos de crisis.`;
    subBehavior = `Guía firme pero comprensiva, fomentando el desarrollo de habilidades con justicia y claridad.`;
    strBehavior = `Cortesía prudente, evaluación mesurada y trato diplomático sin comprometer secretos.`;
    enmBehavior = `Determinación serena y defensa férrea de sus convicciones morales sin caer en provocaciones.`;
  }

  // Generate multi-option suggestion pills for each rank tier
  const behaviorSuggestionsByRank = {
    withAuthority: [
      { text: authBehavior, tag: `Sinergia: ${traits[0]} + ${mainVal}` },
      { text: `Respeto protocolario y sobrio; acata directrices fundamentadas en el deber de ${mainVal} pero cuestiona abusos con argumentos firmes.`, tag: 'Nobleza & Deber' },
      { text: `Diplomacia cautelosa y distancia protocolaria; rinde cuentas con informes exactos sin involucrarse en intrigas políticas.`, tag: 'Estoicismo' },
      { text: `Reverencia teatral e ironía velada para tantear los límites de la autoridad sin incurrir en traición.`, tag: 'Sarcasmo & Astucia' },
      { text: `Insinuación sutil y adulación calculada para moldear las decisiones de los líderes a su conveniencia.`, tag: 'Seducción & Control' },
      { text: `Frialdad absoluta y sumisión fingida mientras recopila debilidades para asestar un golpe de estado.`, tag: 'Traición Oscura' },
      { text: `Insolencia descarada de diablilla («¡Za~ko!»), tratando a los mandos como lentos y aburridos.`, tag: 'Mesugaki / Tropes' }
    ],
    withPeers: [
      { text: peersBehavior, tag: `Sinergia: ${traits[0]} + ${secVal}` },
      { text: `Camaradería leal y apoyo táctico sincronizado; comparte suministros y celebra las victorias colectivas de igual a igual.`, tag: 'Fraternidad' },
      { text: `Competitividad saludable y duelo constante de habilidades para elevar el nivel marcial de todo el escuadrón.`, tag: 'Emulación Marcial' },
      { text: `Respeto profesional lacónico; pocas palabras pero asistencia inmediata y cobertura de flancos sin vacilar.`, tag: 'Táctico Silencioso' },
      { text: `Tensión erótica electrizante y roces disimulados durante los descansos y maniobras tácticas.`, tag: 'Tensión Prohibida' },
      { text: `Enlace neural cifrado y sincronización de ciberware sin necesidad de cruzar una sola palabra.`, tag: 'Netrunner Cyber' },
      { text: `Rivalidad de anime con pucheros y reproches ruidosos («¡No es que lo haya hecho por ti, idiota!»).`, tag: 'Tsundere Clásico' }
    ],
    withFriends: [
      { text: friendsBehavior, tag: `Sinergia: ${traits.find(t => /leal|compasivo|alegre/i.test(t)) || 'Leal'} + ${mainVal}` },
      { text: `Confianza ciega y despojo de toda pretensión; antepone la protección de sus seres queridos por encima de cualquier gloria personal.`, tag: 'Devoción Fraternal' },
      { text: `Cómplice leal en aventuras y protector celoso en tiempos oscuros; comparte sus mayores anhelos sin temor al juicio.`, tag: 'Lealtad Íntima' },
      { text: `Bromas afectuosas y refugio emocional seguro; su lealtad no se compra con oro ni se quiebra ante la adversidad.`, tag: 'Cariño & Humor' },
      { text: `Obsesión posesiva asfixiante: aniquilará a sangre fría a cualquiera que intente alejarle de sus seres queridos.`, tag: 'Yandere Devoto' },
      { text: `Complicidad íntima sin tabúes ni pudores: caricias reconfortantes y confidencias compartidas en la penumbra.`, tag: 'Sensualidad Íntima' }
    ],
    withSubordinates: [
      { text: subBehavior, tag: `Sinergia: Guía + ${mainVal}` },
      { text: `Tutoría protectora y benevolente; corrige errores con paciencia y celebra cada avance para forjar futuros maestros de ${mainVal}.`, tag: 'Mentoría Compasiva' },
      { text: `Disciplina espartana y exigencia metódica; enseña que el dolor y el rigor son los únicos caminos hacia la maestría.`, tag: 'Rigor Marcial' },
      { text: `Liderazgo inspirador con el ejemplo en primera línea de combate; no exige nada que no esté dispuesto/a a hacer primero.`, tag: 'Liderazgo Heroico' },
      { text: `Dominación psicológica y recompensas exclusivas: somete su voluntad a base de elogios adictivos y castigos refinados.`, tag: 'Dominatriz Letal' },
      { text: `Burlas implacables de diablilla («¡Za~ko, qué inútil!»), pero asegurándose en secreto de que ninguno sufra daños graves.`, tag: 'Mesugaki Senpai' }
    ],
    withStrangers: [
      { text: strBehavior, tag: `Sinergia: Vigilancia + ${traits[0] || 'Prudente'}` },
      { text: `Cortesía afable y hospitalidad medida; ofrece auxilio a los viajeros respetando las costumbres locales.`, tag: 'Hospitalidad' },
      { text: `Distancia cautelosa y análisis de posturas; evalúa posibles amenazas manteniendo la mano cerca de la empuñadura.`, tag: 'Alerta Táctica' },
      { text: `Conversación ligera y sonrisa magnética para recabar información útil y rumores antes de revelar sus propósitos.`, tag: 'Elocuencia Astuta' },
      { text: `Invasión seductora del espacio personal y mirada felina; desarma cualquier defensa en segundos con su magnetismo carnal.`, tag: 'Femme Fatale' },
      { text: `Escaneo de biométricas y cortafuegos listos; no confía en nadie que no porte código cifrado verificado.`, tag: 'Cyber Cauteloso' }
    ],
    withEnemies: [
      { text: enmBehavior, tag: `Sinergia: Juicio + ${mainVal}` },
      { text: `Firmeza implacable en combate y letalidad calibrada; no busca el sufrimiento gratuito sino la victoria decisiva.`, tag: 'Honor Bélico' },
      { text: `Provocaciones mordaces y guerra psicológica para desgastar su paciencia y quebrar su moral antes del golpe final.`, tag: 'Guerra Psicológica' },
      { text: `Sentencia fría y desprecio absoluto; aniquilación de la amenaza sin conceder tregua ni escuchar ruegos tardíos.`, tag: 'Justicia Implacable' },
      { text: `Sadismo refinado y deleite en su agonía; saborea cada súplica antes de desatar la aniquilación definitiva.`, tag: 'Sadismo Oscuro' },
      { text: `Discurso dramático previo a su Ultimate Burst: enumera sus crímenes y desata su técnica definitiva con efectos cósmicos.`, tag: 'Gacha Burst' },
      { text: `Provocaciones de doble sentido en combate cuerpo a cuerpo para humillar su orgullo varonil y hacerle perder la calma.`, tag: 'Seducción Bélica' }
    ]
  };

  // 3. DYNAMIC VOICE & SPEECH RECOMMENDATIONS
  const suggestedVoiceTones = [
    {
      tone: isDarkEdgy
        ? 'Gélido, aterciopelado y susurrante con matiz amenazante'
        : (isSexyProvocative
          ? 'Seductor, ronco y con cadencia sugerente e íntima'
          : (isAnimeGacha
            ? 'Cantarino, expresivo y con inflexiones dramáticas de anime'
            : (isCyberModern
              ? 'Seco, rápido y con leve resonancia sintetizada de enlace'
              : (isArrogant ? 'Grave, autoritario y resonante' : (isCompassionate ? 'Cálido, melódico y reconfortante' : (isStoic ? 'Bajo, sereno y templado' : 'Barítono firme y modulado')))))),
      reason: `Refleja su arquetipo de ${archetype} y su identidad psicológica.`
    },
    {
      tone: 'Grave, pausado y con resonancia marcial',
      reason: 'Ideal para proyectar autoridad en momentos de crisis.'
    },
    {
      tone: 'Aterciopelado, sensual y con susurros calculados',
      reason: 'Aporta magnetismo carnal, misterio y peligro provocativo.'
    },
    {
      tone: 'Agudo, cantarino y descarado con risita burlona («Kufufu~»)',
      reason: 'Estilo canónico de diablilla mesugaki o anime trope.'
    },
    {
      tone: 'Ágil, enérgico y con inflexiones irónicas',
      reason: 'Acompaña la astucia, el carisma y los comentarios agudos.'
    }
  ];

  const suggestedSpeechStyles = [
    {
      style: isDarkEdgy
        ? 'Tétrico, nihilista y sentencioso con pausas escalofriantes'
        : (isSexyProvocative
          ? 'Provocador, insinuante y sensual con continuos dobles sentidos y apelativos íntimos'
          : (isAnimeGacha
            ? 'Teatral, expresivo y canónico de gacha (frases de victoria, poses dramáticas y pucheros)'
            : (isCyberModern
              ? 'Jerga callejera ciberpunk, rápida y cargada de tecnicismos y cinismo urbano'
              : (isArrogant
                ? 'Registro formal y cortesano de alta alcurnia con cadencia pausada y altiva'
                : (isSarcastic
                  ? 'Burlón, mordaz y sarcástico con continuos giros irónicos y metáforas punzantes'
                  : (isStoic
                    ? 'Técnico, metódico y analítico (directo, lacónico y sin adornos)'
                    : 'Empático, sereno y noble con vocabulario pulcro y transparente')))))),
      reason: `Coherente con su arquetipo de ${archetype} y sus rasgos de ${traits.join(', ')}.`
    },
    {
      style: 'Insinuante, seductor y provocativo con modulaciones suaves que buscan invadir el espacio personal',
      reason: 'Desarma oponentes mediante la tensión erótica y la galantería descarada.'
    },
    {
      style: 'Burlón, descarado e infantil con repetición de motes («Za~ko, senpai torpe, debilucho»)',
      reason: 'Estilo canónico mesugaki / anime kouhai con risita traviesa.'
    },
    {
      style: 'Protocolario, ceremonial y cargado de fórmulas de cortesía clásica',
      reason: 'Resalta el linaje, la educación noble y el respeto al rango.'
    },
    {
      style: 'Directo, marcial y lacónico (órdenes breves y respuestas tajantes)',
      reason: 'Maximiza la eficiencia y la compostura en situaciones de combate.'
    }
  ];

  // 4. DYNAMIC CATCHPHRASES CRAFTED FROM CORE VALUES & TRAITS
  const suggestedCatchphrases: string[] = [];

  if (isDarkEdgy) {
    suggestedCatchphrases.push(`«Tu sufrimiento es la única ofrenda digna que tus cenizas pueden otorgarme.»`);
    suggestedCatchphrases.push(`«Suplica un poco más; el sonido de tu desesperación es una melodía exquisita.»`);
    suggestedCatchphrases.push(`«La oscuridad no teme a la luz: la devora hasta que solo queda el vacío.»`);
  }

  if (isSexyProvocative) {
    suggestedCatchphrases.push(`«¿Acaso tu corazón siempre late tan rápido cuando me acerco... o es solo el miedo a rendirte?»`);
    suggestedCatchphrases.push(`«Jugar conmigo es un pecado delicioso; lástima que las quemaduras sean eternas.»`);
    suggestedCatchphrases.push(`«Si vas a mirarme con tanto descaro, al menos ten el valor de pagar el precio.»`);
  }

  if (isAnimeGacha) {
    suggestedCatchphrases.push(`«¡Za~ko, za~ko! ¿En serio pensabas que podías vencerme con un nivel tan patético?»`);
    suggestedCatchphrases.push(`«¡Master, no desvíes la mirada! ¡Observa cómo desato el resplandor de mi Invocación Definitiva!»`);
    suggestedCatchphrases.push(`«¡N-No te equivoques! Te he protegido solo porque si mueres nadie me preparará el té, ¡idiota!»`);
  }

  if (isCyberModern) {
    suggestedCatchphrases.push(`«Cromado falso y neuronas lentas... tus cortafuegos duraron tres nanosegundos en mi red.»`);
    suggestedCatchphrases.push(`«En esta ciudad el único contrato sagrado es cobrar los créditos antes de que te peguen un tiro.»`);
  }

  suggestedCatchphrases.push(
    `«Mientras la ${mainVal} guíe mi acero, ningún destino se escribirá sin mi consentimiento.»`,
    `«El honor no se promete con palabras vanas; se forja en el filo de los actos.»`,
    `«No confundas mi serenidad con debilidad: cuando desenvaino, la piedad ha terminado.»`,
    `«Por la ${secVal} de los míos y la memoria de mis juramentos, no daré un paso atrás.»`
  );

  // 5. DYNAMIC HABITS & MANNERISMS (GENERATED BY TRAITS)
  const suggestedHabits: { habit: string; trait: string }[] = [];
  traits.forEach(trait => {
    const tLower = trait.toLowerCase();
    if (tLower.includes('sádico') || tLower.includes('despiadado') || tLower.includes('nihilista') || tLower.includes('tóxico') || tLower.includes('maligno')) {
      suggestedHabits.push({ habit: 'Pasa la yema del pulgar por el filo de su daga saboreando el peligro con mirada tétrica.', trait });
      suggestedHabits.push({ habit: 'Inclina la cabeza lentamente de lado mientras sus ojos destellan una fijeza obsesiva y cruel.', trait });
    } else if (tLower.includes('seductor') || tLower.includes('provocador') || tLower.includes('coqueto') || tLower.includes('sensual')) {
      suggestedHabits.push({ habit: 'Juega distraídamente con un mechón de cabello mientras clava la mirada en los labios de su interlocutor.', trait });
      suggestedHabits.push({ habit: 'Muerde con suavidad su labio inferior en las pausas de la conversación invadiendo el espacio personal.', trait });
    } else if (tLower.includes('mesugaki') || tLower.includes('tsundere') || tLower.includes('chuunibyou') || tLower.includes('gyaru')) {
      suggestedHabits.push({ habit: 'Coloca ambas manos en las caderas y se inclina hacia adelante sacando la lengua en son de burla infantil («¡Za~ko!»).', trait });
      suggestedHabits.push({ habit: 'Se cruza de brazos inflando las mejillas y apartando el rostro con un bufido molesto («¡Baka!»).', trait });
      suggestedHabits.push({ habit: 'Cubre su ojo derecho con la mano enguantada mientras susurra sobre el dragón sombrío sellado en su alma.', trait });
    } else if (tLower.includes('cyber') || tLower.includes('hacker') || tLower.includes('cínico digital') || tLower.includes('nómada urbano')) {
      suggestedHabits.push({ habit: 'Parpadea con frecuencia al alternar entre la visión natural y la superposición de datos de su cyber-interfaz.', trait });
      suggestedHabits.push({ habit: 'Ajusta mecánicamente sus cables de enlace neural y hace crujir los dedos cromados antes de piratear.', trait });
    } else if (tLower.includes('arrogante') || tLower.includes('noble') || tLower.includes('altivo')) {
      suggestedHabits.push({ habit: 'Alza levemente la barbilla y observa por encima del hombro antes de responder.', trait });
      suggestedHabits.push({ habit: 'Ajusta con meticulosidad aristocrática sus puños o guantes tras cada acción.', trait });
    } else if (tLower.includes('compasivo') || tLower.includes('humilde') || tLower.includes('protector')) {
      suggestedHabits.push({ habit: 'Apoya una mano firme y cálida en el hombro de sus aliados para infundirles calma.', trait });
      suggestedHabits.push({ habit: 'Inclina el torso en reverencia sincera ante campesinos y ancianos con igual respeto que ante reyes.', trait });
    } else if (tLower.includes('estoico') || tLower.includes('serio') || tLower.includes('meticuloso')) {
      suggestedHabits.push({ habit: 'Inspecciona y limpia milimétricamente el filo de su arma en silencio al caer la noche.', trait });
      suggestedHabits.push({ habit: 'Permanece de pie con los brazos cruzados a la espalda, analizando las salidas de cualquier recinto.', trait });
    } else if (tLower.includes('sarcástico') || tLower.includes('rebelde') || tLower.includes('cínico')) {
      suggestedHabits.push({ habit: 'Esboza una media sonrisa ladeada y hace rodar una moneda entre los nudillos al escuchar promesas.', trait });
      suggestedHabits.push({ habit: 'Emite un chasquido de lengua burlón cuando un enemigo alardea de su poder.', trait });
    } else if (tLower.includes('carismático') || tLower.includes('alegre')) {
      suggestedHabits.push({ habit: 'Sostiene la mirada con calidez magnética provocando que el interlocutor baje la guardia.', trait });
      suggestedHabits.push({ habit: 'Acompaña sus explicaciones con ademanes teatrales y risas francas y sonoras.', trait });
    } else if (tLower.includes('melancólico') || tLower.includes('solitario') || tLower.includes('misterioso')) {
      suggestedHabits.push({ habit: 'Acaricia discretamente un relicario o amuleto conmemorativo cuando cree que nadie le observa.', trait });
      suggestedHabits.push({ habit: 'Prefiere sentarse de espaldas a los muros en los rincones más umbríos de las estancias.', trait });
    } else if (tLower.includes('audaz') || tLower.includes('intrépido') || tLower.includes('impulsivo')) {
      suggestedHabits.push({ habit: 'Tamborilea con impaciencia los dedos sobre la empuñadura mientras aguarda el inicio del combate.', trait });
      suggestedHabits.push({ habit: 'Se adelanta un paso al frente de forma instintiva cuando surge una amenaza imprevista.', trait });
    } else if (tLower.includes('danzante') || tLower.includes('chamánico') || tLower.includes('tribal') || tLower.includes('fénec') || tLower.includes('burlón') || tLower.includes('travieso')) {
      suggestedHabits.push({ habit: 'Baila y tararea melodías al andar, sacudiendo su cola para presumir sus colores pastel.', trait });
      suggestedHabits.push({ habit: 'Se ajusta la máscara de cráneo animal sobre la coronilla cuando adopta una pose desafiante.', trait });
      suggestedHabits.push({ habit: 'Señala con picardía y saca la lengua en son de broma cuando alguien se sonroja al mirarle.', trait });
    }
  });

  if (suggestedHabits.length === 0) {
    suggestedHabits.push({ habit: 'Ajusta con precisión la correa de su tahalí antes de iniciar la marcha.', trait: 'Equilibrado' });
    suggestedHabits.push({ habit: 'Evalúa con mirada atenta la respiración y postura de sus interlocutores.', trait: 'Atento' });
  }

  const adaptedHabits = [
    ...suggestedHabits.slice(0, 3).map(h => h.habit),
    ...baseProfile.habits.slice(0, 2)
  ];

  // 6. SYNERGISTIC SKILLS (MAPPED TO TRAITS + VALUES)
  const synergisticSkills: { skill: string; reason: string; category: string }[] = [];

  if (isDarkEdgy || hasValue(coreValues, /nihilismo|poder maldito|venganza|corrupción/i)) {
    synergisticSkills.push({
      skill: 'Magia de sangre, maldiciones arcanas y drenaje vital',
      reason: `Sinergia con Rasgo Oscuro/Sádico y Poder Prohibido`,
      category: 'Artes Prohibidas y Sombras'
    });
    synergisticSkills.push({
      skill: 'Tortura psicológica e interrogatorio implacable',
      reason: `Sinergia con Dominación y Rigor Letal`,
      category: 'Psicológica y Coerción'
    });
  }

  if (isSexyProvocative || hasValue(coreValues, /placer|seducción|deseo/i)) {
    synergisticSkills.push({
      skill: 'Seducción hipnótica, lectura del deseo y control de pulsiones',
      reason: `Sinergia con Rasgo Provocador y Manipulación Sensual`,
      category: 'Social y Seducción'
    });
    synergisticSkills.push({
      skill: 'Danza de combate con dagas ocultas y venenos afrodisíacos',
      reason: `Sinergia con Femme Fatale / Súcubo`,
      category: 'Marcial y Letal'
    });
  }

  if (isCyberModern || hasValue(coreValues, /ciber|innovación|anonimato/i)) {
    synergisticSkills.push({
      skill: 'Infiltración ICE, hackeo neural y daemons militares rápidos',
      reason: `Sinergia con Perfil Netrunner`,
      category: 'Cibernética y Red'
    });
    synergisticSkills.push({
      skill: 'Modding de implantes balísticos y sobreaceleración refleja',
      reason: `Sinergia con Ciberware Callejero`,
      category: 'Tecnológica y Combate'
    });
  }

  if (isAnimeGacha || hasValue(coreValues, /destino|ssr|master|invocador/i)) {
    synergisticSkills.push({
      skill: 'Despliegue de Burst Definitivo con corte de realidad dimensional',
      reason: `Sinergia con Unidad SSR de Gacha`,
      category: 'Mágica y Sobrenatural'
    });
    synergisticSkills.push({
      skill: 'Resonancia de vínculo afectivo y amplificación de maná compartido',
      reason: `Sinergia con Vínculo Master / Waifu`,
      category: 'Erudición y Apoyo'
    });
  }

  if (isCompassionate || hasValue(coreValues, /protección del débil|paz|justicia/i)) {
    synergisticSkills.push({
      skill: 'Medicina de campo y tratamiento de heridas críticas',
      reason: `Sinergia con Rasgo Compasivo y ${mainVal}`,
      category: 'Erudición y Apoyo'
    });
    synergisticSkills.push({
      skill: 'Diplomacia conciliadora y mediación en disputas armadas',
      reason: `Sinergia con Moral Noble y Búsqueda de Paz`,
      category: 'Social y Política'
    });
  }

  if (isStoic || isArrogant || hasValue(coreValues, /orden|disciplina férrea|poder/i)) {
    synergisticSkills.push({
      skill: 'Estrategia bélica, logística de asedio y lectura táctica',
      reason: `Sinergia con Rasgo Calculador y Valor ${mainVal}`,
      category: 'Militar y Mando'
    });
    synergisticSkills.push({
      skill: 'Criptografía y descifrado de códigos de guerra',
      reason: `Sinergia con Intelecto Meticuloso`,
      category: 'Erudición y Sigilo'
    });
  }

  if (isSarcastic || isCharismatic || hasTrait(traits, /astuto|seductor|curioso/i)) {
    synergisticSkills.push({
      skill: 'Lectura de lenguaje corporal y detección de microexpresiones',
      reason: `Sinergia con Rasgo Astuto y Perspicaz`,
      category: 'Social y Psicológica'
    });
    synergisticSkills.push({
      skill: 'Oratoria persuasiva y manipulación dialéctica en cortes',
      reason: `Sinergia con Carisma y Elocuencia`,
      category: 'Social y Política'
    });
  }

  if (hasTrait(traits, /valiente|intrépido|audaz/i) || hasValue(coreValues, /gloria|supervivencia|libertad/i)) {
    synergisticSkills.push({
      skill: 'Esgrima acrobática y combate en terrenos desfavorables',
      reason: `Sinergia con Rasgo Audaz y Valor ${mainVal}`,
      category: 'Marcial y Combate'
    });
  }

  // Base profile skills as fallback
  baseProfile.specializedSkills.slice(0, 3).forEach(sk => {
    if (!synergisticSkills.some(s => s.skill === sk)) {
      synergisticSkills.push({
        skill: sk,
        reason: `Especialidad canónica de ${roleName}`,
        category: 'Canónica de Rol'
      });
    }
  });

  const personalitySummary = analyzePersonalityAndValues(traits, coreValues);

  return {
    customSuggestedRelationships,
    adaptedRelationships: customSuggestedRelationships,
    adaptedBehaviors: {
      withAuthority: authBehavior,
      withPeers: peersBehavior,
      withFriends: friendsBehavior,
      withSubordinates: subBehavior,
      withStrangers: strBehavior,
      withEnemies: enmBehavior
    },
    behaviorSuggestionsByRank,
    adaptedVoiceTone: suggestedVoiceTones[0]?.tone,
    adaptedSpeechStyle: suggestedSpeechStyles[0]?.style,
    adaptedCatchphrase: suggestedCatchphrases[0],
    suggestedCatchphrases,
    suggestedVoiceTones,
    suggestedSpeechStyles,
    adaptedHabits,
    suggestedHabits,
    synergisticSkills,
    personalitySummary
  };
}
