import { CharacterState, SavedCharacterEntry } from '../types';
import { DEFAULT_MAKEUP_CONFIG } from '../data';
import { NATIVE_SEED_CHARACTERS } from '../data/canonicalSeedCharacters';

export const LIBRARY_STORAGE_KEY = 'CANONICAL_CHARACTER_LIBRARY_V8';

export const createDefaultCharacterState = (): CharacterState => ({
  id: '',
  name: '',
  personality: 'Alegre',
  personalityTraits: ['Alegre'],
  archetype: 'Genérico',
  raceGroup: '',
  raceId: '',
  raceName: '',
  subtype: '',
  anatomy: {
    sexBase: '1 Hombre',
    age: '3 Juventud (18-25 años)',
    complexion: '2 Esbelto / Estandar',
    height: 'C Normal / Estándar (1.60 m – 1.80 m)',
    breastDevelopment: 'A Senos Planos / Pechos Incipientes / Copa AA',
    waist: '3 Media / Equilibrada',
    glutes: '3 Moderados',
    thighs: '3 Medios / Equilibrados',
    skinColor: 'Piel Caucásica Clara',
    lowerBodyStructure: 'Bípedo Humanoide Estándar'
  },
  facial: {
    headShape: 'Ovalada',
    headWidth: 'Media / Equilibrada',
    boneStructure: 'Media / Normal',
    eyeColor: 'Marrón / Castaño',
    eyesCategory: 'A Filosos / Afilados',
    eyesSubtype: 'A1 Almendrado Clásico',
    eyeliner: 'DEL1 Delgado',
    shadow: 'SOM1 Sombra Suave',
    expression: 'EXP1 Neutral',
    iris: '1 Humano',
    nose: '1 Recta / Clásica',
    lips: 'A1 Básico',
    mouthExp: 'E1 Sonriente',
    mouthSpecial: 'Ninguna',
    teeth: 'B1 Normales',
    mouthCorners: 'COM2 Neutras',
    mouthTexture: 'TEX1 Mate',
    earsBase: 'E01 Normales',
    earsLength: 'EL1 0–5 cm',
    kemonoEars: 'Ninguno'
  },
  hair: {
    texture: '1 Liso / Lacio',
    length: '3 Medio (Hombros)',
    cut: '4 Recto',
    part: '1 Al Centro',
    bangs: '1 Sin Flequillo',
    style: 'HST00 Sin peinado / suelto',
    hairColor: 'Negro Azabache'
  },
  appendices: {
    hornsForm: 'Ninguno',
    hornsLength: 'HL1 0-10 cm',
    hornsThickness: 'G3 Medio',
    hornsPosition: 'P1 Frontales',
    wingsSize: 'S2 Medio',
    wingsPosition: 'P1 Espalda Alta',
    wingsType: 'Ninguno',
    tailsType: 'Ninguno',
    tailsLength: 'L2 Corta',
    skinAndMarks: 'T1 Piel Lisa',
    scaleLocations: [],
    markTypes: [],
    markLocations: {},
    markShapes: {},
    markColors: {},
    antennaeType: 'Ninguna',
    antennaeLength: 'Medias (10–25 cm)',
    antennaePosition: 'Frontales (Frente)',
    extraEyes: 'Ninguno (2 Ojos Estándar)',
    extraArms: 'Ninguno (2 Brazos Estándar)',
    specialLimbs: 'Ninguna (Extremidades Orgánicas Estándar)',
    lowerBodyStructure: 'Bípedo Humanoide Estándar'
  },
  makeup: { ...DEFAULT_MAKEUP_CONFIG },
  wardrobes: [],
  role: 'A1 Maid de Mansión',
  nobleTitle: '',
  nobleHouseOrDomain: '',
  styleVisual: 'Fantasía Tradicional',
  armor: {
    type: 'Ninguna',
    pieces: [],
    material: 'M1 Acero común',
    finish: 'F2 Mate'
  },
  equipment: {
    weapons: [],
    weaponGrips: [],
    bags: [],
    bagSizes: [],
    bagClosures: [],
    items: []
  },
  orientalFantasy: {
    tradition: '',
    armorPieces: [],
    culturalAccessories: [],
    spiritualMotif: '',
    silkPattern: '',
    jadeAccentColor: '',
    energyAura: '',
    weaponStyle: ''
  },
  background: {
    relationships: [],
    backstory: '',
    motivation: '',
    coreValues: 'Honor, Lealtad',
    advancedCustomization: {
      voiceTone: 'Melifluo, seductor y persuasivo',
      speechStyle: 'Registro formal y cortesano de alta alcurnia (uso de usted, protocolo impecable)',
      catchphrasesOrIdioms: '«Por el filo del alba...»',
      skills: ['Esgrima de duelo y parada con estoque', 'Etiqueta noble y diplomacia cortesana'],
      habitsAndMannerisms: ['Ajusta meticulosamente sus guantes antes de iniciar una conversación'],
      specificInteractions: {
        withAuthority: 'Respeto reverente pero con mirada fija y analítica sin titubear.',
        withSubordinates: 'Exigente con disciplina pero protector/a ante las injusticias.',
        withStrangers: 'Distancia protocolaria y discreción absoluta.',
        withEnemies: 'Frialdad elegante sin perder la compostura ni alzar la voz.'
      }
    }
  },
  validationLogs: [],
  liteAgent: {
    isLiteAgent: true,
    motivations: ['Alcanzar la maestría en las artes místicas del desierto', 'Proteger el secreto de las arenas sagradas'],
    allegianceFactionId: 'FAC-01',
    greatestFear: 'Ser subyugada y despojada de su libertad de elección',
    moralAlignment: 'Devoto Protector',
    interactionRole: 'Místico / Hechicero',
    combatStats: {
      maxHp: 120,
      currentHp: 120,
      maxSp: 80,
      currentSp: 80,
      attack: 28,
      defense: 22,
      agility: 34,
      specialSkillName: 'Danza del Velo Celestial',
      specialSkillDescription: 'Crea una ráfaga de arena luminosa que ciega al oponente y restaura 25 SP al usuario.'
    }
  }
});

export const PRELOADED_SEED_CHARACTERS: SavedCharacterEntry[] = NATIVE_SEED_CHARACTERS;

export const getSavedCharacters = (): SavedCharacterEntry[] => {
  try {
    const raw = localStorage.getItem(LIBRARY_STORAGE_KEY);
    if (!raw) {
      try {
        localStorage.removeItem("CANONICAL_CHARACTER_LIBRARY_V7");
        localStorage.removeItem("CANONICAL_CHARACTER_LIBRARY_V6");
      } catch {}
      localStorage.setItem(LIBRARY_STORAGE_KEY, JSON.stringify(PRELOADED_SEED_CHARACTERS));
      return PRELOADED_SEED_CHARACTERS;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      // Purge obsolete legacy characters (Aeloria, Valerius)
      const cleaned = parsed.filter(c => 
        c.id !== "char-seed-001" && 
        c.id !== "char-seed-001-past" && 
        c.id !== "char-seed-001-future" && 
        c.id !== "char-seed-001-outfit" && 
        c.id !== "char-seed-002" &&
        !c.state?.name?.toLowerCase().includes("aeloria") &&
        !c.state?.name?.toLowerCase().includes("valerius de luminaria")
      );

      // Verify that all native seed characters are present
      const hasValentin = cleaned.some(c => c.state?.name?.includes("Valentín Montclair") || c.id?.includes("valentin"));
      const hasXander = cleaned.some(c => c.state?.name?.includes("Xander Vaelith") || c.id?.includes("xander"));
      const hasGoPip = cleaned.some(c => c.state?.name?.includes("Go pip") || c.id?.includes("go-pip"));

      if (!hasValentin || !hasXander || !hasGoPip || cleaned.length !== parsed.length) {
        const finalCharacters = [...PRELOADED_SEED_CHARACTERS];
        for (const item of cleaned) {
          if (!PRELOADED_SEED_CHARACTERS.some(s => s.id === item.id)) {
            finalCharacters.push(item);
          }
        }
        localStorage.setItem(LIBRARY_STORAGE_KEY, JSON.stringify(finalCharacters));
        return finalCharacters;
      }
      return cleaned;
    }
    return PRELOADED_SEED_CHARACTERS;
  } catch (err) {
    console.error("Error reading character library from localStorage:", err);
    return PRELOADED_SEED_CHARACTERS;
  }
};

export const getSavedCharacterById = (id: string): SavedCharacterEntry | undefined => {
  const list = getSavedCharacters();
  return list.find(c => c.id === id);
};

export const notifyLibraryChange = (action: string, charState?: CharacterState, charId?: string) => {
  if (typeof window !== 'undefined') {
    try {
      window.dispatchEvent(
        new CustomEvent('elysium:modulo-sync', {
          detail: {
            source: 'library',
            action,
            character: charState,
            characterId: charId || charState?.id,
            timestamp: Date.now()
          }
        })
      );
    } catch {}
  }
};

export const saveCharacterToLibrary = (state: CharacterState, variantLabel?: string): SavedCharacterEntry => {
  const list = getSavedCharacters();
  const now = new Date().toISOString();
  const activeVariantLabel = variantLabel || state.variantLabel || 'Base';
  
  // If character already has an ID and exists in library, update it
  if (state.id) {
    const existingIndex = list.findIndex(c => c.id === state.id);
    if (existingIndex >= 0) {
      const updatedEntry: SavedCharacterEntry = {
        ...list[existingIndex],
        updatedAt: now,
        variantLabel: activeVariantLabel,
        thumbnailUrl: state.avatarImageUrl || list[existingIndex].thumbnailUrl,
        state: { ...state, variantLabel: activeVariantLabel }
      };
      list[existingIndex] = updatedEntry;
      localStorage.setItem(LIBRARY_STORAGE_KEY, JSON.stringify(list));
      notifyLibraryChange('update_character', updatedEntry.state, updatedEntry.id);
      return updatedEntry;
    }
  }

  // Create new entry
  const newId = `char-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
  const characterWithId: CharacterState = {
    ...state,
    id: newId,
    variantLabel: activeVariantLabel
  };
  const newEntry: SavedCharacterEntry = {
    id: newId,
    savedAt: now,
    updatedAt: now,
    variantLabel: activeVariantLabel,
    thumbnailUrl: state.avatarImageUrl,
    state: characterWithId
  };

  const updatedList = [newEntry, ...list];
  localStorage.setItem(LIBRARY_STORAGE_KEY, JSON.stringify(updatedList));
  notifyLibraryChange('update_character', newEntry.state, newEntry.id);
  return newEntry;
};

export const updateCharacterInLibrary = (id: string, state: CharacterState): SavedCharacterEntry | null => {
  const list = getSavedCharacters();
  const index = list.findIndex(c => c.id === id);
  if (index < 0) return null;

  const now = new Date().toISOString();
  const updatedEntry: SavedCharacterEntry = {
    ...list[index],
    updatedAt: now,
    thumbnailUrl: state.avatarImageUrl || list[index].thumbnailUrl,
    state: { ...state, id }
  };
  list[index] = updatedEntry;
  localStorage.setItem(LIBRARY_STORAGE_KEY, JSON.stringify(list));
  notifyLibraryChange('update_character', updatedEntry.state, updatedEntry.id);
  return updatedEntry;
};

export const deleteCharacterFromLibrary = (id: string): boolean => {
  const list = getSavedCharacters();
  const filtered = list.filter(c => c.id !== id);
  if (filtered.length === list.length) return false;
  localStorage.setItem(LIBRARY_STORAGE_KEY, JSON.stringify(filtered));
  notifyLibraryChange('delete_character', undefined, id);
  return true;
};

export const duplicateCharacterInLibrary = (id: string): SavedCharacterEntry | null => {
  const list = getSavedCharacters();
  const original = list.find(c => c.id === id);
  if (!original) return null;

  const newId = `char-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
  const now = new Date().toISOString();
  const duplicatedState: CharacterState = {
    ...JSON.parse(JSON.stringify(original.state)),
    id: newId,
    name: `${original.state.name || 'Personaje'} (Copia)`
  };

  const newEntry: SavedCharacterEntry = {
    id: newId,
    savedAt: now,
    updatedAt: now,
    thumbnailUrl: original.thumbnailUrl,
    state: duplicatedState
  };

  const updatedList = [newEntry, ...list];
  localStorage.setItem(LIBRARY_STORAGE_KEY, JSON.stringify(updatedList));
  notifyLibraryChange('update_character', newEntry.state, newEntry.id);
  return newEntry;
};

export const exportLibraryToJson = (): string => {
  const list = getSavedCharacters();
  return JSON.stringify(list, null, 2);
};

export const importLibraryFromJson = (jsonStr: string): { success: boolean; count: number; error?: string } => {
  try {
    const parsed = JSON.parse(jsonStr);
    let itemsToProcess: any[] = [];

    if (Array.isArray(parsed)) {
      itemsToProcess = parsed;
    } else if (parsed && typeof parsed === 'object') {
      if (Array.isArray(parsed.characters)) {
        itemsToProcess = parsed.characters;
      } else if (Array.isArray(parsed.library)) {
        itemsToProcess = parsed.library;
      } else if (parsed.state && typeof parsed.state === 'object') {
        itemsToProcess = [parsed];
      } else if (parsed.raceName || parsed.anatomy || parsed.wardrobes || parsed.role || parsed.name) {
        itemsToProcess = [{ state: parsed }];
      } else {
        return { success: false, count: 0, error: 'El archivo JSON no contiene personajes reconocibles.' };
      }
    } else {
      return { success: false, count: 0, error: 'Formato JSON inválido.' };
    }

    if (itemsToProcess.length === 0) {
      return { success: false, count: 0, error: 'No se encontraron personajes en el archivo JSON.' };
    }

    const existing = getSavedCharacters();
    const existingIds = new Set(existing.map(e => e.id));
    const now = new Date().toISOString();

    const newEntries: SavedCharacterEntry[] = itemsToProcess.map((item, idx) => {
      const stateObj = item.state && typeof item.state === 'object' ? item.state : item;
      let entryId = item.id || stateObj.id;
      if (!entryId || existingIds.has(entryId)) {
        entryId = `char-${Date.now()}-${idx}-${Math.random().toString(36).substring(2, 7)}`;
      }
      const charState = {
        ...stateObj,
        id: entryId,
        variantLabel: item.variantLabel || stateObj.variantLabel || 'Base'
      };

      return {
        id: entryId,
        savedAt: item.savedAt || now,
        updatedAt: now,
        variantLabel: charState.variantLabel,
        baseCharacterId: item.baseCharacterId || stateObj.baseCharacterId || undefined,
        variantNotes: item.variantNotes || stateObj.variantNotes || undefined,
        thumbnailUrl: item.thumbnailUrl || stateObj.avatarImageUrl || undefined,
        state: charState
      };
    });

    const combined = [...newEntries, ...existing];
    localStorage.setItem(LIBRARY_STORAGE_KEY, JSON.stringify(combined));
    return { success: true, count: newEntries.length };
  } catch (err: any) {
    return { success: false, count: 0, error: err.message || 'Error al procesar el archivo JSON.' };
  }
};

// =========================================================================
// ALTERNATE VERSIONS & GROUPING ENGINE
// =========================================================================

export interface CharacterVariantGroup {
  groupId: string;
  groupName: string;
  baseCharacter: SavedCharacterEntry;
  variants: SavedCharacterEntry[];
  allEntries: SavedCharacterEntry[];
}

/**
 * Extracts root clean name without parenthetical tags like (Pasado), (Futuro), (Rol/Vestuario), (Copia)
 */
export const extractRootCharacterName = (name: string): string => {
  if (!name) return 'Personaje';
  return name
    .replace(/\s*[\(\[\{].*?[\)\]\}]/g, '')
    .replace(/\s*-\s*(Pasado|Futuro|Rol|Vestuario|Copia|Variante|Aprendiz|Matriarca|Paladín|Armadura).*$/i, '')
    .trim() || name.trim();
};

/**
 * Returns list of characters grouped by their variantGroupId or common root identity.
 */
export const getCharacterVariantGroups = (list?: SavedCharacterEntry[]): CharacterVariantGroup[] => {
  const characters = list || getSavedCharacters();
  const groupMap = new Map<string, SavedCharacterEntry[]>();

  // 1. Group by explicit variantGroupId or heuristic root name
  characters.forEach(entry => {
    const rootName = extractRootCharacterName(entry.state?.name || '');
    const gId = entry.variantGroupId || entry.state?.variantGroupId || `auto-group-${rootName.toLowerCase()}`;
    if (!groupMap.has(gId)) {
      groupMap.set(gId, []);
    }
    groupMap.get(gId)!.push(entry);
  });

  const groups: CharacterVariantGroup[] = [];

  groupMap.forEach((members, gId) => {
    // Sort so 'Base' is first, or by creation date
    const sorted = [...members].sort((a, b) => {
      const isBaseA = a.variantLabel?.toLowerCase() === 'base' || a.state?.variantLabel?.toLowerCase() === 'base' || (!a.baseCharacterId && !a.state?.baseCharacterId);
      const isBaseB = b.variantLabel?.toLowerCase() === 'base' || b.state?.variantLabel?.toLowerCase() === 'base' || (!b.baseCharacterId && !b.state?.baseCharacterId);
      if (isBaseA && !isBaseB) return -1;
      if (!isBaseA && isBaseB) return 1;
      return new Date(a.savedAt).getTime() - new Date(b.savedAt).getTime();
    });

    const base = sorted[0];
    const variants = sorted.slice(1);
    const rootName = extractRootCharacterName(base.state?.name || '');

    groups.push({
      groupId: gId,
      groupName: rootName || base.state?.name || 'Personaje',
      baseCharacter: base,
      variants,
      allEntries: sorted
    });
  });

  return groups;
};

/**
 * Creates an alternate version of a character with reciprocal relationships and appropriate preset metadata.
 */
export const createAlternateVersion = (
  originalId: string,
  variantType: 'Rol/Vestuario' | 'Futuro' | 'Pasado' | 'Personalizada',
  customLabel?: string,
  autoLinkRelationships: boolean = true
): SavedCharacterEntry | null => {
  const list = getSavedCharacters();
  const originalIndex = list.findIndex(c => c.id === originalId);
  if (originalIndex < 0) return null;

  const original = list[originalIndex];
  const rootName = extractRootCharacterName(original.state.name);
  const now = new Date().toISOString();

  // Ensure original character has a variantGroupId and 'Base' label if not already present
  const groupId = original.variantGroupId || original.state.variantGroupId || `grp-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
  const baseLabel = original.variantLabel || original.state.variantLabel || 'Base';

  const updatedOriginal: SavedCharacterEntry = {
    ...original,
    variantGroupId: groupId,
    variantLabel: baseLabel,
    state: {
      ...original.state,
      variantGroupId: groupId,
      variantLabel: baseLabel
    }
  };
  list[originalIndex] = updatedOriginal;

  // Determine variant configuration
  const newId = `char-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
  let newLabel: string = variantType;
  let newName = `${rootName} (${variantType})`;
  let relTypeToOriginal = 'Versión Alterna: Rol/Vestuario';
  let relTypeFromOriginal = 'Versión Alterna: Rol/Vestuario';
  let feelingToOriginal = `Fascinación al contemplar su reflejo portando otra senda y propósito.`;
  let feelingFromOriginal = `Curiosidad ante el sendero divergente y rol alternativo de su propio ser.`;
  let opinionToOriginal = `«Una faceta alternativa de mi propia alma; nuestras técnicas difieren pero la convicción es una.»`;
  let opinionFromOriginal = `«Ver a mi otro yo con ese atuendo y rol me recuerda que la esencia trasciende la forma.»`;

  // Deep clone original state
  const newState: CharacterState = JSON.parse(JSON.stringify(original.state));
  newState.id = newId;
  newState.variantGroupId = groupId;
  newState.baseCharacterId = original.id;

  if (variantType === 'Rol/Vestuario') {
    newLabel = 'Rol/Vestuario';
    newName = `${rootName} (Rol/Vestuario: Variante)`;
    relTypeToOriginal = 'Versión Alterna: Rol/Vestuario';
    relTypeFromOriginal = 'Versión Alterna: Rol/Vestuario';
  } else if (variantType === 'Futuro') {
    newLabel = 'Futuro';
    newName = `${rootName} (Futuro / Veterano/a)`;
    relTypeToOriginal = 'Versión Alterna: Pasado';
    relTypeFromOriginal = 'Versión Alterna: Futuro';
    feelingToOriginal = 'Ternura nostálgica y deseo protector hacia la pureza e inocencia de su yo pasado.';
    feelingFromOriginal = 'Asombro reverencial y aprensión ante el inmenso poder, cicatrices y madurez que porta su yo futuro.';
    opinionToOriginal = '«Recuerdo esa mirada ingenua y apasionada; haré lo necesario para que no pierda su luz.»';
    opinionFromOriginal = '«Carga en su mirada el peso de batallas que aún no he librado; forjaré mi camino con honor.»';
    // Age adjustments for future
    newState.anatomy.age = '4 Adulto Maduro (36-50 años)';
    newState.background.backstory = `Años después de sus primeras andanzas, ${rootName} ha templado su espíritu a través de innumerables pruebas y sacrificios, alcanzando la cúspide de su poder y sabiduría.`;
  } else if (variantType === 'Pasado') {
    newLabel = 'Pasado';
    newName = `${rootName} (Pasado / Aprendiz)`;
    relTypeToOriginal = 'Versión Alterna: Futuro';
    relTypeFromOriginal = 'Versión Alterna: Pasado';
    feelingToOriginal = 'Asombro reverencial ante el poder, porte y renombre que alcanzará en el porvenir.';
    feelingFromOriginal = 'Nostalgia agridulce y ternura protectora hacia la inocencia, arrojo y pureza de sus primeros años.';
    opinionToOriginal = '«Porta un aplomo y una mirada que me inspiran a entrenar sin descanso cada día.»';
    opinionFromOriginal = '«Un recordatorio vivo de las razones originales por las que juré consagrar mi vida a mis ideales.»';
    // Age adjustments for past
    newState.anatomy.age = '2 Juvenil (15-18 años)';
    newState.background.backstory = `En sus primeros años de formación, ${rootName} deslumbraba a sus instructores con una insaciable curiosidad y un talento innato que comenzaba a florecer.`;
  } else if (variantType === 'Personalizada') {
    newLabel = customLabel?.trim() || 'Variante Personalizada';
    newName = `${rootName} (${newLabel})`;
  }

  newState.name = newName;
  newState.variantLabel = newLabel;

  if (autoLinkRelationships) {
    // 1. Link in the new variant pointing to original
    if (!newState.background) {
      newState.background = { backstory: '', motivation: '', coreValues: '', relationships: [] };
    }
    if (!newState.background.relationships) {
      newState.background.relationships = [];
    }

    const relIdNew = `rel-${Date.now()}-alt-to-orig`;
    newState.background.relationships.push({
      id: relIdNew,
      targetCharacterName: original.state.name,
      relationshipType: relTypeToOriginal,
      interactionDynamic: `Vínculo temporal y reflejo existencial entre versiones alternas de ${rootName}.`,
      feelingsTowards: feelingToOriginal,
      opinionOn: opinionToOriginal
    });

    // 2. Link in original character pointing to new variant
    if (!updatedOriginal.state.background) {
      updatedOriginal.state.background = { backstory: '', motivation: '', coreValues: '', relationships: [] };
    }
    if (!updatedOriginal.state.background.relationships) {
      updatedOriginal.state.background.relationships = [];
    }

    const relIdOrig = `rel-${Date.now()}-alt-from-orig`;
    updatedOriginal.state.background.relationships.push({
      id: relIdOrig,
      targetCharacterName: newName,
      relationshipType: relTypeFromOriginal,
      interactionDynamic: `Vínculo temporal y reflejo existencial entre versiones alternas de ${rootName}.`,
      feelingsTowards: feelingFromOriginal,
      opinionOn: opinionFromOriginal
    });
  }

  const newEntry: SavedCharacterEntry = {
    id: newId,
    savedAt: now,
    updatedAt: now,
    thumbnailUrl: original.thumbnailUrl,
    variantGroupId: groupId,
    variantLabel: newLabel,
    baseCharacterId: original.id,
    state: newState
  };

  const finalList = [newEntry, ...list];
  localStorage.setItem(LIBRARY_STORAGE_KEY, JSON.stringify(finalList));
  notifyLibraryChange('update_character', newEntry.state, newEntry.id);
  return newEntry;
};

/**
 * Links multiple characters into a single variant group.
 */
export const linkCharactersToVariantGroup = (groupId: string, characterIds: string[], baseId?: string): boolean => {
  const list = getSavedCharacters();
  let modified = false;

  const targetGroupId = groupId || `grp-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

  list.forEach(entry => {
    if (characterIds.includes(entry.id)) {
      entry.variantGroupId = targetGroupId;
      if (entry.state) entry.state.variantGroupId = targetGroupId;
      if (baseId && entry.id === baseId) {
        entry.variantLabel = 'Base';
        if (entry.state) entry.state.variantLabel = 'Base';
        entry.baseCharacterId = undefined;
        if (entry.state) entry.state.baseCharacterId = undefined;
      } else if (baseId) {
        entry.baseCharacterId = baseId;
        if (entry.state) entry.state.baseCharacterId = baseId;
      }
      modified = true;
    }
  });

  if (modified) {
    localStorage.setItem(LIBRARY_STORAGE_KEY, JSON.stringify(list));
    notifyLibraryChange('update_character');
  }
  return modified;
};

/**
 * Unlinks a character from its current variant group making it standalone.
 */
export const unlinkCharacterFromVariantGroup = (characterId: string): boolean => {
  const list = getSavedCharacters();
  const index = list.findIndex(c => c.id === characterId);
  if (index < 0) return false;

  list[index].variantGroupId = undefined;
  list[index].variantLabel = undefined;
  list[index].baseCharacterId = undefined;
  if (list[index].state) {
    list[index].state.variantGroupId = undefined;
    list[index].state.variantLabel = undefined;
    list[index].state.baseCharacterId = undefined;
  }

  localStorage.setItem(LIBRARY_STORAGE_KEY, JSON.stringify(list));
  notifyLibraryChange('update_character');
  return true;
};

/**
 * Sets or updates the variant label of a character.
 */
export const setVariantLabel = (characterId: string, label: string): boolean => {
  const list = getSavedCharacters();
  const index = list.findIndex(c => c.id === characterId);
  if (index < 0) return false;

  list[index].variantLabel = label;
  if (list[index].state) {
    list[index].state.variantLabel = label;
  }

  localStorage.setItem(LIBRARY_STORAGE_KEY, JSON.stringify(list));
  notifyLibraryChange('update_character');
  return true;
};

/**
 * Compiles and merges existing characters from the central library into a variant group,
 * with optional label customization and reciprocal narrative relationship generation.
 */
export const compileAndLinkExistingCharactersAsVariants = (
  baseCharacterId: string,
  selectedCharacterIds: string[],
  variantLabelsMap?: Record<string, string>,
  autoLinkRelationships: boolean = true
): { success: boolean; modifiedCount: number; groupId: string } => {
  const list = getSavedCharacters();
  const baseIndex = list.findIndex(c => c.id === baseCharacterId);
  if (baseIndex < 0 || selectedCharacterIds.length === 0) {
    return { success: false, modifiedCount: 0, groupId: '' };
  }

  const baseEntry = list[baseIndex];
  const rootName = extractRootCharacterName(baseEntry.state?.name || 'Personaje');
  const targetGroupId =
    baseEntry.variantGroupId ||
    baseEntry.state?.variantGroupId ||
    `grp-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
  const baseLabel = baseEntry.variantLabel || baseEntry.state?.variantLabel || 'Base';

  // Ensure base has group ID and base label
  baseEntry.variantGroupId = targetGroupId;
  baseEntry.variantLabel = baseLabel;
  if (baseEntry.state) {
    baseEntry.state.variantGroupId = targetGroupId;
    baseEntry.state.variantLabel = baseLabel;
    baseEntry.state.baseCharacterId = undefined;
  }
  baseEntry.baseCharacterId = undefined;

  let modifiedCount = 0;

  selectedCharacterIds.forEach(charId => {
    if (charId === baseCharacterId) return;
    const charIndex = list.findIndex(c => c.id === charId);
    if (charIndex < 0) return;

    const entry = list[charIndex];
    const chosenLabel =
      (variantLabelsMap && variantLabelsMap[charId]) ||
      entry.variantLabel ||
      entry.state?.variantLabel ||
      'Variante Alterna';

    entry.variantGroupId = targetGroupId;
    entry.variantLabel = chosenLabel;
    entry.baseCharacterId = baseCharacterId;
    if (entry.state) {
      entry.state.variantGroupId = targetGroupId;
      entry.state.variantLabel = chosenLabel;
      entry.state.baseCharacterId = baseCharacterId;
    }

    if (autoLinkRelationships && baseEntry.state && entry.state) {
      // 1. In candidate, add reciprocal relationship to base character
      if (!entry.state.background) {
        entry.state.background = { backstory: '', motivation: '', coreValues: '', relationships: [] };
      }
      if (!entry.state.background.relationships) {
        entry.state.background.relationships = [];
      }

      const relTypeCandidateToBase =
        chosenLabel === 'Rol/Vestuario'
          ? 'Versión Alterna: Rol/Vestuario'
          : chosenLabel === 'Futuro'
          ? 'Versión Alterna: Pasado'
          : chosenLabel === 'Pasado'
          ? 'Versión Alterna: Futuro'
          : `Versión Alterna: ${chosenLabel}`;

      const relTypeBaseToCandidate =
        chosenLabel === 'Rol/Vestuario'
          ? 'Versión Alterna: Rol/Vestuario'
          : chosenLabel === 'Futuro'
          ? 'Versión Alterna: Futuro'
          : chosenLabel === 'Pasado'
          ? 'Versión Alterna: Pasado'
          : `Versión Alterna: ${chosenLabel}`;

      // Check if relationship already exists
      const existingRelInCandidate = entry.state.background.relationships.find(
        r => r.targetCharacterName === baseEntry.state.name
      );
      if (!existingRelInCandidate) {
        entry.state.background.relationships.push({
          id: `rel-${Date.now()}-var-${charId}-to-base`,
          targetCharacterName: baseEntry.state.name,
          relationshipType: relTypeCandidateToBase,
          interactionDynamic: `Vínculo temporal y reflejo existencial entre variantes compiladas en la biblioteca central.`,
          feelingsTowards: `Reconocimiento mutuo y afinidad dimensional ante la encarnación base de su linaje.`,
          opinionOn: `«Nuestra esencia es una, aun cuando nuestras historias y atuendos han tomado cauces singulares.»`
        });
      }

      // 2. In base character, add reciprocal relationship to candidate
      if (!baseEntry.state.background) {
        baseEntry.state.background = { backstory: '', motivation: '', coreValues: '', relationships: [] };
      }
      if (!baseEntry.state.background.relationships) {
        baseEntry.state.background.relationships = [];
      }

      const existingRelInBase = baseEntry.state.background.relationships.find(
        r => r.targetCharacterName === entry.state.name
      );
      if (!existingRelInBase) {
        baseEntry.state.background.relationships.push({
          id: `rel-${Date.now()}-base-to-var-${charId}`,
          targetCharacterName: entry.state.name,
          relationshipType: relTypeBaseToCandidate,
          interactionDynamic: `Vínculo temporal y reflejo existencial entre variantes compiladas en la biblioteca central.`,
          feelingsTowards: `Fascinación y resonancia ante otra vertiente existencial de ${rootName}.`,
          opinionOn: `«Ver una bifurcación de mi propio destino me recuerda la vastedad de los caminos transitados.»`
        });
      }
    }

    modifiedCount++;
  });

  if (modifiedCount > 0) {
    localStorage.setItem(LIBRARY_STORAGE_KEY, JSON.stringify(list));
    notifyLibraryChange('update_character');
  }

  return { success: modifiedCount > 0, modifiedCount, groupId: targetGroupId };
};

