/**
 * Helpers to detect if an option, print, mark, or detail corresponds to:
 * 1. Calligraphy, Text, or Typography (requires text input for what is written)
 * 2. Logo, Shield (Escudo), or Seal (Sello) (requires builder / written description)
 */

export const isCalligraphyOrTextOption = (typeOrName?: string, shapeOrDetail?: string): boolean => {
  if (!typeOrName && !shapeOrDetail) return false;
  const combined = `${typeOrName || ''} ${shapeOrDetail || ''}`.toLowerCase();
  
  const textKeywords = [
    'tipografía',
    'tipografia',
    'caligrafía',
    'caligrafia',
    'kanji',
    'texto:',
    'texto',
    'frase',
    'cita poética',
    'cita poetica',
    'latín',
    'latin',
    'alfanumérico',
    'alfanumerico',
    'serial number',
    'runa',
    'runas',
    'glifo',
    'glifos',
    'inscripción',
    'inscripcion',
    'escritura',
    'código',
    'codigo binario',
    'blackletter',
    'gótica',
    'gotica',
    'árabe',
    'arabe'
  ];

  return textKeywords.some(k => combined.includes(k));
};

export const isLogoShieldOrSealOption = (typeOrName?: string, shapeOrDetail?: string): boolean => {
  if (!typeOrName && !shapeOrDetail) return false;
  const combined = `${typeOrName || ''} ${shapeOrDetail || ''}`.toLowerCase();

  // Exclude 'ninguno' or 'sin'
  if (/^(ningun|sin\s|liso)/i.test(typeOrName?.trim() || '')) return false;

  const emblemKeywords = [
    'logo',
    'logotipo',
    'escudo',
    'sello',
    'blasón',
    'blason',
    'heráldic',
    'heraldic',
    'insignia',
    'parche',
    'emblema',
    'círculo de transmutación',
    'circulo de transmutacion',
    'sello de invocación',
    'sello de invocacion',
    'sello mágico',
    'sello magico',
    'sello maldito',
    'pentagrama',
    'corona',
    'crest',
    'jolly roger',
    'calavera táctica',
    'signet',
    'culto',
    'escuadrón',
    'escuadron'
  ];

  return emblemKeywords.some(k => combined.includes(k));
};
