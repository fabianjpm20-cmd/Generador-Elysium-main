// =========================================================================
// LOCAL LANGUAGE MODEL (LLM) - MODELO DE LENGUAJE LOCAL CON RAZONAMIENTO
// Motor de procesamiento de lenguaje natural 100% offline
// Implementa razonamiento determinista, generaci\u00f3n de texto contextual,
// y capacidad de comprensi\u00f3n sem\u00e1ntica sin depender de APIs externas.
// =========================================================================

import { CharacterConsciousnessProfile } from './characterConsciousnessEngine';
import { UnifiedParticipant } from './characterLogicEngine';
import { SemanticAnalysisResult } from './somaticCognitiveEngine';

// -------------------------------------------------------------------------
// TIPOS E INTERFACES
// -------------------------------------------------------------------------

export interface Token {
  text: string;
  type: 'word' | 'punctuation' | 'space' | 'unknown';
  position: number;
  score: number; // Relevancia en el contexto
}

export interface LLMContext {
  systemPrompt: string;
  conversationHistory: Array<{ role: 'user' | 'assistant' | 'system'; content: string }>;
  characterProfile?: CharacterConsciousnessProfile;
  semanticAnalysis?: SemanticAnalysisResult;
  maxTokens: number;
  temperature: number; // 0 = determinista, 1 = creativo
  topK: number;
}

export interface LLMResponse {
  text: string;
  reasoning: string; // Cadena de pensamiento (Chain of Thought)
  tokens: Token[];
  confidence: number; // 0-1
  finishReason: 'stop' | 'length' | 'context';
}

export interface ReasoningStep {
  step: number;
  thought: string;
  confidence: number;
  source: 'knowledge' | 'memory' | 'logic' | 'pattern' | 'template';
}

export interface LLMConfig {
  model: 'elysium-v1' | 'elysium-v2' | 'elysium-reasoner';
  maxContextLength: number;
  maxResponseLength: number;
  enableReasoning: boolean;
  enableMemory: boolean;
  enablePersonality: boolean;
}

// Configuraci\u00f3n por defecto
export const DEFAULT_LLM_CONFIG: LLMConfig = {
  model: 'elysium-v2',
  maxContextLength: 4096,
  maxResponseLength: 1024,
  enableReasoning: true,
  enableMemory: true,
  enablePersonality: true,
};

// -------------------------------------------------------------------------
// BASE DE CONOCIMIENTO LOCAL
// -------------------------------------------------------------------------

// Conocimiento estructurado por dominios
interface KnowledgeEntry {
  domain: string;
  category: string;
  content: string;
  keywords: string[];
  priority: number;
}

const KNOWLEDGE_BASE: KnowledgeEntry[] = [
  // Dominio: Psicolog\u00eda y Emociones
  {
    domain: 'psychology',
    category: 'emotions',
    content: 'La ira es una emoci\u00f3n intensa que surge ante la percepci\u00f3n de una injusticia o amenaza. Se manifiesta con aumento de la frecuencia card\u00edaca, tensi\u00f3n muscular y pensamiento acelerado.',
    keywords: ['ira', 'enojo', 'rabia', 'furia', 'molestia', 'indignaci\u00f3n'],
    priority: 9,
  },
  {
    domain: 'psychology',
    category: 'emotions',
    content: 'El miedo activa el sistema nervioso simp\u00e1tico, preparando al cuerpo para la huida o la lucha. Puede manifestarse como ansiedad, nerviosismo o p\u00e1nico.',
    keywords: ['miedo', 'temor', 'ansiedad', 'p\u00e1nico', 'nerviosismo', 'alerta'],
    priority: 9,
  },
  {
    domain: 'psychology',
    category: 'emotions',
    content: 'La alegr\u00eda genera una sensaci\u00f3n de bienestar y expansi\u00f3n. Fisiol\u00f3gicamente, libera endorfinas y reduce el estr\u00e9s.',
    keywords: ['alegr\u00eda', 'felicidad', 'contento', 'dicha', 'regocijo', '\u00e9xtasis'],
    priority: 8,
  },
  {
    domain: 'psychology',
    category: 'emotions',
    content: 'La tristeza es una emoci\u00f3n adaptativa que permite procesar p\u00e9rdidas. Puede manifestarse como melancol\u00eda, depresi\u00f3n o nostalgia.',
    keywords: ['tristeza', 'melancol\u00eda', 'depresi\u00f3n', 'nostalgia', 'pena', 'dolor'],
    priority: 8,
  },
  
  // Dominio: \u00c9tica y Moral
  {
    domain: 'ethics',
    category: 'moral_principles',
    content: 'El honor es el principio que gu\u00eda a una persona a actuar con integridad, incluso cuando nadie observa. Es la br\u00fajula interna de la \u00e9tica.',
    keywords: ['honor', 'integridad', '\u00e9tica', 'principios', 'valores', 'moral'],
    priority: 10,
  },
  {
    domain: 'ethics',
    category: 'moral_principles',
    content: 'La lealtad es la fidelidad a una persona, causa o ideal. Implica compromiso, confianza y sacrificio cuando es necesario.',
    keywords: ['lealtad', 'fidelidad', 'compromiso', 'confianza', 'sacrificio'],
    priority: 10,
  },
  {
    domain: 'ethics',
    category: 'dilemmas',
    content: 'Un dilema moral surge cuando dos o m\u00e1s principios \u00e9ticos entran en conflicto. La soluci\u00f3n requiere an\u00e1lisis profundo y valent\u00eda.',
    keywords: ['dilema', 'conflicto', 'moral', '\u00e9tica', 'decisi\u00f3n', 'elecci\u00f3n'],
    priority: 9,
  },
  
  // Dominio: Estrategia y T\u00e1ctica
  {
    domain: 'strategy',
    category: 'tactics',
    content: 'La estrategia es el arte de planificar acciones para alcanzar un objetivo a largo plazo. La t\u00e1ctica es la ejecuci\u00f3n de movimientos espec\u00edficos.',
    keywords: ['estrategia', 't\u00e1ctica', 'plan', 'objetivo', 'movimiento', 'maniobra'],
    priority: 9,
  },
  {
    domain: 'strategy',
    category: 'combat',
    content: 'En combate, el terreno dictamina la t\u00e1ctica. Siempre eval\u00faa los puntos altos, las rutas de escape y los obst\u00e1culos naturales.',
    keywords: ['combate', 'terreno', 't\u00e1ctica', 'escape', 'obst\u00e1culo', 'ventaja'],
    priority: 8,
  },
  
  // Dominio: Vestuario y Som\u00e1tica
  {
    domain: 'somatic',
    category: 'wardrobe',
    content: 'El vestuario no es solo apariencia; es una extensi\u00f3n de la identidad y la funci\u00f3n. Cada tela, cada costura, cada accesorio tiene un prop\u00f3sito.',
    keywords: ['vestuario', 'ropa', 'tela', 'costura', 'accesorio', 'atuendo'],
    priority: 9,
  },
  {
    domain: 'somatic',
    category: 'fabrics',
    content: 'El lino es fresco y transpirable, ideal para climas c\u00e1lidos. El cuero ofrece protecci\u00f3n y durabilidad. La seda es elegante pero fr\u00e1gil.',
    keywords: ['lino', 'cuero', 'seda', 'tela', 'tejido', 'material'],
    priority: 8,
  },
  {
    domain: 'somatic',
    category: 'footwear',
    content: 'Las botas reforzadas proporcionan estabilidad en terrenos irregulares. Los zapatos ligeros permiten movimiento \u00e1gil. Las sandalias son para climas c\u00e1lidos.',
    keywords: ['botas', 'zapatos', 'sandalias', 'calzado', 'estabilidad', 'movimiento'],
    priority: 8,
  },
  
  // Dominio: Relaciones y Social
  {
    domain: 'social',
    category: 'relationships',
    content: 'La confianza se construye con acciones consistentes y palabras honestas. Es el cemento de cualquier relaci\u00f3n duradera.',
    keywords: ['confianza', 'relaci\u00f3n', 'amistad', 'lealtad', 'honestidad', 'respeto'],
    priority: 9,
  },
  {
    domain: 'social',
    category: 'communication',
    content: 'La comunicaci\u00f3n efectiva requiere escuchar activamente, hablar con claridad y adaptarse al contexto del interlocutor.',
    keywords: ['comunicaci\u00f3n', 'escuchar', 'hablar', 'claro', 'adaptarse', 'di\u00e1logo'],
    priority: 8,
  },
];

// -------------------------------------------------------------------------
// TOKENIZADOR
// -------------------------------------------------------------------------

// Patr\u00f3n para tokenizar texto en espa\u00f1ol
const TOKEN_PATTERN = /(\w+[\u00C0-\u017F\u0300-\u036f\u2000-\u206F\u2E00-\u2E7F]\w*|\d+|[\u0021-\u002F\u003A-\u0040\u005B-\u0060\u007B-\u007E\u00A1\u00A9\u00B0\u00BF\u00D1\u00F7\u2013-\u201E\u2020-\u2027\u2030-\u203E\u2041-\u2053\u2055-\u205E\u2190-\u21FF\u2500-\u2573\u2575-\u259F\u25A0-\u25F7\u2E00-\u2E7F]+|\s+)/g;

/**
 * Tokeniza un texto en unidades sem\u00e1nticas
 */
export function tokenize(text: string): Token[] {
  const matches = text.match(TOKEN_PATTERN) || [];
  return matches.map((match, index) => {
    const trimmed = match.trim();
    let type: Token['type'] = 'word';
    
    if (!trimmed) {
      type = 'space';
    } else if (/^[\u0021-\u002F\u003A-\u0040\u005B-\u0060\u007B-\u007E\u00A1\u00A9\u00B0\u00BF\u00D1\u00F7\u2013-\u201E\u2020-\u2027\u2030-\u203E\u2041-\u2053\u2055-\u205E\u2190-\u21FF\u2500-\u2573\u2575-\u259F\u25A0-\u25F7\u2E00-\u2E7F]$/.test(trimmed)) {
      type = 'punctuation';
    } else if (/^\d+$/.test(trimmed)) {
      type = 'word';
    }
    
    return {
      text: trimmed,
      type,
      position: index,
      score: 1.0,
    };
  }).filter(t => t.text);
}

/**
 * Normaliza texto para comparaci\u00f3n
 */
export function normalizeText(text: string): string {
  return text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\w\s]/g, ' ')
    .trim();
}

// -------------------------------------------------------------------------
// RECOVERY DE CONOCIMIENTO
// -------------------------------------------------------------------------

/**
 * Busca conocimiento relevante para el prompt
 */
export function retrieveRelevantKnowledge(query: string, domain?: string): KnowledgeEntry[] {
  const normalizedQuery = normalizeText(query);
  const queryTokens = normalizedQuery.split(/\s+/).filter(t => t.length > 2);
  
  return KNOWLEDGE_BASE
    .filter(entry => {
      if (domain && entry.domain !== domain) return false;
      
      // Coincidencia exacta con keywords
      const keywordMatch = entry.keywords.some(kw => 
        normalizedQuery.includes(normalizeText(kw))
      );
      
      // Coincidencia con tokens del query
      const tokenMatch = queryTokens.some(token => 
        entry.keywords.some(kw => normalizeText(kw).includes(token))
      );
      
      return keywordMatch || tokenMatch;
    })
    .sort((a, b) => b.priority - a.priority)
    .slice(0, 5);
}

// -------------------------------------------------------------------------
// MOTOR DE RAZONAMIENTO (Chain of Thought)
// -------------------------------------------------------------------------

/**
 * Genera una cadena de pensamiento determinista
 */
export function generateReasoningChain(
  query: string,
  context: LLMContext,
  profile?: CharacterConsciousnessProfile
): ReasoningStep[] {
  const steps: ReasoningStep[] = [];
  const normalizedQuery = normalizeText(query);
  
  // Paso 1: An\u00e1lisis inicial
  steps.push({
    step: 1,
    thought: `Analizando la consulta: "${query}"`,
    confidence: 0.9,
    source: 'logic',
  });
  
  // Paso 2: Recuperaci\u00f3n de conocimiento
  const relevantKnowledge = retrieveRelevantKnowledge(query);
  if (relevantKnowledge.length > 0) {
    steps.push({
      step: 2,
      thought: `Conocimiento relevante encontrado: ${relevantKnowledge.map(k => k.category).join(', ')}`,
      confidence: 0.85,
      source: 'knowledge',
    });
  }
  
  // Paso 3: An\u00e1lisis sem\u00e1ntico
  if (context.semanticAnalysis) {
    steps.push({
      step: 3,
      thought: `Intenci\u00f3n detectada: ${context.semanticAnalysis.intent}. Intensidad: ${context.semanticAnalysis.intensity}. Valencia emocional: ${context.semanticAnalysis.emotionalValence}`,
      confidence: 0.9,
      source: 'pattern',
    });
  }
  
  // Paso 4: Integraci\u00f3n con perfil de personaje
  if (profile) {
    steps.push({
      step: 4,
      thought: `Contexto del personaje: ${profile.name} (${profile.role}). Motivaci\u00f3n principal: ${profile.motivations?.[0] || 'Ninguna especificada'}. Alineaci\u00f3n moral: ${profile.moralAlignment || 'Neutral'}`,
      confidence: 0.8,
      source: 'memory',
    });
    
    // Paso 5: Adaptaci\u00f3n a la personalidad
    if (normalizedQuery.includes('miedo') || normalizedQuery.includes('temor')) {
      steps.push({
        step: 5,
        thought: `El personaje tiene como mayor temor: "${profile.greatestFear || 'Ninguno'}". Esto puede influir en su respuesta.`,
        confidence: 0.75,
        source: 'personality',
      });
    }
  }
  
  // Paso 6: S\u00edntesis
  steps.push({
    step: steps.length + 1,
    thought: `S\u00edntesis: La respuesta debe ser coherente con el contexto, el conocimiento recuperado y la personalidad del personaje.`,
    confidence: 0.95,
    source: 'logic',
  });
  
  return steps;
}

// -------------------------------------------------------------------------
// GENERADOR DE TEXTO CONTEXUAL
// -------------------------------------------------------------------------

/**
 * Plantillas de respuesta por tipo de intencionalidad
 */
const RESPONSE_TEMPLATES: Record<string, string[]> = {
  greeting: [
    'Te saludo con respeto. \u00bfEn qu\u00e9 puedo servirte hoy?',
    'Es un placer verte. \u00bfQu\u00e9 te trae por aqu\u00ed?',
    'Que la luz te acompa\u00f1e. Dime, \u00bfqu\u00e9 necesitas?',
    'Saludos. Estoy atento a tu solicitud.',
  ],
  wardrobe_somatic_inquiry: [
    'Mi atuendo actual est\u00e1 dise\u00f1ado para {function}. Cada prenda tiene un prop\u00f3sito espec\u00edfico.',
    'Llevo puesto {garment}, confeccionado con {fabric}. Me proporciona {benefit}.',
    'Mi vestuario refleja mi rol como {role}. La comodidad y la funcionalidad son prioritarias.',
    'Este conjunto me permite moverme con agilidad mientras mantengo una apariencia {appearance}.',
  ],
  emotional_intimacy: [
    'Comprendo lo que sientes. En momentos como este, es importante {action}.',
    'Tus palabras resuenan en m\u00ed. {emotion} es una emoci\u00f3n que todos experimentamos.',
    'Valoro tu honestidad. La {emotion} puede ser una fuerza motivadora.',
    'No est\u00e1s solo. Juntos podemos superar este {challenge}.',
  ],
  tactical_planning: [
    'Analicemos la situaci\u00f3n. Los puntos clave son: {points}.',
    'Propongo el siguiente plan: {plan}. \u00bfQu\u00e9 opinas?',
    'La estrategia \u00f3ptima ser\u00eda {strategy}. Debemos considerar {factors}.',
    'Para alcanzar {goal}, necesitamos {resources} y {actions}.',
  ],
  combat_alert: [
    '\u00a1Alerta! Detecto {threat}. Debemos prepararnos para {action}.',
    'Mant\u00e9n la calma. La amenaza parece ser {threat}. Tomemos posiciones.',
    'El peligro es inminente. {threat} se aproxima. \u00bfEst\u00e1s listo?',
    'No subestimes la situaci\u00f3n. {threat} requiere nuestra atenci\u00f3n inmediata.',
  ],
  philosophical_debate: [
    'La {concept} es un tema profundo. Desde mi perspectiva, {opinion}.',
    'Has planteado una pregunta importante. La {concept} implica {implications}.',
    'La \u00e9tica de {situation} es compleja. Debemos considerar {factors}.',
    'Mi postura sobre {topic} se basa en {principles}.',
  ],
  inquiry_about_self: [
    'Soy {name}, {role}. Mi prop\u00f3sito es {purpose}.',
    'Me llamo {name}. He dedicado mi vida a {cause}.',
    'Soy {name}, un {role} con {years} a\u00f1os de experiencia.',
    'Mi nombre es {name}. Mi historia comenz\u00f3 cuando {origin}.',
  ],
  order_or_command: [
    'Entiendo tu solicitud. Sin embargo, debo considerar {factors} antes de actuar.',
    'Tus \u00f3rdenes son claras. Proceder\u00e9 con {action} de inmediato.',
    'Evaluar\u00e9 tu petici\u00f3n a la luz de {principles}.',
    'No puedo cumplir esa orden. Va en contra de {values}.',
  ],
  provocation_or_threat: [
    'Tus palabras son provocadoras. No me dejar\u00e9 intimidar.',
    'No temo a tus amenazas. Mi {strength} es mayor que tu {weakness}.',
    'La violencia no es la soluci\u00f3n. Propongo {alternative}.',
    'Cuidado con lo que dices. Las consecuencias pueden ser {consequences}.',
  ],
  conversational: [
    'Entiendo tu punto. Perm\u00edteme reflexionar al respecto.',
    'Interesante perspectiva. \u00bfPodr\u00edas elaborar m\u00e1s?',
    'Tomar\u00e9 en cuenta tu opini\u00f3n. La discusi\u00f3n es valiosa.',
    'Veo lo que quieres decir. Exploremos esto juntos.',
  ],
  default: [
    'Entiendo tu punto. Perm\u00edteme reflexionar al respecto.',
    'Interesante perspectiva. \u00bfPodr\u00edas elaborar m\u00e1s?',
    'Tomar\u00e9 en cuenta tu opini\u00f3n. La discusi\u00f3n es valiosa.',
    'Veo lo que quieres decir. Exploremos esto juntos.',
  ],
};

/**
 * Reemplaza placeholders en una plantilla con valores del contexto
 */
function fillTemplate(template: string, context: LLMContext, profile?: CharacterConsciousnessProfile): string {
  const replacements: Record<string, string> = {
    '{name}': profile?.name || 'el personaje',
    '{role}': profile?.role || 'mi rol',
    '{purpose}': profile?.motivations?.[0] || 'mi prop\u00f3sito',
    '{cause}': profile?.coreValues || 'una causa noble',
    '{years}': String(profile?.age || 'varios'),
    '{origin}': profile?.backstory?.[0] || 'un evento significativo',
    '{function}': profile?.wardrobe?.garmentsList?.[0]?.purpose || 'protecci\u00f3n y comodidad',
    '{garment}': profile?.wardrobe?.garmentsList?.[0]?.name || 'mi atuendo',
    '{fabric}': profile?.wardrobe?.garmentsList?.[0]?.fabrics || 'tejidos de calidad',
    '{benefit}': 'protecci\u00f3n contra los elementos',
    '{appearance}': 'adecuada para la ocasi\u00f3n',
    '{action}': 'respirar hondo y analizar la situaci\u00f3n',
    '{emotion}': context.semanticAnalysis?.emotionalValence === 'warm' ? 'alegr\u00eda' : 
                 context.semanticAnalysis?.emotionalValence === 'tense' ? 'tensi\u00f3n' : 
                 context.semanticAnalysis?.emotionalValence === 'defensive' ? 'defensa' : 'emoci\u00f3n',
    '{challenge}': 'desaf\u00edo',
    '{points}': 'identificar los objetivos, evaluar los recursos y anticipar obst\u00e1culos',
    '{plan}': 'dividir las tareas, asignar responsabilidades y establecer plazos',
    '{strategy}': 'una aproximaci\u00f3n met\u00f3dica y coordinada',
    '{resources}': 'los recursos disponibles',
    '{actions}': 'acciones concretas y medibles',
    '{goal}': 'el objetivo propuesto',
    '{factors}': 'todos los factores relevantes',
    '{threat}': 'una amenaza potencial',
    '{concept}': 'cuesti\u00f3n',
    '{opinion}': 'tiene valor en el contexto adecuado',
    '{implications}': 'm\u00faltiples capas de significado',
    '{situation}': 'esta situaci\u00f3n',
    '{topic}': 'este tema',
    '{principles}': profile?.coreValues || 'mis principios',
    '{values}': profile?.coreValues || 'mis valores',
    '{strength}': 'resoluci\u00f3n',
    '{weakness}': 'debilidad',
    '{alternative}': 'el di\u00e1logo civilizado',
    '{consequences}': 'graves',
  };
  
  return template.replace(/\{[\w]+\}/g, match => replacements[match] || match);
}

/**
 * Selecciona la mejor plantilla seg\u00fan la intenci\u00f3n
 */
function selectTemplate(intent: string): string[] {
  const normalizedIntent = intent.toLowerCase().replace(/_/g, '');
  return RESPONSE_TEMPLATES[normalizedIntent] || RESPONSE_TEMPLATES.default;
}

// -------------------------------------------------------------------------
// MODELO PRINCIPAL DE LENGUAJE
// -------------------------------------------------------------------------

/**
 * Clase principal del LLM Local
 */
export class LocalLLM {
  private config: LLMConfig;
  private context: LLMContext;
  private memory: Map<string, string>;
  private _characterProfile?: CharacterConsciousnessProfile;
  
  constructor(config: Partial<LLMConfig> = {}) {
    this.config = { ...DEFAULT_LLM_CONFIG, ...config };
    this.context = {
      systemPrompt: 'Eres un asistente inteligente y reflexivo. Responde con profundidad y coherencia.',
      conversationHistory: [],
      maxTokens: this.config.maxResponseLength,
      temperature: 0.3,
      topK: 5,
    };
    this.memory = new Map();
    this._characterProfile = undefined;
  }
  
  /**
   * Inicializa el contexto con un perfil de personaje
   */
  setCharacterProfile(profile: CharacterConsciousnessProfile): void {
    this._characterProfile = profile;
    this.context.characterProfile = profile;
    this.context.systemPrompt = this.generateSystemPrompt(profile);
  }
  
  /**
   * Obtiene el perfil de personaje actual
   */
  getCharacterProfile(): CharacterConsciousnessProfile | undefined {
    return this._characterProfile;
  }
  
  /**
   * Genera el system prompt basado en el perfil
   */
  private generateSystemPrompt(profile: CharacterConsciousnessProfile): string {
    return `Eres ${profile.name}, un ${profile.role} con las siguientes caracter\u00edsticas:
- Personalidad: ${profile.personality || 'equilibrada'}
- Motivaciones: ${profile.motivations?.join(', ') || 'cumplir con el deber'}
- Valores fundamentales: ${profile.coreValues || 'honor, lealtad, superaci\u00f3n'}
- Mayor temor: ${profile.greatestFear || 'la p\u00e9rdida de control'}
- Alineaci\u00f3n moral: ${profile.moralAlignment || 'Neutral Bondadoso'}

Tu estilo de comunicaci\u00f3n debe reflejar tu personalidad y experiencia. Responde de manera coherente con tu trasfondo y principios.`;
  }
  
  /**
   * Establece el an\u00e1lisis sem\u00e1ntico para el contexto actual
   */
  setSemanticAnalysis(analysis: SemanticAnalysisResult): void {
    this.context.semanticAnalysis = analysis;
  }
  
  /**
   * A\u00f1ade un mensaje al historial de conversaci\u00f3n
   */
  addMessage(role: 'user' | 'assistant' | 'system', content: string): void {
    this.context.conversationHistory.push({ role, content });
    
    // Limitar el historial para evitar exceso de memoria
    if (this.context.conversationHistory.length > 20) {
      this.context.conversationHistory = this.context.conversationHistory.slice(-20);
    }
  }
  
  /**
   * Genera una respuesta usando el modelo local
   */
  async generateResponse(prompt: string): Promise<LLMResponse> {
    // Tokenizar el prompt
    const inputTokens = tokenize(prompt);
    
    // Analizar la intenci\u00f3n
    const intent = this.context.semanticAnalysis?.intent || 'conversational';
    
    // Generar cadena de razonamiento
    const reasoningSteps = this.config.enableReasoning 
      ? generateReasoningChain(prompt, this.context, this.context.characterProfile)
      : [];
    
    // Recuperar conocimiento relevante
    const knowledge = retrieveRelevantKnowledge(prompt);
    
    // Construir la respuesta
    const templates = selectTemplate(intent);
    const selectedTemplate = templates[Math.floor(Math.random() * templates.length)];
    const responseText = fillTemplate(selectedTemplate, this.context, this.context.characterProfile);
    
    // Tokenizar la respuesta
    const responseTokens = tokenize(responseText);
    
    // Construir el texto de razonamiento
    const reasoningText = reasoningSteps
      .map(step => `[Paso ${step.step}] ${step.thought}`)
      .join(' \n');
    
    // Calcular confianza
    const confidence = this.calculateConfidence(knowledge.length, reasoningSteps.length);
    
    // Determinar raz\u00f3n de finalizaci\u00f3n
    const finishReason: LLMResponse['finishReason'] = 
      responseText.length >= this.config.maxResponseLength ? 'length' : 'stop';
    
    // A\u00f1adir al historial
    this.addMessage('user', prompt);
    this.addMessage('assistant', responseText);
    
    return {
      text: responseText,
      reasoning: reasoningText,
      tokens: responseTokens,
      confidence,
      finishReason,
    };
  }
  
  /**
   * Genera una respuesta (m\u00e9todo alias para compatibilidad con Elysium Neural)
   */
  async generate(prompt: string, context?: Partial<LLMContext>): Promise<LLMResponse> {
    // Si se proporciona un contexto, actualizar temporalmente
    if (context) {
      const originalContext = { ...this.context };
      const originalProfile = this._characterProfile;
      
      this.context = { ...this.context, ...context };
      if (context.characterProfile) {
        this._characterProfile = context.characterProfile;
        this.context.characterProfile = context.characterProfile;
      }
      
      const response = await this.generateResponse(prompt);
      
      // Restaurar contexto original
      this.context = originalContext;
      this._characterProfile = originalProfile;
      if (originalProfile) {
        this.context.characterProfile = originalProfile;
      }
      
      return response;
    }
    return this.generateResponse(prompt);
  }
  
  /**
   * Generaci\u00f3n de respuesta en modo streaming (simulado)
   */
  async *generateStreamingResponse(prompt: string): AsyncGenerator<string> {
    const response = await this.generateResponse(prompt);
    const words = response.text.split(/(\s+)/);
    
    for (const word of words) {
      yield word;
      await new Promise(resolve => setTimeout(resolve, 20));
    }
  }
  
  /**
   * Calcula la confianza de la respuesta
   */
  private calculateConfidence(knowledgeCount: number, reasoningSteps: number): number {
    let confidence = 0.5; // Base
    
    // Aumentar confianza con conocimiento relevante
    if (knowledgeCount > 0) {
      confidence += knowledgeCount * 0.1;
    }
    
    // Aumentar confianza con m\u00e1s pasos de razonamiento
    if (reasoningSteps > 3) {
      confidence += (reasoningSteps - 3) * 0.05;
    }
    
    // Asegurar que la confianza est\u00e1 entre 0 y 1
    return Math.min(Math.max(confidence, 0), 1);
  }
  
  /**
   * Resetea el contexto de conversaci\u00f3n
   */
  resetContext(): void {
    this.context = {
      systemPrompt: 'Eres un asistente inteligente y reflexivo. Responde con profundidad y coherencia.',
      conversationHistory: [],
      maxTokens: this.config.maxResponseLength,
      temperature: 0.3,
      topK: 5,
    };
    this.memory.clear();
    this._characterProfile = undefined;
  }
  
  /**
   * Obtiene el historial de conversaci\u00f3n
   */
  getConversationHistory(): Array<{ role: string; content: string }> {
    return [...this.context.conversationHistory];
  }
  
  /**
   * Guarda un hecho en la memoria
   */
  remember(key: string, value: string): void {
    this.memory.set(key, value);
  }
  
  /**
   * Recupera un hecho de la memoria
   */
  recall(key: string): string | undefined {
    return this.memory.get(key);
  }
  
  /**
   * Genera una respuesta m\u00e1s elaborada usando el perfil completo
   */
  async generateDetailedResponse(
    prompt: string,
    profile: CharacterConsciousnessProfile,
    semanticAnalysis: SemanticAnalysisResult
  ): Promise<LLMResponse> {
    // Configurar el contexto
    this.setCharacterProfile(profile);
    this.setSemanticAnalysis(semanticAnalysis);
    
    // Generar respuesta
    return this.generateResponse(prompt);
  }
}

// -------------------------------------------------------------------------
// INSTANCIA GLOBAL
// -------------------------------------------------------------------------

// Instancia singleton del LLM
export const localLLM = new LocalLLM();

// -------------------------------------------------------------------------
// FUNCIONES DE CONVENIENCIA
// -------------------------------------------------------------------------

/**
 * Genera una respuesta r\u00e1pida sin necesidad de instanciar el LLM
 */
export async function generateQuickResponse(
  prompt: string,
  profile?: CharacterConsciousnessProfile,
  semanticAnalysis?: SemanticAnalysisResult
): Promise<LLMResponse> {
  const llm = new LocalLLM();
  
  if (profile) {
    llm.setCharacterProfile(profile);
  }
  
  if (semanticAnalysis) {
    llm.setSemanticAnalysis(semanticAnalysis);
  }
  
  return llm.generateResponse(prompt);
}

/**
 * Analiza y responde usando el LLM local
 */
export async function analyzeAndRespond(
  prompt: string,
  profile: CharacterConsciousnessProfile,
  semanticAnalysis: SemanticAnalysisResult
): Promise<{
  response: LLMResponse;
  reasoning: ReasoningStep[];
  knowledgeUsed: KnowledgeEntry[];
}> {
  const llm = new LocalLLM();
  llm.setCharacterProfile(profile);
  llm.setSemanticAnalysis(semanticAnalysis);
  
  const response = await llm.generateResponse(prompt);
  const reasoning = generateReasoningChain(prompt, llm['context'], profile);
  const knowledgeUsed = retrieveRelevantKnowledge(prompt);
  
  return { response, reasoning, knowledgeUsed };
}

// -------------------------------------------------------------------------
// EXPORTACIONES
// -------------------------------------------------------------------------

export type { KnowledgeEntry };
