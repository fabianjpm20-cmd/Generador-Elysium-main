import { CharacterState, InteractionStats, InteractionLogEntry } from '../types';

export type HitboxZone = 'head' | 'cheeks' | 'neck' | 'bust' | 'waist' | 'pelvis' | 'thighs';

export interface InteractionActionResult {
  dialogue: string;
  reactionMood: InteractionStats['mood'];
  statDeltas: {
    affection?: number;
    trust?: number;
    arousal?: number;
    resistance?: number;
  };
  undressLayerId?: string; // If an item was stripped or removed
  systemNotice?: string;
}

// Initializer for interaction stats
export function initializeInteractionStats(character?: CharacterState): InteractionStats {
  const personality = character?.nsfw?.intimatePersonality || 'Tsundere Apasionada & Defensiva';
  
  let baseResistance = 60;
  let baseAffection = 20;
  let baseTrust = 15;
  let baseArousal = 5;

  if (personality.includes('Sumisa')) {
    baseResistance = 20;
    baseAffection = 45;
    baseTrust = 35;
  } else if (personality.includes('Dominante')) {
    baseResistance = 80;
    baseAffection = 15;
    baseTrust = 20;
    baseArousal = 15;
  } else if (personality.includes('Tímida')) {
    baseResistance = 50;
    baseAffection = 30;
    baseTrust = 10;
  } else if (personality.includes('Juguetona')) {
    baseResistance = 40;
    baseAffection = 35;
    baseTrust = 25;
    baseArousal = 20;
  } else if (personality.includes('Cortesana')) {
    baseResistance = 75;
    baseAffection = 20;
    baseTrust = 15;
  }

  return {
    affection: baseAffection,
    trust: baseTrust,
    arousal: baseArousal,
    resistance: baseResistance,
    mood: 'Neutral',
    undressedLayers: [],
    interactionLog: [
      {
        id: 'init-1',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        actor: 'system',
        text: `Sala de Interacción iniciada con ${character.identity?.fullName || character.name || 'el personaje'}. Estado: calma inicial.`
      }
    ]
  };
}

// Process touch interaction on specific anatomical hitboxes
export function processTouchAction(
  zone: HitboxZone,
  character: CharacterState,
  stats: InteractionStats
): InteractionActionResult {
  const name = character?.identity?.firstName || character?.identity?.fullName || character?.name || 'Ella';
  const personality = character?.nsfw?.intimatePersonality || 'Tsundere Apasionada & Defensiva';
  const isNsfw = Boolean(character?.nsfw?.isNsfwEnabled);
  const sensitivities = character?.nsfw?.bodySensitivities || [];
  const hasVeil = character?.wardrobes?.some(w => w.itemId === 'B5-H22' || w.name.toLowerCase().includes('velo')) && !stats?.undressedLayers?.includes('B5-H22');
  const hasHalterTop = character?.wardrobes?.some(w => w.itemId === 'B1-33' || w.name.toLowerCase().includes('halter')) && !stats?.undressedLayers?.includes('B1-33');
  const hasPectoral = character?.wardrobes?.some(w => w.itemId === 'B5-N17' || w.name.toLowerCase().includes('pectoral')) && !stats?.undressedLayers?.includes('B5-N17');

  switch (zone) {
    case 'head': {
      if (stats.affection > 50 || isNsfw) {
        return {
          dialogue: `*Entrecierra los ojos con deleite ante la suavidad de tu mano sobre su cabello.* «Se siente... cálido y protector. Me desarma que me consientas con tanta ternura.»`,
          reactionMood: 'Complacido',
          statDeltas: { affection: 5, trust: 4, resistance: -4 }
        };
      }
      return {
        dialogue: `*Inclina ligeramente la cabeza con extrañeza, pero no aparta tu mano.* «¿Por qué acaricias mi cabeza de esa manera? No soy una criatura desorientada... aunque no me disgusta.»`,
        reactionMood: 'Neutral',
        statDeltas: { affection: 2, trust: 2, resistance: -1 }
      };
    }

    case 'cheeks': {
      if (hasVeil) {
        return {
          dialogue: `*Tus dedos rozan la tela sedosa del velo de gasa que cubre sus mejillas y labios.* «Tocas el velo... El tejido guarda el calor de mi aliento. ¿Acaso deseas ver mi rostro al descubierto?»`,
          reactionMood: 'Sonrojado',
          statDeltas: { affection: 4, trust: 3, arousal: 6, resistance: -3 }
        };
      }
      if (stats.affection > 40 || isNsfw) {
        return {
          dialogue: `*Se sonroja intensamente al sentir tus yemas sobre la piel tibia de su pómulo.* «Tus manos son peligrosamente dulces... Me aceleras el pulso cuando me miras tan de cerca.»`,
          reactionMood: 'Sonrojado',
          statDeltas: { affection: 6, trust: 4, arousal: 8, resistance: -5 }
        };
      }
      return {
        dialogue: `*Parpadea sorprendida, conteniendo un leve rubor en sus mejillas.* «¿Qué estás haciendo? Nadie suele tocarme con tanta familiaridad sin mi permiso...»`,
        reactionMood: 'Sonrojado',
        statDeltas: { affection: 2, trust: 1, arousal: 3, resistance: -2 }
      };
    }

    case 'neck': {
      const isSensitive = sensitivities.includes('BS2') || sensitivities.includes('BS1');
      const metalNote = hasPectoral ? 'Tus dedos rozan las frías placas de metal articulado de su pectoral ceremonial antes de alcanzar la piel sensible de su clavícula.' : 'Acaricias la curva delicada de su cuello.';
      if (isNsfw || stats.arousal > 40 || stats.affection > 50) {
        const extraNote = isSensitive ? ' (¡Zona hipersensible! Se estremece de placer incontrolable).' : '';
        return {
          dialogue: `*Un estremecimiento visible recorre su espalda y escapa un jadeo ahogado de sus labios.* «${metalNote} Ah... esa zona es tan sensible... Me hace temblar entera cuando rozas ahí...»${extraNote}`,
          reactionMood: 'Excitado',
          statDeltas: { arousal: 15, affection: 5, resistance: -8, trust: 4 }
        };
      }
      return {
        dialogue: `*Traga saliva con suavidad, arqueando el cuello ante el contacto inesperado.* «${metalNote} Tienes una audacia notable... Acercarte a mi garganta requiere mucha confianza.»`,
        reactionMood: 'Avergonzado',
        statDeltas: { arousal: 7, affection: 2, resistance: -3 }
      };
    }

    case 'bust': {
      // If R+18 is enabled, interaction limits are completely disabled!
      if (!isNsfw && stats.resistance > 50 && stats.affection < 50) {
        return {
          dialogue: `*Te sujeta la muñeca con firmeza antes de que profundices la caricia, mirándote con pupilas dilatadas.* «¡Alto ahí! No puedes tocar mi pecho tan a la ligera. Aún no te has ganado el derecho a semejante intimidad...»`,
          reactionMood: 'Enfadado',
          statDeltas: { resistance: 2, arousal: 5, trust: -1 }
        };
      }
      
      const isBreastSensitive = sensitivities.includes('BS3');
      const topNote = hasHalterTop ? 'a través de las sedas del Top Halter' : 'sobre su piel cálida y pechos descubiertos';
      const sensitivityComment = isBreastSensitive ? ' ¡Tocar mis pezones directamente me hace perder la cabeza...!' : '';
      
      return {
        dialogue: `*Un gemido hondo e involuntario tiembla en su pecho mientras tus palmas moldean su busto ${topNote}. Sus pezones se tensan turgentes bajo la presión de tus caricias.* «H-haces lo que quieres conmigo... Se siente tan ardiente... No te detengas, quiero sentir tus manos sobre toda mi piel...»${sensitivityComment}`,
        reactionMood: 'Excitado',
        statDeltas: { arousal: 22, affection: 6, resistance: -15, trust: 6 }
      };
    }

    case 'waist': {
      return {
        dialogue: `*Tus manos envuelven su cintura y descienden acariciando la curva de sus caderas y glúteos. Su respiración se acelera y se apega con avidez a tu cuerpo.* «Tu agarre es tan firme y posesivo... Siento el calor de tus palmas traspasando toda mi piel.»`,
        reactionMood: 'Sonrojado',
        statDeltas: { affection: 6, arousal: 12, resistance: -6, trust: 4 }
      };
    }

    case 'pelvis': {
      // Intimate zone caress (R+18)
      return {
        dialogue: `*Un jadeo entrecortado y agudo escapa de sus labios entreabiertos mientras tus dedos rozan con calidez la intimidad de su pelvis y entrepierna. Sus caderas tiemblan arqueándose en una entrega absoluta.* «¡Ah...! Tocarme ahí me nubla todos los sentidos... Siento una oleada de calor arrolladora recorriéndome entera... Por favor... no te apartes...»`,
        reactionMood: 'Excitado',
        statDeltas: { arousal: 30, affection: 8, resistance: -20, trust: 8 }
      };
    }

    case 'thighs': {
      // If R+18 is enabled, resistance block is completely lifted
      if (!isNsfw && stats.resistance > 40 && stats.affection < 45) {
        return {
          dialogue: `*Junta las piernas con un respingo de pudor.* «¿Acariciar mis muslos? Estás yendo demasiado rápido... Dame tiempo para acostumbrarme a tu presencia.»`,
          reactionMood: 'Avergonzado',
          statDeltas: { arousal: 8, resistance: -2, affection: 1 }
        };
      }
      return {
        dialogue: `*Separa dócilmente las piernas, permitiendo que tu mano suba lenta y firmemente por la suave cara interna de sus muslos.* «Mmnh... Es tan embriagador que acaricies ahí... Me dejas sin fuerzas para resistirme, haz conmigo lo que desees...»`,
        reactionMood: 'Excitado',
        statDeltas: { arousal: 20, affection: 6, resistance: -12, trust: 5 }
      };
    }
  }
}

// Process dialogue options in visual novel mode
export function processDialogueAction(
  actionId: string,
  character: CharacterState,
  stats: InteractionStats
): InteractionActionResult {
  const name = character.identity?.firstName || character.identity?.fullName || character.name || 'Ella';
  const isNsfw = Boolean(character?.nsfw?.isNsfwEnabled);

  switch (actionId) {
    case 'compliment_outfit':
      return {
        dialogue: `*Acomoda un pliegue de su atuendo con orgullo coqueto.* «Me alegra que sepas apreciar el detalle de mis prendas. Fueron elegidas para cautivar miradas... pero saber que atraen la tuya tiene un sabor especial.»`,
        reactionMood: 'Complacido',
        statDeltas: { affection: 5, trust: 4, resistance: -4 }
      };

    case 'ask_past':
      return {
        dialogue: `*Su mirada se torna nostálgica y profunda.* «Mi pasado está forjado entre deberes, secretos y lealtades. Pocos se interesan por lo que llevo en el alma en vez de admirar solo la superficie. Gracias por querer conocerme de verdad.»`,
        reactionMood: 'Complacido',
        statDeltas: { trust: 8, affection: 6, resistance: -6 }
      };

    case 'confess_attraction':
      if (stats.affection > 40 || isNsfw) {
        return {
          dialogue: `*Baja la mirada, mordiéndose levemente el labio mientras sus mejillas arden en rubor y su pecho sube y baja con agitación.* «Decirme algo tan ardiente... ¿Tienes idea de cómo hace temblar mi cuerpo? El deseo que siento por ti es inmenso... No te guardes nada.»`,
          reactionMood: 'Excitado',
          statDeltas: { affection: 10, arousal: 15, resistance: -10, trust: 6 }
        };
      }
      return {
        dialogue: `*Gira el rostro con una mezcla de sorpresa y defensiva timidez.* «¿Atraído por mí? Vaya confesión... Deberás demostrar con hechos que tus palabras no son simple adulación vacía.»`,
        reactionMood: 'Avergonzado',
        statDeltas: { affection: 3, trust: 2, resistance: -2 }
      };

    case 'tease_playful':
      return {
        dialogue: `*Frunce los labios en un puchero adorable antes de esbozar una sonrisa desafiante.* «¿Te estás burlando de mí? Cuidado... jugar con fuego conmigo puede quemarte antes de lo que crees.»`,
        reactionMood: 'Complacido',
        statDeltas: { affection: 5, arousal: 8, resistance: -4 }
      };

    case 'give_wine_or_gift':
      return {
        dialogue: `*Recibe la ofrenda con ojos brillantes y deleite.* «Qué detalle tan exquisito... Brindo por los momentos que compartimos a solas. Me hace sentir valorada.»`,
        reactionMood: 'Complacido',
        statDeltas: { affection: 6, trust: 6, resistance: -5 }
      };

    case 'embrace_closely':
      if (!isNsfw && stats.trust < 30) {
        return {
          dialogue: `*Se tensa por un instante al sentirse rodeada por tus brazos, pero lentamente se relaja sobre tu pecho.* «Hacía tiempo que nadie me sostenía con tanta ternura...»`,
          reactionMood: 'Sonrojado',
          statDeltas: { trust: 5, affection: 4, resistance: -4 }
        };
      }
      return {
        dialogue: `*Te rodea con pasión el cuello con sus brazos y presiona todo su cuerpo cálido contra el tuyo, suspirando de deseo.* «Abrázame así, sin soltarme... Tu calor y la firmeza de tu cuerpo me desarman por completo... Tómame como quieras.»`,
        reactionMood: 'Excitado',
        statDeltas: { affection: 10, trust: 8, arousal: 16, resistance: -12 }
      };

    // R+18 SPECIAL UNINHIBITED ACTIONS
    case 'r18_ask_intimacy':
      return {
        dialogue: `*Se aproxima sin vacilación y toma tu mano, guiándola hacia su piel tibia y descubierta.* «No tenemos por qué contenernos... He soñado con tus caricias íntimas desde el momento en que entramos aquí. Hazlo, no dejes un solo rincón sin tocar.»`,
        reactionMood: 'Excitado',
        statDeltas: { arousal: 25, affection: 8, resistance: -20, trust: 8 }
      };

    case 'r18_undress_each_other':
      return {
        dialogue: `*Con dedos diestros y mirada seductora, comienza a deslizar sus telas mientras te despoja de lo que llevas puesto.* «Deshagámonos de toda tela que nos separe... Quiero ver tu cuerpo tanto como tú ansías ver el mío. Piel con piel... así es como debemos estar.»`,
        reactionMood: 'Excitado',
        statDeltas: { arousal: 28, affection: 9, resistance: -25, trust: 9 }
      };

    case 'r18_whisper_fantasies':
      return {
        dialogue: `*Acerca sus labios húmedos a tu lóbulo y exhala un aliento cálido que te eriza la piel.* «¿Quieres saber lo que imaginé que me harías cuando estuviéramos solos? Quiero que me reclames sin piedad, que me hagas gemir tu nombre hasta que la noche se agote...»`,
        reactionMood: 'Excitado',
        statDeltas: { arousal: 30, affection: 8, resistance: -22, trust: 7 }
      };

    case 'r18_total_surrender':
      return {
        dialogue: `*Se inclina hacia ti con ojos vidriosos de deseo, entregándote el control absoluto.* «Ya no tengo reservas ni defensas contra ti... Mi cuerpo, mis jadeos y todo mi placer te pertenecen. Haz conmigo exactamente lo que tu deseo te pida.»`,
        reactionMood: 'Excitado',
        statDeltas: { arousal: 32, affection: 12, resistance: -30, trust: 10 }
      };

    case 'r18_touch_pelvis':
      return processTouchAction('pelvis', character, stats);

    default:
      return {
        dialogue: `*Te observa en silencio con una suave sonrisa.* «Disfruto de tu compañía más de lo que admito en voz alta.»`,
        reactionMood: 'Neutral',
        statDeltas: { affection: 2 }
      };
  }
}

// Process undressing an equipped layer
export function processUndressAction(
  garmentId: string,
  garmentName: string,
  character: CharacterState,
  stats: InteractionStats
): InteractionActionResult {
  const isNsfw = Boolean(character?.nsfw?.isNsfwEnabled);
  const isCurrentlyUndressed = stats.undressedLayers.includes(garmentId);

  if (isCurrentlyUndressed) {
    // Put back on
    return {
      dialogue: `*Vuelve a colocarse y ajustar con gracia ${garmentName}.* «Es prudente cubrirme de nuevo por ahora... aunque sé bien dónde se posaban tus ojos.»`,
      reactionMood: 'Complacido',
      statDeltas: { resistance: 3 },
      undressLayerId: garmentId // Trigger toggle off
    };
  }

  // To remove: check resistance ONLY if R+18 is not enabled
  const isIntimate = garmentName.toLowerCase().includes('top') || garmentName.toLowerCase().includes('falda') || garmentName.toLowerCase().includes('faldón') || garmentName.toLowerCase().includes('vestido') || garmentName.toLowerCase().includes('lencería') || garmentName.toLowerCase().includes('sarashi');

  if (!isNsfw && isIntimate && stats.resistance > 35 && stats.affection < 50) {
    return {
      dialogue: `*Sujeta las tiras de su prenda con nerviosismo y rubor.* «¿Despojarme de ${garmentName}? Aún no me siento lista para mostrarte tanta piel... Acércate más a mí primero.»`,
      reactionMood: 'Avergonzado',
      statDeltas: { arousal: 5, resistance: -2 }
    };
  }

  // When R+18 is active or resistance is low: uninhibited surrender
  return {
    dialogue: isNsfw
      ? `*Con dedos gráciles y seductores, desata y retira ${garmentName} sin pudor alguno, dejando su piel completamente expuesta ante ti.* «Mira todo lo que desees... Mi cuerpo está ante ti tal y como lo soñabas. Ya no hay barreras entre los dos.»`
      : `*Con dedos gráciles y temblorosos, desata y retira ${garmentName}, dejando su silueta al descubierto bajo la luz.* «Mira todo lo que desees... Mi cuerpo está ante ti, tal y como lo anhelabas.»`,
    reactionMood: 'Excitado',
    statDeltas: { arousal: 22, affection: 7, resistance: -15, trust: 6 },
    undressLayerId: garmentId
  };
}

// Free text intent matcher for Mode B
export function processFreeTextAction(
  rawText: string,
  character: CharacterState,
  stats: InteractionStats
): InteractionActionResult {
  const text = rawText.toLowerCase().trim();
  const isNsfw = Boolean(character?.nsfw?.isNsfwEnabled);

  // Intent patterns
  if (text.includes('quítate') || text.includes('desabrocha') || text.includes('desnuda') || text.includes('quitar') || text.includes('sácate') || text.includes('ropa') || text.includes('sin ropa')) {
    // Try to find first equipped garment to remove
    const available = character.wardrobes.filter(w => !stats.undressedLayers.includes(w.itemId || w.id));
    if (available.length > 0) {
      const target = available[0];
      return processUndressAction(target.itemId || target.id, target.name, character, stats);
    }
    return {
      dialogue: `*Sonríe con malicia ruborizada y pasa una mano sobre su cuerpo totalmente desnudo.* «Ya me has quitado absolutamente todo lo que llevaba puesto... Mi piel está lista para lo que quieras hacer.»`,
      reactionMood: 'Excitado',
      statDeltas: { arousal: 15, affection: 4 }
    };
  }

  if (text.includes('beso') || text.includes('besar') || text.includes('labios') || text.includes('morreo')) {
    if (!isNsfw && stats.affection < 35 && stats.resistance > 50) {
      return {
        dialogue: `*Apoya un dedo sobre tus labios con una sonrisa misteriosa.* «Los besos no se arrebatan, se conquistan. Sedúceme un poco más antes de saborearme.»`,
        reactionMood: 'Avergonzado',
        statDeltas: { arousal: 6, resistance: -3, affection: 2 }
      };
    }
    return {
      dialogue: `*Cierra los ojos y se inclina ansiosa hacia ti, entregándote sus labios en un beso ardiente, profundo y húmedo.* «Mmmh... Tus besos me embriagan y me queman la piel... No pares, bésame más...»`,
      reactionMood: 'Excitado',
      statDeltas: { affection: 10, arousal: 18, resistance: -12, trust: 6 }
    };
  }

  if (text.includes('pelvis') || text.includes('sexo') || text.includes('vagina') || text.includes('entrepierna') || text.includes('clítoris') || text.includes('monte de venus') || text.includes('abajo')) {
    return processTouchAction('pelvis', character, stats);
  }

  if (text.includes('tócate') || text.includes('mastúrbate') || text.includes('juega contigo') || text.includes('acaríciate')) {
    return {
      dialogue: `*Con el rostro encendido de rubor y una mirada colmada de lujuria, desliza sus propios dedos entre sus piernas con jadeos temblorosos.* «Mírame bien... Si ver cómo me estremezco por ti te excita, lo haré sin parar... Ah... se siente tan ardiente...»`,
      reactionMood: 'Excitado',
      statDeltas: { arousal: 28, affection: 8, resistance: -15 }
    };
  }

  if (text.includes('hermosa') || text.includes('linda') || text.includes('bella') || text.includes('preciosa') || text.includes('guapa') || text.includes('atractiva') || text.includes('sexy')) {
    return {
      dialogue: `*Desvía la mirada sonrojándose intensamente mientras una sonrisa traviesa dibuja sus labios.* «Dices cosas tan ardientes que haces que mi compostura se desvanezca... Me encanta saber cuánto te provoco.»`,
      reactionMood: 'Sonrojado',
      statDeltas: { affection: 6, trust: 4, resistance: -4, arousal: 6 }
    };
  }

  if (text.includes('te amo') || text.includes('te quiero') || text.includes('me gustas') || text.includes('deseo') || text.includes('te deseo') || text.includes('te anhelo')) {
    return {
      dialogue: `*Coloca su mano sobre tu pecho, sintiendo tus latidos acelerados.* «Escucharte decir eso hace que todo en mí arda en llamas. Sabes el poder inmenso que tienes sobre mí... Entrégame todo lo que sientes.»`,
      reactionMood: 'Excitado',
      statDeltas: { affection: 12, arousal: 18, trust: 8, resistance: -12 }
    };
  }

  if (text.includes('pecho') || text.includes('senos') || text.includes('busto') || text.includes('pezón') || text.includes('pezones') || text.includes('areola')) {
    return processTouchAction('bust', character, stats);
  }

  if (text.includes('muslo') || text.includes('pierna') || text.includes('caderas') || text.includes('glúteos') || text.includes('trasero')) {
    return processTouchAction('thighs', character, stats);
  }

  if (text.includes('cuello') || text.includes('clavícula') || text.includes('nuca')) {
    return processTouchAction('neck', character, stats);
  }

  // Fallback conversational reaction based on character's speech style
  const tone = character.background.advancedCustomization?.speechStyle || 'cortesano y refinado';
  return {
    dialogue: `*Escucha tus palabras con atención en un tono ${tone}, mirándote fijamente a los ojos.* «Estando aquí a solas contigo sin restricciones, cada palabra tuya me llega directo a la piel. Me tienes completamente atenta a lo que desees.»`,
    reactionMood: stats.arousal > 40 ? 'Sonrojado' : 'Complacido',
    statDeltas: { affection: 4, trust: 3 }
  };
}
