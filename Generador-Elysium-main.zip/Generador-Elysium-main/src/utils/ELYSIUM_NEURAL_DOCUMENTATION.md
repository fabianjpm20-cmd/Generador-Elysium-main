# Elysium Neural - Documentación del Sistema

## 📖 Introducción

**Elysium Neural** es un **modelo de lenguaje basado en texto orientado al rolplay** con **razonamiento cognitivo local avanzado**. Este sistema ha sido diseñado específicamente para proporcionar una experiencia de juego de rol inmersiva, coherente y dinámica, completamente funcional sin depender de APIs externas de IA.

### 🎯 Objetivos Principales

1. **Comprensión profunda** de la entrada del usuario (semántica, contexto, subtexto)
2. **Razonamiento cognitivo local** avanzado (Chain of Thought, memoria contextual)
3. **Generación de respuestas** coherentes y contextualizadas
4. **Interpretación avanzada de personajes** (psicología, moral, motivaciones, vestuario somático)
5. **Sistema de conocimiento ontológico** local (física, vestuario, arquitectura, mundo)
6. **Capacidad de simulación autónoma** de personajes con autoconciencia

---

## 🏗️ Arquitectura del Sistema

### Componentes Principales

```
┌─────────────────────────────────────────────────────────────────┐
│                    ELYSIUM NEURAL CORE                              │
│  ┌─────────────────────────────────────────────────────────────┐│
│  │                    processInput()                              ││
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  ││
│  │  │  Analizador  │  │  Recuperador │  │   Generador de        │  ││
│  │  │  Semántico  │  │ de Conocim. │  │    Respuestas         │  ││
│  │  └─────────────┘  └─────────────┘  └─────────────────────┘  ││
│  │         │              │                    │                ││
│  └─────────┬──────────────┬────────────────┬────────────────┘│
│            │              │                │                      │
│  ┌─────────▼─────┐ ┌───────▼───────┐ ┌────────▼──────────┐   │
│  │ Análisis       │ │ Razonamiento   │ │ Generación de       │   │
│  │ Semántico      │ │ (Chain of      │ │ Respuesta          │   │
│  │ y Subtexto     │ │  Thought)      │ │ Contextualizada    │   │
│  └───────────────┘ └───────────────┘ └────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
         │                    │                    │
         ▼                    ▼                    ▼
┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐
│  localLLM.ts     │ │ somaticCognitive │ │ conversation      │
│  - Tokenización  │ │ Engine.ts        │ │ MemoryEngine.ts  │
│  - Plantillas    │ │ - Análisis      │ │ - Consolidación  │
│  - Generación    │ │   Somático      │ │   de Memoria     │
│  - Contexto      │ │ - Monólogo      │ │ - Extracción     │
│                 │ │   Interno       │ │   de Insights    │
└─────────────────┘ └─────────────────┘ └─────────────────┘
         │                    │                    │
         └────────────────────┬───────────────────┘
                              ▼
                    ┌─────────────────────┐
                    │  localKnowledge      │
                    │  Library.ts          │
                    │  - Base de           │
                    │    Conocimiento      │
                    │  - Ontología         │
                    │  - Análisis de       │
                    │    Escenas           │
                    └─────────────────────┘
```

### Flujo de Procesamiento

1. **Recepción de Entrada** (`processInput()`)
   - Identifica el tipo de entrada (mensaje, diálogo, narración, etc.)
   - Valida y normaliza los datos
   - Asigna a una sesión (opcional)

2. **Análisis Semántico** (`analyzeSemanticSubtext()`)
   - Detecta intención (greeting, combat_alert, philosophical_debate, etc.)
   - Analiza valencia emocional (warm, tense, vulnerable, etc.)
   - Extrae entidades clave y subtexto

3. **Recuperación de Conocimiento** (`retrieveKnowledge()`)
   - Busca en la base de conocimiento local
   - Filtra por dominios relevantes (psicología, ética, estrategia, somática)
   - Prioriza por relevancia

4. **Razonamiento Cognitivo** (`generateReasoningChain()`)
   - Genera Chain of Thought determinista
   - Integra contexto del personaje
   - Considera memoria de conversación
   - Evalúa impacto emocional

5. **Generación de Respuesta**
   - Selecciona plantilla adecuada
   - Personaliza con perfil del personaje
   - Aplica estilo narrativo
   - Genera monólogo interno y estado somático

6. **Actualización de Estado**
   - Actualiza memoria de conversación
   - Registra en historial
   - Cachea conocimiento relevante

---

## 🚀 Uso Básico

### Instalación

El sistema Elysium Neural ya está integrado en el proyecto Generador Elysium. No se requiere instalación adicional.

### Importación

```typescript
// Importar la clase principal
import { ElysiumNeural, NeuralInput, NeuralOutput } from './utils/elysiumNeuralCore';

// O importar la instancia singleton
import { elysiumNeural } from './utils/elysiumNeuralCore';
```

### Creación de Instancia

```typescript
// Instancia con configuración por defecto (todas las características activadas)
const neural = new ElysiumNeural();

// Instancia personalizada
const neural = new ElysiumNeural({
  model: 'elysium-v2',
  enableAdvancedReasoning: true,
  enableMemorySystem: true,
  enablePersonalitySystem: true,
  enableSomaticSystem: true,
  enableKnowledgeSystem: true,
  maxResponseLength: 2048,
  defaultTemperature: 0.7,
});

// Instancia mínima (sin características avanzadas)
const minimalNeural = ElysiumNeural.createMinimal();

// Instancia optimizada para rolplay
const roleplayNeural = ElysiumNeural.createForRoleplay();
```

### Procesamiento de Entrada

```typescript
// Procesar un mensaje simple
const output = await neural.processInput({
  type: 'user_message',
  text: 'Hola, ¿cómo estás?',
  sender: { id: 'user-1', name: 'Jugador', role: 'Protagonista', type: 'user' },
});

// Procesar diálogo de personaje
const output = await neural.processInput({
  type: 'character_dialogue',
  text: '¿Qué opinas de mi propuesta?',
  characterProfile: {
    id: 'npc-1',
    name: 'Aeloria',
    role: 'Maga Arcana',
    archetype: 'Sabia',
    personality: 'Inteligente, observadora y empática',
    moralAlignment: 'Neutral Bondadosa',
    coreValues: 'Conocimiento, Sabiduría, Protección',
    motivations: ['Descubrir secretos perdidos'],
    greatestFear: 'La ignorancia eterna',
    race: 'Elfo de la Luna',
    age: 250,
  },
});

// Procesar solicitud de narración
const output = await neural.processInput({
  type: 'narrator_request',
  text: 'Describe la escena actual',
  place: { name: 'Bosque Encantado', weather: 'neblinoso', hour: 'amanecer' },
  worldBuilding: { worldName: 'Elysium', laws: ['La magia fluye libremente'] },
});
```

### Uso con Sesiones

```typescript
// Crear una sesión
const sessionId = 'game-session-1';
neural.createSession(sessionId, {
  place: { name: 'Taberna del Dragón', weather: 'lluvioso', hour: 'noche' },
  worldBuilding: { worldName: 'Elysium', laws: ['La magia tiene un costo'] },
});

// Procesar múltiples mensajes en la misma sesión
const output1 = await neural.processInput({
  type: 'user_message',
  text: 'Entro en la taberna',
  sender: { id: 'user-1', name: 'Adrian', role: 'Aventurero', type: 'user' },
}, sessionId);

const output2 = await neural.processInput({
  type: 'character_dialogue',
  text: '¡Bienvenido, viajero!',
  characterProfile: npcProfile,
}, sessionId);

// Obtener información de la sesión
const session = neural.getSession(sessionId);
console.log(`Historial: ${session?.conversationHistory.length} mensajes`);
```

---

## 📊 Tipos de Entrada

Elysium Neural soporta los siguientes tipos de entrada:

| Tipo | Descripción | Uso Principal |
|------|-------------|---------------|
| `user_message` | Mensaje directo del usuario | Interacción básica |
| `character_dialogue` | Diálogo de un personaje NPC | Respuesta de personajes |
| `narrator_request` | Solicitud de narración | Descripción de escenas |
| `scene_description` | Descripción de una escena | Análisis ambiental |
| `ooc_query` | Consulta Out-Of-Character | Información meta |
| `system_command` | Comando del sistema | Administración |
| `memory_consolidation` | Consolidación de memoria | Persistencia |
| `knowledge_query` | Consulta de conocimiento | Búsqueda de información |
| `backstory_generation` | Generación de trasfondo | Creación de personajes |
| `timeline_generation` | Generación de línea temporal | Historia del personaje |

---

## 🎭 Tipos de Respuesta

Las respuestas de Elysium Neural incluyen:

```typescript
interface NeuralOutput {
  // Respuesta principal
  text: string;
  
  // Metadatos
  responseType: 'dialogue' | 'narration' | 'analysis' | 'command_response' | 'memory_update' | 'knowledge_response' | 'error';
  
  // Información del hablante
  speaker?: { name: string; role: string; type: 'user' | 'npc' | 'narrator' | 'agent' | 'system' };
  
  // Razonamiento
  reasoning?: { chain: ReasoningStep[]; summary: string; confidence: number };
  
  // Análisis semántico
  semanticAnalysis?: SemanticAnalysisResult;
  
  // Conocimiento aplicado
  appliedKnowledge?: KnowledgeEntry[];
  
  // Estado somático (para personajes)
  somaticState?: SomatosensoryState;
  
  // Monólogo interno
  innerMonologue?: string;
  
  // Actualización de memoria
  memoryUpdate?: { keyFacts: string[]; agreementsAndPromises: string[]; unresolvedQuestions: string[] };
  
  // Evaluación cognitiva
  cognitiveAppraisal?: CognitiveAppraisal;
  
  // Información de narración
  narrationInfo?: { directorIntent: string; environmentalShift: string; castReactionsSummary: string; narrativeHooks: string[] };
  
  // Métricas
  tokens?: number;
  processingTime?: number;
  
  // Estado
  isFallback: boolean;
  fallbackReason?: string;
  error?: string;
}
```

---

## 🎯 Características Avanzadas

### 1. Sistema de Memoria de Conversación

Elysium Neural mantiene un historial de conversación y memoria contextual:

```typescript
// La memoria incluye:
- Hechos clave (keyFacts)
- Acuerdos y promesas (agreementsAndPromises)
- Preguntas sin resolver (unresolvedQuestions)
- Temas activos (activeTopics)
- Perspectivas de personajes (characterPerspectives)
- Tono narrativo (narrativeTone)
```

### 2. Análisis Semántico Avanzado

Detecta automáticamente:
- **Intención**: greeting, combat_alert, tactical_planning, emotional_intimacy, philosophical_debate, wardrobe_somatic_inquiry, etc.
- **Intensidad**: subtle, moderate, intense, visceral
- **Proximidad**: contact, intimate, conversational, across_room, distant
- **Valencia emocional**: warm, analytical, tense, vulnerable, defensive, neutral
- **Subtexto y entidades clave**

### 3. Razonamiento Cognitivo (Chain of Thought)

Genera una cadena de pensamiento determinista que incluye:
- Análisis inicial de la consulta
- Recuperación de conocimiento relevante
- Análisis semántico
- Integración con perfil de personaje
- Adaptación a la personalidad
- Síntesis final

### 4. Sistema Somático

Para personajes, genera:
- **Estado somático**: postura, centro de gravedad, contacto con el suelo, fricción de prendas, cinética de tejidos
- **Monólogo interno**: pensamientos privados y evaluación subtextual
- **Evaluación cognitiva**: reconocimiento de intención, autoconciencia, evaluación relacional

### 5. Base de Conocimiento Ontológico

Incluye dominios:
- **Psicología y Emociones**: ira, miedo, alegría, tristeza, etc.
- **Ética y Moral**: honor, lealtad, dilemas morales
- **Estrategia y Táctica**: planes, combate, terreno
- **Vestuario y Somática**: telas, calzado, aparecia
- **Relaciones y Social**: confianza, comunicación

---

## 🔧 Configuración

### Opciones de Configuración

```typescript
interface NeuralConfig {
  model: 'elysium-v1' | 'elysium-v2' | 'elysium-reasoner' | 'elysium-ultimate';
  llmConfig?: Partial<LLMConfig>;
  enableAllFeatures: boolean;
  enableAdvancedReasoning: boolean;
  enableMemorySystem: boolean;
  enablePersonalitySystem: boolean;
  enableSomaticSystem: boolean;
  enableKnowledgeSystem: boolean;
  maxContextLength: number;
  maxResponseLength: number;
  defaultTemperature: number;  // 0 = determinista, 1 = creativo
  defaultTopK: number;
}
```

### Configuración del LLM Local

```typescript
interface LLMConfig {
  model: 'elysium-v1' | 'elysium-v2' | 'elysium-reasoner';
  maxContextLength: number;
  maxResponseLength: number;
  enableReasoning: boolean;
  enableMemory: boolean;
  enablePersonality: boolean;
}
```

---

## 📚 Ejemplos Prácticos

### Ejemplo 1: Conversación Básica

```typescript
const neural = new ElysiumNeural();

const userInput: NeuralInput = {
  type: 'user_message',
  text: '¿Qué debo hacer ahora?',
  sender: { id: 'user-1', name: 'Jugador', role: 'Aventurero', type: 'user' },
};

const response = await neural.processInput(userInput);
console.log(response.text);
// Output: "Analicemos la situación. Los puntos clave son: identificar los objetivos, evaluar los recursos y anticipar obstáculos."
```

### Ejemplo 2: Diálogo de Personaje

```typescript
const warriorProfile: CharacterConsciousnessProfile = {
  id: 'garrick',
  name: 'Garrick',
  role: 'Guerrero',
  archetype: 'Protector',
  personality: 'Valiente, leal y disciplinado',
  moralAlignment: 'Legal Bondadoso',
  coreValues: 'Honor, Lealtad, Coraje',
  motivations: ['Proteger a los débiles', 'Derrotar a las fuerzas del mal'],
  greatestFear: 'Fracasar en proteger a sus seres queridos',
  race: 'Humano',
  age: 35,
};

const dialogueInput: NeuralInput = {
  type: 'character_dialogue',
  text: '¡Cuidado! ¡Hay un dragón!',
  characterProfile: warriorProfile,
  place: { name: 'Cueva del Dragón', weather: 'caluroso' },
};

const response = await neural.processInput(dialogueInput);
console.log(response.text);
// Output: "¡Alerta! Detecto una amenaza potencial. Debemos prepararnos para la acción. Mantén la calma."
console.log(response.somaticState?.postureDescription);
// Output: "Pone una mano firme sobre su cinto, ajustando la postura..."
```

### Ejemplo 3: Narración de Escena

```typescript
const narrationInput: NeuralInput = {
  type: 'narrator_request',
  text: 'Los personajes entran en el bosque',
  place: {
    name: 'Bosque de las Sombras',
    zoneName: 'Claro de la Luna',
    weather: 'neblinoso',
    hour: 'atardecer',
    atmosphere: 'Misterioso y silencioso',
    rhythmOrVibes: ['misterio', 'peligro inminente', 'magia ancestral'],
  },
  worldBuilding: {
    worldName: 'Elysium',
    laws: ['La magia fluye libremente', 'Las sombras guardan secretos'],
    factions: ['Orden de la Luz', 'Hermandad de las Sombras'],
  },
  protagonist: {
    id: 'prot-1',
    name: 'Adrian',
    role: 'Aventurero',
    type: 'user',
  } as UnifiedParticipant,
  companions: [
    {
      id: 'npc-1',
      name: 'Garrick',
      role: 'Guerrero',
      type: 'npc',
    } as UnifiedParticipant,
    {
      id: 'npc-2',
      name: 'Lyria',
      role: 'Hechicera',
      type: 'npc',
    } as UnifiedParticipant,
  ],
};

const response = await neural.processInput(narrationInput);
console.log(response.text);
// Output: "Una bruma espesa se eleva del suelo del Bosque de las Sombras, envolviendo los árboles..."
console.log(response.narrationInfo?.directorIntent);
// Output: "Tensión atmosférica"
console.log(response.narrationInfo?.narrativeHooks);
// Output: ["Investigar las sombras que se mueven", "Buscar el origen de la niebla", "Prepararse para lo desconocido"]
```

### Ejemplo 4: Consulta de Conocimiento

```typescript
const knowledgeInput: NeuralInput = {
  type: 'knowledge_query',
  text: 'Dime sobre el honor y la lealtad',
  knowledgeDomains: ['ethics'],
};

const response = await neural.processInput(knowledgeInput);
console.log(`Entradas encontradas: ${response.appliedKnowledge?.length}`);
response.appliedKnowledge?.forEach(entry => {
  console.log(`- ${entry.category}: ${entry.content}`);
});
```

### Ejemplo 5: Uso con Sesión Persistente

```typescript
// Crear sesión
const sessionId = 'game-1';
neural.createSession(sessionId, {
  place: { name: 'Taberna del Oso', weather: 'lluvioso', hour: 'noche' },
  worldBuilding: { worldName: 'Elysium', laws: ['La magia tiene un costo'] },
});

// Agregar personaje a la sesión
const session = neural.getSession(sessionId);
if (session) {
  session.activeCharacters.set('garrick', warriorProfile);
}

// Procesar múltiples interacciones
const outputs = await Promise.all([
  neural.processInput({
    type: 'user_message',
    text: 'Entro en la taberna',
    sender: { id: 'user-1', name: 'Adrian', role: 'Aventurero', type: 'user' },
  }, sessionId),
  neural.processInput({
    type: 'character_dialogue',
    text: '¡Bienvenido, viajero!',
    characterProfile: warriorProfile,
    target: { id: 'user-1', name: 'Adrian', role: 'Aventurero', type: 'user' },
  }, sessionId),
  neural.processInput({
    type: 'user_message',
    text: '¿Qué hay de nuevo?',
    sender: { id: 'user-1', name: 'Adrian', role: 'Aventurero', type: 'user' },
  }, sessionId),
]);

// La memoria de conversación se actualiza automáticamente
console.log(`Memoria: ${session?.conversationMemory.keyFacts.length} hechos`);
```

---

## 🛠️ Integración con el Sistema Existente

### Integración con server.ts

Elysium Neural puede integrarse fácilmente con los endpoints existentes:

```typescript
// En server.ts
import { elysiumNeural } from './src/utils/elysiumNeuralCore';

// Endpoint de chat mejorado
app.post("/api/elysium-chat", async (req, res) => {
  try {
    const { messages, characterProfile, place, worldBuilding } = req.body;
    
    // Convertir mensajes a formato NeuralInput
    const neuralInput: NeuralInput = {
      type: 'character_dialogue',
      text: messages[messages.length - 1].text,
      characterProfile,
      conversationHistory: messages.slice(0, -1).map((m: any) => ({
        sender: m.sender,
        text: m.text,
        timestamp: m.timestamp,
      })),
      place,
      worldBuilding,
    };
    
    // Procesar con Elysium Neural
    const output = await elysiumNeural.processInput(neuralInput);
    
    res.json({
      text: output.text,
      speaker: output.speaker,
      reasoning: output.reasoning,
      semanticAnalysis: output.semanticAnalysis,
      somaticState: output.somaticState,
      innerMonologue: output.innerMonologue,
      memoryUpdate: output.memoryUpdate,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
```

### Integración con Multi-Agent Chat

```typescript
// Mejorar el endpoint /api/multiagent-chat
app.post("/api/multiagent-chat", async (req, res) => {
  try {
    const { speakerName, speakerRole, userMessage, place, worldBuilding, history, protagonist, companions } = req.body;
    
    // Crear perfil de personaje
    const characterProfile: CharacterConsciousnessProfile = {
      id: speakerName,
      name: speakerName,
      role: speakerRole,
      archetype: req.body.speakerArchetype || 'Neutral',
      personality: req.body.speakerPersonality || 'Equilibrado',
      moralAlignment: req.body.speakerMoralAlignment || 'Neutral',
      coreValues: req.body.speakerCoreValues || 'Honor',
      motivations: req.body.speakerMotivations || ['Supervivencia'],
      greatestFear: req.body.speakerGreatestFear || 'La derrota',
      race: req.body.speakerRace || 'Humano',
      age: 30,
    };
    
    // Procesar con Elysium Neural
    const output = await elysiumNeural.processInput({
      type: 'character_dialogue',
      text: userMessage,
      characterProfile,
      conversationHistory: history,
      place,
      worldBuilding,
      protagonist,
      companions,
    });
    
    res.json({
      text: output.text,
      speakerName: output.speaker?.name || speakerName,
      speakerType: output.speaker?.type || 'agent',
      innerMonologue: output.innerMonologue,
      somaticObservation: output.somaticState?.postureDescription,
      cognitiveTrace: output.cognitiveAppraisal,
      memoryUpdate: output.memoryUpdate,
    });
  } catch (error) {
    // Fallback al sistema existente
    // ... código existente ...
  }
});
```

---

## 🎓 Arquitectura de la Base de Conocimiento

### Estructura de las Entradas

```typescript
interface KnowledgeEntry {
  domain: string;           // Dominio: psychology, ethics, strategy, somatic, social
  category: string;         // Categoría específica
  content: string;          // Contenido descriptivo
  keywords: string[];       // Palabras clave para búsqueda
  priority: number;         // Prioridad (0-10)
}
```

### Dominios Disponibles

1. **psychology** - Emociones y estados mentales
   - emotions: ira, miedo, alegría, tristeza
   - states: ansiedad, pánico, calma
   - traits: valentía, timidez, curiosidad

2. **ethics** - Principios morales
   - moral_principles: honor, lealtad, justicia
   - dilemmas: conflicto moral, decisión ética
   - values: integridad, sacrificio, respeto

3. **strategy** - Planificación y táctica
   - tactics: estrategia, plan, maniobra
   - combat: combate, terreno, ventaja
   - resources: recursos, logística

4. **somatic** - Vestuario y conciencia corporal
   - wardrobe: vestuario, ropa, atuendo
   - fabrics: lino, cuero, seda
   - footwear: botas, zapatos, sandalias

5. **social** - Relaciones interpersonales
   - relationships: confianza, amistad, lealtad
   - communication: diálogo, escuchar, hablar

---

## 📈 Métricas y Rendimiento

### Tiempos de Procesamiento

- **Mensaje simple**: < 100ms
- **Diálogo de personaje**: < 200ms
- **Narración compleja**: < 500ms
- **Consulta de conocimiento**: < 100ms
- **Consolidación de memoria**: < 300ms

### Uso de Memoria

- **Contexto por sesión**: ~1-2KB
- **Base de conocimiento**: ~10KB (estática)
- **Cache de conocimiento**: Depende del uso
- **Historial por sesión**: ~500B por mensaje

### Escalabilidad

- **Sesiones concurrentes**: Limitado solo por memoria disponible
- **Personajes por sesión**: Ilimitado
- **Longitud del historial**: Configurable (default: 20 mensajes)

---

## 🔍 Depuración y Solución de Problemas

### Registro de Eventos

Elysium Neural registra automáticamente:
- Inicialización del sistema
- Creación de sesiones
- Errores de procesamiento
- Tiempos de procesamiento

```typescript
// Activar modo debug (opcional)
const neural = new ElysiumNeural();
// Los logs se imprimen automáticamente a console
```

### Errores Comunes

| Error | Causa | Solución |
|-------|-------|----------|
| `Entrada inválida: el texto es requerido` | `text` está vacío o no es string | Proporcionar texto válido |
| `Se requiere un perfil de personaje` | `characterProfile` faltante para diálogo | Proporcionar perfil de personaje |
| `Error al procesar: ...` | Error interno | Revisar logs, verificar entrada |

### Validación de Entrada

```typescript
// Validar entrada antes de procesar
function validateInput(input: NeuralInput): boolean {
  if (!input.text || typeof input.text !== 'string') {
    return false;
  }
  
  if (input.type === 'character_dialogue' && !input.characterProfile) {
    return false;
  }
  
  return true;
}
```

---

## 📚 API de Referencia

### Métodos de ElysiumNeural

#### Constructor
```typescript
new ElysiumNeural(config?: Partial<NeuralConfig>)
```
Crea una nueva instancia de Elysium Neural.

#### Gestión de Sesiones
```typescript
createSession(sessionId: string, initialContext?: Partial<NeuralSession>): NeuralSession
```
Crea una nueva sesión de conversación.

```typescript
getSession(sessionId: string): NeuralSession | undefined
```
Obtiene una sesión existente.

```typescript
deleteSession(sessionId: string): boolean
```
Elimina una sesión.

```typescript
updateSessionContext(sessionId: string, updates: Partial<NeuralSession>): boolean
```
Actualiza el contexto de una sesión.

#### Procesamiento
```typescript
processInput(input: NeuralInput, sessionId?: string): Promise<NeuralOutput>
```
Procesa una entrada y genera una respuesta.

#### Métodos Estáticos
```typescript
ElysiumNeural.createForRoleplay(config?: Partial<NeuralConfig>): ElysiumNeural
```
Crea una instancia optimizada para rolplay.

```typescript
ElysiumNeural.createMinimal(config?: Partial<NeuralConfig>): ElysiumNeural
```
Crea una instancia mínima sin características avanzadas.

```typescript
ElysiumNeural.processSimpleInput(text: string, characterProfile?: CharacterConsciousnessProfile): Promise<NeuralOutput>
```
Procesa una entrada simple sin sesión.

---

## 🎯 Mejores Prácticas

### 1. Uso de Sesiones

✅ **Hacer**: Crear una sesión para cada conversación prolongada
✅ **Hacer**: Mantener el contexto (lugar, mundo, personajes) en la sesión
❌ **Evitar**: Crear múltiples sesiones para la misma conversación

### 2. Perfiles de Personaje

✅ **Hacer**: Proporcionar perfiles completos con personalidad, valores y miedos
✅ **Hacer**: Usar `CharacterConsciousnessProfile` para personajes complejos
❌ **Evitar**: Usar perfiles vacíos o incompletos

### 3. Historial de Conversación

✅ **Hacer**: Incluir el historial en la entrada para mantener contexto
✅ **Hacer**: Limitar el historial a mensajes relevantes (default: 20)
❌ **Evitar**: Enviar historial excesivamente largo

### 4. Tipos de Entrada

✅ **Hacer**: Usar el tipo de entrada más específico (`character_dialogue` vs `user_message`)
✅ **Hacer**: Usar `narrator_request` para descripciones de escena
❌ **Evitar**: Usar siempre `user_message` para todo

### 5. Manejo de Errores

✅ **Hacer**: Verificar que `output.responseType !== 'error'`
✅ **Hacer**: Usar `output.isFallback` para detectar respuestas de respaldo
❌ **Evitar**: Asumir que todas las respuestas son exitosas

---

## 🔮 Futuras Mejoras

### Roadmap

1. **v1.1** - Mejoras en el sistema de memoria
   - Persistencia en localStorage/IndexedDB
   - Exportación/importación de sesiones
   - Búsqueda semántica en memoria

2. **v1.2** - Expansión de la base de conocimiento
   - Más dominios (magia, tecnología, historia)
   - Conocimiento específico de mundos
   - Integración con datos del juego

3. **v1.3** - Mejoras en el LLM local
   - Modelos más grandes y complejos
   - Generación más variada
   - Mejor manejo de contexto

4. **v2.0** - Sistema de aprendizaje
   - Adaptación a estilos de juego
   - Personalización de respuestas
   - Memoria a largo plazo

### Contribuciones

Para contribuir al desarrollo de Elysium Neural:

1. **Añadir conocimiento**: Extender `KNOWLEDGE_BASE` en `localLLM.ts`
2. **Mejorar plantillas**: Añadir más plantillas de respuesta en `RESPONSE_TEMPLATES`
3. **Nuevos dominios**: Crear nuevos dominios de conocimiento
4. **Optimización**: Mejorar el rendimiento del sistema

---

## 📄 Licencia

Elysium Neural forma parte del proyecto **Generador Elysium** y se distribuye bajo la licencia **MIT**. Consulte el archivo `LICENSE` del proyecto para más detalles.

---

## 🙏 Agradecimientos

Elysium Neural ha sido desarrollado como parte del sistema de **Generador Elysium**, una plataforma integral de creación de personajes y simulación narrativa para juegos de rol.

Especial agradecimiento a:
- La comunidad de desarrollo de juegos de rol
- Los creadores de sistemas de IA local
- Todos los contribuyentes al proyecto

---

*Documentación generada automáticamente. Última actualización: [Fecha])
