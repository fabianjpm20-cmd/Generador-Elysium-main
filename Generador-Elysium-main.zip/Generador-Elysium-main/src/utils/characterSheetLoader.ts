import { 
  CharacterState, 
  GarmentConfig, 
  CharacterRelationship, 
  NarrativeTimelineMilestone, 
  AdvancedCustomization,
  RolePieceDetail,
  EquipmentPieceDetail,
  OrientalFantasyConfig,
  MakeupConfig
} from '../types';
import { createDefaultCharacterState } from './libraryStorage';
import { 
  DEFAULT_MAKEUP_CONFIG,
  RACE_GROUPS,
  SEX_BASES,
  AGES,
  COMPLEXIONS,
  HEIGHTS,
  BREAST_DEV,
  WAISTS,
  GLUTES,
  THIGHS,
  SKIN_COLORS,
  EYE_COLORS,
  HEAD_SHAPES,
  HEAD_WIDTHS,
  BONE_STRUCTURES,
  EYES_CATEGORIES,
  EYES_SUBTYPES,
  EXPRESSIONS,
  IRIS_TYPES,
  NOSES,
  LIPS,
  MOUTH_EXPS,
  TEETHS,
  EARS_BASES,
  KEMONO_EARS,
  HAIR_TEXTURES,
  HAIR_LENGTHS,
  HAIR_CUTS,
  HAIR_PARTS,
  HAIR_BANGS,
  HAIR_STYLES,
  HAIR_COLORS,
  HORNS_FORMS,
  HORNS_LENGTHS,
  HORNS_THICKNESSES,
  HORNS_POSITIONS,
  WINGS_SIZES,
  WINGS_POSITIONS,
  WINGS_TYPES,
  TAILS_TYPES,
  TAILS_LENGTHS,
  ANTENNAE_TYPES,
  ANTENNAE_LENGTHS,
  ANTENNAE_POSITIONS,
  EXTRA_EYES_OPTIONS,
  EXTRA_ARMS_OPTIONS,
  SPECIAL_LIMBS_OPTIONS,
  SKIN_AND_MARKS,
  LOWER_BODY_STRUCTURES,
  CHEST_CORES,
  NECK_FEATURES,
  HAIR_ELEMENTALS,
  FACIAL_MORPHOLOGIES,
  SCLERA_COLORS,
  FACIAL_HAIR_OPTIONS,
  ROLES_CATALOG,
  VISUAL_STYLES,
  ROLE_OUTFIT_TYPES,
  ARMOR_TYPES,
  ARMOR_MATERIALS,
  ARMOR_FINISHES,
  WEAPONS_GRIPS
} from '../data';
import { ROLE_SPECIFIC_CATALOG } from '../data/roles';

// Color name to Hex resolution map for restoring accurate color swatches
const COLOR_NAME_TO_HEX: Record<string, string> = {
  'negro': '#1A1C22',
  'negro azabache': '#1A1C22',
  'negro ébano': '#1A1C22',
  'negro azabache / ébano': '#1A1C22',
  'negro carbón': '#000000',
  'negro carbón absoluto': '#000000',
  'blanco': '#FFFFFF',
  'blanco puro': '#FFFFFF',
  'blanco platino': '#E2E8F0',
  'blanco platino / plata': '#E2E8F0',
  'plata': '#E2E8F0',
  'azul': '#1E3A8A',
  'azul marino': '#1E3A8A',
  'azul zafiro': '#1E3A8A',
  'azul noche': '#1E3A8A',
  'azul zafiro / noche': '#1E3A8A',
  'azul cielo': '#3B82F6',
  'azul cobalto': '#3B82F6',
  'azul cielo / cobalto': '#3B82F6',
  'cian': '#06B6D4',
  'cian hielo': '#06B6D4',
  'cian hielo / eléctrico': '#06B6D4',
  'rojo': '#DC2626',
  'rojo rubí': '#DC2626',
  'rojo carmesí': '#DC2626',
  'rojo rubí / carmesí': '#DC2626',
  'rojo fuego': '#EF4444',
  'rojo escarlata': '#EF4444',
  'rojo fuego / escarlata': '#EF4444',
  'dorado': '#F59E0B',
  'dorado solar': '#F59E0B',
  'oro': '#F59E0B',
  'oro solar': '#F59E0B',
  'dorado solar / ámbar': '#F59E0B',
  'ámbar': '#F59E0B',
  'amarillo': '#FBBF24',
  'amarillo brillante': '#FBBF24',
  'verde': '#059669',
  'verde esmeralda': '#059669',
  'verde bosque': '#047857',
  'verde menta': '#10B981',
  'verde menta / jade': '#10B981',
  'jade': '#10B981',
  'púrpura': '#7C3AED',
  'amatista': '#7C3AED',
  'púrpura / amatista': '#7C3AED',
  'violeta': '#8B5CF6',
  'violeta neón': '#8B5CF6',
  'índigo': '#8B5CF6',
  'violeta neón / índigo': '#8B5CF6',
  'rosa': '#EC4899',
  'rosa fucsia': '#EC4899',
  'fucsia': '#EC4899',
  'rosa fucsia / neón': '#EC4899',
  'rosa pastel': '#F472B6',
  'rosa pastel / sakura': '#F472B6',
  'sakura': '#F472B6',
  'castaño': '#451A03',
  'chocolate': '#451A03',
  'castaño chocolate': '#451A03',
  'castaño chocolate oscuro': '#451A03',
  'caramelo': '#92400E',
  'castaño caramelo': '#92400E',
  'castaño oscuro': '#451A03',
  'castaño claro': '#92400E',
  'rubio': '#FDE047',
  'rubio dorado': '#FDE047',
  'rubio platino': '#FEF08A',
  'pelirrojo': '#EA580C',
  'gris': '#64748B',
  'gris humo': '#64748B',
  'gris humo / ceniza': '#64748B',
  'ceniza': '#64748B'
};

export function resolveColorHexOrValue(colorStr: string | undefined | null): string {
  if (!colorStr) return '#1A1C22';
  const trimmed = colorStr.trim();
  if (/^#[0-9A-F]{3,8}$/i.test(trimmed)) return trimmed;
  
  const lower = trimmed.toLowerCase();
  for (const [key, hex] of Object.entries(COLOR_NAME_TO_HEX)) {
    if (lower === key || lower.includes(key)) {
      return hex;
    }
  }
  return trimmed;
}

/**
 * Normalizes text for robust fuzzy comparison (removes diacritics, codes like P1.1, SIL01, COR01, etc.)
 */
function normalizeForFuzzy(str: string): string {
  return str
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/^[a-z0-9_-]+[:.]?\s*/i, '') // removes prefixes like "COR01 ", "SIL04 ", "P1.1 ", "1 ", "A "
    .replace(/[^a-z0-9\s]/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Intelligent fuzzy option matcher that matches raw text to the canonical options array
 */
export function fuzzyMatchOption(
  rawVal: string | undefined | null,
  options: (string | { id?: string; name: string })[],
  fallbackVal?: string
): string {
  if (!rawVal) return fallbackVal || '';
  const trimmed = rawVal.trim();
  if (!trimmed) return fallbackVal || '';

  const stringOptions = options.map(o => typeof o === 'string' ? o : o.name);

  // 1. Direct exact or case-insensitive match
  const direct = stringOptions.find(o => o.toLowerCase() === trimmed.toLowerCase());
  if (direct) return direct;

  // 2. Direct code or prefix match (e.g. "C1" or "SIL04" or "COR01")
  const codeCandidate = trimmed.split(/[\s:.-]+/)[0].toLowerCase();
  if (codeCandidate.length >= 2) {
    const codeMatch = stringOptions.find(o => {
      const optCode = o.split(/[\s:.-]+/)[0].toLowerCase();
      return optCode === codeCandidate;
    });
    if (codeMatch) return codeMatch;
  }

  // 3. Normalized comparison (removing codes, numbers, punctuation, accents)
  const normVal = normalizeForFuzzy(trimmed);
  if (!normVal) return fallbackVal || trimmed;

  // 3a. Exact normalized match
  for (const opt of stringOptions) {
    const normOpt = normalizeForFuzzy(opt);
    if (normOpt === normVal) return opt;
  }

  // 3b. Substring and token overlap scoring
  let bestMatch = '';
  let bestScore = 0;

  const valTokens = normVal.split(/\s+/).filter(t => t.length >= 3);

  for (const opt of stringOptions) {
    const normOpt = normalizeForFuzzy(opt);
    
    // Substring containment
    if (normOpt.includes(normVal) || normVal.includes(normOpt)) {
      const matchLen = Math.min(normOpt.length, normVal.length) + 10;
      if (matchLen > bestScore) {
        bestScore = matchLen;
        bestMatch = opt;
      }
    }

    // Token overlap match
    if (valTokens.length > 0) {
      const optTokens = normOpt.split(/\s+/).filter(t => t.length >= 3);
      const commonCount = valTokens.filter(t => optTokens.some(ot => ot.includes(t) || t.includes(ot))).length;
      if (commonCount > 0) {
        const score = commonCount * 5;
        if (score > bestScore) {
          bestScore = score;
          bestMatch = opt;
        }
      }
    }
  }

  if (bestMatch) return bestMatch;
  return fallbackVal !== undefined ? fallbackVal : trimmed;
}

/**
 * Height string or numerical meter matcher
 */
function matchHeight(raw: string): string {
  if (!raw) return 'C Normal / Estándar (1.60 m – 1.80 m)';
  const numMatch = raw.match(/(\d+(?:\.\d+)?)\s*m/i);
  if (numMatch) {
    const val = parseFloat(numMatch[1]);
    if (val < 1.40) return 'A Muy Pequeño (1.20 m – 1.40 m)';
    if (val < 1.60) return 'B Petite (1.40 m – 1.60 m)';
    if (val <= 1.80) return 'C Normal / Estándar (1.60 m – 1.80 m)';
    if (val <= 2.00) return 'D Alto (1.80 m – 2.00 m)';
    return 'E Enorme (2.00 m – 2.20 m)';
  }
  return fuzzyMatchOption(raw, HEIGHTS, 'C Normal / Estándar (1.60 m – 1.80 m)');
}

/**
 * Fuzzy matches a race name to catalog to resolve raceId and raceGroup
 */
function resolveRaceIdentifiers(raceName: string): { raceId: string; raceGroup: string; raceName: string } {
  const norm = raceName.toLowerCase().trim();
  
  for (const group of RACE_GROUPS) {
    for (const r of group.races) {
      if (r.name.toLowerCase() === norm || norm.includes(r.name.toLowerCase()) || r.name.toLowerCase().includes(norm)) {
        return { raceId: r.id, raceGroup: group.title, raceName: r.name };
      }
    }
  }
  
  return { raceId: 'HUM_01', raceGroup: 'Humanoides Básicos', raceName: raceName || 'Humano' };
}

/**
 * Normalizes Sex Base
 */
function normalizeSexBase(rawSex: string): string {
  if (!rawSex) return '2 Mujer';
  const lower = rawSex.toLowerCase().trim();
  if (lower.includes('trans')) return '4 Hombre (mujer trans-sexual)';
  return fuzzyMatchOption(rawSex, SEX_BASES, '2 Mujer');
}

/**
 * Helper to match role names from catalogs
 */
function matchRole(rawRole: string): string {
  if (!rawRole) return 'Civil Genérico';
  if (/civil|cotidiano/i.test(rawRole)) return 'Civil Genérico';
  const allRoles = [
    ...ROLES_CATALOG.flatMap(c => c.roles),
    ...Object.keys(ROLE_SPECIFIC_CATALOG)
  ];
  const uniqueRoles = Array.from(new Set(allRoles));
  return fuzzyMatchOption(rawRole, uniqueRoles, rawRole);
}

/**
 * Cleans and prepares state for serialization / export
 */
export function cleanCharacterStateForExport(state: CharacterState): CharacterState {
  return sanitizeCharacterState(state);
}

/**
 * Validates and sanitizes an object into a complete, safe CharacterState,
 * ensuring no undefined fields cause crashes in downstream components.
 */
export function sanitizeCharacterState(raw: any): CharacterState {
  const defaultState = createDefaultCharacterState();
  if (!raw || typeof raw !== 'object') {
    return defaultState;
  }

  // Handle if raw is a SavedCharacterEntry with .state
  const source = raw.state && typeof raw.state === 'object' ? raw.state : raw;

  // Resolve race identifiers if missing
  let raceName = source.raceName || defaultState.raceName || 'Humano';
  let raceId = source.raceId || defaultState.raceId || '';
  let raceGroup = source.raceGroup || defaultState.raceGroup || '';

  if (!raceId || !raceGroup) {
    const resolved = resolveRaceIdentifiers(raceName);
    raceId = resolved.raceId;
    raceGroup = resolved.raceGroup;
  }

  // Secondary Race for hybrids
  let secondaryRaceId = source.secondaryRaceId || source.hybridSecondaryRaceId || undefined;
  let secondaryRaceGroup = source.secondaryRaceGroup || undefined;
  let secondaryRaceName = source.secondaryRaceName || source.hybridSecondaryRaceName || undefined;
  if (secondaryRaceName && !secondaryRaceId) {
    const secResolved = resolveRaceIdentifiers(secondaryRaceName);
    secondaryRaceId = secResolved.raceId;
    secondaryRaceGroup = secResolved.raceGroup;
  }

  // Sanitize Wardrobes
  const rawWardrobes = Array.isArray(source.wardrobes) ? source.wardrobes : [];
  const sanitizedWardrobes: GarmentConfig[] = rawWardrobes.map((w: any, idx: number) => ({
    id: w.id || `g-${Date.now()}-${idx}`,
    categoryId: w.categoryId || 'B0',
    itemId: w.itemId || undefined,
    name: w.name || `Prenda ${idx + 1}`,
    cut: w.cut || '',
    length: w.length || '',
    sleeve: w.sleeve || '',
    material: w.material || 'Seda',
    color: resolveColorHexOrValue(w.color),
    finish: w.finish || 'Mate',
    details: Array.isArray(w.details) ? w.details : [],
    variation: w.variation || 'Estándar',
    layer: w.layer || 'Capa Base',
    location: Array.isArray(w.location) ? w.location : [],
    detailLocations: w.detailLocations && typeof w.detailLocations === 'object' ? w.detailLocations : {},
    detailColors: w.detailColors && typeof w.detailColors === 'object' ? w.detailColors : {},
    pattern: w.pattern || 'Liso / Sin Patrón',
    patternDetail: w.patternDetail || '',
    printTypes: Array.isArray(w.printTypes) ? w.printTypes : [],
    printShapes: w.printShapes && typeof w.printShapes === 'object' ? w.printShapes : {},
    printColors: w.printColors && typeof w.printColors === 'object' ? w.printColors : {},
    printLocations: w.printLocations && typeof w.printLocations === 'object' ? w.printLocations : {},
    printTexts: w.printTexts && typeof w.printTexts === 'object' ? w.printTexts : {},
    printEmblemConfigs: w.printEmblemConfigs && typeof w.printEmblemConfigs === 'object' ? w.printEmblemConfigs : {},
    neckline: w.neckline || '',
    emblem: w.emblem || 'Ninguno',
    emblemConfig: w.emblemConfig && typeof w.emblemConfig === 'object' ? w.emblemConfig : undefined,
    vfx: w.vfx || 'Ninguno',
    accessorySubcategory: w.accessorySubcategory || undefined,
    gemType: w.gemType || undefined,
    gemColor: w.gemColor ? resolveColorHexOrValue(w.gemColor) : undefined,
    engraving: w.engraving || undefined,
    engravingText: w.engravingText || undefined,
    sizeScale: w.sizeScale || undefined,
    fitStyle: w.fitStyle || undefined
  }));

  // Sanitize Relationships
  const rawRels = Array.isArray(source.background?.relationships) ? source.background.relationships : [];
  const sanitizedRels: CharacterRelationship[] = rawRels.map((r: any, idx: number) => ({
    id: r.id || `rel-${Date.now()}-${idx}`,
    targetCharacterName: r.targetCharacterName || `Personaje ${idx + 1}`,
    relationshipType: r.relationshipType || 'Vínculo',
    interactionDynamic: r.interactionDynamic || '',
    feelingsTowards: r.feelingsTowards || undefined,
    opinionOn: r.opinionOn || undefined
  }));

  // Sanitize Timeline Milestones
  const rawMilestones = Array.isArray(source.background?.narrativeTimeline?.milestones) ? source.background.narrativeTimeline.milestones : [];
  const sanitizedMilestones: NarrativeTimelineMilestone[] = rawMilestones.map((m: any, idx: number) => ({
    id: m.id || `ms-${Date.now()}-${idx}`,
    era: m.era || 'Presente',
    title: m.title || `Hito ${idx + 1}`,
    periodOrAge: m.periodOrAge || 'Época Actual',
    summary: m.summary || '',
    keyEvents: Array.isArray(m.keyEvents) ? m.keyEvents : [],
    psychologicalEvolution: m.psychologicalEvolution || '',
    roleAndAppearanceNote: m.roleAndAppearanceNote || undefined,
    linkedVariantName: m.linkedVariantName || undefined
  }));

  // Sanitize Advanced Customization
  const srcAdv = source.background?.advancedCustomization || {};
  const sanitizedAdv: AdvancedCustomization = {
    voiceTone: srcAdv.voiceTone || '',
    speechStyle: srcAdv.speechStyle || '',
    catchphrasesOrIdioms: srcAdv.catchphrasesOrIdioms || '',
    skills: Array.isArray(srcAdv.skills) ? srcAdv.skills : [],
    habitsAndMannerisms: Array.isArray(srcAdv.habitsAndMannerisms) ? srcAdv.habitsAndMannerisms : [],
    specificInteractions: srcAdv.specificInteractions && typeof srcAdv.specificInteractions === 'object' ? {
      withAuthority: srcAdv.specificInteractions.withAuthority || '',
      withPeers: srcAdv.specificInteractions.withPeers || '',
      withFriends: srcAdv.specificInteractions.withFriends || '',
      withSubordinates: srcAdv.specificInteractions.withSubordinates || '',
      withStrangers: srcAdv.specificInteractions.withStrangers || '',
      withEnemies: srcAdv.specificInteractions.withEnemies || ''
    } : {
      withAuthority: '',
      withSubordinates: '',
      withStrangers: '',
      withEnemies: ''
    }
  };

  // Sanitize Makeup
  const srcMakeup = source.makeup || {};
  const sanitizedMakeup: MakeupConfig = {
    lipstickStyle: srcMakeup.lipstickStyle || DEFAULT_MAKEUP_CONFIG.lipstickStyle,
    lipstickColor: srcMakeup.lipstickColor || DEFAULT_MAKEUP_CONFIG.lipstickColor,
    lipstickFinish: srcMakeup.lipstickFinish || DEFAULT_MAKEUP_CONFIG.lipstickFinish,
    blushStyle: srcMakeup.blushStyle || DEFAULT_MAKEUP_CONFIG.blushStyle,
    blushColor: srcMakeup.blushColor || DEFAULT_MAKEUP_CONFIG.blushColor,
    nailStyle: srcMakeup.nailStyle || DEFAULT_MAKEUP_CONFIG.nailStyle,
    nailColor: srcMakeup.nailColor || DEFAULT_MAKEUP_CONFIG.nailColor,
    nailFinish: srcMakeup.nailFinish || DEFAULT_MAKEUP_CONFIG.nailFinish,
    eyeshadowStyle: srcMakeup.eyeshadowStyle || DEFAULT_MAKEUP_CONFIG.eyeshadowStyle,
    eyeshadowColor: srcMakeup.eyeshadowColor || DEFAULT_MAKEUP_CONFIG.eyeshadowColor,
    eyelinerStyle: srcMakeup.eyelinerStyle || DEFAULT_MAKEUP_CONFIG.eyelinerStyle,
    faceAccent: srcMakeup.faceAccent || DEFAULT_MAKEUP_CONFIG.faceAccent
  };

  // Build the complete sanitized state
  const sanitized: CharacterState = {
    name: source.name || defaultState.name || 'Sin nombre',
    raceId,
    raceName,
    raceGroup,
    subtype: source.subtype || '',
    subtypeName: source.subtypeName || source.subtype || '',
    isHybrid: Boolean(source.isHybrid),
    secondaryRaceId,
    secondaryRaceGroup,
    secondaryRaceName,
    secondarySubtype: source.secondarySubtype || '',
    secondarySubtypeName: source.secondarySubtypeName || source.secondarySubtype || '',
    hybridDominance: source.hybridDominance || '',
    personality: source.personality || '',
    personalityTraits: Array.isArray(source.personalityTraits) ? source.personalityTraits : [],
    archetype: source.archetype || 'Genérico',
    nobleTitle: source.nobleTitle || '',
    nobleHouseOrDomain: source.nobleHouseOrDomain || '',
    role: matchRole(source.role || defaultState.role),
    subRole: source.subRole || '',
    hybridRoleTitle: source.hybridRoleTitle || '',
    styleVisual: fuzzyMatchOption(source.styleVisual, VISUAL_STYLES, defaultState.styleVisual),
    subStyleVisual: source.subStyleVisual ? fuzzyMatchOption(source.subStyleVisual, VISUAL_STYLES, source.subStyleVisual) : '',
    styleFusionTitle: source.styleFusionTitle || '',

    anatomy: {
      sexBase: normalizeSexBase(source.anatomy?.sexBase || defaultState.anatomy.sexBase),
      age: fuzzyMatchOption(source.anatomy?.age, AGES, source.anatomy?.age || defaultState.anatomy.age),
      complexion: fuzzyMatchOption(source.anatomy?.complexion, COMPLEXIONS, source.anatomy?.complexion || defaultState.anatomy.complexion),
      height: matchHeight(source.anatomy?.height || defaultState.anatomy.height),
      skinColor: fuzzyMatchOption(source.anatomy?.skinColor, SKIN_COLORS, source.anatomy?.skinColor || defaultState.anatomy.skinColor),
      lowerBodyStructure: fuzzyMatchOption(source.anatomy?.lowerBodyStructure, LOWER_BODY_STRUCTURES, source.anatomy?.lowerBodyStructure || defaultState.anatomy.lowerBodyStructure),
      breastDevelopment: fuzzyMatchOption(source.anatomy?.breastDevelopment, BREAST_DEV, source.anatomy?.breastDevelopment || defaultState.anatomy.breastDevelopment),
      waist: fuzzyMatchOption(source.anatomy?.waist, WAISTS, source.anatomy?.waist || defaultState.anatomy.waist),
      glutes: fuzzyMatchOption(source.anatomy?.glutes, GLUTES, source.anatomy?.glutes || defaultState.anatomy.glutes),
      thighs: fuzzyMatchOption(source.anatomy?.thighs, THIGHS, source.anatomy?.thighs || defaultState.anatomy.thighs),
      chestCore: fuzzyMatchOption(source.anatomy?.chestCore, CHEST_CORES, source.anatomy?.chestCore || defaultState.anatomy.chestCore),
      neckFeature: fuzzyMatchOption(source.anatomy?.neckFeature, NECK_FEATURES, source.anatomy?.neckFeature || defaultState.anatomy.neckFeature)
    },

    facial: {
      headShape: fuzzyMatchOption(source.facial?.headShape, HEAD_SHAPES, source.facial?.headShape || defaultState.facial.headShape),
      headWidth: fuzzyMatchOption(source.facial?.headWidth, HEAD_WIDTHS, source.facial?.headWidth || defaultState.facial.headWidth),
      boneStructure: fuzzyMatchOption(source.facial?.boneStructure, BONE_STRUCTURES, source.facial?.boneStructure || defaultState.facial.boneStructure),
      facialMorphology: fuzzyMatchOption(source.facial?.facialMorphology, FACIAL_MORPHOLOGIES, source.facial?.facialMorphology || defaultState.facial.facialMorphology),
      eyeColor: source.facial?.eyeColor || defaultState.facial.eyeColor,
      scleraColor: fuzzyMatchOption(source.facial?.scleraColor, SCLERA_COLORS, source.facial?.scleraColor || defaultState.facial.scleraColor),
      eyesCategory: fuzzyMatchOption(source.facial?.eyesCategory, EYES_CATEGORIES, source.facial?.eyesCategory || defaultState.facial.eyesCategory),
      eyesSubtype: fuzzyMatchOption(source.facial?.eyesSubtype, EYES_SUBTYPES, source.facial?.eyesSubtype || defaultState.facial.eyesSubtype),
      iris: fuzzyMatchOption(source.facial?.iris, IRIS_TYPES, source.facial?.iris || defaultState.facial.iris),
      nose: fuzzyMatchOption(source.facial?.nose, NOSES, source.facial?.nose || defaultState.facial.nose),
      lips: fuzzyMatchOption(source.facial?.lips, LIPS, source.facial?.lips || defaultState.facial.lips),
      mouthExp: fuzzyMatchOption(source.facial?.mouthExp, MOUTH_EXPS, source.facial?.mouthExp || defaultState.facial.mouthExp),
      expression: fuzzyMatchOption(source.facial?.expression, EXPRESSIONS, source.facial?.expression || defaultState.facial.expression),
      teeth: fuzzyMatchOption(source.facial?.teeth, TEETHS, source.facial?.teeth || defaultState.facial.teeth),
      earsBase: fuzzyMatchOption(source.facial?.earsBase, EARS_BASES, source.facial?.earsBase || defaultState.facial.earsBase),
      earsLength: source.facial?.earsLength || defaultState.facial.earsLength,
      kemonoEars: fuzzyMatchOption(source.facial?.kemonoEars, KEMONO_EARS, source.facial?.kemonoEars || defaultState.facial.kemonoEars),
      eyeliner: source.facial?.eyeliner || defaultState.facial.eyeliner,
      shadow: source.facial?.shadow || defaultState.facial.shadow,
      mouthSpecial: source.facial?.mouthSpecial || defaultState.facial.mouthSpecial,
      mouthCorners: source.facial?.mouthCorners || defaultState.facial.mouthCorners,
      mouthTexture: source.facial?.mouthTexture || defaultState.facial.mouthTexture,
      facialHair: fuzzyMatchOption(source.facial?.facialHair || source.hair?.facialHair, FACIAL_HAIR_OPTIONS, source.facial?.facialHair || defaultState.facial.facialHair),
      facialHairColor: source.facial?.facialHairColor || source.hair?.facialHairColor || defaultState.facial.facialHairColor
    },

    hair: {
      hairColor: source.hair?.hairColor || defaultState.hair.hairColor,
      hairElemental: fuzzyMatchOption(source.hair?.hairElemental, HAIR_ELEMENTALS, source.hair?.hairElemental || defaultState.hair.hairElemental),
      texture: fuzzyMatchOption(source.hair?.texture, HAIR_TEXTURES, source.hair?.texture || defaultState.hair.texture),
      cut: fuzzyMatchOption(source.hair?.cut, HAIR_CUTS, source.hair?.cut || defaultState.hair.cut),
      length: fuzzyMatchOption(source.hair?.length, HAIR_LENGTHS, source.hair?.length || defaultState.hair.length),
      bangs: fuzzyMatchOption(source.hair?.bangs, HAIR_BANGS, source.hair?.bangs || defaultState.hair.bangs),
      part: fuzzyMatchOption(source.hair?.part, HAIR_PARTS, source.hair?.part || defaultState.hair.part),
      style: fuzzyMatchOption(source.hair?.style, HAIR_STYLES, source.hair?.style || defaultState.hair.style)
    },

    appendices: {
      skinAndMarks: fuzzyMatchOption(source.appendices?.skinAndMarks, SKIN_AND_MARKS, source.appendices?.skinAndMarks || defaultState.appendices.skinAndMarks),
      scaleLocations: Array.isArray(source.appendices?.scaleLocations) ? source.appendices.scaleLocations : [],
      markTypes: Array.isArray(source.appendices?.markTypes) ? source.appendices.markTypes : [],
      markShapes: source.appendices?.markShapes && typeof source.appendices.markShapes === 'object' ? source.appendices.markShapes : {},
      markColors: source.appendices?.markColors && typeof source.appendices.markColors === 'object' ? source.appendices.markColors : {},
      markSecondaryColors: source.appendices?.markSecondaryColors && typeof source.appendices.markSecondaryColors === 'object' ? source.appendices.markSecondaryColors : {},
      markFinishes: source.appendices?.markFinishes && typeof source.appendices.markFinishes === 'object' ? source.appendices.markFinishes : {},
      markLocations: source.appendices?.markLocations && typeof source.appendices.markLocations === 'object' ? source.appendices.markLocations : {},
      markTexts: source.appendices?.markTexts && typeof source.appendices.markTexts === 'object' ? source.appendices.markTexts : {},
      markEmblemConfigs: source.appendices?.markEmblemConfigs && typeof source.appendices.markEmblemConfigs === 'object' ? source.appendices.markEmblemConfigs : {},
      hornsForm: fuzzyMatchOption(source.appendices?.hornsForm, HORNS_FORMS, source.appendices?.hornsForm || defaultState.appendices.hornsForm),
      hornsLength: fuzzyMatchOption(source.appendices?.hornsLength, HORNS_LENGTHS, source.appendices?.hornsLength || defaultState.appendices.hornsLength),
      hornsThickness: fuzzyMatchOption(source.appendices?.hornsThickness, HORNS_THICKNESSES, source.appendices?.hornsThickness || defaultState.appendices.hornsThickness),
      hornsPosition: fuzzyMatchOption(source.appendices?.hornsPosition, HORNS_POSITIONS, source.appendices?.hornsPosition || defaultState.appendices.hornsPosition),
      wingsType: fuzzyMatchOption(source.appendices?.wingsType, WINGS_TYPES, source.appendices?.wingsType || defaultState.appendices.wingsType),
      wingsSize: fuzzyMatchOption(source.appendices?.wingsSize, WINGS_SIZES, source.appendices?.wingsSize || defaultState.appendices.wingsSize),
      wingsPosition: fuzzyMatchOption(source.appendices?.wingsPosition, WINGS_POSITIONS, source.appendices?.wingsPosition || defaultState.appendices.wingsPosition),
      tailsType: fuzzyMatchOption(source.appendices?.tailsType, TAILS_TYPES, source.appendices?.tailsType || defaultState.appendices.tailsType),
      tailsLength: fuzzyMatchOption(source.appendices?.tailsLength, TAILS_LENGTHS, source.appendices?.tailsLength || defaultState.appendices.tailsLength),
      antennaeType: fuzzyMatchOption(source.appendices?.antennaeType, ANTENNAE_TYPES, source.appendices?.antennaeType || defaultState.appendices.antennaeType),
      antennaeLength: fuzzyMatchOption(source.appendices?.antennaeLength, ANTENNAE_LENGTHS, source.appendices?.antennaeLength || defaultState.appendices.antennaeLength),
      antennaePosition: fuzzyMatchOption(source.appendices?.antennaePosition, ANTENNAE_POSITIONS, source.appendices?.antennaePosition || defaultState.appendices.antennaePosition),
      extraEyes: fuzzyMatchOption(source.appendices?.extraEyes, EXTRA_EYES_OPTIONS, source.appendices?.extraEyes || defaultState.appendices.extraEyes),
      extraArms: fuzzyMatchOption(source.appendices?.extraArms, EXTRA_ARMS_OPTIONS, source.appendices?.extraArms || defaultState.appendices.extraArms),
      specialLimbs: fuzzyMatchOption(source.appendices?.specialLimbs, SPECIAL_LIMBS_OPTIONS, source.appendices?.specialLimbs || defaultState.appendices.specialLimbs),
      lowerBodyStructure: fuzzyMatchOption(source.appendices?.lowerBodyStructure, LOWER_BODY_STRUCTURES, source.appendices?.lowerBodyStructure || defaultState.appendices.lowerBodyStructure)
    },

    makeup: sanitizedMakeup,
    wardrobes: sanitizedWardrobes,

    armor: {
      type: source.armor?.type || defaultState.armor.type,
      material: source.armor?.material || defaultState.armor.material,
      finish: source.armor?.finish || defaultState.armor.finish,
      specialType: source.armor?.specialType || defaultState.armor.specialType,
      pieces: Array.isArray(source.armor?.pieces) ? source.armor.pieces : [],
      pieceDetails: source.armor?.pieceDetails && typeof source.armor.pieceDetails === 'object' ? source.armor.pieceDetails : {}
    },

    equipment: {
      weapons: Array.isArray(source.equipment?.weapons) ? source.equipment.weapons : [],
      weaponGrips: Array.isArray(source.equipment?.weaponGrips) ? source.equipment.weaponGrips : [],
      bags: Array.isArray(source.equipment?.bags) ? source.equipment.bags : [],
      bagSizes: Array.isArray(source.equipment?.bagSizes) ? source.equipment.bagSizes : [],
      bagClosures: Array.isArray(source.equipment?.bagClosures) ? source.equipment.bagClosures : [],
      items: Array.isArray(source.equipment?.items) ? source.equipment.items : [],
      equipmentDetails: source.equipment?.equipmentDetails && typeof source.equipment.equipmentDetails === 'object' ? source.equipment.equipmentDetails : {}
    },

    orientalFantasy: source.orientalFantasy && typeof source.orientalFantasy === 'object' ? {
      tradition: source.orientalFantasy.tradition || '',
      armorPieces: Array.isArray(source.orientalFantasy.armorPieces) ? source.orientalFantasy.armorPieces : [],
      culturalAccessories: Array.isArray(source.orientalFantasy.culturalAccessories) ? source.orientalFantasy.culturalAccessories : [],
      silkPattern: source.orientalFantasy.silkPattern || '',
      jadeAccentColor: source.orientalFantasy.jadeAccentColor || '',
      spiritualMotif: source.orientalFantasy.spiritualMotif || '',
      energyAura: source.orientalFantasy.energyAura || '',
      weaponStyle: source.orientalFantasy.weaponStyle || ''
    } : defaultState.orientalFantasy,

    background: {
      homelandOrDomain: source.background?.homelandOrDomain || '',
      factionOrFaith: source.background?.factionOrFaith || '',
      languages: Array.isArray(source.background?.languages) ? source.background.languages : [],
      fatalFlawOrVulnerability: source.background?.fatalFlawOrVulnerability || '',
      fatalFlaws: Array.isArray(source.background?.fatalFlaws) && source.background.fatalFlaws.length > 0
        ? source.background.fatalFlaws
        : (source.background?.fatalFlawOrVulnerability
            ? source.background.fatalFlawOrVulnerability.split(/\s*\|\s*|\s*;\s*/).map(s => s.trim()).filter(Boolean)
            : []),
      coreValues: source.background?.coreValues || '',
      backstory: source.background?.backstory || '',
      motivation: source.background?.motivation || '',
      relationships: sanitizedRels,
      narrativeTimeline: {
        thematicArc: source.background?.narrativeTimeline?.thematicArc || '',
        overview: source.background?.narrativeTimeline?.overview || '',
        pivotalTurningPoints: Array.isArray(source.background?.narrativeTimeline?.pivotalTurningPoints) ? source.background.narrativeTimeline.pivotalTurningPoints : [],
        milestones: sanitizedMilestones
      },
      advancedCustomization: sanitizedAdv
    },

    nsfw: source.nsfw ? { ...source.nsfw } : undefined,
    validationLogs: Array.isArray(source.validationLogs) ? source.validationLogs : []
  };

  return sanitized;
}

/**
 * Deep semantic Markdown parser that extracts character data from unstructured/structured
 * canonical character sheet text.
 */
export function parseMarkdownCharacterSheet(markdown: string): CharacterState {
  const result = createDefaultCharacterState();
  const lines = markdown.split('\n');

  let currentMainSection = '';
  let currentSubSection = '';
  let isCapturingBackstory = false;
  let isCapturingMotivation = false;
  const backstoryBuffer: string[] = [];
  const motivationBuffer: string[] = [];

  const parsedWardrobes: GarmentConfig[] = [];
  let currentGarment: Partial<GarmentConfig> | null = null;

  const parsedRelationships: CharacterRelationship[] = [];
  const parsedMilestones: NarrativeTimelineMilestone[] = [];
  const parsedTurningPoints: string[] = [];
  let currentMilestone: Partial<NarrativeTimelineMilestone> | null = null;

  const flushCurrentGarment = () => {
    if (currentGarment && currentGarment.name) {
      parsedWardrobes.push({
        id: currentGarment.id || `g-${Date.now()}-${parsedWardrobes.length}`,
        name: currentGarment.name,
        categoryId: currentGarment.categoryId || 'B0',
        itemId: currentGarment.itemId || undefined,
        cut: currentGarment.cut || '',
        length: currentGarment.length || '',
        sleeve: currentGarment.sleeve || '',
        neckline: currentGarment.neckline || '',
        material: currentGarment.material || 'Seda',
        color: resolveColorHexOrValue(currentGarment.color),
        finish: currentGarment.finish || 'Mate',
        details: currentGarment.details || [],
        variation: currentGarment.variation || 'Estándar',
        layer: currentGarment.layer || 'Capa Base',
        location: currentGarment.location || [],
        detailLocations: currentGarment.detailLocations || {},
        detailColors: currentGarment.detailColors || {},
        pattern: currentGarment.pattern || 'Liso / Sin Patrón',
        patternDetail: currentGarment.patternDetail || '',
        printTypes: currentGarment.printTypes || [],
        printShapes: currentGarment.printShapes || {},
        printColors: currentGarment.printColors || {},
        printLocations: currentGarment.printLocations || {},
        printTexts: currentGarment.printTexts || {},
        printEmblemConfigs: currentGarment.printEmblemConfigs || {},
        emblem: currentGarment.emblem || 'Ninguno',
        emblemConfig: currentGarment.emblemConfig || undefined,
        vfx: currentGarment.vfx || 'Ninguno',
        accessorySubcategory: currentGarment.accessorySubcategory || undefined,
        gemType: currentGarment.gemType || undefined,
        gemColor: currentGarment.gemColor ? resolveColorHexOrValue(currentGarment.gemColor) : undefined,
        engraving: currentGarment.engraving || undefined,
        engravingText: currentGarment.engravingText || undefined,
        sizeScale: currentGarment.sizeScale || undefined,
        fitStyle: currentGarment.fitStyle || undefined
      });
      currentGarment = null;
    }
  };

  const flushCurrentMilestone = () => {
    if (currentMilestone && currentMilestone.title) {
      parsedMilestones.push({
        id: currentMilestone.id || `ms-${Date.now()}-${parsedMilestones.length}`,
        era: currentMilestone.era || 'Presente',
        title: currentMilestone.title,
        periodOrAge: currentMilestone.periodOrAge || 'Época Actual',
        summary: currentMilestone.summary || '',
        keyEvents: currentMilestone.keyEvents || [],
        psychologicalEvolution: currentMilestone.psychologicalEvolution || '',
        roleAndAppearanceNote: currentMilestone.roleAndAppearanceNote || undefined,
        linkedVariantName: currentMilestone.linkedVariantName || undefined
      });
      currentMilestone = null;
    }
  };

  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i];
    const line = rawLine.trim();
    if (!line) continue;

    // Header Title
    if (line.startsWith('# Ficha Técnica Canónica')) {
      const nameMatch = line.replace('# Ficha Técnica Canónica', '').replace(/^[:\s-]+/, '').trim();
      if (nameMatch && nameMatch !== 'Canónica') result.name = nameMatch;
      continue;
    }

    if (line.startsWith('## ')) {
      flushCurrentGarment();
      flushCurrentMilestone();
      currentMainSection = line.replace('## ', '').trim();
      if (/íntima|intima|r\+18/i.test(currentMainSection)) {
        if (!result.nsfw) {
          result.nsfw = { isNsfwEnabled: true, ageConfirmed: true };
        } else {
          result.nsfw.isNsfwEnabled = true;
        }
      }
      currentSubSection = '';
      isCapturingBackstory = false;
      isCapturingMotivation = false;
      continue;
    }

    if (line.startsWith('### ')) {
      flushCurrentGarment();
      flushCurrentMilestone();
      currentSubSection = line.replace('### ', '').trim();
      
      if (currentSubSection.includes('5.3 Historia de Origen')) {
        isCapturingBackstory = true;
        isCapturingMotivation = false;
      } else if (currentSubSection.includes('5.4 Motivación Principal')) {
        isCapturingBackstory = false;
        isCapturingMotivation = true;
      } else {
        isCapturingBackstory = false;
        isCapturingMotivation = false;
      }
      continue;
    }

    // Capture multiline backstory
    if (isCapturingBackstory) {
      if (line.startsWith('#') || line.startsWith('- ')) {
        isCapturingBackstory = false;
      } else {
        backstoryBuffer.push(line.replace(/^«|»$/g, ''));
        continue;
      }
    }

    // Capture multiline motivation
    if (isCapturingMotivation) {
      if (line.startsWith('#') || line.startsWith('- ')) {
        isCapturingMotivation = false;
      } else {
        motivationBuffer.push(line.replace(/^«|»$/g, ''));
        continue;
      }
    }

    // ==========================================
    // PARSE WARDROBE SECTION (State 3)
    // ==========================================
    if (currentMainSection.includes('Vestuario') || currentMainSection.includes('Atuendo')) {
      if (line.startsWith('- ') && line.endsWith(':')) {
        flushCurrentGarment();
        const headerContent = line.replace(/^- /, '').replace(/:$/, '').trim();
        const parenMatch = headerContent.match(/^(.*?)\s*\((.*?)\)$/);
        
        let garmentName = headerContent;
        let layer = 'Capa Base';
        let subcat = '';

        if (parenMatch) {
          garmentName = parenMatch[1].trim();
          const tagParts = parenMatch[2].split('•').map(s => s.trim());
          if (tagParts[0]) layer = tagParts[0];
          if (tagParts[1]) subcat = tagParts[1];
        }

        currentGarment = {
          name: garmentName,
          layer,
          accessorySubcategory: subcat || undefined,
          categoryId: inferGarmentCategoryId(garmentName, layer),
          details: [],
          detailLocations: {},
          detailColors: {}
        };
        continue;
      }

      if (currentGarment && line.startsWith('•')) {
        const bulletText = line.replace(/^•\s*/, '').trim();
        const bColon = bulletText.indexOf(':');
        if (bColon > 0) {
          const bKey = bulletText.substring(0, bColon).trim().toLowerCase();
          const bVal = bulletText.substring(bColon + 1).trim();

          if (bKey.includes('textil') || bKey.includes('metal y color') || bKey.includes('color')) {
            const matMatch = bVal.match(/confeccionado en ([^(]+)/i) || bVal.match(/en ([^(]+)/i);
            const finMatch = bVal.match(/\(Acabado ([^)]+)\)/i) || bVal.match(/\(([^)]+)\)/i);
            const colorPart = bVal.split('confeccionado en')[0].split('en ')[0].split('(')[0].trim();
            
            if (colorPart) currentGarment.color = colorPart;
            if (matMatch) currentGarment.material = matMatch[1].trim();
            if (finMatch) currentGarment.finish = finMatch[1].trim();
          } else if (bKey.includes('corte') || bKey.includes('silueta')) {
            const parts = bVal.split('|').map(s => s.trim());
            parts.forEach(p => {
              if (p.toLowerCase().startsWith('corte ')) currentGarment!.cut = p.replace(/^corte\s+/i, '');
              else if (p.toLowerCase().startsWith('escote ')) currentGarment!.neckline = p.replace(/^escote\s+/i, '');
              else if (!currentGarment!.cut) currentGarment!.cut = p;
            });
          } else if (bKey.includes('largo') || bKey.includes('caída')) {
            currentGarment.length = bVal;
          } else if (bKey.includes('mangas') || bKey.includes('cobertura')) {
            currentGarment.sleeve = bVal;
          } else if (bKey.includes('patrones') || bKey.includes('grabados')) {
            const gMatch = bVal.match(/\(Grabado ([^)]+)\)/i);
            if (gMatch) currentGarment.engraving = gMatch[1].trim();
            const patPart = bVal.split('(')[0].trim();
            if (patPart) currentGarment.pattern = patPart;
          } else if (bKey.includes('gemas') || bKey.includes('engarces')) {
            const gemColorMatch = bVal.match(/\(tono ([^)]+)\)/i) || bVal.match(/\(([^)]+)\)/i);
            if (gemColorMatch) currentGarment.gemColor = gemColorMatch[1].trim();
            const gemPart = bVal.split('(')[0].trim();
            if (gemPart) currentGarment.gemType = gemPart;
          } else if (bKey.includes('detalles de confección') || bKey.includes('detalles')) {
            currentGarment.details = bVal.split(',').map(s => s.trim()).filter(Boolean);
          } else if (bKey.includes('emblemas') || bKey.includes('efectos')) {
            const vfxMatch = bVal.match(/efecto ([^|]+)/i);
            if (vfxMatch) currentGarment.vfx = vfxMatch[1].trim();
            const embMatch = bVal.match(/emblema ([^|]+)/i) || bVal.match(/([^(|]+)/);
            if (embMatch) currentGarment.emblem = embMatch[1].trim();
          }
        }
        continue;
      }
    }

    // ==========================================
    // PARSE ROLE PIECES & ARMOR / WEAPONS (State 4)
    // ==========================================
    if (line.startsWith('• ') && (currentMainSection.includes('Rol') || currentMainSection.includes('Armadura') || currentMainSection.includes('Indumentaria') || currentMainSection.includes('Identidad'))) {
      const itemBullet = line.replace(/^•\s*/, '').trim();
      const bCol = itemBullet.indexOf(':');
      const itemName = (bCol > 0 ? itemBullet.substring(0, bCol) : itemBullet).trim();
      const itemAttrStr = bCol > 0 ? itemBullet.substring(bCol + 1).trim() : '';

      // Check if it belongs to weapons, bags, or items
      if (itemName.toLowerCase().startsWith('w') || itemName.toLowerCase().includes('espada') || itemName.toLowerCase().includes('bastón') || itemName.toLowerCase().includes('daga') || itemName.toLowerCase().includes('arco') || itemName.toLowerCase().includes('báculo')) {
        if (!result.equipment.weapons.includes(itemName)) {
          result.equipment.weapons.push(itemName);
        }
        if (itemAttrStr) {
          if (!result.equipment.equipmentDetails) result.equipment.equipmentDetails = {};
          result.equipment.equipmentDetails[itemName] = parseEquipmentPieceDetail(itemName, 'weapon', itemAttrStr);
        }
        continue;
      } else if (itemName.toLowerCase().startsWith('bg') || itemName.toLowerCase().includes('bolsa') || itemName.toLowerCase().includes('mochila') || itemName.toLowerCase().includes('morral') || itemName.toLowerCase().includes('alforja')) {
        if (!result.equipment.bags.includes(itemName)) {
          result.equipment.bags.push(itemName);
        }
        if (itemAttrStr) {
          if (!result.equipment.equipmentDetails) result.equipment.equipmentDetails = {};
          result.equipment.equipmentDetails[itemName] = parseEquipmentPieceDetail(itemName, 'bag', itemAttrStr);
        }
        continue;
      } else if (itemName.toLowerCase().startsWith('i1') || itemName.toLowerCase().includes('amuleto') || itemName.toLowerCase().includes('anillo') || itemName.toLowerCase().includes('pocion') || itemName.toLowerCase().includes('grimorio') || itemName.toLowerCase().includes('relicario')) {
        if (!result.equipment.items.includes(itemName)) {
          result.equipment.items.push(itemName);
        }
        if (itemAttrStr) {
          if (!result.equipment.equipmentDetails) result.equipment.equipmentDetails = {};
          result.equipment.equipmentDetails[itemName] = parseEquipmentPieceDetail(itemName, 'item', itemAttrStr);
        }
        continue;
      } else {
        // Role armor piece
        if (!result.armor.pieces.includes(itemName)) {
          result.armor.pieces.push(itemName);
        }
        if (itemAttrStr) {
          if (!result.armor.pieceDetails) result.armor.pieceDetails = {};
          result.armor.pieceDetails[itemName] = parseRolePieceDetail(itemName, itemAttrStr);
        }
        continue;
      }
    }

    // ==========================================
    // PARSE 5.1 RELATIONSHIPS
    // ==========================================
    if (currentSubSection.includes('5.1 Relaciones')) {
      if (line.startsWith('- ')) {
        const relLine = line.replace(/^- /, '').trim();
        const nameTypeMatch = relLine.match(/^(.*?)\s*\[(.*?)\]:\s*(.*)$/);
        if (nameTypeMatch) {
          const targetName = nameTypeMatch[1].trim();
          const relType = nameTypeMatch[2].trim();
          const rest = nameTypeMatch[3].trim();
          
          let dynamic = rest;
          let feelings = '';
          let opinion = '';

          const parts = rest.split('|').map(s => s.trim());
          if (parts[0]) dynamic = parts[0];
          parts.slice(1).forEach(p => {
            if (p.toLowerCase().startsWith('sentimientos:')) feelings = p.replace(/^sentimientos:\s*/i, '').trim();
            else if (p.toLowerCase().startsWith('opinión:') || p.toLowerCase().startsWith('opinion:')) opinion = p.replace(/^opini[óo]n:\s*/i, '').trim();
          });

          parsedRelationships.push({
            id: `rel-${Date.now()}-${parsedRelationships.length}`,
            targetCharacterName: targetName,
            relationshipType: relType,
            interactionDynamic: dynamic,
            feelingsTowards: feelings || undefined,
            opinionOn: opinion || undefined
          });
          continue;
        }
      }
    }

    // ==========================================
    // PARSE 5.2 TIMELINE & MILESTONES
    // ==========================================
    if (currentSubSection.includes('5.2 Línea Temporal')) {
      if (line.startsWith('- Arco Temático:')) {
        if (!result.background.narrativeTimeline) result.background.narrativeTimeline = { overview: '', thematicArc: '', pivotalTurningPoints: [], milestones: [] };
        result.background.narrativeTimeline.thematicArc = line.replace('- Arco Temático:', '').trim();
        continue;
      }
      if (line.startsWith('- Visión Panorámica:')) {
        if (!result.background.narrativeTimeline) result.background.narrativeTimeline = { overview: '', thematicArc: '', pivotalTurningPoints: [], milestones: [] };
        result.background.narrativeTimeline.overview = line.replace('- Visión Panorámica:', '').trim();
        continue;
      }
      if (line.startsWith('• [') || line.startsWith('- [')) {
        flushCurrentMilestone();
        const mMatch = line.replace(/^[•-]\s*/, '').match(/^\[(.*?)\]\s*(.*?)\s*\((.*?)\)(?:\s*\[(.*?)\])?:\s*(.*)$/);
        if (mMatch) {
          const eraVal = mMatch[1].trim() as any;
          currentMilestone = {
            era: eraVal === 'Pasado' || eraVal === 'Presente' || eraVal === 'Futuro' || eraVal === 'Variante Alterna' ? eraVal : 'Presente',
            title: mMatch[2].trim(),
            periodOrAge: mMatch[3].trim(),
            linkedVariantName: mMatch[4] ? mMatch[4].trim() : undefined,
            summary: mMatch[5].trim(),
            keyEvents: []
          };
          continue;
        }
      }
      if (currentMilestone && line.startsWith('- Eventos clave:')) {
        currentMilestone.keyEvents = line.replace('- Eventos clave:', '').split(';').map(s => s.trim()).filter(Boolean);
        continue;
      }
      if (currentMilestone && line.startsWith('- Evolución psicológica:')) {
        currentMilestone.psychologicalEvolution = line.replace('- Evolución psicológica:', '').trim();
        continue;
      }
      if (currentMilestone && line.startsWith('- Rol y apariencia:')) {
        currentMilestone.roleAndAppearanceNote = line.replace('- Rol y apariencia:', '').trim();
        continue;
      }
      if (line.startsWith('• ') && !line.includes('[')) {
        parsedTurningPoints.push(line.replace(/^•\s*/, '').trim());
        continue;
      }
    }

    // ==========================================
    // KEY-VALUE & MULTI-ATTRIBUTE PARSING
    // ==========================================
    let rawContent = line.trim();
    rawContent = rawContent.replace(/^[\s-•*]+\s*/, '').trim();
    
    const colonIdx = rawContent.indexOf(':');
    if (colonIdx > 0 && !rawContent.startsWith('#')) {
      const key = rawContent.substring(0, colonIdx).trim().toLowerCase();
      const value = rawContent.substring(colonIdx + 1).trim();
      if (!value) continue;

      // Identity & Core Profile (State 1)
      if (key === 'nombre' || key.includes('nombre del personaje')) {
        if (value && value !== 'Sin nombre asignado') {
          result.name = value;
        }
      } else if (key.includes('raza canónica') || key === 'raza' || key.includes('especie')) {
        if (/h[ií]brido/i.test(value) && value.includes('×')) {
          const domMatch = value.match(/\[(.*?)\]/);
          if (domMatch) {
            result.hybridDominance = domMatch[1].trim();
          }
          const cleanedRaceStr = value.replace(/^h[ií]brido\s+/i, '').replace(/\[.*?\]/, '').trim();
          const [primPart, secPart] = cleanedRaceStr.split('×').map(s => s.trim());
          if (primPart) {
            const pMatch = primPart.match(/^(.*?)(?:\s*\((.*?)\))?$/);
            if (pMatch) {
              result.raceName = pMatch[1].trim();
              if (pMatch[2]) {
                result.subtype = pMatch[2].trim();
                result.subtypeName = pMatch[2].trim();
              }
            } else {
              result.raceName = primPart;
            }
          }
          if (secPart) {
            result.isHybrid = true;
            const sMatch = secPart.match(/^(.*?)(?:\s*\((.*?)\))?$/);
            if (sMatch) {
              result.secondaryRaceName = sMatch[1].trim();
              if (sMatch[2]) {
                result.secondarySubtype = sMatch[2].trim();
                result.secondarySubtypeName = sMatch[2].trim();
              }
            } else {
              result.secondaryRaceName = secPart;
            }
          }
        } else {
          const raceMatch = value.match(/^(.*?)(?:\s*\((.*?)\))?$/);
          if (raceMatch) {
            result.raceName = raceMatch[1].trim();
            if (raceMatch[2]) {
              result.subtype = raceMatch[2].trim();
              result.subtypeName = raceMatch[2].trim();
            }
          } else {
            result.raceName = value;
          }
        }
      } else if (key.includes('edad aparente') || key.includes('edad')) {
        result.anatomy.age = fuzzyMatchOption(value, AGES, value);
      } else if (key.includes('complexión física') || key.includes('complexión')) {
        result.anatomy.complexion = fuzzyMatchOption(value, COMPLEXIONS, value);
      } else if (key.includes('estatura') || key.includes('altura')) {
        result.anatomy.height = matchHeight(value);
      } else if (key.includes('tono de piel') || key.includes('color de piel')) {
        result.anatomy.skinColor = fuzzyMatchOption(value, SKIN_COLORS, value);
      } else if (key.includes('sexo base') || key.includes('base sexual') || key.includes('género') || key.includes('sexo')) {
        result.anatomy.sexBase = normalizeSexBase(value);
      } else if (key.includes('desarrollo mamario') || key.includes('pecho / copa') || key.includes('busto')) {
        result.anatomy.breastDevelopment = fuzzyMatchOption(value, BREAST_DEV, value);
      } else if (key.includes('cintura')) {
        result.anatomy.waist = fuzzyMatchOption(value, WAISTS, value);
      } else if (key.includes('glúteos') || key.includes('gluteos') || key.includes('caderas')) {
        result.anatomy.glutes = fuzzyMatchOption(value, GLUTES, value);
      } else if (key.includes('muslos') || key.includes('piernas superiores')) {
        result.anatomy.thighs = fuzzyMatchOption(value, THIGHS, value);
      } else if (key.includes('estructura inferior') || key.includes('parte inferior')) {
        const sil = fuzzyMatchOption(value, LOWER_BODY_STRUCTURES, value);
        result.anatomy.lowerBodyStructure = sil;
        result.appendices.lowerBodyStructure = sil;
      } else if (key.includes('núcleo vital') || key.includes('nucleo vital') || key.includes('núcleo en el pecho')) {
        result.anatomy.chestCore = fuzzyMatchOption(value, CHEST_CORES, value);
      } else if (key.includes('rasgo de cuello') || key.includes('cuello')) {
        result.anatomy.neckFeature = fuzzyMatchOption(value, NECK_FEATURES, value);
      }

      // Multi-attribute body line: - Cuerpo: sexo 2 mujer, complexión esbelto...
      else if (key === 'cuerpo' || key.includes('anatomía')) {
        parseMultiAttributeBodyLine(value, result);
      }

      // Facial & Structure (State 2)
      else if (key.includes('cabeza y estructura') || key === 'cabeza') {
        parseMultiAttributeHeadLine(value, result);
      } else if (key === 'forma de cabeza' || key.includes('forma facial')) {
        result.facial.headShape = fuzzyMatchOption(value, HEAD_SHAPES, value);
      } else if (key.includes('anchura de cabeza') || key === 'anchura') {
        result.facial.headWidth = fuzzyMatchOption(value, HEAD_WIDTHS, value);
      } else if (key.includes('estructura ósea') || key === 'estructura') {
        result.facial.boneStructure = fuzzyMatchOption(value, BONE_STRUCTURES, value);
      } else if (key.includes('morfología facial') || key.includes('morfologia')) {
        result.facial.facialMorphology = fuzzyMatchOption(value, FACIAL_MORPHOLOGIES, value);
      } else if (key.includes('esclerótica') || key.includes('esclerotica')) {
        result.facial.scleraColor = fuzzyMatchOption(value, SCLERA_COLORS, value);
      } else if (key === 'ojos' || key.includes('ojos (rasgos)')) {
        parseMultiAttributeEyesLine(value, result);
      } else if (key.includes('color de ojos') || key.includes('color ocular')) {
        result.facial.eyeColor = fuzzyMatchOption(value, EYE_COLORS, value);
      } else if (key.includes('categoría de ojos') || key.includes('forma de ojos')) {
        result.facial.eyesCategory = fuzzyMatchOption(value, EYES_CATEGORIES, value);
      } else if (key.includes('subtipo de ojos')) {
        result.facial.eyesSubtype = fuzzyMatchOption(value, EYES_SUBTYPES, value);
      } else if (key === 'iris') {
        result.facial.iris = fuzzyMatchOption(value, IRIS_TYPES, value);
      } else if (key === 'nariz') {
        result.facial.nose = fuzzyMatchOption(value, NOSES, value);
      } else if (key === 'boca') {
        parseMultiAttributeMouthLine(value, result);
      } else if (key === 'labios') {
        result.facial.lips = fuzzyMatchOption(value, LIPS, value);
      } else if (key.includes('dientes') || key.includes('dentadura')) {
        result.facial.teeth = fuzzyMatchOption(value, TEETHS, value);
      } else if (key === 'orejas') {
        parseMultiAttributeEarsLine(value, result);
      } else if (key.includes('orejas especiales') || key.includes('orejas kemono')) {
        result.facial.kemonoEars = fuzzyMatchOption(value, KEMONO_EARS, value);
      } else if (key.includes('expresión facial') || key === 'expresión' || key === 'expresion') {
        result.facial.expression = fuzzyMatchOption(value, EXPRESSIONS, value);
      }

      // Hair (State 2)
      else if (key === 'cabello' || key.includes('cabello (rasgos)')) {
        parseMultiAttributeHairLine(value, result);
      } else if (key.includes('color de cabello') || key.includes('color capilar')) {
        result.hair.hairColor = fuzzyMatchOption(value, HAIR_COLORS, value);
      } else if (key.includes('naturaleza elemental')) {
        result.hair.hairElemental = fuzzyMatchOption(value, HAIR_ELEMENTALS, value);
      } else if (key.includes('textura de cabello') || key === 'textura') {
        result.hair.texture = fuzzyMatchOption(value, HAIR_TEXTURES, value);
      } else if (key.includes('corte de cabello') || key === 'corte') {
        result.hair.cut = fuzzyMatchOption(value, HAIR_CUTS, value);
      } else if (key.includes('longitud de cabello') || key.includes('largo')) {
        result.hair.length = fuzzyMatchOption(value, HAIR_LENGTHS, value);
      } else if (key.includes('flequillo')) {
        result.hair.bangs = fuzzyMatchOption(value, HAIR_BANGS, value);
      } else if (key.includes('partido') || key.includes('raya de cabello')) {
        result.hair.part = fuzzyMatchOption(value, HAIR_PARTS, value);
      } else if (key.includes('peinado') || key.includes('estilo de peinado')) {
        result.hair.style = fuzzyMatchOption(value, HAIR_STYLES, value);
      } else if (key.includes('barba') || key.includes('vello facial')) {
        result.facial.facialHair = fuzzyMatchOption(value, FACIAL_HAIR_OPTIONS, value);
      }

      // Skin patterns & marks (State 2)
      else if (key.includes('piel y patrones') || key.includes('textura/patrón')) {
        parseSkinAndMarksLine(value, result);
      }

      // Makeup & Cosmetics (State 2)
      else if (key.includes('labial')) {
        if (!result.makeup) result.makeup = { ...DEFAULT_MAKEUP_CONFIG };
        result.makeup.lipstickStyle = value;
      } else if (key.includes('rubor')) {
        if (!result.makeup) result.makeup = { ...DEFAULT_MAKEUP_CONFIG };
        result.makeup.blushStyle = value;
      } else if (key.includes('manicura') || key.includes('uñas')) {
        if (!result.makeup) result.makeup = { ...DEFAULT_MAKEUP_CONFIG };
        result.makeup.nailStyle = value;
      } else if (key.includes('sombras de ojos')) {
        if (!result.makeup) result.makeup = { ...DEFAULT_MAKEUP_CONFIG };
        result.makeup.eyeshadowStyle = value;
      } else if (key.includes('delineado')) {
        if (!result.makeup) result.makeup = { ...DEFAULT_MAKEUP_CONFIG };
        result.makeup.eyelinerStyle = value;
      } else if (key.includes('acentos faciales')) {
        if (!result.makeup) result.makeup = { ...DEFAULT_MAKEUP_CONFIG };
        result.makeup.faceAccent = value;
      }

      // Appendices (State 2)
      else if (key.includes('cuernos')) {
        parseHornsLine(value, result);
      } else if (key.includes('alas')) {
        parseWingsLine(value, result);
      } else if (key.includes('cola')) {
        parseTailsLine(value, result);
      } else if (key.includes('antenas') || key.includes('palpos')) {
        parseAntennaeLine(value, result);
      } else if (key.includes('ojos adicionales')) {
        result.appendices.extraEyes = fuzzyMatchOption(value, EXTRA_EYES_OPTIONS, value);
      } else if (key.includes('brazos adicionales')) {
        result.appendices.extraArms = fuzzyMatchOption(value, EXTRA_ARMS_OPTIONS, value);
      } else if (key.includes('extremidades especiales')) {
        result.appendices.specialLimbs = fuzzyMatchOption(value, SPECIAL_LIMBS_OPTIONS, value);
      }

      // Role, Armor & Equipment (State 4)
      else if (key.includes('rol canónico principal') || key.includes('rol canónico') || key === 'rol') {
        result.role = matchRole(value);
      } else if (key.includes('sub-rol') || key.includes('subrol') || key.includes('modificador')) {
        result.subRole = value;
      } else if (key.includes('rol compuesto híbrido') || key.includes('rol híbrido') || key.includes('rol compuesto')) {
        result.hybridRoleTitle = value;
      } else if (key.includes('título nobiliario') || key.includes('titulo nobiliario')) {
        const titleMatch = value.match(/^(.*?)(?:\s+(de la Casa.*|del Dominio.*|de.*))?$/);
        if (titleMatch) {
          result.nobleTitle = titleMatch[1].trim();
          if (titleMatch[2]) result.nobleHouseOrDomain = titleMatch[2].trim();
        } else {
          result.nobleTitle = value;
        }
      } else if (key.includes('estilo estético principal') || key.includes('estilo estético') || key.includes('estilo visual') || key === 'estilo') {
        result.styleVisual = fuzzyMatchOption(value, VISUAL_STYLES, value);
      } else if (key.includes('sub-estilo compatible') || key.includes('sub-estilo') || key.includes('subestilo')) {
        result.subStyleVisual = fuzzyMatchOption(value, VISUAL_STYLES, value);
      } else if (key.includes('fusión estética visual') || key.includes('fusión estética') || key.includes('estilo fusión')) {
        result.styleFusionTitle = value;
      } else if (key.includes('indumentaria base')) {
        parseRoleAttireBaseLine(value, result);
      } else if (key.includes('protección y blindaje de rol') || key.includes('protección y blindaje') || key.includes('blindaje')) {
        result.armor.specialType = fuzzyMatchOption(value, ARMOR_TYPES, value);
      } else if (key.includes('empuñaduras') || key.includes('agarre de armamento')) {
        result.equipment.weaponGrips = value.split(',').map(s => fuzzyMatchOption(s.trim(), WEAPONS_GRIPS, s.trim())).filter(Boolean);
      }

      // Oriental / Thematic Style Gear Config (State 4)
      else if (key.includes('tradición / arquetipo aplicado') || key.includes('tradición') || key.includes('arquetipo aplicado')) {
        if (!result.orientalFantasy) result.orientalFantasy = {};
        result.orientalFantasy.tradition = value;
      } else if (key.includes('piezas de armadura del estilo')) {
        if (!result.orientalFantasy) result.orientalFantasy = {};
        result.orientalFantasy.armorPieces = value.split(';').map(s => s.trim()).filter(Boolean);
      } else if (key.includes('accesorios y joyería del estilo')) {
        if (!result.orientalFantasy) result.orientalFantasy = {};
        result.orientalFantasy.culturalAccessories = value.split(';').map(s => s.trim()).filter(Boolean);
      } else if (key.includes('patrón textil / damascado') || key.includes('damascado')) {
        if (!result.orientalFantasy) result.orientalFantasy = {};
        result.orientalFantasy.silkPattern = value;
      } else if (key.includes('gema / mineral de acento') || key.includes('mineral de acento')) {
        if (!result.orientalFantasy) result.orientalFantasy = {};
        result.orientalFantasy.jadeAccentColor = value;
      } else if (key.includes('motivo / sello temático') || key.includes('sello temático')) {
        if (!result.orientalFantasy) result.orientalFantasy = {};
        result.orientalFantasy.spiritualMotif = value;
      } else if (key.includes('aura / resplandor visual ambiental') || key.includes('aura / resplandor') || key.includes('aura')) {
        if (!result.orientalFantasy) result.orientalFantasy = {};
        result.orientalFantasy.energyAura = value;
      } else if (key.includes('estilo de armamento / herramienta') || key.includes('estilo de armamento')) {
        if (!result.orientalFantasy) result.orientalFantasy = {};
        result.orientalFantasy.weaponStyle = value;
      }

      // Intimate Anatomy & NSFW (State 2 - 2.6 R+18)
      else if (key.includes('pigmentación de areola') || key.includes('color y pigmentación de areola') || (key.includes('areola') && key.includes('color'))) {
        if (!result.nsfw) result.nsfw = { isNsfwEnabled: true, ageConfirmed: true };
        result.nsfw.isNsfwEnabled = true;
        result.nsfw.areolaColor = value;
      } else if (key.includes('proporción de areola') || key.includes('tamaño y proporción de areola') || (key.includes('areola') && (key.includes('tamaño') || key.includes('tamano')))) {
        if (!result.nsfw) result.nsfw = { isNsfwEnabled: true, ageConfirmed: true };
        result.nsfw.isNsfwEnabled = true;
        result.nsfw.areolaSize = value;
      } else if (key.includes('firmeza de pezón') || key.includes('morfología y firmeza de pezón') || key.includes('pezón') || key.includes('pezon')) {
        if (!result.nsfw) result.nsfw = { isNsfwEnabled: true, ageConfirmed: true };
        result.nsfw.isNsfwEnabled = true;
        result.nsfw.nippleType = value;
      } else if (key.includes('vello púbico') || key.includes('vello pubico') || key.includes('estilo y corte de vello')) {
        if (!result.nsfw) result.nsfw = { isNsfwEnabled: true, ageConfirmed: true };
        result.nsfw.isNsfwEnabled = true;
        result.nsfw.pubicHairStyle = value;
      } else if (key.includes('morfología y tipo de genitales') || key.includes('tipo de genitales') || key.includes('genitales')) {
        if (!result.nsfw) result.nsfw = { isNsfwEnabled: true, ageConfirmed: true };
        result.nsfw.isNsfwEnabled = true;
        result.nsfw.genitalType = value;
      } else if (key.includes('proporción / tamaño genital') || key.includes('proporción genital') || key.includes('tamaño genital') || key.includes('tamano genital')) {
        if (!result.nsfw) result.nsfw = { isNsfwEnabled: true, ageConfirmed: true };
        result.nsfw.isNsfwEnabled = true;
        result.nsfw.genitalSize = value;
      } else if (key.includes('rasgos & acabados íntimos') || key.includes('rasgos y acabados íntimos') || key.includes('acabados íntimos')) {
        if (!result.nsfw) result.nsfw = { isNsfwEnabled: true, ageConfirmed: true };
        result.nsfw.isNsfwEnabled = true;
        const details = value.split(/\s*\|\s*|\s*;\s*/).map(s => s.trim()).filter(Boolean);
        result.nsfw.genitalDetails = details.length > 0 ? details : [value];
      } else if (key.includes('zonas corporales hipersensibles') || key.includes('zonas hipersensibles') || key.includes('zonas erógenas')) {
        if (!result.nsfw) result.nsfw = { isNsfwEnabled: true, ageConfirmed: true };
        result.nsfw.isNsfwEnabled = true;
        const sensList = value.split(/\s*,\s*|\s*\|\s*/).map(s => s.trim()).filter(Boolean);
        result.nsfw.bodySensitivities = sensList;
      } else if (key.includes('dinámica / personalidad íntima') || key.includes('personalidad íntima') || key.includes('dinámica íntima')) {
        if (!result.nsfw) result.nsfw = { isNsfwEnabled: true, ageConfirmed: true };
        result.nsfw.isNsfwEnabled = true;
        result.nsfw.intimatePersonality = value;
      }

      // Background, Personality & Advanced Customization (State 5)
      else if (key === 'arquetipo') {
        result.archetype = value;
      } else if (key.includes('rasgos de personalidad') || key.includes('personalidad canónica') || key === 'personalidad') {
        result.personality = value;
        result.personalityTraits = value.split(',').map(s => s.trim()).filter(Boolean);
      } else if (key.includes('core de valores') || key.includes('valores fundamentales')) {
        result.background.coreValues = value;
      } else if (key.includes('talón de aquiles') || key.includes('defecto fatal') || key.includes('defecto trágico') || key.includes('vulnerabilidad fatal') || key.includes('vulnerabilidad')) {
        result.background.fatalFlawOrVulnerability = value;
        const flaws = value.split(/\s*\|\s*|\s*;\s*/).map(s => s.trim()).filter(Boolean);
        result.background.fatalFlaws = flaws.length > 0 ? flaws : [value];
      } else if (key.includes('voz (tono') || key.includes('tono de voz') || key.includes('tono y resonancia')) {
        if (result.background?.advancedCustomization) {
          result.background.advancedCustomization.voiceTone = value;
        }
      } else if (key.includes('forma de hablar') || key.includes('registro y modo') || key.includes('registro')) {
        if (result.background?.advancedCustomization) {
          result.background.advancedCustomization.speechStyle = value;
        }
      } else if (key.includes('muletilla') || key.includes('frases emblemáticas')) {
        if (result.background?.advancedCustomization) {
          result.background.advancedCustomization.catchphrasesOrIdioms = value;
        }
      } else if (key.includes('habilidades & talentos') || key.includes('talentos')) {
        if (result.background?.advancedCustomization) {
          result.background.advancedCustomization.skills = value.split(',').map(s => s.trim()).filter(Boolean);
        }
      } else if (key.includes('hábitos & manías') || key.includes('manerismos')) {
        if (result.background?.advancedCustomization) {
          result.background.advancedCustomization.habitsAndMannerisms = value.split(';').map(s => s.trim()).filter(Boolean);
        }
      }
    }
  }

  flushCurrentGarment();
  flushCurrentMilestone();

  if (parsedWardrobes.length > 0) {
    result.wardrobes = parsedWardrobes;
  }

  if (parsedRelationships.length > 0) {
    result.background.relationships = parsedRelationships;
  }

  if (parsedMilestones.length > 0 || parsedTurningPoints.length > 0) {
    if (!result.background.narrativeTimeline) {
      result.background.narrativeTimeline = { overview: '', thematicArc: '', pivotalTurningPoints: [], milestones: [] };
    }
    if (parsedMilestones.length > 0) result.background.narrativeTimeline.milestones = parsedMilestones;
    if (parsedTurningPoints.length > 0) result.background.narrativeTimeline.pivotalTurningPoints = parsedTurningPoints;
  }

  if (backstoryBuffer.length > 0) {
    result.background.backstory = backstoryBuffer.join('\n\n');
  }

  if (motivationBuffer.length > 0) {
    result.background.motivation = motivationBuffer.join('\n\n');
  }

  return sanitizeCharacterState(result);
}

/**
 * Parses role attire base line with multiple attributes:
 * e.g. "Corte/Tipología: O4 Ceremonial / Nobleza; Material Base: MAT04 - Seda; Acabado Base: FIN02 - Satinado"
 */
function parseRoleAttireBaseLine(lineVal: string, result: CharacterState) {
  const parts = lineVal.split(';').map(s => s.trim());
  parts.forEach(p => {
    const col = p.indexOf(':');
    if (col > 0) {
      const k = p.substring(0, col).trim().toLowerCase();
      const v = p.substring(col + 1).trim();
      if (k.includes('corte') || k.includes('tipolog')) {
        result.armor.type = fuzzyMatchOption(v, ROLE_OUTFIT_TYPES, v);
      } else if (k.includes('material')) {
        result.armor.material = fuzzyMatchOption(v, ARMOR_MATERIALS, v);
      } else if (k.includes('acabado')) {
        result.armor.finish = fuzzyMatchOption(v, ARMOR_FINISHES, v);
      }
    } else {
      if (!result.armor.type) result.armor.type = fuzzyMatchOption(p, ROLE_OUTFIT_TYPES, p);
    }
  });
}

/**
 * Parses role piece details string
 * e.g. "Color: Negro | Material: Terciopelo | Acabado: Mate | Adornos: Filigrana dorada en borde | Silueta/Aspecto: Amplia"
 */
function parseRolePieceDetail(pieceName: string, attrStr: string): RolePieceDetail {
  const detail: RolePieceDetail = {
    id: pieceName,
    name: pieceName
  };
  const segments = attrStr.split('|').map(s => s.trim());
  
  segments.forEach(seg => {
    const col = seg.indexOf(':');
    if (col > 0) {
      const k = seg.substring(0, col).trim().toLowerCase();
      const v = seg.substring(col + 1).trim();
      if (k.includes('color')) detail.color = resolveColorHexOrValue(v);
      else if (k.includes('largo') || k.includes('caída')) detail.length = v;
      else if (k.includes('material')) detail.material = fuzzyMatchOption(v, ARMOR_MATERIALS, v);
      else if (k.includes('acabado')) detail.finish = fuzzyMatchOption(v, ARMOR_FINISHES, v);
      else if (k.includes('adorno') || k.includes('detalles')) detail.detail = v;
      else if (k.includes('ubicación') || k.includes('ubicacion')) detail.detailLocation = v;
      else if (k.includes('silueta') || k.includes('aspecto')) detail.description = v;
    }
  });

  return detail;
}

/**
 * Parses equipment piece details string
 * e.g. "Color: Oro Viejo | Material: Madera de fresno | Acabado: Pulido | Dimensiones: 1.80m | Detalles: Orbe amatista"
 */
function parseEquipmentPieceDetail(itemName: string, category: 'weapon' | 'item' | 'bag', attrStr: string): EquipmentPieceDetail {
  const detail: EquipmentPieceDetail = {
    id: itemName,
    name: itemName,
    category
  };
  const segments = attrStr.split('|').map(s => s.trim());

  segments.forEach(seg => {
    const col = seg.indexOf(':');
    if (col > 0) {
      const k = seg.substring(0, col).trim().toLowerCase();
      const v = seg.substring(col + 1).trim();
      if (k.includes('color')) detail.color = resolveColorHexOrValue(v);
      else if (k.includes('material')) detail.material = fuzzyMatchOption(v, ARMOR_MATERIALS, v);
      else if (k.includes('acabado')) detail.finish = fuzzyMatchOption(v, ARMOR_FINISHES, v);
      else if (k.includes('dimensión') || k.includes('dimension') || k.includes('tamaño') || k.includes('capacidad')) detail.sizeOrLength = v;
      else if (k.includes('detalle') || k.includes('adornos')) detail.detail = v;
    }
  });

  return detail;
}

/**
 * Parses multi-attribute body line
 */
function parseMultiAttributeBodyLine(val: string, result: CharacterState) {
  const parts = val.split(/,\s*(?=[a-záéíóúñ\s]+(?:\d|sil|cor|nck|esbelto|atlético|normal|alto|incipiente|pequeño|medio|prominente|muy|avispa|redondead|planos|delgad|gruesos|bípede|cola|matriz|núcleo|gargantilla|pelaje|branquias|placas))/i).map(s => s.trim());
  
  parts.forEach(p => {
    const lower = p.toLowerCase();
    if (lower.startsWith('sexo') || lower.includes('mujer') || lower.includes('hombre') || lower.includes('andrógino')) {
      const clean = p.replace(/^sexo\s+/i, '').trim();
      result.anatomy.sexBase = normalizeSexBase(clean);
    } else if (lower.startsWith('complexión') || lower.includes('escuálido') || lower.includes('esbelto') || lower.includes('atlético') || lower.includes('musculoso') || lower.includes('voluminoso') || lower.includes('hipertrofiado') || lower.includes('relleno') || lower.includes('obeso')) {
      const clean = p.replace(/^complexión\s+/i, '').trim();
      result.anatomy.complexion = fuzzyMatchOption(clean, COMPLEXIONS, result.anatomy.complexion);
    } else if (lower.startsWith('altura') || lower.startsWith('estatura') || lower.includes(' m') || lower.includes('petite') || lower.includes('enorme')) {
      const clean = p.replace(/^(?:altura|estatura)\s+/i, '').trim();
      result.anatomy.height = matchHeight(clean);
    } else if (lower.startsWith('desarrollo mamario') || lower.includes('copa') || lower.includes('mamario') || lower.includes('busto') || lower.includes('incipiente') || lower.includes('abundante') || lower.includes('hipertrófico')) {
      const clean = p.replace(/^desarrollo mamario\s+/i, '').trim();
      result.anatomy.breastDevelopment = fuzzyMatchOption(clean, BREAST_DEV, result.anatomy.breastDevelopment);
    } else if (lower.startsWith('cintura') || lower.includes('avispa') || lower.includes('estrecha') || lower.includes('ancha')) {
      const clean = p.replace(/^cintura\s+/i, '').trim();
      result.anatomy.waist = fuzzyMatchOption(clean, WAISTS, result.anatomy.waist);
    } else if (lower.startsWith('glúteos') || lower.startsWith('gluteos') || lower.includes('glúteo') || lower.includes('gluteo') || lower.includes('redondeados') || lower.includes('firmes')) {
      const clean = p.replace(/^gl[úu]teos\s+/i, '').trim();
      result.anatomy.glutes = fuzzyMatchOption(clean, GLUTES, result.anatomy.glutes);
    } else if (lower.startsWith('muslos') || lower.includes('muslo') || lower.includes('torneados')) {
      const clean = p.replace(/^muslos\s+/i, '').trim();
      result.anatomy.thighs = fuzzyMatchOption(clean, THIGHS, result.anatomy.thighs);
    } else if (lower.includes('estructura inferior') || lower.includes('sil0') || lower.includes('bípedo') || lower.includes('aracne') || lower.includes('cecaelia') || lower.includes('lamia') || lower.includes('sirena') || lower.includes('centauro')) {
      const clean = p.replace(/^estructura inferior\s+/i, '').trim();
      const sil = fuzzyMatchOption(clean, LOWER_BODY_STRUCTURES, clean);
      result.anatomy.lowerBodyStructure = sil;
      result.appendices.lowerBodyStructure = sil;
    } else if (lower.includes('núcleo vital') || lower.includes('nucleo vital') || lower.includes('cor0') || lower.includes('núcleo de energía')) {
      const clean = p.replace(/^n[úu]cleo vital\s+/i, '').trim();
      result.anatomy.chestCore = fuzzyMatchOption(clean, CHEST_CORES, clean);
    } else if (lower.includes('rasgo de cuello') || lower.includes('nck0') || lower.includes('pelaje de lana') || lower.includes('branquias')) {
      const clean = p.replace(/^rasgo de cuello\s+/i, '').trim();
      result.anatomy.neckFeature = fuzzyMatchOption(clean, NECK_FEATURES, clean);
    }
  });
}

/**
 * Parses multi-attribute head line
 */
function parseMultiAttributeHeadLine(val: string, result: CharacterState) {
  const parts = val.split(',').map(s => s.trim());
  parts.forEach(p => {
    const lower = p.toLowerCase();
    if (lower.startsWith('forma') || lower.includes('ovalada') || lower.includes('redonda') || lower.includes('alargada') || lower.includes('cuadrada') || lower.includes('corazón') || lower.includes('diamante')) {
      const clean = p.replace(/^forma\s+/i, '').trim();
      result.facial.headShape = fuzzyMatchOption(clean, HEAD_SHAPES, result.facial.headShape);
    } else if (lower.startsWith('anchura') || lower.includes('estrecha') || lower.includes('ancha')) {
      const clean = p.replace(/^anchura\s+/i, '').trim();
      result.facial.headWidth = fuzzyMatchOption(clean, HEAD_WIDTHS, result.facial.headWidth);
    } else if (lower.startsWith('estructura') || lower.includes('pómulos') || lower.includes('mandíbula') || lower.includes('grácil') || lower.includes('robusta')) {
      const clean = p.replace(/^estructura\s+/i, '').trim();
      result.facial.boneStructure = fuzzyMatchOption(clean, BONE_STRUCTURES, result.facial.boneStructure);
    } else if (lower.includes('morfología') || lower.includes('morfologia') || lower.includes('morf0') || lower.includes('hocico') || lower.includes('pantheris') || lower.includes('orco') || lower.includes('arpía') || lower.includes('demiurgo')) {
      const clean = p.replace(/^morfolog[íi]a facial\s+/i, '').trim();
      result.facial.facialMorphology = fuzzyMatchOption(clean, FACIAL_MORPHOLOGIES, clean);
    }
  });
}

/**
 * Parses multi-attribute eyes line
 */
function parseMultiAttributeEyesLine(val: string, result: CharacterState) {
  const parts = val.split(',').map(s => s.trim());
  parts.forEach(p => {
    const lower = p.toLowerCase();
    if (lower.startsWith('color') || lower.includes('azul') || lower.includes('verde') || lower.includes('rojo') || lower.includes('dorado') || lower.includes('violeta') || lower.includes('marrón') || lower.includes('ámbar') || lower.includes('negro') || lower.includes('heterocromía')) {
      const clean = p.replace(/^color\s+/i, '').trim();
      result.facial.eyeColor = fuzzyMatchOption(clean, EYE_COLORS, clean);
    } else if (lower.includes('esclerótica') || lower.includes('esclerotica')) {
      const clean = p.replace(/^escler[óo]tica\s+/i, '').trim();
      result.facial.scleraColor = fuzzyMatchOption(clean, SCLERA_COLORS, clean);
    } else if (lower.startsWith('forma') || lower.includes('almendrados') || lower.includes('filosos') || lower.includes('caídos') || lower.includes('redondos') || lower.includes('rasgados') || lower.includes('inexpresivos') || lower.includes('exóticos')) {
      const clean = p.replace(/^forma\s+/i, '').trim();
      result.facial.eyesCategory = fuzzyMatchOption(clean, EYES_CATEGORIES, clean);
    } else if (lower.startsWith('tipo') || lower.includes('a1') || lower.includes('b1') || lower.includes('c1') || lower.includes('d1') || lower.includes('e1') || lower.includes('f1') || lower.includes('g1')) {
      const clean = p.replace(/^tipo\s+/i, '').trim();
      result.facial.eyesSubtype = fuzzyMatchOption(clean, EYES_SUBTYPES, clean);
    }
  });
}

/**
 * Parses multi-attribute mouth line
 */
function parseMultiAttributeMouthLine(val: string, result: CharacterState) {
  const parts = val.split(',').map(s => s.trim());
  parts.forEach(p => {
    const lower = p.toLowerCase();
    if (lower.startsWith('labios') || lower.includes('delgados') || lower.includes('carnosos') || lower.includes('básico')) {
      const clean = p.replace(/^labios\s+/i, '').trim();
      result.facial.lips = fuzzyMatchOption(clean, LIPS, clean);
    } else if (lower.startsWith('expresión') || lower.startsWith('expresion') || lower.includes('sonriente') || lower.includes('seria') || lower.includes('sensual') || lower.includes('entreabierta')) {
      const clean = p.replace(/^expresi[óo]n\s+/i, '').trim();
      result.facial.mouthExp = fuzzyMatchOption(clean, MOUTH_EXPS, clean);
      result.facial.expression = fuzzyMatchOption(clean, EXPRESSIONS, result.facial.expression);
    } else if (lower.startsWith('dientes') || lower.includes('colmillos') || lower.includes('afilados') || lower.includes('normales') || lower.includes('serrados')) {
      const clean = p.replace(/^dientes\s+/i, '').trim();
      result.facial.teeth = fuzzyMatchOption(clean, TEETHS, clean);
    }
  });
}

/**
 * Parses multi-attribute ears line
 */
function parseMultiAttributeEarsLine(val: string, result: CharacterState) {
  const parts = val.split(',').map(s => s.trim());
  parts.forEach(p => {
    const lower = p.toLowerCase();
    if (lower.includes('especiales') || lower.includes('kemono') || lower.includes('kemo-') || lower.includes('zorro') || lower.includes('gato') || lower.includes('lobo') || lower.includes('conejo') || lower.includes('dragón')) {
      const clean = p.replace(/^(?:orejas especiales|orejas kemono|orejas)\s+/i, '').trim();
      result.facial.kemonoEars = fuzzyMatchOption(clean, KEMONO_EARS, clean);
    } else {
      const clean = p.replace(/^tipo\s+/i, '').trim();
      result.facial.earsBase = fuzzyMatchOption(clean, EARS_BASES, clean);
    }
  });
}

/**
 * Parses multi-attribute hair line
 */
function parseMultiAttributeHairLine(val: string, result: CharacterState) {
  const parts = val.split(',').map(s => s.trim());
  parts.forEach(p => {
    const lower = p.toLowerCase();
    if (lower.startsWith('color') || lower.includes('platino') || lower.includes('negro') || lower.includes('castaño') || lower.includes('rubio') || lower.includes('pelirrojo')) {
      const clean = p.replace(/^color\s+/i, '').trim();
      result.hair.hairColor = fuzzyMatchOption(clean, HAIR_COLORS, clean);
    } else if (lower.includes('naturaleza elemental') || lower.includes('elemental') || lower.includes('tentáculos') || lower.includes('serpientes') || lower.includes('fuego') || lower.includes('niebla') || lower.includes('cables')) {
      const clean = p.replace(/^naturaleza elemental\s+/i, '').trim();
      result.hair.hairElemental = fuzzyMatchOption(clean, HAIR_ELEMENTALS, clean);
    } else if (lower.startsWith('textura') || lower.includes('liso') || lower.includes('ondulado') || lower.includes('rizado') || lower.includes('afro')) {
      const clean = p.replace(/^textura\s+/i, '').trim();
      result.hair.texture = fuzzyMatchOption(clean, HAIR_TEXTURES, clean);
    } else if (lower.startsWith('corte') || lower.includes('bob') || lower.includes('pixie') || lower.includes('capas') || lower.includes('recto') || lower.includes('hime')) {
      const clean = p.replace(/^corte\s+/i, '').trim();
      result.hair.cut = fuzzyMatchOption(clean, HAIR_CUTS, clean);
    } else if (lower.startsWith('largo') || lower.includes('rapado') || lower.includes('corto') || lower.includes('medio') || lower.includes('largo') || lower.includes('cintura') || lower.includes('piso')) {
      const clean = p.replace(/^largo\s+/i, '').trim();
      result.hair.length = fuzzyMatchOption(clean, HAIR_LENGTHS, clean);
    } else if (lower.startsWith('flequillo')) {
      const clean = p.replace(/^flequillo\s+/i, '').trim();
      result.hair.bangs = fuzzyMatchOption(clean, HAIR_BANGS, clean);
    } else if (lower.startsWith('partido') || lower.includes('al centro') || lower.includes('lateral')) {
      const clean = p.replace(/^partido\s+/i, '').trim();
      result.hair.part = fuzzyMatchOption(clean, HAIR_PARTS, clean);
    } else if (lower.startsWith('peinado') || lower.includes('coleta') || lower.includes('moño') || lower.includes('trenza') || lower.includes('semirrecogido') || lower.includes('suelto')) {
      const clean = p.replace(/^peinado\s+/i, '').trim();
      result.hair.style = fuzzyMatchOption(clean, HAIR_STYLES, clean);
    }
  });
}

/**
 * Parses skin and marks line
 */
function parseSkinAndMarksLine(val: string, result: CharacterState) {
  const locMatch = val.match(/\(ubicaci[óo]n de escamas\/placas:\s*(.*?)\)/i);
  if (locMatch) {
    result.appendices.scaleLocations = locMatch[1].split(',').map(s => s.trim()).filter(Boolean);
  }
  const cleanLine = val.replace(/\(ubicaci[óo]n de escamas\/placas:.*?\)/i, '').trim();
  const parts = cleanLine.split(',').map(s => s.trim());
  parts.forEach(p => {
    const lower = p.toLowerCase();
    if (lower.startsWith('tono') || lower.startsWith('color')) {
      const clean = p.replace(/^(?:tono|color)\s+/i, '').trim();
      result.anatomy.skinColor = fuzzyMatchOption(clean, SKIN_COLORS, clean);
    } else if (lower.includes('textura') || lower.includes('patrón') || lower.includes('t1') || lower.includes('t2') || lower.includes('piel')) {
      const clean = p.replace(/^(?:textura\/patr[óo]n|patr[óo]n|textura)\s+/i, '').trim();
      result.appendices.skinAndMarks = fuzzyMatchOption(clean, SKIN_AND_MARKS, clean);
    }
  });
}

/**
 * Parses horns line
 */
function parseHornsLine(val: string, result: CharacterState) {
  const parts = val.split(',').map(s => s.trim());
  parts.forEach(p => {
    const lower = p.toLowerCase();
    if (lower.startsWith('forma') || lower.includes('curvos') || lower.includes('rectos') || lower.includes('espiral') || lower.includes('ramificados')) {
      const clean = p.replace(/^forma\s+/i, '').trim();
      result.appendices.hornsForm = fuzzyMatchOption(clean, HORNS_FORMS, clean);
    } else if (lower.startsWith('longitud') || lower.includes('cm') || lower.includes('hl')) {
      const clean = p.replace(/^longitud\s+/i, '').trim();
      result.appendices.hornsLength = fuzzyMatchOption(clean, HORNS_LENGTHS, clean);
    } else if (lower.startsWith('grosor') || lower.includes('delgado') || lower.includes('medio') || lower.includes('grueso')) {
      const clean = p.replace(/^grosor\s+/i, '').trim();
      result.appendices.hornsThickness = fuzzyMatchOption(clean, HORNS_THICKNESSES, clean);
    } else if (lower.startsWith('posición') || lower.startsWith('posicion') || lower.includes('frontales') || lower.includes('laterales') || lower.includes('sienes')) {
      const clean = p.replace(/^posici[óo]n\s+/i, '').trim();
      result.appendices.hornsPosition = fuzzyMatchOption(clean, HORNS_POSITIONS, clean);
    }
  });
}

/**
 * Parses wings line
 */
function parseWingsLine(val: string, result: CharacterState) {
  const parts = val.split(',').map(s => s.trim());
  parts.forEach(p => {
    const lower = p.toLowerCase();
    if (lower.startsWith('tipo') || lower.includes('angélicas') || lower.includes('aviares') || lower.includes('dracónicas') || lower.includes('demoníacas') || lower.includes('mariposa') || lower.includes('hada')) {
      const clean = p.replace(/^tipo\s+/i, '').trim();
      result.appendices.wingsType = fuzzyMatchOption(clean, WINGS_TYPES, clean);
    } else if (lower.startsWith('tamaño') || lower.includes('pequeño') || lower.includes('medio') || lower.includes('grande') || lower.includes('masivo')) {
      const clean = p.replace(/^tamaño\s+/i, '').trim();
      result.appendices.wingsSize = fuzzyMatchOption(clean, WINGS_SIZES, clean);
    } else if (lower.startsWith('posición') || lower.startsWith('posicion') || lower.includes('espalda alta') || lower.includes('espalda baja') || lower.includes('cabeza')) {
      const clean = p.replace(/^posici[óo]n\s+/i, '').trim();
      result.appendices.wingsPosition = fuzzyMatchOption(clean, WINGS_POSITIONS, clean);
    }
  });
}

/**
 * Parses tails line
 */
function parseTailsLine(val: string, result: CharacterState) {
  const parts = val.split(',').map(s => s.trim());
  parts.forEach(p => {
    const lower = p.toLowerCase();
    if (lower.startsWith('tipo') || lower.includes('felina') || lower.includes('zorrina') || lower.includes('kitsune') || lower.includes('demoníaca') || lower.includes('lupina') || lower.includes('dracónida') || lower.includes('serpentina') || lower.includes('sirena')) {
      const clean = p.replace(/^tipo\s+/i, '').trim();
      result.appendices.tailsType = fuzzyMatchOption(clean, TAILS_TYPES, clean);
    } else if (lower.startsWith('longitud') || lower.includes('corta') || lower.includes('larga') || lower.includes('cm')) {
      const clean = p.replace(/^longitud\s+/i, '').trim();
      result.appendices.tailsLength = fuzzyMatchOption(clean, TAILS_LENGTHS, clean);
    }
  });
}

/**
 * Parses antennae line
 */
function parseAntennaeLine(val: string, result: CharacterState) {
  const parts = val.split(',').map(s => s.trim());
  parts.forEach(p => {
    const lower = p.toLowerCase();
    if (lower.startsWith('tipo') || lower.includes('plumosas') || lower.includes('filiformes') || lower.includes('articuladas') || lower.includes('bioluminiscentes') || lower.includes('polilla') || lower.includes('mariposa')) {
      const clean = p.replace(/^tipo\s+/i, '').trim();
      result.appendices.antennaeType = fuzzyMatchOption(clean, ANTENNAE_TYPES, clean);
    } else if (lower.startsWith('longitud') || lower.includes('cortas') || lower.includes('medias') || lower.includes('largas')) {
      const clean = p.replace(/^longitud\s+/i, '').trim();
      result.appendices.antennaeLength = fuzzyMatchOption(clean, ANTENNAE_LENGTHS, clean);
    } else if (lower.startsWith('posición') || lower.startsWith('posicion') || lower.includes('frontales') || lower.includes('coronales') || lower.includes('laterales')) {
      const clean = p.replace(/^posici[óo]n\s+/i, '').trim();
      result.appendices.antennaePosition = fuzzyMatchOption(clean, ANTENNAE_POSITIONS, clean);
    }
  });
}

function inferGarmentCategoryId(name: string, layer: string): string {
  const n = name.toLowerCase();
  const l = layer.toLowerCase();
  if (l.includes('interior')) return 'B0';
  if (l.includes('base') || l.includes('principal')) return 'B1';
  if (l.includes('media') || l.includes('chaleco')) return 'B2';
  if (l.includes('superior') || l.includes('chaqueta') || l.includes('abrigo')) return 'B3';
  if (l.includes('accesorio') || l.includes('joyería') || n.includes('collar') || n.includes('anillo')) return 'ACC';
  if (n.includes('vestido') || n.includes('túnica') || n.includes('kimono') || n.includes('hanfu')) return 'B1';
  if (n.includes('pantalón') || n.includes('falda') || n.includes('hakama')) return 'B1';
  if (n.includes('bota') || n.includes('sandalia') || n.includes('zapato')) return 'B4';
  return 'B1';
}

export interface StateTranslationBreakdown {
  state1: {
    title: string;
    details: string[];
    complete: boolean;
  };
  state2: {
    title: string;
    details: string[];
    complete: boolean;
  };
  state3: {
    title: string;
    details: string[];
    count: number;
    complete: boolean;
  };
  state4: {
    title: string;
    details: string[];
    complete: boolean;
  };
  state5: {
    title: string;
    details: string[];
    complete: boolean;
  };
  totalParsedFields: number;
}

/**
 * Generates an informative visual breakdown of how the imported sheet translates into the 5 interactive states.
 */
export function getStateTranslationBreakdown(state: CharacterState): StateTranslationBreakdown {
  const s1Details: string[] = [];
  if (state.raceName) s1Details.push(`Raza: ${state.raceName}${state.subtype ? ` (${state.subtype})` : ''}`);
  if (state.isHybrid && state.secondaryRaceName) s1Details.push(`Híbrido × ${state.secondaryRaceName}`);
  if (state.anatomy.sexBase) s1Details.push(`Base Sexual: ${state.anatomy.sexBase}`);
  if (state.anatomy.age) s1Details.push(`Edad: ${state.anatomy.age}`);
  if (state.anatomy.height) s1Details.push(`Estatura: ${state.anatomy.height}`);
  if (state.anatomy.complexion) s1Details.push(`Complexión: ${state.anatomy.complexion}`);
  if (state.anatomy.skinColor) s1Details.push(`Tono de Piel: ${state.anatomy.skinColor}`);
  if (state.anatomy.breastDevelopment && !/ningun|no aplica|plano/i.test(state.anatomy.breastDevelopment)) {
    s1Details.push(`Desarrollo Mamario: ${state.anatomy.breastDevelopment}`);
  }
  if (state.anatomy.waist) s1Details.push(`Cintura: ${state.anatomy.waist}`);
  if (state.anatomy.glutes) s1Details.push(`Glúteos: ${state.anatomy.glutes}`);
  if (state.anatomy.thighs) s1Details.push(`Muslos: ${state.anatomy.thighs}`);
  if (state.anatomy.lowerBodyStructure && !/bípedo humanoide estándar/i.test(state.anatomy.lowerBodyStructure)) {
    s1Details.push(`Estructura Inferior: ${state.anatomy.lowerBodyStructure}`);
  }
  if (state.anatomy.chestCore && !/ninguno/i.test(state.anatomy.chestCore)) {
    s1Details.push(`Núcleo Vital: ${state.anatomy.chestCore}`);
  }
  if (state.anatomy.neckFeature && !/ninguno/i.test(state.anatomy.neckFeature)) {
    s1Details.push(`Rasgo de Cuello: ${state.anatomy.neckFeature}`);
  }

  const s2Details: string[] = [];
  if (state.facial.headShape) s2Details.push(`Forma de Cabeza: ${state.facial.headShape}`);
  if (state.facial.facialMorphology && !/estándar humanoide/i.test(state.facial.facialMorphology)) {
    s2Details.push(`Morfología Facial: ${state.facial.facialMorphology}`);
  }
  if (state.facial.eyeColor) s2Details.push(`Ojos: ${state.facial.eyeColor} (${state.facial.eyesCategory || 'Forma libre'})`);
  if (state.facial.scleraColor && !/sin ojos|inexistente|ningun/i.test(state.facial.scleraColor)) {
    s2Details.push(`Esclerótica: ${state.facial.scleraColor}`);
  }
  if (state.hair.hairColor) s2Details.push(`Cabello: ${state.hair.hairColor} (${state.hair.style || 'Suelto'})`);
  if (state.hair.hairElemental && !/orgánico/i.test(state.hair.hairElemental)) {
    s2Details.push(`Cabello Elemental: ${state.hair.hairElemental}`);
  }
  if (state.appendices.hornsForm && !/ningun/i.test(state.appendices.hornsForm)) {
    s2Details.push(`Cuernos: ${state.appendices.hornsForm}`);
  }
  if (state.appendices.wingsType && !/ningun/i.test(state.appendices.wingsType)) {
    s2Details.push(`Alas: ${state.appendices.wingsType}`);
  }
  if (state.appendices.tailsType && !/ningun/i.test(state.appendices.tailsType)) {
    s2Details.push(`Cola: ${state.appendices.tailsType}`);
  }
  if (state.appendices.antennaeType && !/ningun/i.test(state.appendices.antennaeType)) {
    s2Details.push(`Antenas: ${state.appendices.antennaeType}`);
  }
  if (state.appendices.extraEyes && !/ningun|2 ojos/i.test(state.appendices.extraEyes)) {
    s2Details.push(`Ojos Adicionales: ${state.appendices.extraEyes}`);
  }
  if (state.appendices.extraArms && !/ningun|2 brazos/i.test(state.appendices.extraArms)) {
    s2Details.push(`Brazos Adicionales: ${state.appendices.extraArms}`);
  }
  if (state.appendices.specialLimbs && !/ningun|orgánicas/i.test(state.appendices.specialLimbs)) {
    s2Details.push(`Extremidades Especiales: ${state.appendices.specialLimbs}`);
  }
  if (state.makeup && state.makeup.lipstickStyle && !/natural|ningun/i.test(state.makeup.lipstickStyle)) {
    s2Details.push(`Maquillaje: ${state.makeup.lipstickStyle}`);
  }

  const s3Details: string[] = (state.wardrobes || []).map(w => `${w.name} [${w.layer || 'Capa'}]`);

  const s4Details: string[] = [];
  if (state.role) s4Details.push(`Rol: ${state.role}${state.subRole ? ` (+ ${state.subRole})` : ''}`);
  if (state.nobleTitle) s4Details.push(`Título: ${state.nobleTitle} ${state.nobleHouseOrDomain || ''}`);
  if (state.styleVisual) s4Details.push(`Estilo: ${state.styleVisual}`);
  if (state.armor?.specialType && !/ningun/i.test(state.armor.specialType)) {
    s4Details.push(`Blindaje: ${state.armor.specialType}`);
  }
  if (state.armor?.pieces && state.armor.pieces.length > 0) {
    s4Details.push(`Piezas de Indumentaria (${state.armor.pieces.length})`);
  }
  if (state.equipment?.weapons && state.equipment.weapons.length > 0) {
    s4Details.push(`Armas (${state.equipment.weapons.length}): ${state.equipment.weapons.join(', ')}`);
  }
  if (state.equipment?.bags && state.equipment.bags.length > 0) {
    s4Details.push(`Contenedores (${state.equipment.bags.length})`);
  }
  if (state.equipment?.items && state.equipment.items.length > 0) {
    s4Details.push(`Reliquias / Objetos (${state.equipment.items.length})`);
  }

  const s5Details: string[] = [];
  if (state.personality) s5Details.push(`Personalidad: ${state.personality}`);
  if (state.archetype && state.archetype !== 'Genérico') s5Details.push(`Arquetipo: ${state.archetype}`);
  if (state.background?.coreValues) s5Details.push(`Valores: ${state.background.coreValues}`);
  if (state.background?.relationships && state.background.relationships.length > 0) {
    s5Details.push(`Relaciones: ${state.background.relationships.length} registradas`);
  }
  if (state.background?.narrativeTimeline?.milestones && state.background.narrativeTimeline.milestones.length > 0) {
    s5Details.push(`Hitos de Cronología: ${state.background.narrativeTimeline.milestones.length}`);
  }
  if (state.background?.backstory) s5Details.push(`Historia de origen activa`);
  if (state.background?.advancedCustomization?.voiceTone || state.background?.advancedCustomization?.speechStyle) {
    s5Details.push(`Personalización de Voz & Habla configurada`);
  }

  const totalFields = s1Details.length + s2Details.length + s3Details.length + s4Details.length + s5Details.length;

  return {
    state1: { title: 'Estado 1: Raza & Anatomía', details: s1Details, complete: s1Details.length >= 3 },
    state2: { title: 'Estado 2: Rostro, Cabello & Apéndices', details: s2Details, complete: s2Details.length >= 2 },
    state3: { title: 'Estado 3: Prendas & Accesorios', details: s3Details, count: s3Details.length, complete: s3Details.length > 0 },
    state4: { title: 'Estado 4: Rol, Armas & Estilo', details: s4Details, complete: s4Details.length >= 2 },
    state5: { title: 'Estado 5: Trasfondo, Cronología & Relaciones', details: s5Details, complete: s5Details.length >= 2 },
    totalParsedFields: totalFields
  };
}

/**
 * Universal loader: parses string content (Embedded JSON in Markdown, Native JSON, or Plain Markdown),
 * detects format, and produces a complete sanitized CharacterState and translation breakdown.
 */
export function parseCharacterData(input: string): {
  success: boolean;
  state?: CharacterState;
  sourceFormat?: 'json' | 'markdown';
  characterName?: string;
  stateBreakdown?: StateTranslationBreakdown;
  error?: string;
} {
  const trimmed = input.trim();
  if (!trimmed) {
    return { success: false, error: 'El contenido está vacío.' };
  }

  // Attempt 0: Check for Embedded Canonical State Block in Markdown comment
  const embeddedMatch = trimmed.match(/<!--\s*CANONICAL_(?:CHARACTER_SHEET_DATA|STATE_JSON|STATE_DATA):\s*(\{[\s\S]*?\})\s*-->/);
  if (embeddedMatch && embeddedMatch[1]) {
    try {
      const parsedEmbedded = JSON.parse(embeddedMatch[1]);
      const state = sanitizeCharacterState(parsedEmbedded);
      const stateBreakdown = getStateTranslationBreakdown(state);
      return {
        success: true,
        state,
        sourceFormat: 'markdown',
        characterName: state.name || 'Personaje desde Ficha Técnica (Canónica Embebida)',
        stateBreakdown
      };
    } catch (e) {
      // Fallback to regular parsing if embedded block was corrupted
    }
  }

  // Attempt 1: Check for JSON code block in Markdown ```json ... ```
  const codeBlockMatch = trimmed.match(/```(?:json)?\s*(\{[\s\S]*?\})\s*```/);
  if (codeBlockMatch && codeBlockMatch[1]) {
    try {
      const parsedJson = JSON.parse(codeBlockMatch[1]);
      const state = sanitizeCharacterState(parsedJson);
      const stateBreakdown = getStateTranslationBreakdown(state);
      return {
        success: true,
        state,
        sourceFormat: 'json',
        characterName: state.name || 'Personaje Importado (JSON)',
        stateBreakdown
      };
    } catch (e) {
      // Proceed
    }
  }

  // Attempt 2: Native JSON format
  if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
    try {
      const parsed = JSON.parse(trimmed);
      let targetObj = parsed;
      if (Array.isArray(parsed)) {
        if (parsed.length === 0) {
          return { success: false, error: 'El archivo JSON es un array vacío.' };
        }
        targetObj = parsed[0];
      }

      const state = sanitizeCharacterState(targetObj);
      const stateBreakdown = getStateTranslationBreakdown(state);
      return {
        success: true,
        state,
        sourceFormat: 'json',
        characterName: state.name || 'Personaje Importado (JSON)',
        stateBreakdown
      };
    } catch (e: any) {
      if (trimmed.startsWith('{') && trimmed.endsWith('}')) {
        return { success: false, error: `Error de sintaxis JSON: ${e.message}` };
      }
    }
  }

  // Attempt 3: Deep Semantic Markdown / Text format
  try {
    const state = parseMarkdownCharacterSheet(trimmed);
    const stateBreakdown = getStateTranslationBreakdown(state);
    return {
      success: true,
      state,
      sourceFormat: 'markdown',
      characterName: state.name || 'Personaje desde Ficha Técnica',
      stateBreakdown
    };
  } catch (e: any) {
    return { success: false, error: `No se pudo interpretar el archivo o texto: ${e.message}` };
  }
}
