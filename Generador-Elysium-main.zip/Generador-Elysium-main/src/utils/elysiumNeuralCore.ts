// =========================================================================
// ELYSIUM NEURAL CORE - NÚCLEO PRINCIPAL DEL MODELO DE LENGUAJE
// =========================================================================
// 
// Elysium Neural es un modelo de lenguaje basado en texto orientado al rolplay
// con razonamiento cognitivo local avanzado. Este núcleo integra:
// 
// 1. Comprensión profunda de entrada de usuario (semántica, contexto, subtexto)
// 2. Razonamiento lógico y cognitivo (Chain of Thought, memoria contextual)
// 3. Generación de respuestas coherentes y contextualizadas
// 4. Interpretación avanzada de personajes (psicología, moral, motivaciones)
// 5. Sistema de conocimiento ontológico local (física, vestuario, arquitectura)
// 6. Capacidad de simulación autónoma de personajes
//
// =========================================================================

import { CharacterConsciousnessProfile, ConsciousResponse, generateCharacterConsciousness } from './characterConsciousnessEngine';
import { UnifiedParticipant, CharacterState, createUnifiedParticipant } from './characterLogicEngine';
import { LocalLLM, LLMContext, LLMResponse, LLMConfig, DEFAULT_LLM_CONFIG, tokenize, normalizeText, retrieveRelevantKnowledge, generateReasoningChain, ReasoningStep } from './localLLM';
import { analyzeSemanticSubtext, SemanticAnalysisResult, CognitiveAppraisal, SomatosensoryState, generateSomaticCognitiveResponse, generateAutonomousSceneNarration, generateAutonomousSceneNarrationFull, generateCharacterSomaticResponse } from './somaticCognitiveEngine';
import { formatConversationMemoryForPrompt, extractMemoryInsightsOffline, mergeMemoryUpdates, ConversationMemory } from './conversationMemoryEngine';
import { formatKnowledgeForPrompt, retrieveKnowledge, KNOWLEDGE_CORPUS, analyzeSceneWithKnowledge, KnowledgeEntry } from './localKnowledgeLibrary';
import { UnifiedCharacterSheet, CharacterAppearance, CharacterPersonality, CharacterWardrobe, CharacterSomatic } from './characterSheetLoader';

// -------------------------------------------------------------------------
// TIPOS PRINCIPALES
// -------------------------------------------------------------------------

/**
 * Tipos de entrada que puede procesar Elysium Neural
 */
export type InputType = 
  | 'user_message'           // Mensaje directo del usuario
  | 'character_dialogue'     // Diálogo de personaje
  | 'narrator_request'       // Solicitud de narración
  | 'scene_description'      // Descripción de escena
  | 'ooc_query'              // Consulta Out-Of-Character
  | 'system_command'         // Comando del sistema
  | 'memory_consolidation'  // Consolidación de memoria
  | 'knowledge_query'        // Consulta de conocimiento
  | 'backstory_generation'   // Generación de trasfondo
  | 'timeline_generation'    // Generación de línea temporal
  ;

/**
 * Contexto de entrada para Elysium Neural
 */
export interface NeuralInput {
  type: InputType;
  text: string;
  sender?: {
    id: string;
    name: string;
    role: string;
    type: 'user' | 'npc' | 'narrator' | 'agent' | 'system';
  };
  target?: {
    id: string;
    name: string;
    role: string;
    type: 'user' | 'npc' | 'narrator' | 'agent' | 'system';
  };
  characterProfile?: CharacterConsciousnessProfile;
  characterSheet?: UnifiedCharacterSheet;
  conversationHistory?: Array<{
    sender: string;
    receiver?: string;
    text: string;
    timestamp?: string;
    intent?: string;
  }>;
  conversationMemory?: ConversationMemory;
  place?: {
    name: string;
    zoneName?: string;
    weather?: string;
    hour?: string;
    atmosphere?: string;
    details?: string;
    rhythmOrVibes?: string[];
  };
  worldBuilding?: {
    worldName: string;
    laws: string[];
    factions?: string[];
    cosmology?: string;
  };
  companions?: UnifiedParticipant[];
  protagonist?: UnifiedParticipant;
  semanticAnalysis?: SemanticAnalysisResult;
  knowledgeDomains?: string[];
  maxTokens?: number;
  temperature?: number;
  enableReasoning?: boolean;
  enableMemory?: boolean;
  enablePersonality?: boolean;
  enableSomatic?: boolean;
}

/**
 * Resultado del procesamiento de Elysium Neural
 */
export interface NeuralOutput {
  // Respuesta principal
  text: string;
  
  // Metadatos de la respuesta
  responseType: 'dialogue' | 'narration' | 'analysis' | 'command_response' | 'memory_update' | 'knowledge_response' | 'error';
  
  // Información del hablante (si aplica)
  speaker?: {
    name: string;
    role: string;
    type: 'user' | 'npc' | 'narrator' | 'agent' | 'system';
  };
  
  // Razonamiento interno
  reasoning?: {
    chain: ReasoningStep[];
    summary: string;
    confidence: number;
  };
  
  // Análisis semántico
  semanticAnalysis?: SemanticAnalysisResult;
  
  // Conocimiento aplicado
  appliedKnowledge?: KnowledgeEntry[];
  
  // Estado somático (para personajes)
  somaticState?: SomatosensoryState;
  
  // Monólogo interno (para personajes)
  innerMonologue?: string;
  
  // Actualización de memoria
  memoryUpdate?: {
    keyFacts: string[];
    agreementsAndPromises: string[];
    unresolvedQuestions: string[];
    narrativeTone?: string;
    characterPerspectives?: Record<string, {
      perceivedAffinity: number;
      trustLevel: number;
      internalObservation: string;
    }>;
  };
  
  // Evaluación cognitiva
  cognitiveAppraisal?: CognitiveAppraisal;
  
  // Información de narración (para narrador)
  narrationInfo?: {
    directorIntent: string;
    environmentalShift: string;
    castReactionsSummary: string;
    narrativeHooks: string[];
    isOocDirectAnswer: boolean;
    discoveredFact?: string;
  };
  
  // Tokens generados
  tokens?: number;
  processingTime?: number;
  
  // Indicador de fallback
  isFallback: boolean;
  fallbackReason?: string;
  
  // Error (si aplica)
  error?: string;
}

/**
 * Configuración de Elysium Neural
 */
export interface NeuralConfig {
  model: 'elysium-v1' | 'elysium-v2' | 'elysium-reasoner' | 'elysium-ultimate';
  llmConfig?: Partial<LLMConfig>;
  enableAllFeatures: boolean;
  enableAdvancedReasoning: boolean;
  enableMemorySystem: boolean;
  enablePersonalitySystem: boolean;
  enableSomaticSystem: boolean;
  enableKnowledgeSystem: boolean;
  maxContextLength: number;
  maxResponseLength: number;
  defaultTemperature: number;
  defaultTopK: number;
}

/**
 * Contexto de sesión para Elysium Neural
 */
export interface NeuralSession {
  id: string;
  conversationHistory: NeuralInput[];
  conversationMemory: ConversationMemory;
  activeCharacters: Map<string, CharacterConsciousnessProfile>;
  place: NeuralInput['place'];
  worldBuilding: NeuralInput['worldBuilding'];
  createdAt: Date;
  lastUpdated: Date;
}

// -------------------------------------------------------------------------
// CONFIGURACIÓN POR DEFECTO
// -------------------------------------------------------------------------

export const DEFAULT_NEURAL_CONFIG: NeuralConfig = {
  model: 'elysium-ultimate',
  llmConfig: DEFAULT_LLM_CONFIG,
  enableAllFeatures: true,
  enableAdvancedReasoning: true,
  enableMemorySystem: true,
  enablePersonalitySystem: true,
  enableSomaticSystem: true,
  enableKnowledgeSystem: true,
  maxContextLength: 8192,
  maxResponseLength: 2048,
  defaultTemperature: 0.7,
  defaultTopK: 10,
};

// =========================================================================
// CLASE PRINCIPAL: Elysium Neural Core
// =========================================================================

/**
 * Elysium Neural - Modelo de Lenguaje Basado en Texto para Rolplay
 * 
 * Capacidades:
 * - Comprensión profunda de entrada de usuario
 * - Razonamiento cognitivo local avanzado
 * - Generación de respuestas coherentes y contextualizadas
 * - Interpretación avanzada de personajes
 * - Sistema de conocimiento ontológico
 * - Simulación autónoma de personajes
 */
export class ElysiumNeural {
  private config: NeuralConfig;
  private llm: LocalLLM;
  private sessions: Map<string, NeuralSession>;
  private knowledgeCache: Map<string, KnowledgeEntry[]>;
  private initializationTime: Date;
  
  constructor(config: Partial<NeuralConfig> = {}) {
    this.config = { ...DEFAULT_NEURAL_CONFIG, ...config };
    this.llm = new LocalLLM(this.config.llmConfig);
    this.sessions = new Map();
    this.knowledgeCache = new Map();
    this.initializationTime = new Date();
    
    console.log(`[Elysium Neural] Initialized with model: ${this.config.model}`);
    console.log(`[Elysium Neural] Features: Reasoning=${this.config.enableAdvancedReasoning}, Memory=${this.config.enableMemorySystem}, Personality=${this.config.enablePersonalitySystem}, Somatic=${this.config.enableSomaticSystem}, Knowledge=${this.config.enableKnowledgeSystem}`);
  }
  
  // -------------------------------------------------------------------------
  // GESTIÓN DE SESIONES
  // -------------------------------------------------------------------------
  
  /**
   * Crea una nueva sesión de conversación
   */
  createSession(sessionId: string, initialContext: Partial<NeuralSession> = {}): NeuralSession {
    const session: NeuralSession = {
      id: sessionId,
      conversationHistory: [],
      conversationMemory: {
        turnCount: 0,
        summary: '',
        keyFacts: [],
        agreementsAndPromises: [],
        unresolvedQuestions: [],
        activeTopics: [],
        characterPerspectives: {},
        narrativeTone: 'Neutral',
      },
      activeCharacters: new Map(),
      place: initialContext.place || { name: 'Lugar desconocido' },
      worldBuilding: initialContext.worldBuilding || { worldName: 'Elysium', laws: [] },
      createdAt: new Date(),
      lastUpdated: new Date(),
      ...initialContext,
    };
    
    this.sessions.set(sessionId, session);
    return session;
  }
  
  /**
   * Obtiene una sesión existente
   */
  getSession(sessionId: string): NeuralSession | undefined {
    return this.sessions.get(sessionId);
  }
  
  /**
   * Elimina una sesión
   */
  deleteSession(sessionId: string): boolean {
    return this.sessions.delete(sessionId);
  }
  
  /**
   * Actualiza el contexto de una sesión
   */
  updateSessionContext(sessionId: string, updates: Partial<NeuralSession>): boolean {
    const session = this.sessions.get(sessionId);
    if (!session) return false;
    
    Object.assign(session, updates);
    session.lastUpdated = new Date();
    return true;
  }
  
  // -------------------------------------------------------------------------
  // PROCESAMIENTO PRINCIPAL
  // -------------------------------------------------------------------------
  
  /**
   * Procesa una entrada y genera una respuesta
   * 
   * Este es el método principal que orchestrate todos los subsistemas:
   * 1. Análisis semántico de la entrada
   * 2. Recuperación de conocimiento relevante
   * 3. Razonamiento cognitivo (Chain of Thought)
   * 4. Generación de respuesta contextualizada
   * 5. Aplicación de personalidad y estilo del personaje
   * 6. Integración somática (si aplica)
   * 7. Actualización de memoria de conversación
   */
  async processInput(input: NeuralInput, sessionId?: string): Promise<NeuralOutput> {
    const startTime = Date.now();
    
    try {
      // Obtener o crear sesión
      const session = sessionId ? this.sessions.get(sessionId) : undefined;
      
      // Validar entrada
      if (!input.text || typeof input.text !== 'string') {
        return this.createErrorOutput('Entrada inválida: el texto es requerido');
      }
      
      // Determinar tipo de procesamiento según el tipo de entrada
      switch (input.type) {
        case 'character_dialogue':
          return await this.processCharacterDialogue(input, session, startTime);
          
        case 'narrator_request':
          return await this.processNarratorRequest(input, session, startTime);
          
        case 'ooc_query':
          return await this.processOOCQuery(input, session, startTime);
          
        case 'knowledge_query':
          return await this.processKnowledgeQuery(input, session, startTime);
          
        case 'memory_consolidation':
          return await this.processMemoryConsolidation(input, session, startTime);
          
        case 'scene_description':
          return await this.processSceneDescription(input, session, startTime);
          
        case 'backstory_generation':
          return await this.processBackstoryGeneration(input, session, startTime);
          
        case 'timeline_generation':
          return await this.processTimelineGeneration(input, session, startTime);
          
        case 'system_command':
          return await this.processSystemCommand(input, session, startTime);
          
        case 'user_message':
        default:
          return await this.processUserMessage(input, session, startTime);
      }
    } catch (error) {
      console.error('[Elysium Neural] Error processing input:', error);
      return this.createErrorOutput(`Error al procesar: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
  
  // -------------------------------------------------------------------------
  // PROCESADORES ESPECIALIZADOS
  // -------------------------------------------------------------------------
  
  /**
   * Procesa un mensaje de usuario
   */
  private async processUserMessage(input: NeuralInput, session: NeuralSession | undefined, startTime: number): Promise<NeuralOutput> {
    const cleanText = input.text.trim();
    
    if (!cleanText) {
      return this.createErrorOutput('El mensaje está vacío');
    }
    
    // Analizar semántica
    const semanticAnalysis = this.config.enableAdvancedReasoning && this.config.enablePersonalitySystem
      ? analyzeSemanticSubtext(cleanText, input.target?.name)
      : this.createBasicSemanticAnalysis(cleanText);
    
    // Determinar el personaje objetivo
    const targetCharacter = input.characterProfile || 
      (input.target?.id && session?.activeCharacters.get(input.target.id));
    
    // Configurar contexto LLM
    const llmContext: LLMContext = {
      systemPrompt: this.generateSystemPromptForUserMessage(input, targetCharacter),
      conversationHistory: this.convertHistoryToLLMFormat(session?.conversationHistory || input.conversationHistory || []),
      characterProfile: targetCharacter,
      semanticAnalysis,
      maxTokens: input.maxTokens || this.config.maxResponseLength,
      temperature: input.temperature || this.config.defaultTemperature,
      topK: this.config.defaultTopK,
    };
    
    // Recuperar conocimiento relevante
    const knowledgeEntries = this.config.enableKnowledgeSystem
      ? this.retrieveContextualKnowledge(cleanText, input.knowledgeDomains)
      : [];
    
    // Generar cadena de razonamiento
    const reasoningChain = this.config.enableAdvancedReasoning
      ? generateReasoningChain(cleanText, llmContext, targetCharacter)
      : [];
    
    // Configurar el LLM con el perfil del personaje
    if (targetCharacter) {
      this.llm.setCharacterProfile(targetCharacter);
    }
    
    // Generar respuesta usando el LLM local
    const llmResponse = this.llm.generate(cleanText, llmContext);
    
    // Procesar la respuesta
    const responseText = this.postProcessResponse(llmResponse.text, targetCharacter, semanticAnalysis);
    
    // Generar estado somático si aplica
    let somaticState: SomatosensoryState | undefined;
    let innerMonologue: string | undefined;
    
    if (this.config.enableSomaticSystem && targetCharacter) {
      const somaticResponse = generateCharacterSomaticResponse({
        character: targetCharacter,
        userMessage: cleanText,
        place: input.place,
        semanticAnalysis,
      });
      somaticState = somaticResponse.somaticState;
      innerMonologue = somaticResponse.innerMonologue;
    }
    
    // Actualizar memoria de conversación
    const memoryUpdate = this.config.enableMemorySystem && session
      ? this.updateConversationMemory(session, input, llmResponse, semanticAnalysis)
      : undefined;
    
    return this.createSuccessOutput({
      text: responseText,
      responseType: 'dialogue',
      speaker: input.target || input.sender,
      reasoning: {
        chain: reasoningChain,
        summary: `Respuesta generada a partir de análisis semántico: ${semanticAnalysis.intent}`,
        confidence: llmResponse.confidence,
      },
      semanticAnalysis,
      appliedKnowledge: knowledgeEntries,
      somaticState,
      innerMonologue,
      memoryUpdate,
      tokens: llmResponse.tokens.length,
      processingTime: Date.now() - startTime,
      isFallback: false,
    });
  }
  
  /**
   * Procesa un diálogo de personaje
   */
  private async processCharacterDialogue(input: NeuralInput, session: NeuralSession | undefined, startTime: number): Promise<NeuralOutput> {
    const cleanText = input.text.trim();
    
    if (!cleanText) {
      return this.createErrorOutput('El diálogo está vacío');
    }
    
    const characterProfile = input.characterProfile;
    const characterSheet = input.characterSheet;
    
    if (!characterProfile && !characterSheet) {
      return this.createErrorOutput('Se requiere un perfil de personaje o ficha para procesar el diálogo');
    }
    
    // Crear perfil de conciencia si no existe
    const fullProfile = characterProfile || createUnifiedParticipant(characterSheet as any).consciousnessProfile;
    
    // Analizar semántica
    const semanticAnalysis = analyzeSemanticSubtext(cleanText, input.target?.name);
    
    // Generar respuesta de conciencia del personaje
    const consciousResponse = generateCharacterConsciousness({
      profile: fullProfile,
      userMessage: cleanText,
      place: input.place,
      companions: input.companions,
      protagonist: input.protagonist,
      semanticAnalysis,
      conversationHistory: input.conversationHistory,
      conversationMemory: input.conversationMemory,
    });
    
    // Generar estado somático
    const somaticResponse = this.config.enableSomaticSystem
      ? generateCharacterSomaticResponse({
          character: fullProfile,
          userMessage: cleanText,
          place: input.place,
          semanticAnalysis,
        })
      : { somaticState: undefined, innerMonologue: '' };
    
    // Actualizar memoria
    const memoryUpdate = this.config.enableMemorySystem && session
      ? this.updateConversationMemory(session, input, { text: consciousResponse.reply, tokens: [], confidence: 0.9, finishReason: 'stop' }, semanticAnalysis)
      : undefined;
    
    return this.createSuccessOutput({
      text: consciousResponse.reply,
      responseType: 'dialogue',
      speaker: {
        name: fullProfile.name,
        role: fullProfile.role,
        type: 'npc',
      },
      reasoning: {
        chain: consciousResponse.reasoningSteps || [],
        summary: consciousResponse.reasoningSummary || 'Respuesta basada en conciencia del personaje',
        confidence: 0.9,
      },
      semanticAnalysis,
      somaticState: somaticResponse.somaticState,
      innerMonologue: somaticResponse.innerMonologue || consciousResponse.innerMonologue,
      cognitiveAppraisal: consciousResponse.cognitiveAppraisal,
      memoryUpdate,
      tokens: cleanText.split(/\s+/).length,
      processingTime: Date.now() - startTime,
      isFallback: false,
    });
  }
  
  /**
   * Procesa una solicitud de narración
   */
  private async processNarratorRequest(input: NeuralInput, session: NeuralSession | undefined, startTime: number): Promise<NeuralOutput> {
    const cleanText = input.text.trim();
    
    const place = input.place || session?.place || { name: 'el escenario' };
    const worldBuilding = input.worldBuilding || session?.worldBuilding || { worldName: 'Elysium', laws: [] };
    const history = input.conversationHistory || session?.conversationHistory || [];
    const memory = input.conversationMemory || session?.conversationMemory;
    
    // Generar narración autónoma
    const narration = generateAutonomousSceneNarrationFull({
      userAction: cleanText,
      place,
      worldBuilding,
      recentHistory: history.map(h => ({
        speakerName: h.sender,
        text: h.text,
        timestamp: h.timestamp,
      })),
      protagonist: input.protagonist,
      companions: input.companions,
      conversationMemory: memory,
    });
    
    return this.createSuccessOutput({
      text: narration.text,
      responseType: 'narration',
      speaker: {
        name: 'Narrador',
        role: 'Maestro de Juego',
        type: 'narrator',
      },
      narrationInfo: {
        directorIntent: narration.directorIntent,
        environmentalShift: narration.environmentalShift,
        castReactionsSummary: narration.castReactionsSummary,
        narrativeHooks: narration.narrativeHooks,
        isOocDirectAnswer: narration.isOocDirectAnswer,
        discoveredFact: narration.discoveredFact,
      },
      tokens: cleanText.split(/\s+/).length,
      processingTime: Date.now() - startTime,
      isFallback: false,
    });
  }
  
  /**
   * Procesa una consulta OOC (Out of Character)
   */
  private async processOOCQuery(input: NeuralInput, session: NeuralSession | undefined, startTime: number): Promise<NeuralOutput> {
    const cleanText = input.text.trim();
    
    // Analizar la consulta OOC
    const semanticAnalysis = analyzeSemanticSubtext(cleanText);
    
    // Determinar contexto
    const place = input.place || session?.place || { name: 'el escenario' };
    const worldBuilding = input.worldBuilding || session?.worldBuilding || { worldName: 'Elysium', laws: [] };
    const companions = input.companions || [];
    const protagonist = input.protagonist;
    
    // Formatear memoria de conversación
    const memoryFormatted = formatConversationMemoryForPrompt(input.conversationMemory || session?.conversationMemory);
    
    // Consultar conocimiento local
    const knowledgeBlock = formatKnowledgeForPrompt(cleanText + ' ' + place.name, 3);
    
    // Generar respuesta OOC
    const systemPrompt = this.generateOOCSystemPrompt(place, worldBuilding, companions, protagonist, memoryFormatted, knowledgeBlock);
    
    const llmContext: LLMContext = {
      systemPrompt,
      conversationHistory: this.convertHistoryToLLMFormat(session?.conversationHistory || input.conversationHistory || []),
      maxTokens: this.config.maxResponseLength,
      temperature: 0.3,
      topK: this.config.defaultTopK,
    };
    
    this.llm.setCharacterProfile(undefined);
    const llmResponse = this.llm.generate(cleanText, llmContext);
    
    return this.createSuccessOutput({
      text: llmResponse.text,
      responseType: 'analysis',
      speaker: {
        name: 'Sistema OOC',
        role: 'Asistente de Juego',
        type: 'system',
      },
      reasoning: {
        chain: generateReasoningChain(cleanText, llmContext),
        summary: 'Respuesta OOC basada en análisis contextual',
        confidence: llmResponse.confidence,
      },
      semanticAnalysis,
      tokens: llmResponse.tokens.length,
      processingTime: Date.now() - startTime,
      isFallback: false,
    });
  }
  
  /**
   * Procesa una consulta de conocimiento
   */
  private async processKnowledgeQuery(input: NeuralInput, session: NeuralSession | undefined, startTime: number): Promise<NeuralOutput> {
    const cleanText = input.text.trim();
    const domains = input.knowledgeDomains || [];
    
    // Consultar conocimiento
    const entries = retrieveKnowledge(cleanText, domains.length > 0 ? domains : undefined);
    
    // Analizar escena si hay contexto
    let sceneAnalysis = null;
    if (input.place) {
      sceneAnalysis = analyzeSceneWithKnowledge({
        text: cleanText,
        placeName: input.place.name,
        weather: input.place.weather,
        isCombatOrTension: cleanText.toLowerCase().includes('combate') || 
                          cleanText.toLowerCase().includes('peligro') ||
                          cleanText.toLowerCase().includes('amenaza'),
      });
    }
    
    return this.createSuccessOutput({
      text: `Consulta de conocimiento: ${entries.length} entradas encontradas. Dominios: ${Array.from(new Set(entries.map(e => e.domain))).join(', ')}`,
      responseType: 'knowledge_response',
      speaker: {
        name: 'Biblioteca de Conocimiento',
        role: 'Sistema de Conocimiento',
        type: 'system',
      },
      appliedKnowledge: entries,
      narrationInfo: sceneAnalysis ? {
        directorIntent: sceneAnalysis.directorIntent,
        environmentalShift: sceneAnalysis.environmentalShift,
        castReactionsSummary: '',
        narrativeHooks: sceneAnalysis.narrativeHooks,
        isOocDirectAnswer: true,
      } : undefined,
      tokens: cleanText.split(/\s+/).length,
      processingTime: Date.now() - startTime,
      isFallback: false,
    });
  }
  
  /**
   * Procesa consolidación de memoria
   */
  private async processMemoryConsolidation(input: NeuralInput, session: NeuralSession | undefined, startTime: number): Promise<NeuralOutput> {
    const history = input.conversationHistory || session?.conversationHistory || [];
    const memory = input.conversationMemory || session?.conversationMemory || {
      turnCount: 0,
      summary: '',
      keyFacts: [],
      agreementsAndPromises: [],
      unresolvedQuestions: [],
      activeTopics: [],
      characterPerspectives: {},
      narrativeTone: 'Neutral',
    };
    
    const place = input.place || session?.place || { name: 'el escenario' };
    const protagonistName = input.protagonist?.name || input.sender?.name || 'Protagonista';
    const companions = input.companions || [];
    
    // Extraer insights de memoria
    const insights = extractMemoryInsightsOffline({
      dialogueHistory: history.map(h => ({
        speakerName: h.sender,
        text: h.text,
        timestamp: h.timestamp,
      })),
      existingMemory: memory,
      placeName: place.name,
      protagonistName,
    });
    
    // Consolidar memoria
    const consolidatedMemory = mergeMemoryUpdates(memory, {
      turnCount: history.length,
      summary: insights.summary || memory.summary,
      keyFacts: insights.keyFacts || memory.keyFacts,
      agreementsAndPromises: insights.agreementsAndPromises || memory.agreementsAndPromises,
      unresolvedQuestions: insights.unresolvedQuestions || memory.unresolvedQuestions,
      activeTopics: insights.activeTopics || memory.activeTopics,
      characterPerspectives: insights.characterPerspectives || memory.characterPerspectives,
      narrativeTone: insights.narrativeTone || memory.narrativeTone,
    });
    
    // Actualizar sesión
    if (session) {
      session.conversationMemory = consolidatedMemory;
    }
    
    return this.createSuccessOutput({
      text: `Memoria consolidada: ${consolidatedMemory.keyFacts.length} hechos, ${consolidatedMemory.agreementsAndPromises.length} acuerdos, ${consolidatedMemory.unresolvedQuestions.length} preguntas abiertas`,
      responseType: 'memory_update',
      speaker: {
        name: 'Sistema de Memoria',
        role: 'Consolidador de Conocimiento',
        type: 'system',
      },
      memoryUpdate: {
        keyFacts: consolidatedMemory.keyFacts,
        agreementsAndPromises: consolidatedMemory.agreementsAndPromises,
        unresolvedQuestions: consolidatedMemory.unresolvedQuestions,
        narrativeTone: consolidatedMemory.narrativeTone,
        characterPerspectives: consolidatedMemory.characterPerspectives,
      },
      tokens: 0,
      processingTime: Date.now() - startTime,
      isFallback: false,
    });
  }
  
  /**
   * Procesa descripción de escena
   */
  private async processSceneDescription(input: NeuralInput, session: NeuralSession | undefined, startTime: number): Promise<NeuralOutput> {
    const place = input.place || session?.place || { name: 'el escenario' };
    const worldBuilding = input.worldBuilding || session?.worldBuilding || { worldName: 'Elysium', laws: [] };
    
    // Analizar la escena con conocimiento local
    const sceneAnalysis = analyzeSceneWithKnowledge({
      text: input.text,
      placeName: place.name,
      weather: place.weather,
      isCombatOrTension: input.text.toLowerCase().includes('combate') || 
                        input.text.toLowerCase().includes('peligro') ||
                        input.text.toLowerCase().includes('tensión'),
    });
    
    // Formatear conocimiento
    const knowledgeBlock = formatKnowledgeForPrompt(input.text + ' ' + place.name, 5);
    
    return this.createSuccessOutput({
      text: `Análisis de escena: ${place.name} - ${sceneAnalysis.environmentalShift}`,
      responseType: 'analysis',
      speaker: {
        name: 'Analizador de Escena',
        role: 'Sistema de Análisis',
        type: 'system',
      },
      narrationInfo: {
        directorIntent: sceneAnalysis.directorIntent,
        environmentalShift: sceneAnalysis.environmentalShift,
        castReactionsSummary: sceneAnalysis.castReactionsSummary,
        narrativeHooks: sceneAnalysis.narrativeHooks,
        isOocDirectAnswer: true,
      },
      tokens: input.text.split(/\s+/).length,
      processingTime: Date.now() - startTime,
      isFallback: false,
    });
  }
  
  /**
   * Procesa generación de trasfondo (fallback básico)
   */
  private async processBackstoryGeneration(input: NeuralInput, session: NeuralSession | undefined, startTime: number): Promise<NeuralOutput> {
    const character = input.characterProfile || 
      (input.characterSheet ? createUnifiedParticipant(input.characterSheet as any).consciousnessProfile : undefined);
    
    if (!character) {
      return this.createErrorOutput('Se requiere un perfil de personaje para generar el trasfondo');
    }
    
    // Generar trasfondo determinista
    const backstory = this.generateDeterministicBackstory(character, input);
    
    return this.createSuccessOutput({
      text: `Trasfondo generado para ${character.name}: ${backstory.backstory.slice(0, 200)}...`,
      responseType: 'analysis',
      speaker: {
        name: 'Generador de Trasfondo',
        role: 'Sistema de Narrativa',
        type: 'system',
      },
      tokens: backstory.backstory.split(/\s+/).length,
      processingTime: Date.now() - startTime,
      isFallback: true,
      fallbackReason: 'Generación determinista de trasfondo',
    });
  }
  
  /**
   * Procesa generación de línea temporal (fallback básico)
   */
  private async processTimelineGeneration(input: NeuralInput, session: NeuralSession | undefined, startTime: number): Promise<NeuralOutput> {
    const character = input.characterProfile || 
      (input.characterSheet ? createUnifiedParticipant(input.characterSheet as any).consciousnessProfile : undefined);
    
    if (!character) {
      return this.createErrorOutput('Se requiere un perfil de personaje para generar la línea temporal');
    }
    
    // Generar línea temporal determinista
    const timeline = this.generateDeterministicTimeline(character);
    
    return this.createSuccessOutput({
      text: `Línea temporal generada para ${character.name}: ${timeline.overview}`,
      responseType: 'analysis',
      speaker: {
        name: 'Generador de Línea Temporal',
        role: 'Sistema de Narrativa',
        type: 'system',
      },
      tokens: timeline.overview.split(/\s+/).length,
      processingTime: Date.now() - startTime,
      isFallback: true,
      fallbackReason: 'Generación determinista de línea temporal',
    });
  }
  
  /**
   * Procesa comando del sistema
   */
  private async processSystemCommand(input: NeuralInput, session: NeuralSession | undefined, startTime: number): Promise<NeuralOutput> {
    const cleanText = input.text.trim().toLowerCase();
    
    // Procesar comandos específicos
    if (cleanText.includes('reiniciar') || cleanText.includes('reset')) {
      if (session) {
        session.conversationHistory = [];
        session.conversationMemory = {
          turnCount: 0,
          summary: '',
          keyFacts: [],
          agreementsAndPromises: [],
          unresolvedQuestions: [],
          activeTopics: [],
          characterPerspectives: {},
          narrativeTone: 'Neutral',
        };
      }
      return this.createSuccessOutput({
        text: 'Sistema reiniciado: memoria de conversación borrada',
        responseType: 'command_response',
        speaker: { name: 'Sistema', role: 'Administrador', type: 'system' },
        processingTime: Date.now() - startTime,
      });
    }
    
    if (cleanText.includes('estado') || cleanText.includes('status')) {
      const status = this.getSystemStatus();
      return this.createSuccessOutput({
        text: `Estado del sistema: ${status.sessions} sesiones activas, ${status.characters} personajes cargados`,
        responseType: 'command_response',
        speaker: { name: 'Sistema', role: 'Administrador', type: 'system' },
        processingTime: Date.now() - startTime,
      });
    }
    
    return this.createSuccessOutput({
      text: `Comando no reconocido: ${input.text}`,
      responseType: 'command_response',
      speaker: { name: 'Sistema', role: 'Administrador', type: 'system' },
      processingTime: Date.now() - startTime,
    });
  }
  
  // -------------------------------------------------------------------------
  // MÉTODOS AUXILIARES
  // -------------------------------------------------------------------------
  
  /**
   * Crea una salida de éxito
   */
  private createSuccessOutput(data: Partial<NeuralOutput> & { text: string; responseType: NeuralOutput['responseType'] }): NeuralOutput {
    return {
      text: data.text,
      responseType: data.responseType,
      speaker: data.speaker,
      reasoning: data.reasoning,
      semanticAnalysis: data.semanticAnalysis,
      appliedKnowledge: data.appliedKnowledge,
      somaticState: data.somaticState,
      innerMonologue: data.innerMonologue,
      memoryUpdate: data.memoryUpdate,
      cognitiveAppraisal: data.cognitiveAppraisal,
      narrationInfo: data.narrationInfo,
      tokens: data.tokens || 0,
      processingTime: data.processingTime || 0,
      isFallback: data.isFallback || false,
      fallbackReason: data.fallbackReason,
    };
  }
  
  /**
   * Crea una salida de error
   */
  private createErrorOutput(error: string): NeuralOutput {
    return {
      text: `[Error] ${error}`,
      responseType: 'error',
      error,
      tokens: 0,
      processingTime: 0,
      isFallback: true,
      fallbackReason: 'Error de procesamiento',
    };
  }
  
  /**
   * Genera un análisis semántico básico
   */
  private createBasicSemanticAnalysis(text: string): SemanticAnalysisResult {
    const clean = text.trim().toLowerCase();
    
    let intent: SemanticAnalysisResult['intent'] = 'conversational' as any;
    let intensity: SemanticAnalysisResult['intensity'] = 'moderate';
    let emotionalValence: SemanticAnalysisResult['emotionalValence'] = 'neutral';
    
    if (/hola|saludos|buenos/i.test(clean)) {
      intent = 'greeting';
      intensity = 'subtle';
      emotionalValence = 'warm';
    } else if (/combate|peligro|amenaza|ataque/i.test(clean)) {
      intent = 'combat_alert';
      intensity = 'intense';
      emotionalValence = 'tense';
    } else if (/ropa|vestid|prenda|atuendo/i.test(clean)) {
      intent = 'wardrobe_somatic_inquiry';
      intensity = 'moderate';
      emotionalValence = 'analytical';
    } else if (/miedo|temor|ansiedad/i.test(clean)) {
      emotionalValence = 'vulnerable';
    } else if (/ira|rabia|furia/i.test(clean)) {
      emotionalValence = 'tense';
      intensity = 'intense';
    }
    
    return {
      intent,
      intensity,
      proximity: 'conversational',
      subtext: text,
      emotionalValence,
      keyEntities: [],
      isDirectAddress: false,
    };
  }
  
  /**
   * Genera el system prompt para mensajes de usuario
   */
  private generateSystemPromptForUserMessage(input: NeuralInput, characterProfile?: CharacterConsciousnessProfile): string {
    const characterName = characterProfile?.name || input.target?.name || 'el personaje';
    const characterRole = characterProfile?.role || input.target?.role || 'asistente';
    
    let prompt = `Eres ${characterName}, un ${characterRole}.`;
    
    if (characterProfile) {
      prompt += `\n\nCaracterísticas:\n`;
      prompt += `- Personalidad: ${characterProfile.personality || 'equilibrada'}\n`;
      prompt += `- Motivación principal: ${characterProfile.motivations?.[0] || 'ayudar al usuario'}\n`;
      prompt += `- Valores: ${characterProfile.coreValues || 'honor y lealtad'}\n`;
      prompt += `- Mayor temor: ${characterProfile.greatestFear || 'la derrota'}\n`;
      prompt += `- Arquetipo: ${characterProfile.archetype || 'neutral'}\n`;
    }
    
    prompt += `\n\nInstrucciones:\n`;
    prompt += `- Responde de manera coherente con tu personalidad y contexto.\n`;
    prompt += `- Usa el análisis semántico para adaptar tu respuesta.\n`;
    prompt += `- Sé detallado y descriptivo en tus respuestas.\n`;
    prompt += `- Mantén la coherencia narrativa en todo momento.\n`;
    
    return prompt;
  }
  
  /**
   * Genera el system prompt para consultas OOC
   */
  private generateOOCSystemPrompt(
    place: NeuralInput['place'],
    worldBuilding: NeuralInput['worldBuilding'],
    companions: UnifiedParticipant[],
    protagonist: UnifiedParticipant | undefined,
    memoryFormatted: string,
    knowledgeBlock: string
  ): string {
    const placeName = place?.name || 'el escenario';
    const zoneName = place?.zoneName || 'zona principal';
    const weather = place?.weather || 'clima templado';
    const hour = place?.hour || 'atardecer';
    const worldName = worldBuilding?.worldName || 'Elysium';
    const worldLaws = worldBuilding?.laws?.join('; ') || 'leyes físicas estándar';
    
    const companionNames = companions.map(c => c.name).join(', ') || 'ninguno';
    const protagonistName = protagonist?.name || 'el protagonista';
    
    return `Eres el Sistema OOC (Out of Character), el narrador omnisciente y director de juego.

Contexto actual:
- Mundo: ${worldName}
- Escenario: ${placeName} (${zoneName})
- Clima: ${weather}, Hora: ${hour}
- Leyes del mundo: ${worldLaws}
- Protagonista: ${protagonistName}
- Compañeros presentes: ${companionNames}

Memoria de conversación:
${memoryFormatted}

Conocimiento ontológico:
${knowledgeBlock}

Instrucciones:
- Responde consultas OOC con claridad y profundidad.
- Proporciona información objetiva sobre el mundo, el escenario y los personajes.
- Mantén la coherencia con la memoria de conversación y el conocimiento ontológico.
- Sé creativo pero preciso en tus descripciones.
- Responde en español, con estilo literario y cinematográfico.`;
  }
  
  /**
   * Convierte el historial a formato LLM
   */
  private convertHistoryToLLMFormat(history: NeuralInput['conversationHistory']): LLMContext['conversationHistory'] {
    return (history || []).map(h => ({
      role: h.sender === 'user' || h.sender === 'Protagonista' ? 'user' : 'assistant',
      content: h.text,
    }));
  }
  
  /**
   * Recupera conocimiento contextual
   */
  private retrieveContextualKnowledge(query: string, domains?: string[]): KnowledgeEntry[] {
    const cacheKey = `${query}:${domains?.join(',') || 'all'}`;
    
    if (this.knowledgeCache.has(cacheKey)) {
      return this.knowledgeCache.get(cacheKey)!;
    }
    
    const entries = retrieveKnowledge(query, domains);
    this.knowledgeCache.set(cacheKey, entries);
    return entries;
  }
  
  /**
   * Procesa la respuesta después de la generación
   */
  private postProcessResponse(text: string, characterProfile?: CharacterConsciousnessProfile, semanticAnalysis?: SemanticAnalysisResult): string {
    let processed = text;
    
    // Limpiar delimitadores de markdown
    processed = processed.replace(/^```(json|text)?\s*/i, '');
    processed = processed.replace(/\s*```$/i, '');
    
    // Asegurar que termine con puntuación
    if (!/[.!?\u2026]$/.test(processed.trim())) {
      processed += '.';
    }
    
    // Capitalizar primera letra
    processed = processed.charAt(0).toUpperCase() + processed.slice(1);
    
    return processed;
  }
  
  /**
   * Actualiza la memoria de conversación
   */
  private updateConversationMemory(
    session: NeuralSession,
    input: NeuralInput,
    llmResponse: LLMResponse,
    semanticAnalysis: SemanticAnalysisResult
  ): NeuralOutput['memoryUpdate'] {
    const insights = extractMemoryInsightsOffline({
      dialogueHistory: session.conversationHistory.map(h => ({
        speakerName: h.sender,
        text: h.text,
        timestamp: h.timestamp,
      })),
      existingMemory: session.conversationMemory,
      placeName: input.place?.name || session.place.name,
      protagonistName: input.sender?.name || input.target?.name || 'Protagonista',
    });
    
    // Actualizar la sesión
    session.conversationMemory = mergeMemoryUpdates(session.conversationMemory, {
      turnCount: session.conversationHistory.length + 1,
      summary: insights.summary || session.conversationMemory.summary,
      keyFacts: insights.keyFacts || session.conversationMemory.keyFacts,
      agreementsAndPromises: insights.agreementsAndPromises || session.conversationMemory.agreementsAndPromises,
      unresolvedQuestions: insights.unresolvedQuestions || session.conversationMemory.unresolvedQuestions,
      activeTopics: insights.activeTopics || session.conversationMemory.activeTopics,
      characterPerspectives: insights.characterPerspectives || session.conversationMemory.characterPerspectives,
      narrativeTone: insights.narrativeTone || session.conversationMemory.narrativeTone,
    });
    
    // Agregar a historial
    session.conversationHistory.push({
      sender: input.sender?.name || 'Desconocido',
      receiver: input.target?.name,
      text: input.text,
      timestamp: new Date().toISOString(),
      intent: semanticAnalysis.intent,
    });
    
    return {
      keyFacts: session.conversationMemory.keyFacts,
      agreementsAndPromises: session.conversationMemory.agreementsAndPromises,
      unresolvedQuestions: session.conversationMemory.unresolvedQuestions,
      narrativeTone: session.conversationMemory.narrativeTone,
      characterPerspectives: session.conversationMemory.characterPerspectives,
    };
  }
  
  /**
   * Genera un trasfondo determinista
   */
  private generateDeterministicBackstory(character: CharacterConsciousnessProfile, input: NeuralInput): any {
    const race = character.race || 'Humano';
    const role = character.role || 'Aventurero';
    const archetype = character.archetype || 'Neutral';
    const personality = character.personality || 'Equilibrado';
    const motivations = character.motivations?.[0] || 'Buscar la verdad';
    const coreValues = character.coreValues || 'Honor y lealtad';
    const greatestFear = character.greatestFear || 'La traición';
    const name = character.name || 'Personaje';
    
    // Generar elementos únicos basados en el personaje
    const uniqueDetails = [
      `Lleva una marca o cicatriz que testimonia su ${motivations.toLowerCase()}`,
      `Posee un objeto personal que simboliza su compromiso con ${coreValues.toLowerCase()}`,
      `Tiene un ritual o hábito que realiza antes de enfrentarse a su ${greatestFear.toLowerCase()}`,
    ];
    
    // Generar hitos
    const milestones = [
      {
        id: 'm1',
        era: 'Pasado',
        title: 'Orígenes',
        periodOrAge: 'Infancia',
        summary: `Creció en un entorno marcado por los valores de ${race}, desarrollando una personalidad ${personality.toLowerCase()}.`,
        keyEvents: ['Primer contacto con su vocación', 'Formación inicial'],
        psychologicalEvolution: `Adquirió los principios fundamentales de ${coreValues}.`,
      },
      {
        id: 'm2',
        era: 'Pasado',
        title: 'El Despertar',
        periodOrAge: 'Juventud',
        summary: `Un evento crucial lo llevó a abrazar su rol como ${role}, superando sus primeros miedos.`,
        keyEvents: ['Descubrimiento de su propósito', 'Primer gran desafío'],
        psychologicalEvolution: `Fortaleció su determinación y claridad de propósito.`,
      },
      {
        id: 'm3',
        era: 'Presente',
        title: 'La Consolidación',
        periodOrAge: 'Actualidad',
        summary: `Ahora encarna plenamente el arquetipo de ${archetype}, enfrentando desafíos con ${personality.toLowerCase()}.`,
        keyEvents: ['Reconocimiento de sus pares', 'Logro de metas significativas'],
        psychologicalEvolution: `Madurez y equilibrio entre sus valores y miedos.`,
      },
      {
        id: 'm4',
        era: 'Futuro',
        title: 'El Legado',
        periodOrAge: 'Futuro',
        summary: `Su destino está ligado a superar su mayor temor: ${greatestFear}.`,
        keyEvents: ['La prueba definitiva', 'El sacrificio por sus valores'],
        psychologicalEvolution: `Trascendencia y legado para las futuras generaciones.`,
      },
    ];
    
    return {
      name,
      homelandOrDomain: `Reino de ${race}`,
      factionOrFaith: `Orden de los ${role}`,
      backstory: `En las tierras de ${race}, ${name} creció bajo la influencia de valores como ${coreValues}. Desde joven, mostró una personalidad marcada por ${personality.toLowerCase()}, lo que lo llevó a abrazar su vocación como ${role}. Su mayor motivación, ${motivations}, lo ha guiado a través de numerosas pruebas, incluyendo el enfrentamiento con su temor más profundo: ${greatestFear}. Hoy, como ${archetype}, continua su camino con determinación y propósito.`,
      motivation: `Superar sus límites y honrar sus valores de ${coreValues}.`,
      secret: `Oculta una verdad que podría cambiar el equilibrio de poder en su entorno.`,
      uniqueDetails,
      timeline: {
        overview: `La vida de ${name} es un viaje de autodescubrimiento y superación.`,
        thematicArc: `De la duda a la certeza, de la debilidad a la fortaleza.`,
        pivotalTurningPoints: ['El descubrimiento de su vocación', 'El enfrentamiento con su mayor temor'],
        milestones,
      },
    };
  }
  
  /**
   * Genera una línea temporal determinista
   */
  private generateDeterministicTimeline(character: CharacterConsciousnessProfile): any {
    const name = character.name || 'Personaje';
    const race = character.race || 'Humano';
    const role = character.role || 'Aventurero';
    const archetype = character.archetype || 'Neutral';
    
    return {
      overview: `La trayectoria de ${name}, un ${race} ${role}, es un testimonio de evolución constante y adaptación a los desafíos del mundo de Elysium.`,
      thematicArc: `De la incertidumbre al dominio, de la búsqueda a la realizacion.`,
      pivotalTurningPoints: [
        `El momento en que descubrió su verdadera vocación como ${role}`,
        `El enfrentamiento que definió su carácter como ${archetype}`,
        `La decisión que lo llevó a abrazar sus valores fundamentales`,
      ],
      milestones: [
        {
          era: 'Pasado',
          title: 'Los Primeros Años',
          periodOrAge: 'Infancia (0-12 años)',
          summary: `Crianza en un entorno marcado por las tradiciones de los ${race}.`,
          keyEvents: ['Primeros contactos con el mundo exterior', 'Formación de su carácter base'],
          psychologicalEvolution: 'Desarrollo de una mentalidad curiosa y resiliente.',
          roleAndAppearanceNote: 'Vestimenta simple, adecuada para su edad.',
          linkedVariantName: `${name} (Niño)`,
        },
        {
          era: 'Pasado',
          title: 'El Llamado',
          periodOrAge: 'Juventud (13-20 años)',
          summary: `El descubrimiento de su vocación como ${role} marcó un punto de inflexión.`,
          keyEvents: ['Primer entrenamiento formal', 'Encuentro con su mentor'],
          psychologicalEvolution: 'Madurez inicial y aceptación de su destino.',
          roleAndAppearanceNote: 'Atuendo de aprendiz, funcional y práctico.',
          linkedVariantName: `${name} (Aprendiz)`,
        },
        {
          era: 'Presente',
          title: 'La Cúspide',
          periodOrAge: 'Adultez (21-40 años)',
          summary: `Ahora en la cima de sus habilidades, ${name} encarna el arquetipo de ${archetype}.`,
          keyEvents: ['Reconocimiento como maestro', 'Liderazgo de su propia facción'],
          psychologicalEvolution: 'Equilibrio entre experiencia y sabiduría.',
          roleAndAppearanceNote: 'Vestimenta distintiva de ${role}, con elementos que reflejan su estatus.',
          linkedVariantName: `${name} (Maestro)`,
        },
        {
          era: 'Futuro',
          title: 'El Legado',
          periodOrAge: 'Vejes (40+ años)',
          summary: `Su legado perdurará como inspiración para futuras generaciones.`,
          keyEvents: ['Transmisión de conocimiento', 'Última gran hazaña'],
          psychologicalEvolution: 'Sabiduría y aceptación de su lugar en el mundo.',
          roleAndAppearanceNote: 'Atuendo ceremonial, símbolo de su trayectoria.',
          linkedVariantName: `${name} (Leyenda)`,
        },
      ],
    };
  }
  
  /**
   * Obtiene el estado del sistema
   */
  private getSystemStatus(): { sessions: number; characters: number; uptime: number } {
    let characterCount = 0;
    this.sessions.forEach(session => {
      characterCount += session.activeCharacters.size;
    });
    
    return {
      sessions: this.sessions.size,
      characters: characterCount,
      uptime: Date.now() - this.initializationTime.getTime(),
    };
  }
  
  // -------------------------------------------------------------------------
  // MÉTODOS ESTÁTICOS DE UTILIDAD
  // -------------------------------------------------------------------------
  
  /**
   * Crea una instancia preconfigurada para rolplay
   */
  static createForRoleplay(config?: Partial<NeuralConfig>): ElysiumNeural {
    return new ElysiumNeural({
      ...config,
      enableAllFeatures: true,
      enableAdvancedReasoning: true,
      enableMemorySystem: true,
      enablePersonalitySystem: true,
      enableSomaticSystem: true,
      enableKnowledgeSystem: true,
    });
  }
  
  /**
   * Crea una instancia mínima (sin características avanzadas)
   */
  static createMinimal(config?: Partial<NeuralConfig>): ElysiumNeural {
    return new ElysiumNeural({
      ...config,
      enableAllFeatures: false,
      enableAdvancedReasoning: false,
      enableMemorySystem: false,
      enablePersonalitySystem: false,
      enableSomaticSystem: false,
      enableKnowledgeSystem: false,
    });
  }
  
  /**
   * Procesa una entrada simple sin sesión
   */
  static async processSimpleInput(text: string, characterProfile?: CharacterConsciousnessProfile): Promise<NeuralOutput> {
    const neural = ElysiumNeural.createForRoleplay();
    return neural.processInput({
      type: 'user_message',
      text,
      characterProfile,
    });
  }
}

// -------------------------------------------------------------------------
// EXPORTS ADICIONALES
// -------------------------------------------------------------------------

export { LocalLLM, LLMContext, LLMResponse, LLMConfig, DEFAULT_LLM_CONFIG };
export { analyzeSemanticSubtext, SemanticAnalysisResult, CognitiveAppraisal, SomatosensoryState };
export { CharacterConsciousnessProfile, ConsciousResponse };
export { ConversationMemory };
export { KnowledgeEntry, KNOWLEDGE_CORPUS };

// Exportar instancia singleton para uso rápido
export const elysiumNeural = ElysiumNeural.createForRoleplay();
