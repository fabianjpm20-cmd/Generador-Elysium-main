import { CharacterState, WorldPlace, WorldBuildingConfig } from '../types';
import type { UnifiedParticipant } from './characterLogicEngine';
import {
  characterStateToUnifiedParticipant,
  syncParticipantToCharacterState
} from './characterLogicEngine';
import type { AgentLogicalMemory } from './autonomousAgentEngine';
import type { EnhancedConversationMemory } from './conversationMemoryEngine';
import { createInitialConversationMemory } from './conversationMemoryEngine';

export type { UnifiedParticipant, AgentLogicalMemory, EnhancedConversationMemory };
export {
  characterStateToUnifiedParticipant,
  syncParticipantToCharacterState,
  createInitialConversationMemory
};

export interface InteractionSessionState {
  id: string;
  title: string;
  subtitle: string;
  savedAt: string;
  phase: 'phase0_sessions' | 'phase1_config' | 'phase2_chat' | 'phase2_map' | 'phase3_dialogue';
  protagonist: UnifiedParticipant;
  npc: UnifiedParticipant;
  secondaryAgents?: UnifiedParticipant[];
  companionAgents?: UnifiedParticipant[];
  isOfflineMode?: boolean; // Modo Offline activo (usa lógica y terminales autónomos locales)
  companionMemories?: Record<string, AgentLogicalMemory>; // Memoria y estado psicológico independiente por cada agente
  worldBuilding?: {
    id?: string;
    worldName?: string;
    laws?: string[];
    summary?: string;
  };
  place: {
    id: string;
    name: string;
    zoneName: string;
    initialCoords: { x: number; y: number };
    weather: string;
    hour: string;
    details: string;
  };
  config: {
    npcDensity: 'Ninguno' | 'Pocos' | 'Moderados' | 'Multitud';
    storyTone: 'Romance' | 'R+18' | 'Aventura' | 'Guerra / Política';
    battleEnabled: boolean;
  };
  conversationMemory?: EnhancedConversationMemory;
  mapState?: {
    playerPos: { x: number; y: number };
    npcPos: { x: number; y: number };
    objects: Array<{
      id: string;
      name: string;
      type: 'door' | 'chest' | 'inspectable' | 'water';
      x: number;
      y: number;
      isOpened?: boolean;
      description: string;
    }>;
  };
  eventLogs: Array<{
    id: string;
    timestamp: string;
    coords?: { x: number; y: number };
    category: 'MOVIMIENTO' | 'ENTORNO' | 'NPC' | 'MUNDO' | 'COMBATE' | 'ACCIÓN' | 'OOC';
    title: string;
    text: string;
  }>;
  dialogueHistory: Array<{
    id: string;
    speaker: 'protagonist' | 'npc' | 'agent' | 'narrator' | 'system';
    speakerName: string;
    speakerId?: string;
    text: string;
    timestamp?: string;
    oocNote?: string;
    rollDetail?: string;
    innerMonologue?: string;
    somaticObservation?: string;
    cognitiveTrace?: {
      intentRecognized?: string;
      selfAwarenessPoint?: string;
      relationalAssessment?: string;
      environmentalTrigger?: string;
    };
    narratorAnalysis?: {
      directorIntent?: string;
      environmentalShift?: string;
      castReactionsSummary?: string;
      narrativeHooks?: string[];
      isOocDirectAnswer?: boolean;
    };
  }>;
}

// ----------------------------------------------------
// FÓRMULAS DE ATRIBUTOS Y ESTADÍSTICAS DERIVADAS
// Conforme a los documentos:
// PV = (CON * 10) + (FUE * 2) + bonos_raza + bonos_rol
// PEP = CEP * (EFC / 100)
// CA = 10 + (DES // 2) + bonos_armadura + bonos_raza + bonos_rol
// Modificador = (Atributo - 10) // 2
// ----------------------------------------------------

export function calculateAttributeModifier(attrVal: number): number {
  return Math.floor((attrVal - 10) / 2);
}

export function calculateDerivedStats(
  attributes: { FUE: number; DES: number; CON: number; INT: number; SAB: number; CAR: number },
  raceName: string = 'Humano',
  roleName: string = 'Estratega'
) {
  let bonosRaza = { PV: 0, CA: 0, Vel: 30, CEP: 15, EFC: 35, RR: 50 };
  const rLower = raceName.toLowerCase();
  if (rLower.includes('elf')) {
    bonosRaza = { PV: 10, CA: 0, Vel: 35, CEP: 120, EFC: 65, RR: 60 };
  } else if (rLower.includes('enano')) {
    bonosRaza = { PV: 0, CA: 0, Vel: 25, CEP: 80, EFC: 60, RR: 70 };
  } else if (rLower.includes('orco') || rLower.includes('oni') || rLower.includes('troll')) {
    bonosRaza = { PV: 0, CA: 1, Vel: 30, CEP: 60, EFC: 45, RR: 50 };
  } else if (rLower.includes('bovinae')) {
    bonosRaza = { PV: 20, CA: 0, Vel: 35, CEP: 80, EFC: 50, RR: 60 };
  } else if (rLower.includes('demonio') || rLower.includes('ángel')) {
    bonosRaza = { PV: 0, CA: 0, Vel: 35, CEP: 400, EFC: 85, RR: 80 };
  }

  let bonosRol = { PV: 0, CA: 0, Vel: 0, Ini: 0, RR: 0, CEP: 0, EFC: 0 };
  const roLower = roleName.toLowerCase();
  if (roLower.includes('berserker')) {
    bonosRol = { PV: 20, CA: -1, Vel: 0, Ini: 0, RR: 10, CEP: 0, EFC: 0 };
  } else if (roLower.includes('caballero de placas') || roLower.includes('paladín')) {
    bonosRol = { PV: 15, CA: 4, Vel: -5, Ini: 0, RR: 5, CEP: 0, EFC: 0 };
  } else if (roLower.includes('duelista')) {
    bonosRol = { PV: 5, CA: 2, Vel: 0, Ini: 2, RR: 0, CEP: 0, EFC: 0 };
  } else if (roLower.includes('guardián de escudo')) {
    bonosRol = { PV: 20, CA: 3, Vel: -3, Ini: 0, RR: 10, CEP: 0, EFC: 0 };
  } else if (roLower.includes('hechicero') || roLower.includes('mago')) {
    bonosRol = { PV: -5, CA: 0, Vel: 0, Ini: 0, RR: 5, CEP: 30, EFC: 20 };
  } else if (roLower.includes('pícaro') || roLower.includes('sombra')) {
    bonosRol = { PV: 0, CA: 1, Vel: 2, Ini: 3, RR: 0, CEP: 5, EFC: 5 };
  }

  const pv = (attributes.CON * 10) + (attributes.FUE * 2) + bonosRaza.PV + bonosRol.PV;
  const cep = bonosRaza.CEP + bonosRol.CEP;
  const efc = bonosRaza.EFC + bonosRol.EFC;
  const pep = Math.max(5, Math.round(cep * (efc / 100)));
  const ca = 10 + Math.floor(attributes.DES / 2) + bonosRaza.CA + bonosRol.CA;
  const ini = attributes.DES + bonosRol.Ini;
  const vel = bonosRaza.Vel + bonosRol.Vel;
  const rr = bonosRaza.RR + bonosRol.RR;

  return {
    PV: pv,
    maxPV: pv,
    PEP: pep,
    maxPEP: pep,
    CA: ca,
    iniciativa: ini,
    velocidad: vel,
    CEP: cep,
    EFC: efc,
    RR: rr,
    XP: 250
  };
}

// ----------------------------------------------------
// DADOS D20 Y RESOLUCIÓN DE ACCIONES (tiradas.py)
// ----------------------------------------------------

export interface DiceRollResult {
  d20: number;
  modifier: number;
  total: number;
  dc: number;
  isSuccess: boolean;
  isCritical: boolean;
  statusText: 'ÉXITO' | 'FALLO' | 'ÉXITO CRÍTICO' | 'FALLO CRÍTICO';
}

export function performD20Check(attributeValue: number, dc: number = 14): DiceRollResult {
  const d20 = Math.floor(Math.random() * 20) + 1;
  const modifier = calculateAttributeModifier(attributeValue);
  const total = d20 + modifier;
  const isCritical = d20 === 20;
  const isCriticalFail = d20 === 1;
  const isSuccess = isCritical || (!isCriticalFail && total >= dc);

  let statusText: DiceRollResult['statusText'] = isSuccess ? 'ÉXITO' : 'FALLO';
  if (isCritical) statusText = 'ÉXITO CRÍTICO';
  if (isCriticalFail) statusText = 'FALLO CRÍTICO';

  return {
    d20,
    modifier,
    total,
    dc,
    isSuccess,
    isCritical,
    statusText
  };
}

// ----------------------------------------------------
// MOTOR DE INTERPRETACIÓN NARRATIVA CON FÍSICA CINEMÁTICA
// Ripple Effect, Lag, Centro de Gravedad y Ropa
// ----------------------------------------------------

export interface FreeTextProcessingResult {
  isOoc: boolean;
  oocInstruction?: string;
  actionCategory: 'DIÁLOGO' | 'ACCIÓN' | 'MOVIMIENTO' | 'INTENCIÓN' | 'EXAMINAR' | 'OOC' | 'COMBATE';
  targetElement?: string;
  rollResult?: DiceRollResult;
  systemNarrative: string;
  npcSpeech: string;
  npcEmotionDelta: {
    emotion?: string;
    confidenceDelta: number;
    affinityDelta: number;
    resistanceDelta: number;
    arousalDelta?: number;
  };
  eventLogTitle: string;
  eventLogCategory: 'MOVIMIENTO' | 'ENTORNO' | 'NPC' | 'MUNDO' | 'COMBATE' | 'ACCIÓN';
}

export function interpretFreeText(
  rawText: string,
  session: InteractionSessionState
): FreeTextProcessingResult {
  const text = rawText.trim();
  const lower = text.toLowerCase();
  const protagonistName = session.protagonist.name;
  const npcName = session.npc.name;

  // 1. Detección de OOC (Out of Character)
  if (lower.startsWith('ooc:') || lower.startsWith('(ooc')) {
    const cleanOoc = text.replace(/^(ooc:?|\(ooc:?)/i, '').replace(/\)$/, '').trim();
    return {
      isOoc: true,
      oocInstruction: cleanOoc,
      actionCategory: 'OOC',
      systemNarrative: `*Directriz de dirección narrativa asimilada por el sistema:* «${cleanOoc}». Las próximas reacciones y atmósfera se ajustarán a esta pauta sin alterar las acciones del protagonista.`,
      npcSpeech: `*El narrador sincroniza el compás dramático respetando tu directriz OOC.*`,
      npcEmotionDelta: { confidenceDelta: 0, affinityDelta: 0, resistanceDelta: 0 },
      eventLogTitle: 'Directriz OOC',
      eventLogCategory: 'ENTORNO'
    };
  }

  // 2. Intención de acción física con atributos (ej: forzar, saltar, escabullirse, analizar, persuadir)
  if (lower.includes('fuerza') || lower.includes('forzar') || lower.includes('empujar') || lower.includes('romper')) {
    const roll = performD20Check(session.protagonist.attributes.FUE, 15);
    const success = roll.isSuccess;
    return {
      isOoc: false,
      actionCategory: 'ACCIÓN',
      targetElement: 'Entorno / Mecanismo',
      rollResult: roll,
      systemNarrative: success
        ? `${protagonistName} afianza las plantas de los pies sobre el pavimento de mármol, transfiriendo el peso a través de la cadera y el torso hacia los brazos con un impulso sólido. Con un crujido de bisagras vencidas por la inercia, la estructura cede. La tela de su vestimenta se tensa y reajusta con el retroceso del movimiento.`
        : `${protagonistName} aplica una palanca frontal buscando vencer el cerrojo, pero la resistencia del metal amortigua el esfuerzo sin abrirse. El rebote cinético obliga a reacomodar el centro de gravedad para evitar perder el equilibrio.`,
      npcSpeech: success
        ? `«Impresionante demostración de fuerza bruta... No cualquiera logra hacer ceder un cerrojo templado con tanta soltura.»`
        : `«Ten cuidado con forzarlo así. El metal antiguo no cede ante la prisa; requiere técnica o una llave adecuada.»`,
      npcEmotionDelta: {
        emotion: success ? 'Impresionado' : 'Vigilante',
        confidenceDelta: success ? 3 : 0,
        affinityDelta: success ? 2 : -1,
        resistanceDelta: -2
      },
      eventLogTitle: `Prueba de FUE [${roll.statusText}: ${roll.total} vs DC ${roll.dc}]`,
      eventLogCategory: 'ACCIÓN'
    };
  }

  if (lower.includes('persuadir') || lower.includes('convencer') || lower.includes('negociar') || lower.includes('proponer')) {
    const roll = performD20Check(session.protagonist.attributes.CAR, 13);
    const success = roll.isSuccess;
    return {
      isOoc: false,
      actionCategory: 'INTENCIÓN',
      targetElement: npcName,
      rollResult: roll,
      systemNarrative: `${protagonistName} modula el tono con serenidad, manteniendo el contacto visual y adoptando una postura abierta sin tensión muscular. El peso reposa equilibrado mientras sus palabras buscan resonar con las prioridades de ${npcName}.`,
      npcSpeech: success
        ? `*${npcName} exhala lentamente, relajando los hombros mientras la tela de su atuendo cae con naturalidad.* «Tienes un argumento convincente. Acepto considerar tus términos si garantizas reciprocidad.»`
        : `*${npcName} entrecierra la mirada con escepticismo, ladeando ligeramente el rostro.* «Tus palabras suenan seductoras, pero en este lugar las promesas vacías se pagan caras. Necesitaré más garantías.»`,
      npcEmotionDelta: {
        emotion: success ? 'Complacido' : 'Cauteloso',
        confidenceDelta: success ? 5 : 1,
        affinityDelta: success ? 4 : 0,
        resistanceDelta: success ? -6 : 1
      },
      eventLogTitle: `Persuasión [CAR: ${roll.statusText} ${roll.total} vs DC ${roll.dc}]`,
      eventLogCategory: 'NPC'
    };
  }

  // 3. Intención de combate o desenfundar arma
  if (lower.includes('atacar') || lower.includes('golpear') || lower.includes('espada') || lower.includes('arma') || lower.includes('combate')) {
    const roll = performD20Check(session.protagonist.attributes.DES, 14);
    return {
      isOoc: false,
      actionCategory: 'COMBATE',
      targetElement: npcName,
      rollResult: roll,
      systemNarrative: `${protagonistName} cambia de guardia bajando el centro de gravedad, desplazando la masa del torso en un arco rápido que desgarra el aire. El cabello y los pliegues de la capa ondean por el brusco frenado inercial.`,
      npcSpeech: `*${npcName} da un paso atrás amortiguando la inercia sobre el talón, llevando la mano al cinto con reflejos felinos.* «¿Prefieres que resolvamos esto por las armas? Mide tus movimientos antes de lamentarlo.»`,
      npcEmotionDelta: {
        emotion: 'Alerta Hostil',
        confidenceDelta: -2,
        affinityDelta: -5,
        resistanceDelta: 8
      },
      eventLogTitle: `Maniobra de Combate [DES: ${roll.statusText} ${roll.total}]`,
      eventLogCategory: 'COMBATE'
    };
  }

  // 4. Diálogo o interacción conversacional libre
  return {
    isOoc: false,
    actionCategory: 'DIÁLOGO',
    targetElement: npcName,
    systemNarrative: `${protagonistName} habla con determinación. El eco de sus palabras vibra con nitidez en el aire del recinto, mientras las sombras de las columnas se alargan al compás del viento.`,
    npcSpeech: `*${npcName} sostiene tu mirada, percibiendo el matiz de tus palabras mientras sus facciones se distienden sutilmente.* «Escucho con atención cada una de tus palabras. En un lugar como este, la franqueza es una joya escasa.»`,
    npcEmotionDelta: {
      emotion: 'Atento y Receptivo',
      confidenceDelta: 2,
      affinityDelta: 3,
      resistanceDelta: -2,
      arousalDelta: 1
    },
    eventLogTitle: `Intercambio de Diálogo`,
    eventLogCategory: 'NPC'
  };
}

// ----------------------------------------------------
// PRESETS CANÓNICOS DE SESIÓN (FASE 0)
// Exactamente coincidentes con el wireframe de FASE 0
// ----------------------------------------------------

export function getInitialSavedSessions(): InteractionSessionState[] {
  const defaultProtagonist: UnifiedParticipant = {
    name: 'Xander Vaelith',
    title: 'Ficha del Usuario',
    role: 'Estratega de Élite',
    race: 'Humano',
    gender: 'Masculino',
    faction: 'Orden de la Balanza Astral',
    moralAlignment: 'Devoto Protector',
    allegianceFactionId: 'Orden de la Balanza Astral',
    greatestFear: 'El fracaso táctico que condene a sus compañeros',
    motivations: ['Salvaguardar el equilibrio de los reinos', 'Desentrañar los códices del Pneuma'],
    coreValues: 'Honor, Deber, Verdad y Disciplina',
    interactionRole: 'Estratega Táctico & Mediador',
    personality: 'Sereno, calculador, observador y leal a sus principios.',
    personalityTraits: ['Pragmático', 'Vigilante', 'Noble'],
    hp: 216,
    maxHp: 216,
    sp: 120,
    maxSp: 120,
    attack: 34,
    defense: 28,
    agility: 30,
    specialSkillName: 'Tajo Espejado de la Balanza',
    specialSkillDescription: 'Ejecuta un contragolpe coordinado que desvía el impacto rival y restituye pneuma.',
    skills: ['Tajo Espejado', 'Evaluación Táctica', 'Foco Inquebrantable'],
    armorDescription: 'Coraza de Acero Adamantino con remates de zafiro',
    weapons: ['Hoja Damasquina', 'Daga de Parada'],
    inventory: ['Hoja Damasquina', 'Poción de Vigor', 'Mapa Cartográfico del Oasis'],
    attributes: { FUE: 18, DES: 14, CON: 16, INT: 14, SAB: 14, CAR: 14 },
    derived: {
      PV: 216,
      maxPV: 216,
      PEP: 12,
      maxPEP: 12,
      CA: 17,
      iniciativa: 14,
      velocidad: 30,
      CEP: 25,
      EFC: 45,
      RR: 65,
      XP: 450,
      nivel: 1
    },
    confidence: 100,
    affinity: 100,
    resistance: 0,
    arousal: 0,
    emotionalState: 'Enfocado & Determinado',
    isHostile: false
  };

  const preset1: InteractionSessionState = {
    id: 'session-palacio-oasis',
    title: 'Palacio del Oasis',
    subtitle: 'Valentín Montclair · Punto de guardado: patio',
    savedAt: 'Reciente',
    phase: 'phase2_map',
    protagonist: { ...defaultProtagonist },
    npc: {
      id: 'npc-valentin',
      name: 'Valentín Montclair',
      title: 'Noble Diplomático & Agente Lite',
      role: 'Noble Diplomático & Agente Lite',
      race: 'Humano',
      gender: 'Masculino',
      faction: 'Casa Montclair del Oasis',
      moralAlignment: 'Neutral Bondadoso',
      allegianceFactionId: 'Casa Montclair del Oasis',
      greatestFear: 'La ruina de su casa noble y la pérdida de prestigio cortesano',
      motivations: ['Establecer alianzas estratégicas', 'Preservar la paz en el Oasis'],
      coreValues: 'Diplomacia, Elegancia, Tradición y Hospitalidad',
      interactionRole: 'Diplomático & Consejero',
      personality: 'Refinado, analítico, complaciente pero con astucia cortesana.',
      personalityTraits: ['Elocuente', 'Astuto', 'Galante'],
      dialogueExcerpt: '«Parece que has encontrado algo interesante en este patio.»',
      emotionalState: 'Complacido',
      confidence: 64,
      affinity: 78,
      resistance: 22,
      arousal: 14,
      hp: 140,
      maxHp: 140,
      sp: 90,
      maxSp: 90,
      attack: 26,
      defense: 24,
      agility: 32,
      specialSkillName: 'Danza del Velo Astral',
      specialSkillDescription: 'Maniobra defensiva cortesana que confunde al oponente y reduce su resistencia.',
      skills: ['Danza del Velo Astral', 'Etiqueta Aristocrática', 'Puntada Quirúrgica'],
      armorDescription: 'Jubón de seda reforzada con mallas de plata',
      weapons: ['Estoque de Gala con pomo enjoyado'],
      inventory: ['Sello de Cera Montclair', 'Perfume de Jazmín', 'Bolsa de Florines'],
      attributes: { FUE: 12, DES: 16, CON: 13, INT: 16, SAB: 14, CAR: 18 },
      derived: {
        PV: 140,
        maxPV: 140,
        PEP: 9,
        maxPEP: 9,
        CA: 15,
        iniciativa: 16,
        velocidad: 30,
        CEP: 20,
        EFC: 45,
        RR: 50,
        XP: 200,
        nivel: 1
      },
      isHostile: false
    },
    place: {
      id: 'place-oasis',
      name: 'Palacio del Oasis',
      zoneName: 'Patio de los Pavos Reales',
      initialCoords: { x: 8, y: 14 },
      weather: 'Cálido, brisa de jazmín',
      hour: '17:40 - Atardecer Dorado',
      details: 'Patios con fuentes de agua turquesa, losas de mármol pulido y columnas talladas.'
    },
    config: {
      npcDensity: 'Moderados',
      storyTone: 'Aventura',
      battleEnabled: false
    },
    mapState: {
      playerPos: { x: 8, y: 14 },
      npcPos: { x: 9, y: 14 },
      objects: [
        { id: 'obj-door-1', name: 'Puerta Principal del Patio', type: 'door', x: 5, y: 12, isOpened: false, description: 'Puerta de cedro con herrajes dorados cerrada con llave ceremonial.' },
        { id: 'obj-fountain', name: 'Fuente de Mármol', type: 'water', x: 7, y: 14, description: 'Agua cristalina que refleja la luz del sol poniente.' },
        { id: 'obj-chest-1', name: 'Arcón de Viajero', type: 'chest', x: 10, y: 16, isOpened: false, description: 'Cofre con refuerzos de bronce que parece contener suministros.' }
      ]
    },
    eventLogs: [
      { id: 'ev-1', timestamp: '17:35', coords: { x: 8, y: 14 }, category: 'MOVIMIENTO', title: 'Llegaste al patio.', text: 'Avanzaste por la arcada oeste hasta detenerte frente a la fuente.' },
      { id: 'ev-2', timestamp: '17:36', category: 'ENTORNO', title: 'Puerta cerrada.', text: 'El acceso a las cámaras residenciales permanece sellado con cerrojo grabado.' },
      { id: 'ev-3', timestamp: '17:37', category: 'NPC', title: 'Valentín está aquí.', text: 'Observa tus pasos con una leve sonrisa y las manos descansando en el cinto.' },
      { id: 'ev-4', timestamp: '17:38', category: 'MUNDO', title: 'Mercaderes pasan.', text: 'El bullicio de las caravanas que llegan del desierto resuena amortiguado tras los muros.' }
    ],
    dialogueHistory: [
      {
        id: 'dlg-1',
        speaker: 'npc',
        speakerName: 'Valentín Montclair',
        text: '«Parece que has encontrado algo interesante en este patio.»'
      }
    ]
  };

  const preset2: InteractionSessionState = {
    id: 'session-distrito-mercaderes',
    title: 'Distrito de Mercaderes',
    subtitle: '3 NPC activos · Aventura política',
    savedAt: 'Ayer',
    phase: 'phase2_map',
    protagonist: { ...defaultProtagonist, name: 'Comandante Vaelith' },
    npc: {
      id: 'npc-bazar',
      name: 'Nadim El-Zahra',
      title: 'Tesorero del Gremio Mercantil',
      role: 'Tesorero del Gremio Mercantil',
      race: 'Humano',
      gender: 'Masculino',
      faction: 'Gremio Mercantil del Gran Zoco',
      moralAlignment: 'Neutral Ambicioso',
      allegianceFactionId: 'Gremio Mercantil del Gran Zoco',
      greatestFear: 'La bancarrota y ser traicionado por contrabandistas rivales',
      motivations: ['Monopolizar las rutas caravaneras', 'Acumular reliquias del desierto'],
      coreValues: 'Pragmatismo, Negociación, Riqueza y Discreción',
      interactionRole: 'Comerciante & Tasador',
      personality: 'Calculador, pragmático y sumamente observador.',
      personalityTraits: ['Perspicaz', 'Pragmático', 'Negociador'],
      dialogueExcerpt: '«En este zoco, cada secreto tiene su precio en moneda o sangre.»',
      emotionalState: 'Neutral',
      confidence: 45,
      affinity: 50,
      resistance: 40,
      arousal: 5,
      hp: 120,
      maxHp: 120,
      sp: 70,
      maxSp: 70,
      attack: 30,
      defense: 20,
      agility: 26,
      specialSkillName: 'Balanza de la Fortuna',
      specialSkillDescription: 'Ciega temporalmente con polvo dorado reduciendo la precisión enemiga.',
      skills: ['Negociación Maestra', 'Ojo para el Contrabando', 'Disparo de Cimitarra'],
      armorDescription: 'Túnica de lino grueso con refuerzos de placas de latón',
      weapons: ['Cimitarra de Mercader', 'Daga Oculta'],
      inventory: ['Balanza de Precisión', 'Monedas de Oro', 'Libro Mayor Contable'],
      attributes: { FUE: 14, DES: 14, CON: 14, INT: 16, SAB: 14, CAR: 14 },
      derived: {
        PV: 120,
        maxPV: 120,
        PEP: 7,
        maxPEP: 7,
        CA: 14,
        iniciativa: 14,
        velocidad: 30,
        CEP: 15,
        EFC: 40,
        RR: 45,
        XP: 180,
        nivel: 1
      },
      isHostile: false
    },
    place: {
      id: 'place-mercaderes',
      name: 'Distrito de Mercaderes',
      zoneName: 'Plaza del Gran Zoco',
      initialCoords: { x: 4, y: 6 },
      weather: 'Seco y ventoso con polvo fino',
      hour: '12:15 - Mediodía ardiente',
      details: 'Puestos de telas, especias exóticas, dromedarios y guardias armados con cimitarras.'
    },
    config: {
      npcDensity: 'Multitud',
      storyTone: 'Guerra / Política',
      battleEnabled: true
    },
    mapState: {
      playerPos: { x: 4, y: 6 },
      npcPos: { x: 5, y: 6 },
      objects: [
        { id: 'obj-stall', name: 'Puesto de Especias', type: 'inspectable', x: 3, y: 5, description: 'Montículos de azafrán, canela y sales alquímicas del sur.' },
        { id: 'obj-cart', name: 'Carro Blindado', type: 'chest', x: 6, y: 8, isOpened: false, description: 'Transporte de caudales vigilado por mercenarios contratados.' }
      ]
    },
    eventLogs: [
      { id: 'ev-m1', timestamp: '12:10', coords: { x: 4, y: 6 }, category: 'MOVIMIENTO', title: 'Entrada al distrito.', text: 'Te abres paso entre la multitud de compradores y comerciantes.' },
      { id: 'ev-m2', timestamp: '12:12', category: 'ENTORNO', title: 'Inspección de guardias.', text: 'Los centinelas revisan salvoconductos en la puerta de la aduana.' }
    ],
    dialogueHistory: [
      {
        id: 'dlg-m1',
        speaker: 'npc',
        speakerName: 'Nadim El-Zahra',
        text: '«En este zoco, cada secreto tiene su precio en moneda o sangre.»'
      }
    ]
  };

  const preset3: InteractionSessionState = {
    id: 'session-campamento-norte',
    title: 'Campamento del Norte',
    subtitle: 'Batalla desactivada · Última escena: fogata',
    savedAt: 'Hace 3 días',
    phase: 'phase3_dialogue',
    protagonist: { ...defaultProtagonist },
    npc: {
      id: 'npc-erika',
      name: 'Erika Vaelen',
      title: 'Exploradora de los Riscos',
      role: 'Exploradora de los Riscos',
      race: 'Humana',
      gender: 'Femenino',
      faction: 'Guardia de la Frontera Boreal',
      moralAlignment: 'Leal Bondadoso',
      allegianceFactionId: 'Guardia de la Frontera Boreal',
      greatestFear: 'Perder a su destacamento en las tormentas de nieve',
      motivations: ['Vigilar los pasos de montaña', 'Proteger los refugios de refugiados'],
      coreValues: 'Lealtad, Vigilancia, Sacrificio y Calidez Fraternal',
      interactionRole: 'Exploradora & Protectora',
      personality: 'Leal, taciturna, sincera y profundamente protectora.',
      personalityTraits: ['Observadora', 'Resistente', 'Afectuosa'],
      dialogueExcerpt: '«La escarcha cubrirá las tiendas antes de medianoche. Ven cerca del fuego.»',
      emotionalState: 'Afectuosa & Serena',
      confidence: 80,
      affinity: 85,
      resistance: 10,
      arousal: 30,
      hp: 135,
      maxHp: 135,
      sp: 80,
      maxSp: 80,
      attack: 32,
      defense: 22,
      agility: 36,
      specialSkillName: 'Disparo de la Ventisca',
      specialSkillDescription: 'Flecha infundida en escarcha que inmoviliza al adversario.',
      skills: ['Rastreo Infalible', 'Disparo Preciso', 'Orientación Nocturna'],
      armorDescription: 'Abrigo de pieles de lobo sobre cota de anillas',
      weapons: ['Arco Compuesto Recurvo', 'Cuchillo de Caza'],
      inventory: ['Piedra de Fuego', 'Manta Térmica', 'Raciones de Cecina'],
      attributes: { FUE: 14, DES: 18, CON: 15, INT: 12, SAB: 16, CAR: 12 },
      derived: {
        PV: 135,
        maxPV: 135,
        PEP: 8,
        maxPEP: 8,
        CA: 16,
        iniciativa: 18,
        velocidad: 35,
        CEP: 18,
        EFC: 45,
        RR: 55,
        XP: 220,
        nivel: 1
      },
      isHostile: false
    },
    place: {
      id: 'place-campamento',
      name: 'Campamento del Norte',
      zoneName: 'Círculo de la Fogata Mayor',
      initialCoords: { x: 5, y: 5 },
      weather: 'Frío glacial con nieve ligera',
      hour: '21:00 - Noche cerrada',
      details: 'Tiendas de lona gruesa y pieles, leños crepitantes y vapor de aliento en la penumbra.'
    },
    config: {
      npcDensity: 'Pocos',
      storyTone: 'Romance',
      battleEnabled: false
    },
    mapState: {
      playerPos: { x: 5, y: 5 },
      npcPos: { x: 5, y: 6 },
      objects: [
        { id: 'obj-fire', name: 'Fogata Mayor', type: 'inspectable', x: 5, y: 5, description: 'Llamas vivas que despiden un calor reconfortante.' },
        { id: 'obj-tent', name: 'Tienda de Campaña', type: 'inspectable', x: 3, y: 4, description: 'Refugio forrado con mantas de lana y pellejos curtidos.' }
      ]
    },
    eventLogs: [
      { id: 'ev-c1', timestamp: '20:55', coords: { x: 5, y: 5 }, category: 'MOVIMIENTO', title: 'Te sientas junto al fuego.', text: 'El frío mengua con el calor de las brasas.' },
      { id: 'ev-c2', timestamp: '20:58', category: 'NPC', title: 'Erika comparte una manta.', text: 'Se acomoda a tu lado buscando refugio mutuo.' }
    ],
    dialogueHistory: [
      {
        id: 'dlg-c1',
        speaker: 'npc',
        speakerName: 'Erika Vaelen',
        text: '«La escarcha cubrirá las tiendas antes de medianoche. Ven cerca del fuego.»'
      }
    ]
  };

  return [preset1, preset2, preset3];
}

export const STORAGE_KEY = 'elysium_saved_sessions_v2';
export const ACTIVE_SESSION_KEY = 'elysium_active_session_id';

export function getActiveSessionId(): string | null {
  try {
    return localStorage.getItem(ACTIVE_SESSION_KEY);
  } catch {
    return null;
  }
}

export function setActiveSessionId(sessionId: string | null): void {
  try {
    if (sessionId) {
      localStorage.setItem(ACTIVE_SESSION_KEY, sessionId);
    } else {
      localStorage.removeItem(ACTIVE_SESSION_KEY);
    }
  } catch (e) {
    console.error('Error setting active session ID in storage:', e);
  }
}

export function loadAllSavedSessions(): InteractionSessionState[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      const presets = getInitialSavedSessions();
      localStorage.setItem(STORAGE_KEY, JSON.stringify(presets));
      return presets;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
    const presets = getInitialSavedSessions();
    localStorage.setItem(STORAGE_KEY, JSON.stringify(presets));
    return presets;
  } catch (e) {
    console.error('Error loading sessions from storage:', e);
    return getInitialSavedSessions();
  }
}

export function getSessionById(sessionId: string): InteractionSessionState | null {
  const sessions = loadAllSavedSessions();
  return sessions.find(s => s.id === sessionId) || null;
}

export function saveSessionState(session: InteractionSessionState): void {
  try {
    const sessions = loadAllSavedSessions();
    const index = sessions.findIndex(s => s.id === session.id);
    const updated = {
      ...session,
      savedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    if (index >= 0) {
      sessions[index] = updated;
    } else {
      sessions.unshift(updated);
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
    // Also guarantee active session pointer matches if updated
    if (session.id) {
      setActiveSessionId(session.id);
    }
  } catch (e) {
    console.error('Error saving session to storage:', e);
  }
}

export function appendMessageToSession(
  sessionId: string,
  message: {
    id: string;
    speaker: 'protagonist' | 'npc' | 'agent' | 'narrator' | 'system';
    speakerName: string;
    speakerId?: string;
    text: string;
    timestamp?: string;
  }
): InteractionSessionState | null {
  try {
    const sessions = loadAllSavedSessions();
    const index = sessions.findIndex(s => s.id === sessionId);
    if (index < 0) return null;

    const session = sessions[index];
    const updatedHistory = [...(session.dialogueHistory || []), message];
    const updatedSession: InteractionSessionState = {
      ...session,
      dialogueHistory: updatedHistory,
      savedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    sessions[index] = updatedSession;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
    setActiveSessionId(sessionId);
    return updatedSession;
  } catch (e) {
    console.error('Error appending message to session:', e);
    return null;
  }
}

export function exportSessionTranscriptAsText(session: InteractionSessionState): string {
  const lines: string[] = [
    `============================================================`,
    `ELYSIUM · HISTORIAL DE CONVERSACIÓN & TERTULIA DE AGENTES`,
    `Sesión: ${session.title}`,
    `Escenario: ${session.place?.name || 'Recinto'} (${session.place?.zoneName || 'Área Principal'})`,
    `Mundo: ${session.worldBuilding?.worldName || 'Elysium'}`,
    `Protagonista: ${session.protagonist?.name || 'Protagonista'} (${session.protagonist?.role || 'Aventurero'})`,
    `Acompañantes en Sala: ${(session.companionAgents || [session.npc]).map(c => `${c.name} [${c.role}]`).join(', ')}`,
    `Fecha de Exportación: ${new Date().toLocaleString()}`,
    `Total de Mensajes Persistidos: ${session.dialogueHistory?.length || 0}`,
    `============================================================\n`
  ];

  session.dialogueHistory?.forEach((msg, idx) => {
    const time = msg.timestamp ? `[${msg.timestamp}] ` : '';
    const speaker = msg.speakerName || msg.speaker;
    lines.push(`${idx + 1}. ${time}${speaker}:`);
    lines.push(`   ${msg.text}\n`);
  });

  return lines.join('\n');
}

export function deleteSavedSession(sessionId: string): InteractionSessionState[] {
  try {
    const sessions = loadAllSavedSessions().filter(s => s.id !== sessionId);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
    if (getActiveSessionId() === sessionId) {
      setActiveSessionId(sessions[0]?.id || null);
    }
    return sessions;
  } catch (e) {
    console.error('Error deleting session:', e);
    return [];
  }
}

export function duplicateSavedSession(sessionId: string): InteractionSessionState | null {
  try {
    const sessions = loadAllSavedSessions();
    const source = sessions.find(s => s.id === sessionId);
    if (!source) return null;

    const duplicated: InteractionSessionState = {
      ...JSON.parse(JSON.stringify(source)),
      id: `chat-session-${Date.now()}`,
      title: `${source.title} (Copia)`,
      savedAt: 'Ahora'
    };

    saveSessionState(duplicated);
    return duplicated;
  } catch (e) {
    console.error('Error duplicating session:', e);
    return null;
  }
}

export function restartSessionHistory(sessionId: string): InteractionSessionState | null {
  try {
    const sessions = loadAllSavedSessions();
    const session = sessions.find(s => s.id === sessionId);
    if (!session) return null;

    const firstCompanion = session.companionAgents?.[0] || session.npc;
    const initialText = `*Saluda cordialmente al observar tu presencia.* «Saludos, ${session.protagonist?.name || 'viajero'}. La conversación en ${session.place?.name || 'este lugar'} comienza de nuevo. ¿De qué deseas que hablemos?»`;

    const restarted: InteractionSessionState = {
      ...session,
      dialogueHistory: [
        {
          id: `dlg-restart-${Date.now()}`,
          speaker: 'npc',
          speakerName: firstCompanion?.name || 'Acompañante',
          speakerId: firstCompanion?.id || 'npc',
          text: initialText,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ],
      conversationMemory: createInitialConversationMemory(session.place?.name, session.worldBuilding?.worldName),
      eventLogs: [
        {
          id: `ev-restart-${Date.now()}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          category: 'ENTORNO',
          title: 'Conversación reiniciada',
          text: `Se reinició el diálogo en ${session.place?.name || 'el escenario'}.`
        }
      ]
    };

    saveSessionState(restarted);
    return restarted;
  } catch (e) {
    console.error('Error restarting session:', e);
    return null;
  }
}
