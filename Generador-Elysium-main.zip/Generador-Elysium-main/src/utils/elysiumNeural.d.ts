// =========================================================================
// DECLARACIONES DE TIPOS PARA ELYSIUM NEURAL CORE
// =========================================================================

import { CharacterConsciousnessProfile, ConsciousResponse } from './characterConsciousnessEngine';
import { UnifiedParticipant, CharacterState } from './characterLogicEngine';
import { LocalLLM, LLMContext, LLMResponse, LLMConfig, DEFAULT_LLM_CONFIG, Token, ReasoningStep } from './localLLM';
import { SemanticAnalysisResult, CognitiveAppraisal, SomatosensoryState } from './somaticCognitiveEngine';
import { ConversationMemory } from './conversationMemoryEngine';
import { KnowledgeEntry, KNOWLEDGE_CORPUS } from './localKnowledgeLibrary';
import { UnifiedCharacterSheet } from './characterSheetLoader';

// -------------------------------------------------------------------------
// TIPOS PRINCIPALES
// -------------------------------------------------------------------------

/**
 * Tipos de entrada que puede procesar Elysium Neural
 */
export type InputType = 
  | 'user_message'           // Mensaje directo del usuario
  | 'character_dialogue'     // Diálogo de personaje
  | 'narrator_request'       // Solicitud de narración
  | 'scene_description'      // Descripción de escena
  | 'ooc_query'              // Consulta Out-Of-Character
  | 'system_command'         // Comando del sistema
  | 'memory_consolidation'  // Consolidación de memoria
  | 'knowledge_query'        // Consulta de conocimiento
  | 'backstory_generation'   // Generación de trasfondo
  | 'timeline_generation'    // Generación de línea temporal
  ;

/**
 * Contexto de entrada para Elysium Neural
 */
export interface NeuralInput {
  type: InputType;
  text: string;
  sender?: {
    id: string;
    name: string;
    role: string;
    type: 'user' | 'npc' | 'narrator' | 'agent' | 'system';
  };
  target?: {
    id: string;
    name: string;
    role: string;
    type: 'user' | 'npc' | 'narrator' | 'agent' | 'system';
  };
  characterProfile?: CharacterConsciousnessProfile;
  characterSheet?: UnifiedCharacterSheet;
  conversationHistory?: Array<{
    sender: string;
    receiver?: string;
    text: string;
    timestamp?: string;
    intent?: string;
  }>;
  conversationMemory?: ConversationMemory;
  place?: {
    name: string;
    zoneName?: string;
    weather?: string;
    hour?: string;
    atmosphere?: string;
    details?: string;
    rhythmOrVibes?: string[];
  };
  worldBuilding?: {
    worldName: string;
    laws: string[];
    factions?: string[];
    cosmology?: string;
  };
  companions?: UnifiedParticipant[];
  protagonist?: UnifiedParticipant;
  semanticAnalysis?: SemanticAnalysisResult;
  knowledgeDomains?: string[];
  maxTokens?: number;
  temperature?: number;
  enableReasoning?: boolean;
  enableMemory?: boolean;
  enablePersonality?: boolean;
  enableSomatic?: boolean;
}

/**
 * Resultado del procesamiento de Elysium Neural
 */
export interface NeuralOutput {
  // Respuesta principal
  text: string;
  
  // Metadatos de la respuesta
  responseType: 'dialogue' | 'narration' | 'analysis' | 'command_response' | 'memory_update' | 'knowledge_response' | 'error';
  
  // Información del hablante (si aplica)
  speaker?: {
    name: string;
    role: string;
    type: 'user' | 'npc' | 'narrator' | 'agent' | 'system';
  };
  
  // Razonamiento interno
  reasoning?: {
    chain: ReasoningStep[];
    summary: string;
    confidence: number;
  };
  
  // Análisis semántico
  semanticAnalysis?: SemanticAnalysisResult;
  
  // Conocimiento aplicado
  appliedKnowledge?: KnowledgeEntry[];
  
  // Estado somático (para personajes)
  somaticState?: SomatosensoryState;
  
  // Monólogo interno (para personajes)
  innerMonologue?: string;
  
  // Actualización de memoria
  memoryUpdate?: {
    keyFacts: string[];
    agreementsAndPromises: string[];
    unresolvedQuestions: string[];
    narrativeTone?: string;
    characterPerspectives?: Record<string, {
      perceivedAffinity: number;
      trustLevel: number;
      internalObservation: string;
    }>;
  };
  
  // Evaluación cognitiva
  cognitiveAppraisal?: CognitiveAppraisal;
  
  // Información de narración (para narrador)
  narrationInfo?: {
    directorIntent: string;
    environmentalShift: string;
    castReactionsSummary: string;
    narrativeHooks: string[];
    isOocDirectAnswer: boolean;
    discoveredFact?: string;
  };
  
  // Tokens generados
  tokens?: number;
  processingTime?: number;
  
  // Indicador de fallback
  isFallback: boolean;
  fallbackReason?: string;
  
  // Error (si aplica)
  error?: string;
}

/**
 * Configuración de Elysium Neural
 */
export interface NeuralConfig {
  model: 'elysium-v1' | 'elysium-v2' | 'elysium-reasoner' | 'elysium-ultimate';
  llmConfig?: Partial<LLMConfig>;
  enableAllFeatures: boolean;
  enableAdvancedReasoning: boolean;
  enableMemorySystem: boolean;
  enablePersonalitySystem: boolean;
  enableSomaticSystem: boolean;
  enableKnowledgeSystem: boolean;
  maxContextLength: number;
  maxResponseLength: number;
  defaultTemperature: number;
  defaultTopK: number;
}

/**
 * Contexto de sesión para Elysium Neural
 */
export interface NeuralSession {
  id: string;
  conversationHistory: NeuralInput[];
  conversationMemory: ConversationMemory;
  activeCharacters: Map<string, CharacterConsciousnessProfile>;
  place: NeuralInput['place'];
  worldBuilding: NeuralInput['worldBuilding'];
  createdAt: Date;
  lastUpdated: Date;
}

// -------------------------------------------------------------------------
// CONFIGURACIÓN POR DEFECTO
// -------------------------------------------------------------------------

export const DEFAULT_NEURAL_CONFIG: NeuralConfig;

// -------------------------------------------------------------------------
// CLASE PRINCIPAL
// -------------------------------------------------------------------------

/**
 * Elysium Neural - Modelo de Lenguaje Basado en Texto para Rolplay
 */
export class ElysiumNeural {
  constructor(config?: Partial<NeuralConfig>);
  
  // Gestión de sesiones
  createSession(sessionId: string, initialContext?: Partial<NeuralSession>): NeuralSession;
  getSession(sessionId: string): NeuralSession | undefined;
  deleteSession(sessionId: string): boolean;
  updateSessionContext(sessionId: string, updates: Partial<NeuralSession>): boolean;
  
  // Procesamiento principal
  processInput(input: NeuralInput, sessionId?: string): Promise<NeuralOutput>;
  
  // Métodos estáticos
  static createForRoleplay(config?: Partial<NeuralConfig>): ElysiumNeural;
  static createMinimal(config?: Partial<NeuralConfig>): ElysiumNeural;
  static processSimpleInput(text: string, characterProfile?: CharacterConsciousnessProfile): Promise<NeuralOutput>;
}

// -------------------------------------------------------------------------
// EXPORTS ADICIONALES
// -------------------------------------------------------------------------

export { LocalLLM, LLMContext, LLMResponse, LLMConfig, DEFAULT_LLM_CONFIG, Token, ReasoningStep };
export { analyzeSemanticSubtext, SemanticAnalysisResult, CognitiveAppraisal, SomatosensoryState };
export { CharacterConsciousnessProfile, ConsciousResponse };
export { ConversationMemory };
export { KnowledgeEntry, KNOWLEDGE_CORPUS };

// Instancia singleton
export const elysiumNeural: ElysiumNeural;
