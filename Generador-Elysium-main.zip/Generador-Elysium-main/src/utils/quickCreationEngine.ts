import { CharacterState, GarmentConfig } from '../types';
import {
  RACE_GROUPS,
  RACE_PRESET_TRAITS,
  applyRaceSuggestedTraits,
  ROLES_CATALOG,
  VISUAL_STYLES,
  CHARACTER_ARCHETYPES,
  PERSONALITIES,
  ROLE_THEME_CONFIG,
  STYLE_THEME_CONFIG,
  WEAPONS_LIST,
  WEAPONS_GRIPS,
  BAGS_LIST,
  BAGS_SIZES,
  BAGS_CLOSURES,
  ITEMS_LIST,
  getRoleAttireConfig,
  RoleAttireConfig,
  getPieceLengthOptions,
  GENERAL_ROLE_MATERIALS,
  GENERAL_ROLE_FINISHES,
  ALL_STYLE_THEMATIC_DATA,
  getStyleThematicPackage,
  DEFAULT_MAKEUP_CONFIG
} from '../data';
import { generateArchetypeAdaptedBackground } from './dynamicBackgroundEngine';
import {
  computeRoleHybrid,
  computeStyleFusion,
  getCompatibleSubRoles,
  getCompatibleSubStyles
} from '../data/styleRoleFusionEngine';

export interface QuickCreationInput {
  raceId: string;
  subtypeId?: string;
  sexBase: string; // '1 Hombre' | '2 Mujer' | '3 Andrógino' | '4 Hombre (mujer trans-sexual)'
  role: string;
  subRole?: string;
  hybridRoleTitle?: string;
  styleVisual: string;
  subStyleVisual?: string;
  archetype: string;
  personality: string;
  personalityTraits: string[];
  coreValues: string;
  motivation?: string;
  secret?: string;
  backstory?: string;
  name?: string;
}

export interface ThematicPreset {
  id: string;
  title: string;
  tagline: string;
  badge: string;
  input: QuickCreationInput;
}

// -------------------------------------------------------------
// CURATED THEMATIC PRESETS (1-CLICK INSPIRATION)
// -------------------------------------------------------------
export const THEMATIC_QUICK_PRESETS: ThematicPreset[] = [
  {
    id: 'princesa-barbara',
    title: 'Princesa Bárbara (Noble + Berserker)',
    tagline: 'Aristócrata regia que desciende al frenesí salvaje con armadura de gala y hacha de guerra.',
    badge: 'Híbrido Canónico',
    input: {
      raceId: '1.1',
      subtypeId: '1.1.2',
      sexBase: '2 Mujer',
      role: 'F1 Aristócrata de Corte',
      subRole: 'B1 Berserker',
      hybridRoleTitle: 'Princesa Bárbara / Noble Berserker',
      styleVisual: 'Gótico',
      subStyleVisual: 'Elegante',
      archetype: 'Diva',
      personality: 'Orgulloso',
      personalityTraits: ['Orgulloso', 'Feroz', 'Noble', 'Intransigente'],
      coreValues: 'El linaje imperial se defiende con sangre, acero pesado y diplomacia implacable.',
      motivation: 'Recuperar el trono usurpado a través de la conquista marcial y el poder de la corte.',
      secret: 'Oculta marcas tribales de sangre bajo sus vestidos de seda que brillan al enfurecerse.',
      name: 'Princesa Astrid von Valerius'
    }
  },
  {
    id: 'maid-asesina',
    title: 'Maid Asesina (Servicio + Asesino)',
    tagline: 'Doncella de modales impecables con dagas y venenos ocultos bajo el delantal.',
    badge: 'Híbrido Sigilo',
    input: {
      raceId: '1.1',
      subtypeId: '1.1.1',
      sexBase: '2 Mujer',
      role: 'A1 Maid de Mansión',
      subRole: 'G8 Asesino de Alquiler',
      hybridRoleTitle: 'Maid Asesina / Doncella de las Sombras',
      styleVisual: 'Gótico',
      subStyleVisual: 'Techwear',
      archetype: 'Yandere',
      personality: 'Meticuloso',
      personalityTraits: ['Meticuloso', 'Protector', 'Calculador', 'Leal'],
      coreValues: 'Mantener la mansión impecable y eliminar a cualquier amenaza hacia su amo sin dejar rastro.',
      motivation: 'Garantizar la supervivencia de su señor en una corte repleta de conspiradores.',
      secret: 'Colecciona los anillos de las víctimas que intentaron envenenar el té de su señor.',
      name: 'Evelyn Cross'
    }
  },
  {
    id: 'paladin-caido',
    title: 'Paladín Caído (Paladín + Nigromante)',
    tagline: 'Cruzado de la fe que comanda legiones de espectros para imponer justicia implacable.',
    badge: 'Arcano & Marcial',
    input: {
      raceId: '1.2',
      subtypeId: '1.2.3',
      sexBase: '1 Hombre',
      role: 'E3 Paladín',
      subRole: 'C3 Nigromante',
      hybridRoleTitle: 'Paladín Caído / Caballero del Ocaso',
      styleVisual: 'Fantasía Tradicional',
      subStyleVisual: 'Gótico',
      archetype: 'Antihéroe',
      personality: 'Estoico',
      personalityTraits: ['Estoico', 'Valiente', 'Sombrío', 'Leal'],
      coreValues: 'Si la luz no pudo salvarlos, las sombras purgarán a los verdaderos monstruos.',
      motivation: 'Resucitar a su orden caída para terminar la cruzada sagrada que les costó la vida.',
      secret: 'Lleva el cráneo de su antiguo maestro como catalizador de su fuego oscuro.',
      name: 'Lord Morvath de Ocaso'
    }
  },
  {
    id: 'samurai-ronin-oni',
    title: 'Ronin Cyber-Yakuza (Samurái + Sicario)',
    tagline: 'Kenshi sin amo con katana de filo térmico y tatuajes de dragón holográficos.',
    badge: 'Cyber-Samurái',
    input: {
      raceId: '2.1',
      subtypeId: '2.1.1',
      sexBase: '1 Hombre',
      role: 'B5 Samurái Pesado',
      subRole: 'G1 Sicario de Gremio',
      hybridRoleTitle: 'Ronin Renegado / Asesino del Shogunato',
      styleVisual: 'Cyberpunk',
      subStyleVisual: 'Fantasía Oriental',
      archetype: 'Gladiador',
      personality: 'Agresivo',
      personalityTraits: ['Agresivo', 'Noble', 'Intrépido', 'Leal'],
      coreValues: 'El filo de la katana refleja el alma; quien no lucha con honor merece el olvido.',
      motivation: 'Destruir a los barones corporativos que traicionaron el código sagrado de su clan.',
      secret: 'Debe realizar ofrendas de energía dérmica cada ciclo para aplacar su implante oni demoníaco.',
      name: 'Kurokiba Tetsuzan'
    }
  },
  {
    id: 'pistolero-alquimico',
    title: 'Pistolero Alquímico (Alquimista + Tirador)',
    tagline: 'Artificiero balístico que dispara proyectiles cargados de fuego griego y criogénico.',
    badge: 'Steampunk Táctico',
    input: {
      raceId: '1.1',
      subtypeId: '1.1.1',
      sexBase: '2 Mujer',
      role: 'C5 Alquimista',
      subRole: 'D5 Tirador de Élite',
      hybridRoleTitle: 'Pistolero Alquímico / Artificiero Balístico',
      styleVisual: 'Steampunk',
      subStyleVisual: 'Militar',
      archetype: 'Prodigio',
      personality: 'Curioso',
      personalityTraits: ['Curioso', 'Audaz', 'Meticuloso', 'Excéntrico'],
      coreValues: 'La precisión balística y la química reactiva resuelven cualquier problema con elegancia.',
      motivation: 'Construir el cañón de resonancia elemental definitivo capaz de perforar fortalezas flotantes.',
      secret: 'Lleva una cápsula de nitroglicerina alquímica sellada en su antebrazo protésico.',
      name: 'Capitana Vespera Volt'
    }
  },
  {
    id: 'artificiero-steampunk',
    title: 'Maestro Artificiero a Vapor',
    tagline: 'Inventor incansable rodeado de engranajes de latón, manómetros y autómatas.',
    badge: 'Steampunk',
    input: {
      raceId: '1.3',
      subtypeId: '1.3.1',
      sexBase: '1 Hombre',
      role: 'A3 Artificiero',
      styleVisual: 'Steampunk',
      archetype: 'Alquimista',
      personality: 'Enérgico',
      personalityTraits: ['Enérgico', 'Curioso', 'Excéntrico', 'Audaz'],
      coreValues: 'Todo problema tiene solución mecánica o química; el progreso exige experimentación osada.',
      motivation: 'Construir el primer motor de éter perpetuo capaz de elevar ciudades enteras.',
      secret: 'Un accidente de laboratorio le costó un brazo, reemplazado por una prótesis biónica de bronce.',
      name: 'Magnus Cogwheel'
    }
  },
  {
    id: 'maid-tsundere-gotica',
    title: 'Maid de Mansión Aristocrática',
    tagline: 'Servidumbre impecable de modales cortantes y lealtad feroz.',
    badge: 'Servicio & Nobleza',
    input: {
      raceId: '5.3',
      subtypeId: '5.3.1',
      sexBase: '2 Mujer',
      role: 'A1 Maid de Mansión',
      styleVisual: 'Elegante',
      archetype: 'Tsundere',
      personality: 'Orgulloso',
      personalityTraits: ['Orgulloso', 'Meticuloso', 'Leal', 'Exigente'],
      coreValues: 'La disciplina y la excelencia en el servicio son el único escudo contra el desorden vulgar.',
      motivation: 'Proteger la integridad de la casa noble que la acogió cuando fue repudiada por su cónclave.',
      secret: 'Practica secretly esgrima nocturna para proteger a su señor de asesinos encubiertos.',
      name: 'Celeste von Lavenza'
    }
  },
  {
    id: 'picaro-femboy-elfo',
    title: 'Pícaro Encantador de las Sombras',
    tagline: 'Ladrón ágil de movimientos gráciles, carisma deslumbrante y dagas ocultas.',
    badge: 'Sigilo & Belleza',
    input: {
      raceId: '1.2',
      subtypeId: '1.2.1',
      sexBase: '3 Andrógino',
      role: 'D1 Pícaro Urbano',
      styleVisual: 'Vanguardista / Haute Couture',
      archetype: 'Femboy',
      personality: 'Carismático',
      personalityTraits: ['Carismático', 'Pícaro', 'Juguetón', 'Astuto'],
      coreValues: 'La elegancia es la mejor distracción; nadie sospecha de una sonrisa angelical.',
      motivation: 'Recuperar las joyas de la corona que pertenecieron a su familia antes del golpe de estado.',
      secret: 'Utiliza su apariencia delicada como trampa para desarmar a nobles arrogantes.',
      name: 'Lysander Silvershade'
    }
  },
  {
    id: 'demonio-lord-kamidere',
    title: 'Señor Demonio de la Alta Corte',
    tagline: 'Soberano arrogante con alas de sombra, cuernos de obsidiana y poder colosal.',
    badge: 'Nobleza Abisal',
    input: {
      raceId: '5.1',
      subtypeId: '5.1.1',
      sexBase: '1 Hombre',
      role: 'F3 Señor de la Guerra',
      styleVisual: 'Gótico',
      archetype: 'Kamidere',
      personality: 'Agresivo',
      personalityTraits: ['Agresivo', 'Dominante', 'Calculador', 'Magnánimo'],
      coreValues: 'El poder absoluto define el orden natural; los débiles necesitan una mano férrea que los guíe.',
      motivation: 'Unificar los reinos fragmentados bajo su trono para detener la catástrofe dimensional.',
      secret: 'Hizo un pacto secreto de sangre con un ángel caído para preservar la vida de su pueblo.',
      name: 'Lord Malakor de Gehena'
    }
  }
];

// -------------------------------------------------------------
// RANDOM GENERATORS FOR INSTANT CREATIVITY
// -------------------------------------------------------------
const RANDOM_NAMES = {
  male: ['Valerius', 'Kaelen', 'Theron', 'Dante', 'Ignis', 'Kazuki', 'Caelum', 'Oberon', 'Victor', 'Dorian', 'Bastian', 'Gideon'],
  female: ['Aurelia', 'Sylvia', 'Katarina', 'Elowen', 'Nyx', 'Seraphina', 'Yuki', 'Lyra', 'Morrigan', 'Cassandra', 'Vespera', 'Lumina'],
  androgynous: ['Rowan', 'Morgan', 'Kiran', 'Astraea', 'Vesper', 'Zephyr', 'Rin', 'Valis', 'Eli', 'Cael']
};

const RANDOM_SURNAMES = ['de Luminaria', 'Nightshade', 'Silverwind', 'Ravencroft', 'Ironclad', 'Vanderbilt', 'Blackwood', 'Moonveil', 'Frostborn', 'von Drake'];

export function getRandomQuickInput(): QuickCreationInput {
  const allRaces = RACE_GROUPS.flatMap(g => g.races);
  const pickedRace = allRaces[Math.floor(Math.random() * allRaces.length)];
  
  const sexes = ['1 Hombre', '2 Mujer', '3 Andrógino'];
  const pickedSex = sexes[Math.floor(Math.random() * sexes.length)];

  const allRoles = ROLES_CATALOG.flatMap(c => c.roles);
  const pickedRole = allRoles[Math.floor(Math.random() * allRoles.length)];

  const pickedStyle = VISUAL_STYLES[Math.floor(Math.random() * VISUAL_STYLES.length)];
  const pickedArchetype = CHARACTER_ARCHETYPES[Math.floor(Math.random() * CHARACTER_ARCHETYPES.length)];
  const pickedPersonality = PERSONALITIES[Math.floor(Math.random() * PERSONALITIES.length)];

  let nameList = RANDOM_NAMES.female;
  if (pickedSex === '1 Hombre') nameList = RANDOM_NAMES.male;
  if (pickedSex === '3 Andrógino') nameList = RANDOM_NAMES.androgynous;

  const firstName = nameList[Math.floor(Math.random() * nameList.length)];
  const surname = RANDOM_SURNAMES[Math.floor(Math.random() * RANDOM_SURNAMES.length)];
  const fullName = `${firstName} ${surname}`;

  return {
    raceId: pickedRace.id,
    sexBase: pickedSex,
    role: pickedRole,
    styleVisual: pickedStyle,
    archetype: pickedArchetype,
    personality: pickedPersonality,
    personalityTraits: [pickedPersonality, 'Leal', 'Decidido'],
    coreValues: 'Lealtad inquebrantable a sus principios y búsqueda implacable de la verdad sin importar el coste.',
    motivation: 'Demostrar su valía y forjar su propio destino fuera de los mandatos impuestos.',
    secret: 'Guarda un juramento secreto sellado en su infancia que no puede revelar a nadie.',
    name: fullName
  };
}

// -------------------------------------------------------------
// CORE GENERATOR ENGINE (AUTO SYNTHESIS)
// -------------------------------------------------------------
export function generateQuickCharacter(input: QuickCreationInput): CharacterState {
  const raceTraits = applyRaceSuggestedTraits(input.raceId, input.subtypeId);
  const isFemale = input.sexBase === '2 Mujer' || input.sexBase.includes('mujer trans') || input.sexBase.includes('trans');
  const isMale = input.sexBase === '1 Hombre';
  const isAndrogynous = input.sexBase === '3 Andrógino';

  // 1. Race Metadata Resolution
  let raceName = 'Humano';
  let raceGroup = 'GRUPO 1: HUMANODES SABIOS';
  for (const grp of RACE_GROUPS) {
    const r = grp.races.find(rc => rc.id === input.raceId);
    if (r) {
      raceName = r.name;
      raceGroup = grp.title;
      break;
    }
  }

  // 2. Anatomy Auto-Synthesis
  let breastDev = 'A Senos Planos / Pechos Incipientes / Copa AA';
  let waist = '3 Media / Equilibrada';
  let glutes = '3 Moderados';
  let thighs = '3 Medios / Equilibrados';
  let complexion = raceTraits.anatomy?.complexion || '2 Esbelto / Estandar';
  let height = raceTraits.anatomy?.height || 'C Normal / Estándar (1.60 m – 1.80 m)';

  if (isFemale) {
    if (input.archetype === 'Tomboy' || input.archetype === 'Niño Prodigio') {
      breastDev = 'B Senos Pequeños / Pechos Discretos / Copa A';
      waist = '2 Estrecha / Atlética';
      glutes = '3 Moderados';
    } else if (input.archetype === 'Himedere' || input.archetype === 'Ojou-sama') {
      breastDev = 'C Senos Medianos / Pechos Equilibrados / Copa B-C';
      waist = '2 Estrecha / Marcada';
      glutes = '4 Voluminosos';
      thighs = '3 Medios / Torneados';
    } else if (input.role.includes('Maid') || input.archetype.includes('Diva') || input.archetype === 'Yandere') {
      breastDev = 'D Senos Prominentes / Pechos Voluminosos / Copa D';
      waist = '1 Muy Estrecha (Avispa)';
      glutes = '4 Voluminosos';
      thighs = '4 Gruesos / Curvilíneos';
    } else {
      breastDev = 'C Senos Medianos / Pechos Equilibrados / Copa B-C';
      waist = '2 Estrecha / Marcada';
      glutes = '3 Moderados';
      thighs = '3 Medios / Equilibrados';
    }
  } else if (isMale) {
    breastDev = 'A Senos Planos / Pechos Incipientes / Copa AA';
    waist = '4 Ancha / Recta';
    glutes = '3 Moderados';
    thighs = '3 Medios / Equilibrados';
    if (input.role.includes('Caballero') || input.role.includes('Berserker') || input.role.includes('Gladiador')) {
      complexion = '4 Musculoso';
    }
  } else {
    // Androgynous
    breastDev = 'A Senos Planos / Pechos Incipientes / Copa AA';
    waist = '3 Media / Equilibrada';
    glutes = '3 Moderados';
    thighs = '3 Medios / Equilibrados';
    complexion = '2 Esbelto / Estandar';
  }

  // 3. Facial Auto-Synthesis
  let facialExpression = 'EXP1 Neutral';
  if (input.archetype === 'Kuudere' || input.archetype === 'Estoico Reservado') {
    facialExpression = 'EXP1 Neutral / Sereno';
  } else if (input.archetype === 'Tsundere' || input.archetype === 'Himedere') {
    facialExpression = 'EXP4 Orgullosa / Desafiante';
  } else if (input.archetype === 'Genki' || input.archetype === 'Optimista Incansable') {
    facialExpression = 'EXP2 Alegre / Sonriente';
  } else if (input.archetype === 'Yandere') {
    facialExpression = 'EXP6 Intensa / Ojos Brillantes Fijos';
  } else if (input.archetype === 'Dandere') {
    facialExpression = 'EXP3 Tímida / Mirada Baja';
  } else if (input.archetype === 'Kamidere') {
    facialExpression = 'EXP5 Burlona / Superior';
  } else if (input.archetype === 'Hacker Rebelde' || input.archetype === 'Pícaro Encantador') {
    facialExpression = 'EXP7 Guiño Pícaro / Sonrisa Confiada';
  }

  let eyeColor = raceTraits.facial?.eyeColor || 'Marrón / Castaño';
  if (input.styleVisual === 'Cyberpunk') eyeColor = 'Azul Eléctrico / Cian Emisivo';
  if (input.styleVisual === 'Gótico') eyeColor = 'Rojo Carmesí / Borgoña Profundo';
  if (input.styleVisual === 'Fantasía Oriental') eyeColor = 'Dorado Solar / Ámbar Brillante';

  // 4. Hair Auto-Synthesis
  let hairStyle = 'HST00 Sin peinado / suelto';
  let hairLength = '3 Medio (Hombros)';
  let hairCut = '4 Recto';
  let hairColor = 'Negro Azabache';

  if (input.archetype === 'Ojou-sama') {
    hairStyle = 'HST08 Tirabuzones / Doble Rizo Drill Noble';
    hairLength = '4 Largo (Espalda Media)';
    hairColor = 'Rubio Dorado Platino';
  } else if (input.archetype === 'Tsundere') {
    hairStyle = 'HST04 Coletas Dobles / Twintails';
    hairLength = '4 Largo (Espalda Media)';
    hairColor = 'Carmesí / Castaño Rojizo';
  } else if (input.archetype === 'Kuudere') {
    hairStyle = 'HST02 Bob Clásico / Hime Cut';
    hairLength = '2 Corto (Mentón)';
    hairColor = 'Blanco Plateado / Ceniza';
  } else if (input.archetype === 'Dandere') {
    hairStyle = 'HST01 Melena Corta Suave con Flequillo Oculto';
    hairLength = '3 Medio (Hombros)';
    hairColor = 'Azul Marino Oscuro / Noche';
  } else if (input.archetype === 'Tomboy' || input.archetype === 'Femboy') {
    hairStyle = 'HST03 Pixie Andrógino / Corto Despeinado';
    hairLength = '1 Muy Corto (Cuello)';
    hairColor = 'Castaño Claro / Rubio Cenizo';
  } else if (input.styleVisual === 'Cyberpunk') {
    hairStyle = 'HST09 Undercut Asimétrico con Mechones Neón';
    hairLength = '2 Corto (Mentón)';
    hairColor = 'Magenta Neón / Cian Bicolor';
  } else if (input.styleVisual === 'Fantasía Oriental') {
    hairStyle = 'HST07 Moño Superior / Topknot Tradicional con Horquilla';
    hairLength = '5 Extra Largo (Cintura)';
    hairColor = 'Negro Azabache Brillante';
  } else if (input.role.includes('Maid')) {
    hairStyle = 'HST10 Recogido con Cofia / Moño Francés Pulcro';
    hairLength = '3 Medio (Hombros)';
    hairColor = 'Castaño Oscuro / Chocolate';
  } else if (input.role.includes('Caballero') || input.role.includes('Paladín')) {
    hairStyle = 'HST11 Coleta Alta de Batalla / Trenza de Corona';
    hairLength = '4 Largo (Espalda Media)';
    hairColor = 'Rubio Ceniza / Oro Pálido';
  }

  // 5. Wardrobe Auto-Synthesis (Layered Garments & Style Integration)
  const roleAttire = getRoleAttireConfig(input.role);
  const styleTheme = STYLE_THEME_CONFIG[input.styleVisual] || STYLE_THEME_CONFIG['Fantasía Tradicional'];
  const roleTheme = ROLE_THEME_CONFIG[roleAttire?.category || 'Civiles'] || ROLE_THEME_CONFIG['Civiles'];

  const primaryMaterial = styleTheme?.primaryMaterial || roleTheme?.primaryMaterial || 'MAT01 - Algodón refinado';
  const primaryFinish = styleTheme?.primaryFinish || roleTheme?.primaryFinish || 'FIN01 - Mate';
  const primaryColor = styleTheme?.colorPalette?.[0]?.hex || '#1A1C22';
  const secondaryColor = styleTheme?.colorPalette?.[1]?.hex || '#C9A050';
  const accentColor = styleTheme?.colorPalette?.[2]?.hex || '#E5C17D';

  const autoWardrobes: GarmentConfig[] = [];

  // Layer 1: Undergarments (B3-A / B3-B or Bóxer)
  if (isFemale) {
    autoWardrobes.push({
      id: `w-auto-bra-${Date.now()}-1`,
      categoryId: 'B3-A',
      name: input.styleVisual === 'Gótico' ? 'Bralette de Encaje Victoriano' : 'Sostén Clásico de Seda',
      cut: 'Ceñido con Realce y Copas Anatómicas',
      length: 'Estándar',
      sleeve: 'Sin Mangas',
      material: 'MAT10 - Encaje bordado translúcido',
      color: primaryColor,
      finish: 'FIN02 - Satinado suave',
      details: ['DET04 - Encajes y puntillas'],
      variation: 'Elegante',
      layer: 'Capa 1: Ropa Interior Superior',
      location: ['Pecho / Busto'],
      detailLocations: { 'DET04 - Encajes y puntillas': ['Pecho / Centro frontal'] },
      pattern: 'Liso',
      patternDetail: '',
      neckline: 'Escote Corazón',
      emblem: 'Ninguno',
      vfx: 'Ninguno'
    });

    autoWardrobes.push({
      id: `w-auto-panty-${Date.now()}-2`,
      categoryId: 'B3-B',
      name: input.styleVisual === 'Gótico' ? 'Panty de Encaje a Juego' : 'Panty Clásica de Seda',
      cut: 'Corte Curvo Anatómico de Tiro Medio',
      length: 'Estándar',
      sleeve: 'Sin Mangas',
      material: 'MAT10 - Encaje bordado translúcido',
      color: primaryColor,
      finish: 'FIN02 - Satinado suave',
      details: ['DET04 - Encajes y puntillas'],
      variation: 'Elegante',
      layer: 'Capa 1: Ropa Interior Inferior',
      location: ['Cintura y Cadera'],
      detailLocations: {},
      pattern: 'Liso',
      patternDetail: '',
      neckline: 'Cintura Baja',
      emblem: 'Ninguno',
      vfx: 'Ninguno'
    });
  } else {
    autoWardrobes.push({
      id: `w-auto-brief-${Date.now()}-1`,
      categoryId: 'B3-B',
      name: 'Bóxer Ajustado de Algodón Elástico',
      cut: 'Ajuste Recto Elástico Anatómico',
      length: 'Corto',
      sleeve: 'Sin Mangas',
      material: 'MAT01 - Algodón refinado',
      color: '#111317',
      finish: 'FIN01 - Mate natural',
      details: ['DET03 - Costuras reforzadas'],
      variation: 'Básico',
      layer: 'Capa 1: Ropa Interior',
      location: ['Cintura y Muslos'],
      detailLocations: {},
      pattern: 'Liso',
      patternDetail: '',
      neckline: 'Elástico de Cintura',
      emblem: 'Ninguno',
      vfx: 'Ninguno'
    });
  }

  // Layer 2: Main Top / Dress / Robe (B0 / B1)
  let topName = 'Túnica / Jubón Superior de Corte Impecable';
  if (input.role.includes('Maid')) topName = 'Vestido de Maid Clásico con Mandil Blanco';
  else if (input.role.includes('Caballero') || input.role.includes('Paladín')) topName = 'Jubón de Armadura Acolchado con Tabardo';
  else if (input.role.includes('Nigromante') || input.role.includes('Hechicero')) topName = 'Túnica Arcana Fluida con Bordados Rúnicos';
  else if (input.role.includes('Pícaro')) topName = 'Chaleco y Camisa de Cuero Táctico con Fundas';
  else if (input.styleVisual === 'Fantasía Oriental') topName = 'Túnica Hanfu / Kimono de Seda con Fajín';
  else if (input.styleVisual === 'Cyberpunk') topName = 'Camisa Táctica con Circuitos y Cuello Alto';

  autoWardrobes.push({
    id: `w-auto-top-${Date.now()}-3`,
    categoryId: 'B1',
    name: topName,
    cut: 'Entallado al Contorno (Slim Fit)',
    length: 'Medio (Cintura/Cadera)',
    sleeve: 'Manga Larga con Puños Estructurados',
    material: primaryMaterial,
    color: primaryColor,
    finish: primaryFinish,
    details: ['DET01 - Bordados de Hilo Metálico', 'DET02 - Hebillas de Ajuste'],
    variation: 'Especializada por Rol',
    layer: 'Capa 2: Prenda Superior Principal',
    location: ['Torso', 'Brazos', 'Pecho'],
    detailLocations: {
      'DET01 - Bordados de Hilo Metálico': ['Cuello, solapas y escote', 'Puños'],
      'DET02 - Hebillas de Ajuste': ['Cintura']
    },
    pattern: input.styleVisual === 'Fantasía Oriental' ? 'Seda Damasco' : 'Liso',
    patternDetail: '',
    neckline: 'Cuello Mao / Mandarín Vertical',
    emblem: 'Ninguno',
    vfx: 'Ninguno'
  });

  // Layer 3: Bottom (B2)
  let bottomName = 'Pantalón de Corte Recto y Botonadura Doble';
  if (isFemale && (input.role.includes('Maid') || input.archetype === 'Ojou-sama')) {
    bottomName = 'Falda Plisada Amplia con Enaguas de Encaje';
  } else if (input.styleVisual === 'Fantasía Oriental' || input.role.includes('Samurái')) {
    bottomName = 'Hakama Tradicional de Pliegues Profundos';
  } else if (input.role.includes('Pícaro') || input.styleVisual === 'Cyberpunk') {
    bottomName = 'Pantalón Táctico Multibolsillos Antidesgarro';
  }

  autoWardrobes.push({
    id: `w-auto-bot-${Date.now()}-4`,
    categoryId: 'B2',
    name: bottomName,
    cut: isFemale && (input.role.includes('Maid') || input.archetype === 'Ojou-sama') ? 'Corte en A (Evasé) Entallada a la Cintura' : 'Corte Recto Clásico (Regular Fit)',
    length: 'Largo (Hasta los Tobillos)',
    sleeve: 'Sin Mangas',
    material: primaryMaterial,
    color: secondaryColor,
    finish: primaryFinish,
    details: ['DET03 - Costuras Reforzadas', 'DET06 - Trabillas y Cinturón'],
    variation: 'Especializada',
    layer: 'Capa 2: Prenda Inferior Principal',
    location: ['Piernas', 'Cintura'],
    detailLocations: {},
    pattern: 'Liso',
    patternDetail: '',
    neckline: 'Pretina de Cintura Alta',
    emblem: 'Ninguno',
    vfx: 'Ninguno'
  });

  // Layer 4: Outerwear (B12 / Capa / Chaqueta)
  let outerName = 'Capa Corta de Hombro con Broche de Oro';
  if (input.styleVisual === 'Cyberpunk') outerName = 'Chaqueta Biker Holográfica con Reflectores Neón';
  else if (input.styleVisual === 'Gótico') outerName = 'Sobretodo Victoriano de Terciopelo y Cuello Alto';
  else if (input.role.includes('Paladín') || input.role.includes('Caballero')) outerName = 'Manto Pesado de Hombro con Insignia Heráldica';
  else if (input.role.includes('Nigromante')) outerName = 'Manto con Capucha Arcana Sombría';

  autoWardrobes.push({
    id: `w-auto-outer-${Date.now()}-5`,
    categoryId: 'B12',
    name: outerName,
    cut: 'Estructurado Rígido con Hombreras Marcadas',
    length: 'Medio a Largo',
    sleeve: 'Manga Completa / Sin Mangas (Capa)',
    material: 'MAT06 - Cuero curtido flexible',
    color: accentColor,
    finish: 'FIN02 - Satinado suave',
    details: ['DET02 - Broche Metálico de Fijación'],
    variation: 'Gala / Aventura',
    layer: 'Capa 3: Prenda Exterior',
    location: ['Hombros', 'Espalda'],
    detailLocations: { 'DET02 - Broche Metálico de Fijación': ['Hombros y hombreras'] },
    pattern: 'Liso',
    patternDetail: '',
    neckline: 'Solapa en Pico Alzada',
    emblem: 'Ninguno',
    vfx: 'Ninguno'
  });

  // Layer 5: Footwear (B4)
  let shoeName = 'Botas de Cuero de Media Caña con Hebillas';
  if (input.role.includes('Paladín') || input.role.includes('Caballero')) shoeName = 'Botas Blindadas de Placas y Acero Templado';
  else if (input.role.includes('Maid')) shoeName = 'Zapatos Mary Jane de Cuero Lustrado con Tacón Bajo';
  else if (input.styleVisual === 'Cyberpunk') shoeName = 'Botas Tácticas de Asalto con Luces LED en Suela';
  else if (input.styleVisual === 'Fantasía Oriental') shoeName = 'Botas Orientales de Tela y Cuero con Puntera Elevada';

  autoWardrobes.push({
    id: `w-auto-shoes-${Date.now()}-6`,
    categoryId: 'B4',
    name: shoeName,
    cut: 'Caña Media Entallada con Cremallera',
    length: 'A la Rodilla / Pantorrilla',
    sleeve: 'Sin Mangas',
    material: 'MAT06 - Cuero curtido flexible',
    color: '#0A0B0E',
    finish: 'FIN03 - Brillante pulido',
    details: ['DET02 - Hebillas Metálicas', 'DET03 - Puntera Reforzada'],
    variation: 'Especializada',
    layer: 'Capa 4: Calzado',
    location: ['Pies', 'Espinillas'],
    detailLocations: {},
    pattern: 'Liso',
    patternDetail: '',
    neckline: 'Ajuste de Cordones y Correas',
    emblem: 'Ninguno',
    vfx: 'Ninguno'
  });

  // Layer 6: Signature Accessory (B5)
  let accName = 'Amuleto Focal de Cuello con Gema Engarzada';
  if (input.role.includes('Maid')) accName = 'Gargantilla de Terciopelo Negro con Lazo y Campana de Plata';
  else if (input.styleVisual === 'Cyberpunk') accName = 'Gafas Visor Tácticas HUD con Escáner Óptico';
  else if (input.styleVisual === 'Fantasía Oriental') accName = 'Colgante de Jade Imperial con Borla de Seda Roja';
  else if (input.role.includes('Pícaro')) accName = 'Cinturón Bandolera con Fundas de Dagas y Ganzúas';

  autoWardrobes.push({
    id: `w-auto-acc-${Date.now()}-7`,
    categoryId: 'B5',
    name: accName,
    cut: 'Clavicular con Colgante Central',
    length: 'Estándar',
    sleeve: 'Sin Mangas',
    material: 'MAT08 - Acero templado pulido',
    color: '#C9A050',
    finish: 'FIN04 - Pulido espejo reflectante',
    details: ['DET01 - Filigrana Ornamental'],
    variation: 'Accesorio Principal',
    layer: 'Capa 5: Accesorios y Joyería',
    location: ['Cuello', 'Pecho'],
    detailLocations: {},
    pattern: 'Liso',
    patternDetail: '',
    neckline: 'Ajuste Regulable',
    emblem: 'Ninguno',
    vfx: 'Ninguno',
    accessorySubcategory: 'Cuello & Gargantillas',
    gemType: 'Zafiro Azul Real',
    gemColor: '#2563EB',
    sizeScale: 'Mediano / Destacado'
  });

  // 6. Role Armor & Equipment Synthesis
  const defaultWeapon = roleAttire?.weapons?.[0] || 'Espada Larga de Acero Templado';
  const defaultBag = roleAttire?.bags?.[0] || 'Bolsa de Cinturón de Cuero Reforzado';
  const defaultItem = roleAttire?.relicsAndItems?.[0] || 'Frasco de Poción Alquímica Curativa';

  // 7. Dynamic Background & Behavior Engine Modulation
  const dynBackground = generateArchetypeAdaptedBackground(
    input.role,
    input.archetype,
    input.personalityTraits,
    input.coreValues
  );

  const finalCharacter: CharacterState = {
    id: `char-quick-${Date.now()}`,
    name: input.name || `${input.archetype} ${input.role.replace(/^[A-Z0-9]+\s*/, '')}`,
    personality: input.personality,
    personalityTraits: input.personalityTraits,
    archetype: input.archetype,
    raceGroup: raceGroup,
    raceId: input.raceId,
    raceName: raceName,
    subtype: input.subtypeId || '',
    anatomy: {
      sexBase: input.sexBase,
      age: '3 Juventud (18-25 años)',
      complexion: complexion,
      height: height,
      breastDevelopment: breastDev,
      waist: waist,
      glutes: glutes,
      thighs: thighs,
      skinColor: raceTraits.anatomy?.skinColor || 'Piel Caucásica Clara',
      lowerBodyStructure: raceTraits.anatomy?.lowerBodyStructure || 'SIL01 Bípedo Humanoide Estándar (Piernas)',
      chestCore: raceTraits.anatomy?.chestCore || 'COR00 Ninguno (Torso Orgánico Estándar)',
      neckFeature: raceTraits.anatomy?.neckFeature || 'NCK00 Ninguno (Cuello Estándar)'
    },
    facial: {
      headShape: 'Ovalada',
      headWidth: 'Media / Equilibrada',
      boneStructure: isMale ? 'Marcada / Fuerte' : 'Fina / Delicada',
      eyeColor: eyeColor,
      eyesCategory: raceTraits.facial?.eyesCategory || 'A Filosos / Afilados',
      eyesSubtype: raceTraits.facial?.eyesSubtype || 'A1 Almendrado Clásico',
      eyeliner: isFemale ? 'DEL2 Marcado' : 'DEL1 Delgado',
      shadow: isFemale ? 'SOM1 Sombra Suave' : 'SOM0 Sin Sombra',
      expression: facialExpression,
      iris: raceTraits.facial?.iris || '1 Humano',
      nose: raceTraits.facial?.nose || '1 Recta / Clásica',
      lips: isFemale ? 'A2 Definidos' : 'A1 Básico',
      mouthExp: 'E1 Sonriente Sutil',
      mouthSpecial: 'Ninguna',
      teeth: raceTraits.facial?.teeth || 'B1 Normales',
      mouthCorners: 'COM2 Neutras',
      mouthTexture: 'TEX1 Mate',
      earsBase: raceTraits.facial?.earsBase || 'E01 Normales',
      earsLength: raceTraits.facial?.earsLength || 'EL1 0–5 cm',
      kemonoEars: raceTraits.facial?.kemonoEars || 'Ninguno',
      scleraColor: raceTraits.facial?.scleraColor || 'SCL01 Blanca Estándar (Humana Clásica)',
      facialMorphology: raceTraits.facial?.facialMorphology || 'MORF01 Estándar Humanoide'
    },
    hair: {
      texture: '1 Liso / Lacio',
      length: hairLength,
      cut: hairCut,
      part: '1 Al Centro',
      bangs: '2 Flequillo Recto Suave',
      style: hairStyle,
      hairColor: hairColor,
      hairElemental: raceTraits.hair?.hairElemental || 'Cabello Orgánico Natural'
    },
    appendices: {
      hornsForm: raceTraits.appendices?.hornsForm || 'Ninguno',
      hornsLength: raceTraits.appendices?.hornsLength || 'HL1 0-10 cm',
      hornsThickness: raceTraits.appendices?.hornsThickness || 'G3 Medio',
      hornsPosition: raceTraits.appendices?.hornsPosition || 'P1 Frontales',
      wingsSize: raceTraits.appendices?.wingsSize || 'S2 Medio',
      wingsPosition: raceTraits.appendices?.wingsPosition || 'P1 Espalda Alta',
      wingsType: raceTraits.appendices?.wingsType || 'Ninguno',
      tailsType: raceTraits.appendices?.tailsType || 'Ninguno',
      tailsLength: raceTraits.appendices?.tailsLength || 'L2 Corta',
      skinAndMarks: raceTraits.appendices?.skinAndMarks || 'T1 Piel Lisa',
      scaleLocations: raceTraits.appendices?.scaleLocations || [],
      markTypes: raceTraits.appendices?.markTypes || [],
      markLocations: {},
      markShapes: {},
      markColors: {},
      antennaeType: raceTraits.appendices?.antennaeType || 'Ninguna',
      antennaeLength: raceTraits.appendices?.antennaeLength || 'Medias (10–25 cm)',
      antennaePosition: raceTraits.appendices?.antennaePosition || 'Frontales (Frente)',
      extraEyes: raceTraits.appendices?.extraEyes || 'Ninguno (2 Ojos Estándar)',
      extraArms: raceTraits.appendices?.extraArms || 'Ninguno (2 Brazos Estándar)',
      specialLimbs: raceTraits.appendices?.specialLimbs || 'Ninguna (Extremidades Orgánicas Estándar)',
      lowerBodyStructure: raceTraits.appendices?.lowerBodyStructure || 'SIL01 Bípedo Humanoide Estándar (Piernas)'
    },
    makeup: {
      ...DEFAULT_MAKEUP_CONFIG,
      lipstickColor: isFemale ? '#A83246' : 'Sin Labial',
      blushColor: isFemale ? '#D47385' : 'Sin Rubor'
    },
    wardrobes: autoWardrobes,
    role: input.role,
    subRole: input.subRole || undefined,
    hybridRoleTitle: input.subRole ? computeRoleHybrid(input.role, input.subRole, input.hybridRoleTitle).hybridTitle : undefined,
    styleVisual: input.styleVisual,
    subStyleVisual: input.subStyleVisual || undefined,
    styleFusionTitle: input.subStyleVisual ? computeStyleFusion(input.styleVisual, input.subStyleVisual).fusedTitle : undefined,
    armor: {
      type: roleAttire?.recommendedOutfitType || 'O2 Media / Aventurero (Cuero, lana gruesa, lino endurecido)',
      pieces: roleAttire?.slots?.map(s => s.pieces[0] || '') || [],
      material: roleAttire?.materials?.[0] || 'M1 Acero común',
      finish: roleAttire?.finishes?.[0] || 'F2 Mate'
    },
    equipment: {
      weapons: [defaultWeapon],
      weaponGrips: ['G1 Empuñadura a Una Mano'],
      bags: [defaultBag],
      bagSizes: ['M2 Mediana (Cinturón)'],
      bagClosures: ['C1 Hebilla Metálica'],
      items: [defaultItem]
    },
    orientalFantasy: input.styleVisual === 'Fantasía Oriental' ? {
      tradition: 'Tradición Imperial Hanfu & Wuxia',
      armorPieces: ['Hombreras Lamelares Dragón'],
      culturalAccessories: ['Horquilla de Jade Tallado', 'Borla de Seda Carmesí'],
      spiritualMotif: 'Dragón Celestial de Nueve Olas',
      silkPattern: 'Brocado Imperial con Hilos de Oro',
      jadeAccentColor: 'Jade Verde Esmeralda',
      energyAura: 'Aura Dorada Qi de Espada',
      weaponStyle: 'Jian / Espada Recta Cultivadora'
    } : {
      tradition: '',
      armorPieces: [],
      culturalAccessories: [],
      spiritualMotif: '',
      silkPattern: '',
      jadeAccentColor: '',
      energyAura: '',
      weaponStyle: ''
    },
    background: {
      backstory: input.backstory || `Nacido/a bajo la influencia del reino, ${input.name || 'este personaje'} ha forjado su camino dominando el rol de ${input.role}. Su fisonomía de ${raceName} y su mentalidad ${input.archetype} le otorgan una presencia inconfundible ante aliados y rivales.`,
      motivation: input.motivation || 'Alcanzar la maestría en su disciplina y salvaguardar sus principios morales.',
      secret: input.secret || 'Mantiene oculto un linaje o acontecimiento que podría alterar el equilibrio de fuerzas.',
      coreValues: input.coreValues,
      relationships: dynBackground.customSuggestedRelationships.slice(0, 3).map((r, i) => ({
        id: `rel-auto-${Date.now()}-${i}`,
        targetCharacterName: r.targetCharacterName,
        relationshipType: r.relationshipType,
        interactionDynamic: r.interactionDynamic,
        feelingsTowards: r.feelingsTowards,
        opinionOn: r.opinionOn
      })),
      advancedCustomization: {
        voiceTone: dynBackground.adaptedVoiceTone || 'Barítono sereno y refinado',
        speechStyle: dynBackground.adaptedSpeechStyle || 'Registro formal y analítico',
        catchphrasesOrIdioms: dynBackground.adaptedCatchphrase || '«Por mi convicción y mi honor.»',
        skills: ['Esgrima y combate táctico', 'Erudición y diplomacia', 'Percepción de amenazas'],
        habitsAndMannerisms: dynBackground.adaptedHabits,
        specificInteractions: {
          withAuthority: dynBackground.adaptedBehaviors.withAuthority,
          withPeers: dynBackground.adaptedBehaviors.withPeers,
          withFriends: dynBackground.adaptedBehaviors.withFriends,
          withSubordinates: dynBackground.adaptedBehaviors.withSubordinates,
          withStrangers: dynBackground.adaptedBehaviors.withStrangers,
          withEnemies: dynBackground.adaptedBehaviors.withEnemies
        }
      }
    },
    validationLogs: []
  };

  return finalCharacter;
}
