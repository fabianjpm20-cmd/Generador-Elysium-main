import { UnifiedParticipant } from './characterLogicEngine';
import { analyzeSemanticSubtext } from './somaticCognitiveEngine';
import { retrieveKnowledge } from './localKnowledgeLibrary';
import { LocalLLM, LLMResponse, ReasoningStep, generateReasoningChain } from './localLLM';

// ================================================================
// MOTOR DE AGENTES AUTÓNOMOS & TERMINAL LÓGICO OFFLINE
// Proporciona a cada Acompañante Principal (personaje secundario)
// su propio bot/agente con lógica, memoria episódica, humor dinámico,
// objetivos internos y capacidad de interactuar/reaccionar offline.
// ================================================================

export interface AgentPerceivedRelation {
  affinity: number; // -100 a 100
  trust: number;    // 0 a 100
  opinion: string;
}

export interface AgentEpisodicMemoryEvent {
  turn: number;
  speakerName: string;
  summary: string;
  reactionType: 'acuerdo' | 'objeción' | 'precaución' | 'aprecio' | 'curiosidad' | 'neutral';
  timestamp: string;
}

export interface AgentInnerThought {
  thought: string;
  timestamp: string;
  trigger: string;
}

export interface AgentLogicalMemory {
  agentId: string;
  agentName: string;
  currentMood: 'Sereno' | 'Alerta' | 'Intrigado' | 'Pensativo' | 'Cauto' | 'Divertido' | 'Agradecido' | 'Desafiante' | 'Resolutivo';
  innerGoal: string;
  affinityWithUser: number; // 0 a 100
  trustLevel: number;       // 0 a 100
  perceivedRelationships: Record<string, AgentPerceivedRelation>;
  episodicEvents: AgentEpisodicMemoryEvent[];
  innerMonologueLog: AgentInnerThought[];
  autonomousBanterEnabled: boolean;
  lastReactionTurn: number;
}

// Inicializar memoria lógica e independiente para un agente en sala
export function initAgentLogicalMemory(
  agent: UnifiedParticipant,
  otherAgents: UnifiedParticipant[],
  protagonistName: string
): AgentLogicalMemory {
  // Derivar objetivo interno del rol y motivaciones
  let innerGoal = 'Observar el entorno y mantener la cohesión del grupo.';
  if (agent.motivations && agent.motivations.length > 0) {
    innerGoal = agent.motivations[0];
  } else if (agent.role?.toLowerCase().includes('diplomát') || agent.role?.toLowerCase().includes('erudito') || agent.role?.toLowerCase().includes('noble')) {
    innerGoal = 'Descifrar intenciones ocultas y preservar la ventaja diplomática del grupo.';
  } else if (agent.role?.toLowerCase().includes('guard') || agent.role?.toLowerCase().includes('protector') || agent.role?.toLowerCase().includes('guerrer') || agent.role?.toLowerCase().includes('explorad')) {
    innerGoal = 'Vigilar accesos, anticipar emboscadas y salvaguardar a los aliados.';
  } else if (agent.role?.toLowerCase().includes('mago') || agent.role?.toLowerCase().includes('místic') || agent.role?.toLowerCase().includes('arcano')) {
    innerGoal = 'Sondear las corrientes energéticas y vigilar anomalías arcanas en la zona.';
  }

  // Derivar humor inicial
  let initialMood: AgentLogicalMemory['currentMood'] = 'Sereno';
  const personalityLower = (agent.personality || '').toLowerCase();
  if (personalityLower.includes('alerta') || personalityLower.includes('taciturn') || personalityLower.includes('caut')) {
    initialMood = 'Cauto';
  } else if (personalityLower.includes('curios') || personalityLower.includes('analític') || personalityLower.includes('perspicaz')) {
    initialMood = 'Intrigado';
  }

  // Relaciones iniciales con otros acompañantes
  const relations: Record<string, AgentPerceivedRelation> = {};
  for (const other of otherAgents) {
    if (other.id && other.id !== agent.id) {
      relations[other.id] = {
        affinity: 50,
        trust: 50,
        opinion: `Compañero en la expedición. Observo su desempeño como ${other.role || 'aliado'}.`
      };
    }
  }

  const initialThought: AgentInnerThought = {
    thought: `Nos encontramos en este recinto junto a ${protagonistName}. Mantendré la atención fija en mis deberes y en las intenciones del grupo.`,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    trigger: 'Inicio de interacción'
  };

  return {
    agentId: agent.id || `agent-${agent.name.toLowerCase().replace(/\s+/g, '-')}`,
    agentName: agent.name,
    currentMood: initialMood,
    innerGoal,
    affinityWithUser: agent.affinity || 55,
    trustLevel: 50,
    perceivedRelationships: relations,
    episodicEvents: [],
    innerMonologueLog: [initialThought],
    autonomousBanterEnabled: true,
    lastReactionTurn: 0
  };
}

// Analizador semántico-heurístico de texto offline
export interface TextSemanticAnalysis {
  isDirectAddress: boolean;
  hasDangerKeyword: boolean;
  hasMagicKeyword: boolean;
  hasDiplomacyKeyword: boolean;
  hasAffectionKeyword: boolean;
  isQuestion: boolean;
  sentiment: 'positivo' | 'negativo' | 'alerta' | 'curioso' | 'neutro';
}

export function analyzeMessageOffline(text: string, agentName: string): TextSemanticAnalysis {
  const lower = text.toLowerCase();
  const nameParts = agentName.toLowerCase().split(' ');

  const isDirectAddress = nameParts.some(part => part.length > 2 && lower.includes(part));

  const dangerWords = ['peligro', 'enemigo', 'trampa', 'emboscada', 'cuidado', 'arma', 'monstruo', 'muerte', 'amenaza', 'sospech', 'atacar', 'defensa', 'sangre', 'herido', 'vigil'];
  const hasDangerKeyword = dangerWords.some(w => lower.includes(w));

  const magicWords = ['magia', 'arcano', 'hechizo', 'runa', 'poder', 'pneuma', 'reliquia', 'portal', 'energía', 'éter', 'místico', 'sombra', 'luz', 'aura', 'vórtice'];
  const hasMagicKeyword = magicWords.some(w => lower.includes(w));

  const diplomacyWords = ['plan', 'estrategia', 'pacto', 'verdad', 'secreto', 'rumor', 'ley', 'noble', 'orden', 'honor', 'trato', 'alianza', 'consejo', 'palabra', 'destino'];
  const hasDiplomacyKeyword = diplomacyWords.some(w => lower.includes(w));

  const affectionWords = ['gracias', 'confío', 'juntos', 'amigo', 'leal', 'aprecio', 'valiente', 'descansa', 'noble', 'abrazo', 'cuidar', 'confianza', 'favorito'];
  const hasAffectionKeyword = affectionWords.some(w => lower.includes(w));

  const isQuestion = lower.includes('?') || lower.includes('¿') || lower.includes('qué opinas') || lower.includes('cómo') || lower.includes('dónde') || lower.includes('cuándo');

  let sentiment: TextSemanticAnalysis['sentiment'] = 'neutro';
  if (hasDangerKeyword) sentiment = 'alerta';
  else if (hasAffectionKeyword) sentiment = 'positivo';
  else if (isQuestion || hasMagicKeyword) sentiment = 'curioso';

  return {
    isDirectAddress,
    hasDangerKeyword,
    hasMagicKeyword,
    hasDiplomacyKeyword,
    hasAffectionKeyword,
    isQuestion,
    sentiment
  };
}

// Evaluación de si un agente específico desea intervenir o reaccionar espontáneamente
export function evaluateAgentReactionWillingness(
  agent: UnifiedParticipant,
  memory: AgentLogicalMemory,
  messageText: string,
  speakerName: string,
  speakerId?: string
): { shouldReact: boolean; willingnessScore: number; reactionTone: string; reason: string } {
  // Si el hablante es el propio agente, no reacciona a sí mismo
  if (speakerId === agent.id || speakerName === agent.name) {
    return { shouldReact: false, willingnessScore: 0, reactionTone: 'neutral', reason: 'Mensaje propio' };
  }

  const analysis = analyzeMessageOffline(messageText, agent.name);
  let score = 20; // Base willingness

  // Si fue nombrado directamente, la prioridad se dispara
  if (analysis.isDirectAddress) {
    score += 65;
  }

  // Si se menciona algo alineado con su arquetipo o rol
  const roleLower = (agent.role || '').toLowerCase();
  if (analysis.hasDangerKeyword && (roleLower.includes('protector') || roleLower.includes('guard') || roleLower.includes('explorad') || roleLower.includes('guerrer'))) {
    score += 45;
  }
  if (analysis.hasMagicKeyword && (roleLower.includes('mág') || roleLower.includes('místic') || roleLower.includes('arcano') || roleLower.includes('runa'))) {
    score += 45;
  }
  if (analysis.hasDiplomacyKeyword && (roleLower.includes('diplomát') || roleLower.includes('erudito') || roleLower.includes('noble'))) {
    score += 40;
  }

  // Pregunta abierta al grupo
  if (analysis.isQuestion && !analysis.isDirectAddress) {
    score += 25;
  }

  // Afinidad hacia el hablante
  if (speakerId && memory.perceivedRelationships[speakerId]) {
    const rel = memory.perceivedRelationships[speakerId];
    if (rel.affinity > 60) score += 15;
    if (rel.trust > 60) score += 10;
  } else {
    // Es el protagonista
    if (memory.affinityWithUser > 65) score += 15;
  }

  // Determinar tono de reacción
  let reactionTone = 'reflexión';
  if (analysis.hasDangerKeyword) reactionTone = 'precaución marcial';
  else if (analysis.hasMagicKeyword) reactionTone = 'perspicacia arcana';
  else if (analysis.hasAffectionKeyword) reactionTone = 'calidez y lealtad';
  else if (analysis.hasDiplomacyKeyword) reactionTone = 'ponderación analítica';

  return {
    shouldReact: score >= 50,
    willingnessScore: score,
    reactionTone,
    reason: analysis.isDirectAddress
      ? 'Dirigido directamente a este agente'
      : analysis.hasDangerKeyword
      ? 'Alerta o situación táctica detectada'
      : analysis.hasMagicKeyword
      ? 'Afinidad con temas arcanos'
      : 'Participación contextual'
  };
}

// Generación local 100% OFFLINE de la intervención del agente
export async function generateOfflineAgentResponse(params: {
  agent: UnifiedParticipant;
  memory: AgentLogicalMemory;
  lastMessageText: string;
  speakerName: string;
  protagonist: UnifiedParticipant;
  otherCompanions: UnifiedParticipant[];
  place: {
    name: string;
    zoneName?: string;
    weather?: string;
    hour?: string;
    details?: string;
  };
  activeLaws?: string[];
  tone?: string;
}): { text: string; updatedMemory: AgentLogicalMemory; innerThought: string } {
  const {
    agent,
    memory,
    lastMessageText,
    speakerName,
    protagonist,
    otherCompanions,
    place,
    activeLaws = []
  } = params;

  const analysis = analyzeMessageOffline(lastMessageText, agent.name);
  const semantic = analyzeSemanticSubtext(lastMessageText, agent.name);
  const nowTimestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  // 1. Determinar gesticulación física conforme al SISTEMA MAESTRO DE ROL Y NARRACIÓN (Cadena Física, masa, telas, calzado)
  let gesture = '';
  const habits = agent.habitsAndMannerisms || [];
  const physicalActions = [
    'afianza su calzado contra el suelo distribuyendo el peso con elegancia controlada, mientras el dobladillo de sus prendas cae con un suave roce tras el movimiento',
    'desplaza sutilmente su centro de gravedad de una pierna a otra; la tela de sus vestiduras oscila con leve inercia antes de ceñirse de nuevo a su silueta',
    'mantiene la postura erguida y los hombros firmes; la tensión contenida en sus músculos y el contacto de sus accesorios afianzan su presencia física en la sala',
    'da un paso medido hacia adelante sintiendo la tracción de sus botas contra la superficie, mientras sus manos ajustan con serenidad el cinto de su indumentaria',
    'inclina levemente el torso con aplomo; la caída de su cabello y el peso de sus ropas acompañan la cadencia de su respiración pausada'
  ];

  if (habits.length > 0 && Math.random() > 0.5) {
    gesture = `${habits[Math.floor(Math.random() * habits.length)]}, afianzando su postura mientras siente el roce de sus prendas`;
  } else {
    const roleLower = (agent.role || '').toLowerCase();
    if (roleLower.includes('diplomát') || roleLower.includes('erudito') || roleLower.includes('noble')) {
      const g = [
        'acomoda el borde de sus vestiduras sintiendo el peso de las telas, distribuyendo su peso entre los talones con serenidad cortesana',
        'inclina levemente la cabeza y el torso mientras analiza cada matiz, dejando que sus prendas caigan con naturalidad a sus costados',
        'junta las yemas de sus dedos en un gesto meditado y elocuente, con los hombros relajados y la respiración acompasada',
        'sostiene la mirada con calidez calculada antes de articular palabra, mientras sus pies mantienen una estabilidad inquebrantable'
      ];
      gesture = g[Math.floor(Math.random() * g.length)];
    } else if (roleLower.includes('protector') || roleLower.includes('explorad') || roleLower.includes('guerrer')) {
      const g = [
        'apoya con naturalidad su diestra sobre el pomo del cinto y otea el perímetro, sintiendo la firmeza del calzado y la tensión de sus piernas',
        'mantiene la postura erguida y en guardia activa, distribuyendo el peso para reaccionar al menor estímulo mientras sus prendas se tensan',
        'asiente con firmeza serena, sin apartar la vista de los accesos, mientras una leve exhalación distiende sus hombros anchos',
        'da un paso firme al frente, interponiendo su presencia física y sintiendo el peso de su equipo en perfecto equilibrio'
      ];
      gesture = g[Math.floor(Math.random() * g.length)];
    } else if (roleLower.includes('mág') || roleLower.includes('místic') || roleLower.includes('arcano')) {
      const g = [
        'traza un semicírculo sutil en el aire; las mangas de su atuendo se mecen con una leve inercia mientras percibe las corrientes de éter',
        'cierra un instante los párpados, sintiendo la gravedad anclada en sus apoyos y sintonizando su cuerpo con la vibración del recinto',
        'observa los reflejos de luz con una leve oscilación de hombros, dejando que sus accesorios metálicos tintineen con discreción',
        'acaricia el talismán que pende de su cuello con pausada devoción, afianzando la espalda recta con gracia natural'
      ];
      gesture = g[Math.floor(Math.random() * g.length)];
    } else {
      gesture = physicalActions[Math.floor(Math.random() * physicalActions.length)];
    }
  }

  // 2. Componer el núcleo dialógico según el contexto y el análisis semántico
  let speech = '';
  let innerThoughtText = '';
  let newMood: AgentLogicalMemory['currentMood'] = memory.currentMood;
  let affinityDelta = 0;
  let trustDelta = 0;
  let llmResponse: LLMResponse | null = null;
  let reasoningSteps: ReasoningStep[] = [];
  
  // Integración con LLM Local para respuestas mejoradas
  if (params.tone !== 'offline_only') {
    try {
      const llm = new LocalLLM();
      
      // Crear perfil de personaje para el agente
      const agentProfile: any = {
        name: agent.name,
        role: agent.role || 'Compañero',
        personality: agent.personality || 'equilibrada',
        motivations: agent.motivations || ['Proteger al grupo'],
        coreValues: agent.coreValues || 'Lealtad, Honor',
        moralAlignment: agent.moralAlignment || 'Neutral Bondadoso',
        greatestFear: agent.greatestFear || 'Fracasar en la misión',
        somatic: { heightAndBuild: 'Complexión atlética' },
        wardrobe: { garmentsList: [], shoesAndFootwear: 'Botines de viaje' },
      };
      
      llm.setCharacterProfile(agentProfile);
      llm.setSemanticAnalysis(semantic);
      
      // Generar respuesta usando el LLM
      llmResponse = await llm.generateResponse(lastMessageText);
      reasoningSteps = generateReasoningChain(lastMessageText, llm['context'], agentProfile);
      
      // Si el LLM devuelve una respuesta válida con alta confianza, usarla
      if (llmResponse && llmResponse.confidence > 0.8) {
        speech = llmResponse.text;
        innerThoughtText = `LLM Analysis: ${reasoningSteps.map(s => s.thought).join(' | ')}`;
      }
    } catch (error) {
      // Si falla el LLM, usar el sistema original
      console.warn('[Agent LLM Fallback] Usando respuestas deterministas:', error);
    }
  }

  const otherCompanionNames = otherCompanions.map(c => c.name).filter(n => n !== agent.name);
  const otherMention = otherCompanionNames.length > 0 ? otherCompanionNames[0] : null;

  if (semantic.intent === 'wardrobe_somatic_inquiry') {
    newMood = 'Pensativo';
    affinityDelta = +2;
    trustDelta = +2;
    innerThoughtText = `Indagan sobre mi presencia corpórea y mis ropajes. Sé cómo cada costura y mi calzado definen mi equilibrio aquí.`;
    speech = `«Porto prendas confeccionadas para resistir las exigencias de mi deber. Las costuras se ciñen con exactitud sin restar movilidad, y el peso de las telas me ayuda a afianzar el centro de gravedad. Cuando se viaja por territorios inciertos, el atuendo es tanto protección como declaración de intenciones.»`;
  } else if (semantic.intent === 'philosophical_debate') {
    newMood = 'Pensativo';
    affinityDelta = +3;
    trustDelta = +2;
    innerThoughtText = `Un desafío ético profundo. Mi alineación (${agent.moralAlignment || 'Leal'}) y valores (${agent.coreValues || 'Honor'}) guían mi respuesta.`;
    speech = `«Poner sobre la mesa cuestiones morales exige franqueza, ${speakerName}. Para mí, actuar con integridad y respetar nuestros principios esenciales no es negociable; renunciar a lo que creemos por conveniencia momentánea destruiría el cimiento de nuestra alianza.»`;
  } else if (semantic.intent === 'order_or_command') {
    if ((agent.moralAlignment || '').toLowerCase().includes('caótico') || (agent.moralAlignment || '').toLowerCase().includes('rebelde')) {
      newMood = 'Pensativo';
      affinityDelta = -1;
      innerThoughtText = `Intentan imponerme órdenes directas. Mi espíritu no tolera yugos arbitrarios.`;
      speech = `«Camino a tu lado por decisión compartida y respeto, ${speakerName}, no como subordinado. Pondero tus sugerencias cuando tienen fundamento táctico, pero nadie gobierna mis pasos salvo mi propia conciencia.»`;
    } else {
      newMood = 'Sereno';
      affinityDelta = +1;
      trustDelta = +1;
      innerThoughtText = `Acepto la dirección estratégica siempre que preserve la seguridad y el honor del grupo.`;
      speech = `«Entendido, ${speakerName}. Si esa es la directriz que mejor salvaguarda nuestros objetivos en ${place.name}, coordinaré mis movimientos para asegurar su cumplimiento.»`;
    }
  } else if (analysis.hasDangerKeyword || semantic.intent === 'combat_alert') {
    newMood = 'Alerta';
    affinityDelta = +2;
    trustDelta = +3;
    innerThoughtText = `La tensión se eleva. Debo vigilar el flanco de ${speakerName} y no permitir que un descuido nos cueste caro en ${place.name}.`;

    if (agent.role?.toLowerCase().includes('protector') || agent.role?.toLowerCase().includes('explorad')) {
      speech = `«Coincido con la cautela, ${speakerName}. En un sitio como ${place.name}, con esta ${place.weather?.toLowerCase() || 'atmósfera'}, los ecos pueden traicionar nuestra posición antes de lo previsto. Yo mantendré la retaguardia asegurada.»`;
    } else if (agent.role?.toLowerCase().includes('diplomát') || agent.role?.toLowerCase().includes('erudito')) {
      speech = `«La prudencia nos evitará un desenlace hostil, ${speakerName}. Antes de desenvainar o precipitarnos, conviene medir si el adversario busca provocarnos o simplemente tantear nuestro temple en este terreno.»`;
    } else {
      speech = `«Siento la alteración en el ambiente. Sea lo que sea lo que acecha en ${place.name}, no nos hallará desprevenidos si coordinamos nuestras fuerzas.»`;
    }
  } else if (analysis.hasMagicKeyword) {
    newMood = 'Intrigado';
    affinityDelta = +3;
    innerThoughtText = `El flujo arcano aquí tiene peculiaridades. ${speakerName} toca un punto neurálgico que resuena con mi comprensión mística.`;

    if (agent.role?.toLowerCase().includes('mág') || agent.role?.toLowerCase().includes('místic')) {
      speech = `«Tus palabras tocan fibras profundas, ${speakerName}. Las líneas de poder en ${place.name} laten al compás de lo que acabas de mencionar. Si sabemos canalizarlo, la balanza se inclinará a nuestro favor.»`;
    } else {
      speech = `«Aunque los enigmas de esa naturaleza escapan a la vista ordinaria, reconozco la gravedad de lo que expones, ${speakerName}. Cualquier alteración mística aquí debe ser tratada con sumo respeto.»`;
    }
  } else if (analysis.hasAffectionKeyword || semantic.intent === 'emotional_intimacy') {
    newMood = 'Agradecido';
    affinityDelta = +4;
    trustDelta = +4;
    innerThoughtText = `Siento sinceridad en las palabras de ${speakerName}. Es reconfortante saber que caminamos bajo un mismo código de lealtad.`;

    speech = `«Agradezco tus palabras con el alma, ${speakerName}. Compartir este viaje contigo y con quienes nos acompañan aquí le otorga verdadero sentido a cuanto defendemos.»`;
  } else if (analysis.isQuestion || semantic.questionNature) {
    newMood = 'Pensativo';
    affinityDelta = +2;
    innerThoughtText = `Una pregunta directa. Responderé con total fidelidad a mis convicciones morales (${agent.moralAlignment || 'Neutral'}) y a lo que observo aquí.`;

    if (agent.role?.toLowerCase().includes('diplomát')) {
      speech = `«Si me permites ponderar tu interrogante, ${speakerName}: cada camino encierra una promesa y un peaje. En este enclave de ${place.name}, lo más sensato es observar las normas tácitas del lugar antes de fijar nuestro siguiente paso.»`;
    } else if (agent.role?.toLowerCase().includes('explorad') || agent.role?.toLowerCase().includes('protector')) {
      speech = `«Mi respuesta es práctica, ${speakerName}: mientras conservemos la iniciativa y no nos dispersemos, superaremos cualquier obstáculo. Eso es lo que dicta la experiencia.»`;
    } else {
      speech = `«Desde mi perspectiva, ${speakerName}, la clave radica en no perder de vista por qué vinimos a ${place.name}. Lo que decidamos ahora marcará el rumbo de las próximas horas.»`;
    }
  } else {
    // Diálogo reflexivo general
    newMood = 'Sereno';
    affinityDelta = +1;
    innerThoughtText = `El diálogo fluye con naturalidad. Observo cómo se desenvuelve la charla entre ${speakerName}${otherMention ? ` y ${otherMention}` : ''}.`;

    if (otherMention && Math.random() > 0.4) {
      speech = `«Comprendo tu punto, ${speakerName}. ${otherMention}, ¿tienes la misma impresión al contemplar este entorno?»`;
    } else {
      speech = `«Escucho con atención tus palabras, ${speakerName}. Estando en ${place.name} a esta hora, cualquier detalle adquiere un peso que no debemos subestimar.»`;
    }
  }

  // Consulta al corpus ontológico local (sin red ni latencia)
  const localKnowledge = retrieveKnowledge(lastMessageText);
  let knowledgeRemark = '';
  if (localKnowledge.length > 0 && Math.random() > 0.45) {
    const topEntry = localKnowledge[0];
    if (topEntry.domain === 'physics') {
      knowledgeRemark = ` Cuidado con el retraso inercial y el efecto en el suelo si nos movemos deprisa.`;
      innerThoughtText += ` (Percibo la física en juego: ${topEntry.summary})`;
    } else if (topEntry.domain === 'clothing') {
      knowledgeRemark = ` Las telas y el calzado acusarán las condiciones de este lugar.`;
      innerThoughtText += ` (Considerando materiales: ${topEntry.summary})`;
    } else if (topEntry.domain === 'architecture' || topEntry.domain === 'geology') {
      knowledgeRemark = ` La piedra y el suelo de ${place.name} delatan cualquier pisada en falso.`;
      innerThoughtText += ` (Estructura espacial: ${topEntry.summary})`;
    } else if (topEntry.domain === 'culture') {
      knowledgeRemark = ` Las normas tácitas y el respeto a los presentes son vitales aquí.`;
      innerThoughtText += ` (Protocolo cultural: ${topEntry.summary})`;
    }
  }

  // Si hay leyes activas en el Worldbuilding, incorporar una sutil alusión
  if (activeLaws.length > 0 && Math.random() > 0.6) {
    const lawSample = activeLaws[0];
    speech += ` Además, recordemos siempre el precepto que rige estas tierras: *${lawSample.length > 80 ? lawSample.slice(0, 77) + '...' : lawSample}*.`;
  } else if (knowledgeRemark) {
    speech += knowledgeRemark;
  }

  const fullDialogueText = `*${gesture}.* ${speech}`;

  // Actualizar memoria episódica
  const newEvent: AgentEpisodicMemoryEvent = {
    turn: memory.episodicEvents.length + 1,
    speakerName,
    summary: lastMessageText.slice(0, 90),
    reactionType: analysis.hasDangerKeyword ? 'precaución' : analysis.hasAffectionKeyword ? 'aprecio' : analysis.isQuestion ? 'curiosidad' : 'acuerdo',
    timestamp: nowTimestamp
  };

  const newThought: AgentInnerThought = {
    thought: innerThoughtText,
    timestamp: nowTimestamp,
    trigger: `${speakerName}: "${lastMessageText.slice(0, 45)}..."`
  };

  const updatedMemory: AgentLogicalMemory = {
    ...memory,
    currentMood: newMood,
    affinityWithUser: Math.min(100, Math.max(0, memory.affinityWithUser + affinityDelta)),
    trustLevel: Math.min(100, Math.max(0, memory.trustLevel + trustDelta)),
    episodicEvents: [...memory.episodicEvents, newEvent].slice(-30),
    innerMonologueLog: [...memory.innerMonologueLog, newThought].slice(-25),
    lastReactionTurn: memory.episodicEvents.length + 1
  };

  return {
    text: fullDialogueText,
    updatedMemory,
    innerThought: innerThoughtText,
    llmResponse,
    reasoningSteps,
  };
}

// Diálogo autónomo cruzado entre dos acompañantes (Banter entre Agentes)
export function generateInterAgentBanterOffline(params: {
  agentA: UnifiedParticipant;
  memoryA: AgentLogicalMemory;
  agentB: UnifiedParticipant;
  memoryB: AgentLogicalMemory;
  topicText: string;
  placeName: string;
}): {
  responseA: { text: string; updatedMemory: AgentLogicalMemory };
  responseB: { text: string; updatedMemory: AgentLogicalMemory };
} {
  const { agentA, memoryA, agentB, memoryB, topicText, placeName } = params;
  const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  // Agente A interpela o reflexiona hacia Agente B sobre el tema
  const textA = `*Mira hacia ${agentB.name} con semblante meditabundo.* «${agentB.name}, conoces bien las complejidades de este territorio. A la luz de lo que estamos discutiendo en ${placeName}, ¿cuál sería tu sugerencia para no dar un paso en falso?»`;

  // Agente B responde con su carácter propio
  let textB = '';
  const roleBLower = (agentB.role || '').toLowerCase();
  if (roleBLower.includes('protector') || roleBLower.includes('explorad') || roleBLower.includes('guerrer')) {
    textB = `*Asiente con gravedad hacia ${agentA.name} y ajusta su postura.* «Mi consejo es directo, ${agentA.name}: no confiemos en la calma aparente de ${placeName}. Vigilemos las espaldas del grupo y actuemos con decisión en cuanto se presente la menor discordia.»`;
  } else if (roleBLower.includes('diplomát') || roleBLower.includes('erudito')) {
    textB = `*Esboza una leve sonrisa comprensiva.* «Coincido en que la cautela es oro, estimado ${agentA.name}. Sin embargo, más que preparar las armas, sugiero escuchar los silencios de este lugar. En ${placeName}, quien sabe negociar gana antes de derramar una sola gota.»`;
  } else {
    textB = `*Inclina la cabeza con serenidad mística.* «Las respuestas ya flotan en este recinto, ${agentA.name}. Solo debemos alinearnos con la verdad del momento y respaldar las elecciones de nuestro líder.»`;
  }

  // Actualizar memorias mutuas
  const relA = memoryA.perceivedRelationships[agentB.id || ''] || { affinity: 50, trust: 50, opinion: '' };
  const updatedMemoryA: AgentLogicalMemory = {
    ...memoryA,
    perceivedRelationships: {
      ...memoryA.perceivedRelationships,
      [agentB.id || 'b']: {
        affinity: Math.min(100, relA.affinity + 2),
        trust: Math.min(100, relA.trust + 2),
        opinion: `Intercambio de pareceres constructivo con ${agentB.name} en ${placeName}.`
      }
    },
    innerMonologueLog: [
      ...memoryA.innerMonologueLog,
      {
        thought: `He consultado el criterio de ${agentB.name}. Su perspectiva complementa mi visión de la escena.`,
        timestamp: time,
        trigger: `Diálogo cruzado con ${agentB.name}`
      }
    ].slice(-25)
  };

  const relB = memoryB.perceivedRelationships[agentA.id || ''] || { affinity: 50, trust: 50, opinion: '' };
  const updatedMemoryB: AgentLogicalMemory = {
    ...memoryB,
    perceivedRelationships: {
      ...memoryB.perceivedRelationships,
      [agentA.id || 'a']: {
        affinity: Math.min(100, relB.affinity + 2),
        trust: Math.min(100, relB.trust + 2),
        opinion: `Valoro que ${agentA.name} busque mi consejo ante este dilema.`
      }
    },
    innerMonologueLog: [
      ...memoryB.innerMonologueLog,
      {
        thought: `He respondido a la consulta de ${agentA.name}. Nuestra coordinación fortalece al grupo.`,
        timestamp: time,
        trigger: `Respuesta a ${agentA.name}`
      }
    ].slice(-25)
  };

  return {
    responseA: { text: textA, updatedMemory: updatedMemoryA },
    responseB: { text: textB, updatedMemory: updatedMemoryB }
  };
}
