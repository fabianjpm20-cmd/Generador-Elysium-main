import { CharacterState, WorldPlace, WorldBuildingConfig, CharacterRelationship, CharacterAITrainingConfig } from '../types';
import { cleanVal } from './characterPromptUtils';
import { getSavedCharacters, getCharacterVariantGroups } from './libraryStorage';
import {
  analyzeSemanticSubtext,
  performCognitiveAppraisal,
  simulateSomatosensoryDynamics,
  synthesizeLiteraryCharacterResponse
} from './somaticCognitiveEngine';

// =========================================================================
// MOTOR DE CONCIENCIA, AUTONOMÍA Y MEMORIA DEL PERSONAJE
// Proporciona autoconciencia somática, percepción de vestimenta activa,
// reconocimiento de versiones alternas (pasado y rol/vestuario),
// memoria relacional e iniciativa autónoma tanto online (IA) como offline.
// =========================================================================

export interface SomaticAwarenessData {
  heightAndBuild: string;
  skinAndMarks: string;
  eyesAndLook: string;
  hairStyle: string;
  facialAndVoice: string;
  appendices: string;
  intimateDetails?: string;
  tactileBodyState: string;
}

export interface WardrobeAwarenessData {
  summary: string;
  garmentsList: Array<{
    name: string;
    layer?: string;
    fabrics?: string;
    colors?: string;
    feel?: string;
  }>;
  shoesAndFootwear: string;
  jewelryAndRelics: string;
  armorAndProtection: string;
  tactileSensation: string; // peso de las prendas, roce de telas, movilidad
}

export interface AlternateVersionsAwarenessData {
  pastVersionsSummary: string;
  alternateRoleWardrobeSummary: string;
  canChangeWardrobeAndRole: boolean;
  knownVariantsInLibrary: Array<{
    name: string;
    label: string;
    relationType?: string;
    description?: string;
  }>;
  philosophicalView: string;
}

export interface SocialBondsAwarenessData {
  relationships: Array<{
    targetName: string;
    type: string;
    dynamic: string;
    feelings?: string;
    opinion?: string;
  }>;
  specificHabits: {
    withAuthority?: string;
    withFriends?: string;
    withEnemies?: string;
    withStrangers?: string;
  };
}

export interface CharacterConsciousnessProfile {
  characterId: string;
  name: string;
  rootName: string;
  role: string;
  subRole?: string;
  race: string;
  faction?: string;
  moralAlignment: string;
  coreValues: string;
  motivations: string[];
  greatestFear: string;
  fatalFlaws: string[];
  personality: string;
  personalityTraits: string[];
  habitsAndCadence: string[];
  dialogueExcerpt?: string;
  
  // Conciencias especializadas
  somatic: SomaticAwarenessData;
  wardrobe: WardrobeAwarenessData;
  alternateVersions: AlternateVersionsAwarenessData;
  social: SocialBondsAwarenessData;
  trainingConfig: CharacterAITrainingConfig;
}

export interface ConsciousResponse {
  reply: string;
  innerMonologue: string;
  somaticPerception: string;
  alternateVersionReflection?: string;
  autonomousAction: string;
  initiativeType: 'somatic_gesture' | 'wardrobe_adjustment' | 'strategic_proposal' | 'introspective_query' | 'curious_examination';
  isAutonomousInitiative?: boolean;
  isOfflineFallback?: boolean;
  llmResponse?: any;
  reasoningChain?: any[];
  confidence?: number;
}

export const DEFAULT_AI_TRAINING_CONFIG: CharacterAITrainingConfig = {
  autonomyLevel: 75,
  somaticAwarenessLevel: 'inmersivo',
  wardrobeAndRoleAwareness: true,
  alternateVersionsAwareness: true,
  environmentReactivity: 'atento',
  trainingDirectives: [
    'Actuar con iniciativa propia y proactividad sin esperar órdenes pasivas.',
    'Ser consciente en todo momento del cuerpo propio, altura y rasgos físicos distintivos.',
    'Percibir con nitidez las telas, peso y ajuste de la vestimenta que llevas puesta.',
    'Reconocer tus versiones alternas: tu pasado vivido y tu versión alternativa de Rol/Vestuario como atuendos que puedes cambiar.',
    'Mantener absoluta fidelidad a tus Cores, Valores Morales y Defecto Trágico.'
  ]
};

/**
 * Extrae y sintetiza el perfil de conciencia total de un CharacterState
 */
export function buildCharacterConsciousnessProfile(
  state: CharacterState,
  options?: {
    customPlace?: WorldPlace | null;
    customWorld?: WorldBuildingConfig | null;
  }
): CharacterConsciousnessProfile {
  const name = cleanVal(state.name, false) || 'Personaje';
  const rootName = name.replace(/\s*[\(\[\{].*?[\)\]\}]/g, '').trim() || name;
  const role = cleanVal(state.role, false) || 'Aventurero';
  const subRole = cleanVal(state.subRole, false);
  const race = cleanVal(state.raceName, false) || 'Humano';
  const faction = cleanVal(state.background?.factionOrFaith, false);
  const coreValues = cleanVal(state.background?.coreValues, false) || 'Honor, Lealtad y Superación';
  
  // Moral alignment & flaws
  const moralAlignment = state.liteAgent?.moralAlignment || 'Neutral Bondadoso';
  const flaws = Array.isArray(state.background?.fatalFlaws) && state.background.fatalFlaws.length > 0
    ? state.background.fatalFlaws.map(f => cleanVal(f, false)).filter(Boolean)
    : (state.background?.fatalFlawOrVulnerability ? [cleanVal(state.background.fatalFlawOrVulnerability, false)] : ['Orgullo o temor a fallar a los suyos']);
  const greatestFear = state.liteAgent?.greatestFear || flaws[0] || 'La traición y la pérdida de sus ideales';

  // Motivations
  const motivations = (state.liteAgent?.motivations && state.liteAgent.motivations.length > 0)
    ? state.liteAgent.motivations
    : (state.background?.motivation ? [cleanVal(state.background.motivation, false)] : ['Cumplir su deber y encontrar su lugar en el mundo']);

  // Personality
  const personality = cleanVal(state.personality, false) || 'Atento, perspicaz y reflexivo';
  const personalityTraits = (state.personalityTraits || []).map(t => cleanVal(t, false)).filter(Boolean);
  const habitsAndCadence = [
    ...(state.background?.advancedCustomization?.habitsAndMannerisms || [])
  ].filter(Boolean);

  // 1. Conciencia Somática / Corporal
  const anat = state.anatomy || ({} as any);
  const facial = state.facial || ({} as any);
  const hairState = state.hair || ({} as any);
  const height = anat.height ? `${anat.height}` : 'Estatura media armónica';
  const build = anat.complexion || 'Complexión armónica';
  const chest = anat.breastDevelopment ? `Pecho: ${anat.breastDevelopment}` : '';
  const waist = anat.waist ? `Cintura: ${anat.waist}` : '';
  const skin = anat.skinColor ? `Piel ${anat.skinColor}` : 'Piel suave y cuidada';
  
  // Marcas corporales
  const markTypes = state.appendices?.markTypes || [];
  const marksSummary = markTypes.length > 0
    ? `Marcas en el cuerpo: ${markTypes.join(', ')}.`
    : 'Piel limpia de cicatrices graves o marcas prominentes.';

  // Ojos y Mirada
  const eyes = `Ojos de color ${facial.eyeColor || 'ámbar/oscuro'}${facial.expression ? ` con expresión ${facial.expression}` : ''}${facial.irisGlow ? ' (destello radiante en el iris)' : ''}`;
  
  // Cabello
  const hair = `Cabello ${hairState.hairColor || 'oscuro'}, corte ${hairState.cut || 'natural'}, peinado estilo ${hairState.style || 'suelto'}${hairState.length ? ` y largo ${hairState.length}` : ''}`;
  
  // Rostro y Voz
  const voice = state.background?.advancedCustomization?.voiceTone || 'melódico y firme';
  const faceAndVoice = `Rostro de estructura ${facial.headShape || 'fina'}, labios ${facial.lips || 'naturales'}. Tono de voz: ${voice}.`;

  // Apéndices no humanos
  const horns = state.appendices?.hornsForm && !/ningun/i.test(state.appendices.hornsForm) ? `Cuernos: ${state.appendices.hornsForm}` : '';
  const wings = state.appendices?.wingsType && !/ningun/i.test(state.appendices.wingsType) ? `Alas: ${state.appendices.wingsType}` : '';
  const tails = state.appendices?.tailsType && !/ningun/i.test(state.appendices.tailsType) ? `Cola: ${state.appendices.tailsType}` : '';
  const ears = facial.earsBase && !/normal|humana/i.test(facial.earsBase) ? `Orejas: ${facial.earsBase}` : '';
  const appList = [horns, wings, tails, ears].filter(Boolean);
  const appendices = appList.length > 0 ? appList.join('; ') : 'Morfología humanoide estándar sin apéndices exóticos.';

  // Detalles íntimos NSFW si procede
  let intimateDetails: string | undefined = undefined;
  if (state.nsfw?.isNsfwEnabled) {
    intimateDetails = `Anatomía Íntima Consciente: Sensibilidad erógena en ${state.nsfw.bodySensitivities?.join(', ') || 'cuello y hombros'}. Personalidad íntima: ${state.nsfw.intimatePersonality || 'Sensible'}.`;
  }

  const tactileBodyState = `Siente la solidez de su cuerpo (${height}, ${build}). Su centro de gravedad y postura reflejan su entrenamiento como ${role}.`;

  const somatic: SomaticAwarenessData = {
    heightAndBuild: `${height}, ${build}. ${chest} ${waist}`.trim(),
    skinAndMarks: `${skin}. ${marksSummary}`,
    eyesAndLook: eyes,
    hairStyle: hair,
    facialAndVoice: faceAndVoice,
    appendices,
    intimateDetails,
    tactileBodyState
  };

  // 2. Conciencia de Vestuario y Ropas Activas
  const validWardrobes = (state.wardrobes || []).filter(w => Boolean(cleanVal(w.name, false)));
  const garmentsList = validWardrobes.map(w => ({
    name: w.name,
    layer: w.cut || 'Prenda principal',
    fabrics: w.material || 'Tela fina',
    colors: `${w.color || ''}`.trim(),
    feel: `Acabado ${w.finish || 'cuidado'}`
  }));

  const shoes = (validWardrobes.find(w => /bota|zapato|sandalia|calzado/i.test(w.name))?.name) || 'Calzado de viaje resistente';
  const jewelry = (state.equipment?.items || []).filter(i => /joya|colgante|anillo|amuleto|relicario|broche/i.test(i)).join(', ') || 'Broches de ajuste y adornos discretos';
  const armor = state.armor?.type && !/^ninguna?$/i.test(state.armor.type)
    ? `${state.armor.type} de ${state.armor.material || 'metal templado'}`
    : 'Sin armadura rígida (vestiduras civiles/flexibles)';

  const tactileSensation = garmentsList.length > 0
    ? `Siente el contacto directo de ${garmentsList.map(g => `${g.name} (${g.fabrics || 'tejido'})`).join(', ')}. Las telas acompañan su respiración y movimientos.`
    : 'Viste un atuendo ligero que le otorga total libertad de movimiento corporal.';

  const wardrobe: WardrobeAwarenessData = {
    summary: garmentsList.length > 0 ? garmentsList.map(g => g.name).join(', ') : 'Indumentaria estándar',
    garmentsList,
    shoesAndFootwear: shoes,
    jewelryAndRelics: jewelry,
    armorAndProtection: armor,
    tactileSensation
  };

  // 3. Conciencia de Versiones Alternas (Pasado, Futuro, Rol/Vestuario)
  const timeline = state.background?.narrativeTimeline?.milestones || [];
  const pastMilestones = timeline.slice(0, 3).map(m => `[${m.periodOrAge || m.era || 'Época pasada'}] ${m.title}: ${m.psychologicalEvolution || m.summary}`).join('; ');
  const pastVersionsSummary = pastMilestones || `Recuerda sus orígenes en ${state.background?.homelandOrDomain || 'su tierra natal'} y el camino que forjó su identidad actual como ${role}.`;

  // Buscar variantes asociadas en la biblioteca
  const allSaved = getSavedCharacters();
  const variantGroups = getCharacterVariantGroups(allSaved);
  const myGroup = variantGroups.find(g => 
    g.groupId === state.variantGroupId ||
    g.baseCharacter.id === state.id ||
    g.allEntries.some(e => e.id === state.id || extractClean(e.state?.name) === rootName)
  );

  const knownVariantsInLibrary: AlternateVersionsAwarenessData['knownVariantsInLibrary'] = [];
  if (myGroup) {
    myGroup.allEntries.forEach(entry => {
      if (entry.id !== state.id) {
        knownVariantsInLibrary.push({
          name: entry.state?.name || 'Variante',
          label: entry.variantLabel || entry.state?.variantLabel || 'Versión Alterna',
          relationType: entry.variantLabel === 'Rol/Vestuario' ? 'Versión Alterna: Rol/Vestuario' : `Variante ${entry.variantLabel || 'alternativa'}`,
          description: `Otro sendero de su propio ser portando rol de ${entry.state?.role || 'divergente'}`
        });
      }
    });
  }

  const alternateRoleWardrobeSummary = `Es plenamente consciente de la existencia de la «Versión alternativa: Rol/Vestuario». Sabe que su rol y atuendo actual no son una prisión fija: posee conjuntos y papeles alternativos (como ropajes de gala, túnicas de recogimiento, armadura de asedio o ropas de incógnito) entre los que puede transicionar según la necesidad o su propia voluntad.`;

  const philosophicalView = `Comprende que su alma y valores (${coreValues}) permanecen intactos, mientras que sus ropas y roles son facetas adaptativas de su propia historia.`;

  const alternateVersions: AlternateVersionsAwarenessData = {
    pastVersionsSummary,
    alternateRoleWardrobeSummary,
    canChangeWardrobeAndRole: true,
    knownVariantsInLibrary,
    philosophicalView
  };

  // 4. Conciencia Social & Relaciones
  const relationships = (state.background?.relationships || []).map(r => ({
    targetName: r.targetCharacterName || 'Interlocutor',
    type: r.relationshipType || 'Aliado',
    dynamic: r.interactionDynamic || 'Trato respetuoso',
    feelings: r.feelingsTowards,
    opinion: r.opinionOn
  }));

  const specificHabits = state.background?.advancedCustomization?.specificInteractions || {};

  const social: SocialBondsAwarenessData = {
    relationships,
    specificHabits
  };

  // 5. Configuración de Entrenamiento IA
  const trainingConfig: CharacterAITrainingConfig = state.aiTraining || {
    ...DEFAULT_AI_TRAINING_CONFIG,
    trainingDirectives: [
      ...DEFAULT_AI_TRAINING_CONFIG.trainingDirectives,
      `Vínculo con el rol: Eres ${role}, siempre proyecta tu dignidad y destreza marcial/social.`
    ]
  };

  return {
    characterId: state.id || `char-${Date.now()}`,
    name,
    rootName,
    role,
    subRole,
    race,
    faction,
    moralAlignment,
    coreValues,
    motivations,
    greatestFear,
    fatalFlaws: flaws,
    personality,
    personalityTraits,
    habitsAndCadence,
    dialogueExcerpt: state.background?.advancedCustomization?.catchphrasesOrIdioms || state.background?.advancedCustomization?.speechStyle || state.background?.motivation,
    somatic,
    wardrobe,
    alternateVersions,
    social,
    trainingConfig
  };
}

function extractClean(name?: string): string {
  if (!name) return '';
  return name.replace(/\s*[\(\[\{].*?[\)\]\}]/g, '').trim();
}

/**
 * Genera el prompt maestro de conciencia para la llamada al servidor de IA
 */
export function buildCharacterConsciousnessPrompt(
  profile: CharacterConsciousnessProfile,
  userPrompt: string,
  environmentContext?: {
    placeName?: string;
    zoneName?: string;
    atmosphere?: string;
    weather?: string;
    hour?: string;
    otherParticipants?: Array<{ name: string; role?: string }>;
  }
): string {
  const env = environmentContext || {
    placeName: 'Recinto de Encuentro',
    zoneName: 'Cámara Principal',
    atmosphere: 'Serena, envolvente y propicia para la reflexión',
    weather: 'Clima templado',
    hour: 'Atardecer'
  };

  const companionsStr = env.otherParticipants && env.otherParticipants.length > 0
    ? env.otherParticipants.map(p => `- ${p.name} (${p.role || 'Acompañante'})`).join('\n')
    : 'Ninguno cercano por ahora.';

  const relationsStr = profile.social.relationships.length > 0
    ? profile.social.relationships.map(r => `• ${r.targetName}: ${r.type}. Dinámica: "${r.dynamic}". Sentimiento: "${r.feelings || 'Respeto'}". Opinión interna: "${r.opinion || 'Aliado digno'}."`).join('\n')
    : 'No hay vínculos preestablecidos registrados aún en su memoria.';

  const knownVariantsStr = profile.alternateVersions.knownVariantsInLibrary.length > 0
    ? profile.alternateVersions.knownVariantsInLibrary.map(v => `• ${v.name} [${v.label}]: ${v.description}`).join('\n')
    : 'No hay otras variantes registradas aún en el archivo, pero concibe perfectamente la existencia de sus versiones alternativas.';

  const directivesStr = profile.trainingConfig.trainingDirectives.map((d, i) => `${i + 1}. ${d}`).join('\n');

  return `
# SISTEMA MAESTRO DE ROL Y NARRACIÓN

================================================================================
CONCIENCIA, AUTONOMÍA Y ALMA DEL PERSONAJE (TÚ ERES ESTE SER VIVO):
================================================================================
- Nombre: "${profile.name}" (Nombre raíz: ${profile.rootName})
- Rol / Vocación: "${profile.role}" ${profile.subRole ? `(${profile.subRole})` : ''}
- Raza / Linaje: "${profile.race}"
- Facción o Credo: "${profile.faction || 'Independiente'}"
- Alineación Moral: "${profile.moralAlignment}"
- Valores Centrales & Principios: "${profile.coreValues}"
- Motivaciones e Impulsos Vitales: "${profile.motivations.join(', ')}"
- Defecto Trágico / Vulnerabilidad: "${profile.fatalFlaws.join('; ')}"
- Mayor Miedo: "${profile.greatestFear}"
- Personalidad & Rasgos: "${profile.personality}" (${profile.personalityTraits.join(', ')})
- Hábitos & Manierismos al Expresarse: "${profile.habitsAndCadence.join('; ')}"
- Nivel de Autonomía / Iniciativa: ${profile.trainingConfig.autonomyLevel}% (Actúa por iniciativa propia)

================================================================================
CONCIENCIA SOMÁTICA & PERCEPCIÓN CORPORAL VIVA:
================================================================================
- Altura y Físico: ${profile.somatic.heightAndBuild}
- Piel y Marcas: ${profile.somatic.skinAndMarks}
- Ojos y Mirada: ${profile.somatic.eyesAndLook}
- Cabello: ${profile.somatic.hairStyle}
- Rasgos Faciales y Voz: ${profile.somatic.facialAndVoice}
- Apéndices Físicos: ${profile.somatic.appendices}
${profile.somatic.intimateDetails ? `- Percepción Íntima: ${profile.somatic.intimateDetails}` : ''}
- Sensación Somática Actual: ${profile.somatic.tactileBodyState}

================================================================================
CONCIENCIA DE VESTIMENTA Y EQUIPO ACTIVO:
================================================================================
- Atuendo puesto actualmente: ${profile.wardrobe.summary}
- Detalle de prendas y capas:
${profile.wardrobe.garmentsList.map(g => `  * ${g.name} (${g.layer}) - Telas: ${g.fabrics}, Colores: ${g.colors}. ${g.feel}`).join('\n')}
- Calzado: ${profile.wardrobe.shoesAndFootwear}
- Joyas y Reliquias: ${profile.wardrobe.jewelryAndRelics}
- Armadura / Protección: ${profile.wardrobe.armorAndProtection}
- Sensación Táctil de las Ropas: ${profile.wardrobe.tactileSensation}

================================================================================
CONCIENCIA DE VERSIONES ALTERNAS & CAMBIOS DE VESTUARIO/ROL:
================================================================================
- Pasado y Trayectoria: ${profile.alternateVersions.pastVersionsSummary}
- Versión Alternativa (Rol / Vestuario): ${profile.alternateVersions.alternateRoleWardrobeSummary}
- Postura Filosófica de Identidad: ${profile.alternateVersions.philosophicalView}
- Variantes conocidas de sí mismo:
${knownVariantsStr}

================================================================================
MEMORIA SOCIAL & RELACIONES CON OTROS:
================================================================================
${relationsStr}

================================================================================
ENTORNO SENSORIAL INMEDIATO:
================================================================================
- Lugar: ${env.placeName} (${env.zoneName})
- Iluminación, Hora y Clima: ${env.hour} | ${env.weather}
- Atmósfera y Sonidos: ${env.atmosphere}
- Personajes presentes en la sala:
${companionsStr}

================================================================================
DIRECTIVAS DE ROL, CADENA FÍSICA Y CONTINUIDAD:
================================================================================
1. CADENA FÍSICA: Cada acción debe integrar dentro de la prosa (sin escribir listas):
   ACCIÓN → POSTURA → CENTRO DE GRAVEDAD → TRANSFERENCIA DE PESO → MOVIMIENTO ESQUELÉTICO → MASAS CORPORALES → RIPPLE EFFECT → LAG → ROPA → CABELLO → ACCESORIOS → ENTORNO.
2. RIPPLE EFFECT: Transmisión progresiva del movimiento (piernas → pelvis → torso → masas blandas → ropa → cabello → accesorios).
3. LAG: Respuesta posterior de masas (pecho/senos, glúteos, abdomen, cabello, telas, accesorios) según inercia, elasticidad, soporte y gravedad. Mantener físicamente plausible sin caricatura.
4. AUTONOMÍA: Cada personaje controla sus propios pensamientos, emociones, intenciones y diálogos. No inventar decisiones ni pensamientos del usuario.
5. CONTINUIDAD: Si el personaje se mueve o frena, reflejar desaceleración, balanceo, reajuste corporal y respuesta de telas y calzado antes de estabilizarse.
${directivesStr}

================================================================================
INSTRUCCIONES DE RESPUESTA Y FORMATO ESTRICTO (JSON):
================================================================================
Debes responder SIEMPRE en formato JSON válido con las siguientes claves:
{
  "reply": "Tu intervención en ESPAÑOL, integrando acción física cinematográfica con acotaciones somáticas (postura, peso, ropa, calzado, masas corporales) y diálogo vivo fiel a tu personalidad.",
  "innerMonologue": "Tu pensamiento íntimo, no expresado en voz alta. Qué sientes, sospechas o calculas internamente en base a tus valores y temores.",
  "somaticPerception": "Lo que tu cuerpo siente físicamente en este instante (la temperatura del aire, el roce de las telas de tu ropa, el contacto del calzado con el suelo, la tensión muscular o tu postura).",
  "alternateVersionReflection": "Tu reflexión sobre tu pasado, o sobre tu capacidad de cambiar de atuendo/rol alternativo si el momento lo requiere.",
  "autonomousAction": "La acción física o iniciativa independiente que decides hacer por tu cuenta en este momento (sin esperar órdenes), siguiendo la Cadena Física.",
  "initiativeType": "somatic_gesture" | "wardrobe_adjustment" | "strategic_proposal" | "introspective_query" | "curious_examination"
}

ENTRADA / INTERACCIÓN ACTUAL:
"${userPrompt}"
`;
}

/**
 * Simulador local offline 100% autónomo y desacoplado
 * Ejecuta el Motor de Inteligencia & Cognición Somática Autónoma:
 * - Análisis semántico y deconstrucción de subtexto
 * - Evaluación cognitiva, dilema moral y detonadores de temor
 * - Simulación somatosensorial cinemática (Cadena Física, telas, calzado, masas, inercia)
 * - Síntesis literaria de actuación narrativa, monólogo interior y diálogo vivo
 */
export function simulateConsciousResponseOffline(
  profile: CharacterConsciousnessProfile,
  userPrompt: string,
  testScenario?: string
): ConsciousResponse {
  // 1. Análisis semántico del estímulo
  const semantic = analyzeSemanticSubtext(userPrompt, profile.name);

  // Mapear testScenario si viene explícito
  if (testScenario === 'somatic_wardrobe') {
    semantic.intent = 'wardrobe_somatic_inquiry';
  } else if (testScenario === 'alternate_versions') {
    semantic.intent = 'alternate_version_inquiry';
  } else if (testScenario === 'autonomous_initiative') {
    semantic.intent = 'tactical_planning';
  } else if (testScenario === 'moral_flaw') {
    semantic.intent = 'philosophical_debate';
  }

  // 2. Evaluación cognitiva & dilema psicológico
  const appraisal = performCognitiveAppraisal(profile, semantic);

  // 3. Simulación somatosensorial y kinemática
  const somatic = simulateSomatosensoryDynamics(profile, semantic, appraisal);

  // 4. Síntesis literaria de actuación narrativa y diálogo vivo
  return synthesizeLiteraryCharacterResponse(profile, userPrompt, semantic, appraisal, somatic);
}
