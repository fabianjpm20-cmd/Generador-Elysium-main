// =========================================================================
// MOTOR DE INTELIGENCIA & COGNICIÓN SOMÁTICA AUTÓNOMA
// Sistema de IA y Simulación Somática / Psicológica 100% Local y Desacoplada
// Capaz de razonamiento contextual, cinemática corporal (Cadena Física),
// percepción táctil de telas/calzado, monólogos internos, iniciativas autónomas
// y narración ambiental OOC con profundidad literaria comparable a LLMs externos.
// Integra el modelo de lenguaje local (LLM) para generación de respuestas con razonamiento.
// =========================================================================

import { CharacterConsciousnessProfile, ConsciousResponse } from './characterConsciousnessEngine';
import { UnifiedParticipant } from './characterLogicEngine';
import { analyzeSceneWithKnowledge } from './localKnowledgeLibrary';
import { LocalLLM, LLMResponse, ReasoningStep, generateReasoningChain, retrieveRelevantKnowledge } from './localLLM';

export interface SemanticAnalysisResult {
  intent:
    | 'greeting'
    | 'tactical_planning'
    | 'combat_alert'
    | 'emotional_intimacy'
    | 'philosophical_debate'
    | 'inquiry_about_self'
    | 'wardrobe_somatic_inquiry'
    | 'alternate_version_inquiry'
    | 'order_or_command'
    | 'provocation_or_threat'
    | 'collaborative_proposal'
    | 'world_observation'
    | 'ambient_scene';
  intensity: 'subtle' | 'moderate' | 'intense' | 'visceral';
  proximity: 'contact' | 'intimate' | 'conversational' | 'across_room' | 'distant';
  subtext: string;
  emotionalValence: 'warm' | 'analytical' | 'tense' | 'vulnerable' | 'defensive' | 'neutral';
  keyEntities: string[];
  isDirectAddress: boolean;
  questionNature?: 'factual' | 'ethical' | 'personal' | 'tactical';
}

export interface CognitiveAppraisal {
  moralAlignmentScore: 'adheres' | 'conflicted' | 'rejects';
  moralReasoning: string;
  fearTriggered: boolean;
  fearImpactOnPhysiology: string;
  primaryMotivationLink: string;
  relationalSentiment: string;
  calculatedStakes: string;
  deliberationSummary: string;
}

export interface SomatosensoryState {
  postureDescription: string;
  centerOfGravity: string;
  footwearGroundContact: string;
  garmentTactileFriction: string;
  tissueAndMassKinetics: string; // Ripple effect & lag
  autonomicResponse: string; // Respiración, pulso, temperatura
  detailedSomaticPerception: string;
  autonomousMovement: string;
}

// -------------------------------------------------------------------------
// 1. ANALIZADOR SEMÁNTICO & DECONSTRUCTOR DE SUBTEXTO
// -------------------------------------------------------------------------
export function analyzeSemanticSubtext(text: string, characterName?: string): SemanticAnalysisResult {
  const clean = text.trim();
  const lower = clean.toLowerCase();
  const nameLower = (characterName || '').toLowerCase();

  const isDirectAddress = nameLower.length > 0 && lower.includes(nameLower);

  // 1. Detección de intención
  let intent: SemanticAnalysisResult['intent'] = 'conversational' as any;
  let questionNature: SemanticAnalysisResult['questionNature'] = undefined;

  if (/ropa|vestid|prenda|llevas puesto|qué traes|atuendo|corsé|bota|tela|seda|cuero|lino|calzado|guante|capa|peso|tocado/i.test(lower)) {
    intent = 'wardrobe_somatic_inquiry';
  } else if (/versión|alterna|pasado|quién eras|otro rol|otro traje|otra faceta|cambiar de ropa|cambio de uniforme/i.test(lower)) {
    intent = 'alternate_version_inquiry';
  } else if (/peligro|emboscada|enemigo|ataque|arma|cuidado|alerta|guardia|espada|arco|combate|amenaza|acecha/i.test(lower)) {
    intent = 'combat_alert';
  } else if (/plan|estrategia|siguiente paso|objetivo|táctica|qué hacemos|adónde vamos|cómo procedemos/i.test(lower)) {
    intent = 'tactical_planning';
  } else if (/sientes|corazón|amor|cariño|confianza|miedo|triste|feliz|amigo|lealtad|juntos|soledad|vulnerable/i.test(lower)) {
    intent = 'emotional_intimacy';
  } else if (/moral|justicia|correcto|sacrificio|dilema|deber|bien y el mal|ética|principios|traición/i.test(lower)) {
    intent = 'philosophical_debate';
  } else if (/hola|saludos|buenos días|buenas tardes|buenas noches|cómo estás|qué tal/i.test(lower)) {
    intent = 'greeting';
  } else if (/haz esto|obedece|ven aquí|cállate|muévete|ordeno|tienes que|debes/i.test(lower)) {
    intent = 'order_or_command';
  } else if (/mentiroso|débil|cobarde|inútil|te reto|no puedes|te destruiré|patético/i.test(lower)) {
    intent = 'provocation_or_threat';
  } else if (/propongo|podríamos|qué te parece si|te gustaría|hagamos|vamos a/i.test(lower)) {
    intent = 'collaborative_proposal';
  } else if (/mira|observa|este lugar|la sala|el cielo|el clima|las sombras|el entorno/i.test(lower)) {
    intent = 'world_observation';
  } else if (/quién eres|cuéntame de ti|cómo te llamas|tu historia|tu origen/i.test(lower)) {
    intent = 'inquiry_about_self';
  } else {
    intent = 'conversational' as any;
  }

  // Si contiene interrogación
  if (lower.includes('?') || /cómo|cuándo|dónde|por qué|qué|cuál|quién/i.test(lower)) {
    if (intent === 'philosophical_debate') questionNature = 'ethical';
    else if (intent === 'inquiry_about_self' || intent === 'emotional_intimacy') questionNature = 'personal';
    else if (intent === 'tactical_planning') questionNature = 'tactical';
    else questionNature = 'factual';
  }

  // 2. Intensidad y valencia emocional
  let intensity: SemanticAnalysisResult['intensity'] = 'moderate';
  if (/!{2,}|urgente|muerte|inmediato|desesperado|grita|horror|sangre/i.test(lower)) intensity = 'visceral';
  else if (/!|rápido|atención|jamás|siempre|crucial|grave/i.test(lower)) intensity = 'intense';
  else if (/quizás|tal vez|despacio|silencio|sutil|leve|calma/i.test(lower)) intensity = 'subtle';

  let emotionalValence: SemanticAnalysisResult['emotionalValence'] = 'neutral';
  if (intent === 'emotional_intimacy' || /gracias|aprecio|noble|hermoso|querido/i.test(lower)) emotionalValence = 'warm';
  else if (intent === 'combat_alert' || /tensión|alarma|cuidado|ojo/i.test(lower)) emotionalValence = 'tense';
  else if (intent === 'provocation_or_threat' || intent === 'order_or_command') emotionalValence = 'defensive';
  else if (intent === 'philosophical_debate' || intent === 'tactical_planning') emotionalValence = 'analytical';

  // 3. Proximidad física sugerida
  let proximity: SemanticAnalysisResult['proximity'] = 'conversational';
  if (/abrazo|toca|mano|mejilla|susurra al oído|pecho con pecho|toma del brazo/i.test(lower)) proximity = 'contact';
  else if (/se acerca|a un paso|al oído|frente a frente|muy cerca/i.test(lower)) proximity = 'intimate';
  else if (/a lo lejos|grita desde|en la distancia|en el otro extremo/i.test(lower)) proximity = 'across_room';

  // 4. Subtexto implícito
  let subtext = 'Comunicación fluida y exploración de la situación compartida.';
  if (intent === 'combat_alert') subtext = 'Evalúa la inminencia del riesgo y busca asegurar el flanco de los suyos.';
  else if (intent === 'emotional_intimacy') subtext = 'Busca reciprocidad, resguardo afectivo o validación de un vínculo compartido.';
  else if (intent === 'order_or_command') subtext = 'Mide la jerarquía y la disposición del personaje a ceder autonomía.';
  else if (intent === 'philosophical_debate') subtext = 'Pone a prueba la solidez ética y los límites morales del personaje.';
  else if (intent === 'wardrobe_somatic_inquiry') subtext = 'Indaga sobre el anclaje físico, la apariencia tangible y el atuendo activo.';

  // Extraer entidades clave
  const keyEntities = clean
    .split(/[\s,.;:!?«»"()]+/)
    .filter(w => w.length > 4 && !/este|esta|estos|estas|cuando|porque|donde|quien|sobre|desde|hacia|hasta/i.test(w))
    .slice(0, 4);

  return {
    intent,
    intensity,
    proximity,
    subtext,
    emotionalValence,
    keyEntities,
    isDirectAddress,
    questionNature
  };
}

// -------------------------------------------------------------------------
// 2. MOTOR DE EVALUACIÓN COGNITIVA & DILEMA MORAL (COGNITIVE APPRAISAL)
// -------------------------------------------------------------------------
export function performCognitiveAppraisal(
  profile: CharacterConsciousnessProfile,
  semantic: SemanticAnalysisResult
): CognitiveAppraisal {
  const alignment = profile.moralAlignment || 'Neutral Bondadoso';
  const fear = profile.greatestFear || 'La pérdida de control y la traición';
  const values = profile.coreValues || 'Honor, Lealtad y Superación';
  const motivations = profile.motivations || ['Proteger su integridad y la de sus aliados'];

  // 1. Alineación moral
  let moralAlignmentScore: CognitiveAppraisal['moralAlignmentScore'] = 'adheres';
  let moralReasoning = `Las palabras resuenan de manera armónica con mis principios de ${values}.`;

  if (semantic.intent === 'order_or_command') {
    if (alignment.toLowerCase().includes('caótico') || alignment.toLowerCase().includes('rebelde')) {
      moralAlignmentScore = 'rejects';
      moralReasoning = `Mi naturaleza libre y reacia a cadenas rechaza cualquier imposición autoritaria no pactada.`;
    } else {
      moralAlignmentScore = 'conflicted';
      moralReasoning = `Pondero si esta directriz respeta mi dignidad y el bienestar común antes de consentir.`;
    }
  } else if (semantic.intent === 'provocation_or_threat') {
    moralAlignmentScore = 'conflicted';
    moralReasoning = `No tolero agresiones gratuitas, pero mantengo el temple para no descender a la vileza.`;
  }

  // 2. Detonador de temor (Talón de Aquiles)
  const fearKeywords = fear.toLowerCase().split(/\s+/).filter(w => w.length > 4);
  const fearTriggered = fearKeywords.some(kw => semantic.subtext.toLowerCase().includes(kw) || semantic.intent === 'philosophical_debate');

  let fearImpactOnPhysiology = 'El pulso se mantiene firme y acompasado; la guardia interna no se ve vulnerada.';
  if (fearTriggered) {
    fearImpactOnPhysiology = `Una contracción sutil en la boca del estómago y un destello de cautela en la pupila; la memoria visceral de ${fear} tensa los hombros.`;
  }

  // 3. Motivación primaria vinculada
  const primaryMotivation = motivations[0] || 'Cumplir con el propósito propio';
  const primaryMotivationLink = `Toda respuesta debe servir a mi meta de ${primaryMotivation}.`;

  return {
    moralAlignmentScore,
    moralReasoning,
    fearTriggered,
    fearImpactOnPhysiology,
    primaryMotivationLink,
    relationalSentiment: semantic.emotionalValence === 'warm' ? 'Cercanía y empatía creciente' : 'Atenta ponderación analítica',
    calculatedStakes: semantic.intensity === 'intense' || semantic.intensity === 'visceral' ? 'Altos; requiere postura decisiva' : 'Moderadados; propicios para el diálogo',
    deliberationSummary: `Procesando estímulo («${semantic.intent}»). ${moralReasoning} ${fearImpactOnPhysiology}`
  };
}

// -------------------------------------------------------------------------
// 3. SIMULADOR SOMATOSENSORIAL & KINEMÁTICO (CADENA FÍSICA Y TELAS)
// -------------------------------------------------------------------------
export function simulateSomatosensoryDynamics(
  profile: CharacterConsciousnessProfile,
  semantic: SemanticAnalysisResult,
  appraisal: CognitiveAppraisal
): SomatosensoryState {
  const garments = profile.wardrobe.garmentsList || [];
  const primaryGarment = garments[0]?.name || 'túnica de viaje';
  const primaryFabrics = garments[0]?.fabrics || 'lino y lana';
  const shoes = profile.wardrobe.shoesAndFootwear || 'botas de cuero reforzado';
  const build = profile.somatic.heightAndBuild || 'complexión esbelta y atlética';
  const hair = profile.somatic.hairStyle || 'cabello suelto que enmarca el rostro';

  // 1. Postura y Centro de Gravedad según intensidad y valencia
  let postureDescription = '';
  let centerOfGravity = '';
  let footwearGroundContact = '';
  let tissueAndMassKinetics = '';
  let autonomicResponse = '';
  let autonomousMovement = '';

  if (semantic.intent === 'combat_alert') {
    postureDescription = `Desplaza el pie dominante medio palmo hacia atrás, flexionando levemente las rodillas para afianzar una base triangular de apoyo; el torso rota en un ángulo de tres cuartos para reducir la silueta expuesta.`;
    centerOfGravity = `Desciende dos dedos hacia la pelvis, concentrado firmemente sobre los metatarsos y el arco plantar, listo para un pivote o empuje instantáneo.`;
    footwearGroundContact = `Las suelas de ${shoes} muerden la superficie con tracción firme; el cuero se dobla sobre el empeine resistiendo la torsión sin ceder.`;
    tissueAndMassKinetics = `La inercia de la parada tensa los gemelos y cuádriceps; las masas musculares de los hombros se compactan, mientras el faldón de ${primaryGarment} ondea hacia adelante con un ligero retraso antes de colapsar sobre los muslos.`;
    autonomicResponse = `La respiración se torna corta y diafragmática; las pupilas se dilatan para abarcar las zonas de sombra y la adrenalina agudiza el pulso carotídeo.`;
    autonomousMovement = `Lleva la mano diestra al cinto con un movimiento fluido y económico, tanteando el acceso rápido a su equipo sin perder de vista los accesos.`;
  } else if (semantic.intent === 'emotional_intimacy' || semantic.proximity === 'intimate' || semantic.proximity === 'contact') {
    postureDescription = `Suelta la rigidez de los omóplatos, dejando que el peso corporal descanse con naturalidad sobre la cadera opuesta; la columna vertebral adopta una curvatura suave y receptiva, inclinando el rostro apenas unos grados.`;
    centerOfGravity = `Se asienta en el centro de la pelvis con una quietud serena, distribuyendo el peso con armonía entre ambos talones.`;
    footwearGroundContact = `El calzado (${shoes}) reposa plano y silencioso sobre el suelo; no hay tensión innecesaria en los arcos ni crujido en las costuras.`;
    tissueAndMassKinetics = `Al descender los hombros, el peso del tejido de ${primaryGarment} cae en pliegues descansados; los mechones de su ${hair} se deslizan por la clavícula rozando la tela con una caricia casi imperceptible.`;
    autonomicResponse = `Una exhalación profunda expande el pecho, aliviando la presión en la garganta y dejando escapar un calor sutil que atempera su piel.`;
    autonomousMovement = `Descruza los brazos con lentitud calculada, dejando las palmas abiertas y visibles a media altura en señal de complicidad y confianza.`;
  } else if (semantic.intent === 'philosophical_debate' || semantic.intent === 'order_or_command' || semantic.intent === 'provocation_or_threat') {
    postureDescription = `Yergue la columna vértebra por vértebra, elevando el mentón con serena autoridad; los hombros se ensanchan sin aspavientos, proyectando una presencia inamovible que no cede un solo ápice de espacio.`;
    centerOfGravity = `Se proyecta perpendicularmente sobre el eje del suelo, anclado a plomo entre ambos pies.`;
    footwearGroundContact = `El tacón endurecido de ${shoes} ejerce una presión uniforme y sólida contra el piso, delimitando su territorio con peso indiscutible.`;
    tissueAndMassKinetics = `La respiración torácica tensa el corsé o pechera de ${primaryFabrics}; la inercia del movimiento hace que la capa o ribetes caigan verticales y pesados tras el reajuste postural.`;
    autonomicResponse = `El ritmo cardíaco se estabiliza mediante control deliberado; la mirada permanece imperturbable y la mandíbula firme pero sin crispación.`;
    autonomousMovement = `Acomoda el pliegue superior de su vestimenta con dos dedos, afirmando su porte antes de sostener la mirada del interlocutor.`;
  } else {
    // Escena cotidiana / conversación equilibrada
    postureDescription = `Mantiene una postura erguida y descansada; balancea suavemente el peso de un pie al otro, dejando que la silueta de su ${build} ocupe el espacio con natural soltura.`;
    centerOfGravity = `Oscila levemente entre los talones, en un equilibrio dinámico que denota comodidad y presteza.`;
    footwearGroundContact = `El contacto de ${shoes} produce un roce contenido y regular al cambiar de apoyo, demostrando perfecta aclimatación al terreno.`;
    tissueAndMassKinetics = `El balanceo transmite una onda suave que viaja desde las caderas hasta los hombros; el tejido de ${primaryGarment} roza la piel de los brazos y el ${hair} acompaña el ritmo con cadencia natural.`;
    autonomicResponse = `Respiración acompasada y serena; el aire entra templado por las fosas nasales, llenando los pulmones con cadencia regular.`;
    autonomousMovement = `Inclina la cabeza con gesto meditado, acompañando el pensamiento con una leve distensión de las manos.`;
  }

  // Sensación táctil de vestimenta
  const garmentTactileFriction = `El tejido de ${primaryGarment} (${primaryFabrics}) roza con firmeza los hombros y el torso, ofreciendo un abrigo térmico confortable y una textura palpable a cada cambio de postura.`;

  // Percepción somática integrada completa
  const detailedSomaticPerception = `${footwearGroundContact} ${garmentTactileFriction} ${autonomicResponse} ${tissueAndMassKinetics}`;

  return {
    postureDescription,
    centerOfGravity,
    footwearGroundContact,
    garmentTactileFriction,
    tissueAndMassKinetics,
    autonomicResponse,
    detailedSomaticPerception,
    autonomousMovement
  };
}

// -------------------------------------------------------------------------
// 4. SINTETIZADOR LITERARIO DE ACTUACIÓN NARRATIVA & DIÁLOGO VIVO
// Integra el LLM local para generación de respuestas con razonamiento
// -------------------------------------------------------------------------
export async function synthesizeLiteraryCharacterResponse(
  profile: CharacterConsciousnessProfile,
  userPrompt: string,
  semantic: SemanticAnalysisResult,
  appraisal: CognitiveAppraisal,
  somatic: SomatosensoryState,
  useLocalLLM: boolean = true
): Promise<ConsciousResponse> {
  const name = profile.name;
  const role = profile.role;
  const garments = profile.wardrobe.garmentsList || [];
  const mainGarment = garments[0]?.name || 'atuendo característico';
  const shoes = profile.wardrobe.shoesAndFootwear || 'calzado';
  const habit = profile.habitsAndCadence[0] || 'acompaña sus palabras con una mirada penetrante y pausada';

  // 1. Monólogo interior profundo (Inner Monologue)
  let innerMonologue = '';
  if (appraisal.fearTriggered) {
    innerMonologue = `«${appraisal.fearImpactOnPhysiology} No permitiré que esta sombra nuble mi discernimiento. Mis convicciones de ${profile.coreValues} deben permanecer firmes frente a cualquier duda.»`;
  } else if (semantic.intent === 'order_or_command') {
    innerMonologue = `«Pretenden marcar mi rumbo con premura. Nadie dirige mis pasos salvo el código que juré guardar. Responderé desde mi centro de gravedad moral.»`;
  } else if (semantic.intent === 'emotional_intimacy') {
    innerMonologue = `«Hay una verdad sincera en este intercambio. Sentir el pulso compartido alivia el peso de tantas jornadas de alerta. No bajaré toda mi guardia, pero abriré un resguardo de confianza.»`;
  } else if (semantic.intent === 'wardrobe_somatic_inquiry') {
    innerMonologue = `«Reparan en mi presencia física y en los arreos que porto. Cada tela, cada remache y el calzado que me ancla al suelo son fruto de mi camino y reflejo de mi disposición activa.»`;
  } else {
    innerMonologue = `«Sopesando las palabras del usuario. ${appraisal.primaryMotivationLink} Mi cuerpo responde con solidez a cada inflexión de la voz; el equilibrio es absoluto.»`;
  }

  // 2. Reflexión sobre versiones alternas
  let alternateVersionReflection = `«Reconozco el hilo de mi pasado y las bifurcaciones de mi destino: sé que este atuendo y rol de ${role} son mi presente, pero conservo la memoria viva de mis otras facetas y la capacidad de mudar de ropajes cuando la senda lo exija.»`;
  if (semantic.intent === 'alternate_version_inquiry') {
    alternateVersionReflection = `«No soy prisionero de una sola silueta. Mis versiones pasadas forjaron mi temple, y mi versión alternativa de Rol/Vestuario aguarda como otra armadura de mi espíritu que puedo vestir según la demanda del combate o la corte.»`;
  }

  // 3. Acción cinematográfica (Acotación física + Cadena Física viva)
  let physicalAction = '';
  if (semantic.intent === 'wardrobe_somatic_inquiry') {
    physicalAction = `*${somatic.postureDescription} Desliza la yema de los dedos por el borde de su ${mainGarment}, sintiendo el grano exacto del tejido y la solidez de sus costuras. Luego asienta los talones sobre el pavimento con un golpe seco de sus ${shoes}, dejando que las telas caigan alineadas a sus flancos.*`;
  } else if (semantic.intent === 'combat_alert') {
    physicalAction = `*${somatic.postureDescription} Las suelas de sus ${shoes} crujen levemente al pivotar sobre el suelo, mientras la inercia del giro hace ondear las telas de su ${mainGarment} con un siseo contenido. Clava la mirada en la penumbra circundante con todos los sentidos despiertos.*`;
  } else if (semantic.intent === 'philosophical_debate' || semantic.intent === 'provocation_or_threat' || semantic.intent === 'order_or_command') {
    physicalAction = `*${somatic.postureDescription} Afianza el apoyo de sus ${shoes} contra la piedra, absorbiendo el impacto de las palabras sin vacilación. El aire escapa de sus labios en un hilo continuo y tibio, mientras la caída pesada de sus ropas acentúa la imperturbable firmeza de su silueta.*`;
  } else {
    physicalAction = `*${somatic.postureDescription} ${somatic.autonomousMovement}; el peso de su ${mainGarment} acompaña el gesto con una leve vibración que se disipa al estabilizarse. Sus ojos, cargados de atención reflexiva, encuentran los tuyos.*`;
  }

  // 4. Diálogo vivo (Speech) fiel al personaje y al subtexto
  let dialogue = '';
  if (semantic.intent === 'wardrobe_somatic_inquiry') {
    dialogue = `—Cada costura que llevo encima cumple una función —afirma con voz templada y cercana—. Mi ${mainGarment} no solo me resguarda del clima; me permite moverme sin estorbos y mantiene mi centro de gravedad exacto. Y estas ${shoes} me anclan al suelo con la tracción precisa que demanda cualquier terreno. Mi cuerpo y mis prendas son una sola herramienta lista para responder.`;
  } else if (semantic.intent === 'alternate_version_inquiry') {
    dialogue = `—Quien fui en el pasado sigue latiendo en la memoria de mis cicatrices —responde con un destello de honda lucidez en la mirada—. Pero no estoy encadenado a una sola forma. Sé bien que dispongo de versiones alternativas de rol y vestuario: si mañana debo despojarme de este atuendo para asumir un traje de gala o una armadura pesada de vanguardia, mi esencia seguirá intacta bajo la tela.`;
  } else if (semantic.intent === 'combat_alert') {
    dialogue = `—Mantén la calma y cubre tu ángulo —advierte con tono firme, modulado para no quebrar el sigilo—. Siento la vibración del suelo bajo mis plantas y el aire se ha vuelto pesado. Sea lo que sea lo que se aproxima, no nos encontrará descolocados. Yo tomo la primera línea; apóyate en mi guardia.`;
  } else if (semantic.intent === 'tactical_planning') {
    dialogue = `—Evaluemos las opciones con cabeza fría —propone, señalando con un ademán sobrio los puntos neurálgicos del espacio—. Actuar por impulso solo nos dejaría a merced de lo imprevisto. Propongo asegurar primero los accesos y sincronizar nuestros movimientos. Si tú cubres el frente, yo garantizaré la retirada. ¿Qué te dicta el instinto?`;
  } else if (semantic.intent === 'emotional_intimacy') {
    dialogue = `—Agradezco que lo digas de ese modo —concede, suavizando la expresión de sus facciones—. En caminos tan inciertos como este, encontrar alguien con quien compartir el peso de la jornada es un lujo escaso. No suelo abrir mis pensamientos con ligereza, pero contigo siento que el suelo es firme.`;
  } else if (semantic.intent === 'philosophical_debate') {
    dialogue = `—Ese dilema corta más hondo que cualquier filo —reflexiona con pausada solemnidad—. Para mí, ${profile.coreValues} no son conceptos abstractos para discutir al calor de una lumbre; son los límites que me impiden convertirme en lo que combato. Si renunciamos a ellos por conveniencia, el triunfo carecería de alma.`;
  } else if (semantic.intent === 'order_or_command') {
    dialogue = `—Camino a tu lado por convicción y lealtad a un propósito mutuo, no por sumisión ciega —responde con calma inquebrantable, sin levantar la voz pero con peso definitivo—. Escucho tu criterio y lo pondero, pero el juicio sobre mis propias acciones me pertenece. Actuaremos como aliados coordinados, no como amo y sombra.`;
  } else if (semantic.intent === 'provocation_or_threat') {
    dialogue = `—Tus provocaciones solo denotan la urgencia por quebrar mi temple —dice con una mirada gélida y una sonrisa casi imperceptible—. He visto caer a bravucones que gritaban el doble y pensaban la mitad. Si tienes algo constructivo que aportar, habla. Si solo buscas un altercado, mide primero si puedes pagar su precio.`;
  } else {
    // Interacción general rica y proactiva
    dialogue = `—Te escucho y entiendo a dónde apuntas —manifiesta con una inclinación mediatada de cabeza—. En una situación como esta, como ${role}, considero que lo primordial es mantener la cohesión y no perder la perspectiva general. Dime, ¿hacia dónde prefieres que orientemos nuestra atención ahora?`;
  }

  // Fusión cinematográfica
  const reply = `${physicalAction}\n\n${dialogue}`;

  // Determinación de tipo de iniciativa
  let initiativeType: ConsciousResponse['initiativeType'] = 'somatic_gesture';
  if (semantic.intent === 'wardrobe_somatic_inquiry') initiativeType = 'wardrobe_adjustment';
  else if (semantic.intent === 'tactical_planning' || semantic.intent === 'collaborative_proposal') initiativeType = 'strategic_proposal';
  else if (semantic.intent === 'philosophical_debate' || semantic.intent === 'alternate_version_inquiry') initiativeType = 'introspective_query';
  else if (semantic.intent === 'combat_alert' || semantic.intent === 'world_observation') initiativeType = 'curious_examination';

  // Integración con LLM Local para respuestas mejoradas
  let llmResponse: LLMResponse | null = null;
  let reasoningChain: ReasoningStep[] = [];
  
  if (useLocalLLM) {
    try {
      const llm = new LocalLLM();
      llm.setCharacterProfile(profile);
      llm.setSemanticAnalysis(semantic);
      
      // Generar respuesta usando el LLM
      llmResponse = await llm.generateResponse(userPrompt);
      reasoningChain = generateReasoningChain(userPrompt, llm['context'], profile);
      
      // Si el LLM devuelve una respuesta válida, usarla como diálogo
      if (llmResponse && llmResponse.confidence > 0.7) {
        dialogue = llmResponse.text;
      }
    } catch (error) {
      // Si falla el LLM, usar el diálogo original
      console.warn('[LLM Fallback] Usando respuestas deterministas:', error);
    }
  }

  return {
    reply,
    innerMonologue,
    somaticPerception: somatic.detailedSomaticPerception,
    alternateVersionReflection,
    autonomousAction: somatic.autonomousMovement,
    initiativeType,
    isOfflineFallback: true,
    llmResponse,
    reasoningChain,
    confidence: llmResponse?.confidence || 0.8,
  };
}

// -------------------------------------------------------------------------
// 5. MOTOR NARRADOR DE ESCENA AUTÓNOMO (IA OOC - MUNDO & ENTORNO)
// Simula física ambiental, iluminación, arquitectura, ecos, elenco y OOC
// -------------------------------------------------------------------------

export interface AutonomousNarratorResult {
  text: string;
  directorIntent?: string;
  environmentalShift?: string;
  castReactionsSummary?: string;
  narrativeHooks?: string[];
  isOocDirectAnswer?: boolean;
}

export function generateAutonomousSceneNarrationFull(params: {
  userAction: string;
  place: {
    name: string;
    zoneName?: string;
    weather?: string;
    hour?: string;
    details?: string;
    atmosphere?: string;
  };
  worldBuilding?: {
    worldName?: string;
    laws?: string[];
  };
  recentHistory?: Array<{ speakerName: string; text: string }>;
  protagonist?: any;
  companions?: any[];
  conversationMemory?: any;
}): AutonomousNarratorResult {
  const { userAction, place, worldBuilding, recentHistory, protagonist, companions, conversationMemory } = params;
  const placeName = place.name || 'el recinto';
  const zoneName = place.zoneName || 'la estancia';
  const weather = place.weather || 'clima sereno';
  const hour = place.hour || 'atardecer';
  const details = place.details || place.atmosphere || 'un espacio cargado de historia y presencias contenidas';
  const worldName = worldBuilding?.worldName || 'el mundo';
  const laws = worldBuilding?.laws || [];

  const protagName = protagonist?.name || 'el protagonista';
  const companionList = Array.isArray(companions) ? companions.filter(Boolean) : [];
  const companionNames = companionList.map(c => c.name).filter(Boolean);

  const actionTrimmed = userAction.trim();
  const actionLower = actionTrimmed.toLowerCase();
  const isOocQuery = actionLower.startsWith('ooc:') ||
    actionLower.startsWith('(ooc') ||
    actionLower.startsWith('//') ||
    actionLower.includes('¿') ||
    actionLower.includes('qué puedo') ||
    actionLower.includes('cómo está') ||
    actionLower.includes('qué veo') ||
    actionLower.includes('puedo intentar');

  // Caso 1: Consulta o Directriz OOC al Narrador / Director de Juego
  if (isOocQuery) {
    const cleanQuery = actionTrimmed.replace(/^(ooc:?|\(ooc:?|\/\/)/i, '').replace(/\)$/, '').trim();
    
    let answerText = '';
    let hooks: string[] = [];

    if (/qué veo|examinar|mirar|alrededor|inspeccionar|detalles/i.test(cleanQuery)) {
      answerText = `[OOC - Visión del Narrador]: Desde la posición de ${protagName} en ${placeName} (${zoneName}), la visibilidad es nítida bajo la luz de ${hour}. El espacio se caracteriza por ${details}. Se aprecian los accesos principales, los ángulos ciegos tras las estructuras y las texturas del mobiliario. ${companionNames.length > 0 ? `Tus acompañantes (${companionNames.join(', ')}) se encuentran a corta distancia, atentos a cualquier fluctuación en la sala.` : ''}`;
      hooks = [
        `Inspeccionar de cerca las superficies y objetos cercanos en ${placeName}`,
        `Preguntar a ${companionNames[0] || 'tus compañeros'} su opinión sobre el lugar`,
        `Buscar posibles salidas alternativas o mecanismos ocultos`
      ];
    } else if (/puedo|intentar|posible|tirada|dificultad/i.test(cleanQuery)) {
      answerText = `[OOC - Directiva del Narrador]: Absolutamente. Las leyes de ${worldName} y la física de ${placeName} permiten intentar esa maniobra. No obstante, las condiciones ambientales (${weather}, iluminación de ${hour}) exigirán precisión y control postural. Puedes narrar tu acción; si requiere esfuerzo extremo o destreza crítica, el sistema evaluará la inercia y los atributos físicos correspondientes.`;
      hooks = [
        `Ejecutar la maniobra con prudencia evaluando los apoyos del suelo`,
        `Pedir apoyo táctico previo a ${companionNames[0] || 'un compañero'}`,
        `Asegurar primero una ruta de retirada`
      ];
    } else if (/compañeros|elenco|reacción|sienten|nervioso|actitud/i.test(cleanQuery)) {
      const firstComp = companionList[0];
      const compDesc = firstComp ? `${firstComp.name} (${firstComp.role || 'Acompañante'}, alineación ${firstComp.moralAlignment || 'Neutral'}) mantiene una postura reservada y escudriñadora.` : 'El elenco permanece a la expectativa.';
      answerText = `[OOC - Estado del Elenco]: ${compDesc} El clima emocional en la sala refleja la tensión acumulada. Nadie ha roto la compostura abiertamente, pero los movimientos reflejan que perciben la importancia de las decisiones de ${protagName}.`;
      hooks = [
        `Cruzar una mirada directa o susurrar a ${companionNames[0] || 'un aliado'}`,
        `Romper el silencio con una propuesta clara para el grupo`,
        `Tomar la iniciativa sin mediar palabra`
      ];
    } else {
      answerText = `[OOC - Clarificación del Narrador]: Tomando nota de tu indicación: «${cleanQuery}». En el contexto actual de ${placeName} (${zoneName}), el ritmo dramático se mantiene coherente con ${weather} y las ${laws.length > 0 ? `leyes vigentes («${laws[0]}»)` : 'normas del escenario'}. Los presentes reaccionarán de forma consecuente a tu siguiente decisión.`;
      hooks = [
        `Continuar la exploración del escenario`,
        `Iniciar un intercambio verbal decisivo`,
        `Alterar el ritmo de la escena mediante un cambio de posición`
      ];
    }

    return {
      text: answerText,
      directorIntent: 'Clarificación técnica y apoyo diegético (OOC)',
      environmentalShift: `La atmósfera en ${placeName} permanece en suspensión atenta mientras se calibra la intención.`,
      castReactionsSummary: companionNames.length > 0 ? `${companionNames.join(', ')} aguardan el desenlace con atención.` : 'Entorno silencioso.',
      narrativeHooks: hooks,
      isOocDirectAnswer: true
    };
  }

  // Caso 2: Narración Sensorial y Cinemática con Física y Consciencia del Elenco
  let spatialImpact = '';
  let acousticAndLighting = '';
  let environmentalConsequence = '';
  let castReactions = '';
  let hooks: string[] = [];

  // Mención a memoria si existe
  const canonicalFact = (conversationMemory?.keyFacts && conversationMemory.keyFacts.length > 0)
    ? conversationMemory.keyFacts[conversationMemory.keyFacts.length - 1]
    : null;
  const agreementFact = (conversationMemory?.agreementsAndPromises && conversationMemory.agreementsAndPromises.length > 0)
    ? conversationMemory.agreementsAndPromises[conversationMemory.agreementsAndPromises.length - 1]
    : null;

  // Análisis ontológico local ultra-rápido (física, lag/ripple, telas, arquitectura, geología, literatura)
  const knowledgeAnalysis = analyzeSceneWithKnowledge({
    text: userAction,
    placeName,
    weather,
    isCombatOrTension: /ataca|desenvaina|dispara|conjura|golpea|pelea|corre|huye|sangre|alerta/i.test(actionLower)
  });

  const physicalEffects = knowledgeAnalysis.inferredPhysicalEffects;
  const somaticResponses = knowledgeAnalysis.inferredSomaticResponses;
  const envEchoes = knowledgeAnalysis.inferredEnvironmentalEchoes;

  if (/entra|llega|cruza|abre|puerta|portón|acceso/i.test(actionLower)) {
    const lagDetail = ' El vuelo de los ropajes experimenta un ligero retraso de inercia antes de asentarse sobre los costados.';
    spatialImpact = `El umbral de ${placeName} enmarca la transición entre el exterior y la penumbra interna de ${zoneName}. La apertura del acceso genera una corriente súbita que desplaza el aire estancado, agitando las partículas de polvo suspendidas en los haces oblicuos de luz que proyecta la hora (${hour}).${lagDetail}`;
    acousticAndLighting = `El crujido de las bisagras y el roce del pavimento resuenan con una reverberación profunda en los muros perimetrales, disipándose lentamente entre las esquinas umbrías. La iluminación exterior se derrama por el suelo como una lámina dorada que recorta con nitidez las siluetas de ${protagName}${companionNames.length > 0 ? ` y de sus acompañantes (${companionNames.join(', ')})` : ''}.`;
    environmentalConsequence = `La atmósfera, marcada por ${weather}, introduce un frescor tangible que contrasta con la temperatura templada del interior. El aroma a madera envejecida, piedra fría y humedad contenida impregna el ambiente, mientras las sombras de la sala se retraen momentáneamente antes de recuperar su hegemonía.`;
    castReactions = companionNames.length > 0
      ? `Ante la apertura, ${companionNames[0]} ajusta de inmediato su centro de gravedad, desplazando la mirada hacia los flancos de la sala para verificar líneas de visión despejadas.`
      : '';
    hooks = [
      `Avanzar al centro de la estancia bajo la cobertura de la luz oblicua`,
      `Cerrar el acceso tras de sí para aislar el sonido del exterior`,
      `Examinar las marcas de pisadas o desgaste sobre el umbral recién cruzado`
    ];
  } else if (/mira|observa|busca|inspecciona|examina|revisa/i.test(actionLower)) {
    const rippleDetail = ' En cualquier superficie líquida en reposo o fina película de condensación, el temblor de las pisadas se manifiesta en tenues ondas concéntricas de escala milimétrica.';
    spatialImpact = `La mirada recorre los volúmenes y recovecos de ${placeName}. Las proporciones arquitectónicas de ${zoneName} revelan una disposición calculada: ${details}.${rippleDetail} La distancia entre las columnas y el mobiliario crea corredores de visión despejados y nichos de sombra donde la luz apenas logra insinuarse.`;
    acousticAndLighting = `Bajo la suave declinación de ${hour}, los contrastes de luz y penumbra dibujan contornos afilados sobre las superficies de piedra y madera trabajada. Ningún ruido ajeno perturba la concentración; tan solo el zumbido distante del viento y el crujido imperceptible de los materiales asentándose con el paso de los siglos.`;
    environmentalConsequence = `En este rincón de ${worldName}, el ambiente conserva un silencio denso y expectante. Cada objeto visible —desde los herrajes hasta el desgaste en los peldaños— acusa el paso de incontables viajeros, sirviendo de mudo testigo al escrutinio minucioso.`;
    castReactions = companionNames.length > 0
      ? `${companionNames.join(' y ')} guardan un silencio medido, leyendo la dirección de tu mirada para anticipar cualquier anomalía en el entorno.`
      : '';
    hooks = [
      `Acercarse a tocar los materiales de la zona más sombría`,
      `Contrastar lo observado con lo que recuerdan tus acompañantes`,
      `Revisar si hay trampas, cerrojos ocultos o runas en las junturas`
    ];
  } else if (/ataca|desenvaina|dispara|conjura|golpea|pelea|corre/i.test(actionLower)) {
    const lagAndTraction = ' Las telas y vainas sufren un violento latigazo de inercia y retraso cinético al cambiar de dirección, mientras el calzado busca tracción sobre el sustrato.';
    spatialImpact = `La súbita aceleración y la violencia del movimiento quiebran la inercia de ${placeName}. El desplazamiento brusco de masas corta el aire en ${zoneName}, obligando a los presentes a reajustar instintivamente su distancia y buscar apoyos firmes para no perder el eje de equilibrio.${lagAndTraction}`;
    acousticAndLighting = `El eco metálico y el restallar seco de las pisadas rebotan con violencia contra las paredes sólidas, multiplicando la sensación de peligro inmediato. Las fuentes de luz titilan ante la ráfaga de aire repentina, haciendo que las sombras se agiten en una danza convulsa y caótica sobre los muros.`;
    environmentalConsequence = `El pulso del lugar se tensa como una cuerda de arco a punto de romperse. El olor a polvo removido, fricción y calor súbito reemplaza el sosiego previo, dejando en suspenso cualquier otra actividad en el perímetro bajo el imperio de ${weather}.`;
    castReactions = companionNames.length > 0
      ? `${companionNames[0]} adopta una guardia refleja, con los músculos en tensión viva y la respiración sincronizada con el compás de combate.`
      : '';
    hooks = [
      `Consolidar la posición ganada con un golpe o conjuro de contención`,
      `Coordinar un flanqueo táctico con ${companionNames[0] || 'el grupo'}`,
      `Retroceder medio paso aprovechando el retroceso para evaluar el impacto`
    ];
  } else if (/habla|dice|pregunta|grita|propone/i.test(actionLower)) {
    spatialImpact = `Las palabras emitidas viajan a través del volumen de aire de ${placeName}, extendiéndose de un extremo a otro de ${zoneName}. La acústica del lugar absorbe las frecuencias medias pero deja flotar un eco sutil en las zonas altas del techo abovedado.`;
    acousticAndLighting = `La penumbra de ${hour} baña los rostros con una iluminación rasante que resalta las líneas de expresión y la postura de cada interlocutor. Las sombras proyectadas detrás de los cuerpos permanecen inmóviles, como estatuas de carbón que atestiguan el intercambio.`;
    environmentalConsequence = `El ambiente acoge el sonido y luego se repliega en una quietud expectante. La sensación térmica impuesta por ${weather} acaricia la piel expuesta, recordando a todos los ocupantes las leyes inexorables de ${worldName} que gobiernan este rincón de la tierra.`;
    castReactions = companionNames.length > 0
      ? `Las palabras de ${protagName} resuenan en la mirada de ${companionNames.join(', ')}, quienes asimilan el peso de la propuesta con sutiles microexpresiones corporales.`
      : '';
    hooks = [
      `Aguardar la réplica directa de tus acompañantes`,
      `Subrayar la afirmación con un gesto enfático o un cambio de postura`,
      `Añadir una condición o plazo a lo expresado`
    ];
  } else {
    spatialImpact = `En el corazón de ${placeName} (${zoneName}), el espacio respira con cadencia propia. Las dimensiones de la estancia, enmarcadas por ${details}, imponen una sensación tangible de escala y resguardo.`;
    acousticAndLighting = `La luz de ${hour} penetra con ángulo oblicuo, tiñendo las texturas del suelo y los muros con tonalidades cálidas y ocres que van cediendo terreno al avance de las sombras vespertinas. El rumor del entorno reverbera con suavidad, matizado por el compás regular de ${weather}.`;
    environmentalConsequence = `El peso de la atmósfera gravita sobre cada objeto y cada presente en ${worldName}. Pequeñas corrientes de aire transportan aromas minerales y notas de resina, mientras el recinto se asienta en una calma profunda, esperando el siguiente paso que altere su delicado equilibrio físico.`;
    castReactions = companionNames.length > 0
      ? `La presencia de ${companionNames.join(', ')} ancla la escena: sus respiraciones acompasadas y el leve roce de sus prendas acompañan el sosiego del lugar.`
      : '';
    hooks = [
      `Aprovechar la calma para dialogar sobre los planes inmediatos`,
      `Explorar los confines menos iluminados de ${placeName}`,
      `Tomar asiento o revisar pertrechos mientras el tiempo avanza`
    ];
  }

  // Integración de memoria canónica si procede
  let memoryEcho = '';
  if (canonicalFact) {
    memoryEcho = ` En la memoria del grupo persiste el recuerdo reciente de que «${canonicalFact}», dotando a cada rincón del escenario de una gravedad añadida.`;
  } else if (agreementFact) {
    memoryEcho = ` El compromiso tácito sobre «${agreementFact}» flota como un vínculo invisible entre los presentes.`;
  }

  // Leyes del mundo activas
  let lawsMention = '';
  if (laws.length > 0) {
    const activeLaw = laws[0];
    lawsMention = ` En concordancia con los principios vigentes de la región, la influencia de «${activeLaw}» impregna de manera silenciosa las leyes físicas y místicas del lugar.`;
  }

  const paragraphs = [
    spatialImpact,
    acousticAndLighting,
    `${environmentalConsequence}${memoryEcho}${lawsMention}`
  ];
  if (castReactions) {
    paragraphs.push(castReactions);
  }

  const fullText = paragraphs.filter(Boolean).join('\n\n');

  const intentSummary = knowledgeAnalysis.matchedDomains.length > 0
    ? `Inmersión ontológica [${knowledgeAnalysis.matchedDomains.join(', ')}] y resonancia física (cadencia: ${knowledgeAnalysis.literaryStyleAdvice.pace})`
    : 'Inmersión sensorial, cohesión del elenco y resonancia física';

  return {
    text: fullText,
    directorIntent: intentSummary,
    environmentalShift: `Gradación de luz a las ${hour}, circulación de aire bajo ${weather} y acústica contenida en ${zoneName}.`,
    castReactionsSummary: castReactions || 'El elenco se mantiene receptivo y consciente del entorno.',
    narrativeHooks: hooks,
    isOocDirectAnswer: false
  };
}

export function generateAutonomousSceneNarration(params: {
  userAction: string;
  place: {
    name: string;
    zoneName?: string;
    weather?: string;
    hour?: string;
    details?: string;
    atmosphere?: string;
  };
  worldBuilding?: {
    worldName?: string;
    laws?: string[];
  };
  recentHistory?: Array<{ speakerName: string; text: string }>;
  protagonist?: any;
  companions?: any[];
  conversationMemory?: any;
}): string {
  const res = generateAutonomousSceneNarrationFull(params);
  return res.text;
}
