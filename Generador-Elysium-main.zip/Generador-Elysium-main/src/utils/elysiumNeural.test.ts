// =========================================================================
// PRUEBAS DE ELYSIUM NEURAL CORE
// =========================================================================

import { ElysiumNeural, NeuralInput, NeuralOutput, NeuralConfig, DEFAULT_NEURAL_CONFIG } from './elysiumNeuralCore';
import { CharacterConsciousnessProfile } from './characterConsciousnessEngine';

// -------------------------------------------------------------------------
// CONFIGURACIÓN DE PRUEBAS
// -------------------------------------------------------------------------

describe('Elysium Neural Core', () => {
  let neural: ElysiumNeural;
  
  beforeEach(() => {
    neural = new ElysiumNeural();
  });
  
  afterEach(() => {
    // Limpiar sesiones después de cada prueba
    const sessions = neural['sessions'];
    sessions.forEach((_, key) => {
      neural.deleteSession(key);
    });
  });

  // -------------------------------------------------------------------------
  // PRUEBAS DE INICIALIZACIÓN
  // -------------------------------------------------------------------------

  describe('Initialization', () => {
    it('should initialize with default configuration', () => {
      expect(neural['config'].model).toBe('elysium-ultimate');
      expect(neural['config'].enableAllFeatures).toBe(true);
      expect(neural['config'].enableAdvancedReasoning).toBe(true);
      expect(neural['config'].enableMemorySystem).toBe(true);
      expect(neural['config'].enablePersonalitySystem).toBe(true);
      expect(neural['config'].enableSomaticSystem).toBe(true);
      expect(neural['config'].enableKnowledgeSystem).toBe(true);
    });

    it('should allow custom configuration', () => {
      const customConfig: Partial<NeuralConfig> = {
        model: 'elysium-v2',
        enableAdvancedReasoning: false,
        maxResponseLength: 512,
      };
      const customNeural = new ElysiumNeural(customConfig);
      expect(customNeural['config'].model).toBe('elysium-v2');
      expect(customNeural['config'].enableAdvancedReasoning).toBe(false);
      expect(customNeural['config'].maxResponseLength).toBe(512);
    });

    it('should create singleton instance', () => {
      const { elysiumNeural } = require('./elysiumNeuralCore');
      expect(elysiumNeural).toBeInstanceOf(ElysiumNeural);
    });
  });

  // -------------------------------------------------------------------------
  // PRUEBAS DE GESTIÓN DE SESIONES
  // -------------------------------------------------------------------------

  describe('Session Management', () => {
    it('should create a new session', () => {
      const session = neural.createSession('test-session-1');
      expect(session.id).toBe('test-session-1');
      expect(session.conversationHistory).toEqual([]);
      expect(session.activeCharacters.size).toBe(0);
      expect(neural.getSession('test-session-1')).toBeDefined();
    });

    it('should retrieve existing session', () => {
      neural.createSession('test-session-2', {
        place: { name: 'Bosque de Elysium', weather: 'soleado' },
      });
      const session = neural.getSession('test-session-2');
      expect(session).toBeDefined();
      expect(session?.place.name).toBe('Bosque de Elysium');
    });

    it('should delete a session', () => {
      neural.createSession('test-session-3');
      expect(neural.getSession('test-session-3')).toBeDefined();
      
      const deleted = neural.deleteSession('test-session-3');
      expect(deleted).toBe(true);
      expect(neural.getSession('test-session-3')).toBeUndefined();
    });

    it('should update session context', () => {
      neural.createSession('test-session-4');
      const updated = neural.updateSessionContext('test-session-4', {
        place: { name: 'Castillo de Cristal', hour: 'medianoche' },
      });
      expect(updated).toBe(true);
      
      const session = neural.getSession('test-session-4');
      expect(session?.place.name).toBe('Castillo de Cristal');
      expect(session?.place.hour).toBe('medianoche');
    });

    it('should return undefined for non-existent session', () => {
      expect(neural.getSession('non-existent')).toBeUndefined();
    });
  });

  // -------------------------------------------------------------------------
  // PRUEBAS DE PROCESAMIENTO DE ENTRADA
  // -------------------------------------------------------------------------

  describe('Input Processing', () => {
    const testProfile: CharacterConsciousnessProfile = {
      id: 'test-char-1',
      name: 'Aeloria',
      role: 'Maga Arcana',
      archetype: 'Sabia',
      personality: 'Inteligente, observadora y empática',
      moralAlignment: 'Neutral Bondadosa',
      coreValues: 'Conocimiento, Sabiduría, Protección',
      motivations: ['Descubrir secretos perdidos', 'Proteger el equilibrio cósmico'],
      greatestFear: 'La ignorancia eterna',
      race: 'Elfo de la Luna',
      age: 250,
      backstory: ['Criada en la Torre del Conocimiento', 'Maestra de las artes arcanas'],
    };

    it('should process user message', async () => {
      const input: NeuralInput = {
        type: 'user_message',
        text: 'Hola, ¿cómo estás?',
        sender: { id: 'user-1', name: 'Jugador', role: 'Protagonista', type: 'user' },
      };

      const output = await neural.processInput(input);
      expect(output.responseType).toBe('dialogue');
      expect(output.text).toBeTruthy();
      expect(output.text.length).toBeGreaterThan(0);
      expect(output.isFallback).toBe(false);
    });

    it('should process character dialogue', async () => {
      const input: NeuralInput = {
        type: 'character_dialogue',
        text: '¿Qué opinas de mi propuesta?',
        characterProfile: testProfile,
        sender: { id: 'npc-1', name: 'Aeloria', role: 'Maga', type: 'npc' },
        target: { id: 'user-1', name: 'Jugador', role: 'Protagonista', type: 'user' },
      };

      const output = await neural.processInput(input);
      expect(output.responseType).toBe('dialogue');
      expect(output.text).toBeTruthy();
      expect(output.speaker?.name).toBe('Aeloria');
      expect(output.speaker?.role).toBe('Maga Arcana');
    });

    it('should process narrator request', async () => {
      const input: NeuralInput = {
        type: 'narrator_request',
        text: 'Describe la escena actual',
        place: { name: 'Bosque Encantado', weather: 'neblinoso', hour: 'amanecer' },
        worldBuilding: { worldName: 'Elysium', laws: ['La magia fluye libremente'] },
      };

      const output = await neural.processInput(input);
      expect(output.responseType).toBe('narration');
      expect(output.speaker?.name).toBe('Narrador');
      expect(output.speaker?.role).toBe('Maestro de Juego');
      expect(output.narrationInfo).toBeDefined();
    });

    it('should process OOC query', async () => {
      const input: NeuralInput = {
        type: 'ooc_query',
        text: '¿Cuál es la hora actual en el juego?',
        place: { name: 'Taberna del Dragón', hour: 'tarde' },
      };

      const output = await neural.processInput(input);
      expect(output.responseType).toBe('analysis');
      expect(output.speaker?.name).toBe('Sistema OOC');
    });

    it('should process knowledge query', async () => {
      const input: NeuralInput = {
        type: 'knowledge_query',
        text: 'Dime sobre el honor',
        knowledgeDomains: ['ethics'],
      };

      const output = await neural.processInput(input);
      expect(output.responseType).toBe('knowledge_response');
      expect(output.appliedKnowledge).toBeDefined();
      expect(output.appliedKnowledge?.length).toBeGreaterThan(0);
    });

    it('should process memory consolidation', async () => {
      const sessionId = 'memory-test-session';
      neural.createSession(sessionId, {
        conversationHistory: [
          { sender: 'Jugador', text: 'Hola Aeloria', timestamp: new Date().toISOString() },
          { sender: 'Aeloria', text: 'Hola Jugador, ¿en qué puedo ayudarte?', timestamp: new Date().toISOString() },
        ],
      });

      const input: NeuralInput = {
        type: 'memory_consolidation',
        conversationHistory: [
          { sender: 'Jugador', text: 'Hola Aeloria', timestamp: new Date().toISOString() },
          { sender: 'Aeloria', text: 'Hola Jugador, ¿en qué puedo ayudarte?', timestamp: new Date().toISOString() },
        ],
      };

      const output = await neural.processInput(input, sessionId);
      expect(output.responseType).toBe('memory_update');
      expect(output.memoryUpdate).toBeDefined();
    });

    it('should process system command', async () => {
      const sessionId = 'command-test-session';
      neural.createSession(sessionId);

      const input: NeuralInput = {
        type: 'system_command',
        text: 'reiniciar',
      };

      const output = await neural.processInput(input, sessionId);
      expect(output.responseType).toBe('command_response');
      expect(output.text).toContain('reiniciado');
    });

    it('should handle empty input', async () => {
      const input: NeuralInput = {
        type: 'user_message',
        text: '',
      };

      const output = await neural.processInput(input);
      expect(output.responseType).toBe('error');
      expect(output.error).toContain('vac\u00edo');
    });

    it('should handle invalid input type', async () => {
      const input = { type: 'invalid' as any, text: 'test' };
      const output = await neural.processInput(input as NeuralInput);
      // Debería caer al default (user_message)
      expect(output.responseType).toBe('dialogue');
    });
  });

  // -------------------------------------------------------------------------
  // PRUEBAS DE PERSONALIDAD DE PERSONAJE
  // -------------------------------------------------------------------------

  describe('Character Personality', () => {
    const warriorProfile: CharacterConsciousnessProfile = {
      id: 'warrior-1',
      name: 'Garrick',
      role: 'Guerrero',
      archetype: 'Protector',
      personality: 'Valiente, leal y disciplinado',
      moralAlignment: 'Legal Bondadoso',
      coreValues: 'Honor, Lealtad, Coraje',
      motivations: ['Proteger a los débiles', 'Derrotar a las fuerzas del mal'],
      greatestFear: 'Fracasar en proteger a sus seres queridos',
      race: 'Humano',
      age: 35,
    };

    const mageProfile: CharacterConsciousnessProfile = {
      id: 'mage-1',
      name: 'Lyria',
      role: 'Hechicera',
      archetype: 'Erudita',
      personality: 'Curiosa, analítica y reservada',
      moralAlignment: 'Neutral',
      coreValues: 'Conocimiento, Precisión, Sabiduría',
      motivations: ['Descubrir secretos arcanos', 'Perfeccionar sus habilidades'],
      greatestFear: 'Pérdida de conocimiento',
      race: 'Elfo',
      age: 150,
    };

    it('should generate different responses based on character profile', async () => {
      const warriorInput: NeuralInput = {
        type: 'character_dialogue',
        text: '¿Qué hacemos con este enemigo?',
        characterProfile: warriorProfile,
      };

      const mageInput: NeuralInput = {
        type: 'character_dialogue',
        text: '¿Qué hacemos con este enemigo?',
        characterProfile: mageProfile,
      };

      const warriorOutput = await neural.processInput(warriorInput);
      const mageOutput = await neural.processInput(mageInput);

      // Ambos deberían responder, pero con estilos diferentes
      expect(warriorOutput.text).toBeTruthy();
      expect(mageOutput.text).toBeTruthy();
      expect(warriorOutput.speaker?.name).toBe('Garrick');
      expect(mageOutput.speaker?.name).toBe('Lyria');
    });

    it('should include cognitive appraisal for character dialogue', async () => {
      const input: NeuralInput = {
        type: 'character_dialogue',
        text: 'Temo que no podamos ganar esta batalla',
        characterProfile: warriorProfile,
      };

      const output = await neural.processInput(input);
      expect(output.cognitiveAppraisal).toBeDefined();
      if (output.cognitiveAppraisal) {
        expect(output.cognitiveAppraisal.fearTriggered).toBeDefined();
        expect(output.cognitiveAppraisal.moralAlignmentScore).toBeDefined();
      }
    });
  });

  // -------------------------------------------------------------------------
  // PRUEBAS DE MEMORIA DE CONVERSACIÓN
  // -------------------------------------------------------------------------

  describe('Conversation Memory', () => {
    it('should maintain conversation history in session', async () => {
      const sessionId = 'memory-test-1';
      neural.createSession(sessionId);

      const input1: NeuralInput = {
        type: 'user_message',
        text: 'Primera pregunta',
        sender: { id: 'user-1', name: 'Jugador', role: 'Protagonista', type: 'user' },
      };

      const input2: NeuralInput = {
        type: 'user_message',
        text: 'Segunda pregunta',
        sender: { id: 'user-1', name: 'Jugador', role: 'Protagonista', type: 'user' },
      };

      await neural.processInput(input1, sessionId);
      await neural.processInput(input2, sessionId);

      const session = neural.getSession(sessionId);
      expect(session?.conversationHistory.length).toBe(2);
    });

    it('should update memory with key facts', async () => {
      const sessionId = 'memory-test-2';
      neural.createSession(sessionId);

      const input: NeuralInput = {
        type: 'character_dialogue',
        text: 'Te prometo que protegeré este lugar',
        characterProfile: {
          id: 'npc-1',
          name: 'Aeloria',
          role: 'Maga',
          archetype: 'Sabia',
          personality: 'Inteligente',
          moralAlignment: 'Neutral',
          coreValues: 'Conocimiento',
          motivations: ['Proteger'],
          greatestFear: 'Pérdida',
          race: 'Elfo',
          age: 200,
        },
      };

      const output = await neural.processInput(input, sessionId);
      
      if (output.memoryUpdate) {
        // Debería haber actualizado la memoria
        expect(output.memoryUpdate.keyFacts.length).toBeGreaterThanOrEqual(0);
      }
    });
  });

  // -------------------------------------------------------------------------
  // PRUEBAS DE CONOCIMIENTO ONTOLÓGICO
  // -------------------------------------------------------------------------

  describe('Ontological Knowledge', () => {
    it('should retrieve knowledge for specific domains', async () => {
      const input: NeuralInput = {
        type: 'knowledge_query',
        text: 'honor y lealtad',
        knowledgeDomains: ['ethics'],
      };

      const output = await neural.processInput(input);
      expect(output.appliedKnowledge).toBeDefined();
      expect(output.appliedKnowledge?.some(k => k.domain === 'ethics')).toBe(true);
    });

    it('should analyze scene with knowledge', async () => {
      const input: NeuralInput = {
        type: 'scene_description',
        text: 'El bosque está oscuro y hay niebla',
        place: { name: 'Bosque de las Sombras', weather: 'neblinoso', hour: 'noche' },
      };

      const output = await neural.processInput(input);
      expect(output.narrationInfo).toBeDefined();
      if (output.narrationInfo) {
        expect(output.narrationInfo.environmentalShift).toBeTruthy();
        expect(output.narrationInfo.directorIntent).toBeTruthy();
      }
    });
  });

  // -------------------------------------------------------------------------
  // PRUEBAS DE RENDIMIENTO Y TIEMPO
  // -------------------------------------------------------------------------

  describe('Performance', () => {
    it('should process input within reasonable time', async () => {
      const startTime = Date.now();
      
      const input: NeuralInput = {
        type: 'user_message',
        text: 'Esta es una pregunta compleja que requiere análisis profundo de múltiples aspectos del juego y los personajes involucrados.',
      };

      const output = await neural.processInput(input);
      const processingTime = Date.now() - startTime;

      expect(processingTime).toBeLessThan(5000); // Menos de 5 segundos
      expect(output.processingTime).toBeLessThan(5000);
    });

    it('should count tokens correctly', async () => {
      const input: NeuralInput = {
        type: 'user_message',
        text: 'Hola mundo esto es una prueba',
      };

      const output = await neural.processInput(input);
      expect(output.tokens).toBeGreaterThan(0);
    });
  });

  // -------------------------------------------------------------------------
  // PRUEBAS DE MÉTODOS ESTÁTICOS
  // -------------------------------------------------------------------------

  describe('Static Methods', () => {
    it('should create roleplay-optimized instance', () => {
      const roleplayNeural = ElysiumNeural.createForRoleplay();
      expect(roleplayNeural['config'].enableAllFeatures).toBe(true);
      expect(roleplayNeural['config'].enableAdvancedReasoning).toBe(true);
      expect(roleplayNeural['config'].enableMemorySystem).toBe(true);
      expect(roleplayNeural['config'].enablePersonalitySystem).toBe(true);
      expect(roleplayNeural['config'].enableSomaticSystem).toBe(true);
      expect(roleplayNeural['config'].enableKnowledgeSystem).toBe(true);
    });

    it('should create minimal instance', () => {
      const minimalNeural = ElysiumNeural.createMinimal();
      expect(minimalNeural['config'].enableAllFeatures).toBe(false);
      expect(minimalNeural['config'].enableAdvancedReasoning).toBe(false);
      expect(minimalNeural['config'].enableMemorySystem).toBe(false);
      expect(minimalNeural['config'].enablePersonalitySystem).toBe(false);
      expect(minimalNeural['config'].enableSomaticSystem).toBe(false);
      expect(minimalNeural['config'].enableKnowledgeSystem).toBe(false);
    });

    it('should process simple input without session', async () => {
      const output = await ElysiumNeural.processSimpleInput('Hola, ¿cómo estás?');
      expect(output.responseType).toBe('dialogue');
      expect(output.text).toBeTruthy();
    });
  });

  // -------------------------------------------------------------------------
  // PRUEBAS DE ESCENARIOS COMPLEJOS
  // -------------------------------------------------------------------------

  describe('Complex Scenarios', () => {
    it('should handle multi-character conversation', async () => {
      const sessionId = 'complex-scenario-1';
      neural.createSession(sessionId, {
        place: { name: 'Taberna del Oso', weather: 'lluvioso', hour: 'noche' },
        worldBuilding: { worldName: 'Elysium', laws: ['La magia tiene un costo'] },
      });

      const protagonist: NeuralInput['protagonist'] = {
        id: 'prot-1',
        name: 'Adrian',
        role: 'Aventurero',
        type: 'user',
      };

      const companions: NeuralInput['companions'] = [
        {
          id: 'npc-1',
          name: 'Garrick',
          role: 'Guerrero',
          type: 'npc',
          consciousnessProfile: {
            id: 'npc-1',
            name: 'Garrick',
            role: 'Guerrero',
            archetype: 'Protector',
            personality: 'Valiente',
            moralAlignment: 'Legal Bondadoso',
            coreValues: 'Honor',
            motivations: ['Proteger'],
            greatestFear: 'Fracaso',
            race: 'Humano',
            age: 35,
          },
        } as any,
      ];

      const input: NeuralInput = {
        type: 'narrator_request',
        text: 'Describe lo que ven los personajes al entrar',
        protagonist,
        companions,
      };

      const output = await neural.processInput(input, sessionId);
      expect(output.responseType).toBe('narration');
      expect(output.text.length).toBeGreaterThan(50);
    });

    it('should handle combat scenario', async () => {
      const input: NeuralInput = {
        type: 'character_dialogue',
        text: '¡Cuidado! ¡Hay un dragón!',
        characterProfile: {
          id: 'npc-2',
          name: 'Lyria',
          role: 'Hechicera',
          archetype: 'Erudita',
          personality: 'Rápida y estratégica',
          moralAlignment: 'Neutral',
          coreValues: 'Supervivencia',
          motivations: ['Proteger al grupo'],
          greatestFear: 'Muerte',
          race: 'Elfo',
          age: 150,
        },
        place: { name: 'Cueva del Dragón', weather: 'caluroso' },
      };

      const output = await neural.processInput(input);
      expect(output.responseType).toBe('dialogue');
      expect(output.semanticAnalysis?.intent).toBe('combat_alert');
    });

    it('should handle philosophical debate', async () => {
      const input: NeuralInput = {
        type: 'character_dialogue',
        text: '¿Qué es más importante: el honor o la supervivencia?',
        characterProfile: {
          id: 'npc-3',
          name: 'Maestro Eldrin',
          role: 'Sabio',
          archetype: 'Filósofo',
          personality: 'Sabio y contemplativo',
          moralAlignment: 'Neutral',
          coreValues: 'Sabiduría, Equilibrio',
          motivations: ['Enseñar', 'Guiar'],
          greatestFear: 'Ignorancia',
          race: 'Anciano',
          age: 500,
        },
      };

      const output = await neural.processInput(input);
      expect(output.responseType).toBe('dialogue');
      expect(output.semanticAnalysis?.intent).toBe('philosophical_debate');
    });
  });

  // -------------------------------------------------------------------------
  // PRUEBAS DE ERRORES Y CASOS LÍMITE
  // -------------------------------------------------------------------------

  describe('Error Handling', () => {
    it('should handle missing text', async () => {
      const input = { type: 'user_message' } as any;
      const output = await neural.processInput(input);
      expect(output.responseType).toBe('error');
      expect(output.error).toContain('requerido');
    });

    it('should handle invalid character profile', async () => {
      const input: NeuralInput = {
        type: 'character_dialogue',
        text: 'Hola',
        characterProfile: {} as any,
      };

      const output = await neural.processInput(input);
      // Debería manejar el perfil inválido sin romperse
      expect(output.responseType).toBeDefined();
    });

    it('should handle very long input', async () => {
      const longText = 'A'.repeat(5000);
      const input: NeuralInput = {
        type: 'user_message',
        text: longText,
      };

      const output = await neural.processInput(input);
      expect(output.responseType).toBe('dialogue');
      expect(output.text.length).toBeGreaterThan(0);
    });

    it('should handle special characters', async () => {
      const input: NeuralInput = {
        type: 'user_message',
        text: '¡Hola! ¿Cómo estás? \u00bfQué tal?',
      };

      const output = await neural.processInput(input);
      expect(output.responseType).toBe('dialogue');
      expect(output.text).toBeTruthy();
    });
  });
});

// -------------------------------------------------------------------------
// PRUEBAS DE INTEGRACIÓN
// -------------------------------------------------------------------------

describe('Integration Tests', () => {
  it('should work with character consciousness engine', async () => {
    const neural = new ElysiumNeural();
    const profile: CharacterConsciousnessProfile = {
      id: 'integration-test-1',
      name: 'Test Character',
      role: 'Test Role',
      archetype: 'Test Archetype',
      personality: 'Test Personality',
      moralAlignment: 'Neutral',
      coreValues: 'Test Values',
      motivations: ['Test Motivation'],
      greatestFear: 'Test Fear',
      race: 'Test Race',
      age: 100,
    };

    const input: NeuralInput = {
      type: 'character_dialogue',
      text: 'Test message',
      characterProfile: profile,
    };

    const output = await neural.processInput(input);
    expect(output.responseType).toBe('dialogue');
    expect(output.speaker?.name).toBe('Test Character');
  });

  it('should maintain state across multiple calls', async () => {
    const neural = new ElysiumNeural();
    const sessionId = 'integration-session-1';
    neural.createSession(sessionId);

    // Primer mensaje
    const input1: NeuralInput = {
      type: 'user_message',
      text: 'Primera interacción',
      sender: { id: 'user-1', name: 'Jugador', role: 'Protagonista', type: 'user' },
    };
    await neural.processInput(input1, sessionId);

    // Segundo mensaje
    const input2: NeuralInput = {
      type: 'user_message',
      text: 'Segunda interacción',
      sender: { id: 'user-1', name: 'Jugador', role: 'Protagonista', type: 'user' },
    };
    await neural.processInput(input2, sessionId);

    // Verificar que la sesión tiene historial
    const session = neural.getSession(sessionId);
    expect(session?.conversationHistory.length).toBe(2);
  });
});
