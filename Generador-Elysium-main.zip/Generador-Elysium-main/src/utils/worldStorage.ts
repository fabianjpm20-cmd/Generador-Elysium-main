import { WorldPlace, WorldBuildingConfig, WorldFaction, WorldLaw } from '../types';
import { DEFAULT_PLACES, DEFAULT_WORLDBUILDING } from '../data/worldData';
import { getSavedCharacters, saveCharacterToLibrary } from './libraryStorage';

export const PLACES_STORAGE_KEY = 'ELYSIUM_WORLD_PLACES_V1';
export const WORLDBUILDING_STORAGE_KEY = 'ELYSIUM_WORLDBUILDING_V1';
export const WORLDBUILDING_LIST_STORAGE_KEY = 'ELYSIUM_WORLDBUILDINGS_LIST_V2';

export const getSavedPlaces = (): WorldPlace[] => {
  try {
    const raw = localStorage.getItem(PLACES_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(PLACES_STORAGE_KEY, JSON.stringify(DEFAULT_PLACES));
      return DEFAULT_PLACES;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : DEFAULT_PLACES;
  } catch (err) {
    console.error('Error loading places:', err);
    return DEFAULT_PLACES;
  }
};

export const savePlace = (place: WorldPlace): WorldPlace => {
  const list = getSavedPlaces();
  const existingIdx = list.findIndex(p => p.id === place.id);
  let updatedList: WorldPlace[];

  if (existingIdx >= 0) {
    updatedList = [...list];
    updatedList[existingIdx] = place;
  } else {
    const newPlace = {
      ...place,
      id: place.id || `LOC-${Date.now()}`,
      createdAt: place.createdAt || new Date().toISOString().slice(0, 10)
    };
    updatedList = [newPlace, ...list];
  }

  localStorage.setItem(PLACES_STORAGE_KEY, JSON.stringify(updatedList));
  return place;
};

export const deletePlace = (id: string): boolean => {
  const list = getSavedPlaces();
  const filtered = list.filter(p => p.id !== id);
  if (filtered.length === list.length) return false;
  localStorage.setItem(PLACES_STORAGE_KEY, JSON.stringify(filtered));
  return true;
};

// ==========================================
// WORLDBUILDING LIST & CRUD STORAGE
// ==========================================

export const getSavedWorldConfigs = (): WorldBuildingConfig[] => {
  try {
    const raw = localStorage.getItem(WORLDBUILDING_LIST_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
    // Check legacy single storage key
    const singleRaw = localStorage.getItem(WORLDBUILDING_STORAGE_KEY);
    if (singleRaw) {
      const parsedSingle = JSON.parse(singleRaw);
      if (parsedSingle?.worldName) {
        const initialList = [parsedSingle];
        localStorage.setItem(WORLDBUILDING_LIST_STORAGE_KEY, JSON.stringify(initialList));
        return initialList;
      }
    }
    // Fallback to default
    const initialList = [DEFAULT_WORLDBUILDING];
    localStorage.setItem(WORLDBUILDING_LIST_STORAGE_KEY, JSON.stringify(initialList));
    localStorage.setItem(WORLDBUILDING_STORAGE_KEY, JSON.stringify(DEFAULT_WORLDBUILDING));
    return initialList;
  } catch (err) {
    console.error('Error loading worldbuilding list:', err);
    return [DEFAULT_WORLDBUILDING];
  }
};

export const getWorldBuildingConfig = (): WorldBuildingConfig => {
  try {
    const raw = localStorage.getItem(WORLDBUILDING_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed?.worldName) return parsed;
    }
    const all = getSavedWorldConfigs();
    return all[0] || DEFAULT_WORLDBUILDING;
  } catch (err) {
    console.error('Error loading active worldbuilding:', err);
    return DEFAULT_WORLDBUILDING;
  }
};

export const saveWorldBuildingConfig = (config: WorldBuildingConfig): void => {
  // Save as current active
  localStorage.setItem(WORLDBUILDING_STORAGE_KEY, JSON.stringify(config));
  // Also update in list
  const list = getSavedWorldConfigs();
  const index = list.findIndex(w => w.id === config.id);
  let updatedList: WorldBuildingConfig[];
  if (index >= 0) {
    updatedList = [...list];
    updatedList[index] = config;
  } else {
    updatedList = [config, ...list];
  }
  localStorage.setItem(WORLDBUILDING_LIST_STORAGE_KEY, JSON.stringify(updatedList));
};

export const duplicateWorldBuilding = (id: string): WorldBuildingConfig | null => {
  const list = getSavedWorldConfigs();
  const source = list.find(w => w.id === id);
  if (!source) return null;

  const currentVer = source.version || 'v1.0';
  const verNum = parseFloat(currentVer.replace('v', '')) || 1.0;
  const newVer = `v${(verNum + 0.1).toFixed(1)}`;

  const duplicated: WorldBuildingConfig = {
    ...JSON.parse(JSON.stringify(source)),
    id: `WORLD-${Date.now()}`,
    worldName: `${source.worldName} (Copia)`,
    version: newVer
  };

  const updatedList = [duplicated, ...list];
  localStorage.setItem(WORLDBUILDING_LIST_STORAGE_KEY, JSON.stringify(updatedList));
  return duplicated;
};

export const deleteWorldBuilding = (id: string): boolean => {
  const list = getSavedWorldConfigs();
  const filtered = list.filter(w => w.id !== id);
  if (filtered.length === list.length) return false;
  
  // If we deleted all, keep DEFAULT_WORLDBUILDING
  const finalList = filtered.length > 0 ? filtered : [DEFAULT_WORLDBUILDING];
  localStorage.setItem(WORLDBUILDING_LIST_STORAGE_KEY, JSON.stringify(finalList));
  
  // Update active if active was deleted
  const current = getWorldBuildingConfig();
  if (current.id === id) {
    localStorage.setItem(WORLDBUILDING_STORAGE_KEY, JSON.stringify(finalList[0]));
  }
  return true;
};

export const createEmptyWorldBuilding = (): WorldBuildingConfig => {
  return {
    ...JSON.parse(JSON.stringify(DEFAULT_WORLDBUILDING)),
    id: `WORLD-${Date.now()}`,
    worldName: 'Nuevo Mundo & Reino',
    version: 'v1.0'
  };
};

export const createEmptyPlace = (): WorldPlace => {
  return {
    id: `LOC-${Date.now()}`,
    name: 'Nuevo Escenario o Distrito',
    version: 'v1.0',
    geographicContext: 'Distrito urbano o asentamiento',
    rhythmOrVibes: ['Tranquilo', 'Vigilado'],
    region: 'Provincia Central',
    environmentType: 'Ciudadela',
    dangerLevel: 'Seguro',
    atmosphere: 'Brisa templada, aroma a piedra cálida y susurros de transeúntes.',
    description: 'Lugar estructurado con arquitectura organizada y servicios comunales.',
    constructionStyle: 'Tradicional',
    materials: ['Piedra', 'Madera'],
    condition: 'Conservado',
    criticalPointsOfInterest: [
      {
        id: `POI-${Date.now()}-1`,
        name: 'Plaza de Encuentro',
        type: 'Plaza',
        function: 'Punto de reunión comunal y comercio ligero',
        owner: 'Comunidad',
        location: 'Sector central',
        description: 'Espacio abierto con bancos de piedra y farolas.',
        importance: 'Alta'
      }
    ],
    convergenceZones: [
      {
        id: `ZONE-${Date.now()}-1`,
        name: 'Avenida de los Mercaderes',
        type: 'Calle comercial',
        schedule: 'Todo el día',
        npcDensity: 'Media',
        frequentEvents: 'Paseo de ciudadanos y comercio',
        securityLevel: 'Medio',
        associatedCharacters: ['Transeúntes', 'Vendedores']
      }
    ],
    cultureAndSecurity: {
      authority: 'Gobierno local',
      surveillance: 'Media',
      socialConduct: ['Cortesía', 'Comercio justo']
    },
    hasHousing: false,
    uniqueElements: [],
    pointsOfInterest: ['Plaza de Encuentro', 'Avenida de los Mercaderes'],
    ambientColorTheme: 'from-amber-950/40 via-stone-900/40 to-black',
    createdAt: new Date().toISOString().slice(0, 10)
  };
};

export const toggleWorldLaw = (lawId: string): WorldBuildingConfig => {
  const current = getWorldBuildingConfig();
  const updatedLaws = current.laws.map(l => l.id === lawId ? { ...l, isActive: !l.isActive } : l);
  const updatedConfig = { ...current, laws: updatedLaws };
  saveWorldBuildingConfig(updatedConfig);
  return updatedConfig;
};

export const saveFaction = (faction: WorldFaction): WorldBuildingConfig => {
  const current = getWorldBuildingConfig();
  const existingIdx = current.factions.findIndex(f => f.id === faction.id);
  let updatedFactions: WorldFaction[];
  if (existingIdx >= 0) {
    updatedFactions = [...current.factions];
    updatedFactions[existingIdx] = faction;
  } else {
    updatedFactions = [...current.factions, { ...faction, id: faction.id || `FAC-${Date.now()}` }];
  }
  const updatedConfig = { ...current, factions: updatedFactions };
  saveWorldBuildingConfig(updatedConfig);
  return updatedConfig;
};

export const saveWorldLaw = (law: WorldLaw): WorldBuildingConfig => {
  const current = getWorldBuildingConfig();
  const existingIdx = current.laws.findIndex(l => l.id === law.id);
  let updatedLaws: WorldLaw[];
  if (existingIdx >= 0) {
    updatedLaws = [...current.laws];
    updatedLaws[existingIdx] = law;
  } else {
    updatedLaws = [...current.laws, { ...law, id: law.id || `LAW-${Date.now()}` }];
  }
  const updatedConfig = { ...current, laws: updatedLaws };
  saveWorldBuildingConfig(updatedConfig);
  return updatedConfig;
};

export const duplicatePlace = (sourcePlaceId: string): WorldPlace | null => {
  const list = getSavedPlaces();
  const source = list.find(p => p.id === sourcePlaceId);
  if (!source) return null;

  const currentVer = source.version || 'v1.0';
  const verNum = parseFloat(currentVer.replace('v', '')) || 1.0;
  const newVer = `v${(verNum + 0.1).toFixed(1)}`;

  const duplicated: WorldPlace = {
    ...JSON.parse(JSON.stringify(source)),
    id: `LOC-${Date.now()}`,
    name: `${source.name} (Copia)`,
    version: newVer,
    createdAt: new Date().toISOString().slice(0, 10),
    updatedAt: new Date().toISOString()
  };

  savePlace(duplicated);
  return duplicated;
};

export const exportSinglePlaceJson = (place: WorldPlace): string => {
  return JSON.stringify(place, null, 2);
};

export const exportWorldBuildingJson = (config: WorldBuildingConfig): string => {
  return JSON.stringify(config, null, 2);
};

// ==========================================
// MÓDULO 2 - PERSISTENCIA DE SESIONES
// ==========================================

export const SESSIONS_STORAGE_KEY = 'ELYSIUM_SAVED_SESSIONS_V1.1';

export const getSavedSessions = (): any[] => {
  try {
    const raw = localStorage.getItem(SESSIONS_STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (err) {
    console.error('Error loading sessions:', err);
    return [];
  }
};

export const saveSimulationSession = (session: any): void => {
  const sessions = getSavedSessions();
  const index = sessions.findIndex(s => s.id === session.id);
  let updated: any[];
  if (index >= 0) {
    updated = [...sessions];
    updated[index] = session;
  } else {
    updated = [session, ...sessions];
  }
  localStorage.setItem(SESSIONS_STORAGE_KEY, JSON.stringify(updated));
};

export const deleteSimulationSession = (sessionId: string): void => {
  const sessions = getSavedSessions().filter(s => s.id !== sessionId);
  localStorage.setItem(SESSIONS_STORAGE_KEY, JSON.stringify(sessions));
};

// ==========================================
// UNIFIED ECOSYSTEM EXPORT & IMPORT
// ==========================================

export interface EcosystemExportData {
  version: string;
  timestamp: string;
  characters: any[];
  places: WorldPlace[];
  worldBuilding: WorldBuildingConfig;
}

export const exportEcosystemToJson = (): string => {
  const data: EcosystemExportData = {
    version: 'ELYSIUM-V2.0',
    timestamp: new Date().toISOString(),
    characters: getSavedCharacters(),
    places: getSavedPlaces(),
    worldBuilding: getWorldBuildingConfig()
  };
  return JSON.stringify(data, null, 2);
};

export const importEcosystemFromJson = (
  jsonStr: string
): { success: boolean; characterCount: number; placeCount: number; error?: string } => {
  try {
    const data: EcosystemExportData = JSON.parse(jsonStr);
    let charCount = 0;
    let placeCount = 0;

    if (Array.isArray(data.characters)) {
      data.characters.forEach(c => {
        if (c.state) {
          saveCharacterToLibrary(c.state, c.variantLabel);
          charCount++;
        }
      });
    }

    if (Array.isArray(data.places)) {
      localStorage.setItem(PLACES_STORAGE_KEY, JSON.stringify(data.places));
      placeCount = data.places.length;
    }

    if (data.worldBuilding && data.worldBuilding.worldName) {
      saveWorldBuildingConfig(data.worldBuilding);
    }

    return { success: true, characterCount: charCount, placeCount: placeCount };
  } catch (err: any) {
    return { success: false, characterCount: 0, placeCount: 0, error: err.message || 'Error parsing JSON' };
  }
};
