import { CharacterState, GarmentConfig, EmblemBuilderConfig } from '../types';
import { BODY_SENSITIVITIES, GENITAL_TYPES } from '../data/nsfwData';

// Helper to check if role is civil or null/empty
export const isRoleNull = (r: string | undefined | null): boolean => {
  if (!r) return true;
  const lower = r.toLowerCase().trim();
  return /^(civil|civil gen[eé]rico|civil general|civil \/ cotidiano|civil cotidiano|ningun[oa]s?|vac[ií]o|sin rol|r-null ninguno|r-null|default|n\/a)$/i.test(lower) || lower === 'civil' || lower === 'r-null ninguno';
};

// Formats a constructed or written emblem/shield/seal configuration into natural phrasing
export const formatEmblemBuilderDescription = (
  cfg?: EmblemBuilderConfig,
  isPrompt = false
): string => {
  if (!cfg) return '';
  const parts: string[] = [];
  if (cfg.symbol) parts.push(isPrompt ? `figura ${cleanVal(cfg.symbol, true)}` : `Figura: ${cfg.symbol}`);
  if (cfg.frame) parts.push(isPrompt ? `marco ${cleanVal(cfg.frame, true)}` : `Marco: ${cfg.frame}`);
  if (cfg.motto) parts.push(isPrompt ? `lema "${cfg.motto}"` : `Lema/Inscripción: "${cfg.motto}"`);
  if (cfg.supportOrnaments && !/sin adorno|minimalista/i.test(cfg.supportOrnaments)) {
    parts.push(isPrompt ? `adornos ${cleanVal(cfg.supportOrnaments, true)}` : `Soportes: ${cfg.supportOrnaments}`);
  }
  if (cfg.description) {
    parts.push(isPrompt ? `detalle: ${cleanVal(cfg.description, true)}` : `Detalle: "${cfg.description}"`);
  }
  return parts.join(isPrompt ? ', ' : '; ');
};

// Helper to check if style is generic or null/empty
export const isStyleNull = (s: string | undefined | null): boolean => {
  if (!s) return true;
  const lower = s.toLowerCase().trim();
  return /^(gen[eé]rico|estilo gen[eé]rico|ningun[oa]s?|default|vac[ií]o|sin estilo|n\/a)$/i.test(lower);
};

// Helper to check if armor protection is valid (filters out 'ninguna', 'sin armadura', 'sin protección', etc. and disabled by civil role)
export const hasValidArmorProtection = (specialType: string | undefined | null, role?: string | null): boolean => {
  if (role && isRoleNull(role)) return false;
  if (!specialType) return false;
  const lower = specialType.trim().toLowerCase();
  if (/^(ningun[oa]s?|none|null|undefined|sin armadura|sin protecci[oó]n|sin proteccion|sin blindaje|desprotegido|civil|sin rol|vac[ií]o|no aplica|n\/a|deshabilitad[oa])$/i.test(lower)) return false;
  if (lower.includes('ningun') || lower.includes('sin armadura') || lower.includes('sin protección') || lower.includes('sin proteccion') || lower.includes('sin blindaje') || lower.includes('desprotegido')) return false;
  return true;
};

// Helper to clean UI values (remove codes like A1, B0, P1.1, and strictly filter out 'ninguno', 'vacío', 'sin ...')
export const cleanVal = (val: string | undefined | null, lower = true): string => {
  if (!val) return '';
  const trimmed = val.trim();
  // Filter out none/null/empty/disabled equivalents
  if (/^(ningun[oa]s?|none|null|undefined|\{\}|\[\]|0|vac[ií]o|sin\s+especificar|no\s+aplica|n\/a|deshabilitad[oa]|no\s+definido|sin\s+asignar)$/i.test(trimmed)) return '';
  if (/^(sin armadura|sin marca|sin marcas|sin tatuaje|sin tatuajes|sin cuernos|sin alas|sin cola|sin protecci[oó]n|sin proteccion|sin blindaje|desprotegido|sin gema|sin grabado|sin adorno|sin adornos|sin detalle|sin detalles|sin aplicaciones|sin vfx|sin efecto|sin efectos|sin aura|sin arma|sin armas|sin bolso|sin bolsos|sin objeto|sin objetos|sin reliquia|sin contenedor|desarmado|sin modificador)$/i.test(trimmed)) return '';
  if (/^ningun[oa]\s*(\/|-)\s*sin\s+(armadura|protecci[oó]n|blindaje|aura|gema|grabado|accesorio|arma|efecto|modificador)$/i.test(trimmed)) return '';
  if (/^sin\s+aura\s*\([^)]*\)$/i.test(trimmed)) return '';
  if (/^sin\s+aura$/i.test(trimmed)) return '';
  if (/^r-null\s*ninguno$/i.test(trimmed)) return '';
  if (/^sin\s+gema\s*\/\s*met[aá]lico\s+puro$/i.test(trimmed)) return '';
  if (/^sin\s+grabado\s*\/\s*liso\s+pulido$/i.test(trimmed)) return '';
  if (/^sin\s+dise[ñn]o\s*\/\s*liso$/i.test(trimmed)) return '';
  if (/^t0\s+piel\s+lisa\s+est[aá]ndar$/i.test(trimmed)) return '';
  if (/^sin\s+orejas\s+kemono$/i.test(trimmed)) return '';
  if (/^sin\s+flequillo$/i.test(trimmed)) return '';
  if (/^sin\s+partido$/i.test(trimmed)) return '';
  if (/^sin\s+rubor$/i.test(trimmed)) return '';
  if (/^sin\s+delineado$/i.test(trimmed)) return '';
  if (/^sin\s+acento$/i.test(trimmed)) return '';
  if (/^labios\s+naturales$/i.test(trimmed)) return '';
  if (/^u[ñn]as\s+naturales$/i.test(trimmed)) return '';
  if (/^sin\s+peinado\s*(\/|-)\s*suelto\s+natural$/i.test(trimmed)) return '';
  
  // Remove category prefixes like "B.x.1.01 - ", "MAT01 - ", "A1 ", "P1.2 ", "M1 ", "1 ", "HST00 ", "DEL1 ", "KEMO-A1 ", etc.
  let cleaned = trimmed
    .replace(/^B\.x\.[0-9A-Za-z.]+\s+-\s+/i, '')
    .replace(/^(MAT|FIN|DET|VAR|CAP|DEL|SOM|EXP|TEX|COM|HST|KEMO|AR|EL|HL|MOD|CAT|SEC)[0-9A-Za-z.\-]*(\s+-\s+|\s+)/i, '')
    .replace(/^[A-Z]{1,4}[0-9]+[A-Z0-9.\-]*(\s+-\s+|\s+)/i, '')
    .replace(/^\d+(\.\d+)?\s+-\s+/i, '')
    .replace(/^\d+(\.\d+)?\s+/i, '')
    .replace(/^[A-G]\s+/i, '')
    .trim();
    
  return lower ? cleaned.toLowerCase() : cleaned;
};

// Resolves canonical group header for genitals according to category and organ (pene, vagina, o ambos)
export const resolveGenitalHeader = (genitalTypeStr?: string, sexBase?: string): string => {
  const gClean = cleanVal(genitalTypeStr, false);
  const found = GENITAL_TYPES.find(gt => gt.name === gClean || gt.id === gClean);

  if (found) {
    if (found.category === 'Masculino') {
      return '- Genitales Masculinos (pene)';
    }
    if (found.category === 'Femenino') {
      return '- Genitales Femeninos (vagina)';
    }
    // Fantasía / Andrógino
    const lower = found.name.toLowerCase();
    if (lower.includes('dual') || lower.includes('hermafrodita') || lower.includes('ambos')) {
      return '- Genitales Hermafroditas / Mixtos (ambos: pene y vagina)';
    }
    if (lower.includes('falo') || lower.includes('pene') || lower.includes('bulbo')) {
      return '- Genitales Masculinos (pene)';
    }
    if (lower.includes('vulva') || lower.includes('vagina') || lower.includes('hendidura')) {
      return '- Genitales Femeninos (vagina)';
    }
  }

  if (gClean) {
    const lower = gClean.toLowerCase();
    if (lower.includes('dual') || lower.includes('hermafrodita') || (lower.includes('pene') && lower.includes('vagina'))) {
      return '- Genitales Hermafroditas / Mixtos (ambos: pene y vagina)';
    }
    if (lower.includes('falo') || lower.includes('pene') || lower.includes('glande') || lower.includes('escroto')) {
      return '- Genitales Masculinos (pene)';
    }
    if (lower.includes('vulva') || lower.includes('vagina') || lower.includes('clítoris') || lower.includes('hendidura')) {
      return '- Genitales Femeninos (vagina)';
    }
  }

  // Fallback using anatomy sexBase
  const sb = (sexBase || '').toLowerCase();
  if (sb.includes('masculin') || sb.includes('hombre') || sb.includes('varón') || sb.includes('varon')) {
    return '- Genitales Masculinos (pene)';
  }
  if (sb.includes('femenin') || sb.includes('mujer')) {
    return '- Genitales Femeninos (vagina)';
  }
  if (sb.includes('andróg') || sb.includes('intersex') || sb.includes('hermafrodita')) {
    return '- Genitales Hermafroditas / Mixtos (ambos: pene y vagina)';
  }

  return '- Genitales (pene / vagina)';
};

export const buildPart = (label: string, val: string | undefined | null, lower = true): string => {
  const c = cleanVal(val, lower);
  return c ? `${label} ${c}` : '';
};

// Formats natural body location string (e.g. "Rostro: Ojo Derecho" -> "en el ojo derecho del rostro")
export const formatLocationSpan = (loc: string): string => {
  const clean = cleanVal(loc, false);
  if (!clean) return '';
  if (clean.includes(':')) {
    const [zone, spot] = clean.split(':').map(s => s.trim());
    return `${spot.toLowerCase()} (${zone.toLowerCase()})`;
  }
  return clean.toLowerCase();
};

// Formats hair length into descriptive natural phrasing
export const formatHairLength = (len: string | undefined | null): string => {
  if (!len) return '';
  const val = len.toLowerCase();
  if (val.includes('rapado') || val.includes('muy corto')) return 'rapado muy corto';
  if (val.includes('nuca')) return 'corto hasta la nuca';
  if (val.includes('hombro') || val.includes('medio')) return 'largo medio hasta los hombros';
  if (val.includes('espalda') || (val.includes('largo') && !val.includes('muy') && !val.includes('extra'))) return 'largo hasta la mitad de la espalda';
  if (val.includes('cintura') || val.includes('muy largo')) return 'muy largo hasta la cintura';
  if (val.includes('piso') || val.includes('extra largo')) return 'extra largo hasta el suelo';
  if (val.includes('asimétrico')) return 'longitud asimétrica variable';
  return cleanVal(len, true);
};

/**
 * Formats a body mark (such as a mole/lunar, tattoo, scar, etc.)
 * Dynamically adapts singular vs plural (e.g. "Lunar" vs "Lunares") based on number of selected locations.
 * Removes plural terms like "pecas" or "pequitas" when only one location/spot is selected.
 */
export const formatMarkDescription = (
  markType: string,
  shapeRaw: string | undefined,
  colorRaw: string | undefined,
  locations: string[],
  isPrompt: boolean = false,
  customText?: string,
  emblemConfig?: EmblemBuilderConfig,
  finishRaw?: string,
  secondaryColorRaw?: string
): string => {
  const cleanType = cleanVal(markType, isPrompt);
  if (!cleanType) return '';

  const locCount = locations.length;
  const isSingular = locCount <= 1;
  const isLunar = /lunar|marca de nacimiento/i.test(markType);

  let categoryName = cleanType;
  let cleanShape = cleanVal(shapeRaw, isPrompt);
  const cleanColor = cleanVal(colorRaw, isPrompt);
  const cleanSecondaryColor = secondaryColorRaw && !/^ningun/i.test(secondaryColorRaw) ? cleanVal(secondaryColorRaw, isPrompt) : '';
  const cleanFinish = cleanVal(finishRaw, isPrompt);
  const emblemDesc = emblemConfig ? formatEmblemBuilderDescription(emblemConfig, isPrompt) : '';

  if (isLunar) {
    if (isSingular) {
      // Force singular: "Lunar"
      categoryName = isPrompt ? 'lunar' : 'Lunar';

      // Clean shape: remove plural words like "pequitas", "pecas", "constelación de pecas"
      if (cleanShape) {
        cleanShape = cleanShape
          .replace(/^Lunar:\s*/i, '')
          .replace(/^Marca:\s*/i, '')
          .replace(/punto simple\s*\/\s*pequitas/gi, isPrompt ? 'punto simple' : 'Punto Simple')
          .replace(/pequitas/gi, isPrompt ? 'punto pequeño' : 'Punto Pequeño')
          .replace(/constelaci[oó]n de pecas\s*\/\s*puntos/gi, isPrompt ? 'punto sutil' : 'Punto Sutil')
          .replace(/pecas/gi, isPrompt ? 'lunar' : 'Lunar')
          .trim();
      }
    } else {
      // Force plural: "Lunares"
      categoryName = isPrompt ? 'lunares' : 'Lunares';

      if (cleanShape) {
        cleanShape = cleanShape
          .replace(/^Lunar:\s*/i, '')
          .replace(/^Marca:\s*/i, '')
          .replace(/punto simple\s*\/\s*pequitas/gi, isPrompt ? 'puntos / pecas' : 'Puntos / Lunares')
          .trim();
      }
    }
  } else {
    if (cleanShape) {
      cleanShape = cleanShape.replace(/^[A-Za-z0-9Á-ú]+:\s*/, '').trim();
    }
  }

  // Preposition and location construction
  let prep = '';
  if (locCount === 1) {
    if (isPrompt) {
      prep = `en ${locations[0]}`;
    } else {
      if (/cicatriz|marca|pintura/i.test(categoryName)) {
        prep = `ubicada en ${locations[0]}`;
      } else {
        prep = `ubicado en ${locations[0]}`;
      }
    }
  } else if (locCount > 1) {
    if (isPrompt) {
      prep = `en ${locations.join(' y ')}`;
    } else {
      if (/cicatriz|marca|pintura/i.test(categoryName)) {
        prep = `ubicadas en ${locations.join(' y ')}`;
      } else {
        prep = `ubicados en ${locations.join(' y ')}`;
      }
    }
  }

  // Build final description
  if (isPrompt) {
    let desc = categoryName;
    if (cleanShape && !cleanShape.toLowerCase().includes(categoryName.toLowerCase())) {
      desc += ` diseño ${cleanShape}`;
    }
    if (customText) {
      desc += ` con texto "${customText}"`;
    }
    if (emblemDesc) {
      desc += ` con ${emblemDesc}`;
    }
    if (cleanFinish) {
      desc += ` acabado ${cleanFinish}`;
    }
    if (cleanColor) {
      desc += ` color ${cleanColor}`;
    }
    if (cleanSecondaryColor) {
      desc += ` con degradado a ${cleanSecondaryColor}`;
    }
    if (prep) {
      desc += ` ${prep}`;
    }
    return desc;
  } else {
    let desc = categoryName;
    if (cleanShape) {
      desc += `, diseño de ${cleanShape}`;
    }
    if (customText) {
      desc += `, con texto/caracteres: "${customText}"`;
    }
    if (emblemDesc) {
      desc += `, composición: ${emblemDesc}`;
    }
    if (cleanFinish) {
      desc += `, acabado: ${cleanFinish}`;
    }
    if (cleanColor) {
      desc += `, color ${cleanColor}`;
    }
    if (cleanSecondaryColor) {
      desc += `, degradado/secundario: ${cleanSecondaryColor}`;
    }
    if (prep) {
      desc += `, ${prep}`;
    }
    return desc;
  }
};

// Helper to map color hex codes or raw color strings to clean aesthetic color names
export const formatGarmentPrintDescription = (
  rawType: string,
  rawShape?: string,
  rawColor?: string,
  locations: string[] = [],
  isPrompt = false,
  customText?: string,
  emblemConfig?: EmblemBuilderConfig
): string => {
  const typeClean = cleanVal(rawType, isPrompt);
  if (!typeClean) return '';

  const cleanShape = cleanVal(rawShape, isPrompt);
  const cleanColor = cleanVal(rawColor, isPrompt);
  const locCount = locations.length;

  let prep = '';
  if (locCount === 1) {
    prep = isPrompt ? `en ${locations[0]}` : `ubicado en ${locations[0]}`;
  } else if (locCount > 1) {
    prep = isPrompt ? `en ${locations.join(' y ')}` : `ubicado en ${locations.join(' y ')}`;
  }

  const emblemDesc = emblemConfig ? formatEmblemBuilderDescription(emblemConfig, isPrompt) : '';

  if (isPrompt) {
    let desc = `estampado ${typeClean}`;
    if (cleanShape) desc += ` diseño ${cleanShape}`;
    if (customText) desc += ` con texto "${customText}"`;
    if (emblemDesc) desc += ` con ${emblemDesc}`;
    if (cleanColor) desc += ` color ${cleanColor}`;
    if (prep) desc += ` ${prep}`;
    return desc;
  } else {
    let desc = `${typeClean}`;
    const details: string[] = [];
    if (cleanShape) details.push(`Diseño: ${cleanShape}`);
    if (customText) details.push(`Texto/Caracteres: "${customText}"`);
    if (emblemDesc) details.push(`Composición: ${emblemDesc}`);
    if (cleanColor) details.push(`Color: ${cleanColor}`);
    if (prep) details.push(prep);
    if (details.length > 0) {
      desc += ` (${details.join(', ')})`;
    }
    return desc;
  }
};

export const resolveColorName = (colorStr: string | undefined | null): string => {
  if (!colorStr) return 'Negro';
  const trimmed = colorStr.trim();
  if (!trimmed) return 'Negro';

  // If it's a known hex code
  const hexMap: Record<string, string> = {
    '#1A1C22': 'Negro Azabache / Ébano',
    '#111317': 'Negro Azabache / Ébano',
    '#000000': 'Negro Carbón Absoluto',
    '#FFFFFF': 'Blanco',
    '#E2E8F0': 'Blanco Platino / Plata',
    '#1E3A8A': 'Azul Zafiro / Noche',
    '#3B82F6': 'Azul Cielo / Cobalto',
    '#06B6D4': 'Cian Hielo / Eléctrico',
    '#DC2626': 'Rojo Rubí / Carmesí',
    '#EF4444': 'Rojo Fuego / Escarlata',
    '#F59E0B': 'Dorado Solar / Ámbar',
    '#FBBF24': 'Amarillo Brillante',
    '#059669': 'Verde Esmeralda',
    '#10B981': 'Verde Menta / Jade',
    '#7C3AED': 'Púrpura / Amatista',
    '#8B5CF6': 'Violeta Neón / Índigo',
    '#EC4899': 'Rosa Fucsia / Neón',
    '#F472B6': 'Rosa Pastel / Sakura',
    '#451A03': 'Castaño Chocolate Oscuro',
    '#92400E': 'Castaño Caramelo',
    '#FDE047': 'Rubio Dorado',
    '#64748B': 'Gris Humo / Ceniza'
  };

  const upperHex = trimmed.toUpperCase();
  if (hexMap[upperHex]) return hexMap[upperHex];

  // If it's a raw hex code without direct match
  if (/^#[0-9A-F]{3,8}$/i.test(trimmed)) {
    return `Tono hexadecimal ${trimmed}`;
  }

  return cleanVal(trimmed, false);
};

// Formats detailed garment description for Technical Sheet and AI Prompt with context-aware typology
export const formatGarmentDescription = (g: GarmentConfig, isCompact = false): string => {
  const name = cleanVal(g.name, false);
  if (!name) return '';

  const nameLow = name.toLowerCase();
  const catId = g.categoryId || '';

  // Classify Garment Typology
  const isShoes = catId === 'B4' || nameLow.includes('bota') || nameLow.includes('botín') || nameLow.includes('zapato') || nameLow.includes('tacón') || nameLow.includes('sandalia') || nameLow.includes('zapatilla') || nameLow.includes('mocasín') || nameLow.includes('zueco') || nameLow.includes('descalzo') || nameLow.includes('sneaker');
  const isSocks = catId === 'B3-C' || (catId !== 'B3-D' && (nameLow.includes('media') || nameLow.includes('calcet') || nameLow.includes('pantimedia') || nameLow.includes('calza') || nameLow.includes('legging') || nameLow.includes('fishnet') || nameLow.includes('ligas') || nameLow.includes('vendaje')));
  const isBra = catId === 'B3-A' || nameLow.includes('bra') || nameLow.includes('sostén') || nameLow.includes('bralette') || nameLow.includes('balconette') || nameLow.includes('bandeau') || nameLow.includes('push-up');
  const isPanties = catId === 'B3-B' || nameLow.includes('panty') || nameLow.includes('panties') || nameLow.includes('tanga') || nameLow.includes('g-string') || nameLow.includes('brief') || nameLow.includes('bikini') || nameLow.includes('tap pants') || nameLow.includes('crotch');
  const isDress = catId === 'B0' || nameLow.includes('vestido') || nameLow.includes('jumpsuit') || nameLow.includes('bodycon') || nameLow.includes('monos') || nameLow.includes('leotardo') || nameLow.includes('unitardo');
  const isJacket = (catId === 'B12' || catId === 'B12-A') || nameLow.includes('chaqueta') || nameLow.includes('abrigo') || nameLow.includes('blazer') || nameLow.includes('cardigan') || nameLow.includes('gabardina') || nameLow.includes('parka') || nameLow.includes('topcoat') || nameLow.includes('tailcoat') || nameLow.includes('bolero') || nameLow.includes('bomber') || nameLow.includes('biker') || nameLow.includes('trench') || nameLow.includes('capa') || nameLow.includes('pelerina') || nameLow.includes('sobretodo') || nameLow.includes('capota') || nameLow.includes('túnica exterior') || nameLow.includes('chaleco') || nameLow.includes('waistcoat') || nameLow.includes('vest');
  const isBottom = (catId === 'B2') || nameLow.includes('pantalón') || nameLow.includes('jeans') || nameLow.includes('falda') || nameLow.includes('shorts') || nameLow.includes('bermuda') || nameLow.includes('hakama') || nameLow.includes('tutú') || nameLow.includes('kilt') || nameLow.includes('faldón');
  const isTop = (catId === 'B1' || catId === 'B3-D') || (!isDress && !isJacket && !isBottom && !isBra && !isPanties && !isSocks && !isShoes && catId !== 'B5');
  const isAcc = catId === 'B5';

  const isSkirt = nameLow.includes('falda') || nameLow.includes('kilt') || nameLow.includes('tutú');
  const isPants = nameLow.includes('pantalón') || nameLow.includes('jeans') || nameLow.includes('leggings') || nameLow.includes('sweatpants') || nameLow.includes('hakama');
  const isShorts = nameLow.includes('shorts') || nameLow.includes('bermuda') || nameLow.includes('hot pants');

  const mat = cleanVal(g.material, false);
  const colorResolved = resolveColorName(g.color);
  const finish = cleanVal(g.finish, false);
  const cut = cleanVal(g.cut, false);
  const length = cleanVal(g.length, false);
  const sleeve = cleanVal(g.sleeve, false);
  const neckline = cleanVal(g.neckline, false);
  const pattern = cleanVal(g.pattern, false);
  const patternDetail = cleanVal(g.patternDetail, false);
  const variation = cleanVal(g.variation, false);
  const layer = cleanVal(g.layer, false);
  const emblem = cleanVal(g.emblem, false);
  const vfx = cleanVal(g.vfx, false);
  const gemType = cleanVal(g.gemType, false);
  const gemColor = g.gemColor ? resolveColorName(g.gemColor) : '';
  const engraving = cleanVal(g.engraving, false);
  const sizeScale = cleanVal(g.sizeScale, false);
  const fitStyle = cleanVal(g.fitStyle, false);
  const subcategory = cleanVal(g.accessorySubcategory, false);

  // Formatting Length Contextually with Anatomical Precision
  let lengthDesc = '';
  if (length && !isAcc) {
    const lLower = length.toLowerCase();
    if (isShoes) {
      if (lLower.includes('bajo el tobillo') || lLower.includes('low-cut') || lLower.includes('suela plana')) lengthDesc = 'altura baja bajo el tobillo';
      else if (lLower.includes('tobillero') || lLower.includes('botín') || lLower.includes('al tobillo')) lengthDesc = 'altura al tobillo (botín)';
      else if (lLower.includes('media caña') || lLower.includes('pantorrilla') || lLower.includes('media pierna')) lengthDesc = 'altura de media caña a la pantorrilla';
      else if (lLower.includes('caña alta') || lLower.includes('bajo rodilla')) lengthDesc = 'caña alta bajo la rodilla';
      else if (lLower.includes('muslo') || lLower.includes('over-the-knee') || lLower.includes('over-knee')) lengthDesc = 'botas altas sobre el muslo (over-the-knee)';
      else if (lLower.includes('tacón alto') || lLower.includes('stiletto')) lengthDesc = 'calzado de tacón alto';
      else if (lLower.includes('tacón medio')) lengthDesc = 'calzado de tacón medio';
      else if (lLower.includes('plataforma')) lengthDesc = 'calzado con plataforma';
      else lengthDesc = `altura ${length.toLowerCase()}`;
    } else if (isSocks) {
      if (lLower.includes('tobillero') || lLower.includes('al tobillo')) lengthDesc = 'calcetín corto al tobillo';
      else if (lLower.includes('media pantorrilla') || lLower.includes('crew')) lengthDesc = 'altura de media pantorrilla';
      else if (lLower.includes('bajo la rodilla') || lLower.includes('knee-high')) lengthDesc = 'medias bajo la rodilla';
      else if (lLower.includes('sobre la rodilla') || lLower.includes('over-the-knee') || lLower.includes('over-knee')) lengthDesc = 'medias sobre la rodilla (over-the-knee)';
      else if (lLower.includes('muslo') || lLower.includes('thigh-high')) lengthDesc = 'medias de muslo alto (thigh-high)';
      else if (lLower.includes('panty entero') || lLower.includes('pantimedias')) lengthDesc = 'pantimedias completas hasta la cintura';
      else lengthDesc = `longitud ${length.toLowerCase()}`;
    } else if (isBra) {
      if (lLower.includes('cubre pezón') || lLower.includes('micro')) lengthDesc = 'cobertura micro cubre pezón';
      else if (lLower.includes('bajo busto') || lLower.includes('underbust')) lengthDesc = 'corte bajo el busto';
      else if (lLower.includes('costillas') || lLower.includes('longline')) lengthDesc = 'largo longline extendido hasta las costillas';
      else lengthDesc = 'cobertura estándar con copa';
    } else if (isPanties) {
      if (lLower.includes('inguinal') || lLower.includes('micro')) lengthDesc = 'corte micro tanga a la línea inguinal';
      else if (lLower.includes('caderas') || lLower.includes('tiro bajo')) lengthDesc = 'corte de tiro bajo a las caderas';
      else if (lLower.includes('cintura') || lLower.includes('tiro medio')) lengthDesc = 'corte de tiro medio a la cintura';
      else if (lLower.includes('ombligo') || lLower.includes('tiro alto')) lengthDesc = 'corte de tiro alto sobre el ombligo';
      else lengthDesc = `corte de tiro ${length.toLowerCase()}`;
    } else if (isJacket) {
      if (lLower.includes('pecho') || lLower.includes('bolero') || lLower.includes('torera')) lengthDesc = 'largo bolero bajo el pecho';
      else if (lLower.includes('cintura') || lLower.includes('crop')) lengthDesc = 'largo crop a la cintura';
      else if (lLower.includes('cadera') && !lLower.includes('bajo') && !lLower.includes('medio')) lengthDesc = 'largo estándar a la cadera';
      else if (lLower.includes('muslo') || lLower.includes('tres cuartos') || lLower.includes('parka')) lengthDesc = 'largo tres cuartos a medio muslo';
      else if (lLower.includes('rodilla') || lLower.includes('trench')) lengthDesc = 'largo abrigo hasta la rodilla';
      else if (lLower.includes('suelo') || lLower.includes('maxi') || lLower.includes('cola')) lengthDesc = 'largo maxi hasta el suelo';
      else lengthDesc = `largo ${length.toLowerCase()}`;
    } else if (isTop && !isDress) {
      if (lLower.includes('pecho') || lLower.includes('bajo busto') || lLower.includes('ultra crop') || lLower.includes('muy corto') || lLower.includes('cortísimo')) lengthDesc = 'largo ultra corto hasta el pecho / bajo el busto';
      else if (lLower.includes('ombligo') || lLower.includes('crop')) lengthDesc = 'largo crop sobre el ombligo';
      else if (lLower.includes('cintura')) lengthDesc = 'largo a la altura de la cintura';
      else if (lLower.includes('cadera') && !lLower.includes('bajo')) lengthDesc = 'largo estándar a la cadera';
      else if (lLower.includes('bajo la cadera') || lLower.includes('túnica')) lengthDesc = 'largo extendido bajo la cadera estilo túnica';
      else if (lLower.includes('asimétrico')) lengthDesc = 'largo asimétrico irregular';
      else lengthDesc = `largo ${length.toLowerCase()}`;
    } else if (isBottom) {
      if (lLower.includes('glúteos') || lLower.includes('glútea') || lLower.includes('micro') || lLower.includes('muy corto') || lLower.includes('cortísimo')) lengthDesc = 'largo micro justo bajo la línea glútea';
      else if (lLower.includes('muslo superior') || lLower.includes('alto muslo')) lengthDesc = 'largo corto al muslo superior';
      else if (lLower.includes('medio muslo') || lLower.includes('mini')) lengthDesc = 'largo mini a medio muslo';
      else if (lLower.includes('sobre la rodilla') || lLower.includes('ciclista')) lengthDesc = 'largo sobre la rodilla';
      else if (lLower.includes('hasta la rodilla') || lLower.includes('bermuda') || (lLower.includes('rodilla') && !lLower.includes('bajo') && !lLower.includes('sobre'))) lengthDesc = 'largo hasta la rodilla';
      else if (lLower.includes('bajo la rodilla') || lLower.includes('capri')) lengthDesc = 'largo capri bajo la rodilla';
      else if (lLower.includes('media pantorrilla') || lLower.includes('midi')) lengthDesc = 'largo midi a media pantorrilla';
      else if (lLower.includes('sobre el tobillo') || lLower.includes('tobillero')) lengthDesc = 'largo tobillero sobre el tobillo';
      else if (lLower.includes('a los tobillos') || lLower.includes('maxi') || (lLower.includes('tobillo') && !lLower.includes('sobre'))) lengthDesc = 'largo maxi a los tobillos';
      else if (lLower.includes('empeine') || lLower.includes('regular')) lengthDesc = 'largo regular descansando sobre el empeine';
      else if (lLower.includes('cubriendo el calzado') || lLower.includes('arrastre') || lLower.includes('suelo') || lLower.includes('cola')) lengthDesc = 'largo hasta el suelo cubriendo el calzado';
      else lengthDesc = `largo ${length.toLowerCase()}`;
    } else {
      // Dresses & General
      if (lLower.includes('glúteos') || lLower.includes('micro') || lLower.includes('muy corto') || lLower.includes('cortísimo')) lengthDesc = 'largo micro justo bajo los glúteos';
      else if (lLower.includes('medio muslo') || lLower.includes('mini')) lengthDesc = 'largo mini a medio muslo';
      else if (lLower.includes('sobre la rodilla')) lengthDesc = 'largo sobre la rodilla';
      else if (lLower.includes('hasta la rodilla') || (lLower.includes('rodilla') && !lLower.includes('sobre') && !lLower.includes('bajo'))) lengthDesc = 'largo hasta la rodilla';
      else if (lLower.includes('media pantorrilla') || lLower.includes('midi')) lengthDesc = 'largo midi a media pantorrilla';
      else if (lLower.includes('a los tobillos') || lLower.includes('maxi') || lLower.includes('tobillo')) lengthDesc = 'largo maxi hasta los tobillos';
      else if (lLower.includes('suelo') || lLower.includes('cola')) lengthDesc = 'largo hasta el suelo con cola';
      else lengthDesc = `largo ${length.toLowerCase()}`;
    }
  }

  // Formatting Sleeve Contextually (Only for Tops, Dresses, Jackets, Bras)
  let sleeveDesc = '';
  if (sleeve && (isTop || isDress || isJacket || isBra)) {
    const sLower = sleeve.toLowerCase();
    if (sLower.includes('sin manga')) sleeveDesc = 'sin mangas';
    else if (sLower.includes('tirantes finos')) sleeveDesc = 'tirantes finos';
    else if (sLower.includes('tirantes gruesos') || sLower.includes('tirantes anchos')) sleeveDesc = 'tirantes anchos';
    else if (sLower.includes('hombros descubiertos')) sleeveDesc = 'hombros descubiertos';
    else if (sLower.includes('corta')) sleeveDesc = 'mangas cortas';
    else if (sLower.includes('3/4')) sleeveDesc = 'mangas 3/4';
    else if (sLower.includes('larga')) sleeveDesc = 'mangas largas';
    else if (sLower.includes('abullonada')) sleeveDesc = 'mangas abullonadas';
    else if (sLower.includes('kimono')) sleeveDesc = 'mangas estilo kimono';
    else if (sLower.includes('campana') || sLower.includes('acampanada')) sleeveDesc = 'mangas acampanadas';
    else if (sLower.includes('remangada')) sleeveDesc = 'mangas largas remangadas';
    else if (sLower.startsWith('manga') || sLower.startsWith('mangas')) sleeveDesc = sLower;
    else sleeveDesc = `mangas ${sLower}`;
  }

  // Details with individual colors and anatomically specific locations
  const detailsList: string[] = [];
  if (g.details && g.details.length > 0 && !g.details.includes('Minimalista')) {
    g.details.forEach(det => {
      const dClean = cleanVal(det, false);
      if (!dClean) return;
      const dColorRaw = g.detailColors && g.detailColors[det];
      const dColor = dColorRaw ? resolveColorName(dColorRaw) : '';
      const dLocs = g.detailLocations && g.detailLocations[det] ? g.detailLocations[det].map(formatLocationSpan).filter(Boolean) : [];
      
      let dDesc = dClean;
      if (dColor) dDesc += ` color ${dColor}`;
      if (dLocs.length > 0) dDesc += ` en ${dLocs.join(' y ')}`;
      detailsList.push(dDesc);
    });
  }

  // Textile Prints & Graphic Designs (similar to A.2.4.5)
  const printsList: string[] = [];
  if (g.printTypes && g.printTypes.length > 0) {
    g.printTypes.forEach(pType => {
      const pShape = g.printShapes && g.printShapes[pType];
      const pColor = g.printColors && g.printColors[pType];
      const pLocs = g.printLocations && g.printLocations[pType] ? g.printLocations[pType].map(formatLocationSpan).filter(Boolean) : [];
      const pText = g.printTexts && g.printTexts[pType];
      const pEmblemConfig = g.printEmblemConfigs && g.printEmblemConfigs[pType];
      const pDesc = formatGarmentPrintDescription(pType, pShape, pColor, pLocs, isCompact, pText, pEmblemConfig);
      if (pDesc) printsList.push(pDesc);
    });
  }

  // Locations / Body Coverage & Anatomical Fit
  const rawLocs = (g.coverageZones && g.coverageZones.length > 0) ? g.coverageZones : (g.location || []);
  const locList = rawLocs.map(formatLocationSpan).filter(Boolean);
  const covStyle = cleanVal(g.coverageStyle, false);
  const covDetails = cleanVal(g.coverageDetails, false);

  const emblemDetailDesc = g.emblemConfig ? formatEmblemBuilderDescription(g.emblemConfig, isCompact) : '';

  if (isCompact) {
    // Compact AI Prompt Format
    const tokens: string[] = [];
    tokens.push(name.toLowerCase());
    if (colorResolved) tokens.push(`color ${colorResolved.toLowerCase()}`);
    if (mat) tokens.push(`de ${mat.toLowerCase()}`);
    if (finish && !/mate/i.test(finish)) tokens.push(`acabado ${finish.toLowerCase()}`);
    if (cut) tokens.push(isShoes ? `ajuste/forma ${cut.toLowerCase()}` : isAcc ? `estilo ${cut.toLowerCase()}` : `corte y ajuste ${cut.toLowerCase()}`);
    if (neckline && (isTop || isDress || isJacket || isBra)) {
      const nLow = neckline.toLowerCase();
      if (/^(cuello|escote|solapa|gorguera|capucha|hombros|abertura|espalda|tiras|sin\s)/i.test(nLow)) {
        tokens.push(nLow);
      } else {
        tokens.push(`escote ${nLow}`);
      }
    }
    if (lengthDesc) tokens.push(lengthDesc);
    if (sleeveDesc) tokens.push(sleeveDesc);
    if (isAcc && sizeScale && !/estándar/i.test(sizeScale)) tokens.push(`escala ${sizeScale.toLowerCase()}`);
    if (isAcc && fitStyle && !/estándar/i.test(fitStyle)) tokens.push(`ajuste ${fitStyle.toLowerCase()}`);
    if (isAcc && gemType && !/sin gema|ningun/i.test(gemType)) tokens.push(`con gema de ${gemType.toLowerCase()}${gemColor ? ` (${gemColor.toLowerCase()})` : ''}`);
    if (isAcc && engraving && !/sin grabado|ningun|liso/i.test(engraving)) {
      tokens.push(`grabado ${engraving.toLowerCase()}${g.engravingText ? ` con texto "${g.engravingText}"` : ''}`);
    }
    if (locList.length > 0) {
      const showCovStyle = covStyle && (!cut || (covStyle.toLowerCase().trim() !== cut.toLowerCase().trim() && !covStyle.toLowerCase().includes(cut.toLowerCase())));
      tokens.push(`cobertura en ${locList.join(', ')}${showCovStyle ? ` (ajuste ${covStyle.toLowerCase()})` : ''}`);
    } else if (covStyle && (!cut || covStyle.toLowerCase().trim() !== cut.toLowerCase().trim())) {
      tokens.push(`ajuste ${covStyle.toLowerCase()}`);
    }
    if (covDetails) tokens.push(`especificaciones: ${covDetails.toLowerCase()}`);
    if (pattern && !/liso/i.test(pattern)) tokens.push(`patrón ${pattern.toLowerCase()}${patternDetail ? ` (${patternDetail.toLowerCase()})` : ''}`);
    if (printsList.length > 0) tokens.push(printsList.join(', '));
    if (detailsList.length > 0) tokens.push(`detalles: ${detailsList.join(', ').toLowerCase()}`);
    if (variation && !/estándar|simétrica/i.test(variation)) tokens.push(`diseño ${variation.toLowerCase()}`);
    if (emblem && !/ningun/i.test(emblem)) {
      tokens.push(`emblema de ${emblem.toLowerCase()}${emblemDetailDesc ? ` (${emblemDetailDesc})` : ''}`);
    }
    if (g.culturalTradition && !/todas|ningun/i.test(g.culturalTradition)) {
      tokens.push(`tradición ${cleanVal(g.culturalTradition, true)}`);
    }
    if (g.wearCondition && !/impecable/i.test(g.wearCondition)) {
      tokens.push(`estado ${cleanVal(g.wearCondition, true)}`);
    }
    if (isShoes) {
      if (g.soleType && !/estándar|ningun/i.test(g.soleType)) {
        tokens.push(`suela ${cleanVal(g.soleType, true)}`);
      }
      if (g.heelType && !/estándar|ningun/i.test(g.heelType)) {
        tokens.push(`tacón ${cleanVal(g.heelType, true)}`);
      }
    } else {
      if (g.wearStyle && !/estándar/i.test(g.wearStyle)) {
        tokens.push(`porte ${cleanVal(g.wearStyle, true)}`);
      }
    }
    if (vfx && !/ningun/i.test(vfx)) tokens.push(`efecto ${vfx.toLowerCase()}`);
    return tokens.join(', ');
  } else {
    // Human-readable Character Sheet Format
    const lines: string[] = [`- ${name} (${layer || (isAcc ? 'Accesorio' : 'Prenda')}${subcategory ? ` • ${subcategory}` : ''}):`];
    const attrs: string[] = [];

    // 1. Material, Tono y Acabado
    if (colorResolved || mat || finish) {
      attrs.push(`  • ${isAcc ? 'Material, Metal y Color' : 'Textil y Color'}: ${colorResolved || 'Estándar'}${mat ? ` confeccionado en ${mat}` : ''}${finish ? ` (Acabado ${finish})` : ''}`);
    }

    // 1.1 Estado de Desgaste, Porte y Tradición Cultural / Suela y Tacón
    const wearParts: string[] = [];
    if (g.wearCondition && cleanVal(g.wearCondition, false)) wearParts.push(`Condición: ${g.wearCondition}`);
    if (isShoes) {
      if (g.soleType && cleanVal(g.soleType, false)) wearParts.push(`Suela: ${g.soleType}`);
      if (g.heelType && cleanVal(g.heelType, false)) wearParts.push(`Tacón: ${g.heelType}`);
    } else {
      if (g.wearStyle && cleanVal(g.wearStyle, false)) wearParts.push(`Porte: ${g.wearStyle}`);
    }
    if (g.culturalTradition && cleanVal(g.culturalTradition, false) && !/todas/i.test(g.culturalTradition)) wearParts.push(`Tradición: ${g.culturalTradition}`);
    if (wearParts.length > 0) {
      attrs.push(`  • ${isShoes ? 'Estado, Suela y Tacón' : 'Estado y Porte'}: ${wearParts.join('; ')}`);
    }

    // 2. Tipología, Corte y Escote
    const cutNecklineParts: string[] = [];
    if (cut) cutNecklineParts.push(isShoes ? `Ajuste/Forma: ${cut}` : isAcc ? `Estilo: ${cut}` : `Corte y Ajuste: ${cut}`);
    if (isAcc && sizeScale) cutNecklineParts.push(`Escala ${sizeScale}`);
    if (isAcc && fitStyle) cutNecklineParts.push(`Ajuste ${fitStyle}`);
    if (neckline && (isTop || isDress || isJacket || isBra)) cutNecklineParts.push(`Escote/Cuello ${neckline}`);
    if (cutNecklineParts.length > 0) {
      attrs.push(`  • ${isAcc ? 'Estilo, Escala y Ajuste' : 'Silueta y Escote'}: ${cutNecklineParts.join('; ')}`);
    }

    // 2.1 Gemas e Incrustaciones (Accesorios)
    if (isAcc && gemType && !/sin gema|ningun/i.test(gemType)) {
      attrs.push(`  • Gema / Incrustación: ${gemType}${gemColor ? ` (Tono: ${gemColor})` : ''}`);
    }

    // 2.2 Grabados y Filigrana (Accesorios)
    if (isAcc && engraving && !/sin grabado|ningun|liso/i.test(engraving)) {
      attrs.push(`  • Grabado / Motivo: ${engraving}${g.engravingText ? ` (Inscripción: "${g.engravingText}")` : ''}`);
    }

    // 3. Largo y Mangas
    const lengthSleeveParts: string[] = [];
    if (lengthDesc) lengthSleeveParts.push(lengthDesc.charAt(0).toUpperCase() + lengthDesc.slice(1));
    if (sleeveDesc) lengthSleeveParts.push(sleeveDesc.charAt(0).toUpperCase() + sleeveDesc.slice(1));
    if (lengthSleeveParts.length > 0) {
      attrs.push(`  • Proporción y Mangas: ${lengthSleeveParts.join('; ')}`);
    }

    // 4. Estampados, Bordados y Diseños Gráficos
    if (printsList.length > 0) {
      attrs.push(`  • Estampados y Diseños Gráficos: ${printsList.join('; ')}`);
    }

    // 5. Detalles, Aplicaciones y Posiciones
    if (detailsList.length > 0) {
      attrs.push(`  • Detalles y Aplicaciones: ${detailsList.join('; ')}`);
    } else if (g.details && g.details.includes('Minimalista')) {
      attrs.push(`  • Estilo de Acabado: Minimalista sin aplicaciones`);
    }

    // 6. Zona de Ajuste / Cobertura Corporal
    if (locList.length > 0 || covStyle || covDetails) {
      const covParts: string[] = [];
      if (locList.length > 0) covParts.push(locList.join(', '));
      if (covStyle && (!cut || covStyle.toLowerCase().trim() !== cut.toLowerCase().trim())) {
        covParts.push(`Ajuste/Estilo: ${covStyle}`);
      }
      if (covDetails) covParts.push(`Detalles: ${covDetails}`);
      attrs.push(`  • Zona de Ajuste/Cobertura: ${covParts.join(' | ')}`);
    }

    // 7. Patrón
    if (pattern && !/liso/i.test(pattern)) {
      attrs.push(`  • Estampado/Patrón: ${pattern}${patternDetail ? ` (${patternDetail})` : ''}`);
    }

    // 8. Variación de confección
    if (variation && !/estándar|simétrica/i.test(variation)) {
      attrs.push(`  • Variación de Confección: ${variation}`);
    }

    // 9. Emblema
    if (emblem && !/ningun/i.test(emblem)) {
      attrs.push(`  • Emblema / Blasón: ${emblem}${emblemDetailDesc ? ` (${emblemDetailDesc})` : ''}`);
    }

    // 10. VFX / Condición
    if (vfx && !/ningun/i.test(vfx)) {
      attrs.push(`  • Condición / Efecto Visual: ${vfx}`);
    }

    return lines.concat(attrs).join('\n');
  }
};

// Generates the comprehensive character sheet text (Technical Sheet)
export const generateCharacterSheetText = (state: CharacterState): string => {
  const isRoleCivil = isRoleNull(state.role);
  const isStyleGeneric = isStyleNull(state.styleVisual);

  const lowerBodyClean = cleanVal(state.anatomy?.lowerBodyStructure, false);
  const isBiped = !lowerBodyClean || /b[ií]pedo/i.test(lowerBodyClean);
  const chestCoreClean = cleanVal(state.anatomy?.chestCore, false);
  const isChestCoreNone = !chestCoreClean || /ningun/i.test(chestCoreClean);
  const neckFeatureClean = cleanVal(state.anatomy?.neckFeature, false);
  const isNeckFeatureNone = !neckFeatureClean || /ningun/i.test(neckFeatureClean);

  const scleraClean = cleanVal(state.facial?.scleraColor, false);
  const isScleraNone = !scleraClean || /^sin\s+ojos/i.test(scleraClean) || /^inexistente/i.test(scleraClean) || /^ningun/i.test(scleraClean);
  const facialMorphClean = cleanVal(state.facial?.facialMorphology, false);
  const isFacialMorphStandard = !facialMorphClean || /humanoide/i.test(facialMorphClean) || /ningun/i.test(facialMorphClean);
  const hairElementalClean = cleanVal(state.hair?.hairElemental, false);
  const isHairElementalStandard = !hairElementalClean || /org[aá]nico/i.test(hairElementalClean) || /ningun/i.test(hairElementalClean);

  const breastDevClean = cleanVal(state.anatomy?.breastDevelopment, false);
  const isBreastDevNone = !breastDevClean || /ningun|no aplica|plano/i.test(breastDevClean);

  const bodyParts = [
    buildPart('complexión', state.anatomy?.complexion, false),
    buildPart('altura', state.anatomy?.height, false),
    !isBreastDevNone ? buildPart('desarrollo mamario', breastDevClean, false) : '',
    buildPart('cintura', state.anatomy?.waist, false),
    buildPart('glúteos', state.anatomy?.glutes, false),
    buildPart('muslos', state.anatomy?.thighs, false),
    !isBiped ? `estructura inferior ${lowerBodyClean}` : '',
    !isChestCoreNone ? `núcleo vital ${chestCoreClean}` : '',
    !isNeckFeatureNone ? `rasgo de cuello ${neckFeatureClean}` : ''
  ].filter(Boolean);

  const headParts = [
    buildPart('forma', state.facial?.headShape, false),
    buildPart('anchura', state.facial?.headWidth, false),
    buildPart('estructura', state.facial?.boneStructure, false),
    !isFacialMorphStandard ? `morfología facial ${facialMorphClean}` : ''
  ].filter(Boolean);
  
  const eyeParts = [
    state.facial?.isHeterochromia
      ? `heterocromía (ojo izquierdo: ${cleanVal(state.facial?.eyeColor, false) || 'Estándar'}, ojo derecho: ${cleanVal(state.facial?.eyeColorRight, false) || cleanVal(state.facial?.eyeColor, false)})`
      : buildPart('color', state.facial?.eyeColor, false),
    state.facial?.pupilShape && !/redonda humana/i.test(state.facial.pupilShape) ? `pupilas ${state.facial.pupilShape}` : '',
    state.facial?.irisGlow ? 'iris bioluminiscente / resplandor arcano' : '',
    !isScleraNone ? `esclerótica ${scleraClean}` : '',
    buildPart('forma', state.facial?.eyesCategory, false),
    buildPart('tipo', state.facial?.eyesSubtype, false)
  ].filter(Boolean);
  
  const mouthParts = [
    buildPart('labios', state.facial?.lips, false),
    buildPart('expresión', state.facial?.mouthExp, false),
    buildPart('dientes', state.facial?.teeth, false),
    state.facial?.tongueType && !/humana estándar/i.test(state.facial.tongueType) ? `lengua ${state.facial.tongueType}` : ''
  ].filter(Boolean);
  
  const earsBaseClean = cleanVal(state.facial?.earsBase, false);
  const kemonoEarsClean = cleanVal(state.facial?.kemonoEars, false);
  const earParts = [
    earsBaseClean ? `tipo ${earsBaseClean}` : '',
    kemonoEarsClean ? `orejas especiales ${kemonoEarsClean}` : ''
  ].filter(Boolean);

  const hairLengthFormatted = formatHairLength(state.hair?.length);
  const hairCutClean = cleanVal(state.hair?.cut, false);
  const hairTextureClean = cleanVal(state.hair?.texture, false);
  const hairStyleClean = cleanVal(state.hair?.style, false);
  const hairBangsClean = cleanVal(state.hair?.bangs, false);
  const hairPartClean = cleanVal(state.hair?.part, false);

  const hairParts = [
    buildPart('color', state.hair?.hairColor, false),
    !isHairElementalStandard ? `naturaleza elemental ${hairElementalClean}` : '',
    hairTextureClean ? `textura ${hairTextureClean}` : '',
    hairCutClean ? `corte ${hairCutClean}` : '',
    hairLengthFormatted ? `largo ${hairLengthFormatted}` : '',
    hairBangsClean && !/sin flequillo/i.test(hairBangsClean) ? `flequillo ${hairBangsClean}` : '',
    hairPartClean && !/sin partido/i.test(hairPartClean) ? `partido ${hairPartClean}` : '',
    hairStyleClean && !/sin peinado|suelto/i.test(hairStyleClean) ? `peinado ${hairStyleClean}` : ''
  ].filter(Boolean);

  const skinColorClean = cleanVal(state.anatomy?.skinColor, false);
  const skinPatternClean = cleanVal(state.appendices?.skinAndMarks, false);
  const isSkinPatternStandard = !skinPatternClean || /piel lisa/i.test(skinPatternClean) || /est[aá]ndar/i.test(skinPatternClean);
  const scaleLocs = (state.appendices?.scaleLocations || []).map(formatLocationSpan).filter(Boolean);

  const skinTokens = [
    skinColorClean ? `tono ${skinColorClean}` : '',
    !isSkinPatternStandard ? `textura/patrón ${skinPatternClean}` : '',
    scaleLocs.length ? `(ubicación de escamas/placas: ${scaleLocs.join(', ')})` : ''
  ].filter(Boolean);

  const detailedMarks = (state.appendices?.markTypes || []).map(m => {
    const shape = (state.appendices?.markShapes || {})[m];
    const color = (state.appendices?.markColors || {})[m];
    const secondaryColor = (state.appendices?.markSecondaryColors || {})[m];
    const locs = ((state.appendices?.markLocations || {})[m] || []).map(formatLocationSpan).filter(Boolean);
    const text = state.appendices?.markTexts?.[m];
    const emblemConfig = state.appendices?.markEmblemConfigs?.[m];
    const finish = state.appendices?.markFinishes?.[m];
    return formatMarkDescription(m, shape, color, locs, false, text, emblemConfig, finish, secondaryColor);
  }).filter(Boolean);

  const horns = cleanVal(state.appendices?.hornsForm, false);
  const wings = cleanVal(state.appendices?.wingsType, false);
  const tail = cleanVal(state.appendices?.tailsType, false);
  const antennae = cleanVal(state.appendices?.antennaeType, false);
  const isAntennaeNone = !antennae || /^ninguna?$/i.test(antennae);
  const extraEyes = cleanVal(state.appendices?.extraEyes, false);
  const isExtraEyesNone = !extraEyes || /^ningun/i.test(extraEyes) || /2 ojos est/i.test(extraEyes);
  const extraArms = cleanVal(state.appendices?.extraArms, false);
  const isExtraArmsNone = !extraArms || /^ningun/i.test(extraArms) || /2 brazos est/i.test(extraArms);
  const specialLimbs = cleanVal(state.appendices?.specialLimbs, false);
  const isSpecialLimbsNone = !specialLimbs || /^ningun/i.test(specialLimbs) || /org[aá]nicas est/i.test(specialLimbs);
  const lowerBody = cleanVal(state.appendices?.lowerBodyStructure || state.anatomy?.lowerBodyStructure, false);
  const isLowerBodyStandard = !lowerBody || /b[ií]pedo humanoide est[aá]ndar/i.test(lowerBody);

  // Group garments by category or list all rich wardrobe items
  const wardrobeItems = (state.wardrobes || [])
    .filter(g => Boolean(cleanVal(g.name, false)))
    .map(g => formatGarmentDescription(g, false))
    .filter(Boolean);

  // Check armor and weapons
  const hasSpecialArmor = hasValidArmorProtection(state.armor?.specialType, state.role);
  const rawPieces = (state.armor?.pieces || [])
    .map(rawPiece => {
      const cleanName = cleanVal(rawPiece.replace(/^P\d+\.?\d*\s*/, '').replace(/^P-Custom:\s*/, ''), false);
      return cleanName ? rawPiece : '';
    })
    .filter(Boolean);

  const weapons = (state.equipment?.weapons || []).map(w => cleanVal(w, false)).filter(Boolean);
  const bags = (state.equipment?.bags || []).map(b => cleanVal(b, false)).filter(Boolean);
  const items = (state.equipment?.items || []).map(i => cleanVal(i, false)).filter(Boolean);

  const lines: string[] = [
    "# Ficha Técnica Canónica",
    "",
    "## Identidad y Perfil",
    `Nombre: ${state.name || 'Sin nombre asignado'}`
  ];

  const sexBaseVal = cleanVal(state.anatomy?.sexBase, false);
  if (sexBaseVal) {
    lines.push(`Sexo Base (A.2.1.1): ${sexBaseVal}`);
  }

  const race = cleanVal(state.raceName, false);
  const primarySub = state.subtypeName || state.subtype;
  const primarySubClean = primarySub ? cleanVal(primarySub, false) : '';
  if (race) {
    if (state.isHybrid && state.secondaryRaceName) {
      const secRaceClean = cleanVal(state.secondaryRaceName, false);
      const secSub = state.secondarySubtypeName || state.secondarySubtype;
      const secSubClean = secSub ? cleanVal(secSub, false) : '';
      const primaryDisplay = primarySubClean ? `${race} (${primarySubClean})` : race;
      const secondaryDisplay = secSubClean ? `${secRaceClean} (${secSubClean})` : secRaceClean;
      lines.push(`Raza: Híbrido ${primaryDisplay} × ${secondaryDisplay}${state.hybridDominance ? ` [${state.hybridDominance}]` : ''}`);
    } else {
      lines.push(`Raza: ${race}${primarySubClean ? ` (${primarySubClean})` : ''}`);
    }
  }
  const age = cleanVal(state.anatomy?.age, false);
  if (age) lines.push(`Edad aparente: ${age}`);
  const validTraits = (state.personalityTraits || []).map(t => cleanVal(t, false)).filter(Boolean);
  const basePers = cleanVal(state.personality, false);
  const combinedPersList: string[] = [];
  if (validTraits.length > 0) {
    if (basePers && !validTraits.some(t => t.toLowerCase() === basePers.toLowerCase())) {
      combinedPersList.push(basePers);
    }
    combinedPersList.push(...validTraits);
  } else if (basePers) {
    combinedPersList.push(basePers);
  }

  if (combinedPersList.length > 0) {
    lines.push(`Rasgos de Personalidad: ${combinedPersList.join(', ')}`);
  }
  if (state.background?.coreValues && cleanVal(state.background.coreValues, false)) {
    lines.push(`Valores Fundamentales: ${state.background.coreValues}`);
  }
  const role = cleanVal(state.role, false);
  const subRole = cleanVal(state.subRole, false);
  const hybridTitle = cleanVal(state.hybridRoleTitle, false);
  if (role && !isRoleCivil) {
    if (subRole && !isRoleNull(subRole) && subRole !== role) {
      lines.push(`Rol Canónico Principal: ${role}`);
      lines.push(`Sub-Rol / Modificador: ${subRole}`);
      if (hybridTitle && hybridTitle !== role) {
        lines.push(`Rol Compuesto Híbrido: ${hybridTitle}`);
      }
    } else {
      lines.push(`Rol Canónico: ${role}`);
    }
  } else {
    lines.push(`Rol Canónico: Civil / Cotidiano`);
  }
  if (state.nobleTitle && cleanVal(state.nobleTitle, false)) {
    const fullNobleTitle = state.nobleHouseOrDomain
      ? `${state.nobleTitle} ${state.nobleHouseOrDomain}`
      : state.nobleTitle;
    lines.push(`Título Nobiliario: ${fullNobleTitle}`);
  }
  if (state.archetype && state.archetype !== 'Genérico' && cleanVal(state.archetype, false)) {
    lines.push(`Arquetipo: ${state.archetype}`);
  }
  const style = cleanVal(state.styleVisual, false);
  const subStyle = cleanVal(state.subStyleVisual, false);
  const styleFusion = cleanVal(state.styleFusionTitle, false);
  if (style && !isStyleGeneric) {
    if (subStyle && !isStyleNull(subStyle) && subStyle !== style) {
      lines.push(`Estilo Estético Principal: ${style}`);
      lines.push(`Sub-Estilo Compatible: ${subStyle}`);
      if (styleFusion && styleFusion !== style) {
        lines.push(`Fusión Estética Visual: ${styleFusion}`);
      }
    } else {
      lines.push(`Estilo Estético: ${style}`);
    }
  }

  lines.push("", "## Anatomía y Rasgos Físicos");
  if (bodyParts.length) lines.push(`- Cuerpo: ${bodyParts.join(', ')}`);
  if (headParts.length) lines.push(`- Cabeza y Estructura: ${headParts.join(', ')}`);
  if (eyeParts.length) lines.push(`- Ojos: ${eyeParts.join(', ')}`);
  const iris = cleanVal(state.facial?.iris, false);
  if (iris && !/est[aá]ndar/i.test(iris)) lines.push(`- Iris: ${iris}`);
  const nose = cleanVal(state.facial?.nose, false);
  if (nose && !/est[aá]ndar/i.test(nose)) lines.push(`- Nariz: ${nose}`);
  if (mouthParts.length) lines.push(`- Boca: ${mouthParts.join(', ')}`);
  if (earParts.length) lines.push(`- Orejas: ${earParts.join(', ')}`);
  if (hairParts.length) lines.push(`- Cabello: ${hairParts.join(', ')}`);
  if (skinTokens.length) lines.push(`- Piel y Patrones (A.2.4.4): ${skinTokens.join(', ')}`);
  if (detailedMarks.length) {
    lines.push("- Marcas y Rasgos Singulares (A.2.4.5):");
    detailedMarks.forEach(m => lines.push(`  • ${m}`));
  }

  // Makeup & Aesthetics
  const makeupParts: string[] = [];
  if (state.makeup) {
    const lipStyle = cleanVal(state.makeup.lipstickStyle, false);
    const lipColor = cleanVal(state.makeup.lipstickColor, false);
    const lipFinish = cleanVal(state.makeup.lipstickFinish, false);
    if (lipStyle && !/labios naturales/i.test(lipStyle)) {
      makeupParts.push(`Labial: ${lipStyle}${lipColor ? ` color ${lipColor}` : ''}${lipFinish ? ` (${lipFinish})` : ''}`);
    }

    const blushStyle = cleanVal(state.makeup.blushStyle, false);
    const blushColor = cleanVal(state.makeup.blushColor, false);
    if (blushStyle && !/ningun/i.test(blushStyle)) {
      makeupParts.push(`Rubor: ${blushStyle}${blushColor ? ` tono ${blushColor}` : ''}`);
    }

    const nailStyle = cleanVal(state.makeup.nailStyle, false);
    const nailColor = cleanVal(state.makeup.nailColor, false);
    const nailFinish = cleanVal(state.makeup.nailFinish, false);
    if (nailStyle && !/u[ñn]as naturales/i.test(nailStyle)) {
      makeupParts.push(`Manicura: ${nailStyle}${nailColor ? ` esmalte ${nailColor}` : ''}${nailFinish ? ` (${nailFinish})` : ''}`);
    }

    const eyeShadow = cleanVal(state.makeup.eyeshadowStyle, false);
    const eyeShadowColor = cleanVal(state.makeup.eyeshadowColor, false);
    if (eyeShadow && !/natural/i.test(eyeShadow)) {
      makeupParts.push(`Sombras de Ojos: ${eyeShadow}${eyeShadowColor ? ` tono ${eyeShadowColor}` : ''}`);
    }

    const eyelinerM = cleanVal(state.makeup.eyelinerStyle, false);
    if (eyelinerM && !/ningun/i.test(eyelinerM)) {
      makeupParts.push(`Delineado cosmético: ${eyelinerM}`);
    }

    const faceAcc = cleanVal(state.makeup.faceAccent, false);
    if (faceAcc && !/ningun/i.test(faceAcc)) {
      makeupParts.push(`Acentos faciales: ${faceAcc}`);
    }
  }

  if (makeupParts.length > 0) {
    lines.push("", "## Maquillaje y Cosmética");
    makeupParts.forEach(mp => lines.push(`- ${mp}`));
  }

  if (horns || wings || tail || !isAntennaeNone || !isExtraEyesNone || !isExtraArmsNone || !isSpecialLimbsNone || !isLowerBodyStandard) {
    lines.push("", "## Apéndices Especiales y Sobrenaturales");
    if (horns) {
      const hL = cleanVal(state.appendices?.hornsLength, false);
      const hT = cleanVal(state.appendices?.hornsThickness, false);
      const hP = cleanVal(state.appendices?.hornsPosition, false);
      lines.push(`- Cuernos: forma ${horns}${hL ? `, longitud ${hL}` : ''}${hT ? `, grosor ${hT}` : ''}${hP ? `, posición ${hP}` : ''}`);
    }
    if (wings) {
       const wS = cleanVal(state.appendices?.wingsSize, false);
       const wP = cleanVal(state.appendices?.wingsPosition, false);
       lines.push(`- Alas: tipo ${wings}${wS ? `, tamaño ${wS}` : ''}${wP ? `, ubicadas en ${wP}` : ''}`);
    }
    if (tail) {
       const tL = cleanVal(state.appendices?.tailsLength, false);
       const tCP = cleanVal(state.appendices?.tailsColorPrimary, false);
       const tCS = cleanVal(state.appendices?.tailsColorSecondary, false);
       const tF = cleanVal(state.appendices?.tailsFinish, false);
       const tailDetails = [
         tL ? `longitud ${tL}` : '',
         tCP ? `color principal ${tCP}` : '',
         tCS && !/ningun/i.test(tCS) ? `puntas/degradado ${tCS}` : '',
         tF ? `acabado ${tF}` : ''
       ].filter(Boolean);
       lines.push(`- Cola: tipo ${tail}${tailDetails.length ? ` (${tailDetails.join(', ')})` : ''}`);
    }
    if (!isAntennaeNone) {
      const aL = cleanVal(state.appendices?.antennaeLength, false);
      const aP = cleanVal(state.appendices?.antennaePosition, false);
      lines.push(`- Antenas / Palpos: ${antennae}${aL ? `, longitud ${aL}` : ''}${aP ? `, posición ${aP}` : ''}`);
    }
    if (!isExtraEyesNone) {
      lines.push(`- Ojos Adicionales: ${extraEyes}`);
    }
    if (!isExtraArmsNone) {
      lines.push(`- Brazos Adicionales: ${extraArms}`);
    }
    if (!isSpecialLimbsNone) {
      lines.push(`- Extremidades Especiales (Brazos / Piernas): ${specialLimbs}`);
    }
    if (!isLowerBodyStandard) {
      lines.push(`- Estructura y Parte Inferior del Cuerpo: ${lowerBody}`);
    }
    const claws = cleanVal(state.appendices?.clawsType, false);
    if (claws && !/uñas naturales/i.test(claws)) {
      lines.push(`- Uñas / Garras: ${claws}`);
    }
  }

  // 2.6 Anatomía Íntima & Parámetros Explícitos (R+18)
  const nsfw = state.nsfw;
  const hasIntimateAnatomy = Boolean(
    nsfw?.isNsfwEnabled ||
    nsfw?.areolaColor ||
    nsfw?.areolaSize ||
    nsfw?.nippleType ||
    nsfw?.pubicHairStyle ||
    nsfw?.genitalType ||
    nsfw?.genitalSize ||
    (Array.isArray(nsfw?.genitalDetails) ? nsfw.genitalDetails.length > 0 : Boolean(nsfw?.genitalDetails)) ||
    (nsfw?.bodySensitivities && nsfw.bodySensitivities.length > 0) ||
    nsfw?.intimatePersonality
  );

  if (hasIntimateAnatomy && nsfw) {
    lines.push("", "## 2.6 Anatomía Íntima & Parámetros Explícitos (R+18)");

    // Grupo 1: Pezones
    const aColor = cleanVal(nsfw.areolaColor, false);
    const aSize = cleanVal(nsfw.areolaSize, false);
    const nType = cleanVal(nsfw.nippleType, false);
    const hasPezones = Boolean(aColor || aSize || nType);

    if (hasPezones) {
      lines.push("- Pezones");
      if (aColor) lines.push(`  • Color y Pigmentación de Areola: ${aColor}`);
      if (aSize) lines.push(`  • Tamaño y Proporción de Areola: ${aSize}`);
      if (nType) lines.push(`  • Morfología y Firmeza de Pezón: ${nType}`);
    }

    // Grupo 2: Genitales Masculinos / Femeninos / Mixtos
    const gType = cleanVal(nsfw.genitalType, false);
    const gSize = cleanVal(nsfw.genitalSize, false);
    const rawGDetails = nsfw.genitalDetails;
    const gDetailsList: string[] = Array.isArray(rawGDetails)
      ? rawGDetails.map(d => cleanVal(d, false)).filter(Boolean)
      : (typeof rawGDetails === 'string' && cleanVal(rawGDetails, false) ? [cleanVal(rawGDetails, false)] : []);
    const hasGenitales = Boolean(gType || gSize || gDetailsList.length > 0);

    if (hasGenitales) {
      if (hasPezones) lines.push("");
      const genitalHeader = resolveGenitalHeader(nsfw.genitalType, state.anatomy?.sexBase);
      lines.push(genitalHeader);
      if (gType) lines.push(`  • Morfología y Tipo de Genitales (2.6.5): ${gType}`);
      if (gSize) lines.push(`  • Proporción / Tamaño Genital: ${gSize}`);
      if (gDetailsList.length > 0) {
        lines.push(`  • Rasgos & Acabados Íntimos: ${gDetailsList.join(' | ')}`);
      }
    }

    // Grupo 3: Otros Parámetros Explícitos
    const pStyle = cleanVal(nsfw.pubicHairStyle, false);
    const rawSens = nsfw.bodySensitivities || [];
    const resolvedSens = rawSens.map(idOrName => {
      const found = BODY_SENSITIVITIES.find(b => b.id === idOrName || b.name === idOrName);
      return found ? found.name : cleanVal(idOrName, false);
    }).filter(Boolean);
    const intPers = cleanVal(nsfw.intimatePersonality, false);
    const hasOtros = Boolean(pStyle || resolvedSens.length > 0 || intPers);

    if (hasOtros) {
      if (hasPezones || hasGenitales) lines.push("");
      lines.push("- Otros Parámetros Explícitos");
      if (pStyle) lines.push(`  • Estilo y Corte de Vello Púbico: ${pStyle}`);
      if (resolvedSens.length > 0) {
        lines.push(`  • Zonas Corporales Hipersensibles (2.6.6): ${resolvedSens.join(', ')}`);
      }
      if (intPers) lines.push(`  • Dinámica / Personalidad Íntima: ${intPers}`);
    }
  }

  if (wardrobeItems.length > 0) {
    lines.push("", "## Vestuario y Atuendo");
    wardrobeItems.forEach(w => lines.push(w));
  }

  // Atuendo de Rol / Armaduras / Equipamiento (Estado 4)
  const roleOutfitType = cleanVal(state.armor?.type, false);
  const isNoneOutfit = !roleOutfitType || /^ninguna?$/i.test(roleOutfitType) || isRoleCivil;
  const hasRoleOutfit = Boolean(roleOutfitType && !isNoneOutfit);
  const armorMat = !isNoneOutfit ? cleanVal(state.armor?.material, false) : '';
  const armorFin = !isNoneOutfit ? cleanVal(state.armor?.finish, false) : '';
  const validRolePieces = isRoleCivil ? [] : rawPieces;
  const hasRolePieces = validRolePieces.length > 0;
  const eqDetails = state.equipment?.equipmentDetails || {};

  if (hasRolePieces || hasSpecialArmor || hasRoleOutfit || weapons.length || bags.length || items.length) {
    lines.push("", "## Especialización, Equipamiento y Vestimenta de Rol (Estado 4)");
    
    // 1. Estructura e indumentaria base del rol (sólo si no es 'Ninguna' y no es civil)
    if (!isNoneOutfit && (hasRoleOutfit || armorMat || armorFin)) {
      const outfitParts: string[] = [];
      if (hasRoleOutfit) outfitParts.push(`Corte/Tipología: ${roleOutfitType}`);
      if (armorMat) outfitParts.push(`Material Base: ${armorMat}`);
      if (armorFin) outfitParts.push(`Acabado Base: ${armorFin}`);
      lines.push(`- Indumentaria Base de ${state.role || 'Rol'}: ${outfitParts.join('; ')}`);
    }

    // 2. Piezas individuales de rol y estilo con modificadores físicos completos
    if (hasRolePieces) {
      lines.push(`- Piezas Específicas de Indumentaria y Armadura (${validRolePieces.length}):`);
      validRolePieces.forEach(rawPiece => {
        const cleanName = cleanVal(rawPiece.replace(/^P\d+\.?\d*\s*/, '').replace(/^P-Custom:\s*/, ''), false);
        if (!cleanName) return;
        const detail = state.armor?.pieceDetails?.[rawPiece];
        
        if (!detail) {
          lines.push(`  • ${cleanName}`);
          return;
        }

        const pieceAttributes: string[] = [];
        if (detail.color && cleanVal(detail.color, false)) pieceAttributes.push(`Color: ${resolveColorName(detail.color)}`);
        if (detail.length && cleanVal(detail.length, false)) pieceAttributes.push(`Largo/Caída: ${detail.length}`);
        if (detail.material && cleanVal(detail.material, false)) pieceAttributes.push(`Material: ${detail.material}`);
        if (detail.finish && cleanVal(detail.finish, false)) pieceAttributes.push(`Acabado: ${detail.finish}`);
        if (detail.detail && cleanVal(detail.detail, false)) {
          if (detail.detailLocation && detail.detailLocation !== 'Patrón integral / Toda la superficie' && cleanVal(detail.detailLocation, false)) {
            pieceAttributes.push(`Adornos: ${detail.detail} en ${detail.detailLocation.toLowerCase()}`);
          } else {
            pieceAttributes.push(`Adornos: ${detail.detail}`);
          }
        } else if (detail.detailLocation && detail.detailLocation !== 'Patrón integral / Toda la superficie' && cleanVal(detail.detailLocation, false)) {
          pieceAttributes.push(`Ubicación: ${detail.detailLocation}`);
        }
        if (detail.description && cleanVal(detail.description, false)) {
          pieceAttributes.push(`Silueta/Aspecto: ${detail.description}`);
        }

        if (pieceAttributes.length > 0) {
          lines.push(`  • ${cleanName}: ${pieceAttributes.join(' | ')}`);
        } else {
          lines.push(`  • ${cleanName}`);
        }
      });
    }

    // 3. Protección de rol (sólo si válida y no civil/ninguna)
    if (hasSpecialArmor) {
      lines.push(`- Protección y Blindaje de Rol: ${cleanVal(state.armor?.specialType, false)}`);
    }

    // 4. Armamento e Instrumentos
    if (weapons.length) {
      lines.push(`- Armamento e Instrumentos (${weapons.length}):`);
      weapons.forEach(w => {
        const det = eqDetails[w];
        if (!det) {
          lines.push(`  • ${w}`);
          return;
        }
        const wAttrs: string[] = [];
        if (det.color && cleanVal(det.color, false)) wAttrs.push(`Color: ${resolveColorName(det.color)}`);
        if (det.material && cleanVal(det.material, false)) wAttrs.push(`Material: ${det.material}`);
        if (det.finish && cleanVal(det.finish, false)) wAttrs.push(`Acabado: ${det.finish}`);
        if (det.sizeOrLength && cleanVal(det.sizeOrLength, false)) wAttrs.push(`Dimensiones: ${det.sizeOrLength}`);
        if (det.detail && cleanVal(det.detail, false)) wAttrs.push(`Detalles: ${det.detail}`);
        if (wAttrs.length > 0) {
          lines.push(`  • ${w}: ${wAttrs.join(' | ')}`);
        } else {
          lines.push(`  • ${w}`);
        }
      });
    }

    if (state.equipment?.weaponGrips && state.equipment.weaponGrips.length > 0) {
      const validGrips = state.equipment.weaponGrips.map(g => cleanVal(g, false)).filter(Boolean);
      if (validGrips.length > 0) {
        lines.push(`- Empuñaduras / Agarre de Armamento: ${validGrips.join(', ')}`);
      }
    }

    // 5. Bolsas y Contenedores
    if (bags.length) {
      lines.push(`- Bolsas y Contenedores (${bags.length}):`);
      bags.forEach(b => {
        const det = eqDetails[b];
        if (!det) {
          lines.push(`  • ${b}`);
          return;
        }
        const bAttrs: string[] = [];
        if (det.color && cleanVal(det.color, false)) bAttrs.push(`Color: ${resolveColorName(det.color)}`);
        if (det.material && cleanVal(det.material, false)) bAttrs.push(`Material: ${det.material}`);
        if (det.finish && cleanVal(det.finish, false)) bAttrs.push(`Acabado: ${det.finish}`);
        if (det.sizeOrLength && cleanVal(det.sizeOrLength, false)) bAttrs.push(`Capacidad/Tamaño: ${det.sizeOrLength}`);
        if (det.detail && cleanVal(det.detail, false)) bAttrs.push(`Detalles: ${det.detail}`);
        if (bAttrs.length > 0) {
          lines.push(`  • ${b}: ${bAttrs.join(' | ')}`);
        } else {
          lines.push(`  • ${b}`);
        }
      });
    }

    // 6. Reliquias y Objetos Personales
    if (items.length) {
      lines.push(`- Reliquias y Objetos Personales (${items.length}):`);
      items.forEach(it => {
        const det = eqDetails[it];
        if (!det) {
          lines.push(`  • ${it}`);
          return;
        }
        const itAttrs: string[] = [];
        if (det.color && cleanVal(det.color, false)) itAttrs.push(`Color: ${resolveColorName(det.color)}`);
        if (det.material && cleanVal(det.material, false)) itAttrs.push(`Material: ${det.material}`);
        if (det.finish && cleanVal(det.finish, false)) itAttrs.push(`Acabado: ${det.finish}`);
        if (det.detail && cleanVal(det.detail, false)) itAttrs.push(`Detalles: ${det.detail}`);
        if (itAttrs.length > 0) {
          lines.push(`  • ${it}: ${itAttrs.join(' | ')}`);
        } else {
          lines.push(`  • ${it}`);
        }
      });
    }
  }

  // Influencia de Estilo & Acentos Temáticos (Estado 4)
  const of = state.orientalFantasy;
  const currentStyle = state.styleVisual || 'Temático';
  const hasGlobalThematicFinishes = !isNoneOutfit && Boolean(
    (of?.spiritualMotif && cleanVal(of.spiritualMotif, false)) ||
    (of?.silkPattern && cleanVal(of.silkPattern, false)) ||
    (of?.jadeAccentColor && cleanVal(of.jadeAccentColor, false)) ||
    (of?.energyAura && cleanVal(of.energyAura, false) && of.energyAura !== 'Sin Aura (Aspecto Natural Puramente Físico)' && !/sin aura/i.test(of.energyAura))
  );
  const styleArmorPieces = !isRoleCivil ? (of?.armorPieces || []).map(p => cleanVal(p, false)).filter(Boolean) : [];
  const styleCulturalAccs = (of?.culturalAccessories || []).map(a => cleanVal(a, false)).filter(Boolean);
  const hasThematicGear = of && (
    (of.tradition && cleanVal(of.tradition, false)) ||
    styleArmorPieces.length > 0 ||
    styleCulturalAccs.length > 0 ||
    hasGlobalThematicFinishes ||
    (of.weaponStyle && cleanVal(of.weaponStyle, false))
  );

  if (hasThematicGear) {
    lines.push("", `## Influencia de Estilo & Acentos de Identidad (${currentStyle})`);
    if (of?.tradition && cleanVal(of.tradition, false)) lines.push(`- Tradición / Arquetipo Aplicado: ${cleanVal(of.tradition, false)}`);
    if (styleArmorPieces.length > 0) {
      lines.push(`- Piezas de Armadura del Estilo: ${styleArmorPieces.join('; ')}`);
    }
    if (styleCulturalAccs.length > 0) {
      lines.push(`- Accesorios y Joyería del Estilo: ${styleCulturalAccs.join('; ')}`);
    }
    if (!isNoneOutfit) {
      if (of?.silkPattern && cleanVal(of.silkPattern, false)) lines.push(`- Patrón Textil / Damascado: ${cleanVal(of.silkPattern, false)}`);
      if (of?.jadeAccentColor && cleanVal(of.jadeAccentColor, false)) lines.push(`- Gema / Mineral de Acento: ${cleanVal(of.jadeAccentColor, false)}`);
      if (of?.spiritualMotif && cleanVal(of.spiritualMotif, false)) lines.push(`- Motivo / Sello Temático: ${cleanVal(of.spiritualMotif, false)}`);
      if (of?.energyAura && cleanVal(of.energyAura, false) && of.energyAura !== 'Sin Aura (Aspecto Natural Puramente Físico)' && !/sin aura/i.test(of.energyAura)) {
        lines.push(`- Aura / Resplandor Visual Ambiental: ${cleanVal(of.energyAura, false)}`);
      }
    }
    if (of?.weaponStyle && cleanVal(of.weaponStyle, false)) lines.push(`- Estilo de Armamento / Herramienta: ${cleanVal(of.weaponStyle, false)}`);
  }

  // Estado 5: Trasfondo, Relaciones y Personalización Avanzada
  const rels = (state.background?.relationships || []).filter(r => Boolean(cleanVal(r.targetCharacterName, false)));
  const bg = state.background?.backstory?.trim();
  const mot = state.background?.motivation?.trim();
  const adv = state.background?.advancedCustomization;
  const cleanBg = cleanVal(bg, false);
  const cleanMot = cleanVal(mot, false);
  const coreVals = cleanVal(state.background?.coreValues, false);
  const homeland = cleanVal(state.background?.homelandOrDomain, false);
  const faction = cleanVal(state.background?.factionOrFaith, false);
  const rawFatalFlaws = (Array.isArray(state.background?.fatalFlaws) && state.background.fatalFlaws.length > 0)
    ? state.background.fatalFlaws
    : (state.background?.fatalFlawOrVulnerability ? state.background.fatalFlawOrVulnerability.split(/\s*\|\s*|\s*;\s*/).map(s => s.trim()).filter(Boolean) : []);
  const fatalFlaws = rawFatalFlaws.map(f => cleanVal(f, false)).filter(Boolean);
  const langs = (state.background?.languages || []).filter(Boolean);

  if (rels.length || cleanBg || cleanMot || coreVals || adv || homeland || faction || fatalFlaws.length > 0 || langs.length) {
    lines.push("", "## Antecedentes, Relaciones y Personalización Avanzada (Estado 5)");
    
    if (homeland) {
      lines.push(`- Origen Territorial / Dominio: ${homeland}`);
    }
    if (faction) {
      lines.push(`- Facción / Fe / Filosofía: ${faction}`);
    }
    if (coreVals) {
      lines.push(`- Core de Valores: ${coreVals}`);
    }
    if (fatalFlaws.length > 0) {
      if (fatalFlaws.length === 1) {
        lines.push(`- Talón de Aquiles / Defecto Fatal: ${fatalFlaws[0]}`);
      } else {
        lines.push(`- Talón de Aquiles / Defectos Fatales (${fatalFlaws.length}): ${fatalFlaws.join(' | ')}`);
      }
    }

    if (rels.length > 0) {
      lines.push("", "### 5.1 Relaciones & Dinámica de Interacción:");
      rels.forEach(r => {
        const charName = cleanVal(r.targetCharacterName, false);
        const relType = cleanVal(r.relationshipType, false) || 'Vínculo';
        const dynamic = cleanVal(r.interactionDynamic, false);
        const feelings = cleanVal(r.feelingsTowards, false);
        const opinion = cleanVal(r.opinionOn, false);

        let relLine = `- ${charName} [${relType}]: ${dynamic || 'Trato estándar recíproco.'}`;
        if (feelings) {
          relLine += ` | Sentimientos: ${feelings}`;
        }
        if (opinion) {
          relLine += ` | Opinión: ${opinion}`;
        }
        lines.push(relLine);
      });
    }

    if (state.background?.narrativeTimeline) {
      const tl = state.background.narrativeTimeline;
      lines.push("", "### 5.2 Línea Temporal Narrativa & Historial Multiversal:");
      if (tl.thematicArc) {
        lines.push(`- Arco Temático: ${tl.thematicArc}`);
      }
      if (tl.overview) {
        lines.push(`- Visión Panorámica: ${tl.overview}`);
      }
      if (tl.pivotalTurningPoints && tl.pivotalTurningPoints.length > 0) {
        lines.push("- Puntos de Inflexión del Destino:");
        tl.pivotalTurningPoints.forEach(tp => lines.push(`  • ${tp}`));
      }
      if (tl.milestones && tl.milestones.length > 0) {
        lines.push("- Hitos Cronológicos & Multiversales:");
        tl.milestones.forEach(m => {
          const varTag = m.linkedVariantName ? ` [${m.linkedVariantName}]` : '';
          lines.push(`  • [${m.era}] ${m.title} (${m.periodOrAge})${varTag}: ${m.summary}`);
          if (m.keyEvents && m.keyEvents.length > 0) {
            lines.push(`    - Eventos clave: ${m.keyEvents.join('; ')}`);
          }
          if (m.psychologicalEvolution) {
            lines.push(`    - Evolución psicológica: ${m.psychologicalEvolution}`);
          }
          if (m.roleAndAppearanceNote) {
            lines.push(`    - Rol y apariencia: ${m.roleAndAppearanceNote}`);
          }
        });
      }
    }

    if (cleanBg) {
      lines.push("", "### 5.3 Historia de Origen:");
      lines.push(cleanBg);
    }

    if (cleanMot) {
      lines.push("", "### 5.4 Motivación Principal:");
      lines.push(cleanMot);
    }

    if (adv) {
      lines.push("", "### 5.5 Personalización Avanzada:");
      if (adv.voiceTone) lines.push(`- Voz (Tono & Timbre): ${adv.voiceTone}`);
      if (adv.speechStyle) lines.push(`- Forma de Hablar & Registro: ${adv.speechStyle}`);
      if (adv.catchphrasesOrIdioms) lines.push(`- Muletilla / Expresión Recurrente: ${adv.catchphrasesOrIdioms}`);
      if (adv.skills && adv.skills.length > 0) {
        lines.push(`- Habilidades & Talentos: ${adv.skills.join(', ')}`);
      }
      if (adv.habitsAndMannerisms && adv.habitsAndMannerisms.length > 0) {
        lines.push(`- Hábitos & Manías: ${adv.habitsAndMannerisms.join('; ')}`);
      }
      if (adv.specificInteractions) {
        lines.push("- Comportamiento y Trato por Rangos / Tipos de Personaje:");
        if (adv.specificInteractions.withAuthority) lines.push(`  • Con Superiores / Autoridades: ${adv.specificInteractions.withAuthority}`);
        if (adv.specificInteractions.withPeers) lines.push(`  • Con Compañeros / Igual Rango: ${adv.specificInteractions.withPeers}`);
        if (adv.specificInteractions.withFriends) lines.push(`  • Con Amigos / Aliados: ${adv.specificInteractions.withFriends}`);
        if (adv.specificInteractions.withSubordinates) lines.push(`  • Con Aprendices / Subordinados: ${adv.specificInteractions.withSubordinates}`);
        if (adv.specificInteractions.withStrangers) lines.push(`  • Con Desconocidos / Sospechosos: ${adv.specificInteractions.withStrangers}`);
        if (adv.specificInteractions.withEnemies) lines.push(`  • Con Rivales / Enemigos: ${adv.specificInteractions.withEnemies}`);
      }
    }
  }

  // AI Prompt formatting
  const compactData = getCompiledPromptString(state);
  lines.push(
    "",
    "## Prompt Canónico para Generación IA",
    `[${compactData}]`,
    "",
    `<!-- CANONICAL_CHARACTER_SHEET_DATA: ${JSON.stringify(state)} -->`
  );

  return lines.join('\n');
};

// Generates the pure compact prompt for Gemini / Imagen (Coherent & Contextual)
export const getCompiledPromptString = (state: CharacterState): string => {
  const parts: string[] = [];
  const add = (str: string) => { if (str) parts.push(str.toLowerCase()); };
  
  // 1. Race, identity & style
  const raceNameClean = cleanVal(state.raceName, true);
  const subtypeClean = cleanVal(state.subtypeName || state.subtype, true);
  const sexBaseClean = cleanVal(state.anatomy?.sexBase, true);
  if (sexBaseClean) {
    add(`sexo base ${sexBaseClean}`);
  }
  if (state.isHybrid && state.secondaryRaceName) {
    const secRaceClean = cleanVal(state.secondaryRaceName, true);
    const secSubClean = cleanVal(state.secondarySubtypeName || state.secondarySubtype, true);
    const primaryPart = subtypeClean ? `${raceNameClean} (${subtypeClean})` : raceNameClean;
    const secondaryPart = secSubClean ? `${secRaceClean} (${secSubClean})` : secRaceClean;
    add(`híbrido racial ${primaryPart} con ${secondaryPart}${state.hybridDominance ? ` (${cleanVal(state.hybridDominance, true)})` : ''}`);
  } else if (raceNameClean) {
    add(`raza ${raceNameClean}${subtypeClean ? ` subtipo ${subtypeClean}` : ''}`);
  }
  const validTraits = (state.personalityTraits || []).map(t => cleanVal(t, true)).filter(Boolean);
  const persClean = cleanVal(state.personality, true);
  const combinedPersList: string[] = [];
  if (validTraits.length > 0) {
    if (persClean && !validTraits.some(t => t.toLowerCase() === persClean.toLowerCase())) {
      combinedPersList.push(persClean);
    }
    combinedPersList.push(...validTraits);
  } else if (persClean) {
    combinedPersList.push(persClean);
  }
  if (combinedPersList.length > 0) {
    add(`personalidad ${combinedPersList.join(', ')}`);
  }
  if (!isRoleNull(state.role)) {
    const roleClean = cleanVal(state.role, true);
    const subRoleClean = cleanVal(state.subRole, true);
    const hybridTitleClean = cleanVal(state.hybridRoleTitle, true);
    if (subRoleClean && !isRoleNull(subRoleClean) && subRoleClean !== roleClean) {
      if (hybridTitleClean && hybridTitleClean !== roleClean) {
        add(`rol híbrido ${hybridTitleClean} (${roleClean} con ${subRoleClean})`);
      } else {
        add(`rol ${roleClean} con sub-rol ${subRoleClean}`);
      }
    } else if (roleClean) {
      add(`rol ${roleClean}`);
    }
    if (state.nobleTitle && cleanVal(state.nobleTitle, true)) {
      const fullNobleTitle = state.nobleHouseOrDomain
        ? `${state.nobleTitle} ${state.nobleHouseOrDomain}`
        : state.nobleTitle;
      add(`título nobiliario de ${fullNobleTitle}`);
    }
  }
  if (!isStyleNull(state.styleVisual)) {
    const styleClean = cleanVal(state.styleVisual, true);
    const subStyleClean = cleanVal(state.subStyleVisual, true);
    const styleFusionClean = cleanVal(state.styleFusionTitle, true);
    if (subStyleClean && !isStyleNull(subStyleClean) && subStyleClean !== styleClean) {
      if (styleFusionClean && styleFusionClean !== styleClean) {
        add(`estilo estético fusionado ${styleFusionClean} (${styleClean} + ${subStyleClean})`);
      } else {
        add(`estilo estético ${styleClean} con ${subStyleClean}`);
      }
    } else if (styleClean) {
      add(`estilo estético ${styleClean}`);
    }
  }
  if (state.archetype && state.archetype !== 'Genérico') {
    const archClean = cleanVal(state.archetype, true);
    if (archClean) add(`arquetipo ${archClean}`);
  }

  // 2. Body anatomy
  const lowerBodyClean = cleanVal(state.anatomy?.lowerBodyStructure, true);
  const isBiped = !lowerBodyClean || /b[ií]pedo/i.test(lowerBodyClean);
  const chestCoreClean = cleanVal(state.anatomy?.chestCore, true);
  const isChestCoreNone = !chestCoreClean || /ningun/i.test(chestCoreClean);
  const neckFeatureClean = cleanVal(state.anatomy?.neckFeature, true);
  const isNeckFeatureNone = !neckFeatureClean || /ningun/i.test(neckFeatureClean);

  const scleraClean = cleanVal(state.facial?.scleraColor, true);
  const isScleraNone = !scleraClean || /^sin\s+ojos/i.test(scleraClean) || /^inexistente/i.test(scleraClean) || /^ningun/i.test(scleraClean);
  const facialMorphClean = cleanVal(state.facial?.facialMorphology, true);
  const isFacialMorphStandard = !facialMorphClean || /humanoide/i.test(facialMorphClean) || /ningun/i.test(facialMorphClean);
  const hairElementalClean = cleanVal(state.hair?.hairElemental, true);
  const isHairElementalStandard = !hairElementalClean || /org[aá]nico/i.test(hairElementalClean) || /ningun/i.test(hairElementalClean);

  const breastDevClean = cleanVal(state.anatomy?.breastDevelopment, true);
  const isBreastDevNone = !breastDevClean || /ningun|no aplica|plano/i.test(breastDevClean);

  const bodyParts = [
    buildPart('sexo', state.anatomy?.sexBase, true),
    buildPart('complexión', state.anatomy?.complexion, true),
    buildPart('altura', state.anatomy?.height, true),
    !isBreastDevNone ? buildPart('desarrollo mamario', breastDevClean, true) : '',
    buildPart('cintura', state.anatomy?.waist, true),
    buildPart('glúteos', state.anatomy?.glutes, true),
    buildPart('muslos', state.anatomy?.thighs, true),
    !isBiped ? `estructura inferior ${lowerBodyClean}` : '',
    !isChestCoreNone ? `núcleo vital ${chestCoreClean}` : '',
    !isNeckFeatureNone ? `rasgo cuello ${neckFeatureClean}` : ''
  ].filter(Boolean);
  if (bodyParts.length) parts.push(`cuerpo: ${bodyParts.join(', ')}`);

  // 3. Facial features
  const eyeParts = [
    state.facial?.isHeterochromia
      ? `heterocromía (ojo izquierdo ${cleanVal(state.facial?.eyeColor, true) || 'estándar'}, ojo derecho ${cleanVal(state.facial?.eyeColorRight, true) || cleanVal(state.facial?.eyeColor, true)})`
      : buildPart('color', state.facial?.eyeColor, true),
    state.facial?.pupilShape && !/redonda humana/i.test(state.facial.pupilShape) ? `pupila ${cleanVal(state.facial.pupilShape, true)}` : '',
    state.facial?.irisGlow ? 'iris bioluminiscente' : '',
    !isScleraNone ? `esclerótica ${scleraClean}` : '',
    buildPart('forma', state.facial?.eyesCategory, true),
    buildPart('tipo', state.facial?.eyesSubtype, true)
  ].filter(Boolean);
  if (eyeParts.length) parts.push(`ojos: ${eyeParts.join(', ')}`);

  const iris = cleanVal(state.facial?.iris, true);
  if (iris && !/est[aá]ndar/i.test(iris)) parts.push(`iris: forma ${iris}`);
  const nose = cleanVal(state.facial?.nose, true);
  if (nose && !/est[aá]ndar/i.test(nose)) parts.push(`nariz: ${nose}`);
  if (!isFacialMorphStandard) parts.push(`morfología facial: ${facialMorphClean}`);

  const mouthParts = [
    buildPart('labios', state.facial?.lips, true),
    buildPart('expresión', state.facial?.mouthExp, true),
    buildPart('dientes', state.facial?.teeth, true),
    state.facial?.tongueType && !/humana estándar/i.test(state.facial.tongueType) ? `lengua ${cleanVal(state.facial.tongueType, true)}` : ''
  ].filter(Boolean);
  if (mouthParts.length) parts.push(`boca: ${mouthParts.join(', ')}`);

  const earsBaseClean = cleanVal(state.facial?.earsBase, true);
  const kemonoEarsClean = cleanVal(state.facial?.kemonoEars, true);
  const earParts = [
    earsBaseClean ? `orejas ${earsBaseClean}` : '',
    kemonoEarsClean ? `orejas kemono ${kemonoEarsClean}` : ''
  ].filter(Boolean);
  if (earParts.length) parts.push(earParts.join(', '));

  // 4. Hair (rich & complete)
  const hairLengthFormatted = formatHairLength(state.hair?.length);
  const hairCutClean = cleanVal(state.hair?.cut, true);
  const hairTextureClean = cleanVal(state.hair?.texture, true);
  const hairStyleClean = cleanVal(state.hair?.style, true);
  const hairBangsClean = cleanVal(state.hair?.bangs, true);
  const hairPartClean = cleanVal(state.hair?.part, true);
  const hairColorClean = cleanVal(state.hair?.hairColor, true);

  const hairTokens = [
    hairColorClean ? `color ${hairColorClean}` : '',
    !isHairElementalStandard ? `elemento ${hairElementalClean}` : '',
    hairTextureClean ? `textura ${hairTextureClean}` : '',
    hairCutClean ? `corte ${hairCutClean}` : '',
    hairLengthFormatted ? `largo ${hairLengthFormatted}` : '',
    hairBangsClean && !/sin flequillo/i.test(hairBangsClean) ? `flequillo ${hairBangsClean}` : '',
    hairPartClean && !/sin partido/i.test(hairPartClean) ? `partido ${hairPartClean}` : '',
    hairStyleClean && !/sin peinado|suelto/i.test(hairStyleClean) ? `peinado ${hairStyleClean}` : ''
  ].filter(Boolean);
  if (hairTokens.length) parts.push(`cabello: ${hairTokens.join(', ')}`);

  // 5. Skin & Patterns (A.2.4.4)
  const skinColorClean = cleanVal(state.anatomy?.skinColor, true);
  const skinPatternClean = cleanVal(state.appendices?.skinAndMarks, true);
  const isSkinPatternStandard = !skinPatternClean || /piel lisa/i.test(skinPatternClean) || /est[aá]ndar/i.test(skinPatternClean);
  const scaleLocsLower = (state.appendices?.scaleLocations || []).map(formatLocationSpan).filter(Boolean);

  const skinTokens = [
    skinColorClean ? `tono ${skinColorClean}` : '',
    !isSkinPatternStandard ? `textura ${skinPatternClean}` : '',
    scaleLocsLower.length ? `escamas en ${scaleLocsLower.join(', ')}` : ''
  ].filter(Boolean);
  if (skinTokens.length) parts.push(`piel: ${skinTokens.join(', ')}`);

  // Marcas y Rasgos Singulares (A.2.4.5)
  const detailedMarksLower = (state.appendices?.markTypes || []).map(m => {
    const shape = (state.appendices?.markShapes || {})[m];
    const color = (state.appendices?.markColors || {})[m];
    const secondaryColor = (state.appendices?.markSecondaryColors || {})[m];
    const locs = ((state.appendices?.markLocations || {})[m] || []).map(formatLocationSpan).filter(Boolean);
    const text = state.appendices?.markTexts?.[m];
    const emblemConfig = state.appendices?.markEmblemConfigs?.[m];
    const finish = state.appendices?.markFinishes?.[m];
    return formatMarkDescription(m, shape, color, locs, true, text, emblemConfig, finish, secondaryColor);
  }).filter(Boolean);

  if (detailedMarksLower.length) parts.push(`marcas: ${detailedMarksLower.join('; ')}`);

  // 6. Makeup
  if (state.makeup) {
    const mkTokens: string[] = [];
    const lipStyle = cleanVal(state.makeup.lipstickStyle, true);
    const lipColor = cleanVal(state.makeup.lipstickColor, true);
    const lipFinish = cleanVal(state.makeup.lipstickFinish, true);
    if (lipStyle && !/labios naturales/i.test(lipStyle)) {
      mkTokens.push(`labial ${lipStyle}${lipColor ? ` color ${lipColor}` : ''}${lipFinish ? ` ${lipFinish}` : ''}`);
    }

    const blushStyle = cleanVal(state.makeup.blushStyle, true);
    const blushColor = cleanVal(state.makeup.blushColor, true);
    if (blushStyle && !/ningun/i.test(blushStyle)) {
      mkTokens.push(`rubor ${blushStyle}${blushColor ? ` tono ${blushColor}` : ''}`);
    }

    const nailStyle = cleanVal(state.makeup.nailStyle, true);
    const nailColor = cleanVal(state.makeup.nailColor, true);
    const nailFinish = cleanVal(state.makeup.nailFinish, true);
    if (nailStyle && !/u[ñn]as naturales/i.test(nailStyle)) {
      mkTokens.push(`uñas ${nailStyle}${nailColor ? ` esmalte ${nailColor}` : ''}${nailFinish ? ` ${nailFinish}` : ''}`);
    }

    const eyeShadow = cleanVal(state.makeup.eyeshadowStyle, true);
    const eyeShadowColor = cleanVal(state.makeup.eyeshadowColor, true);
    if (eyeShadow && !/natural/i.test(eyeShadow)) {
      mkTokens.push(`sombra de ojos ${eyeShadow}${eyeShadowColor ? ` tono ${eyeShadowColor}` : ''}`);
    }

    const eyelinerM = cleanVal(state.makeup.eyelinerStyle, true);
    if (eyelinerM && !/ningun/i.test(eyelinerM)) {
      mkTokens.push(`delineado ${eyelinerM}`);
    }

    const faceAcc = cleanVal(state.makeup.faceAccent, true);
    if (faceAcc && !/ningun/i.test(faceAcc)) {
      mkTokens.push(`acento facial ${faceAcc}`);
    }

    if (mkTokens.length > 0) {
      parts.push(`maquillaje: ${mkTokens.join(', ')}`);
    }
  }
  
  // 7. Appendices & Supernatural Traits (Horns, Wings, Tails, Antennae, Extra Eyes, Extra Arms, Special Limbs, Lower Body)
  const horns = cleanVal(state.appendices?.hornsForm, true);
  if (horns) {
    const hL = cleanVal(state.appendices?.hornsLength, true);
    const hP = cleanVal(state.appendices?.hornsPosition, true);
    parts.push(`cuernos: forma ${horns}${hL ? ` largo ${hL}` : ''}${hP ? ` en ${hP}` : ''}`);
  }

  const wings = cleanVal(state.appendices?.wingsType, true);
  if (wings) {
    const wS = cleanVal(state.appendices?.wingsSize, true);
    const wP = cleanVal(state.appendices?.wingsPosition, true);
    parts.push(`alas: tipo ${wings}${wS ? ` tamaño ${wS}` : ''}${wP ? ` en ${wP}` : ''}`);
  }

  const tail = cleanVal(state.appendices?.tailsType, true);
  if (tail) {
    const tL = cleanVal(state.appendices?.tailsLength, true);
    const tCP = cleanVal(state.appendices?.tailsColorPrimary, true);
    const tCS = cleanVal(state.appendices?.tailsColorSecondary, true);
    const tF = cleanVal(state.appendices?.tailsFinish, true);
    parts.push(`cola: tipo ${tail}${tL ? ` largo ${tL}` : ''}${tCP ? ` color ${tCP}` : ''}${tCS && !/ningun/i.test(tCS) ? ` puntas ${tCS}` : ''}${tF ? ` acabado ${tF}` : ''}`);
  }

  const antennae = cleanVal(state.appendices?.antennaeType, true);
  if (antennae && !/^ninguna?$/i.test(antennae)) {
    const aL = cleanVal(state.appendices?.antennaeLength, true);
    const aP = cleanVal(state.appendices?.antennaePosition, true);
    parts.push(`antenas: tipo ${antennae}${aL ? ` largo ${aL}` : ''}${aP ? ` en ${aP}` : ''}`);
  }

  const extraEyes = cleanVal(state.appendices?.extraEyes, true);
  if (extraEyes && !/^ningun/i.test(extraEyes) && !/2 ojos est/i.test(extraEyes)) {
    parts.push(`ojos adicionales: ${extraEyes}`);
  }

  const extraArms = cleanVal(state.appendices?.extraArms, true);
  if (extraArms && !/^ningun/i.test(extraArms) && !/2 brazos est/i.test(extraArms)) {
    parts.push(`brazos adicionales: ${extraArms}`);
  }

  const specialLimbs = cleanVal(state.appendices?.specialLimbs, true);
  if (specialLimbs && !/^ningun/i.test(specialLimbs) && !/org[aá]nicas est/i.test(specialLimbs)) {
    parts.push(`extremidades especiales: ${specialLimbs}`);
  }

  const lowerBody = cleanVal(state.appendices?.lowerBodyStructure || state.anatomy?.lowerBodyStructure, true);
  if (lowerBody && !/b[ií]pedo humanoide est[aá]ndar/i.test(lowerBody)) {
    parts.push(`cuerpo inferior y locomoción: ${lowerBody}`);
  }

  const clawsLower = cleanVal(state.appendices?.clawsType, true);
  if (clawsLower && !/uñas naturales/i.test(clawsLower)) {
    parts.push(`uñas y garras: ${clawsLower}`);
  }

  // 8. Wardrobe (Extensive, descriptive garments with length, sleeves, coverage, and details)
  if (state.wardrobes && state.wardrobes.length > 0) {
    const wardrobeStrings = state.wardrobes
      .filter(w => Boolean(cleanVal(w.name, true)))
      .map(w => formatGarmentDescription(w, true))
      .filter(Boolean);
    if (wardrobeStrings.length > 0) {
      parts.push(`vestimenta detallada: ${wardrobeStrings.join('; ')}`);
    }
  }

  // 9. Role Attire, Armor & Protection (Estado 4)
  const isRoleCivil = isRoleNull(state.role);
  const hasSpecialArmor = hasValidArmorProtection(state.armor?.specialType, state.role);
  const roleOutfitTypeStr = cleanVal(state.armor?.type, true);
  const isNoneOutfitPrompt = !roleOutfitTypeStr || /^ninguna?$/i.test(roleOutfitTypeStr) || isRoleCivil;
  const hasPromptRoleOutfit = Boolean(roleOutfitTypeStr && !isNoneOutfitPrompt);
  if (hasPromptRoleOutfit) {
    parts.push(`atuendo de rol: ${roleOutfitTypeStr}`);
  }

  if (hasSpecialArmor) {
    const mat = !isNoneOutfitPrompt ? cleanVal(state.armor?.material, true) : '';
    const fin = !isNoneOutfitPrompt ? cleanVal(state.armor?.finish, true) : '';
    const cleanArmorType = cleanVal(state.armor?.specialType, true);
    if (cleanArmorType) {
      parts.push(`protección de rol: ${cleanArmorType}${mat ? ` de ${mat}` : ''}${fin ? ` acabado ${fin}` : ''}`);
    }
  }

  if (!isRoleCivil && state.armor?.pieces && state.armor.pieces.length > 0) {
    const promptPieces = state.armor.pieces.map(rawPiece => {
      const cleanName = cleanVal(rawPiece.replace(/^P\d+\.?\d*\s*/, '').replace(/^P-Custom:\s*/, ''), true);
      if (!cleanName) return '';
      const detail = state.armor?.pieceDetails?.[rawPiece];
      if (!detail) return cleanName;

      const pieceTokens = [cleanName];
      if (detail.color && cleanVal(detail.color, true)) {
        const cName = resolveColorName(detail.color);
        pieceTokens.push(`color ${cName.toLowerCase()}`);
      }
      if (detail.length && cleanVal(detail.length, true)) pieceTokens.push(`largo ${detail.length.toLowerCase()}`);
      if (detail.material && cleanVal(detail.material, true) && detail.material !== state.armor?.material) pieceTokens.push(`en ${detail.material.toLowerCase()}`);
      if (detail.finish && cleanVal(detail.finish, true) && detail.finish !== state.armor?.finish) pieceTokens.push(`acabado ${detail.finish.toLowerCase()}`);
      if (detail.detail && cleanVal(detail.detail, true)) {
        if (detail.detailLocation && detail.detailLocation !== 'Patrón integral / Toda la superficie' && cleanVal(detail.detailLocation, true)) {
          pieceTokens.push(`con ${detail.detail.toLowerCase()} en ${detail.detailLocation.toLowerCase()}`);
        } else {
          pieceTokens.push(`con ${detail.detail.toLowerCase()}`);
        }
      } else if (detail.detailLocation && detail.detailLocation !== 'Patrón integral / Toda la superficie' && cleanVal(detail.detailLocation, true)) {
        pieceTokens.push(`acentos en ${detail.detailLocation.toLowerCase()}`);
      }
      if (detail.description && cleanVal(detail.description, true)) {
        pieceTokens.push(`silueta ${detail.description.toLowerCase()}`);
      }

      return pieceTokens.join(' ');
    }).filter(Boolean);

    if (promptPieces.length > 0) {
      parts.push(`piezas de indumentaria y armadura: ${promptPieces.join(', ')}`);
    }
  }

  // 10. Equipment & Weapons
  const eqDetails = state.equipment?.equipmentDetails || {};
  (state.equipment?.weapons || []).forEach(w => {
    const cl = cleanVal(w, true);
    if (!cl) return;
    const det = eqDetails[w];
    if (det) {
      const tokens = [cl];
      if (det.color && cleanVal(det.color, true)) tokens.push(`color ${resolveColorName(det.color).toLowerCase()}`);
      if (det.material && cleanVal(det.material, true)) tokens.push(`en ${det.material.toLowerCase()}`);
      if (det.finish && cleanVal(det.finish, true)) tokens.push(`acabado ${det.finish.toLowerCase()}`);
      if (det.sizeOrLength && cleanVal(det.sizeOrLength, true)) tokens.push(`tamaño ${det.sizeOrLength.toLowerCase()}`);
      if (det.detail && cleanVal(det.detail, true)) tokens.push(`con ${det.detail.toLowerCase()}`);
      parts.push(`arma: ${tokens.join(' ')}`);
    } else {
      parts.push(`arma: ${cl}`);
    }
  });

  if (state.equipment?.weaponGrips && state.equipment.weaponGrips.length > 0) {
    const validGrips = state.equipment.weaponGrips.map(g => cleanVal(g, true)).filter(Boolean);
    if (validGrips.length > 0) {
      parts.push(`empuñadura: ${validGrips.join(', ')}`);
    }
  }

  (state.equipment?.bags || []).forEach(b => {
    const cl = cleanVal(b, true);
    if (!cl) return;
    const det = eqDetails[b];
    if (det) {
      const tokens = [cl];
      if (det.color && cleanVal(det.color, true)) tokens.push(`color ${resolveColorName(det.color).toLowerCase()}`);
      if (det.material && cleanVal(det.material, true)) tokens.push(`en ${det.material.toLowerCase()}`);
      if (det.finish && cleanVal(det.finish, true)) tokens.push(`acabado ${det.finish.toLowerCase()}`);
      if (det.sizeOrLength && cleanVal(det.sizeOrLength, true)) tokens.push(`tamaño ${det.sizeOrLength.toLowerCase()}`);
      if (det.detail && cleanVal(det.detail, true)) tokens.push(`con ${det.detail.toLowerCase()}`);
      parts.push(`bolso: ${tokens.join(' ')}`);
    } else {
      parts.push(`bolso: ${cl}`);
    }
  });

  (state.equipment?.items || []).forEach(i => {
    const cl = cleanVal(i, true);
    if (!cl) return;
    const det = eqDetails[i];
    if (det) {
      const tokens = [cl];
      if (det.color && cleanVal(det.color, true)) tokens.push(`color ${resolveColorName(det.color).toLowerCase()}`);
      if (det.material && cleanVal(det.material, true)) tokens.push(`en ${det.material.toLowerCase()}`);
      if (det.finish && cleanVal(det.finish, true)) tokens.push(`acabado ${det.finish.toLowerCase()}`);
      if (det.sizeOrLength && cleanVal(det.sizeOrLength, true)) tokens.push(`tamaño ${det.sizeOrLength.toLowerCase()}`);
      if (det.detail && cleanVal(det.detail, true)) tokens.push(`con ${det.detail.toLowerCase()}`);
      parts.push(`objeto: ${tokens.join(' ')}`);
    } else {
      parts.push(`objeto: ${cl}`);
    }
  });

  // 11. Style Thematic Pieces & Accessories (Estado 4)
  const of = state.orientalFantasy;
  if (of) {
    const traditionClean = cleanVal(of.tradition, true);
    if (traditionClean) parts.push(`arquetipo temático: ${traditionClean}`);
    
    if (!isRoleCivil && of.armorPieces && of.armorPieces.length > 0) {
      const validStyleArmors = of.armorPieces.map(p => cleanVal(p, true)).filter(Boolean);
      if (validStyleArmors.length > 0) {
        parts.push(`armadura temática: ${validStyleArmors.join(', ')}`);
      }
    }
    if (of.culturalAccessories && of.culturalAccessories.length > 0) {
      const validCulturalAccs = of.culturalAccessories.map(a => cleanVal(a, true)).filter(Boolean);
      if (validCulturalAccs.length > 0) {
        parts.push(`accesorios temáticos: ${validCulturalAccs.join(', ')}`);
      }
    }
    if (!isNoneOutfitPrompt) {
      const motifClean = cleanVal(of.spiritualMotif, true);
      if (motifClean) parts.push(`motivo/sello: ${motifClean}`);
      const patternClean = cleanVal(of.silkPattern, true);
      if (patternClean) parts.push(`patrón textil: ${patternClean}`);
      const jadeClean = cleanVal(of.jadeAccentColor, true);
      if (jadeClean) parts.push(`acento mineral: ${jadeClean}`);
      if (of.energyAura && cleanVal(of.energyAura, true) && of.energyAura !== 'Sin Aura (Aspecto Natural Puramente Físico)' && !/sin aura/i.test(of.energyAura)) {
        parts.push(`aura ambiental: ${cleanVal(of.energyAura, true)}`);
      }
    }
    const weaponStyleClean = cleanVal(of.weaponStyle, true);
    if (weaponStyleClean) parts.push(`arma temática: ${weaponStyleClean}`);
  }

  // 12. Background context
  const homelandClean = cleanVal(state.background?.homelandOrDomain, true);
  if (homelandClean) parts.push(`origen territorial: ${homelandClean}`);
  const factionClean = cleanVal(state.background?.factionOrFaith, true);
  if (factionClean) parts.push(`facción/fe: ${factionClean}`);
  const rawFatalFlawsClean = (Array.isArray(state.background?.fatalFlaws) && state.background.fatalFlaws.length > 0)
    ? state.background.fatalFlaws
    : (state.background?.fatalFlawOrVulnerability ? state.background.fatalFlawOrVulnerability.split(/\s*\|\s*|\s*;\s*/).map(s => s.trim()).filter(Boolean) : []);
  const fatalFlawClean = rawFatalFlawsClean.map(f => cleanVal(f, true)).filter(Boolean).join(', ');
  if (fatalFlawClean) parts.push(`vulnerabilidad: ${fatalFlawClean}`);

  // 13. Intimate Anatomy & Explicit Parameters (Estado 2.6 R+18)
  const nsfw = state.nsfw;
  const hasIntimateAnatomyForPrompt = Boolean(
    nsfw?.isNsfwEnabled ||
    nsfw?.areolaColor ||
    nsfw?.areolaSize ||
    nsfw?.nippleType ||
    nsfw?.pubicHairStyle ||
    nsfw?.genitalType ||
    nsfw?.genitalSize ||
    (Array.isArray(nsfw?.genitalDetails) ? nsfw.genitalDetails.length > 0 : Boolean(nsfw?.genitalDetails)) ||
    (nsfw?.bodySensitivities && nsfw.bodySensitivities.length > 0) ||
    nsfw?.intimatePersonality
  );

  if (hasIntimateAnatomyForPrompt && nsfw) {
    const nsfwParts: string[] = [];

    // Pezones & Areolas
    if (nsfw.areolaColor) nsfwParts.push(`areolas color ${cleanVal(nsfw.areolaColor, true)}`);
    if (nsfw.areolaSize) nsfwParts.push(`proporción de areolas ${cleanVal(nsfw.areolaSize, true)}`);
    if (nsfw.nippleType) nsfwParts.push(`morfología de pezones ${cleanVal(nsfw.nippleType, true)}`);

    // Genitales
    if (nsfw.genitalType) nsfwParts.push(`genitales ${cleanVal(nsfw.genitalType, true)}`);
    if (nsfw.genitalSize) nsfwParts.push(`proporción genital ${cleanVal(nsfw.genitalSize, true)}`);

    const rawGDetails = nsfw.genitalDetails;
    const gDetailsList: string[] = Array.isArray(rawGDetails)
      ? rawGDetails.map(d => cleanVal(d, true)).filter(Boolean)
      : (typeof rawGDetails === 'string' && cleanVal(rawGDetails, true) ? [cleanVal(rawGDetails, true)] : []);
    if (gDetailsList.length > 0) {
      nsfwParts.push(`acabados íntimos (${gDetailsList.join(' | ')})`);
    }

    // Otros Parámetros Explícitos
    if (nsfw.pubicHairStyle) nsfwParts.push(`vello púbico ${cleanVal(nsfw.pubicHairStyle, true)}`);

    const rawSens = nsfw.bodySensitivities || [];
    const resolvedSens = rawSens.map(idOrName => {
      const found = BODY_SENSITIVITIES.find(b => b.id === idOrName || b.name === idOrName);
      return found ? found.name.toLowerCase() : cleanVal(idOrName, true);
    }).filter(Boolean);
    if (resolvedSens.length > 0) {
      nsfwParts.push(`zonas hipersensibles (${resolvedSens.join(', ')})`);
    }

    if (nsfw.intimatePersonality) nsfwParts.push(`dinámica íntima ${cleanVal(nsfw.intimatePersonality, true)}`);

    if (nsfwParts.length > 0) {
      parts.push(nsfwParts.join(', '));
    }
  }

  return parts.join(', ');
};

// Formats canonical background description in real-time (Estado 5)
export const formatBackgroundCanonicalDescription = (state: CharacterState): string => {
  const lines: string[] = [];

  const charName = state.name?.trim() || 'Sin nombre asignado';
  const archetype = cleanVal(state.archetype, false) || 'Genérico';
  lines.push(`[Perfil Canónico: ${charName} | Arquetipo: ${archetype}]`);

  // Rasgos y Valores
  const validTraits = (state.personalityTraits || []).map(t => cleanVal(t, false)).filter(Boolean);
  const coreVals = cleanVal(state.background?.coreValues, false);
  if (validTraits.length > 0) {
    lines.push(`• Rasgos de Personalidad: ${validTraits.join(', ')}`);
  }
  if (coreVals) {
    lines.push(`• Core de Valores: ${coreVals}`);
  }

  // Origen territorial y facción
  const homeland = cleanVal(state.background?.homelandOrDomain, false);
  const faction = cleanVal(state.background?.factionOrFaith, false);
  if (homeland) lines.push(`• Origen Territorial / Dominio: ${homeland}`);
  if (faction) lines.push(`• Facción / Fe / Filosofía: ${faction}`);

  // Detalles Únicos y Singularidades
  const uniqueDetails = (state.background?.uniqueDetails || []).filter(Boolean);
  if (uniqueDetails.length > 0) {
    lines.push(`• Detalles Únicos & Singularidades: ${uniqueDetails.join(' | ')}`);
  }

  // Línea Temporal Narrativa
  const timeline = state.background?.narrativeTimeline || state.narrativeTimeline;
  if (timeline && timeline.milestones && timeline.milestones.length > 0) {
    const timelineSummary = timeline.milestones.map(m => `[${m.era}] ${m.periodOrAge}: ${m.title}`).join(' -> ');
    lines.push(`• Línea Temporal Narrativa: ${timelineSummary}`);
  }

  // Talón de Aquiles / Defectos Fatales
  const rawFatalFlaws = (Array.isArray(state.background?.fatalFlaws) && state.background.fatalFlaws.length > 0)
    ? state.background.fatalFlaws
    : (state.background?.fatalFlawOrVulnerability ? state.background.fatalFlawOrVulnerability.split(/\s*\|\s*|\s*;\s*/).map(s => s.trim()).filter(Boolean) : []);
  const fatalFlaws = rawFatalFlaws.map(f => cleanVal(f, false)).filter(Boolean);
  if (fatalFlaws.length > 0) {
    lines.push(`• Talón de Aquiles / Defectos Fatales: ${fatalFlaws.join(' | ')}`);
  }

  // Historia de Origen
  const bg = state.background?.backstory?.trim();
  if (bg) {
    lines.push(`• Historia de Origen: ${bg}`);
  }

  // Motivación Principal
  const mot = state.background?.motivation?.trim();
  if (mot) {
    lines.push(`• Motivación Principal: ${mot}`);
  }

  // Personalización Avanzada
  const adv = state.background?.advancedCustomization;
  if (adv) {
    const advParts: string[] = [];
    if (adv.voiceTone) advParts.push(`Voz: ${adv.voiceTone}`);
    if (adv.speechStyle) advParts.push(`Habla: ${adv.speechStyle}`);
    if (adv.catchphrasesOrIdioms) advParts.push(`Muletilla: ${adv.catchphrasesOrIdioms}`);
    if (adv.skills && adv.skills.length > 0) advParts.push(`Habilidades: ${adv.skills.join(', ')}`);
    if (adv.habitsAndMannerisms && adv.habitsAndMannerisms.length > 0) advParts.push(`Hábitos: ${adv.habitsAndMannerisms.join('; ')}`);
    if (advParts.length > 0) {
      lines.push(`• Personalización Avanzada: ${advParts.join(' | ')}`);
    }
  }

  // Relaciones
  const rels = (state.background?.relationships || []).filter(r => Boolean(cleanVal(r.targetCharacterName, false)));
  if (rels.length > 0) {
    const relSummary = rels.map(r => `${r.targetCharacterName} [${r.relationshipType || 'Vínculo'}]`).join(', ');
    lines.push(`• Relaciones Registradas: ${relSummary}`);
  }

  return lines.join('\n');
};
