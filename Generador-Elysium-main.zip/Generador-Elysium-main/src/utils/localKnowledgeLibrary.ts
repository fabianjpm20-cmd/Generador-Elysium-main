/**
 * BIBLIOTECA ONTOLÓGICA Y COGNITIVA LOCAL DE ALTO RENDIMIENTO
 * ==========================================================
 * Provee al sistema de un corpus enciclopédico determinista, offline-first
 * y de velocidad ultra-rápida (0ms latencia de red) que abarca:
 * 1. Anatomía y Biomecánica
 * 2. Ropa, Fibras y Vestuario
 * 3. Física Fenomenológica (Lag de inercia, Efectos Ripple, Ondas, Convección)
 * 4. Cultura, Protocolo y Antropología
 * 5. Psicología, Teoría de la Mente y Razonamiento Lógico/Emocional
 * 6. Arquitectura, Masa Constructiva y Espacialidad
 * 7. Geología, Edafología y Topografía
 * 8. Tono Narrativo, Prosodia y Lenguaje Literario
 */

export type KnowledgeDomain =
  | 'anatomy'
  | 'clothing'
  | 'physics'
  | 'culture'
  | 'psychology'
  | 'architecture'
  | 'geology'
  | 'literature';

export interface KnowledgeEntry {
  id: string;
  domain: KnowledgeDomain;
  title: string;
  keywords: string[];
  summary: string;
  detailedMechanics: string;
  sensoryManifestations: {
    visual: string;
    auditory?: string;
    tactile?: string;
    kinesthetic?: string;
    olfactory?: string;
  };
  reasoningRules: string[];
  narrativeApplication: string;
}

export interface KnowledgeReasoningResult {
  matchedDomains: KnowledgeDomain[];
  relevantEntries: KnowledgeEntry[];
  inferredPhysicalEffects: string[];
  inferredSomaticResponses: string[];
  inferredEnvironmentalEchoes: string[];
  literaryStyleAdvice: {
    pace: 'rapid_percussive' | 'contemplative_cadenced' | 'suspenseful_layered';
    suggestedSensoryFocus: string;
    narrativeDevice: string;
  };
}

// -------------------------------------------------------------------------
// CORPUS DE CONOCIMIENTOS POR DOMINIO
// -------------------------------------------------------------------------

export const KNOWLEDGE_CORPUS: Record<KnowledgeDomain, KnowledgeEntry[]> = {
  // -----------------------------------------------------------------------
  // 1. ANATOMÍA Y BIOMECÁNICA
  // -----------------------------------------------------------------------
  anatomy: [
    {
      id: 'anat_biomechanics_center_gravity',
      domain: 'anatomy',
      title: 'Biomecánica, Centro de Gravedad y Distribución Cinética',
      keywords: ['equilibrio', 'peso', 'postura', 'gravedad', 'pisada', 'apoyo', 'caída', 'cadera', 'zancada', 'inercia'],
      summary: 'El centro de gravedad humanoide (nivel L4-S1 en reposo) gobierna la estabilidad, la tensión de cuádriceps y la compensación pélvica.',
      detailedMechanics: 'Al detenerse súbitamente o esquivar, el tronco continúa su vector inercial. Los tobillos flexionan dorsalmente, la columna compensa con curvatura lordótica y los brazos realizan abducción refleja. La fatiga muscular reduce la absorción de impactos, trasladando el estrés a meniscos y cartílago sacroilíaco.',
      sensoryManifestations: {
        visual: 'Micro-oscilación compensatoria en los tobillos; hundimiento del talón antes de distribuir la masa al metatarso; tensión de los tendones extensores en el empeine.',
        auditory: 'Crujido de cartílago bajo carga rápida; sonido sordo de talón percutiendo suelo antes del arrastre del cuero.',
        tactile: 'Presión densa focalizada en la almohadilla plantar; tensión ardiente en gemelos al frenar en pendiente.',
        kinesthetic: 'Vértigo propioceptivo momentáneo si el pie resbala en grava o losa pulida; ajuste reflejo del core abdominal.'
      },
      reasoningRules: [
        'Un personaje cargado o herido en un miembro no puede cambiar de vector de movimiento instantáneamente sin perder balance.',
        'La inclinación previa del tronco anticipa la dirección de aceleración antes de que el pie abandone el piso.'
      ],
      narrativeApplication: 'Describe la masa del personaje en relación con el suelo: el crujido del peso redistribuyéndose, el apoyo en la rodilla adelantada y la tracción antes del despegue.'
    },
    {
      id: 'anat_microexpressions_cranial',
      domain: 'anatomy',
      title: 'Microexpresiones Faciales y Dinámica Craneofacial',
      keywords: ['rostro', 'mirada', 'ceño', 'mandíbula', 'labios', 'ojos', 'músculos faciales', 'parpadeo', 'deglución'],
      summary: 'Las expresiones genuinas duran entre 1/25 y 1/5 de segundo, activando músculos inervados por el VII par craneal (nervio facial).',
      detailedMechanics: 'La sorpresa genuina involucra el músculo frontal elevando simétricamente las cejas sin arrugas profundas centrales. El desdén o escepticismo activa asimétricamente el buccinador y el elevador del labio superior. La contención de cólera o miedo somatiza en contracción involuntaria del masetero (apretar mandíbula) y deglución seca por inhibición de glándulas salivales simpáticas.',
      sensoryManifestations: {
        visual: 'Espasmo rápido en la comisura del labio; ensanchamiento escleral que deja ver el blanco sobre el iris; abultamiento muscular en el ángulo de la mandíbula; tensión de la piel sobre los pómulos.',
        auditory: 'El chasquido tenue de la saliva espesa en la garganta al tragar con dificultad; respiración suspendida un instante.',
        tactile: 'Pulso visible en la sien y en la carótida; sequedad en las mucosas orales.'
      },
      reasoningRules: [
        'Un personaje que intenta ocultar hostilidad o sorpresa mostrará micro-asimetrías en párpados o comisuras antes de reasumir una máscara neutra.',
        'La mirada sostenida sin parpadeo indica evaluación de amenaza o dominancia; el desvío ocular súbito hacia abajo denota procesamiento interno o sumisión.'
      ],
      narrativeApplication: 'Evita decir "tenía miedo"; describe el nudo deglutorio en la manzana de Adán, la rigidez mandibular y la dilatación de sus pupilas a la luz de las teas.'
    },
    {
      id: 'anat_autonomic_somatic_cascade',
      domain: 'anatomy',
      title: 'Cascada Somática y Sistema Nervioso Autónomo',
      keywords: ['adrenalina', 'pulso', 'sudor', 'respiración', 'escalofrío', 'vasoconstricción', 'piloerección', 'temblor'],
      summary: 'La activación simpática redirige flujo sanguíneo de la dermis y vísceras hacia músculo estriado esquelético (lucha/huida).',
      detailedMechanics: 'Provoca palidez periférica instantánea, piloerección en antebrazos y nuca por contracción de músculos erectores del pelo, taquipnea superficial y dilatación pupilar (midriasis) para maximizar campo visual, a expensas del enfoque fino cercano. Las manos se tornan frías y ligeramente sudorosas por secreción ecrina simpática.',
      sensoryManifestations: {
        visual: 'Palidez cérea en mejillas; vello erizado en los brazos; sudor frío humedeciendo la línea del cabello; aleteo nasal rápido.',
        auditory: 'Respiración audible entrecortada con sibilancia bronquial leve; el golpeteo del pulso retumbando en el oído interno.',
        tactile: 'Piel fría y pegajosa al contacto; temblor distal fino en la punta de los dedos al sostener un objeto o pluma.'
      },
      reasoningRules: [
        'Bajo adrenalina extrema, la motricidad fina (ensartar una aguja, forzar una cerradura delicada) se deteriora drásticamente mientras que la motricidad gruesa (correr, empujar) aumenta.',
        'Tras el pico simpático sobreviene un bajón parasimpático con laxitud muscular, temblor incontrolable y sed intensa.'
      ],
      narrativeApplication: 'Muestra la respuesta del cuerpo antes de la emoción consciente: el frío en los dedos, la boca seca como polvo y el corazón latiendo contra las costillas.'
    }
  ],

  // -----------------------------------------------------------------------
  // 2. ROPA, FIBRAS Y VESTUARIO
  // -----------------------------------------------------------------------
  clothing: [
    {
      id: 'cloth_fibers_weight_drape',
      domain: 'clothing',
      title: 'Texturas, Fibras, Gramaje y Caída (Drapeado)',
      keywords: ['telas', 'lana', 'lino', 'seda', 'cuero', 'capas', 'pliegues', 'ropaje', 'terciopelo', 'gramaje'],
      summary: 'El comportamiento de la ropa está regido por la elasticidad de la fibra, el ligamento del tejido y el peso por metro cuadrado.',
      detailedMechanics: 'El lino crudo es rígido, forma pliegues angulares quebradizos y cruje secamente. La seda pesada (damasco, brocado) cae con ondas continuas y fluidas, reflejando luz especular con sheen móvil. La lana hilada a mano es densa, absorbente y silencia el movimiento. El cuero endurecido al aceite conserva forma tubular y restringe arcos de movimiento en cintura y codos.',
      sensoryManifestations: {
        visual: 'Pliegues geométricos en el lino; ondulaciones continuas en capas de lana fina; lustre metálico en los brocados según el ángulo de luz.',
        auditory: 'El susurro seco (frufrú) del tafetán; el crujido untuoso del cuero al doblar el codo; el apagado roce sordo de paños pesados de lana.',
        tactile: 'La textura rugosa con briznas vegetales del sayal; la frialdad inicial de la seda contra el pecho; el peso tranquilizador de una capa de tres cuartos de lana forrada.'
      },
      reasoningRules: [
        'Las prendas con forro múltiple y capas no se arrugan igual que una túnica de una sola capa; amortiguan golpes contusos leves pero acumulan sudor y peso.',
        'La ropa suelta ondea con retardo respecto al paso y genera firma sonora reconocible en la penumbra.'
      ],
      narrativeApplication: 'Diferencia a los personajes por cómo suena y cae su indumentaria: el chasquido de un jubón ajustado frente a la pesada quietud de los hábitos monacales.'
    },
    {
      id: 'cloth_weather_deterioration',
      domain: 'clothing',
      title: 'Respuesta al Clima, Humedad y Deterioro Textil',
      keywords: ['lluvia', 'lodo', 'humedad', 'empapado', 'desgaste', 'polvo', 'sudor', 'mojado', 'salpicaduras'],
      summary: 'Los textiles absorben entre el 15% (lino) y el 150% (lana virgen) de su propio peso en agua, alterando su cinemática.',
      detailedMechanics: 'Al mojarse, la ropa se adhiere a las crestas óseas (omóplatos, clavículas, muslos), revelando la silueta interna y perdiendo capacidad aislante térmica. Los bajos de capas y faldas acumulan barro, que al secarse se torna rígido y quebradizo como costra arenosa. El cuero empapado se estira y oscurece, y al secarse al calor directo de una hoguera encoge y se agrieta.',
      sensoryManifestations: {
        visual: 'Bandas oscuras de saturación de agua subiendo por capilaridad en los dobladillos; tejido pegado a la piel con transparencia húmeda; costras terrosas en los puños.',
        auditory: 'Chasquido húmedo de telas empapadas fustigando las espinillas; goteo continuo desde las puntas de capas y mangas.',
        tactile: 'Pesantez asfixiante de ropa mojada que estira los hombros; frío que muerde la piel a través del paño empapado; aspereza arenosa del lodo seco.',
        olfactory: 'Olor animal y almizclado de lana húmeda; olor agrio a curtido vegetal y moho en cuero mojado.'
      },
      reasoningRules: [
        'Un personaje que ha cruzado un río o caminado bajo lluvia torrencial tiene un peso corporal efectivo de 4 a 10 kg superior debido al agua retenida en la ropa.',
        'El barro seco en las costuras y botas delata la procedencia geológica reciente de un viajero.'
      ],
      narrativeApplication: 'Usa el estado de la ropa para anclar el tiempo transcurrido y la aspereza del viaje sin necesidad de fechas explícitas.'
    }
  ],

  // -----------------------------------------------------------------------
  // 3. FÍSICA DINÁMICA Y FENOMENOLOGÍA
  // -----------------------------------------------------------------------
  physics: [
    {
      id: 'phys_lag_hysteresis',
      domain: 'physics',
      title: 'Efectos de Retardo (Lag de Inercia, Histéresis y Desfase Cinético)',
      keywords: ['lag', 'retardo', 'inercia', 'desfase', 'elasticidad', 'momento', 'balanceo', 'coletazo', 'frenado'],
      summary: 'Todo cuerpo flexible o suspendido posee histéresis e inercia: su movimiento sigue al origen con un retardo proporcional a su longitud y masa.',
      detailedMechanics: 'Cuando un guerrero gira sobre sus talones, la cabeza del cabello o la cola de la capa no giran al unísono: experimentan un retardo inercial (lag angular), alcanzando su máxima amplitud milisegundos después del frenado del torso, generando un latigazo o retroceso elástico. Igualmente, las vainas de espadas, bolsas de cinto y colgantes oscilan en contrafase respecto al paso.',
      sensoryManifestations: {
        visual: 'La capa que continúa hinchándose hacia adelante cuando el personaje ya se ha detenido en seco; el cabello que azota la mejilla tras el giro brusco; la funda que golpea el muslo medio segundo después del salto.',
        auditory: 'El golpe rítmico desfasado: paso en el suelo... y fracción de segundo después el tintineo de las hebillas rebotando.',
        tactile: 'El tirón diferido en el broche del cuello cuando el vuelo de la tela llega al tope de su cuerda inercial.'
      },
      reasoningRules: [
        'Los giros y frenadas bruscas siempre dejan un remanente visual de movimiento secundario (prendas, cabello, accesorios).',
        'Cualquier impacto no frena solo el punto de choque; desata ondas elásticas de vibración en las extremidades adyacentes.'
      ],
      narrativeApplication: 'Dota de dinamismo cinematográfico a las pausas: cuando alguien se detiene para hablar, sus ropajes y aliento aún tardan un instante en acomodarse a la quietud.'
    },
    {
      id: 'phys_ripple_concentric_waves',
      domain: 'physics',
      title: 'Efecto Ripple (Ondas Concéntricas, Resonancia y Propagación Perturbativa)',
      keywords: ['ripple', 'ondas', 'concentric', 'perturbacion', 'charco', 'vibracion', 'resonancia', 'reflejo', 'eco', 'impacto'],
      summary: 'Una perturbación puntual en medios fluidos o elásticos genera frentes de onda concéntricos que atenúan su amplitud inversamente al radio.',
      detailedMechanics: 'En líquidos (un vaso sobre la mesa, un charco en el suelo), la tensión superficial genera trenes de ondas capilares seguidas de ondas de gravedad. Al chocar contra las orillas o recipientes, las ondas rebotan interfiriendo constructiva y destructivamente, revelando vibraciones mecánicas lejanas (pisadas pesadas, maquinaria subterránea, trote de caballos) antes de que sean audibles.',
      sensoryManifestations: {
        visual: 'Anillos concéntricos perfectos deformando el reflejo del rostro en el agua; el vino en la copa temblando con estrías geométricas concéntricas con cada pisada en el corredor.',
        auditory: 'El eco amortiguado de ondas chocando en orillas subterráneas; el zumbido armónico de una vasija de bronce al entrar en resonancia con un grito o golpe.',
        tactile: 'La vibración que sube por la suela de las botas a través del piso de piedra o madera ante un derrumbe distante.'
      },
      reasoningRules: [
        'El efecto ripple en fluidos es un detector anticipado determinista de intrusos o colapsos estructurales en la sala.',
        'En un entorno en calma absoluta, una simple gota o roce desencadena perturbaciones que tardan segundos en extinguirse.'
      ],
      narrativeApplication: 'Utiliza el agua o el reflejo vibrante como presagio: antes de que la bestia o los guardias crucen la puerta, el líquido en su cuenco ya tiembla en círculos quebrados.'
    },
    {
      id: 'phys_thermodynamics_convection_sound',
      domain: 'physics',
      title: 'Termodinámica, Corrientes de Convección y Acústica Espacial',
      keywords: ['humo', 'calor', 'frio', 'aire', 'corriente', 'eco', 'acústica', 'fuego', 'ceniza', 'conveccion'],
      summary: 'El gradiente térmico produce corrientes ascendentes que arrastran partículas y modifican la velocidad del sonido en recintos cerrados.',
      detailedMechanics: 'El aire caliente asciende hacia las vigas o bóvedas, creando una capa de aire enrarecido y humo en el tercio superior de una estancia, mientras que a ras de suelo entra aire denso y frío por rendijas. El sonido viaja más rápido en aire caliente que en frío; en recintos de piedra fría con techos calientes, la refracción acústica desvía las voces hacia el suelo, haciendo que los susurros se escuchen con claridad inesperada a gran distancia.',
      sensoryManifestations: {
        visual: 'Ondulaciones de refracción óptica sobre braseros y chimeneas; columnas de polvo que flotan girando en los rayos de luz oblicuos; humo estratificado en bandas horizontales.',
        auditory: 'Crujidos de contracción térmica en vigas de madera al anochecer; eco nítido con retraso de 0.2s en salas abovedadas; siseo sutil del aire filtrándose bajo los portones.',
        tactile: 'Corriente gélida a la altura de los tobillos mientras el rostro siente el calor seco del fuego; sabor amargo a carbón en los labios.'
      },
      reasoningRules: [
        'El humo no se dispersa mágicamente: se acumula arriba forzando a los personajes a agacharse para respirar aire limpio.',
        'La acústica de una sala de piedra revela conversaciones que en un campo abierto quedarían disueltas.'
      ],
      narrativeApplication: 'Juega con las capas térmicas de la habitación: el frío que entra por la rendija de la puerta mientras las velas parpadean al compás de la corriente.'
    }
  ],

  // -----------------------------------------------------------------------
  // 4. CULTURA, PROTOCOLO Y ANTROPOLOGÍA
  // -----------------------------------------------------------------------
  culture: [
    {
      id: 'cult_proxemics_status_hierarchy',
      domain: 'culture',
      title: 'Proxémica Cultural, Espacio Personal y Estatus Jerárquico',
      keywords: ['proxemica', 'distancia', 'jerarquia', 'estatus', 'respeto', 'noble', 'plebeyo', 'saludo', 'reverencia'],
      summary: 'Las distancias de interacción comunican estatus: zona íntima (<0.5m), personal (0.5-1.2m), social (1.2-3.5m) y pública (>3.5m).',
      detailedMechanics: 'Invadir el espacio personal de un superior sin permiso es considerado afrenta o amenaza marcial. Los personajes de alto estatus ocupan más espacio físico con su postura, sus gestos son pausados y delegan la proximidad. La mirada directa y fija desafía; bajar la barbilla inclinando la nuca expone simbólicamente la yugular como señal de sumisión o pacto de paz.',
      sensoryManifestations: {
        visual: 'El paso hacia atrás discreto de un guardia al acercarse un noble; manos mantenidas a la vista sobre los cinturones; inclinaciones de cabeza graduadas por rango (leve cabeceo entre iguales, torsión de torso ante reyes).',
        auditory: 'Silencio respetuoso que precede a la intervención del líder; entonaciones moduladas sin estridencias.',
        tactile: 'El saludo de antebrazo con agarre firme que evalúa discretamente la fuerza y tensión del otro.'
      },
      reasoningRules: [
        'Un personaje que cruza abruptamente la barrera del metro de distancia fuerza al otro a reaccionar (retroceso, crispación de mano hacia el cinto o agresión).',
        'La etiqueta de entrega de armas a la entrada de un recinto determina si el anfitrión confía o subyuga a los visitantes.'
      ],
      narrativeApplication: 'Construye la tensión social en las distancias: no es necesario decir que alguien es amenazante si se detiene a solo dos cuartas del rostro del protagonista sin pestañear.'
    },
    {
      id: 'cult_hospitality_honor_taboos',
      domain: 'culture',
      title: 'Leyes de Hospitalidad, Juramentos y Tabúes de Sangre',
      keywords: ['hospitalidad', 'juramento', 'honor', 'tabu', 'pan y sal', 'traicion', 'acero', 'promesa'],
      summary: 'En sociedades tradicionales y de fantasía, compartir comida y techo establece un pacto inviolable amparado por deidades.',
      detailedMechanics: 'Aceptar pan, sal o agua de un anfitrión ata a ambas partes: el huésped no puede alzar la mano contra la casa y el anfitrión debe defender la vida del huésped. Desenfundar acero en la mesa es un sacrilegio. Los juramentos se sellan con elementos duraderos (hierro frío, sangre vertida en ceniza, fuego del hogar). Romper este pacto atrae deshonra colectiva y venganza de clan.',
      sensoryManifestations: {
        visual: 'El acto de partir el pan con las manos antes de servir carne; la mirada de advertencia de los ancianos cuando alguien roza el pomo de la espada bajo la mesa.',
        auditory: 'El rumor que cesa súbitamente si una copa se quiebra o una gota de sangre cae en la sal.',
        tactile: 'El calor del cuenco compartido pasando de mano en mano sellando el acuerdo tácito.'
      },
      reasoningRules: [
        'La violencia dentro de un espacio de hospitalidad declarada transforma el conflicto en una transgresión cósmica o religiosa, no una simple pelea.',
        'Las negociaciones más duras ocurren mientras se respetan formalidades escrupulosas de protocolo.'
      ],
      narrativeApplication: 'Usa los objetos cotidianos de la mesa como barómetros de tensión: el vino servido que nadie bebe, el cuchillo de carne clavado en la madera con demasiada fuerza.'
    }
  ],

  // -----------------------------------------------------------------------
  // 5. PSICOLOGÍA Y RAZONAMIENTO LÓGICO Y EMOCIONAL
  // -----------------------------------------------------------------------
  psychology: [
    {
      id: 'psych_dual_processing_theory_of_mind',
      domain: 'psychology',
      title: 'Procesamiento Dual y Teoría de la Mente (Atribución Cognitiva)',
      keywords: ['psicologia', 'razonamiento', 'teoria de la mente', 'intuicion', 'logica', 'sesgos', 'creencias', 'intencion'],
      summary: 'El razonamiento combina el Sistema 1 (heurístico, visceral, rápido) con el Sistema 2 (analítico, deliberativo, costoso en glucosa).',
      detailedMechanics: 'La Teoría de la Mente permite a un individuo atribuir estados mentales (deseos, engaños, conocimientos falsos) a otros. Un personaje perspicaz deduce: "Él sabe que yo vi el documento, pero finge ignorancia para ver si lo traiciono". La disonancia cognitiva surge cuando hechos innegables chocan con dogmas arraigados, provocando negación inicial, cólera y posterior reconstrucción racional.',
      sensoryManifestations: {
        visual: 'Parpadeo reflexivo al procesar una contradicción lógica; desviación de la mirada al espacio vacío mientras calcula probabilidades; postura que pasa de relajada a rígida al advertir una trampa retórica.',
        auditory: 'Pausa de tres segundos en el diálogo donde el personaje recalibra su argumento; titubeo en la primera sílaba de una mentira improvisada.'
      },
      reasoningRules: [
        'Bajo pánico o dolor, el Sistema 2 colapsa y prevalecen respuestas instintivas del Sistema 1 (huida, ataque primario, apego al objeto más cercano).',
        'Los personajes no son omniscientes: actúan sobre información incompleta y sus propios sesgos de confirmación.'
      ],
      narrativeApplication: 'Muestra el tren de pensamiento del personaje: cómo descarta una opción por arriesgada, nota la contradicción en el relato del otro y elige qué verdad callar.'
    },
    {
      id: 'psych_emotional_pad_spectrum',
      domain: 'psychology',
      title: 'Modelo Dimensional Emocional PAD (Placer, Activación, Dominancia)',
      keywords: ['emocion', 'valencia', 'arousal', 'dominancia', 'calma', 'ira', 'miedo', 'orgullo', 'humillacion'],
      summary: 'Toda emoción humana puede ubicarse en un espacio tridimensional: Valencia (P), Activación biológica (A) y Sentimiento de control/Dominancia (D).',
      detailedMechanics: 'La Ira es displacentera (-P), de altísima activación (+A) y alta dominancia (+D: empuja a cambiar el entorno por la fuerza). El Terror es (-P), (+A), pero baja dominancia (-D: parálisis o sumisión ante una fuerza ineludible). El Duelo es (-P), baja activación (-A) y baja dominancia (-D: pesadumbre, letargo cinético). El Orgullo es (+P), activación media (+A) y muy alta dominancia (+D).',
      sensoryManifestations: {
        visual: 'En alta dominancia: pecho ensanchado, barbilla en alto, movimientos lentos y calculados. En baja dominancia: hombros caídos, mirada evasiva, manos ocultas en mangas o bolsillos.',
        auditory: 'Voz con resonancia de pecho y tono grave (alta dominancia) vs tono agudo, vacilante o murmurado (baja dominancia).',
        tactile: 'Sensación de peso en el esternón (pena/duelo); calor concentrado en el rostro y puños (ira).'
      },
      reasoningRules: [
        'Un personaje humillado (-D) buscará recuperar dominancia (+D) mediante venganza diferida, agresión pasiva o despliegue verbal.',
        'La contradicción entre emoción interna y máscara externa se evidencia en micro-gestos y lapsus lingual.'
      ],
      narrativeApplication: 'Calibra los diálogos según la dominancia relativa: quién interrumpe a quién, quién formula las preguntas y quién se ve obligado a justificarse.'
    }
  ],

  // -----------------------------------------------------------------------
  // 6. ARQUITECTURA Y ESPACIALIDAD
  // -----------------------------------------------------------------------
  architecture: [
    {
      id: 'arch_masonry_vaults_mass',
      domain: 'architecture',
      title: 'Masa Constructiva, Estructuras Abovedadas y Cantería',
      keywords: ['arquitectura', 'piedra', 'boveda', 'muros', 'arcos', 'canteria', 'sillares', 'pilares', 'contrafuertes'],
      summary: 'La piedra trabaja exclusivamente a compresión; arcos y bóvedas canalizan cargas verticales hacia empujes laterales que requieren muros masivos.',
      detailedMechanics: 'Los sillares de cantería unidos con mortero de cal respiran humedad y mantienen inercia térmica (frescos en verano, fríos implacables en invierno). En bóvedas de cañón corrido, la voz resuena en graves; en bóvedas de crucería góticas con ojivas, el sonido asciende disolviéndose en altura. Las grietas diagonales indican asentamiento de cimientos o falla por peso excesivo en la clave del arco.',
      sensoryManifestations: {
        visual: 'Marcas de cincel en las caras de piedra; eflorescencias blanquecinas de salitre en juntas húmedas; la clave del arco con cuña destacada en el centro.',
        auditory: 'El chasquido metálico de las botas rebotando con eco hueco en las losas de la nave central; el crujido profundo de sillares asentándose con el frío de la noche.',
        tactile: 'La frialdad densa y porosa de la piedra al apoyar la palma; el polvo calcáreo fino que se adhiere a los dedos al rozar la pared.',
        olfactory: 'Olor mineral a cantera, humedad encerrada y cal viva apagada.'
      },
      reasoningRules: [
        'Un muro de sillería de dos varas de espesor aísla el sonido de combates lejanos, pero las chimeneas y conductos de ventilación actúan como teléfonos acústicos.',
        'Golpear un muro permite distinguir mampostería sólida (sonido seco y sordo) de dobles fondos o pasadizos ocultos (vibración hueca con reverberación).'
      ],
      narrativeApplication: 'Haz que el espacio participe en la escena: las sombras que se alargan bajo las arcadas, el peso físico de toneladas de piedra sobre sus cabezas.'
    },
    {
      id: 'arch_circulation_apertures_light',
      domain: 'architecture',
      title: 'Geometría Defensiva, Pasajes y Comportamiento de la Luz',
      keywords: ['escaleras', 'vanos', 'saeteras', 'puertas', 'claraboyas', 'defensivo', 'claroscuro', 'sombra', 'cerrojos'],
      summary: 'La arquitectura medieval y de fortalezas está diseñada con asimetría táctica: escaleras de caracol dextrógiras para ventaja del diestro que defiende desde arriba.',
      detailedMechanics: 'Las saeteras y vanos abocinados concentran la luz en haces estrechos mientras mantienen el interior en penumbra protectora. Los quicios de madera dura (roble, castaño) resisten empuje frontal pero son vulnerables al fuego o apalancamiento de goznes. Las puertas pesadas cuentan con trancas de barra de roble embutidas en cajeras de piedra en el propio muro.',
      sensoryManifestations: {
        visual: 'Un haz de luz oblicuo cargado de motas de polvo suspendidas cortando la oscuridad de la sala; el contorno negro del centinela recortado contra el vano exterior.',
        auditory: 'El bramido del cerrojo de hierro deslizándose en la cajera de piedra; el crujido rítmico en espiral al ascender por escalones gastados de caracol.',
        tactile: 'Hierro forjado áspero y con óxido en aldabas y cerrojos; madera aceitada y astillada por los años en portones.'
      },
      reasoningRules: [
        'Combatir en una escalera de caracol en descenso limita el arco de ataque con espada para quien sube, forzando estocadas frontales o uso de dagas.',
        'Pasar de la luz solar deslumbrante a una estancia de piedra en penumbra genera ceguera retiniana de adaptación durante al menos 15 a 30 segundos.'
      ],
      narrativeApplication: 'Usa los puntos ciegos de la arquitectura y la ceguera de adaptación lumínica para generar suspense antes de cualquier encuentro.'
    }
  ],

  // -----------------------------------------------------------------------
  // 7. GEOLOGÍA, EDAFOLOGÍA Y TOPOGRAFÍA
  // -----------------------------------------------------------------------
  geology: [
    {
      id: 'geo_soils_traction_lithology',
      domain: 'geology',
      title: 'Litología, Tipos de Suelo y Dinámica de Tracción',
      keywords: ['suelo', 'roca', 'barro', 'arcilla', 'granito', 'arena', 'grava', 'traccion', 'deslizamiento', 'pedriza'],
      summary: 'El sustrato geológico determina la velocidad de marcha, el desgaste del calzado y la estabilidad en combate o escape.',
      detailedMechanics: 'El granito húmedo ofrece buena tracción por su textura de cuarzo rugoso, pero las pizarras y esquistos se vuelven resbaladizos como hielo al orientar sus planos de foliación con el agua. La arcilla mojada se adhiere en suelas aumentando el peso del calzado y provocando cizallamiento plástico (pérdida súbita de tracción). Las pedrizas y canchales de talud inestable (>35°) colapsan con el peso de un cuerpo en avalancha de cantos angulares.',
      sensoryManifestations: {
        visual: 'Agujas brillantes de mica en la roca grisácea; huellas que se llenan de agua lodosa turbia en segundos; deslizamiento de guijarros ladera abajo advirtiendo una caída.',
        auditory: 'El castañeo cortante de la pizarra quebrándose bajo la bota; el chapoteo denso de la bota succionada por el lodo arcilloso.',
        tactile: 'El impacto áspero de la roca rugosa al raspar la piel; la inestabilidad traicionera del terreno que cede bajo el talón.'
      },
      reasoningRules: [
        'Correr a toda velocidad en pedriza o arcilla mojada implica alta probabilidad de esguince de tobillo o caída por cizalla del suelo.',
        'El tipo de roca circundante determina la disponibilidad de agua limpia (areniscas filtran agua potable; arcillas forman aguas estancadas parduzcas).'
      ],
      narrativeApplication: 'Describe cómo el suelo castiga las articulaciones del caminante: el dolor en los empeines tras horas en canchales o el esfuerzo de sacar la bota de la arcilla espesa.'
    },
    {
      id: 'geo_karst_caverns_groundwater',
      domain: 'geology',
      title: 'Morfología Kárstica, Cavernas y Dinámica de Aguas Subterráneas',
      keywords: ['cueva', 'caliza', 'estalactita', 'karst', 'abismo', 'filtracion', 'sima', 'agua subterranea', 'humedad'],
      summary: 'La disolución de rocas solubles (caliza, yeso) por ácido carbónico crea redes de simas, galerías subterráneas y bolsas de gas.',
      detailedMechanics: 'En cavernas kársticas, el goteo constante deposita calcita en estalactitas milimétricas por siglo. Las corrientes subterráneas erosionan los lechos creando falsos suelos que pueden colapsar. La humedad relativa roza el 100%, saturando el aire y dificultando la sudoración eficiente (enfriamiento hipotérmico rápido aun a temperaturas de 10°C). Las simas profundas acumulan dióxido de carbono y gases pesados a ras de suelo.',
      sensoryManifestations: {
        visual: 'Lustre perlado en formaciones de coladas calcáreas; vapores sutiles que surgen de simas insondables; el reflejo negro e inmóvil de lagos kársticos.',
        auditory: 'El goteo rítmico distante como un metrónomo milenario; el rumor sordo de ríos subterráneos que vibran a través de la roca.',
        tactile: 'Frialdad húmeda pegándose a la garganta con cada respiración; barro calcáreo blanquecino como pasta en las manos.',
        olfactory: 'Olor a piedra mojada, fósiles triturados y aire inmóvil que no ha visto el sol en eras.'
      },
      reasoningRules: [
        'En galerías subterráneas, una antorcha que empieza a chisporrotear con llama azul o menguante advierte asfixia por desplazamiento de oxígeno antes del desmayo.',
        'Un grito en una caverna kárstica no sólo resuena: puede desencadenar fracturas en espeleotemas frágiles o desprendimiento de lajas sueltas.'
      ],
      narrativeApplication: 'Evoca la opresión del mundo subterráneo: la certeza de que sobre sus cráneos pesan millones de toneladas de caliza inerte que el tiempo disuelve gota a gota.'
    }
  ],

  // -----------------------------------------------------------------------
  // 8. TONO NARRATIVO, FORMAS DE NARRAR Y LENGUAJE LITERARIO
  // -----------------------------------------------------------------------
  literature: [
    {
      id: 'lit_prose_prosody_rhythm',
      domain: 'literature',
      title: 'Prosodia, Cadencia Oracional y Variación de Ritmo Narrativo',
      keywords: ['ritmo', 'cadencia', 'prosa', 'oraciones cortas', 'sintaxis', 'percusivo', 'contemplativo', 'aliteracion'],
      summary: 'La estructura métrica y la longitud sintáctica orquestan directamente la frecuencia cardíaca y la atención del lector.',
      detailedMechanics: 'El combate y la tensión extrema se articulan mediante oraciones unimembres, asíndeton (omisión de conjunciones) y verbos de acción directa sin perífrasis ("Giró. El acero silbó. Golpe seco contra el escudo."). La contemplación, el misterio y el pensamiento filosófico requieren períodos oracionales amplios, subordinadas cadenciosas y pausas rítmicas con comas y punto y coma que imitan la respiración en reposo.',
      sensoryManifestations: {
        visual: 'Párrafos visualmente compactos con oraciones cortas durante el combate; bloques amplios y armónicos durante la introspección.',
        auditory: 'Aliteración consonántica dura (k, t, p) en la violencia; sibilancias suaves (s, f, l) en la penumbra o el silencio.'
      },
      reasoningRules: [
        'Nunca utilices oraciones largas y floridas en mitad de una emboscada con espadas desnudas.',
        'Nunca recurras a frases cortadas y telegráficas durante un banquete cortesano donde reinan las sutilezas y el protocolo.'
      ],
      narrativeApplication: 'Modula la música del texto: haz que el lector sienta el ahogo a través de cortes rápidos o la inmensidad del paisaje a través de cláusulas que fluyen sin prisa.'
    },
    {
      id: 'lit_sensory_synesthesia_subtext',
      domain: 'literature',
      title: 'Sinestesia Sensorial, Simbolismo y Gestión del Subtexto',
      keywords: ['sinestesia', 'subtexto', 'metafora', 'simbolismo', 'silencio', 'sensorial', 'mostrar no decir', 'literatura'],
      summary: 'La gran narrativa nunca enuncia conclusiones obvias ("estaba triste"): cruza sentidos y carga los silencios de significado.',
      detailedMechanics: 'La sinestesia une canales perceptivos distintos: "un silencio áspero", "la luz pesada del atardecer", "un frío con sabor a cobre". El subtexto opera cuando los personajes dialogan sobre el clima o un mapa, pero la tensión real radica en una traición latente o un amor reprimido. Lo que se calla pesa más que lo que se dice.',
      sensoryManifestations: {
        visual: 'El objeto intermedio: las manos que juegan con un cuchillo de mesa mientras se habla de alianzas políticas.',
        auditory: 'La frase que queda colgada en el aire antes del punto final; el silencio denso que nadie se atreve a romper.'
      },
      reasoningRules: [
        'Aplica siempre el principio de "mostrar, no decir" (show, don\'t tell): un temblor en la copa dice más que la palabra "nervioso".',
        'Cada metáfora debe anclarse en la realidad material del mundo que habitan (no metáforas industriales en un mundo medieval de barro y forja).'
      ],
      narrativeApplication: 'Crea dobles lecturas en cada conversación: el lector debe percibir el filo de la daga escondida debajo de cada cortesía formal.'
    }
  ]
};

// -------------------------------------------------------------------------
// MOTOR DE CONSULTA Y RAZONAMIENTO COGNITIVO DETERMINISTA LOCAL
// -------------------------------------------------------------------------

/**
 * Busca y extrae entradas de conocimiento relevantes usando búsqueda por palabras clave,
 * similitud de tokens y ponderación por dominio. (0ms, 100% offline).
 */
export function retrieveKnowledge(
  query: string,
  domainFilters?: KnowledgeDomain[]
): KnowledgeEntry[] {
  if (!query || !query.trim()) return [];

  const normalizedQuery = query.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const tokens = normalizedQuery
    .split(/[\s,.;:!?¿¡"()]+/g)
    .filter(t => t.length > 2);

  if (tokens.length === 0) return [];

  const targetDomains = domainFilters && domainFilters.length > 0
    ? domainFilters
    : (Object.keys(KNOWLEDGE_CORPUS) as KnowledgeDomain[]);

  const scoredEntries: { entry: KnowledgeEntry; score: number }[] = [];

  for (const domain of targetDomains) {
    const entries = KNOWLEDGE_CORPUS[domain] || [];
    for (const entry of entries) {
      let score = 0;

      // Coincidencia exacta o parcial en título
      const normalizedTitle = entry.title.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
      if (normalizedTitle.includes(normalizedQuery)) score += 30;

      // Coincidencia en keywords
      for (const kw of entry.keywords) {
        const normKw = kw.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
        for (const token of tokens) {
          if (normKw === token) {
            score += 15;
          } else if (normKw.includes(token) || token.includes(normKw)) {
            score += 7;
          }
        }
      }

      // Coincidencia en summary y detailedMechanics
      const fullText = (entry.summary + ' ' + entry.detailedMechanics).toLowerCase();
      for (const token of tokens) {
        if (fullText.includes(token)) {
          score += 2;
        }
      }

      if (score > 0) {
        scoredEntries.push({ entry, score });
      }
    }
  }

  scoredEntries.sort((a, b) => b.score - a.score);
  return scoredEntries.map(s => s.entry);
}

/**
 * Analiza una escena o acción en tiempo real extrayendo deducciones
 * físicas, somáticas, arquitectónicas y consejos prosódicos para la narración.
 */
export function analyzeSceneWithKnowledge(context: {
  text: string;
  placeName?: string;
  weather?: string;
  isCombatOrTension?: boolean;
}): KnowledgeReasoningResult {
  const query = `${context.text} ${context.placeName || ''} ${context.weather || ''}`;
  const relevantEntries = retrieveKnowledge(query);

  const matchedDomains = Array.from(new Set(relevantEntries.map(e => e.domain)));
  const inferredPhysicalEffects: string[] = [];
  const inferredSomaticResponses: string[] = [];
  const inferredEnvironmentalEchoes: string[] = [];

  for (const entry of relevantEntries.slice(0, 4)) {
    if (entry.domain === 'physics') {
      inferredPhysicalEffects.push(`${entry.title}: ${entry.reasoningRules[0] || entry.summary}`);
    } else if (entry.domain === 'anatomy' || entry.domain === 'psychology') {
      inferredSomaticResponses.push(`${entry.title}: ${entry.sensoryManifestations.visual || entry.summary}`);
    } else if (entry.domain === 'architecture' || entry.domain === 'geology' || entry.domain === 'clothing') {
      inferredEnvironmentalEchoes.push(`${entry.title}: ${entry.sensoryManifestations.auditory || entry.summary}`);
    }
  }

  // Detección de ritmo literario
  const textLower = context.text.toLowerCase();
  const isAction = context.isCombatOrTension ||
    /(corre|ataca|espada|salta|frena|golpe|dispara|grita|huye|sangre|fuego|desenvaina)/i.test(textLower);

  let pace: 'rapid_percussive' | 'contemplative_cadenced' | 'suspenseful_layered' = 'contemplative_cadenced';
  let suggestedSensoryFocus = 'Luz cenital, sombras en las paredes y peso del aire.';
  let narrativeDevice = 'Oraciones armónicas con cadencia pausada y descripción de texturas.';

  if (isAction) {
    pace = 'rapid_percussive';
    suggestedSensoryFocus = 'Inercia de la masa corporal, vibración del suelo (ripple) y sonido de impacto seco.';
    narrativeDevice = 'Oraciones cortas y percusivas, asíndeton y verbos dinámicos.';
  } else if (/(mira|observa|silencio|sombra|quien|sospecha|cerradura|oculto|oscuro|niebla)/i.test(textLower)) {
    pace = 'suspenseful_layered';
    suggestedSensoryFocus = 'Micro-gestos en los párpados, el crujido del cuero y la reverberación de las pisadas.';
    narrativeDevice = 'Subtexto velado: lo que no se dice, respiración suspendida y sinestesia.';
  }

  return {
    matchedDomains,
    relevantEntries: relevantEntries.slice(0, 5),
    inferredPhysicalEffects,
    inferredSomaticResponses,
    inferredEnvironmentalEchoes,
    literaryStyleAdvice: {
      pace,
      suggestedSensoryFocus,
      narrativeDevice
    }
  };
}

/**
 * Genera un bloque de anclaje ontológico formateado para inyectar en
 * cualquier prompt (online o local) asegurando consistencia física y literaria.
 */
export function formatKnowledgeForPrompt(query: string, maxEntries: number = 3): string {
  const entries = retrieveKnowledge(query).slice(0, maxEntries);
  if (entries.length === 0) return '';

  return `
### ANCLAJE ONTOLÓGICO Y FENOMENOLÓGICO LOCAL (LEYES MATERIALES ESTRICTAS):
${entries.map(e => `
- **${e.title.toUpperCase()}** (${e.domain}):
  * Mecánica: ${e.detailedMechanics}
  * Manifestación Sensorial: ${e.sensoryManifestations.visual} ${e.sensoryManifestations.auditory ? `| Acústica: ${e.sensoryManifestations.auditory}` : ''}
  * Regla Causal: ${e.reasoningRules.join(' ')}
`).join('\n')}
`.trim();
}
