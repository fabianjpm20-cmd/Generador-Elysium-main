// =========================================================================
// MOTOR DE MEMORIA COGNITIVA, ANÁLISIS DE DATOS & RAZONAMIENTO CONTINUO
// Proporciona a los personajes retención semántica a largo plazo para
// conversaciones extensas, extracción de hechos canónicos, seguimiento de
// acuerdos/promesas, preguntas abiertas y teoría de la mente relacional.
// =========================================================================

export interface CharacterPerspectiveInsight {
  perceivedAffinity: number;       // 0 a 100
  trustLevel: number;              // 0 a 100
  internalObservation: string;     // Observación psicológica sobre el interlocutor
  lastInnerMonologue?: string;     // Pensamiento íntimo más reciente
  detectedMotives?: string[];      // Qué cree este personaje que busca el otro
}

export interface EnhancedConversationMemory {
  turnCount: number;
  lastUpdated: string;
  summary: string;                           // Resumen narrativo global y condensado de la conversación
  keyFacts: string[];                        // Hechos inmutables y verdades fijadas en la memoria (nombres, lugares, secretos revelados)
  agreementsAndPromises: string[];           // Compromisos, juramentos o pactos contraídos entre personajes
  unresolvedQuestions: string[];             // Preguntas abiertas o dilemas que aún esperan respuesta
  activeTopics: string[];                    // Tópicos principales que vertebran la conversación
  characterPerspectives: Record<string, CharacterPerspectiveInsight>; // Comprensión psicológica cruzada (Teoría de la Mente)
  narrativeTone?: string;                    // Tono emocional y dramático predominante
}

export function createInitialConversationMemory(placeName?: string, worldName?: string): EnhancedConversationMemory {
  const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  return {
    turnCount: 0,
    lastUpdated: timestamp,
    summary: `Inicio del encuentro e intercambio en ${placeName || 'el recinto'}, bajo el marco de ${worldName || 'Elysium'}.`,
    keyFacts: [
      `Encuentro situado en ${placeName || 'el escenario actual'}.`,
      `Interacción regida por las condiciones del entorno y las personalidades canónicas presentes.`
    ],
    agreementsAndPromises: [],
    unresolvedQuestions: [
      '¿Cuál es el propósito inicial o la inquietud que guía esta conversación?'
    ],
    activeTopics: ['Presentación e intercambio inicial'],
    characterPerspectives: {},
    narrativeTone: 'Atento y reflexivo'
  };
}

/**
 * Combina y deduplica hechos, promesas y preguntas
 */
export function mergeMemoryUpdates(
  current: EnhancedConversationMemory | undefined,
  updates: Partial<EnhancedConversationMemory>
): EnhancedConversationMemory {
  const base = current || createInitialConversationMemory();
  const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  // Deduplicación limpia
  const dedupe = (arr?: string[]) => {
    const set = new Set<string>();
    const result: string[] = [];
    (arr || []).forEach(item => {
      const trimmed = item.trim();
      if (trimmed && !set.has(trimmed.toLowerCase())) {
        set.add(trimmed.toLowerCase());
        result.push(trimmed);
      }
    });
    return result;
  };

  const keyFacts = dedupe([...(base.keyFacts || []), ...(updates.keyFacts || [])]);
  const agreementsAndPromises = dedupe([...(base.agreementsAndPromises || []), ...(updates.agreementsAndPromises || [])]);
  const unresolvedQuestions = dedupe([...(base.unresolvedQuestions || []), ...(updates.unresolvedQuestions || [])]);
  const activeTopics = dedupe([...(base.activeTopics || []), ...(updates.activeTopics || [])]);

  // Si alguna pregunta abierta fue resuelta en los acuerdos o hechos, se puede retirar opcionalmente
  const cleanUnresolved = unresolvedQuestions.filter(q => {
    const qLower = q.toLowerCase();
    const isAnswered = agreementsAndPromises.some(a => a.toLowerCase().includes(qLower.slice(0, 20)));
    return !isAnswered;
  });

  return {
    turnCount: (base.turnCount || 0) + (updates.turnCount ? updates.turnCount : 1),
    lastUpdated: timestamp,
    summary: updates.summary && updates.summary.length > 20 ? updates.summary : base.summary,
    keyFacts: keyFacts.slice(-30), // Mantiene hasta 30 hechos clave esenciales
    agreementsAndPromises: agreementsAndPromises.slice(-20),
    unresolvedQuestions: (cleanUnresolved.length > 0 ? cleanUnresolved : unresolvedQuestions).slice(-15),
    activeTopics: activeTopics.slice(-10),
    characterPerspectives: {
      ...(base.characterPerspectives || {}),
      ...(updates.characterPerspectives || {})
    },
    narrativeTone: updates.narrativeTone || base.narrativeTone || 'Atento y reflexivo'
  };
}

/**
 * Analizador semántico y de datos offline para extracción continua de memoria
 * Se ejecuta automáticamente para garantizar que los personajes nunca pierdan el hilo
 */
export function extractMemoryInsightsOffline(params: {
  dialogueHistory: Array<{ speaker: string; speakerName: string; text: string; timestamp?: string }>;
  existingMemory?: EnhancedConversationMemory;
  placeName?: string;
  protagonistName?: string;
}): EnhancedConversationMemory {
  const { dialogueHistory, existingMemory, placeName, protagonistName = 'Protagonista' } = params;
  const currentMem = existingMemory || createInitialConversationMemory(placeName);

  if (!dialogueHistory || dialogueHistory.length === 0) {
    return currentMem;
  }

  const recentMessages = dialogueHistory.slice(-10);
  const newFacts: string[] = [];
  const newAgreements: string[] = [];
  const newQuestions: string[] = [];
  const detectedTopics: string[] = [];

  // Expresiones regulares para detección semántica en español
  const agreementRegex = /\b(prometo|te aseguro|pacto|de acuerdo|cuenta con ello|trato hecho|lo haré|me comprometo|juro|así será|coincido|acepto tu propuesta)\b/i;
  const questionRegex = /\b(¿|\?|por qué|cómo|adónde|dónde|cuándo|qué opinas|cuál es|qué sabes|acaso)\b/i;
  const factRegex = /\b(mi nombre es|soy|vengo de|mi pasado|oculto|la verdad es|revelar|pertenezco a|mi hogar|mi orden|mi familia|el artefacto|la reliquia)\b/i;

  recentMessages.forEach(msg => {
    const text = msg.text;
    const speaker = msg.speakerName || msg.speaker;

    // Detectar acuerdos y compromisos
    if (agreementRegex.test(text)) {
      const excerpt = text.length > 120 ? `${text.slice(0, 115)}...` : text;
      newAgreements.push(`[Compromiso] ${speaker}: "${excerpt}"`);
    }

    // Detectar hechos revelados
    if (factRegex.test(text)) {
      const excerpt = text.length > 130 ? `${text.slice(0, 125)}...` : text;
      newFacts.push(`[Revelación] ${speaker} señaló: "${excerpt}"`);
    }

    // Detectar preguntas o hilos abiertos
    if (questionRegex.test(text)) {
      // Extraer la oración que contiene el interrogante
      const sentences = text.split(/[.!]+/).filter(s => questionRegex.test(s));
      sentences.forEach(sentence => {
        const cleanS = sentence.trim();
        if (cleanS.length > 12) {
          newQuestions.push(`${speaker} preguntó: "${cleanS}"`);
        }
      });
    }

    // Extraer temas temáticos
    if (/magia|hechizo|arcano|pneuma|energía/i.test(text)) detectedTopics.push('Corrientes arcanas y magia');
    if (/peligro|enemigo|guardia|defensa|arma|combate/i.test(text)) detectedTopics.push('Vigilancia táctica y seguridad');
    if (/viaje|camino|destino|mapa|rumbo/i.test(text)) detectedTopics.push('Expedición y travesía');
    if (/pasado|origen|infancia|tierra natal|linaje/i.test(text)) detectedTopics.push('Orígenes e historia personal');
    if (/política|consejo|noble|ley|orden|pacto/i.test(text)) detectedTopics.push('Política y diplomacia');
  });

  // Sintetizar resumen progresivo del hilo
  const totalTurns = dialogueHistory.length;
  const firstSpeaker = dialogueHistory[0]?.speakerName || 'El grupo';
  const lastSpeaker = dialogueHistory[dialogueHistory.length - 1]?.speakerName || 'El grupo';

  let summary = currentMem.summary;
  if (totalTurns > 4) {
    summary = `Conversación en ${placeName || 'el recinto'} entre ${protagonistName} y sus acompañantes (${totalTurns} intervenciones registradas). El diálogo ha transitado por temas de ${detectedTopics.slice(0, 3).join(', ') || 'reflexión compartida y exploración mutua'}, manteniendo el hilo vivo y la coherencia en torno a los objetivos inmediatos.`;
  }

  return mergeMemoryUpdates(currentMem, {
    turnCount: totalTurns,
    summary,
    keyFacts: newFacts,
    agreementsAndPromises: newAgreements,
    unresolvedQuestions: newQuestions,
    activeTopics: detectedTopics
  });
}

/**
 * Formatea el bloque de memoria para ser inyectado en los prompts de IA en server.ts
 * Esto asegura que el personaje SIEMPRE tenga presentes los hechos históricos y acuerdos
 * independientemente de lo larga que sea la tertulia.
 */
export function formatConversationMemoryForPrompt(memory?: EnhancedConversationMemory): string {
  if (!memory) return '';

  const sections: string[] = [];

  if (memory.summary && memory.summary.trim()) {
    sections.push(`• RESUMEN NARRATIVO ACUMULADO:\n  ${memory.summary.trim()}`);
  }

  if (memory.keyFacts && memory.keyFacts.length > 0) {
    sections.push(`• HECHOS INMUTABLES Y CONOCIMIENTOS ESTABLECIDOS:\n${memory.keyFacts.slice(-12).map(f => `  - ${f}`).join('\n')}`);
  }

  if (memory.agreementsAndPromises && memory.agreementsAndPromises.length > 0) {
    sections.push(`• PACTOS, ACUERDOS Y PROMESAS VIGENTES (NO OLVIDAR):\n${memory.agreementsAndPromises.slice(-8).map(a => `  ✓ ${a}`).join('\n')}`);
  }

  if (memory.unresolvedQuestions && memory.unresolvedQuestions.length > 0) {
    sections.push(`• HILOS Y PREGUNTAS ABIERTAS POR RESPONDER:\n${memory.unresolvedQuestions.slice(-6).map(q => `  ? ${q}`).join('\n')}`);
  }

  if (memory.activeTopics && memory.activeTopics.length > 0) {
    sections.push(`• TEMAS PRINCIPALES DEL DIÁLOGO:\n  ${memory.activeTopics.slice(-5).join(' · ')}`);
  }

  if (sections.length === 0) return '';

  return `
============================================================
MEMORIA COGNITIVA EPISÓDICA A LARGO PLAZO & CONTINUIDAD:
(Retén estos datos firmemente para no perder jamás el hilo de la charla)
============================================================
${sections.join('\n\n')}
`;
}
