import { CharacterState } from '../types';
import { cleanVal } from './characterPromptUtils';
import { buildCharacterConsciousnessProfile } from './characterConsciousnessEngine';

// ----------------------------------------------------
// SISTEMA UNIFICADO DE PERSONAJE & PARTICIPANTE (MÓDULO 1 & MÓDULO 2)
// Unifica el Perfil Psicológico & Alineación del Agente,
// las Estadísticas de Combate por Turnos, y los Atributos D&D/Pneuma.
// ----------------------------------------------------

export interface UnifiedParticipant {
  id?: string;
  characterStateId?: string; // ID del personaje en la Biblioteca si procede
  name: string;
  title: string;
  role: string;
  subRole?: string;
  race: string;
  subtype?: string;
  gender?: string;
  faction?: string;
  avatarImageUrl?: string;

  // 1. PERFIL PSICOLÓGICO & ALINEACIÓN DEL AGENTE (MÓDULO 1 ESTADO 5 Y 7)
  moralAlignment: string; // 'Devoto Protector' | 'Leal Bondadoso' | 'Neutral Bondadoso' | 'Neutral' | 'Neutral Ambicioso' | 'Curioso' | 'Hedonismo' | 'Rebelde' | 'Caótico'
  allegianceFactionId?: string;
  greatestFear: string; // Mayor Miedo / Vulnerabilidad Fatal / Talón de Aquiles
  motivations: string[]; // Motivaciones & Impulsos Clave
  coreValues: string; // Valores Centrales & Principios
  interactionRole: string; // Rol en la interacción / arquetipo conductual
  personality: string;
  personalityTraits?: string[];
  habitsAndMannerisms?: string[];
  specificInteractions?: {
    withAuthority?: string;
    withPeers?: string;
    withFriends?: string;
    withSubordinates?: string;
    withStrangers?: string;
    withEnemies?: string;
  };

  // 2. ESTADÍSTICAS DE COMBATE POR TURNOS (MÓDULO 1 ESTADO 4 Y 7)
  hp: number;
  maxHp: number;
  sp: number;
  maxSp: number;
  attack: number;
  defense: number;
  agility: number;
  specialSkillName: string;
  specialSkillDescription: string;
  skills: string[]; // Habilidades activas & talentos marciales/místicos
  armorDescription?: string; // Tipo de armadura y acabado
  weapons?: string[]; // Armas empuñadas
  inventory: string[]; // Objetos e inventario de campaña

  // 3. ATRIBUTOS PRINCIPALES D&D & ENERGÍA PNEUMA (RESOLUCIÓN & PROGRESIÓN)
  attributes: {
    FUE: number;
    DES: number;
    CON: number;
    INT: number;
    SAB: number;
    CAR: number;
  };
  derived: {
    PV: number;
    maxPV: number;
    PEP: number;
    maxPEP: number;
    CA: number;
    iniciativa: number;
    velocidad: number;
    CEP: number;
    EFC: number;
    RR: number;
    XP: number;
    nivel?: number;
    proficiencia?: number;
  };

  // 4. ESTADO VINCULAR & DE INTERACCIÓN ACTIVA
  confidence: number;
  affinity: number;
  resistance: number;
  arousal: number;
  emotionalState: string;
  dialogueExcerpt?: string;
  isHostile?: boolean;

  // 5. CONCIENCIA SOMÁTICA, VESTIMENTA & AUTONOMÍA
  somaticAwareness?: string;
  wardrobeAwareness?: string;
  alternateVersionsAwareness?: string;
  aiTrainingDirectives?: string[];
  autonomyLevel?: number;
}

// ----------------------------------------------------
// CÁLCULO DE MODIFICADORES MATEMÁTICOS D&D (1 - 20)
// ----------------------------------------------------
export function calculateAttributeModifier(val: number): number {
  return Math.floor((val - 10) / 2);
}

// ----------------------------------------------------
// BONOS RACIALES Y DE ROL PARA PARÁMETROS DERIVADOS
// ----------------------------------------------------
const RACIAL_BONUSES: Record<string, { PV: number; CEP: number; EFC: number; CA: number; Vel: number; RR: number }> = {
  Humano: { PV: 20, CEP: 10, EFC: 5, CA: 0, Vel: 30, RR: 10 },
  Elfo: { PV: 10, CEP: 25, EFC: 15, CA: 1, Vel: 35, RR: 15 },
  Enano: { PV: 40, CEP: 5, EFC: 0, CA: 2, Vel: 25, RR: 20 },
  Orco: { PV: 35, CEP: 5, EFC: 0, CA: 1, Vel: 30, RR: 15 },
  Tiefling: { PV: 15, CEP: 20, EFC: 10, CA: 0, Vel: 30, RR: 15 },
  Dracónido: { PV: 30, CEP: 15, EFC: 5, CA: 2, Vel: 30, RR: 15 },
  Celestial: { PV: 25, CEP: 30, EFC: 20, CA: 2, Vel: 35, RR: 25 }
};

const ROLE_BONUSES: Record<string, { PV: number; CEP: number; EFC: number; CA: number; Ini: number; Vel: number; RR: number }> = {
  Guerrero: { PV: 40, CEP: 0, EFC: 0, CA: 2, Ini: 1, Vel: 0, RR: 10 },
  Caballero: { PV: 45, CEP: 5, EFC: 0, CA: 3, Ini: 0, Vel: -5, RR: 15 },
  Paladín: { PV: 35, CEP: 15, EFC: 10, CA: 2, Ini: 0, Vel: 0, RR: 15 },
  Mago: { PV: 0, CEP: 35, EFC: 25, CA: 0, Ini: 2, Vel: 0, RR: 20 },
  Hechicero: { PV: 5, CEP: 30, EFC: 20, CA: 0, Ini: 1, Vel: 0, RR: 15 },
  Pícaro: { PV: 15, CEP: 5, EFC: 5, CA: 1, Ini: 4, Vel: 5, RR: 5 },
  Asesino: { PV: 10, CEP: 10, EFC: 10, CA: 1, Ini: 5, Vel: 5, RR: 5 },
  Estratega: { PV: 20, CEP: 20, EFC: 15, CA: 1, Ini: 3, Vel: 0, RR: 15 },
  Explorador: { PV: 25, CEP: 10, EFC: 5, CA: 1, Ini: 2, Vel: 5, RR: 10 }
};

export function calculateUnifiedDerivedStats(
  attributes: { FUE: number; DES: number; CON: number; INT: number; SAB: number; CAR: number },
  raceName: string = 'Humano',
  roleName: string = 'Estratega'
) {
  const bonosRaza = RACIAL_BONUSES[raceName] || RACIAL_BONUSES['Humano'];
  const matchedRoleKey = Object.keys(ROLE_BONUSES).find(k => roleName.toLowerCase().includes(k.toLowerCase())) || 'Estratega';
  const bonosRol = ROLE_BONUSES[matchedRoleKey] || ROLE_BONUSES['Estratega'];

  const pv = (attributes.CON * 10) + (attributes.FUE * 2) + bonosRaza.PV + bonosRol.PV;
  const cep = bonosRaza.CEP + bonosRol.CEP;
  const efc = bonosRaza.EFC + bonosRol.EFC;
  const pep = Math.max(5, Math.round(cep * (efc / 100)));
  const ca = 10 + Math.floor(attributes.DES / 2) + bonosRaza.CA + bonosRol.CA;
  const ini = attributes.DES + bonosRol.Ini;
  const vel = bonosRaza.Vel + bonosRol.Vel;
  const rr = bonosRaza.RR + bonosRol.RR;

  return {
    PV: pv,
    maxPV: pv,
    PEP: pep,
    maxPEP: pep,
    CA: ca,
    iniciativa: ini,
    velocidad: vel,
    CEP: cep,
    EFC: efc,
    RR: rr,
    XP: 250,
    nivel: 1,
    proficiencia: 2
  };
}

// ----------------------------------------------------
// SINERGIA DE ALINEACIÓN MORAL AUTOMÁTICA
// ----------------------------------------------------
export function deduceMoralAlignment(coreValues: string, role: string): string {
  const coreValuesArray = coreValues.split(',').map(s => s.trim().toLowerCase()).filter(Boolean);

  for (const val of coreValuesArray) {
    if (/deber|devoción|fe|destino|legado|protección/i.test(val)) return 'Devoto Protector';
    if (/honor|justicia|verdad|redención|protección del débil|lealtad/i.test(val)) return 'Leal Bondadoso';
    if (/armonía|orden|bondad/i.test(val)) return 'Neutral Bondadoso';
    if (/supervivencia|equilibrio/i.test(val)) return 'Neutral';
    if (/dominación|poder|ambición|riqueza/i.test(val)) return 'Neutral Ambicioso';
    if (/conocimiento|curioso|estudio|investigación/i.test(val)) return 'Curioso';
    if (/placer|hedonismo|seducción|goce/i.test(val)) return 'Hedonismo';
    if (/libertad|independencia|rebelión/i.test(val)) return 'Rebelde';
    if (/venganza|caos|nihilismo|destrucción/i.test(val)) return 'Caótico';
  }

  if (/asesino|espía|pícaro|mercenario/i.test(role)) return 'Neutral Ambicioso';
  if (/mago|sabio|erudito|investigador/i.test(role)) return 'Curioso';
  if (/rebelde|errante/i.test(role)) return 'Rebelde';
  if (/paladín|caballero|guardián/i.test(role)) return 'Leal Bondadoso';
  return 'Devoto Protector';
}

// ----------------------------------------------------
// CONVERSIÓN PURA: CharacterState (MÓDULO 1) -> UnifiedParticipant (MÓDULO 2)
// Garantiza que la Ficha del Usuario y la Ficha de los Personajes
// provengan del mismo sistema unificado.
// ----------------------------------------------------
export function characterStateToUnifiedParticipant(
  char: CharacterState,
  defaultRoleTitle: string = 'Ficha del Usuario'
): UnifiedParticipant {
  const name = char.identity?.fullName || char.name || 'Sin Nombre';
  const nobleTitle = char.nobleTitle ? `${char.nobleTitle} ${char.nobleHouseOrDomain || ''}`.trim() : '';
  const title = nobleTitle || char.identity?.epithetOrTitle || defaultRoleTitle;
  const role = char.role || 'Estratega';
  const subRole = char.subRole;
  const race = char.raceName || 'Humano';
  const subtype = char.subtypeName || char.subtype;
  const gender = char.identity?.gender || char.anatomy?.sexBase || 'Femenino';
  const faction = char.background?.factionOrFaith || char.liteAgent?.allegianceFactionId || '';
  const avatarImageUrl = char.avatarImageUrl;

  // Atributos base D&D
  const attributes = char.attributes || {
    FUE: 16,
    DES: 14,
    CON: 14,
    INT: 14,
    SAB: 12,
    CAR: 14
  };

  // 1. Perfil Psicológico & Alineación del Agente
  const coreValues = char.background?.coreValues || 'Deber, Lealtad y Disciplina';
  const moralAlignment = char.liteAgent?.moralAlignment || deduceMoralAlignment(coreValues, role);
  const resolvedFlaw = (Array.isArray(char.background?.fatalFlaws) && char.background.fatalFlaws.length > 0)
    ? char.background.fatalFlaws.join(' | ')
    : char.background?.fatalFlawOrVulnerability;
  const greatestFear = char.liteAgent?.greatestFear || resolvedFlaw || 'La traición y la pérdida de control';
  
  let motivations = char.liteAgent?.motivations || [];
  if (!motivations || motivations.length === 0) {
    if (char.background?.motivation) {
      motivations = [char.background.motivation];
    } else {
      motivations = [`Cumplir el deber como ${role}`, 'Proteger a sus aliados'];
    }
  }

  const personality = char.personality || 'Refinado, analítico y cauto';
  const personalityTraits = char.personalityTraits || [];
  const habitsAndMannerisms = char.background?.advancedCustomization?.habitsAndMannerisms || [];
  const specificInteractions = char.background?.advancedCustomization?.specificInteractions;
  const interactionRole = char.liteAgent?.interactionRole || role;

  // 2. Estadísticas de Combate por Turnos
  const bgSkills = [
    ...(char.background?.advancedCustomization?.skills || [])
  ];
  const firstSkill = char.liteAgent?.combatStats?.specialSkillName || bgSkills[0] || 'Danza del Velo Celestial';
  const skillDesc = char.liteAgent?.combatStats?.specialSkillDescription || 'Canaliza pneuma para desplegar una técnica de alta precisión táctica.';

  const derivedBase = char.derivedStats || calculateUnifiedDerivedStats(attributes, race, role);
  const derived = {
    ...derivedBase,
    maxPV: derivedBase.maxPV ?? derivedBase.PV,
    maxPEP: derivedBase.maxPEP ?? derivedBase.PEP
  };

  // Default combat values tailored to role
  let defHp = derived.PV || 120;
  let defSp = derived.PEP ? derived.PEP * 10 : 80;
  let defAtk = 28;
  let defDef = 22;
  let defAgi = 28;

  if (/guerrer|cabal|paladín|mercenario|tanque/i.test(role)) {
    defHp = Math.max(defHp, 150); defDef = 35; defAtk = 32; defAgi = 20;
  } else if (/mago|hechicero|sabio|sacerdot|bruj/i.test(role)) {
    defSp = Math.max(defSp, 120); defAtk = 36; defDef = 16; defAgi = 30;
  } else if (/asesino|espía|pícaro|cazador/i.test(role)) {
    defAtk = 40; defDef = 18; defAgi = 45;
  }

  const combatStats = char.liteAgent?.combatStats;
  const maxHp = combatStats?.maxHp || defHp;
  const currentHp = combatStats?.currentHp ?? maxHp;
  const maxSp = combatStats?.maxSp || defSp;
  const currentSp = combatStats?.currentSp ?? maxSp;
  const attack = combatStats?.attack || defAtk;
  const defense = combatStats?.defense || defDef;
  const agility = combatStats?.agility || defAgi;

  const armorDesc = char.armor?.type
    ? `${char.armor.type}${char.armor.material ? ` (${char.armor.material})` : ''}`
    : 'Indumentaria ligera y refinada';

  const weapons = (char.equipment?.weapons && char.equipment.weapons.length > 0)
    ? char.equipment.weapons
    : ['Hoja de acero templado'];

  const inventory = (char.equipment?.items && char.equipment.items.length > 0)
    ? char.equipment.items
    : ['Poción de Vigor', 'Bálsamo Alquímico', 'Mapa del Territorio'];

  // 4. Estado de Interacción
  const confidence = char.interactionStats?.trust ?? 65;
  const affinity = char.interactionStats?.affection ?? 75;
  const resistance = char.interactionStats?.resistance ?? 20;
  const arousal = char.interactionStats?.arousal ?? 10;
  const emotionalState = char.interactionStats?.mood || 'Complacido';
  const dialogueExcerpt = char.background?.motivation
    ? `«Mi propósito es claro: ${char.background.motivation}»`
    : '«Parece que nuestros caminos se cruzan en este lugar.»';

  return {
    id: char.id,
    characterStateId: char.id,
    name,
    title,
    role,
    subRole,
    race,
    subtype,
    gender,
    faction,
    avatarImageUrl,

    // 1. Perfil Psicológico & Alineación
    moralAlignment,
    allegianceFactionId: char.liteAgent?.allegianceFactionId || faction,
    greatestFear,
    motivations,
    coreValues,
    interactionRole,
    personality,
    personalityTraits,
    habitsAndMannerisms,
    specificInteractions,

    // 2. Combate por Turnos
    hp: currentHp,
    maxHp,
    sp: currentSp,
    maxSp,
    attack,
    defense,
    agility,
    specialSkillName: firstSkill,
    specialSkillDescription: skillDesc,
    skills: bgSkills.length > 0 ? bgSkills : ['Tajo Espejado', 'Evaluación Táctica', 'Foco Inquebrantable'],
    armorDescription: armorDesc,
    weapons,
    inventory,

    // 3. Atributos D&D & Pneuma
    attributes,
    derived,

    // 4. Interacción
    confidence,
    affinity,
    resistance,
    arousal,
    emotionalState,
    dialogueExcerpt,
    isHostile: false,

    // 5. Conciencia Somática, Vestimenta, Versiones Alternas & Autonomía
    somaticAwareness: (() => {
      const c = buildCharacterConsciousnessProfile(char);
      const parts = [
        c.somatic.heightAndBuild,
        c.somatic.skinAndMarks,
        c.somatic.eyesAndLook,
        c.somatic.hairStyle,
        c.somatic.facialAndVoice,
        c.somatic.appendices,
        c.somatic.intimateDetails,
        c.somatic.tactileBodyState
      ].filter(Boolean);
      return parts.join('. ');
    })(),
    wardrobeAwareness: (() => {
      const c = buildCharacterConsciousnessProfile(char);
      const garments = c.wardrobe.garmentsList.map(g => `${g.name} (${g.layer || 'capa'}: ${g.fabrics || 'telas'}, ${g.colors || 'color'})`).join(', ');
      const parts = [
        `Atuendo: ${c.wardrobe.summary}`,
        garments ? `Prendas: ${garments}` : '',
        c.wardrobe.shoesAndFootwear ? `Calzado: ${c.wardrobe.shoesAndFootwear}` : '',
        c.wardrobe.jewelryAndRelics ? `Accesorios y joyas: ${c.wardrobe.jewelryAndRelics}` : '',
        c.wardrobe.armorAndProtection ? `Protección: ${c.wardrobe.armorAndProtection}` : '',
        c.wardrobe.tactileSensation ? `Sensación física de las telas: ${c.wardrobe.tactileSensation}` : ''
      ].filter(Boolean);
      return parts.join('. ');
    })(),
    alternateVersionsAwareness: (() => {
      const c = buildCharacterConsciousnessProfile(char);
      return `${c.alternateVersions.alternateRoleWardrobeSummary} ${c.alternateVersions.philosophicalView}`;
    })(),
    aiTrainingDirectives: (() => {
      const c = buildCharacterConsciousnessProfile(char);
      return c.trainingConfig.trainingDirectives;
    })(),
    autonomyLevel: char.aiTraining?.autonomyLevel ?? 75
  };
}

// ----------------------------------------------------
// SINCRONIZACIÓN INVERSA: UnifiedParticipant -> CharacterState
// Guarda de vuelta los avances de XP, cambios de atributos y combate
// directamente en la ficha canónica del Módulo 1.
// ----------------------------------------------------
export function syncParticipantToCharacterState(
  participant: UnifiedParticipant,
  baseState: CharacterState
): CharacterState {
  const validMoods = ['Neutral', 'Complacido', 'Sonrojado', 'Avergonzado', 'Enfadado', 'Excitado', 'Sumiso'] as const;
  const moodValue = (validMoods as readonly string[]).includes(participant.emotionalState)
    ? (participant.emotionalState as any)
    : 'Complacido';

  return {
    ...baseState,
    attributes: { ...participant.attributes },
    derivedStats: {
      ...baseState.derivedStats,
      PV: participant.derived.PV,
      maxPV: participant.derived.maxPV,
      PEP: participant.derived.PEP,
      maxPEP: participant.derived.maxPEP,
      CA: participant.derived.CA,
      iniciativa: participant.derived.iniciativa,
      velocidad: participant.derived.velocidad,
      CEP: participant.derived.CEP,
      EFC: participant.derived.EFC,
      RR: participant.derived.RR,
      XP: participant.derived.XP,
      nivel: participant.derived.nivel || 1,
      proficiencia: baseState.derivedStats?.proficiencia || 2,
      habilidades: baseState.derivedStats?.habilidades || [...participant.skills],
      hechizos: baseState.derivedStats?.hechizos || []
    },
    liteAgent: {
      isLiteAgent: true,
      moralAlignment: participant.moralAlignment as any,
      allegianceFactionId: participant.allegianceFactionId,
      greatestFear: participant.greatestFear,
      motivations: [...participant.motivations],
      interactionRole: participant.interactionRole,
      combatStats: {
        maxHp: participant.maxHp,
        currentHp: participant.hp,
        maxSp: participant.maxSp,
        currentSp: participant.sp,
        attack: participant.attack,
        defense: participant.defense,
        agility: participant.agility,
        specialSkillName: participant.specialSkillName,
        specialSkillDescription: participant.specialSkillDescription
      }
    },
    background: {
      ...baseState.background,
      coreValues: participant.coreValues,
      fatalFlawOrVulnerability: participant.greatestFear,
      advancedCustomization: {
        ...baseState.background?.advancedCustomization,
        voiceTone: baseState.background?.advancedCustomization?.voiceTone || 'Serena y firme',
        speechStyle: baseState.background?.advancedCustomization?.speechStyle || 'Formal y comedido',
        skills: [...participant.skills],
        habitsAndMannerisms: baseState.background?.advancedCustomization?.habitsAndMannerisms || [],
        specificInteractions: {
          withAuthority: participant.specificInteractions?.withAuthority || 'Respeto formal y deferencia cauta',
          withSubordinates: participant.specificInteractions?.withSubordinates || 'Instrucción paciente y exigencia justa',
          withPeers: participant.specificInteractions?.withPeers || 'Camaradería sobria',
          withFriends: participant.specificInteractions?.withFriends || 'Confianza franca',
          withStrangers: participant.specificInteractions?.withStrangers || 'Cortesía distante',
          withEnemies: participant.specificInteractions?.withEnemies || 'Alerta implacable'
        }
      }
    },
    interactionStats: {
      trust: participant.confidence,
      affection: participant.affinity,
      resistance: participant.resistance,
      arousal: participant.arousal,
      mood: moodValue,
      undressedLayers: baseState.interactionStats?.undressedLayers || [],
      interactionLog: baseState.interactionStats?.interactionLog || []
    }
  };
}
