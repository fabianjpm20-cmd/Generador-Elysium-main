import { useState, useEffect, useCallback, useRef } from 'react';
import {
  CharacterState,
  SavedCharacterEntry,
  WorldPlace,
  WorldBuildingConfig,
  GarmentConfig
} from '../types';
import {
  getSavedCharacters,
  saveCharacterToLibrary,
  updateCharacterInLibrary,
  deleteCharacterFromLibrary,
  duplicateCharacterInLibrary,
  getSavedCharacterById,
  createDefaultCharacterState,
  LIBRARY_STORAGE_KEY
} from '../utils/libraryStorage';
import {
  getSavedPlaces,
  savePlace,
  deletePlace,
  getWorldBuildingConfig,
  saveWorldBuildingConfig,
  PLACES_STORAGE_KEY,
  WORLDBUILDING_STORAGE_KEY
} from '../utils/worldStorage';
import {
  calculateUnifiedDerivedStats,
  deduceMoralAlignment,
  characterStateToUnifiedParticipant,
  syncParticipantToCharacterState,
  UnifiedParticipant
} from '../utils/characterLogicEngine';
import type { InteractionSessionState } from '../utils/interactionLogicEngine';

// ---------------------------------------------------------------------
// CONSTANTES DE ALMACENAMIENTO & EVENTOS DE SINCRONIZACIÓN REACTIVA
// ---------------------------------------------------------------------
export const CANONICAL_MODULO_SYNC_EVENT = 'elysium:modulo-sync';
export const ACTIVE_CHARACTER_STORAGE_KEY = 'ELYSIUM_ACTIVE_CHARACTER_CANONICAL_V1';
export const PROTAGONIST_STORAGE_KEY = 'ELYSIUM_PROTAGONIST_CANONICAL_V1';
export const ACTIVE_SESSION_STORAGE_KEY = 'ELYSIUM_ACTIVE_SESSION_CANONICAL_V1';
export const ACTIVE_PLACE_STORAGE_KEY = 'ELYSIUM_ACTIVE_PLACE_CANONICAL_V1';

export type ModuloSource = 'creation' | 'library' | 'interaction' | 'modal' | 'system';

export interface ModuloSyncPayload {
  source: ModuloSource;
  action:
    | 'update_character'
    | 'update_protagonist'
    | 'delete_character'
    | 'update_place'
    | 'update_world'
    | 'update_session'
    | 'reload_all';
  character?: CharacterState;
  characterId?: string;
  protagonist?: CharacterState | null;
  place?: WorldPlace;
  worldConfig?: WorldBuildingConfig;
  session?: InteractionSessionState | null;
  timestamp: number;
}

// ---------------------------------------------------------------------
// BROADCASTER GLOBAL UNIFORME
// ---------------------------------------------------------------------
let isInternalBroadcasting = false;

export function emitModuloSync(payload: ModuloSyncPayload): void {
  if (typeof window === 'undefined') return;
  try {
    isInternalBroadcasting = true;
    const event = new CustomEvent<ModuloSyncPayload>(CANONICAL_MODULO_SYNC_EVENT, {
      detail: payload
    });
    window.dispatchEvent(event);
  } finally {
    isInternalBroadcasting = false;
  }
}

// ---------------------------------------------------------------------
// MOTOR CANÓNICO: NORMALIZACIÓN Y RECÁLCULO UNIFORME DE CARACTERÍSTICAS
// Garantiza que la Creación, la Biblioteca y el Simulador de Interacción
// operen bajo EXACTAMENTE la misma matemática, lógica y atributos.
// ---------------------------------------------------------------------
export function normalizeCharacterCharacteristics(state: CharacterState): CharacterState {
  if (!state) return createDefaultCharacterState();

  const race = state.raceName || 'Humano';
  const role = state.role || 'Estratega';
  const attrs = state.attributes || {
    FUE: 14,
    DES: 14,
    CON: 14,
    INT: 14,
    SAB: 12,
    CAR: 14
  };

  // Recálculo matemático unificado (D&D y Pneuma)
  const unifiedDerived = calculateUnifiedDerivedStats(attrs, race, role);
  const currentXp = state.derivedStats?.XP ?? 250;
  const currentNivel = Math.max(1, Math.floor(currentXp / 200) + 1);
  const currentProf = 2 + Math.floor((currentNivel - 1) / 4);

  // Sintonía moral automática
  const currentMoral =
    state.liteAgent?.moralAlignment ||
    deduceMoralAlignment(state.background?.coreValues || '', role);

  // Combat Stats uniformes
  const combatMaxHp = unifiedDerived.PV;
  const combatMaxSp = Math.max(20, unifiedDerived.PEP * 10);
  const prevCombat = state.liteAgent?.combatStats;

  const currentHp = prevCombat?.currentHp !== undefined
    ? Math.min(combatMaxHp, Math.max(0, prevCombat.currentHp))
    : combatMaxHp;

  const currentSp = prevCombat?.currentSp !== undefined
    ? Math.min(combatMaxSp, Math.max(0, prevCombat.currentSp))
    : combatMaxSp;

  const defaultSkill =
    state.background?.advancedCustomization?.skills?.[0] ||
    (state.equipment?.weapons?.[0] ? `Técnica con ${state.equipment.weapons[0]}` : 'Tajo Espejado');

  return {
    ...state,
    attributes: { ...attrs },
    derivedStats: {
      ...state.derivedStats,
      ...unifiedDerived,
      XP: currentXp,
      nivel: currentNivel,
      proficiencia: currentProf,
      maxPV: unifiedDerived.PV,
      maxPEP: unifiedDerived.PEP,
      habilidades:
        state.derivedStats?.habilidades && state.derivedStats.habilidades.length > 0
          ? state.derivedStats.habilidades
          : state.background?.advancedCustomization?.skills || [defaultSkill]
    },
    liteAgent: {
      isLiteAgent: true,
      moralAlignment: currentMoral as any,
      allegianceFactionId:
        state.liteAgent?.allegianceFactionId ||
        state.background?.factionOrFaith ||
        state.nobleHouseOrDomain ||
        'Independiente',
      greatestFear:
        state.liteAgent?.greatestFear ||
        state.background?.fatalFlawOrVulnerability ||
        'La pérdida de su propósito y la caída de sus seres queridos',
      motivations:
        state.liteAgent?.motivations && state.liteAgent.motivations.length > 0
          ? state.liteAgent.motivations
          : [
              state.background?.motivation || 'Alcanzar la maestría absoluta',
              'Proteger sus principios'
            ],
      interactionRole: state.liteAgent?.interactionRole || role,
      combatStats: {
        maxHp: combatMaxHp,
        currentHp: currentHp,
        maxSp: combatMaxSp,
        currentSp: currentSp,
        attack: prevCombat?.attack || (10 + Math.floor(attrs.FUE / 2) + Math.floor(attrs.DES / 4)),
        defense: unifiedDerived.CA,
        agility: unifiedDerived.iniciativa,
        specialSkillName: prevCombat?.specialSkillName || defaultSkill,
        specialSkillDescription:
          prevCombat?.specialSkillDescription || 'Técnica de combate refinada y maniobra táctica.'
      }
    },
    background: {
      ...state.background,
      coreValues: state.background?.coreValues !== undefined ? state.background.coreValues : '',
      fatalFlawOrVulnerability:
        state.background?.fatalFlawOrVulnerability ||
        state.liteAgent?.greatestFear ||
        'Exceso de orgullo o apego al deber',
      advancedCustomization: {
        ...state.background?.advancedCustomization,
        voiceTone: state.background?.advancedCustomization?.voiceTone || 'Serena y firme',
        speechStyle: state.background?.advancedCustomization?.speechStyle || 'Formal y comedido',
        skills:
          state.background?.advancedCustomization?.skills &&
          state.background.advancedCustomization.skills.length > 0
            ? state.background.advancedCustomization.skills
            : [defaultSkill, 'Evaluación Táctica', 'Foco Inquebrantable']
      }
    }
  };
}

// ---------------------------------------------------------------------
// HELPERS DE PERSISTENCIA ACTIVA
// ---------------------------------------------------------------------
export function getStoredActiveCharacter(): CharacterState {
  try {
    const raw = localStorage.getItem(ACTIVE_CHARACTER_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') {
        return normalizeCharacterCharacteristics(parsed);
      }
    }
  } catch (e) {
    console.error('Error loading stored active character:', e);
  }

  // Fallback: primer personaje de la biblioteca
  const lib = getSavedCharacters();
  if (lib.length > 0 && lib[0]?.state) {
    return normalizeCharacterCharacteristics(lib[0].state);
  }
  return normalizeCharacterCharacteristics(createDefaultCharacterState());
}

export function setStoredActiveCharacter(char: CharacterState): void {
  try {
    localStorage.setItem(ACTIVE_CHARACTER_STORAGE_KEY, JSON.stringify(char));
  } catch (e) {
    console.error('Error saving active character to localStorage:', e);
  }
}

export function getStoredProtagonist(): CharacterState | null {
  try {
    const raw = localStorage.getItem(PROTAGONIST_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') {
        return normalizeCharacterCharacteristics(parsed);
      }
    }
  } catch (e) {
    console.error('Error loading stored protagonist:', e);
  }
  return null;
}

export function setStoredProtagonist(char: CharacterState | null): void {
  try {
    if (char) {
      localStorage.setItem(PROTAGONIST_STORAGE_KEY, JSON.stringify(char));
    } else {
      localStorage.removeItem(PROTAGONIST_STORAGE_KEY);
    }
  } catch (e) {
    console.error('Error saving protagonist to localStorage:', e);
  }
}

export function getStoredActiveSession(): InteractionSessionState | null {
  try {
    const raw = localStorage.getItem(ACTIVE_SESSION_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object' && parsed.id) {
        return parsed;
      }
    }
  } catch (e) {
    console.error('Error loading stored active session:', e);
  }
  return null;
}

export function setStoredActiveSession(session: InteractionSessionState | null): void {
  try {
    if (session) {
      localStorage.setItem(ACTIVE_SESSION_STORAGE_KEY, JSON.stringify(session));
    } else {
      localStorage.removeItem(ACTIVE_SESSION_STORAGE_KEY);
    }
  } catch (e) {
    console.error('Error saving active session to localStorage:', e);
  }
}

// ---------------------------------------------------------------------
// CUSTOM HOOK: moduloSync (useModuloSync)
// ---------------------------------------------------------------------
export interface UseModuloSyncOptions {
  source?: ModuloSource;
  autoSyncActiveToLibrary?: boolean;
}

export interface ModuloSyncReturn {
  // 1. Personaje Activo (Creación <-> Biblioteca <-> Simulador)
  characterState: CharacterState;
  updateCharacterState: (
    updater: CharacterState | ((prev: CharacterState) => CharacterState),
    options?: { persistToLibrary?: boolean; source?: ModuloSource }
  ) => CharacterState;

  // 2. Protagonista Designado
  protagonistCharacter: CharacterState | null;
  updateProtagonist: (
    char: CharacterState | null,
    options?: { source?: ModuloSource }
  ) => void;

  // 3. Biblioteca Reactiva Uniforme
  savedCharacters: SavedCharacterEntry[];
  reloadSavedCharacters: () => SavedCharacterEntry[];
  saveToLibrary: (char: CharacterState, variantLabel?: string) => SavedCharacterEntry;
  deleteFromLibrary: (id: string) => boolean;
  duplicateInLibrary: (id: string) => SavedCharacterEntry | null;

  // 4. Lugares & Worldbuilding
  activePlace: WorldPlace;
  updateActivePlace: (place: WorldPlace, options?: { source?: ModuloSource }) => void;
  savedPlaces: WorldPlace[];
  worldConfig: WorldBuildingConfig;
  updateWorldConfig: (config: WorldBuildingConfig, options?: { source?: ModuloSource }) => void;

  // 5. Sesión de Interacción & Sincronización Bidireccional de Participantes
  activeSession: InteractionSessionState | null;
  updateActiveSession: (
    updater: InteractionSessionState | null | ((prev: InteractionSessionState | null) => InteractionSessionState | null),
    options?: { syncParticipantsToLibrary?: boolean; source?: ModuloSource }
  ) => void;
  syncParticipantDirectly: (
    participant: UnifiedParticipant,
    isProtagonist: boolean,
    targetCharState?: CharacterState
  ) => CharacterState;

  // 6. Utilidades
  normalizeCharacter: (char: CharacterState) => CharacterState;
  lastSyncTimestamp: number;
  triggerGlobalSync: (action?: ModuloSyncPayload['action']) => void;
}

export function useModuloSync(options: UseModuloSyncOptions = {}): ModuloSyncReturn {
  const currentSource = options.source || 'system';

  // Estados reactivos locales vinculados al almacén canónico
  const [characterState, setLocalCharacterState] = useState<CharacterState>(() =>
    getStoredActiveCharacter()
  );
  const [protagonistCharacter, setLocalProtagonist] = useState<CharacterState | null>(() =>
    getStoredProtagonist()
  );
  const [savedCharacters, setLocalSavedCharacters] = useState<SavedCharacterEntry[]>(() =>
    getSavedCharacters()
  );
  const [savedPlaces, setLocalSavedPlaces] = useState<WorldPlace[]>(() => getSavedPlaces());
  const [activePlace, setLocalActivePlace] = useState<WorldPlace>(() => {
    try {
      const stored = localStorage.getItem(ACTIVE_PLACE_STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch {}
    const p = getSavedPlaces();
    return p[0] || {
      id: 'default-place',
      name: 'Oasis Sagrado de Al-Zahra',
      region: 'Desierto de Ambar',
      dangerLevel: 1,
      atmosphere: 'Calmo y sereno',
      customRules: []
    };
  });
  const [worldConfig, setLocalWorldConfig] = useState<WorldBuildingConfig>(() =>
    getWorldBuildingConfig()
  );
  const [activeSession, setLocalActiveSession] = useState<InteractionSessionState | null>(() =>
    getStoredActiveSession()
  );
  const [lastSyncTimestamp, setLastSyncTimestamp] = useState<number>(() => Date.now());

  // Ref para evitar ciclos de actualización infinitos
  const isUpdatingRef = useRef<boolean>(false);

  // -------------------------------------------------------------------
  // ESCUCHADOR DE SINCRONIZACIÓN REACTIVA (GLOBAL EVENT & STORAGE)
  // -------------------------------------------------------------------
  useEffect(() => {
    const handleSyncEvent = (e: Event) => {
      const customEvent = e as CustomEvent<ModuloSyncPayload>;
      const detail = customEvent.detail;
      if (!detail) return;

      // Si el evento provino de este mismo ciclo, no repetir
      if (isUpdatingRef.current) return;

      setLastSyncTimestamp(detail.timestamp || Date.now());

      // Recarga de biblioteca
      setLocalSavedCharacters(getSavedCharacters());
      setLocalSavedPlaces(getSavedPlaces());
      setLocalWorldConfig(getWorldBuildingConfig());

      // Sincronización de Personaje Activo
      if (detail.character) {
        setLocalCharacterState(detail.character);
      } else if (detail.characterId) {
        const found = getSavedCharacterById(detail.characterId);
        if (found) {
          setLocalCharacterState(normalizeCharacterCharacteristics(found.state));
        }
      }

      // Sincronización de Protagonista
      if (detail.protagonist !== undefined) {
        setLocalProtagonist(detail.protagonist);
      }

      // Sincronización de Lugar
      if (detail.place) {
        setLocalActivePlace(detail.place);
      }

      // Sincronización de WorldConfig
      if (detail.worldConfig) {
        setLocalWorldConfig(detail.worldConfig);
      }

      // Sincronización de Sesión
      if (detail.session !== undefined) {
        setLocalActiveSession(detail.session);
      }
    };

    const handleStorageEvent = (e: StorageEvent) => {
      if (
        e.key === LIBRARY_STORAGE_KEY ||
        e.key === PLACES_STORAGE_KEY ||
        e.key === WORLDBUILDING_STORAGE_KEY ||
        e.key === ACTIVE_CHARACTER_STORAGE_KEY ||
        e.key === PROTAGONIST_STORAGE_KEY ||
        e.key === ACTIVE_SESSION_STORAGE_KEY ||
        e.key === ACTIVE_PLACE_STORAGE_KEY
      ) {
        setLocalSavedCharacters(getSavedCharacters());
        setLocalSavedPlaces(getSavedPlaces());
        setLocalWorldConfig(getWorldBuildingConfig());
        setLocalCharacterState(getStoredActiveCharacter());
        setLocalProtagonist(getStoredProtagonist());
        setLocalActiveSession(getStoredActiveSession());
        setLastSyncTimestamp(Date.now());
      }
    };

    window.addEventListener(CANONICAL_MODULO_SYNC_EVENT, handleSyncEvent);
    window.addEventListener('storage', handleStorageEvent);

    return () => {
      window.removeEventListener(CANONICAL_MODULO_SYNC_EVENT, handleSyncEvent);
      window.removeEventListener('storage', handleStorageEvent);
    };
  }, []);

  // -------------------------------------------------------------------
  // ACTUALIZADOR UNIFICADO DE PERSONAJE ACTIVO
  // -------------------------------------------------------------------
  const updateCharacterState = useCallback(
    (
      updater: CharacterState | ((prev: CharacterState) => CharacterState),
      updateOptions?: { persistToLibrary?: boolean; source?: ModuloSource }
    ): CharacterState => {
      isUpdatingRef.current = true;
      try {
        const nextRaw =
          typeof updater === 'function' ? updater(characterState) : updater;
        const normalized = normalizeCharacterCharacteristics(nextRaw);

        // Guardar en active character storage
        setStoredActiveCharacter(normalized);
        setLocalCharacterState(normalized);

        // Si se solicita o por defecto con ID, actualizar en la biblioteca
        if (updateOptions?.persistToLibrary !== false && normalized.id) {
          saveCharacterToLibrary(normalized);
          setLocalSavedCharacters(getSavedCharacters());
        }

        // Si el protagonista es este mismo personaje, mantener en sincronía
        if (protagonistCharacter && protagonistCharacter.id === normalized.id) {
          setStoredProtagonist(normalized);
          setLocalProtagonist(normalized);
        }

        // Si hay una sesión activa que involucra este personaje, actualizar su participante
        if (activeSession) {
          let sessionChanged = false;
          let updatedProtagonist = activeSession.protagonist;
          let updatedNpc = activeSession.npc;

          if (
            activeSession.protagonist.characterStateId === normalized.id ||
            activeSession.protagonist.name === normalized.name
          ) {
            updatedProtagonist = characterStateToUnifiedParticipant(
              normalized,
              activeSession.protagonist.title || 'Ficha del Usuario'
            );
            sessionChanged = true;
          }

          if (
            activeSession.npc.characterStateId === normalized.id ||
            activeSession.npc.name === normalized.name
          ) {
            updatedNpc = characterStateToUnifiedParticipant(
              normalized,
              activeSession.npc.title || 'Agente Lite / Acompañante'
            );
            sessionChanged = true;
          }

          if (sessionChanged) {
            const nextSession: InteractionSessionState = {
              ...activeSession,
              protagonist: updatedProtagonist,
              npc: updatedNpc
            };
            setStoredActiveSession(nextSession);
            setLocalActiveSession(nextSession);
          }
        }

        const now = Date.now();
        setLastSyncTimestamp(now);

        // Emitir a todos los otros módulos
        emitModuloSync({
          source: updateOptions?.source || currentSource,
          action: 'update_character',
          character: normalized,
          characterId: normalized.id,
          timestamp: now
        });

        return normalized;
      } finally {
        isUpdatingRef.current = false;
      }
    },
    [characterState, protagonistCharacter, activeSession, currentSource]
  );

  // -------------------------------------------------------------------
  // ACTUALIZADOR UNIFICADO DE PROTAGONISTA
  // -------------------------------------------------------------------
  const updateProtagonist = useCallback(
    (char: CharacterState | null, updateOptions?: { source?: ModuloSource }) => {
      isUpdatingRef.current = true;
      try {
        const normalized = char ? normalizeCharacterCharacteristics(char) : null;
        setStoredProtagonist(normalized);
        setLocalProtagonist(normalized);

        const now = Date.now();
        setLastSyncTimestamp(now);

        emitModuloSync({
          source: updateOptions?.source || currentSource,
          action: 'update_protagonist',
          protagonist: normalized,
          timestamp: now
        });
      } finally {
        isUpdatingRef.current = false;
      }
    },
    [currentSource]
  );

  // -------------------------------------------------------------------
  // OPERACIONES DE BIBLIOTECA SINCRONIZADAS
  // -------------------------------------------------------------------
  const saveToLibrary = useCallback(
    (char: CharacterState, variantLabel?: string): SavedCharacterEntry => {
      isUpdatingRef.current = true;
      try {
        const normalized = normalizeCharacterCharacteristics(char);
        const saved = saveCharacterToLibrary(normalized, variantLabel);
        const updatedList = getSavedCharacters();
        setLocalSavedCharacters(updatedList);

        // Si coincide con el activo, refrescarlo
        if (characterState.id === saved.id || !characterState.id) {
          setStoredActiveCharacter(saved.state);
          setLocalCharacterState(saved.state);
        }

        const now = Date.now();
        setLastSyncTimestamp(now);

        emitModuloSync({
          source: currentSource,
          action: 'update_character',
          character: saved.state,
          characterId: saved.id,
          timestamp: now
        });

        return saved;
      } finally {
        isUpdatingRef.current = false;
      }
    },
    [characterState, currentSource]
  );

  const deleteFromLibrary = useCallback(
    (id: string): boolean => {
      isUpdatingRef.current = true;
      try {
        const ok = deleteCharacterFromLibrary(id);
        if (ok) {
          const updatedList = getSavedCharacters();
          setLocalSavedCharacters(updatedList);

          // Si el activo fue borrado, seleccionar el primero disponible
          if (characterState.id === id) {
            const fallback =
              updatedList.length > 0
                ? normalizeCharacterCharacteristics(updatedList[0].state)
                : normalizeCharacterCharacteristics(createDefaultCharacterState());
            setStoredActiveCharacter(fallback);
            setLocalCharacterState(fallback);
          }

          if (protagonistCharacter?.id === id) {
            setStoredProtagonist(null);
            setLocalProtagonist(null);
          }

          const now = Date.now();
          setLastSyncTimestamp(now);

          emitModuloSync({
            source: currentSource,
            action: 'delete_character',
            characterId: id,
            timestamp: now
          });
        }
        return ok;
      } finally {
        isUpdatingRef.current = false;
      }
    },
    [characterState, protagonistCharacter, currentSource]
  );

  const duplicateInLibrary = useCallback(
    (id: string): SavedCharacterEntry | null => {
      isUpdatingRef.current = true;
      try {
        const entry = duplicateCharacterInLibrary(id);
        if (entry) {
          setLocalSavedCharacters(getSavedCharacters());
          const now = Date.now();
          setLastSyncTimestamp(now);

          emitModuloSync({
            source: currentSource,
            action: 'update_character',
            character: entry.state,
            characterId: entry.id,
            timestamp: now
          });
        }
        return entry;
      } finally {
        isUpdatingRef.current = false;
      }
    },
    [currentSource]
  );

  const reloadSavedCharacters = useCallback((): SavedCharacterEntry[] => {
    const list = getSavedCharacters();
    setLocalSavedCharacters(list);
    return list;
  }, []);

  // -------------------------------------------------------------------
  // OPERACIONES DE LUGARES & WORLDBUILDING SINCRONIZADAS
  // -------------------------------------------------------------------
  const updateActivePlace = useCallback(
    (place: WorldPlace, updateOptions?: { source?: ModuloSource }) => {
      isUpdatingRef.current = true;
      try {
        savePlace(place);
        localStorage.setItem(ACTIVE_PLACE_STORAGE_KEY, JSON.stringify(place));
        setLocalActivePlace(place);
        setLocalSavedPlaces(getSavedPlaces());

        const now = Date.now();
        setLastSyncTimestamp(now);

        emitModuloSync({
          source: updateOptions?.source || currentSource,
          action: 'update_place',
          place,
          timestamp: now
        });
      } finally {
        isUpdatingRef.current = false;
      }
    },
    [currentSource]
  );

  const updateWorldConfig = useCallback(
    (config: WorldBuildingConfig, updateOptions?: { source?: ModuloSource }) => {
      isUpdatingRef.current = true;
      try {
        saveWorldBuildingConfig(config);
        setLocalWorldConfig(config);

        const now = Date.now();
        setLastSyncTimestamp(now);

        emitModuloSync({
          source: updateOptions?.source || currentSource,
          action: 'update_world',
          worldConfig: config,
          timestamp: now
        });
      } finally {
        isUpdatingRef.current = false;
      }
    },
    [currentSource]
  );

  // -------------------------------------------------------------------
  // SESIÓN DE INTERACCIÓN & SINCRONIZACIÓN PARTICIPANTE -> FICHA CANÓNICA
  // -------------------------------------------------------------------
  const syncParticipantDirectly = useCallback(
    (
      participant: UnifiedParticipant,
      isProtagonist: boolean,
      targetCharState?: CharacterState
    ): CharacterState => {
      isUpdatingRef.current = true;
      try {
        // Encontrar ficha canónica base
        const base =
          targetCharState ||
          (isProtagonist && protagonistCharacter ? protagonistCharacter : null) ||
          (participant.characterStateId ? getSavedCharacterById(participant.characterStateId)?.state : null) ||
          (participant.name ? getSavedCharacters().find(c => c.state.name === participant.name)?.state : null) ||
          characterState;

        const synced = syncParticipantToCharacterState(participant, base);
        const normalized = normalizeCharacterCharacteristics(synced);

        // Guardar en la biblioteca
        saveCharacterToLibrary(normalized);
        setLocalSavedCharacters(getSavedCharacters());

        // Si es el personaje activo, actualizarlo
        if (normalized.id === characterState.id || !characterState.id) {
          setStoredActiveCharacter(normalized);
          setLocalCharacterState(normalized);
        }

        // Si es el protagonista, actualizarlo
        if (isProtagonist || normalized.id === protagonistCharacter?.id) {
          setStoredProtagonist(normalized);
          setLocalProtagonist(normalized);
        }

        const now = Date.now();
        setLastSyncTimestamp(now);

        emitModuloSync({
          source: currentSource,
          action: 'update_character',
          character: normalized,
          characterId: normalized.id,
          timestamp: now
        });

        return normalized;
      } finally {
        isUpdatingRef.current = false;
      }
    },
    [characterState, protagonistCharacter, currentSource]
  );

  const updateActiveSession = useCallback(
    (
      updater:
        | InteractionSessionState
        | null
        | ((prev: InteractionSessionState | null) => InteractionSessionState | null),
      sessionOptions?: { syncParticipantsToLibrary?: boolean; source?: ModuloSource }
    ) => {
      isUpdatingRef.current = true;
      try {
        const nextSession =
          typeof updater === 'function' ? updater(activeSession) : updater;

        setStoredActiveSession(nextSession);
        setLocalActiveSession(nextSession);

        // Si se pide sincronizar participantes con la biblioteca (ej: tras combate o descanso)
        if (nextSession && sessionOptions?.syncParticipantsToLibrary) {
          if (nextSession.protagonist) {
            syncParticipantDirectly(nextSession.protagonist, true);
          }
          if (nextSession.npc) {
            syncParticipantDirectly(nextSession.npc, false);
          }
        }

        const now = Date.now();
        setLastSyncTimestamp(now);

        emitModuloSync({
          source: sessionOptions?.source || currentSource,
          action: 'update_session',
          session: nextSession,
          timestamp: now
        });
      } finally {
        isUpdatingRef.current = false;
      }
    },
    [activeSession, syncParticipantDirectly, currentSource]
  );

  const triggerGlobalSync = useCallback((action: ModuloSyncPayload['action'] = 'reload_all') => {
    setLocalSavedCharacters(getSavedCharacters());
    setLocalSavedPlaces(getSavedPlaces());
    setLocalWorldConfig(getWorldBuildingConfig());
    setLocalCharacterState(getStoredActiveCharacter());
    setLocalProtagonist(getStoredProtagonist());
    setLocalActiveSession(getStoredActiveSession());

    const now = Date.now();
    setLastSyncTimestamp(now);

    emitModuloSync({
      source: currentSource,
      action,
      timestamp: now
    });
  }, [currentSource]);

  return {
    characterState,
    updateCharacterState,
    protagonistCharacter,
    updateProtagonist,
    savedCharacters,
    reloadSavedCharacters,
    saveToLibrary,
    deleteFromLibrary,
    duplicateInLibrary,
    activePlace,
    updateActivePlace,
    savedPlaces,
    worldConfig,
    updateWorldConfig,
    activeSession,
    updateActiveSession,
    syncParticipantDirectly,
    normalizeCharacter: normalizeCharacterCharacteristics,
    lastSyncTimestamp,
    triggerGlobalSync
  };
}

// Exportación con el nombre solicitado exactamente por el usuario: moduloSync
export const moduloSync = useModuloSync;
export default useModuloSync;
