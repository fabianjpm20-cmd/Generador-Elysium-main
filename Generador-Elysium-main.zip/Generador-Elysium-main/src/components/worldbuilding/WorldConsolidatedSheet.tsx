import React, { useState } from 'react';
import { WorldBuildingConfig } from '../../types';
import { generateWorldMarkdown } from './worldSyncUtils';
import {
  Eye,
  Copy,
  Download,
  CheckCircle2,
  Scale,
  Shield,
  BookOpen,
  Compass,
  Coins,
  HeartHandshake,
  Cpu,
  Sparkles,
  Layers,
  Users,
  Ban
} from 'lucide-react';

interface WorldConsolidatedSheetProps {
  worldConfig: WorldBuildingConfig;
  onExportJson: () => void;
}

export const WorldConsolidatedSheet: React.FC<WorldConsolidatedSheetProps> = ({
  worldConfig,
  onExportJson
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopyMarkdown = () => {
    const md = generateWorldMarkdown(worldConfig);
    navigator.clipboard.writeText(md);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Barra de Acciones de la Ficha Maestra */}
      <div className="bg-[#12141C] border border-[#262A3A] rounded-3xl p-6 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300">
              Visor Holístico • Simulación Activa
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#1F232F] text-[#A0A5B5] border border-[#2D3242]">
              {worldConfig.version || 'v1.0'}
            </span>
          </div>
          <h3 className="text-xl font-bold text-[#F3F4F6] mt-1">
            Ficha Maestra Consolidada: {worldConfig.worldName}
          </h3>
          <p className="text-xs text-[#8A8F9E] mt-1">
            Inspección integral de las 12 categorías que alimentan el motor de eventos, respuestas de NPCs y coherencia narrativa.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={handleCopyMarkdown}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition-all cursor-pointer"
          >
            {copied ? <CheckCircle2 className="w-4 h-4 text-emerald-200" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? '¡Copiado al Portapapeles!' : 'Copiar Markdown'}</span>
          </button>

          <button
            type="button"
            onClick={onExportJson}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#1A1D27] hover:bg-[#25293A] border border-[#2E3346] text-[#A0A5B5] hover:text-white font-bold text-xs transition-all cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Exportar JSON</span>
          </button>
        </div>
      </div>

      {/* Jerarquía de Prioridades del Motor */}
      <div className="bg-[#12141C] border border-[#242838] rounded-2xl p-4 space-y-2">
        <div className="flex items-center gap-2">
          <Scale className="w-4 h-4 text-[#D4AF37]" />
          <span className="text-xs font-bold uppercase tracking-wider text-[#F3F4F6]">
            Jerarquía de Resolución del Motor de Elysium
          </span>
        </div>
        <div className="flex flex-wrap items-center gap-1.5 text-[11px] font-mono text-[#A0A5B5] bg-[#161823] p-3 rounded-xl border border-[#242838]">
          <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 font-bold">1. CANON</span>
          <span className="text-gray-500">&gt;</span>
          <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold">2. LEYES ESPECIALES</span>
          <span className="text-gray-500">&gt;</span>
          <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 font-bold">3. REGLAS FÍSICAS</span>
          <span className="text-gray-500">&gt;</span>
          <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">4. REGLAS SOCIALES</span>
          <span className="text-gray-500">&gt;</span>
          <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-bold">5. CONFIGURACIÓN</span>
          <span className="text-gray-500">&gt;</span>
          <span className="px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-bold">6. ESCENARIO</span>
          <span className="text-gray-500">&gt;</span>
          <span className="px-2 py-0.5 rounded bg-gray-500/20 text-gray-300 font-bold">7. EVENTO</span>
        </div>
      </div>

      {/* Desglose de las 12 Categorías */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
        {/* 01 Historia */}
        <div className="bg-[#12141C] border border-[#232736] rounded-2xl p-4 space-y-2">
          <div className="flex items-center gap-2 text-emerald-400 font-bold">
            <BookOpen className="w-4 h-4" />
            <span>01. Historia & Cronología</span>
          </div>
          <p className="text-[#A0A5B5]"><strong>Origen:</strong> {worldConfig.history?.origin || 'No definido'}</p>
          <p className="text-[#A0A5B5]"><strong>Eras:</strong> {worldConfig.history?.eras || 'No definidas'}</p>
          {(worldConfig.history?.wars || []).length > 0 && (
            <p className="text-[#8A8F9E]"><strong>Guerras:</strong> {(worldConfig.history?.wars || []).join(', ')}</p>
          )}
        </div>

        {/* 02 Geografía */}
        <div className="bg-[#12141C] border border-[#232736] rounded-2xl p-4 space-y-2">
          <div className="flex items-center gap-2 text-emerald-400 font-bold">
            <Compass className="w-4 h-4" />
            <span>02. Geografía & Climas</span>
          </div>
          <p className="text-[#A0A5B5]"><strong>Continentes:</strong> {(worldConfig.geographyHierarchy?.continents || []).join(', ') || 'N/A'}</p>
          <p className="text-[#A0A5B5]"><strong>Reinos / Países:</strong> {(worldConfig.geographyHierarchy?.countries || []).join(', ') || 'N/A'}</p>
          {(worldConfig.geographyHierarchy?.regions || []).length > 0 && (
            <p className="text-[#A0A5B5]"><strong>Regiones:</strong> {worldConfig.geographyHierarchy?.regions.join(', ')}</p>
          )}
          <p className="text-[#8A8F9E]"><strong>Climas:</strong> {(worldConfig.geographyHierarchy?.climates || []).join(', ') || 'N/A'}</p>
          <p className="text-[#8A8F9E]"><strong>Recursos:</strong> {(worldConfig.geographyHierarchy?.resources || []).join(', ') || 'N/A'}</p>
          {(worldConfig.geographyHierarchy?.specialZones || []).length > 0 && (
            <p className="text-amber-300/90 text-[11px]"><strong>Zonas Especiales:</strong> {worldConfig.geographyHierarchy?.specialZones.join(', ')}</p>
          )}
        </div>

        {/* 03 Política */}
        <div className="bg-[#12141C] border border-[#232736] rounded-2xl p-4 space-y-2">
          <div className="flex items-center gap-2 text-emerald-400 font-bold">
            <Shield className="w-4 h-4" />
            <span>03. Facciones ({worldConfig.politics?.factions?.length || 0})</span>
          </div>
          <p className="text-[#A0A5B5]"><strong>Gobiernos:</strong> {(worldConfig.politics?.governments || []).join(', ') || 'N/A'}</p>
          <div className="space-y-1 pt-1">
            {(worldConfig.politics?.factions || []).map(f => (
              <div key={f.id} className="flex items-center justify-between text-[11px] p-1.5 rounded-lg bg-[#181A24]">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: f.color }} />
                  <span className="font-bold text-[#F3F4F6]">{f.name}</span>
                </div>
                <span className="text-[#8A8F9E] text-[10px]">{f.reputationWithPlayer}</span>
              </div>
            ))}
          </div>
        </div>

        {/* 04 Economía */}
        <div className="bg-[#12141C] border border-[#232736] rounded-2xl p-4 space-y-2">
          <div className="flex items-center gap-2 text-emerald-400 font-bold">
            <Coins className="w-4 h-4" />
            <span>04. Economía & Mercados</span>
          </div>
          <p className="text-[#A0A5B5]"><strong>Moneda:</strong> {worldConfig.economy?.currency || 'Trueque'}</p>
          <p className="text-[#A0A5B5]"><strong>Comercio:</strong> {worldConfig.economy?.trade || 'Local'}</p>
          <p className="text-[#8A8F9E]"><strong>Bienes Clave:</strong> {(worldConfig.economy?.keyGoods || []).join(', ') || 'N/A'}</p>
          <p className="text-[#8A8F9E]"><strong>Escasez:</strong> {(worldConfig.economy?.scarcity || []).join(', ') || 'N/A'}</p>
        </div>

        {/* 05 Religión / Cultura */}
        <div className="bg-[#12141C] border border-[#232736] rounded-2xl p-4 space-y-2">
          <div className="flex items-center gap-2 text-emerald-400 font-bold">
            <HeartHandshake className="w-4 h-4" />
            <span>05. Religión & Cultura</span>
          </div>
          {worldConfig.religionAndCulture?.isApplicable === false ? (
            <p className="text-[#6B7280] italic">No aplica a este mundo.</p>
          ) : (
            <>
              <p className="text-[#A0A5B5]"><strong>Religiones:</strong> {(worldConfig.religionAndCulture?.religions || []).join(', ') || 'N/A'}</p>
              <p className="text-[#A0A5B5]"><strong>Tradiciones:</strong> {(worldConfig.religionAndCulture?.traditions || []).join(', ') || 'N/A'}</p>
              <p className="text-amber-300/90 text-[11px]"><strong>Tabúes:</strong> {(worldConfig.religionAndCulture?.taboos || []).join(', ') || 'N/A'}</p>
            </>
          )}
        </div>

        {/* 06 Tecnología */}
        <div className="bg-[#12141C] border border-[#232736] rounded-2xl p-4 space-y-2">
          <div className="flex items-center gap-2 text-emerald-400 font-bold">
            <Cpu className="w-4 h-4" />
            <span>06. Nivel Tecnológico</span>
          </div>
          <p className="text-[#A0A5B5]">
            <strong>Nivel Global:</strong> <span className="text-emerald-300 font-bold">{worldConfig.technology?.level || 'Medieval'}</span>
          </p>
          <p className="text-[#8A8F9E]"><strong>Permitido:</strong> {(worldConfig.technology?.allowedTech || []).join(', ') || 'Estándar'}</p>
          <p className="text-rose-300/90 text-[11px]"><strong>Prohibido:</strong> {(worldConfig.technology?.forbiddenTech || []).join(', ') || 'Ninguno'}</p>
        </div>

        {/* 07 Magia */}
        <div className="bg-[#12141C] border border-[#232736] rounded-2xl p-4 space-y-2">
          <div className="flex items-center gap-2 text-emerald-400 font-bold">
            <Sparkles className="w-4 h-4" />
            <span>07. Sistema de Magia</span>
          </div>
          <p className="text-[#A0A5B5]">
            <strong>¿Existe Magia?:</strong>{' '}
            <span className={worldConfig.magicSystem?.hasMagic ? 'text-amber-300 font-bold' : 'text-gray-400 font-bold'}>
              {worldConfig.magicSystem?.hasMagic ? 'SÍ' : 'NO'}
            </span>
          </p>
          {worldConfig.magicSystem?.hasMagic && (
            <>
              <p className="text-[#A0A5B5]"><strong>Fuente:</strong> {worldConfig.magicSystem?.source || 'N/A'}</p>
              <p className="text-[#8A8F9E]"><strong>Coste:</strong> {worldConfig.magicSystem?.cost || 'N/A'}</p>
              <p className="text-[#8A8F9E]"><strong>Escuelas:</strong> {(worldConfig.magicSystem?.types || []).join(', ') || 'N/A'}</p>
            </>
          )}
        </div>

        {/* 08 Reglas Físicas */}
        <div className="bg-[#12141C] border border-[#232736] rounded-2xl p-4 space-y-2">
          <div className="flex items-center gap-2 text-emerald-400 font-bold">
            <Layers className="w-4 h-4" />
            <span>08. Reglas Físicas & Biológicas</span>
          </div>
          <p className="text-[#A0A5B5]"><strong>Gravedad:</strong> {worldConfig.physicalRules?.gravity || '1.0G'}</p>
          <p className="text-[#A0A5B5]"><strong>Curación:</strong> {worldConfig.physicalRules?.healing || 'Estándar'}</p>
          <p className="text-[#A0A5B5]"><strong>Muerte:</strong> {worldConfig.physicalRules?.death || 'Definitiva'}</p>
          {worldConfig.physicalRules?.travel && (
            <p className="text-[#8A8F9E]"><strong>Viaje & Transporte:</strong> {worldConfig.physicalRules.travel}</p>
          )}
          {worldConfig.physicalRules?.supernaturalPhenomena && (
            <p className="text-amber-300/90 text-[11px]"><strong>Fenómenos:</strong> {worldConfig.physicalRules.supernaturalPhenomena}</p>
          )}
        </div>

        {/* 09 Reglas Sociales */}
        <div className="bg-[#12141C] border border-[#232736] rounded-2xl p-4 space-y-2">
          <div className="flex items-center gap-2 text-emerald-400 font-bold">
            <Users className="w-4 h-4" />
            <span>09. Reglas Sociales & Conducta</span>
          </div>
          <p className="text-[#A0A5B5]"><strong>Jerarquías:</strong> {worldConfig.socialRules?.hierarchies || 'N/A'}</p>
          <p className="text-[#A0A5B5]"><strong>Costumbres:</strong> {worldConfig.socialRules?.customs || 'N/A'}</p>
          <p className="text-emerald-300/90 text-[11px]"><strong>Aceptado:</strong> {(worldConfig.socialRules?.acceptedBehaviors || []).join(', ') || 'Estándar'}</p>
          <p className="text-rose-300/90 text-[11px]"><strong>Rechazado:</strong> {(worldConfig.socialRules?.rejectedBehaviors || []).join(', ') || 'Ninguno'}</p>
        </div>

        {/* 10 Leyes Especiales */}
        <div className="bg-[#12141C] border border-[#232736] rounded-2xl p-4 space-y-2 md:col-span-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-amber-400 font-bold">
              <Scale className="w-4 h-4" />
              <span>10. Leyes Especiales Activas ({worldConfig.specialLaws?.length || 0})</span>
            </div>
          </div>
          {(worldConfig.specialLaws || []).length === 0 ? (
            <p className="text-[#6B7280] italic">Sin leyes especiales registradas.</p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {(worldConfig.specialLaws || []).map((l, i) => (
                <div key={l.id || i} className="p-2.5 rounded-xl bg-[#171924] border border-[#262B3B] space-y-1 text-[11px]">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[#F3F4F6]">{l.title}</span>
                    <span className={`text-[10px] px-1.5 py-0.2 rounded font-bold ${l.isActive ? 'bg-amber-500/20 text-amber-300' : 'bg-gray-500/20 text-gray-400'}`}>
                      {l.isActive ? 'Activa' : 'Inactiva'}
                    </span>
                  </div>
                  <p className="text-[#8A8F9E]"><strong>Alcance:</strong> {l.scope}</p>
                  <p className="text-emerald-300/90"><strong>Efecto:</strong> {l.effect}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* 11 Canon */}
        <div className="bg-[#12141C] border border-[#232736] rounded-2xl p-4 space-y-2">
          <div className="flex items-center gap-2 text-rose-400 font-bold">
            <Shield className="w-4 h-4" />
            <span>11. Canon Inviolable</span>
          </div>
          <div className="space-y-1">
            {(worldConfig.canon?.facts || []).map((fact, idx) => (
              <p key={idx} className="text-[#A0A5B5] text-[11px] flex items-start gap-1.5">
                <span className="text-rose-400 font-bold">•</span>
                <span>{fact}</span>
              </p>
            ))}
          </div>
        </div>

        {/* 12 Restricciones */}
        <div className="bg-[#12141C] border border-[#232736] rounded-2xl p-4 space-y-2">
          <div className="flex items-center gap-2 text-rose-400 font-bold">
            <Ban className="w-4 h-4" />
            <span>12. Restricciones Narrativas</span>
          </div>
          <p className="text-[#A0A5B5]"><strong>Tecnologías Prohibidas:</strong> {(worldConfig.narrativeRestrictions?.forbiddenTech || []).join(', ') || 'Ninguna'}</p>
          <p className="text-[#A0A5B5]"><strong>Personajes No Autorizados:</strong> {(worldConfig.narrativeRestrictions?.unauthorizedCharacters || []).join(', ') || 'Ninguno'}</p>
          <p className="text-[#A0A5B5]"><strong>Eventos Incompatibles:</strong> {(worldConfig.narrativeRestrictions?.incompatibleEvents || []).join(', ') || 'Ninguno'}</p>
        </div>
      </div>
    </div>
  );
};
