import { WorldBuildingConfig, WorldFaction, WorldSpecialLaw, WorldLaw } from '../../types';

/**
 * Normaliza y sincroniza los campos de WorldBuildingConfig para que los datos
 * se trasladen fielmente entre las 12 categorías, las fichas maestras y los campos legacy.
 */
export const syncWorldConfig = (config: WorldBuildingConfig): WorldBuildingConfig => {
  const synced = JSON.parse(JSON.stringify(config)) as WorldBuildingConfig;

  // 1. Sincronizar facciones entre politics.factions y legacy factions
  const politicsFactions = synced.politics?.factions || synced.factions || [];
  if (!synced.politics) {
    synced.politics = {
      governments: [],
      factions: politicsFactions,
      organizations: [],
      relationships: [],
      conflicts: [],
      hierarchies: []
    };
  } else {
    synced.politics.factions = politicsFactions;
  }
  synced.factions = politicsFactions;

  // 2. Sincronizar leyes especiales entre specialLaws y legacy laws
  const specialLaws = synced.specialLaws || [];
  synced.specialLaws = specialLaws;
  synced.laws = specialLaws.map(sl => ({
    id: sl.id,
    title: sl.title,
    description: `[Alcance: ${sl.scope}] Condición: ${sl.condition} → Efecto: ${sl.effect} (Excepciones: ${sl.exceptions || 'Ninguna'})`,
    impactTag: 'social',
    modifierDescription: sl.effect,
    isActive: sl.isActive
  }));

  // 3. Asegurar estructuras mínimas en cada categoría
  if (!synced.history) {
    synced.history = {
      origin: '',
      eras: '',
      keyEvents: [],
      wars: [],
      catastrophes: [],
      politicalChanges: [],
      fundamentalEvents: []
    };
  }

  if (!synced.geographyHierarchy) {
    synced.geographyHierarchy = {
      continents: [],
      countries: [],
      regions: [],
      cities: [],
      climates: [],
      resources: [],
      specialZones: [],
      hierarchy: []
    };
  }

  if (!synced.economy) {
    synced.economy = {
      currency: '',
      resources: [],
      trade: '',
      markets: [],
      keyGoods: [],
      scarcity: [],
      wealth: '',
      systems: []
    };
  }

  if (!synced.religionAndCulture) {
    synced.religionAndCulture = {
      isApplicable: true,
      religions: [],
      traditions: [],
      customs: [],
      festivities: [],
      taboos: [],
      values: [],
      culturalNorms: []
    };
  }

  if (!synced.technology) {
    synced.technology = {
      level: 'Medieval',
      allowedTech: [],
      forbiddenTech: []
    };
  }

  if (!synced.magicSystem) {
    synced.magicSystem = {
      hasMagic: true,
      source: '',
      rules: [],
      limitations: [],
      cost: '',
      users: '',
      types: [],
      effects: [],
      restrictions: []
    };
  }

  if (!synced.physicalRules) {
    synced.physicalRules = {
      gravity: '1.0G',
      biology: '',
      healing: '',
      death: '',
      travel: '',
      time: '',
      space: '',
      energy: '',
      supernaturalPhenomena: ''
    };
  }

  if (!synced.socialRules) {
    synced.socialRules = {
      hierarchies: '',
      customs: '',
      familyRelations: '',
      socialNorms: '',
      acceptedBehaviors: [],
      rejectedBehaviors: [],
      protocols: [],
      socialRoles: []
    };
  }

  if (!synced.canon) {
    synced.canon = {
      characters: [],
      facts: [],
      relationships: [],
      places: [],
      events: [],
      rules: [],
      historicalData: []
    };
  }

  if (!synced.narrativeRestrictions) {
    synced.narrativeRestrictions = {
      forbiddenTech: [],
      unauthorizedCharacters: [],
      incompatibleEvents: [],
      arbitraryRuleChanges: []
    };
  }

  return synced;
};

/**
 * Calcula el porcentaje de completitud del Worldbuilding
 */
export const calculateWorldCompleteness = (config: WorldBuildingConfig): number => {
  let filled = 0;
  let total = 16;

  if (config.worldName?.trim()) filled++;
  if (config.history?.origin?.trim()) filled++;
  if (config.history?.eras?.trim()) filled++;
  if ((config.geographyHierarchy?.continents?.length || 0) > 0) filled++;
  if ((config.geographyHierarchy?.countries?.length || 0) > 0) filled++;
  if ((config.politics?.factions?.length || 0) > 0) filled++;
  if (config.economy?.currency?.trim()) filled++;
  if (config.religionAndCulture?.isApplicable === false || (config.religionAndCulture?.religions?.length || 0) > 0) filled++;
  if (config.technology?.level) filled++;
  if (config.magicSystem?.hasMagic === false || config.magicSystem?.source?.trim()) filled++;
  if (config.physicalRules?.gravity?.trim()) filled++;
  if (config.physicalRules?.healing?.trim() || config.physicalRules?.death?.trim()) filled++;
  if (config.socialRules?.hierarchies?.trim() || (config.socialRules?.acceptedBehaviors?.length || 0) > 0) filled++;
  if ((config.specialLaws?.length || 0) > 0) filled++;
  if ((config.canon?.facts?.length || 0) > 0) filled++;
  if ((config.narrativeRestrictions?.forbiddenTech?.length || 0) > 0 || (config.narrativeRestrictions?.arbitraryRuleChanges?.length || 0) > 0) filled++;

  return Math.round((filled / total) * 100);
};

/**
 * Genera el documento Markdown consolidado del Worldbuilding listo para copiar o exportar
 */
export const generateWorldMarkdown = (config: WorldBuildingConfig): string => {
  const c = syncWorldConfig(config);

  return `# FICHA MAESTRA DE WORLDBUILDING: ${c.worldName}
**Versión:** ${c.version || 'v1.0'} | **Nivel Tecnológico:** ${c.technology?.level || 'Medieval'} | **Magia:** ${c.magicSystem?.hasMagic ? (c.magicLevel || 'Alta') : 'Nula / Inexistente'}

---

## 01. HISTORIA DEL MUNDO
- **Origen:** ${c.history?.origin || 'No especificado'}
- **Eras Cronológicas:** ${c.history?.eras || 'No especificadas'}
- **Acontecimientos Clave:** ${(c.history?.keyEvents || []).join('; ') || 'Ninguno'}
- **Guerras Históricas:** ${(c.history?.wars || []).join(', ') || 'Ninguna'}
- **Catástrofes:** ${(c.history?.catastrophes || []).join(', ') || 'Ninguna'}
- **Cambios Políticos:** ${(c.history?.politicalChanges || []).join(', ') || 'Ninguno'}

---

## 02. GEOGRAFÍA & JERARQUÍA TERRITORIAL
- **Continentes:** ${(c.geographyHierarchy?.continents || []).join(', ') || 'N/A'}
- **Países / Reinos:** ${(c.geographyHierarchy?.countries || []).join(', ') || 'N/A'}
- **Regiones:** ${(c.geographyHierarchy?.regions || []).join(', ') || 'N/A'}
- **Ciudades Notables:** ${(c.geographyHierarchy?.cities || []).join(', ') || 'N/A'}
- **Climas Dominantes:** ${(c.geographyHierarchy?.climates || []).join(', ') || 'N/A'}
- **Recursos Estratégicos:** ${(c.geographyHierarchy?.resources || []).join(', ') || 'N/A'}
- **Zonas Especiales / Anomalías:** ${(c.geographyHierarchy?.specialZones || []).join(', ') || 'N/A'}

---

## 03. POLÍTICA, FACCIONES & DIPLOMACIA
- **Formas de Gobierno:** ${(c.politics?.governments || []).join(', ') || 'N/A'}
- **Conflictos Abiertos:** ${(c.politics?.conflicts || []).join(', ') || 'N/A'}

### Facciones Registradas (${c.politics?.factions?.length || 0}):
${(c.politics?.factions || []).map((f, i) => `### ${i + 1}. ${f.name}
- **Ideología:** ${f.ideology}
- **Color:** ${f.color} | **Emblema:** ${f.emblemIcon}
- **Reputación con Jugador:** ${f.reputationWithPlayer}
- **Descripción:** ${f.description}
- **Enemigos Declarados:** ${(f.activeEnemies || []).join(', ') || 'Ninguno'}
`).join('\n')}

### Relaciones Diplomáticas:
${(c.politics?.relationships || []).map(r => `- **${r.factionAId}** ↔ **${r.factionBId}**: [${r.status}] ${r.notes || ''}`).join('\n') || 'Sin tratados activos.'}

---

## 04. ECONOMÍA & COMERCIO
- **Moneda / Divisa:** ${c.economy?.currency || 'Trueque'}
- **Rutas de Comercio:** ${c.economy?.trade || 'Locales'}
- **Mercados Principales:** ${(c.economy?.markets || []).join(', ') || 'N/A'}
- **Bienes Clave:** ${(c.economy?.keyGoods || []).join(', ') || 'N/A'}
- **Bienes Escasos:** ${(c.economy?.scarcity || []).join(', ') || 'N/A'}
- **Concentración de Riqueza:** ${c.economy?.wealth || 'N/A'}

---

## 05. RELIGIÓN & CULTURA
${c.religionAndCulture?.isApplicable === false ? '*Categoría marcada como NO APLICA en este mundo.*' : `
- **Religiones & Cultos:** ${(c.religionAndCulture?.religions || []).join(', ') || 'N/A'}
- **Tradiciones:** ${(c.religionAndCulture?.traditions || []).join(', ') || 'N/A'}
- **Costumbres:** ${(c.religionAndCulture?.customs || []).join(', ') || 'N/A'}
- **Festividades:** ${(c.religionAndCulture?.festivities || []).join(', ') || 'N/A'}
- **Tabúes Morales:** ${(c.religionAndCulture?.taboos || []).join(', ') || 'N/A'}
- **Valores Cardinales:** ${(c.religionAndCulture?.values || []).join(', ') || 'N/A'}
`}

---

## 06. TECNOLOGÍA
- **Nivel Tecnológico Global:** ${c.technology?.level || 'Medieval'}
- **Tecnologías Permitidas:** ${(c.technology?.allowedTech || []).join(', ') || 'Estándar'}
- **Tecnologías Prohibidas (No pueden manifestarse):** ${(c.technology?.forbiddenTech || []).join(', ') || 'Ninguna'}

---

## 07. SISTEMA DE MAGIA
${!c.magicSystem?.hasMagic ? '*La magia está DESHABILITADA en este mundo.*' : `
- **Fuente de la Magia:** ${c.magicSystem?.source || 'Desconocida'}
- **Reglas Fundamentales:** ${(c.magicSystem?.rules || []).join('; ') || 'N/A'}
- **Coste & Limitaciones:** ${c.magicSystem?.cost || 'N/A'} | ${(c.magicSystem?.limitations || []).join('; ') || ''}
- **Usuarios de Magia:** ${c.magicSystem?.users || 'N/A'}
- **Escuelas / Tipos:** ${(c.magicSystem?.types || []).join(', ') || 'N/A'}
- **Efectos Comunes:** ${(c.magicSystem?.effects || []).join(', ') || 'N/A'}
- **Restricciones Arcanas:** ${(c.magicSystem?.restrictions || []).join('; ') || 'N/A'}
`}

---

## 08. REGLAS FÍSICAS (Prioridad sobre Eventos)
- **Gravedad:** ${c.physicalRules?.gravity || '1.0G'}
- **Biología:** ${c.physicalRules?.biology || 'Estándar'}
- **Curación:** ${c.physicalRules?.healing || 'Estándar'}
- **Muerte & Reversibilidad:** ${c.physicalRules?.death || 'Definitiva'}
- **Viaje & Transporte:** ${c.physicalRules?.travel || 'Terrestre'}
- **Tiempo & Espacio:** ${c.physicalRules?.time || 'Continuo'} | ${c.physicalRules?.space || 'Euclidiano'}
- **Fenómenos Sobrenaturales:** ${c.physicalRules?.supernaturalPhenomena || 'Ninguno'}

---

## 09. REGLAS SOCIALES & CONDUCTA
- **Jerarquías:** ${c.socialRules?.hierarchies || 'N/A'}
- **Costumbres:** ${c.socialRules?.customs || 'N/A'}
- **Conductas Aceptadas:** ${(c.socialRules?.acceptedBehaviors || []).join(', ') || 'N/A'}
- **Conductas Rechazadas:** ${(c.socialRules?.rejectedBehaviors || []).join(', ') || 'N/A'}
- **Protocolos:** ${(c.socialRules?.protocols || []).join('; ') || 'N/A'}

---

## 10. LEYES ESPECIALES DEL MOTOR (${c.specialLaws?.length || 0})
${(c.specialLaws || []).map((l, i) => `### Ley ${i + 1}: ${l.title} [${l.isActive ? 'ACTIVA' : 'INACTIVA'}]
- **Alcance:** ${l.scope}
- **Condición:** ${l.condition}
- **Efecto Mecánico:** ${l.effect}
- **Excepciones:** ${l.exceptions || 'Ninguna'}
`).join('\n')}

---

## 11. CANON INVIOLABLE DEL MOTOR
- **Hechos Canónicos:**
${(c.canon?.facts || []).map(f => `  - ${f}`).join('\n') || '  - Ninguno'}
- **Reglas Absolutas:**
${(c.canon?.rules || []).map(r => `  - ${r}`).join('\n') || '  - Ninguna'}
- **Personajes Canónicos:** ${(c.canon?.characters || []).join(', ') || 'N/A'}
- **Lugares Canónicos:** ${(c.canon?.places || []).join(', ') || 'N/A'}

---

## 12. RESTRICCIONES NARRATIVAS (Filtros del Motor)
- **Tecnologías Prohibidas:** ${(c.narrativeRestrictions?.forbiddenTech || []).join(', ') || 'Ninguna'}
- **Personajes No Autorizados:** ${(c.narrativeRestrictions?.unauthorizedCharacters || []).join(', ') || 'Ninguno'}
- **Eventos Incompatibles:** ${(c.narrativeRestrictions?.incompatibleEvents || []).join(', ') || 'Ninguno'}
- **Cambios de Reglas Arbitrarios Prohibidos:** ${(c.narrativeRestrictions?.arbitraryRuleChanges || []).join('; ') || 'Ninguno'}
`;
};
