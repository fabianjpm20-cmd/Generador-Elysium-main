import React, { useState } from 'react';
import { WorldPreset, WORLD_PRESETS } from '../../data/creationHubPresets';
import { Sparkles, Cpu, Skull, Check, X, BookOpen, Layers } from 'lucide-react';

interface WorldPresetModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyPreset: (preset: WorldPreset) => void;
}

export const WorldPresetModal: React.FC<WorldPresetModalProps> = ({
  isOpen,
  onClose,
  onApplyPreset
}) => {
  const [selectedId, setSelectedId] = useState<string>(WORLD_PRESETS[0]?.id || '');

  if (!isOpen) return null;

  const selectedPreset = WORLD_PRESETS.find(p => p.id === selectedId) || WORLD_PRESETS[0];

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Sparkles':
        return <Sparkles className="w-5 h-5 text-amber-400" />;
      case 'Cpu':
        return <Cpu className="w-5 h-5 text-cyan-400" />;
      case 'Skull':
        return <Skull className="w-5 h-5 text-rose-400" />;
      default:
        return <BookOpen className="w-5 h-5 text-emerald-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="bg-[#12141C] border border-[#2B2F3E] rounded-3xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl">
        {/* Cabecera del Modal */}
        <div className="p-6 border-b border-[#232736] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-[#F3F4F6]">
                Arquetipos Preconfigurados de Worldbuilding
              </h3>
              <p className="text-xs text-[#8A8F9E]">
                Carga un mundo completo con 12 categorías coherentes, leyes activas y facciones listas para la simulación.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-[#8A8F9E] hover:text-white hover:bg-[#1C202C] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Contenido: Selector Izquierdo + Vista Previa Derecha */}
        <div className="flex-1 overflow-y-auto grid grid-cols-1 md:grid-cols-12 divide-y md:divide-y-0 md:divide-x divide-[#232736]">
          {/* Columna Izquierda: Tarjetas de Preset */}
          <div className="md:col-span-5 p-4 space-y-3 bg-[#0F1118]">
            <span className="text-[11px] font-bold text-[#6B7280] uppercase tracking-wider block px-1">
              Seleccionar Mundo
            </span>
            {WORLD_PRESETS.map(preset => {
              const isSelected = preset.id === selectedId;
              return (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => setSelectedId(preset.id)}
                  className={`w-full text-left p-3.5 rounded-2xl border transition-all cursor-pointer flex flex-col gap-2 ${
                    isSelected
                      ? 'bg-[#1C2130] border-emerald-500/60 shadow-lg ring-1 ring-emerald-500/30'
                      : 'bg-[#141722] border-[#252938] hover:bg-[#181B28] hover:border-[#32384C]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 rounded-xl bg-black/40 border border-white/5">
                        {getIcon(preset.icon)}
                      </div>
                      <span className="text-xs font-bold text-[#F3F4F6]">
                        {preset.name}
                      </span>
                    </div>
                    {isSelected && (
                      <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs">
                        <Check className="w-3 h-3" />
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] px-2 py-0.5 rounded-md bg-[#1B202D] text-[#9BA1B5] border border-[#2B3144]">
                      {preset.badge}
                    </span>
                    <span className="text-[10px] text-[#6B7280]">
                      {preset.tone}
                    </span>
                  </div>
                  <p className="text-[11px] text-[#8A8F9E] line-clamp-2 leading-relaxed">
                    {preset.description}
                  </p>
                </button>
              );
            })}
          </div>

          {/* Columna Derecha: Previsualización de Datos */}
          <div className="md:col-span-7 p-6 space-y-4 bg-[#12141C] text-xs">
            {selectedPreset && (
              <div className="space-y-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300">
                      {selectedPreset.badge}
                    </span>
                    <span className="text-[10px] text-[#8A8F9E]">
                      {selectedPreset.tone}
                    </span>
                  </div>
                  <h4 className="text-base font-bold text-[#F3F4F6] mt-1.5">
                    {selectedPreset.config.worldName}
                  </h4>
                  <p className="text-xs text-[#A0A5B5] mt-1 leading-relaxed">
                    {selectedPreset.description}
                  </p>
                </div>

                {/* Resumen de Módulos */}
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div className="p-2.5 rounded-xl bg-[#171924] border border-[#252938]">
                    <span className="text-[#6B7280] block text-[10px] uppercase font-bold">Nivel Tecnológico</span>
                    <span className="text-emerald-400 font-bold">{selectedPreset.config.technology?.level || 'Medieval'}</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-[#171924] border border-[#252938]">
                    <span className="text-[#6B7280] block text-[10px] uppercase font-bold">Sistema de Magia</span>
                    <span className="text-amber-400 font-bold">
                      {selectedPreset.config.magicSystem?.hasMagic ? 'Sí (Activo)' : 'No (Deshabilitado)'}
                    </span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-[#171924] border border-[#252938]">
                    <span className="text-[#6B7280] block text-[10px] uppercase font-bold">Facciones Incluidas</span>
                    <span className="text-[#E0E2EC] font-bold">
                      {selectedPreset.config.politics?.factions?.length || 0} facciones principales
                    </span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-[#171924] border border-[#252938]">
                    <span className="text-[#6B7280] block text-[10px] uppercase font-bold">Leyes Especiales</span>
                    <span className="text-[#E0E2EC] font-bold">
                      {selectedPreset.config.specialLaws?.length || 0} leyes con modificador
                    </span>
                  </div>
                </div>

                {/* Extracto de Historia */}
                <div className="p-3 rounded-xl bg-[#171924] border border-[#252938] space-y-1">
                  <span className="text-[10px] uppercase font-bold text-[#D4AF37] block">Génesis y Eras</span>
                  <p className="text-[11px] text-[#A0A5B5] leading-relaxed">
                    {selectedPreset.config.history?.origin}
                  </p>
                  <p className="text-[10px] font-mono text-emerald-300/80 pt-1">
                    {selectedPreset.config.history?.eras}
                  </p>
                </div>

                {/* Extracto de Facciones */}
                <div className="space-y-1.5">
                  <span className="text-[10px] uppercase font-bold text-[#6B7280] block">Facciones Clave:</span>
                  <div className="space-y-1.5">
                    {(selectedPreset.config.politics?.factions || []).map(f => (
                      <div key={f.id} className="p-2 rounded-lg bg-[#181B26] border border-[#262B3B] flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: f.color }} />
                          <span className="font-bold text-[#F3F4F6] text-[11px]">{f.name}</span>
                        </div>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-[#202534] text-[#A0A5B5]">
                          {f.reputationWithPlayer}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Pie del Modal */}
        <div className="p-4 border-t border-[#232736] flex items-center justify-between bg-[#0F1118]">
          <span className="text-xs text-[#8A8F9E]">
            * Al aplicar, se reemplazarán los campos del editor con este arquetipo.
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-[#1A1D27] hover:bg-[#232736] text-[#A0A5B5] font-bold text-xs cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="button"
              onClick={() => {
                if (selectedPreset) {
                  onApplyPreset(selectedPreset);
                  onClose();
                }
              }}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition-all cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>Cargar este Arquetipo</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
