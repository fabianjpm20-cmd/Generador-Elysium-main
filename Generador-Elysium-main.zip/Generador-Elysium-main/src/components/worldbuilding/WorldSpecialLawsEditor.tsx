import React, { useState } from 'react';
import { WorldSpecialLaw } from '../../types';
import { SUGGESTIONS_BANK } from '../../data/creationHubPresets';
import { Scale, Plus, Trash2, Sparkles, Check, AlertCircle, Edit3 } from 'lucide-react';

interface WorldSpecialLawsEditorProps {
  specialLaws: WorldSpecialLaw[];
  onUpdateSpecialLaws: (laws: WorldSpecialLaw[]) => void;
}

export const WorldSpecialLawsEditor: React.FC<WorldSpecialLawsEditorProps> = ({
  specialLaws,
  onUpdateSpecialLaws
}) => {
  const [editingId, setEditingId] = useState<string | null>(null);

  // Añadir ley en blanco
  const handleAddBlankLaw = () => {
    const newLaw: WorldSpecialLaw = {
      id: `LAW-${Date.now().toString().slice(-4)}`,
      title: 'Nueva Ley Especial de Convivencia',
      scope: 'Distrito Central y Santuarios',
      condition: 'Portar armas desenfundadas o proferir amenazas',
      effect: 'Intervención inmediata de centinelas y retención temporal',
      exceptions: 'Guardia de la ciudad y defensa justificada',
      isActive: true
    };
    onUpdateSpecialLaws([...specialLaws, newLaw]);
    setEditingId(newLaw.id);
  };

  // Añadir desde plantilla sugerida
  const handleApplyTemplate = (tmpl: (typeof SUGGESTIONS_BANK.specialLawTemplates)[0]) => {
    const newLaw: WorldSpecialLaw = {
      id: `LAW-${Date.now().toString().slice(-4)}`,
      title: tmpl.title,
      scope: tmpl.scope,
      condition: tmpl.condition,
      effect: tmpl.effect,
      exceptions: tmpl.exceptions,
      isActive: true
    };
    onUpdateSpecialLaws([...specialLaws, newLaw]);
    setEditingId(newLaw.id);
  };

  // Actualizar ley específica
  const handleUpdateLaw = (id: string, updates: Partial<WorldSpecialLaw>) => {
    onUpdateSpecialLaws(specialLaws.map(l => (l.id === id ? { ...l, ...updates } : l)));
  };

  // Eliminar ley
  const handleDeleteLaw = (id: string) => {
    onUpdateSpecialLaws(specialLaws.filter(l => l.id !== id));
    if (editingId === id) setEditingId(null);
  };

  return (
    <div className="space-y-6">
      {/* Cabecera & Botón Añadir */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h4 className="text-sm font-bold text-[#F3F4F6] flex items-center gap-2">
            <Scale className="w-4 h-4 text-amber-400" />
            <span>10. Leyes Especiales con Alcance y Condiciones ({specialLaws.length})</span>
          </h4>
          <p className="text-xs text-[#8A8F9E]">
            Estatutos con modificador directo sobre la resolución de acciones y comportamiento de NPCs en zonas designadas.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleAddBlankLaw}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs shadow transition-all cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Añadir Ley</span>
          </button>
        </div>
      </div>

      {/* Sugerencias Rápidas de Leyes */}
      <div className="p-4 rounded-2xl bg-[#141620] border border-[#262A3A] space-y-2">
        <span className="text-[11px] font-bold text-[#D4AF37] flex items-center gap-1.5 uppercase tracking-wider">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Plantillas Sugeridas de Leyes Especiales:</span>
        </span>
        <div className="flex flex-wrap gap-2">
          {SUGGESTIONS_BANK.specialLawTemplates.map((tmpl, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleApplyTemplate(tmpl)}
              className="text-left px-2.5 py-1.5 rounded-xl bg-[#1B1E2B] hover:bg-[#252A3D] border border-[#2E3346] text-[#E0E2EC] text-[11px] font-medium transition-colors cursor-pointer flex items-center gap-1.5 group"
            >
              <Plus className="w-3 h-3 text-amber-400 group-hover:scale-125 transition-transform" />
              <span>{tmpl.title}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Lista de Leyes Registradas */}
      {specialLaws.length === 0 ? (
        <div className="p-8 rounded-2xl bg-[#151720] border border-dashed border-[#282C3C] text-center space-y-2">
          <Scale className="w-8 h-8 text-[#5A6072] mx-auto" />
          <p className="text-xs text-[#8A8F9E]">
            No hay leyes especiales activas. El mundo se rige únicamente por las leyes comunes de cada ciudad.
          </p>
          <button
            type="button"
            onClick={handleAddBlankLaw}
            className="text-xs font-bold text-amber-400 hover:underline cursor-pointer"
          >
            + Crear una ley especial
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {specialLaws.map((law, idx) => {
            const isEditing = editingId === law.id;
            return (
              <div
                key={law.id || idx}
                className={`rounded-2xl border p-4 space-y-3 transition-all ${
                  isEditing
                    ? 'bg-[#181B26] border-amber-500/60 shadow-lg'
                    : 'bg-[#141620] border-[#252837] hover:border-[#33384B]'
                }`}
              >
                {/* Cabecera de la Ley */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <input
                      type="checkbox"
                      checked={law.isActive}
                      onChange={e => handleUpdateLaw(law.id, { isActive: e.target.checked })}
                      className="accent-amber-500 w-4 h-4 rounded cursor-pointer"
                    />
                    <div>
                      <span className={`text-xs font-bold ${law.isActive ? 'text-[#F3F4F6]' : 'text-[#6B7280] line-through'}`}>
                        {law.title}
                      </span>
                      <span className="text-[10px] text-[#8A8F9E] ml-2 font-mono">
                        [{law.isActive ? 'VIGENTE' : 'DEROGADA / INACTIVA'}]
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setEditingId(isEditing ? null : law.id)}
                      className="p-1 rounded-lg text-[#8A8F9E] hover:text-[#F3F4F6] hover:bg-[#202434] transition-colors cursor-pointer"
                      title={isEditing ? 'Guardar edición' : 'Editar ley'}
                    >
                      {isEditing ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Edit3 className="w-3.5 h-3.5" />}
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeleteLaw(law.id)}
                      className="p-1 rounded-lg text-[#8A8F9E] hover:text-rose-400 hover:bg-rose-950/30 transition-colors cursor-pointer"
                      title="Eliminar ley"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Formulario de Edición o Vista Previa */}
                {isEditing ? (
                  <div className="space-y-3 pt-2 border-t border-[#25293A] text-xs">
                    <div>
                      <label className="text-[11px] font-bold text-[#8A8F9E] block mb-1">Título de la Ley:</label>
                      <input
                        type="text"
                        value={law.title}
                        onChange={e => handleUpdateLaw(law.id, { title: e.target.value })}
                        className="w-full bg-[#1A1D2A] border border-[#2E3344] rounded-xl px-3 py-1.5 text-xs text-[#E0E2EC] outline-hidden"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="text-[11px] font-bold text-amber-300 block mb-1">Alcance Geográfico / Sectorial:</label>
                        <input
                          type="text"
                          value={law.scope}
                          onChange={e => handleUpdateLaw(law.id, { scope: e.target.value })}
                          placeholder="Todos los oasis, Murallas interiores, Mercado mayor..."
                          className="w-full bg-[#1A1D2A] border border-[#2E3344] rounded-xl px-3 py-1.5 text-xs text-[#E0E2EC] outline-hidden"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] font-bold text-amber-300 block mb-1">Condición Disparadora:</label>
                        <input
                          type="text"
                          value={law.condition}
                          onChange={e => handleUpdateLaw(law.id, { condition: e.target.value })}
                          placeholder="Desenvainar armas, comerciar de noche, no pagar peaje..."
                          className="w-full bg-[#1A1D2A] border border-[#2E3344] rounded-xl px-3 py-1.5 text-xs text-[#E0E2EC] outline-hidden"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="text-[11px] font-bold text-emerald-300 block mb-1">Efecto Mecánico & Reacción del Motor:</label>
                        <textarea
                          rows={2}
                          value={law.effect}
                          onChange={e => handleUpdateLaw(law.id, { effect: e.target.value })}
                          placeholder="Los guardias intervienen de inmediato, se confiscan armas..."
                          className="w-full bg-[#1A1D2A] border border-[#2E3344] rounded-xl p-2.5 text-xs text-[#E0E2EC] outline-hidden"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] font-bold text-[#8A8F9E] block mb-1">Excepciones y Salvoconductos:</label>
                        <textarea
                          rows={2}
                          value={law.exceptions || ''}
                          onChange={e => handleUpdateLaw(law.id, { exceptions: e.target.value })}
                          placeholder="Peregrinos autorizados, Guardia Real, defensa propia..."
                          className="w-full bg-[#1A1D2A] border border-[#2E3344] rounded-xl p-2.5 text-xs text-[#E0E2EC] outline-hidden"
                        />
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-[#A0A5B5] pt-1">
                    <p className="bg-[#171A25] p-2 rounded-lg border border-[#242837]">
                      <strong className="text-amber-300 block text-[10px] uppercase font-bold">Alcance:</strong>
                      {law.scope}
                    </p>
                    <p className="bg-[#171A25] p-2 rounded-lg border border-[#242837]">
                      <strong className="text-amber-300 block text-[10px] uppercase font-bold">Condición:</strong>
                      {law.condition}
                    </p>
                    <p className="bg-[#171A25] p-2 rounded-lg border border-[#242837]">
                      <strong className="text-emerald-300 block text-[10px] uppercase font-bold">Efecto Mecánico:</strong>
                      {law.effect}
                    </p>
                    <p className="bg-[#171A25] p-2 rounded-lg border border-[#242837]">
                      <strong className="text-[#8A8F9E] block text-[10px] uppercase font-bold">Excepciones:</strong>
                      {law.exceptions || 'Ninguna'}
                    </p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
