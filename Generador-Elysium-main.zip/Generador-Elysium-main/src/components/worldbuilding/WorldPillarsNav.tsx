import React from 'react';
import {
  BookOpen,
  Compass,
  Shield,
  Coins,
  HeartHandshake,
  Cpu,
  Sparkles,
  Layers,
  Scale,
  Ban,
  Eye
} from 'lucide-react';

interface WorldPillarsNavProps {
  activeCategory: number;
  onSelectCategory: (cat: number) => void;
  completenessByCat: Record<number, boolean>;
}

export const CATEGORIES_CONFIG = [
  { num: 1, name: '01. Historia', icon: BookOpen, pillar: 'Cosmos & Crónicas' },
  { num: 2, name: '02. Geografía', icon: Compass, pillar: 'Cosmos & Crónicas' },
  { num: 11, name: '11. Canon', icon: Shield, pillar: 'Cosmos & Crónicas' },

  { num: 3, name: '03. Política & Facciones', icon: Shield, pillar: 'Sociedad & Poder' },
  { num: 4, name: '04. Economía', icon: Coins, pillar: 'Sociedad & Poder' },
  { num: 5, name: '05. Religión / Cultura', icon: HeartHandshake, pillar: 'Sociedad & Poder' },

  { num: 6, name: '06. Tecnología', icon: Cpu, pillar: 'Mecánicas del Motor' },
  { num: 7, name: '07. Magia', icon: Sparkles, pillar: 'Mecánicas del Motor' },
  { num: 8, name: '08. Reglas Físicas', icon: Layers, pillar: 'Mecánicas del Motor' },
  { num: 9, name: '09. Reglas Sociales', icon: HeartHandshake, pillar: 'Mecánicas del Motor' },

  { num: 10, name: '10. Leyes Especiales', icon: Scale, pillar: 'Estatutos & Filtros' },
  { num: 12, name: '12. Restricciones', icon: Ban, pillar: 'Estatutos & Filtros' },

  { num: 13, name: '13. Ficha Consolidada', icon: Eye, pillar: 'Visor General' }
];

export const WorldPillarsNav: React.FC<WorldPillarsNavProps> = ({
  activeCategory,
  onSelectCategory,
  completenessByCat
}) => {
  return (
    <div className="space-y-2">
      {/* Barra de Pestañas con Iconos y Badges */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-2 text-xs">
        {CATEGORIES_CONFIG.map(cat => {
          const Icon = cat.icon;
          const isSelected = activeCategory === cat.num;
          const isFilled = completenessByCat[cat.num];
          const isConsolidated = cat.num === 13;

          return (
            <button
              key={cat.num}
              type="button"
              onClick={() => onSelectCategory(cat.num)}
              className={`flex items-center justify-between p-2.5 rounded-2xl font-bold border transition-all text-left cursor-pointer ${
                isSelected
                  ? isConsolidated
                    ? 'bg-amber-950/40 text-amber-300 border-amber-500/60 shadow-lg ring-1 ring-amber-500/30'
                    : 'bg-[#1C2130] text-emerald-400 border-emerald-500/60 shadow-lg ring-1 ring-emerald-500/30'
                  : 'bg-[#13151D] text-[#8A8F9E] border-[#252836] hover:text-[#E0E2EC] hover:bg-[#181B26]'
              }`}
            >
              <div className="flex items-center gap-2 truncate">
                <Icon className={`w-4 h-4 shrink-0 ${isSelected ? (isConsolidated ? 'text-amber-400' : 'text-emerald-400') : 'text-[#6B7280]'}`} />
                <span className="truncate">{cat.name}</span>
              </div>
              {!isConsolidated && (
                <span
                  className={`w-2 h-2 rounded-full shrink-0 ml-1 ${
                    isFilled ? 'bg-emerald-400 ring-2 ring-emerald-500/20' : 'bg-gray-600'
                  }`}
                  title={isFilled ? 'Categoría completada' : 'Pendiente de rellenar'}
                />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
