import React, { useState } from 'react';
import { WorldFaction, FactionRelationship } from '../../types';
import { Shield, Plus, Trash2, Edit3, HeartHandshake, Swords, Check, Flame, Gem, Skull, Crown } from 'lucide-react';

interface WorldFactionsEditorProps {
  governments: string[];
  conflicts: string[];
  factions: WorldFaction[];
  relationships: FactionRelationship[];
  onUpdateGovernments: (governments: string[]) => void;
  onUpdateConflicts: (conflicts: string[]) => void;
  onUpdateFactions: (factions: WorldFaction[]) => void;
  onUpdateRelationships: (relationships: FactionRelationship[]) => void;
}

const FACTION_COLORS = [
  '#D4AF37', // Oro
  '#38BDF8', // Cyan
  '#10B981', // Esmeralda
  '#E11D48', // Carmesí
  '#8B5CF6', // Púrpura
  '#F59E0B', // Ámbar
  '#64748B', // Acero
  '#EC4899'  // Rosa
];

const REPUTATIONS = ['Aliada', 'Amistosa', 'Neutral', 'Desconfiada', 'Hostil'] as const;

export const WorldFactionsEditor: React.FC<WorldFactionsEditorProps> = ({
  governments,
  conflicts,
  factions,
  relationships,
  onUpdateGovernments,
  onUpdateConflicts,
  onUpdateFactions,
  onUpdateRelationships
}) => {
  const [editingFactionId, setEditingFactionId] = useState<string | null>(null);
  const [editingRelationshipId, setEditingRelationshipId] = useState<string | null>(null);

  // Añadir nueva facción
  const handleAddFaction = () => {
    const newFaction: WorldFaction = {
      id: `FAC-${Date.now().toString().slice(-4)}`,
      name: 'Nueva Facción u Orden',
      ideology: 'Defensa de sus territorios, acumulación de recursos y lealtad a su líder.',
      emblemIcon: 'Shield',
      color: FACTION_COLORS[factions.length % FACTION_COLORS.length],
      reputationWithPlayer: 'Neutral',
      description: 'Grupo organizado con influencia en los sectores locales.',
      activeEnemies: []
    };
    onUpdateFactions([...factions, newFaction]);
    setEditingFactionId(newFaction.id);
  };

  // Modificar facción específica
  const handleUpdateFaction = (id: string, updates: Partial<WorldFaction>) => {
    const updated = factions.map(f => (f.id === id ? { ...f, ...updates } : f));
    onUpdateFactions(updated);
  };

  // Eliminar facción
  const handleDeleteFaction = (id: string) => {
    onUpdateFactions(factions.filter(f => f.id !== id));
    // Limpiar relaciones que involucren a esta facción
    onUpdateRelationships(relationships.filter(r => r.factionAId !== id && r.factionBId !== id));
    if (editingFactionId === id) setEditingFactionId(null);
  };

  // Añadir relación diplomática
  const handleAddRelationship = () => {
    if (factions.length < 2) return;
    const newRel: FactionRelationship = {
      id: `REL-${Date.now().toString().slice(-4)}`,
      factionAId: factions[0]?.name || factions[0]?.id || '',
      factionBId: factions[1]?.name || factions[1]?.id || '',
      status: 'Neutral',
      notes: 'Tratado de no agresión mutua'
    };
    onUpdateRelationships([...relationships, newRel]);
    setEditingRelationshipId(newRel.id);
  };

  const handleUpdateRelationship = (id: string, updates: Partial<FactionRelationship>) => {
    onUpdateRelationships(relationships.map(r => (r.id === id ? { ...r, ...updates } : r)));
  };

  const handleDeleteRelationship = (id: string) => {
    onUpdateRelationships(relationships.filter(r => r.id !== id));
    if (editingRelationshipId === id) setEditingRelationshipId(null);
  };

  return (
    <div className="space-y-6">
      {/* 1. Formas de Gobierno & Conflictos Globales */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-[#F3F4F6] flex items-center gap-2">
            <Crown className="w-4 h-4 text-amber-400" />
            <span>Formas de Gobierno & Estructura de Poder:</span>
          </label>
          <input
            type="text"
            value={governments.join(', ')}
            onChange={e => onUpdateGovernments(e.target.value.split(',').map(s => s.trim()).filter(Boolean))}
            placeholder="Monarquía Teocrática, Concilio de Gremios, Junta Militar..."
            className="w-full bg-[#181A24] border border-[#2A2E3D] rounded-xl px-3 py-2.5 text-xs text-[#E0E2EC] outline-hidden focus:border-emerald-500/50"
          />
          <p className="text-[10px] text-[#8A8F9E]">Separar con comas las entidades de gobierno vigentes.</p>
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-bold text-[#F3F4F6] flex items-center gap-2">
            <Swords className="w-4 h-4 text-rose-400" />
            <span>Conflictos Abiertos / Guerras Frías:</span>
          </label>
          <input
            type="text"
            value={conflicts.join(', ')}
            onChange={e => onUpdateConflicts(e.target.value.split(',').map(s => s.trim()).filter(Boolean))}
            placeholder="Disputa arancelaria de puertos, Caza de herejes en el bosque..."
            className="w-full bg-[#181A24] border border-[#2A2E3D] rounded-xl px-3 py-2.5 text-xs text-[#E0E2EC] outline-hidden focus:border-rose-500/50"
          />
          <p className="text-[10px] text-[#8A8F9E]">Tensiones activas que el motor utiliza para desencadenar eventos.</p>
        </div>
      </div>

      {/* 2. Lista de Facciones */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="text-sm font-bold text-[#F3F4F6] flex items-center gap-2">
              <Shield className="w-4 h-4 text-emerald-400" />
              <span>Facciones del Mundo ({factions.length})</span>
            </h4>
            <p className="text-xs text-[#8A8F9E]">
              Bandos organizados con ideología propia, reputación con el jugador y enemigos jurados.
            </p>
          </div>
          <button
            type="button"
            onClick={handleAddFaction}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Añadir Facción</span>
          </button>
        </div>

        {factions.length === 0 ? (
          <div className="p-6 rounded-2xl bg-[#151720] border border-dashed border-[#282C3C] text-center space-y-2">
            <Shield className="w-8 h-8 text-[#5A6072] mx-auto" />
            <p className="text-xs text-[#8A8F9E]">No hay facciones registradas en este mundo.</p>
            <button
              type="button"
              onClick={handleAddFaction}
              className="text-xs font-bold text-emerald-400 hover:underline cursor-pointer"
            >
              + Crear la primera facción
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {factions.map(faction => {
              const isEditing = editingFactionId === faction.id;
              return (
                <div
                  key={faction.id}
                  className={`rounded-2xl border transition-all p-4 space-y-3 ${
                    isEditing
                      ? 'bg-[#181B26] border-emerald-500/60 shadow-lg'
                      : 'bg-[#14161F] border-[#252837] hover:border-[#33384B]'
                  }`}
                >
                  {/* Fila superior de la tarjeta */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5">
                      <div
                        className="w-4 h-4 rounded-full shrink-0 border border-white/20 shadow-sm"
                        style={{ backgroundColor: faction.color }}
                      />
                      <div>
                        <span className="text-xs font-bold text-[#F3F4F6] block">
                          {faction.name}
                        </span>
                        <span className="text-[10px] font-mono text-[#8A8F9E]">
                          ID: {faction.id}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                        faction.reputationWithPlayer === 'Aliada' || faction.reputationWithPlayer === 'Amistosa'
                          ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                          : faction.reputationWithPlayer === 'Hostil'
                          ? 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                          : faction.reputationWithPlayer === 'Desconfiada'
                          ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                          : 'bg-[#202534] border-[#2E3345] text-[#A0A5B5]'
                      }`}>
                        {faction.reputationWithPlayer}
                      </span>
                      <button
                        type="button"
                        onClick={() => setEditingFactionId(isEditing ? null : faction.id)}
                        className="p-1 rounded-lg text-[#8A8F9E] hover:text-[#F3F4F6] hover:bg-[#202434] transition-colors cursor-pointer"
                        title={isEditing ? 'Cerrar edición' : 'Editar facción'}
                      >
                        {isEditing ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Edit3 className="w-3.5 h-3.5" />}
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteFaction(faction.id)}
                        className="p-1 rounded-lg text-[#8A8F9E] hover:text-rose-400 hover:bg-rose-950/30 transition-colors cursor-pointer"
                        title="Eliminar facción"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Resumen o Formulario de Edición */}
                  {isEditing ? (
                    <div className="space-y-3 pt-2 border-t border-[#25293A] text-xs">
                      <div>
                        <label className="text-[11px] font-bold text-[#8A8F9E] block mb-1">Nombre de la Facción:</label>
                        <input
                          type="text"
                          value={faction.name}
                          onChange={e => handleUpdateFaction(faction.id, { name: e.target.value })}
                          className="w-full bg-[#1A1D2A] border border-[#2E3344] rounded-xl px-3 py-1.5 text-xs text-[#E0E2EC] outline-hidden"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-[11px] font-bold text-[#8A8F9E] block mb-1">Color de Estandarte:</label>
                          <div className="flex items-center gap-1.5">
                            {FACTION_COLORS.map(c => (
                              <button
                                key={c}
                                type="button"
                                onClick={() => handleUpdateFaction(faction.id, { color: c })}
                                className={`w-5 h-5 rounded-full border transition-transform cursor-pointer ${
                                  faction.color === c ? 'scale-125 ring-2 ring-white' : 'opacity-70 hover:opacity-100'
                                }`}
                                style={{ backgroundColor: c }}
                              />
                            ))}
                          </div>
                        </div>
                        <div>
                          <label className="text-[11px] font-bold text-[#8A8F9E] block mb-1">Reputación Jugador:</label>
                          <select
                            value={faction.reputationWithPlayer}
                            onChange={e => handleUpdateFaction(faction.id, { reputationWithPlayer: e.target.value as any })}
                            className="w-full bg-[#1A1D2A] border border-[#2E3344] rounded-xl px-2.5 py-1.5 text-xs text-[#E0E2EC] outline-hidden"
                          >
                            {REPUTATIONS.map(r => (
                              <option key={r} value={r}>{r}</option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <div>
                        <label className="text-[11px] font-bold text-[#8A8F9E] block mb-1">Ideología & Doctrina:</label>
                        <textarea
                          rows={2}
                          value={faction.ideology}
                          onChange={e => handleUpdateFaction(faction.id, { ideology: e.target.value })}
                          className="w-full bg-[#1A1D2A] border border-[#2E3344] rounded-xl p-2.5 text-xs text-[#E0E2EC] outline-hidden"
                        />
                      </div>

                      <div>
                        <label className="text-[11px] font-bold text-[#8A8F9E] block mb-1">Descripción & Comportamiento:</label>
                        <textarea
                          rows={2}
                          value={faction.description}
                          onChange={e => handleUpdateFaction(faction.id, { description: e.target.value })}
                          className="w-full bg-[#1A1D2A] border border-[#2E3344] rounded-xl p-2.5 text-xs text-[#E0E2EC] outline-hidden"
                        />
                      </div>

                      <div>
                        <label className="text-[11px] font-bold text-[#8A8F9E] block mb-1">Enemigos Declarados (IDs o nombres):</label>
                        <input
                          type="text"
                          value={(faction.activeEnemies || []).join(', ')}
                          onChange={e => handleUpdateFaction(faction.id, { activeEnemies: e.target.value.split(',').map(s => s.trim()).filter(Boolean) })}
                          placeholder="FAC-02, Cultistas..."
                          className="w-full bg-[#1A1D2A] border border-[#2E3344] rounded-xl px-3 py-1.5 text-xs text-[#E0E2EC] outline-hidden"
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-1.5 text-xs text-[#8A8F9E]">
                      <p className="line-clamp-2 text-[#C4C8D6] text-[11px] leading-relaxed">
                        <strong className="text-[#A0A5B5]">Ideología:</strong> {faction.ideology}
                      </p>
                      <p className="line-clamp-2 text-[11px]">
                        <strong className="text-[#A0A5B5]">Descripción:</strong> {faction.description}
                      </p>
                      {(faction.activeEnemies || []).length > 0 && (
                        <p className="text-[10px] text-rose-300">
                          <strong>Hostil contra:</strong> {(faction.activeEnemies || []).join(', ')}
                        </p>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 3. Relaciones Diplomáticas entre Facciones */}
      <div className="space-y-3 pt-4 border-t border-[#232736]">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="text-sm font-bold text-[#F3F4F6] flex items-center gap-2">
              <HeartHandshake className="w-4 h-4 text-cyan-400" />
              <span>Matriz Diplomática entre Facciones ({relationships.length})</span>
            </h4>
            <p className="text-xs text-[#8A8F9E]">
              Pactos, guerras abiertas o alianzas formales que condicionan la ayuda de NPCs.
            </p>
          </div>
          {factions.length >= 2 && (
            <button
              type="button"
              onClick={handleAddRelationship}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#1F2432] hover:bg-[#282F42] border border-[#32394E] text-[#E0E2EC] font-bold text-xs transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4 text-cyan-400" />
              <span>Añadir Tratado</span>
            </button>
          )}
        </div>

        {relationships.length === 0 ? (
          <p className="text-xs text-[#6B7280] italic">
            Sin acuerdos diplomáticos explícitos. Las facciones mantendrán relaciones neutrales por omisión.
          </p>
        ) : (
          <div className="space-y-2">
            {relationships.map((rel, idx) => (
              <div
                key={rel.id || idx}
                className="p-3 rounded-xl bg-[#161822] border border-[#282C3C] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div className="flex flex-wrap items-center gap-2">
                  <input
                    type="text"
                    value={rel.factionAId}
                    onChange={e => handleUpdateRelationship(rel.id, { factionAId: e.target.value })}
                    className="bg-[#1C1F2B] border border-[#2E3344] rounded-lg px-2 py-1 font-bold text-[#F3F4F6] text-xs w-36 outline-hidden"
                  />
                  <span className="text-[#6B7280]">↔</span>
                  <select
                    value={rel.status}
                    onChange={e => handleUpdateRelationship(rel.id, { status: e.target.value as any })}
                    className={`rounded-lg px-2.5 py-1 text-xs font-bold border outline-hidden ${
                      rel.status === 'Hostil'
                        ? 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                        : rel.status === 'Alianza'
                        ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                        : rel.status === 'Pacto'
                        ? 'bg-cyan-500/10 border-cyan-500/30 text-cyan-300'
                        : 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                    }`}
                  >
                    <option value="Alianza">Alianza</option>
                    <option value="Pacto">Pacto</option>
                    <option value="Neutral">Neutral</option>
                    <option value="Rival">Rival</option>
                    <option value="Hostil">Hostil</option>
                  </select>
                  <span className="text-[#6B7280]">↔</span>
                  <input
                    type="text"
                    value={rel.factionBId}
                    onChange={e => handleUpdateRelationship(rel.id, { factionBId: e.target.value })}
                    className="bg-[#1C1F2B] border border-[#2E3344] rounded-lg px-2 py-1 font-bold text-[#F3F4F6] text-xs w-36 outline-hidden"
                  />
                </div>

                <div className="flex items-center gap-2 flex-1 sm:justify-end">
                  <input
                    type="text"
                    value={rel.notes || ''}
                    onChange={e => handleUpdateRelationship(rel.id, { notes: e.target.value })}
                    placeholder="Detalle o justificación del tratado..."
                    className="bg-[#1C1F2B] border border-[#2E3344] rounded-lg px-2.5 py-1 text-xs text-[#A0A5B5] flex-1 sm:max-w-xs outline-hidden"
                  />
                  <button
                    type="button"
                    onClick={() => handleDeleteRelationship(rel.id)}
                    className="p-1 text-[#6B7280] hover:text-rose-400 cursor-pointer"
                    title="Eliminar relación"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
