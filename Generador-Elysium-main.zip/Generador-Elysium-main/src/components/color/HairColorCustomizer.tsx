import React, { useState } from 'react';
import {
  BASIC_COLOR_SWATCHES,
  HAIR_COLOR_MODES
} from '../../data';
import { Sparkles, Palette, Scissors } from 'lucide-react';

interface HairColorCustomizerProps {
  value: string;
  onChange: (newValue: string) => void;
}

export const HairColorCustomizer: React.FC<HairColorCustomizerProps> = ({ value, onChange }) => {
  const [distFilter, setDistFilter] = useState<'all' | 'punta' | 'raíz' | 'mezcla' | 'sólido'>('all');
  
  // Custom hair color state
  const [mode, setMode] = useState<string>('dip_dye');
  const [color1Name, setColor1Name] = useState<string>('Negro Azabache');
  const [color1Hex, setColor1Hex] = useState<string>('#111317');
  const [color2Name, setColor2Name] = useState<string>('Azul Cian Eléctrico');
  const [color2Hex, setColor2Hex] = useState<string>('#06B6D4');
  const [glossEffect, setGlossEffect] = useState<boolean>(true);

  const buildCompiledString = (
    selectedMode = mode,
    c1 = color1Name,
    c2 = color2Name,
    gloss = glossEffect
  ) => {
    let result = '';
    const glossStr = gloss ? ' con acabado sedoso brillante' : '';

    switch (selectedMode) {
      case 'dip_dye':
        result = `Color base ${c1} con puntas teñidas en degradado ${c2} (punta / dip-dye)${glossStr}`;
        break;
      case 'ombre_tips':
        result = `Degradado ombré continuo (mezcla fluida) desde raíz ${c1} hasta puntas ${c2}${glossStr}`;
        break;
      case 'shadow_roots':
        result = `Raíces sombreadas en ${c1} (raíz / shadow roots) difuminadas en cuerpo de cabello ${c2}${glossStr}`;
        break;
      case 'split':
        result = `Estilo split bicolor dividido al centro: mitad izquierda ${c1} y mitad derecha ${c2} (mezcla split 50/50)${glossStr}`;
        break;
      case 'underdye':
        result = `Color base ${c1} con capa interior oculta (mezcla under-dye) en ${c2}${glossStr}`;
        break;
      case 'highlights':
        result = `Color base ${c1} con mechas frontales y reflejos en ${c2} (mezcla money piece)${glossStr}`;
        break;
      case 'single':
      default:
        result = `${c1}${glossStr}`;
        break;
    }
    return result;
  };

  const handleApplyCustom = (
    newMode = mode,
    c1 = color1Name,
    c2 = color2Name,
    gloss = glossEffect
  ) => {
    const compiled = buildCompiledString(newMode, c1, c2, gloss);
    onChange(compiled);
  };

  const filteredModes = HAIR_COLOR_MODES.filter(m => {
    if (distFilter === 'all') return true;
    return m.category === distFilter;
  });

  // Render dynamic CSS preview based on the styling mode
  const renderHairVisualRibbon = () => {
    switch (mode) {
      case 'split':
        return (
          <div className="w-full h-10 rounded-xl overflow-hidden flex border border-[#2A2D35] shadow-md relative">
            <div className="w-1/2 h-full transition-all duration-300" style={{ backgroundColor: color1Hex }} />
            <div className="w-1/2 h-full transition-all duration-300" style={{ backgroundColor: color2Hex }} />
            <div className="absolute inset-0 flex items-center justify-between px-3 text-[10px] font-mono font-bold text-white drop-shadow-md pointer-events-none">
              <span>Izq: {color1Name}</span>
              <span>Der: {color2Name}</span>
            </div>
          </div>
        );
      case 'dip_dye':
        return (
          <div className="w-full h-10 rounded-xl overflow-hidden border border-[#2A2D35] shadow-md relative flex flex-col">
            <div className="h-[65%] w-full transition-all duration-300" style={{ backgroundColor: color1Hex }} />
            <div className="h-[35%] w-full transition-all duration-300" style={{ backgroundColor: color2Hex }} />
            <div className="absolute inset-0 flex items-center justify-between px-3 text-[10px] font-mono font-bold text-white drop-shadow-md pointer-events-none">
              <span>Base: {color1Name}</span>
              <span>Puntas Dip-Dye: {color2Name}</span>
            </div>
          </div>
        );
      case 'shadow_roots':
        return (
          <div className="w-full h-10 rounded-xl overflow-hidden border border-[#2A2D35] shadow-md relative flex flex-col">
            <div
              className="w-full h-full transition-all duration-300"
              style={{
                background: `linear-gradient(180deg, ${color1Hex} 0%, ${color1Hex} 25%, ${color2Hex} 55%, ${color2Hex} 100%)`
              }}
            />
            <div className="absolute inset-0 flex items-center justify-between px-3 text-[10px] font-mono font-bold text-white drop-shadow-md pointer-events-none">
              <span>Raíz: {color1Name}</span>
              <span>Cuerpo: {color2Name}</span>
            </div>
          </div>
        );
      case 'underdye':
        return (
          <div className="w-full h-10 rounded-xl overflow-hidden border border-[#2A2D35] shadow-md relative flex">
            <div className="w-3/4 h-full transition-all duration-300" style={{ backgroundColor: color1Hex }} />
            <div className="w-1/4 h-full transition-all duration-300 border-l border-white/20" style={{ backgroundColor: color2Hex }} />
            <div className="absolute inset-0 flex items-center justify-between px-3 text-[10px] font-mono font-bold text-white drop-shadow-md pointer-events-none">
              <span>Exterior: {color1Name}</span>
              <span>Under-dye: {color2Name}</span>
            </div>
          </div>
        );
      case 'highlights':
        return (
          <div
            className="w-full h-10 rounded-xl overflow-hidden border border-[#2A2D35] shadow-md relative transition-all duration-300"
            style={{
              background: `repeating-linear-gradient(90deg, ${color1Hex} 0px, ${color1Hex} 28px, ${color2Hex} 28px, ${color2Hex} 38px)`
            }}
          >
            <div className="absolute inset-0 flex items-center justify-between px-3 text-[10px] font-mono font-bold text-white drop-shadow-md pointer-events-none">
              <span>Base: {color1Name}</span>
              <span>Mechas: {color2Name}</span>
            </div>
          </div>
        );
      case 'ombre_tips':
      default:
        return (
          <div
            className="w-full h-10 rounded-xl overflow-hidden border border-[#2A2D35] shadow-md relative transition-all duration-300"
            style={{
              background: `linear-gradient(180deg, ${color1Hex} 0%, ${color2Hex} 100%)`
            }}
          >
            <div className="absolute inset-0 flex items-center justify-between px-3 text-[10px] font-mono font-bold text-white drop-shadow-md pointer-events-none">
              <span>Raíz: {color1Name}</span>
              <span>Puntas Ombré: {color2Name}</span>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="bg-[#12141A] border border-[#2A2D35] rounded-2xl p-5 space-y-5">
      {/* Header & Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#222222]">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 rounded-xl bg-[#C9A050]/10 border border-[#C9A050]/30 flex items-center justify-center text-[#C9A050]">
            <Scissors className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-[#E0E0E0] flex items-center gap-1.5">
              Coloración de Cabello, Puntas & Degradados
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-[#C9A050]/20 text-[#C9A050] border border-[#C9A050]/30">
                Bicolor & Ombré
              </span>
            </h4>
            <p className="text-[11px] text-[#888888]">
              Personaliza cabello negro con puntas de colores (cian, rojo, blanco), estilos split, shadow root o under-dye
            </p>
          </div>
        </div>

        {/* Bicolor y Mechas Badge */}
        <div className="flex items-center gap-1.5 bg-[#181A20] px-3 py-1.5 rounded-xl border border-[#2A2D35] text-xs font-semibold text-[#C9A050]">
          <Palette className="w-3.5 h-3.5" />
          Bicolor y Mechas / Degradados
        </div>
      </div>

      {/* Distribution Quick Category Filters */}
      <div className="flex flex-wrap items-center gap-1.5 bg-[#15171C] p-2 rounded-xl border border-[#2A2D35] text-xs">
        <span className="text-[10px] text-[#888888] font-mono uppercase mr-1 flex items-center gap-1">
          <Palette className="w-3 h-3 text-[#C9A050]" />
          Distribución:
        </span>
        <button
          type="button"
          onClick={() => setDistFilter('all')}
          className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
            distFilter === 'all'
              ? 'bg-[#C9A050] text-[#0A0B0E]'
              : 'bg-[#181A20] text-[#888888] hover:text-[#E0E0E0]'
          }`}
        >
          Todas
        </button>
        <button
          type="button"
          onClick={() => setDistFilter('punta')}
          className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
            distFilter === 'punta'
              ? 'bg-[#C9A050] text-[#0A0B0E]'
              : 'bg-[#181A20] text-[#888888] hover:text-[#E0E0E0]'
          }`}
        >
          📍 Puntas (Dip-Dye)
        </button>
        <button
          type="button"
          onClick={() => setDistFilter('raíz')}
          className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
            distFilter === 'raíz'
              ? 'bg-[#C9A050] text-[#0A0B0E]'
              : 'bg-[#181A20] text-[#888888] hover:text-[#E0E0E0]'
          }`}
        >
          🌱 Raíz (Shadow Roots)
        </button>
        <button
          type="button"
          onClick={() => setDistFilter('mezcla')}
          className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
            distFilter === 'mezcla'
              ? 'bg-[#C9A050] text-[#0A0B0E]'
              : 'bg-[#181A20] text-[#888888] hover:text-[#E0E0E0]'
          }`}
        >
          🎨 Mezcla (Ombré / Split / Under-dye)
        </button>
        <button
          type="button"
          onClick={() => setDistFilter('sólido')}
          className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
            distFilter === 'sólido'
              ? 'bg-[#C9A050] text-[#0A0B0E]'
              : 'bg-[#181A20] text-[#888888] hover:text-[#E0E0E0]'
          }`}
        >
          ◼️ Sólido
        </button>
      </div>

      {/* Visual Live Strand / Ribbon Preview */}
      <div className="bg-[#181A20] border border-[#2A2D35] rounded-xl p-4 space-y-2">
        <div className="flex items-center justify-between text-xs text-[#888888]">
          <span className="font-mono flex items-center gap-1.5 text-[#E0E0E0]">
            <Palette className="w-3.5 h-3.5 text-[#C9A050]" />
            Previsualización Dinámica de Estilo Capilar:
          </span>
          <span className="text-[10px] text-[#C9A050] uppercase font-mono">
            {mode.replace('_', ' ').toUpperCase()}
          </span>
        </div>

        {/* Dynamic Ribbon */}
        {renderHairVisualRibbon()}

        {/* Value Tag */}
        <div className="flex items-center justify-between text-[11px] pt-1">
          <span className="text-[#888888] font-mono">Prompt resultante:</span>
          <span className="font-semibold text-[#C9A050] bg-[#12141A] px-2.5 py-1 rounded-lg border border-[#2A2D35] truncate max-w-[70%]">
            {value || 'Negro Azabache'}
          </span>
        </div>
      </div>

      {/* CUSTOM BICOLOR & MECHAS */}
      <div className="space-y-5">
        {/* Mode Selector */}
          <div>
            <label className="block text-xs font-medium text-[#AAAAAA] mb-2">
              1. Selecciona la Distribución de Color (Punta, Raíz o Mezcla):
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
              {filteredModes.map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => {
                    setMode(m.id);
                    handleApplyCustom(m.id, color1Name, color2Name, glossEffect);
                  }}
                  className={`p-2.5 rounded-xl border text-left text-xs transition-all ${
                    mode === m.id
                      ? 'bg-[#1E222B] border-[#C9A050] text-[#C9A050] font-bold shadow-xs'
                      : 'bg-[#15171C] border-[#2A2D35] text-[#888888] hover:bg-[#1A1D24] hover:text-[#E0E0E0]'
                  }`}
                >
                  <div className="font-semibold text-xs flex items-center justify-between">
                    <span>{m.name}</span>
                    <span className="text-[9px] uppercase font-mono px-1.5 py-0.5 rounded bg-black/40 text-[#A0A0A0]">
                      {m.category}
                    </span>
                  </div>
                  <div className="text-[10px] text-[#666666] mt-0.5">{m.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Color 1 & Color 2 Selectors */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            {/* Color 1 */}
            <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#E0E0E0] flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: color1Hex }} />
                  {mode === 'split' ? 'Mitad Izquierda' : mode === 'underdye' ? 'Capa Exterior Principal' : 'Color Base / Raíz'}
                </span>
                <input
                  type="color"
                  value={color1Hex}
                  onChange={(e) => {
                    setColor1Hex(e.target.value);
                    handleApplyCustom(mode, color1Name, color2Name, glossEffect);
                  }}
                  className="w-6 h-6 rounded cursor-pointer bg-transparent border-0"
                />
              </div>

              <div>
                <label className="block text-[11px] text-[#888888] mb-1">Nombre / Tono descriptivo:</label>
                <input
                  type="text"
                  value={color1Name}
                  onChange={(e) => {
                    setColor1Name(e.target.value);
                    handleApplyCustom(mode, e.target.value, color2Name, glossEffect);
                  }}
                  placeholder="ej. Negro Azabache, Castaño Oscuro..."
                  className="w-full bg-[#181A20] border border-[#2A2D35] rounded-lg p-2 text-xs text-[#E0E0E0]"
                />
              </div>

              {/* Swatches */}
              <div>
                <label className="block text-[10px] text-[#888888] mb-1.5 font-mono uppercase">Paleta Rápida:</label>
                <div className="flex flex-wrap gap-1.5">
                  {BASIC_COLOR_SWATCHES.map((swatch) => (
                    <button
                      key={swatch.id}
                      type="button"
                      title={swatch.name}
                      onClick={() => {
                        setColor1Name(swatch.name);
                        setColor1Hex(swatch.hex);
                        handleApplyCustom(mode, swatch.name, color2Name, glossEffect);
                      }}
                      className="w-6 h-6 rounded-lg border border-white/20 hover:scale-110 transition-transform relative"
                      style={{ backgroundColor: swatch.hex }}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Color 2 */}
            <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#E0E0E0] flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: color2Hex }} />
                  {mode === 'split' ? 'Mitad Derecha' : mode === 'underdye' ? 'Capa Inferior Oculta' : mode === 'highlights' ? 'Mechas / Mechones' : 'Color de Puntas / Acento'}
                </span>
                <input
                  type="color"
                  value={color2Hex}
                  onChange={(e) => {
                    setColor2Hex(e.target.value);
                    handleApplyCustom(mode, color1Name, color2Name, glossEffect);
                  }}
                  className="w-6 h-6 rounded cursor-pointer bg-transparent border-0"
                />
              </div>

              <div>
                <label className="block text-[11px] text-[#888888] mb-1">Nombre / Tono descriptivo:</label>
                <input
                  type="text"
                  value={color2Name}
                  onChange={(e) => {
                    setColor2Name(e.target.value);
                    handleApplyCustom(mode, color1Name, e.target.value, glossEffect);
                  }}
                  placeholder="ej. Azul Cian Eléctrico, Rojo Fuego, Blanco Platino..."
                  className="w-full bg-[#181A20] border border-[#2A2D35] rounded-lg p-2 text-xs text-[#E0E0E0]"
                />
              </div>

              {/* Swatches */}
              <div>
                <label className="block text-[10px] text-[#888888] mb-1.5 font-mono uppercase">Paleta Rápida:</label>
                <div className="flex flex-wrap gap-1.5">
                  {BASIC_COLOR_SWATCHES.map((swatch) => (
                    <button
                      key={swatch.id}
                      type="button"
                      title={swatch.name}
                      onClick={() => {
                        setColor2Name(swatch.name);
                        setColor2Hex(swatch.hex);
                        handleApplyCustom(mode, color1Name, swatch.name, glossEffect);
                      }}
                      className="w-6 h-6 rounded-lg border border-white/20 hover:scale-110 transition-transform relative"
                      style={{ backgroundColor: swatch.hex }}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Hair Gloss / Silky Finish */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-[#15171C] border border-[#2A2D35]">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-[#C9A050]" />
              <div>
                <div className="text-xs font-semibold text-[#E0E0E0]">Brillo Sedoso & Cel-Shading Lustroso</div>
                <div className="text-[10px] text-[#888888]">Añade reflejos de luz de estudio anime manhwa en las transiciones</div>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={glossEffect}
                onChange={(e) => {
                  setGlossEffect(e.target.checked);
                  handleApplyCustom(mode, color1Name, color2Name, e.target.checked);
                }}
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-[#2A2D35] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#C9A050]"></div>
            </label>
          </div>
        </div>
    </div>
  );
};
