import React, { useState } from 'react';
import {
  BASIC_COLOR_SWATCHES,
  FABRIC_COLOR_MODES
} from '../../data';
import { Palette, Shirt, Layers, Sparkles } from 'lucide-react';

interface FabricColorCustomizerProps {
  value: string;
  onChange: (newValue: string) => void;
  garmentName?: string;
}

export const FabricColorCustomizer: React.FC<FabricColorCustomizerProps> = ({
  value,
  onChange,
  garmentName = 'Prenda'
}) => {
  const [distFilter, setDistFilter] = useState<'all' | 'punta' | 'raíz' | 'mezcla' | 'sólido'>('all');

  // Custom dual-color state
  const [mode, setMode] = useState<string>('punta_dobladillo');
  const [color1Name, setColor1Name] = useState<string>('Negro');
  const [color1Hex, setColor1Hex] = useState<string>('#111317');
  const [color2Name, setColor2Name] = useState<string>('Dorado');
  const [color2Hex, setColor2Hex] = useState<string>('#F59E0B');
  const [metallicThread, setMetallicThread] = useState<boolean>(false);

  const buildCompiledString = (
    selectedMode = mode,
    c1 = color1Name,
    c2 = color2Name,
    goldThread = metallicThread
  ) => {
    let result = '';
    const metallicStr = goldThread ? ' con filigranas y costuras en hilo reflectante' : '';

    switch (selectedMode) {
      case 'punta_dobladillo':
        result = `Color base ${c1} con remates, dobladillos y puntas en ${c2} (punta / bordes contrastantes)${metallicStr}`;
        break;
      case 'mezcla_degradado':
        result = `Degradado ombré continuo (mezcla fluida) desde ${c1} hasta ${c2} en el tejido${metallicStr}`;
        break;
      case 'raiz_cuello':
        result = `Canesú superior y cuello en ${c2} (raíz de la prenda) con cuerpo principal en ${c1}${metallicStr}`;
        break;
      case 'forro_interior':
        result = `Exterior en ${c1} con forro interior sedoso en contraste ${c2} (mezcla por capas)${metallicStr}`;
        break;
      case 'patron_bitono':
        result = `Base en ${c1} con patrón y bordados jacquard en ${c2} (mezcla texturizada bitono)${metallicStr}`;
        break;
      case 'split_vertical':
        result = `Diseño bicolor dividido al centro: mitad ${c1} y mitad ${c2} (mezcla split asimétrica)${metallicStr}`;
        break;
      case 'single':
      default:
        result = `${c1}${metallicStr}`;
        break;
    }
    return result;
  };

  const handleApplyCustom = (
    newMode = mode,
    c1 = color1Name,
    c2 = color2Name,
    goldThread = metallicThread
  ) => {
    const compiled = buildCompiledString(newMode, c1, c2, goldThread);
    onChange(compiled);
  };

  // Render Visual Dynamic Fabric Ribbon Preview
  const renderFabricVisualRibbon = () => {
    switch (mode) {
      case 'punta_dobladillo':
        return (
          <div className="w-full h-10 rounded-xl overflow-hidden border border-[#2A2D35] shadow-md relative flex flex-col justify-between">
            <div className="h-[75%] w-full transition-all duration-300" style={{ backgroundColor: color1Hex }} />
            <div className="h-[25%] w-full border-t-2 border-dashed border-white/40 transition-all duration-300" style={{ backgroundColor: color2Hex }} />
            <div className="absolute inset-0 flex items-center justify-between px-3 text-[10px] font-mono font-bold text-white drop-shadow-md pointer-events-none">
              <span>Cuerpo: {color1Name}</span>
              <span>📍 Puntas / Dobladillos: {color2Name}</span>
            </div>
          </div>
        );
      case 'raiz_cuello':
        return (
          <div className="w-full h-10 rounded-xl overflow-hidden border border-[#2A2D35] shadow-md relative flex flex-col">
            <div className="h-[30%] w-full border-b border-white/30 transition-all duration-300" style={{ backgroundColor: color2Hex }} />
            <div className="h-[70%] w-full transition-all duration-300" style={{ backgroundColor: color1Hex }} />
            <div className="absolute inset-0 flex items-center justify-between px-3 text-[10px] font-mono font-bold text-white drop-shadow-md pointer-events-none">
              <span>🌱 Raíz / Cuello: {color2Name}</span>
              <span>Cuerpo: {color1Name}</span>
            </div>
          </div>
        );
      case 'mezcla_degradado':
        return (
          <div
            className="w-full h-10 rounded-xl overflow-hidden border border-[#2A2D35] shadow-md relative transition-all duration-300"
            style={{
              background: `linear-gradient(90deg, ${color1Hex} 0%, ${color2Hex} 100%)`
            }}
          >
            <div className="absolute inset-0 flex items-center justify-between px-3 text-[10px] font-mono font-bold text-white drop-shadow-md pointer-events-none">
              <span>Primario: {color1Name}</span>
              <span>🎨 Mezcla Ombré: {color2Name}</span>
            </div>
          </div>
        );
      case 'forro_interior':
        return (
          <div className="w-full h-10 rounded-xl overflow-hidden border border-[#2A2D35] shadow-md relative flex">
            <div className="w-[70%] h-full transition-all duration-300" style={{ backgroundColor: color1Hex }} />
            <div className="w-[30%] h-full border-l-2 border-white/30 transition-all duration-300" style={{ backgroundColor: color2Hex }} />
            <div className="absolute inset-0 flex items-center justify-between px-3 text-[10px] font-mono font-bold text-white drop-shadow-md pointer-events-none">
              <span>Exterior: {color1Name}</span>
              <span>Forro Oculto: {color2Name}</span>
            </div>
          </div>
        );
      case 'patron_bitono':
        return (
          <div
            className="w-full h-10 rounded-xl overflow-hidden border border-[#2A2D35] shadow-md relative transition-all duration-300"
            style={{
              backgroundColor: color1Hex,
              backgroundImage: `radial-gradient(${color2Hex} 2px, transparent 2px)`,
              backgroundSize: '12px 12px'
            }}
          >
            <div className="absolute inset-0 flex items-center justify-between px-3 text-[10px] font-mono font-bold text-white drop-shadow-md pointer-events-none">
              <span>Fondo: {color1Name}</span>
              <span>Brocado/Bordado: {color2Name}</span>
            </div>
          </div>
        );
      case 'split_vertical':
        return (
          <div className="w-full h-10 rounded-xl overflow-hidden flex border border-[#2A2D35] shadow-md relative">
            <div className="w-1/2 h-full transition-all duration-300" style={{ backgroundColor: color1Hex }} />
            <div className="w-1/2 h-full transition-all duration-300" style={{ backgroundColor: color2Hex }} />
            <div className="absolute inset-0 flex items-center justify-between px-3 text-[10px] font-mono font-bold text-white drop-shadow-md pointer-events-none">
              <span>Mitad Izq: {color1Name}</span>
              <span>Mitad Der: {color2Name}</span>
            </div>
          </div>
        );
      case 'single':
      default:
        return (
          <div
            className="w-full h-10 rounded-xl overflow-hidden border border-[#2A2D35] shadow-md relative transition-all duration-300 flex items-center px-3"
            style={{ backgroundColor: color1Hex }}
          >
            <span className="text-[10px] font-mono font-bold text-white drop-shadow-md pointer-events-none">
              Sólido Uniforme: {color1Name}
            </span>
          </div>
        );
    }
  };

  const filteredModes = FABRIC_COLOR_MODES.filter(m => {
    if (distFilter === 'all') return true;
    return m.category === distFilter;
  });

  return (
    <div className="bg-[#12141A] border border-[#2A2D35] rounded-2xl p-5 space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#222222]">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 rounded-xl bg-[#C9A050]/10 border border-[#C9A050]/30 flex items-center justify-center text-[#C9A050]">
            <Shirt className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-[#E0E0E0] flex items-center gap-1.5">
              Color & Textura de Tela: <span className="text-[#C9A050] font-mono">{garmentName}</span>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-[#C9A050]/20 text-[#C9A050] border border-[#C9A050]/30">
                Punta • Raíz • Mezcla
              </span>
            </h4>
            <p className="text-[11px] text-[#888888]">
              Configura colores primarios y secundarios para degradados de tela, dobladillos/puntas, cuellos o forros
            </p>
          </div>
        </div>

        {/* Bicolor y Mechas / Texturas Badge */}
        <div className="flex items-center gap-1.5 bg-[#181A20] px-3 py-1.5 rounded-xl border border-[#2A2D35] text-xs font-semibold text-[#C9A050]">
          <Palette className="w-3.5 h-3.5" />
          Bicolor y Mechas / Texturas
        </div>
      </div>

      {/* Distribution Quick Category Filters */}
      <div className="flex flex-wrap items-center gap-1.5 bg-[#15171C] p-2 rounded-xl border border-[#2A2D35] text-xs">
        <span className="text-[10px] text-[#888888] font-mono uppercase mr-1 flex items-center gap-1">
          <Layers className="w-3 h-3 text-[#C9A050]" />
          Distribución:
        </span>
        <button
          type="button"
          onClick={() => setDistFilter('all')}
          className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
            distFilter === 'all'
              ? 'bg-[#C9A050] text-[#0A0B0E]'
              : 'bg-[#181A20] text-[#888888] hover:text-[#E0E0E0]'
          }`}
        >
          Todas
        </button>
        <button
          type="button"
          onClick={() => setDistFilter('punta')}
          className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
            distFilter === 'punta'
              ? 'bg-[#C9A050] text-[#0A0B0E]'
              : 'bg-[#181A20] text-[#888888] hover:text-[#E0E0E0]'
          }`}
        >
          📍 Puntas / Dobladillos
        </button>
        <button
          type="button"
          onClick={() => setDistFilter('raíz')}
          className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
            distFilter === 'raíz'
              ? 'bg-[#C9A050] text-[#0A0B0E]'
              : 'bg-[#181A20] text-[#888888] hover:text-[#E0E0E0]'
          }`}
        >
          🌱 Raíz / Cuello Superior
        </button>
        <button
          type="button"
          onClick={() => setDistFilter('mezcla')}
          className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
            distFilter === 'mezcla'
              ? 'bg-[#C9A050] text-[#0A0B0E]'
              : 'bg-[#181A20] text-[#888888] hover:text-[#E0E0E0]'
          }`}
        >
          🎨 Mezcla / Degradado Ombré
        </button>
        <button
          type="button"
          onClick={() => setDistFilter('sólido')}
          className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
            distFilter === 'sólido'
              ? 'bg-[#C9A050] text-[#0A0B0E]'
              : 'bg-[#181A20] text-[#888888] hover:text-[#E0E0E0]'
          }`}
        >
          ◼️ Monocromático
        </button>
      </div>

      {/* Visual Live Fabric Preview */}
      <div className="bg-[#181A20] border border-[#2A2D35] rounded-xl p-4 space-y-2">
        <div className="flex items-center justify-between text-xs text-[#888888]">
          <span className="font-mono flex items-center gap-1.5 text-[#E0E0E0]">
            <Palette className="w-3.5 h-3.5 text-[#C9A050]" />
            Previsualización de Textura y Degradado de Tela:
          </span>
          <span className="text-[10px] text-[#C9A050] uppercase font-mono">
            {mode.replace('_', ' ').toUpperCase()}
          </span>
        </div>

        {/* Dynamic Ribbon */}
        {renderFabricVisualRibbon()}

        {/* Value Tag */}
        <div className="flex items-center justify-between text-[11px] pt-1">
          <span className="text-[#888888] font-mono">Prompt resultante:</span>
          <span className="font-semibold text-[#C9A050] bg-[#12141A] px-2.5 py-1 rounded-lg border border-[#2A2D35] truncate max-w-[70%]">
            {value || color1Name}
          </span>
        </div>
      </div>

      {/* CUSTOM DUAL-COLOR & TEXTURE */}
      <div className="space-y-5">
        {/* Mode Selector */}
          <div>
            <label className="block text-xs font-medium text-[#AAAAAA] mb-2">
              1. Selecciona la Distribución de Color en la Prenda (Punta, Raíz, Mezcla):
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
              {filteredModes.map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => {
                    setMode(m.id);
                    handleApplyCustom(m.id, color1Name, color2Name, metallicThread);
                  }}
                  className={`p-2.5 rounded-xl border text-left text-xs transition-all ${
                    mode === m.id
                      ? 'bg-[#1E222B] border-[#C9A050] text-[#C9A050] font-bold shadow-xs'
                      : 'bg-[#15171C] border-[#2A2D35] text-[#888888] hover:bg-[#1A1D24] hover:text-[#E0E0E0]'
                  }`}
                >
                  <div className="font-semibold text-xs flex items-center justify-between">
                    <span>{m.name}</span>
                    <span className="text-[9px] uppercase font-mono px-1.5 py-0.5 rounded bg-black/40 text-[#A0A0A0]">
                      {m.category}
                    </span>
                  </div>
                  <div className="text-[10px] text-[#666666] mt-0.5">{m.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Color 1 & Color 2 Selectors (Optimized space / dual-color on demand) */}
          {mode === 'solido' ? (
            <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#E0E0E0] flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: color1Hex }} />
                  Color Sólido de la Prenda
                </span>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      setMode('mezcla_degradado');
                      setDistFilter('mezcla');
                      handleApplyCustom('mezcla_degradado', color1Name, color2Name, metallicThread);
                    }}
                    className="text-[11px] text-[#C9A050] hover:text-[#E0C070] font-semibold flex items-center gap-1 cursor-pointer bg-[#C9A050]/10 px-2.5 py-1 rounded-lg border border-[#C9A050]/30 transition-colors"
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>+ Activar Doble Color / Mezcla</span>
                  </button>
                  <input
                    type="color"
                    value={color1Hex}
                    onChange={(e) => {
                      setColor1Hex(e.target.value);
                      handleApplyCustom(mode, color1Name, color2Name, metallicThread);
                    }}
                    className="w-6 h-6 rounded cursor-pointer bg-transparent border-0"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] text-[#888888] mb-1">Nombre / Tono descriptivo:</label>
                <input
                  type="text"
                  value={color1Name}
                  onChange={(e) => {
                    setColor1Name(e.target.value);
                    handleApplyCustom(mode, e.target.value, color2Name, metallicThread);
                  }}
                  placeholder="ej. Negro Ébano, Blanco, Azul Zafiro..."
                  className="w-full bg-[#181A20] border border-[#2A2D35] rounded-lg p-2 text-xs text-[#E0E0E0]"
                />
              </div>

              {/* Swatches */}
              <div>
                <label className="block text-[10px] text-[#888888] mb-1.5 font-mono uppercase">Paleta Rápida:</label>
                <div className="flex flex-wrap gap-1.5">
                  {BASIC_COLOR_SWATCHES.map((swatch) => (
                    <button
                      key={swatch.id}
                      type="button"
                      title={swatch.name}
                      onClick={() => {
                        setColor1Name(swatch.name);
                        setColor1Hex(swatch.hex);
                        handleApplyCustom(mode, swatch.name, color2Name, metallicThread);
                      }}
                      className="w-6 h-6 rounded-lg border border-white/20 hover:scale-110 transition-transform relative"
                      style={{ backgroundColor: swatch.hex }}
                    />
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              {/* Color 1 */}
              <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#E0E0E0] flex items-center gap-1.5">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: color1Hex }} />
                    Color Primario (Base / Fondo)
                  </span>
                  <input
                    type="color"
                    value={color1Hex}
                    onChange={(e) => {
                      setColor1Hex(e.target.value);
                      handleApplyCustom(mode, color1Name, color2Name, metallicThread);
                    }}
                    className="w-6 h-6 rounded cursor-pointer bg-transparent border-0"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-[#888888] mb-1">Nombre / Tono descriptivo:</label>
                  <input
                    type="text"
                    value={color1Name}
                    onChange={(e) => {
                      setColor1Name(e.target.value);
                      handleApplyCustom(mode, e.target.value, color2Name, metallicThread);
                    }}
                    placeholder="ej. Negro Ébano, Blanco, Azul Zafiro..."
                    className="w-full bg-[#181A20] border border-[#2A2D35] rounded-lg p-2 text-xs text-[#E0E0E0]"
                  />
                </div>

                {/* Swatches */}
                <div>
                  <label className="block text-[10px] text-[#888888] mb-1.5 font-mono uppercase">Paleta Rápida:</label>
                  <div className="flex flex-wrap gap-1.5">
                    {BASIC_COLOR_SWATCHES.map((swatch) => (
                      <button
                        key={swatch.id}
                        type="button"
                        title={swatch.name}
                        onClick={() => {
                          setColor1Name(swatch.name);
                          setColor1Hex(swatch.hex);
                          handleApplyCustom(mode, swatch.name, color2Name, metallicThread);
                        }}
                        className="w-6 h-6 rounded-lg border border-white/20 hover:scale-110 transition-transform relative"
                        style={{ backgroundColor: swatch.hex }}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* Color 2 */}
              <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#E0E0E0] flex items-center gap-1.5">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: color2Hex }} />
                    {mode === 'punta_dobladillo'
                      ? '📍 Color Secundario (Puntas & Dobladillos)'
                      : mode === 'raiz_cuello'
                      ? '🌱 Color Secundario (Raíz & Cuello)'
                      : mode === 'mezcla_degradado'
                      ? '🎨 Color Secundario (Mezcla Ombré)'
                      : mode === 'forro_interior'
                      ? 'Color de Forro Interior'
                      : 'Color Secundario (Acento / Brocado)'}
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setMode('solido');
                        setDistFilter('sólido');
                        handleApplyCustom('solido', color1Name, '', metallicThread);
                      }}
                      className="text-[10px] text-[#888888] hover:text-red-400 font-mono transition-colors"
                    >
                      × Quitar Mezcla
                    </button>
                    <input
                      type="color"
                      value={color2Hex}
                      onChange={(e) => {
                        setColor2Hex(e.target.value);
                        handleApplyCustom(mode, color1Name, color2Name, metallicThread);
                      }}
                      className="w-6 h-6 rounded cursor-pointer bg-transparent border-0"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] text-[#888888] mb-1">Nombre / Tono descriptivo:</label>
                  <input
                    type="text"
                    value={color2Name}
                    onChange={(e) => {
                      setColor2Name(e.target.value);
                      handleApplyCustom(mode, color1Name, e.target.value, metallicThread);
                    }}
                    placeholder="ej. Dorado Solar, Rojo Rubí, Azul Cian..."
                    className="w-full bg-[#181A20] border border-[#2A2D35] rounded-lg p-2 text-xs text-[#E0E0E0]"
                  />
                </div>

                {/* Swatches */}
                <div>
                  <label className="block text-[10px] text-[#888888] mb-1.5 font-mono uppercase">Paleta Rápida:</label>
                  <div className="flex flex-wrap gap-1.5">
                    {BASIC_COLOR_SWATCHES.map((swatch) => (
                      <button
                        key={swatch.id}
                        type="button"
                        title={swatch.name}
                        onClick={() => {
                          setColor2Name(swatch.name);
                          setColor2Hex(swatch.hex);
                          handleApplyCustom(mode, color1Name, swatch.name, metallicThread);
                        }}
                        className="w-6 h-6 rounded-lg border border-white/20 hover:scale-110 transition-transform relative"
                        style={{ backgroundColor: swatch.hex }}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Extra: Metallic Thread / Filigranas */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-[#15171C] border border-[#2A2D35]">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-[#C9A050]" />
              <div>
                <div className="text-xs font-semibold text-[#E0E0E0]">Bordado con Hilo Metálico Reflectante</div>
                <div className="text-[10px] text-[#888888]">Añade costuras y filigranas de hilo de oro/plata reflectante en los dobladillos y uniones</div>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={metallicThread}
                onChange={(e) => {
                  setMetallicThread(e.target.checked);
                  handleApplyCustom(mode, color1Name, color2Name, e.target.checked);
                }}
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-[#2A2D35] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#C9A050]"></div>
            </label>
          </div>
        </div>
    </div>
  );
};
