import React, { useState } from 'react';
import {
  BASIC_COLOR_SWATCHES,
  EYE_COLOR_MODES
} from '../../data';
import { Eye, Sparkles, Palette, RefreshCw } from 'lucide-react';

interface EyeColorCustomizerProps {
  value: string;
  onChange: (newValue: string) => void;
}

export const EyeColorCustomizer: React.FC<EyeColorCustomizerProps> = ({ value, onChange }) => {
  const [distFilter, setDistFilter] = useState<'all' | 'heterocromía' | 'raíz' | 'mezcla' | 'sólido'>('all');
  
  // Custom mode state
  const [mode, setMode] = useState<string>('gradient_vertical');
  const [color1Name, setColor1Name] = useState<string>('Azul Zafiro');
  const [color1Hex, setColor1Hex] = useState<string>('#1E3A8A');
  const [color2Name, setColor2Name] = useState<string>('Blanco');
  const [color2Hex, setColor2Hex] = useState<string>('#FFFFFF');
  const [glowEffect, setGlowEffect] = useState<boolean>(false);

  const buildCompiledString = (
    selectedMode = mode,
    c1 = color1Name,
    c2 = color2Name,
    glow = glowEffect
  ) => {
    let result = '';
    const glowStr = glow ? ' con brillo luminiscente etéreo' : '';

    switch (selectedMode) {
      case 'heterochromia_full':
        result = `Heterocromía completa (Ojo izquierdo ${c1}, Ojo derecho ${c2})${glowStr}`;
        break;
      case 'gradient_vertical':
        result = `Degradado de iris vertical (mezcla fluida de ${c1} superior a ${c2} inferior)${glowStr}`;
        break;
      case 'gradient_radial':
        result = `Mezcla de iris radial (desde núcleo central ${c1} hacia borde exterior ${c2})${glowStr}`;
        break;
      case 'heterochromia_central':
        result = `Heterocromía central (corona en raíz de pupila ${c2} con iris principal ${c1})${glowStr}`;
        break;
      case 'heterochromia_sectoral':
        result = `Heterocromía sectorial (base ${c1} con sector contrastante en ${c2})${glowStr}`;
        break;
      case 'single':
      default:
        result = `${c1}${glowStr}`;
        break;
    }
    return result;
  };

  const handleApplyCustom = (
    newMode = mode,
    c1 = color1Name,
    c2 = color2Name,
    glow = glowEffect
  ) => {
    const compiled = buildCompiledString(newMode, c1, c2, glow);
    onChange(compiled);
  };

  // Compute iris background CSS based on mode
  const getIrisGradientStyle = () => {
    if (mode === 'gradient_vertical') {
      return `linear-gradient(180deg, ${color1Hex} 0%, ${color2Hex} 100%)`;
    }
    if (mode === 'gradient_radial') {
      return `radial-gradient(circle, ${color1Hex} 30%, ${color2Hex} 100%)`;
    }
    if (mode === 'heterochromia_central') {
      return `radial-gradient(circle, ${color2Hex} 40%, ${color1Hex} 45%)`;
    }
    if (mode === 'heterochromia_sectoral') {
      return `conic-gradient(${color1Hex} 0deg 270deg, ${color2Hex} 270deg 360deg)`;
    }
    return color1Hex;
  };

  const filteredModes = EYE_COLOR_MODES.filter(m => {
    if (distFilter === 'all') return true;
    return m.category === distFilter;
  });

  return (
    <div className="bg-[#12141A] border border-[#2A2D35] rounded-2xl p-5 space-y-5">
      {/* Header & Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#222222]">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 rounded-xl bg-[#C9A050]/10 border border-[#C9A050]/30 flex items-center justify-center text-[#C9A050]">
            <Eye className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-[#E0E0E0] flex items-center gap-1.5">
              Color de Ojos, Heterocromía & Degradados
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-[#C9A050]/20 text-[#C9A050] border border-[#C9A050]/30">
                HD Dual Tone
              </span>
            </h4>
            <p className="text-[11px] text-[#888888]">
              Configura degradados de iris (ej. azul a blanco), heterocromía completa o anillos centrales
            </p>
          </div>
        </div>

        {/* Bicolor y Mechas / Heterocromía Badge */}
        <div className="flex items-center gap-1.5 bg-[#181A20] px-3 py-1.5 rounded-xl border border-[#2A2D35] text-xs font-semibold text-[#C9A050]">
          <Palette className="w-3.5 h-3.5" />
          Bicolor y Mechas / Heterocromía
        </div>
      </div>

      {/* Distribution Quick Category Filters */}
      <div className="flex flex-wrap items-center gap-1.5 bg-[#15171C] p-2 rounded-xl border border-[#2A2D35] text-xs">
        <span className="text-[10px] text-[#888888] font-mono uppercase mr-1 flex items-center gap-1">
          <Palette className="w-3 h-3 text-[#C9A050]" />
          Distribución:
        </span>
        <button
          type="button"
          onClick={() => setDistFilter('all')}
          className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
            distFilter === 'all'
              ? 'bg-[#C9A050] text-[#0A0B0E]'
              : 'bg-[#181A20] text-[#888888] hover:text-[#E0E0E0]'
          }`}
        >
          Todas
        </button>
        <button
          type="button"
          onClick={() => setDistFilter('heterocromía')}
          className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
            distFilter === 'heterocromía'
              ? 'bg-[#C9A050] text-[#0A0B0E]'
              : 'bg-[#181A20] text-[#888888] hover:text-[#E0E0E0]'
          }`}
        >
          🌓 Heterocromía (Izq/Der)
        </button>
        <button
          type="button"
          onClick={() => setDistFilter('raíz')}
          className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
            distFilter === 'raíz'
              ? 'bg-[#C9A050] text-[#0A0B0E]'
              : 'bg-[#181A20] text-[#888888] hover:text-[#E0E0E0]'
          }`}
        >
          🌱 Raíz / Corona Pupilar
        </button>
        <button
          type="button"
          onClick={() => setDistFilter('mezcla')}
          className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
            distFilter === 'mezcla'
              ? 'bg-[#C9A050] text-[#0A0B0E]'
              : 'bg-[#181A20] text-[#888888] hover:text-[#E0E0E0]'
          }`}
        >
          🎨 Mezcla / Degradado de Iris
        </button>
        <button
          type="button"
          onClick={() => setDistFilter('sólido')}
          className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
            distFilter === 'sólido'
              ? 'bg-[#C9A050] text-[#0A0B0E]'
              : 'bg-[#181A20] text-[#888888] hover:text-[#E0E0E0]'
          }`}
        >
          ◼️ Sólido
        </button>
      </div>

      {/* Real-Time Eye & Gradient Visualizer */}
      <div className="bg-[#181A20] border border-[#2A2D35] rounded-xl p-4 flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Visualizer Icons */}
        <div className="flex items-center space-x-6">
          {mode === 'heterochromia_full' ? (
            <div className="flex items-center space-x-4">
              {/* Left Eye */}
              <div className="flex flex-col items-center">
                <div
                  className="w-12 h-12 rounded-full border-2 border-white/20 flex items-center justify-center shadow-lg relative overflow-hidden transition-all duration-300"
                  style={{
                    backgroundColor: color1Hex,
                    boxShadow: glowEffect ? `0 0 15px ${color1Hex}` : 'none'
                  }}
                >
                  <div className="w-5 h-5 rounded-full bg-[#0A0B0E] border border-white/30" />
                  <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-white opacity-80" />
                </div>
                <span className="text-[10px] text-[#888888] mt-1 font-mono">Ojo Izq: {color1Name}</span>
              </div>
              
              <span className="text-[#C9A050] font-bold text-xs">VS</span>

              {/* Right Eye */}
              <div className="flex flex-col items-center">
                <div
                  className="w-12 h-12 rounded-full border-2 border-white/20 flex items-center justify-center shadow-lg relative overflow-hidden transition-all duration-300"
                  style={{
                    backgroundColor: color2Hex,
                    boxShadow: glowEffect ? `0 0 15px ${color2Hex}` : 'none'
                  }}
                >
                  <div className="w-5 h-5 rounded-full bg-[#0A0B0E] border border-white/30" />
                  <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-white opacity-80" />
                </div>
                <span className="text-[10px] text-[#888888] mt-1 font-mono">Ojo Der: {color2Name}</span>
              </div>
            </div>
          ) : (
            <div className="flex items-center space-x-4">
              {/* Dual Iris Simulator */}
              <div className="flex items-center space-x-3">
                <div
                  className="w-12 h-12 rounded-full border-2 border-white/20 flex items-center justify-center shadow-lg relative overflow-hidden transition-all duration-300"
                  style={{
                    background: getIrisGradientStyle(),
                    boxShadow: glowEffect ? `0 0 16px ${color1Hex}88` : 'none'
                  }}
                >
                  <div className="w-5 h-5 rounded-full bg-[#0A0B0E] border border-white/30" />
                  <div className="absolute top-2 right-2 w-2.5 h-2.5 rounded-full bg-white opacity-80" />
                  <div className="absolute bottom-2 left-2 w-1.5 h-1.5 rounded-full bg-white opacity-50" />
                </div>
                
                <div
                  className="w-12 h-12 rounded-full border-2 border-white/20 flex items-center justify-center shadow-lg relative overflow-hidden transition-all duration-300"
                  style={{
                    background: getIrisGradientStyle(),
                    boxShadow: glowEffect ? `0 0 16px ${color2Hex}88` : 'none'
                  }}
                >
                  <div className="w-5 h-5 rounded-full bg-[#0A0B0E] border border-white/30" />
                  <div className="absolute top-2 right-2 w-2.5 h-2.5 rounded-full bg-white opacity-80" />
                  <div className="absolute bottom-2 left-2 w-1.5 h-1.5 rounded-full bg-white opacity-50" />
                </div>
              </div>

              {/* Gradient Preview Bar */}
              <div className="hidden sm:flex flex-col space-y-1">
                <div
                  className="w-32 h-4 rounded-full border border-[#2A2D35]"
                  style={{ background: `linear-gradient(to right, ${color1Hex}, ${color2Hex})` }}
                />
                <div className="flex justify-between text-[10px] text-[#888888] font-mono">
                  <span>{color1Name}</span>
                  <span>{color2Name}</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Current Active Value Preview */}
        <div className="flex-1 text-right w-full md:w-auto">
          <div className="text-[10px] text-[#888888] uppercase font-mono tracking-wider">Valor Compilado en Sheet / Prompt:</div>
          <div className="text-xs font-semibold text-[#C9A050] bg-[#12141A] px-3 py-1.5 rounded-lg border border-[#2A2D35] mt-1 inline-block max-w-full truncate">
            {value || 'Marrón / Castaño'}
          </div>
        </div>
      </div>

      {/* CUSTOM COLOR MIXER */}
      <div className="space-y-5">
        {/* Mode Selector */}
          <div>
            <label className="block text-xs font-medium text-[#AAAAAA] mb-2">
              1. Selecciona el Modo de Distribución de Color (Heterocromía, Raíz o Mezcla):
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
              {filteredModes.map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => {
                    setMode(m.id);
                    handleApplyCustom(m.id, color1Name, color2Name, glowEffect);
                  }}
                  className={`p-2.5 rounded-xl border text-left text-xs transition-all ${
                    mode === m.id
                      ? 'bg-[#1E222B] border-[#C9A050] text-[#C9A050] font-bold shadow-xs'
                      : 'bg-[#15171C] border-[#2A2D35] text-[#888888] hover:bg-[#1A1D24] hover:text-[#E0E0E0]'
                  }`}
                >
                  <div className="font-semibold text-xs flex items-center justify-between">
                    <span>{m.name}</span>
                    <span className="text-[9px] uppercase font-mono px-1.5 py-0.5 rounded bg-black/40 text-[#A0A0A0]">
                      {m.category}
                    </span>
                  </div>
                  <div className="text-[10px] text-[#666666] mt-0.5">{m.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Color 1 & Color 2 Panels */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            {/* Color 1 */}
            <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#E0E0E0] flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: color1Hex }} />
                  {mode === 'heterochromia_full' ? 'Color Ojo Izquierdo' : 'Color Primario / Superior (Arriba / Centro)'}
                </span>
                <input
                  type="color"
                  value={color1Hex}
                  onChange={(e) => {
                    setColor1Hex(e.target.value);
                    handleApplyCustom(mode, color1Name, color2Name, glowEffect);
                  }}
                  className="w-6 h-6 rounded cursor-pointer bg-transparent border-0"
                />
              </div>

              <div>
                <label className="block text-[11px] text-[#888888] mb-1">Nombre / Tono descriptivo:</label>
                <input
                  type="text"
                  value={color1Name}
                  onChange={(e) => {
                    setColor1Name(e.target.value);
                    handleApplyCustom(mode, e.target.value, color2Name, glowEffect);
                  }}
                  placeholder="ej. Azul Zafiro, Índigo, Dorado..."
                  className="w-full bg-[#181A20] border border-[#2A2D35] rounded-lg p-2 text-xs text-[#E0E0E0]"
                />
              </div>

              {/* Swatches Color 1 */}
              <div>
                <label className="block text-[10px] text-[#888888] mb-1.5 font-mono uppercase">Paleta Rápida:</label>
                <div className="flex flex-wrap gap-1.5">
                  {BASIC_COLOR_SWATCHES.map((swatch) => (
                    <button
                      key={swatch.id}
                      type="button"
                      title={swatch.name}
                      onClick={() => {
                        setColor1Name(swatch.name);
                        setColor1Hex(swatch.hex);
                        handleApplyCustom(mode, swatch.name, color2Name, glowEffect);
                      }}
                      className="w-6 h-6 rounded-lg border border-white/20 hover:scale-110 transition-transform relative"
                      style={{ backgroundColor: swatch.hex }}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Color 2 */}
            <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#E0E0E0] flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: color2Hex }} />
                  {mode === 'heterochromia_full' ? 'Color Ojo Derecho' : 'Color Secundario / Inferior (Abajo / Borde)'}
                </span>
                <input
                  type="color"
                  value={color2Hex}
                  onChange={(e) => {
                    setColor2Hex(e.target.value);
                    handleApplyCustom(mode, color1Name, color2Name, glowEffect);
                  }}
                  className="w-6 h-6 rounded cursor-pointer bg-transparent border-0"
                />
              </div>

              <div>
                <label className="block text-[11px] text-[#888888] mb-1">Nombre / Tono descriptivo:</label>
                <input
                  type="text"
                  value={color2Name}
                  onChange={(e) => {
                    setColor2Name(e.target.value);
                    handleApplyCustom(mode, color1Name, e.target.value, glowEffect);
                  }}
                  placeholder="ej. Blanco, Cian Eléctrico, Oro..."
                  className="w-full bg-[#181A20] border border-[#2A2D35] rounded-lg p-2 text-xs text-[#E0E0E0]"
                />
              </div>

              {/* Swatches Color 2 */}
              <div>
                <label className="block text-[10px] text-[#888888] mb-1.5 font-mono uppercase">Paleta Rápida:</label>
                <div className="flex flex-wrap gap-1.5">
                  {BASIC_COLOR_SWATCHES.map((swatch) => (
                    <button
                      key={swatch.id}
                      type="button"
                      title={swatch.name}
                      onClick={() => {
                        setColor2Name(swatch.name);
                        setColor2Hex(swatch.hex);
                        handleApplyCustom(mode, color1Name, swatch.name, glowEffect);
                      }}
                      className="w-6 h-6 rounded-lg border border-white/20 hover:scale-110 transition-transform relative"
                      style={{ backgroundColor: swatch.hex }}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Glow & Luminescence Option */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-[#15171C] border border-[#2A2D35]">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-[#C9A050]" />
              <div>
                <div className="text-xs font-semibold text-[#E0E0E0]">Efecto de Brillo & Bioluminiscente</div>
                <div className="text-[10px] text-[#888888]">Añade destello mágico, iris etéreo y reflectancia cristalina</div>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={glowEffect}
                onChange={(e) => {
                  setGlowEffect(e.target.checked);
                  handleApplyCustom(mode, color1Name, color2Name, e.target.checked);
                }}
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-[#2A2D35] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#C9A050]"></div>
            </label>
          </div>
        </div>
    </div>
  );
};
