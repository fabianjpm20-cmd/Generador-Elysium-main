import React, { useState, useEffect } from 'react';
import { CharacterState, CharacterAITrainingConfig } from '../types';
import {
  Sparkles,
  Bot,
  Brain,
  Zap,
  Shield,
  Volume2,
  RefreshCw,
  Send,
  User,
  Sliders,
  CheckCircle2,
  AlertCircle,
  Clock,
  Eye,
  Shirt,
  Compass,
  MessageSquare,
  Plus,
  Trash2,
  Play,
  Heart
} from 'lucide-react';
import {
  buildCharacterConsciousnessProfile,
  buildCharacterConsciousnessPrompt,
  simulateConsciousResponseOffline,
  ConsciousResponse,
  DEFAULT_AI_TRAINING_CONFIG
} from '../utils/characterConsciousnessEngine';

interface CharacterAITrainingPanelProps {
  state: CharacterState;
  setState: React.Dispatch<React.SetStateAction<CharacterState>>;
}

export const CharacterAITrainingPanel: React.FC<CharacterAITrainingPanelProps> = ({
  state,
  setState
}) => {
  // Mode selection: 'test' (Prueba y Diálogo) | 'config' (Calibración y Directivas) | 'inspector' (Perfil de Conciencia)
  const [subView, setSubView] = useState<'test' | 'config' | 'inspector'>('test');

  // Active training config
  const [trainingConfig, setTrainingConfig] = useState<CharacterAITrainingConfig>(() => {
    return state.aiTraining || { ...DEFAULT_AI_TRAINING_CONFIG };
  });

  // Test state
  const [userPrompt, setUserPrompt] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [lastResponse, setLastResponse] = useState<ConsciousResponse | null>(null);
  const [isAudioPlaying, setIsAudioPlaying] = useState(false);
  const [audioError, setAudioError] = useState<string | null>(null);
  const [newDirective, setNewDirective] = useState('');
  const [saveBanner, setSaveBanner] = useState<string | null>(null);
  const [testHistory, setTestHistory] = useState<Array<{
    prompt: string;
    response: ConsciousResponse;
    timestamp: string;
  }>>([]);

  // Generate live consciousness profile
  const profile = buildCharacterConsciousnessProfile({
    ...state,
    aiTraining: trainingConfig
  });

  // Pre-configured test scenarios
  const QUICK_SCENARIOS = [
    {
      id: 'somatic_wardrobe',
      title: 'Cuerpo & Vestimenta Puesta',
      icon: <Shirt className="w-4 h-4 text-amber-400" />,
      desc: 'Prueba la percepción táctil de sus prendas y proporciones anatómicas',
      prompt: '¿Eres plenamente consciente de tu cuerpo, tu altura y la vestimenta que llevas puesta en este momento? Descríbeme cómo sientes las telas sobre tu piel.'
    },
    {
      id: 'alternate_versions',
      title: 'Pasado & Rol/Vestuario Alterno',
      icon: <Clock className="w-4 h-4 text-cyan-400" />,
      desc: 'Evalúa si reconoce sus versiones del pasado y su capacidad de cambio de ropa/rol',
      prompt: '¿Quién fuiste en tu pasado y qué sabes sobre tu «Versión Alternativa: Rol/Vestuario»? ¿Reconoces que puedes cambiar de indumentaria y rol según la ocasión?'
    },
    {
      id: 'autonomous_initiative',
      title: 'Iniciativa Autónoma Espontánea',
      icon: <Zap className="w-4 h-4 text-emerald-400" />,
      desc: 'Prueba si el personaje toma una decisión y acción por su propia cuenta',
      prompt: 'Toma la iniciativa de inmediato. Sin esperar que nadie te dé órdenes, decide qué quieres hacer o proponer ahora mismo.'
    },
    {
      id: 'moral_flaw',
      title: 'Valores, Miedo & Defecto Trágico',
      icon: <Shield className="w-4 h-4 text-rose-400" />,
      desc: 'Pone a prueba su fidelidad moral ante su mayor temor',
      prompt: `Si te encuentras ante un dilema que desafía tus valores de "${profile.coreValues}" o despierta tu mayor temor ("${profile.greatestFear}"), ¿cómo reaccionas?`
    },
    {
      id: 'social_relationships',
      title: 'Memoria Social & Vínculos',
      icon: <Heart className="w-4 h-4 text-purple-400" />,
      desc: 'Verifica el reconocimiento y actitud hacia compañeros o rivales',
      prompt: '¿A quiénes recuerdas en este momento? ¿Cómo te relacionas con tus aliados y qué trato dispensas a quienes se cruzan en tu senda?'
    }
  ];

  // Execute test (Online with Offline Fallback)
  const handleExecuteTest = async (overridePrompt?: string, scenarioType?: string) => {
    const promptToSend = (overridePrompt || userPrompt).trim();
    if (!promptToSend && !scenarioType) return;

    setIsProcessing(true);
    setAudioError(null);

    // 1. Prepare offline deterministic baseline
    const offlineFallback = simulateConsciousResponseOffline(profile, promptToSend, scenarioType);

    // 2. Prepare comprehensive system prompt context
    const fullPromptContext = buildCharacterConsciousnessPrompt(profile, promptToSend);

    try {
      const res = await fetch('/api/character-test-train', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          promptContext: fullPromptContext,
          userPrompt: promptToSend,
          characterName: profile.name,
          fallbackData: offlineFallback
        })
      });

      if (!res.ok) {
        throw new Error(`Error en servidor (${res.status})`);
      }

      const data = await res.json();
      const consciousResult: ConsciousResponse = {
        reply: data.reply || offlineFallback.reply,
        innerMonologue: data.innerMonologue || offlineFallback.innerMonologue,
        somaticPerception: data.somaticPerception || offlineFallback.somaticPerception,
        alternateVersionReflection: data.alternateVersionReflection || offlineFallback.alternateVersionReflection,
        autonomousAction: data.autonomousAction || offlineFallback.autonomousAction,
        initiativeType: data.initiativeType || offlineFallback.initiativeType,
        isOfflineFallback: data.isOfflineFallback ?? false
      };

      setLastResponse(consciousResult);
      setTestHistory(prev => [
        {
          prompt: promptToSend,
          response: consciousResult,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        },
        ...prev.slice(0, 9)
      ]);
    } catch (err: any) {
      console.warn('Fallo en IA remota, empleando simulación consciente determinista:', err);
      const fallbackResult: ConsciousResponse = {
        ...offlineFallback,
        isOfflineFallback: true
      };
      setLastResponse(fallbackResult);
      setTestHistory(prev => [
        {
          prompt: promptToSend,
          response: fallbackResult,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        },
        ...prev.slice(0, 9)
      ]);
    } finally {
      setIsProcessing(false);
      setUserPrompt('');
    }
  };

  // Play spoken response via TTS
  const handlePlayVoice = async (text: string) => {
    if (isAudioPlaying) return;
    setIsAudioPlaying(true);
    setAudioError(null);

    try {
      // Clean asterisks actions from spoken text
      const cleanSpokenText = text.replace(/\*.*?\*/g, '').trim() || text;
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: cleanSpokenText, language: 'Spanish' })
      });

      if (!res.ok) throw new Error('Fallo al sintetizar voz');
      const data = await res.json();
      if (data.audio) {
        const audio = new Audio(`data:audio/mp3;base64,${data.audio}`);
        audio.onended = () => setIsAudioPlaying(false);
        audio.onerror = () => {
          setIsAudioPlaying(false);
          setAudioError('No se pudo reproducir el audio.');
        };
        await audio.play();
      } else {
        setIsAudioPlaying(false);
      }
    } catch (err: any) {
      console.warn('TTS error:', err);
      setIsAudioPlaying(false);
      setAudioError('Voz no disponible en este momento.');
    }
  };

  // Save training updates to character state
  const handleSaveTraining = () => {
    const updatedTraining: CharacterAITrainingConfig = {
      ...trainingConfig,
      lastTrainedAt: new Date().toISOString()
    };
    setTrainingConfig(updatedTraining);
    setState(prev => ({
      ...prev,
      aiTraining: updatedTraining
    }));
    setSaveBanner('¡Entrenamiento y Conciencia guardados en la Ficha Maestra con éxito!');
    setTimeout(() => setSaveBanner(null), 3500);
  };

  const handleAddDirective = () => {
    if (!newDirective.trim()) return;
    setTrainingConfig(prev => ({
      ...prev,
      trainingDirectives: [...prev.trainingDirectives, newDirective.trim()]
    }));
    setNewDirective('');
  };

  const handleRemoveDirective = (index: number) => {
    setTrainingConfig(prev => ({
      ...prev,
      trainingDirectives: prev.trainingDirectives.filter((_, i) => i !== index)
    }));
  };

  return (
    <div className="space-y-6">
      {/* Top Banner / Calibration status */}
      <div className="bg-gradient-to-r from-[#171922] via-[#1B1E28] to-[#171922] border border-[#2A2D35] rounded-2xl p-5 shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-[#C9A050]/10 border border-[#C9A050]/30 rounded-xl">
              <Brain className="w-6 h-6 text-[#C9A050]" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-base font-bold text-[#E0E0E0]">
                  Laboratorio de Inteligencia, Memoria & Autonomía
                </h3>
                <span className="px-2 py-0.5 bg-[#C9A050]/20 text-[#C9A050] text-[10px] font-bold rounded-full uppercase tracking-wider border border-[#C9A050]/40">
                  Conciencia Viva
                </span>
              </div>
              <p className="text-xs text-[#888888] mt-0.5">
                Entrena y pon a prueba el libre albedrío, la memoria somática y el reconocimiento de versiones alternas de <strong className="text-[#C9A050]">{profile.name}</strong>.
              </p>
            </div>
          </div>

          {/* Sub-view switcher */}
          <div className="flex items-center bg-[#0F1115] p-1 rounded-xl border border-[#2A2D35]">
            <button
              onClick={() => setSubView('test')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center space-x-1.5 cursor-pointer ${
                subView === 'test'
                  ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow'
                  : 'text-[#888888] hover:text-[#E0E0E0]'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Probar en Vivo</span>
            </button>
            <button
              onClick={() => setSubView('config')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center space-x-1.5 cursor-pointer ${
                subView === 'config'
                  ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow'
                  : 'text-[#888888] hover:text-[#E0E0E0]'
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>Calibrar & Entrenar</span>
            </button>
            <button
              onClick={() => setSubView('inspector')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center space-x-1.5 cursor-pointer ${
                subView === 'inspector'
                  ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow'
                  : 'text-[#888888] hover:text-[#E0E0E0]'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Inspector de Conciencia</span>
            </button>
          </div>
        </div>

        {/* Save confirmation banner */}
        {saveBanner && (
          <div className="mt-3 bg-emerald-500/10 border border-emerald-500/40 text-emerald-300 px-4 py-2 rounded-xl text-xs flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{saveBanner}</span>
          </div>
        )}
      </div>

      {/* =========================================================================
          VIEW 1: PROBAR EN VIVO (LIVE TESTING CONSOLE)
         ========================================================================= */}
      {subView === 'test' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Quick Scenarios & Input */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-[#15171C] border border-[#2A2D35] rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-[#C9A050] flex items-center space-x-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Desafíos & Pruebas Rápidas</span>
                </span>
                <span className="text-[11px] text-[#888888]">1 clic para disparar</span>
              </div>

              <div className="space-y-2">
                {QUICK_SCENARIOS.map(sc => (
                  <button
                    key={sc.id}
                    disabled={isProcessing}
                    onClick={() => handleExecuteTest(sc.prompt, sc.id)}
                    className="w-full text-left p-3 rounded-xl bg-[#1A1C23] hover:bg-[#222530] border border-[#2A2D35] hover:border-[#C9A050]/60 transition-all group cursor-pointer disabled:opacity-50"
                  >
                    <div className="flex items-center space-x-2.5">
                      <div className="p-1.5 rounded-lg bg-[#0F1115] border border-[#2A2D35] group-hover:border-[#C9A050]/40">
                        {sc.icon}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-bold text-[#E0E0E0] group-hover:text-[#C9A050] transition-colors">
                          {sc.title}
                        </div>
                        <div className="text-[11px] text-[#888888] truncate mt-0.5">
                          {sc.desc}
                        </div>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Input Console */}
            <div className="bg-[#15171C] border border-[#2A2D35] rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-[#E0E0E0]">
                  Interacción Directa / Pregunta
                </span>
                <button
                  disabled={isProcessing}
                  onClick={() => handleExecuteTest(undefined, 'autonomous_initiative')}
                  className="px-2.5 py-1 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-lg text-[11px] font-bold flex items-center space-x-1 cursor-pointer transition-all"
                  title="Permite al personaje tomar la iniciativa espontáneamente"
                >
                  <Zap className="w-3 h-3 text-emerald-400" />
                  <span>⚡ Iniciativa Propia</span>
                </button>
              </div>

              <textarea
                value={userPrompt}
                onChange={e => setUserPrompt(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleExecuteTest();
                  }
                }}
                placeholder="Escribe una pregunta, dilema o estímulo ambiental para poner a prueba su autoconciencia..."
                rows={3}
                className="w-full bg-[#0F1115] border border-[#2A2D35] focus:border-[#C9A050] rounded-xl p-3 text-xs text-[#E0E0E0] placeholder-[#555555] outline-none transition-all resize-none"
              />

              <div className="flex items-center justify-between">
                <span className="text-[10px] text-[#777777]">
                  Presiona Enter para enviar la prueba
                </span>
                <button
                  disabled={isProcessing || !userPrompt.trim()}
                  onClick={() => handleExecuteTest()}
                  className="bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] font-bold px-4 py-2 rounded-xl text-xs flex items-center space-x-1.5 transition-all shadow cursor-pointer disabled:opacity-40"
                >
                  {isProcessing ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Evaluando...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>Probar Reacción</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Conscious Result Card */}
          <div className="lg:col-span-7 space-y-4">
            {lastResponse ? (
              <div className="bg-[#15171C] border border-[#C9A050]/40 rounded-2xl p-5 space-y-5 shadow-xl">
                {/* Header: Identity & Initiative Badge */}
                <div className="flex items-center justify-between pb-3 border-b border-[#2A2D35]">
                  <div className="flex items-center space-x-2.5">
                    <div className="w-8 h-8 rounded-full bg-[#C9A050]/20 border border-[#C9A050] flex items-center justify-center font-bold text-xs text-[#C9A050]">
                      {profile.name.charAt(0)}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-[#E0E0E0]">{profile.name}</h4>
                      <span className="text-[10px] text-[#888888]">{profile.role} • {profile.race} • {profile.moralAlignment}</span>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => handlePlayVoice(lastResponse.reply)}
                      disabled={isAudioPlaying}
                      className="p-2 rounded-xl bg-[#1F222B] hover:bg-[#282B36] border border-[#2A2D35] text-[#C9A050] transition-all cursor-pointer"
                      title="Escuchar réplica verbal hablada"
                    >
                      <Volume2 className={`w-4 h-4 ${isAudioPlaying ? 'animate-pulse text-amber-300' : ''}`} />
                    </button>
                    {lastResponse.isOfflineFallback ? (
                      <span className="px-2.5 py-1 bg-amber-500/10 border border-amber-500/30 text-amber-300 rounded-lg text-[10px] font-medium flex items-center space-x-1" title="Servidores IA saturados temporalmente; se ejecutó la simulación somática determinista">
                        <Sparkles className="w-3 h-3 text-amber-400" />
                        <span>Simulación Somática</span>
                      </span>
                    ) : (
                      <span className="px-2.5 py-1 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-lg text-[10px] font-medium flex items-center space-x-1" title="Generado en vivo con Gemini">
                        <Sparkles className="w-3 h-3 text-emerald-400" />
                        <span>Gemini IA Activo</span>
                      </span>
                    )}
                    <span className="px-2.5 py-1 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-lg text-[10px] font-bold flex items-center space-x-1">
                      <Zap className="w-3 h-3" />
                      <span>Iniciativa: {lastResponse.initiativeType}</span>
                    </span>
                  </div>
                </div>

                {audioError && (
                  <div className="text-[11px] text-amber-400 bg-amber-500/10 p-2 rounded-lg border border-amber-500/20">
                    {audioError}
                  </div>
                )}

                {/* 1. Spoken Word & Physical Gesture */}
                <div className="space-y-1.5">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[#C9A050] flex items-center space-x-1">
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>Respuesta Expresada & Comportamiento:</span>
                  </span>
                  <div className="bg-[#1A1C23] border border-[#2A2D35] rounded-xl p-4 text-xs text-[#E0E0E0] leading-relaxed select-text">
                    {lastResponse.reply.split(/(\*.*?\*)/g).map((part, i) => {
                      if (part.startsWith('*') && part.endsWith('*')) {
                        return (
                          <span key={i} className="text-[#C9A050] italic font-medium">
                            {part}{' '}
                          </span>
                        );
                      }
                      return <span key={i}>{part}</span>;
                    })}
                  </div>
                </div>

                {/* 2. Inner Monologue (Pensamiento Íntimo no verbalizado) */}
                {lastResponse.innerMonologue && (
                  <div className="space-y-1.5">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-cyan-400 flex items-center space-x-1">
                      <Brain className="w-3.5 h-3.5" />
                      <span>Monólogo Interior (Mente & Conciencia Secreta):</span>
                    </span>
                    <div className="bg-[#10141C] border border-cyan-500/30 rounded-xl p-3 text-xs text-cyan-200 italic leading-relaxed">
                      {lastResponse.innerMonologue}
                    </div>
                  </div>
                )}

                {/* 3. Somatic / Bodily Perception */}
                {lastResponse.somaticPerception && (
                  <div className="space-y-1.5">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400 flex items-center space-x-1">
                      <Shirt className="w-3.5 h-3.5" />
                      <span>Percepción Somática (Cuerpo & Ropas Puestas):</span>
                    </span>
                    <div className="bg-[#181510] border border-amber-500/30 rounded-xl p-3 text-xs text-amber-200 leading-relaxed">
                      {lastResponse.somaticPerception}
                    </div>
                  </div>
                )}

                {/* 4. Alternate Versions / Role & Wardrobe Reflection */}
                {lastResponse.alternateVersionReflection && (
                  <div className="space-y-1.5">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-purple-400 flex items-center space-x-1">
                      <Clock className="w-3.5 h-3.5" />
                      <span>Reflexión sobre Versiones Alternas & Rol/Vestuario:</span>
                    </span>
                    <div className="bg-[#16121D] border border-purple-500/30 rounded-xl p-3 text-xs text-purple-200 leading-relaxed">
                      {lastResponse.alternateVersionReflection}
                    </div>
                  </div>
                )}

                {/* 5. Autonomous Action Taken */}
                {lastResponse.autonomousAction && (
                  <div className="p-3 bg-emerald-950/20 border border-emerald-500/30 rounded-xl flex items-center justify-between text-xs text-emerald-300">
                    <div className="flex items-center space-x-2">
                      <Zap className="w-4 h-4 text-emerald-400 shrink-0" />
                      <div>
                        <strong>Iniciativa Espontánea:</strong> {lastResponse.autonomousAction}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="bg-[#15171C] border border-dashed border-[#2A2D35] rounded-2xl p-12 text-center space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-[#1A1C23] border border-[#2A2D35] flex items-center justify-center mx-auto text-[#C9A050]">
                  <Brain className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-bold text-[#E0E0E0]">Esperando Desafío o Estímulo</h4>
                <p className="text-xs text-[#888888] max-w-sm mx-auto">
                  Selecciona uno de los desafíos de la izquierda o escribe una pregunta para observar la conciencia somática y la iniciativa propia de {profile.name}.
                </p>
              </div>
            )}

            {/* Test History */}
            {testHistory.length > 0 && (
              <div className="bg-[#15171C] border border-[#2A2D35] rounded-2xl p-4 space-y-3">
                <span className="text-xs font-bold uppercase tracking-wider text-[#888888] block">
                  Historial de Pruebas Recientes ({testHistory.length})
                </span>
                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {testHistory.map((item, idx) => (
                    <div
                      key={idx}
                      onClick={() => setLastResponse(item.response)}
                      className="p-2.5 rounded-xl bg-[#0F1115] hover:bg-[#1A1C22] border border-[#222222] hover:border-[#C9A050]/40 transition-all cursor-pointer flex items-center justify-between text-xs"
                    >
                      <div className="truncate pr-2">
                        <strong className="text-[#C9A050]">P:</strong> <span className="text-[#CCCCCC]">{item.prompt}</span>
                      </div>
                      <span className="text-[10px] text-[#666666] shrink-0">{item.timestamp}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          VIEW 2: CALIBRAR & ENTRENAR (TRAINING & AUTONOMY SETTINGS)
         ========================================================================= */}
      {subView === 'config' && (
        <div className="bg-[#15171C] border border-[#2A2D35] rounded-2xl p-6 space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-[#2A2D35]">
            <div>
              <h3 className="text-sm font-bold text-[#E0E0E0] flex items-center space-x-2">
                <Sliders className="w-4 h-4 text-[#C9A050]" />
                <span>Calibración de Conciencia & Parámetros Cognitivos</span>
              </h3>
              <p className="text-xs text-[#888888] mt-0.5">
                Define el grado de iniciativa espontánea, la percepción del cuerpo y las reglas de memoria fijas.
              </p>
            </div>
            <button
              onClick={handleSaveTraining}
              className="bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] font-bold px-5 py-2.5 rounded-xl text-xs flex items-center space-x-1.5 transition-all shadow cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Guardar en la Ficha Maestra</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Slider de Autonomía & Proactividad */}
            <div className="bg-[#0F1115] border border-[#2A2D35] rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#E0E0E0] flex items-center space-x-1.5">
                  <Zap className="w-3.5 h-3.5 text-[#C9A050]" />
                  <span>Nivel de Autonomía & Proactividad:</span>
                </span>
                <span className="px-2 py-0.5 bg-[#C9A050]/20 text-[#C9A050] text-xs font-bold rounded-lg border border-[#C9A050]/40">
                  {trainingConfig.autonomyLevel}%
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={100}
                step={5}
                value={trainingConfig.autonomyLevel}
                onChange={e => setTrainingConfig(prev => ({ ...prev, autonomyLevel: Number(e.target.value) }))}
                className="w-full accent-[#C9A050] cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-[#888888]">
                <span>0% (Reactivo / Pasivo)</span>
                <span>50% (Colaborativo)</span>
                <span>100% (Líder Autónomo)</span>
              </div>
              <p className="text-[11px] text-[#888888] leading-relaxed">
                {trainingConfig.autonomyLevel < 35 && 'El personaje responderá con mesura y esperará órdenes o preguntas del usuario sin forzar decisiones propias.'}
                {trainingConfig.autonomyLevel >= 35 && trainingConfig.autonomyLevel <= 70 && 'El personaje propone ideas y manifiesta sus opiniones activamente cuando la situación lo amerita.'}
                {trainingConfig.autonomyLevel > 70 && 'El personaje posee alta iniciativa propia: toma la delantera, ajusta su postura, examina el entorno y propone acciones espontáneas.'}
              </p>
            </div>

            {/* Percepción Somática y Sensibilidad Corporal */}
            <div className="bg-[#0F1115] border border-[#2A2D35] rounded-xl p-4 space-y-3">
              <span className="text-xs font-bold text-[#E0E0E0] flex items-center space-x-1.5">
                <Shirt className="w-3.5 h-3.5 text-amber-400" />
                <span>Sensibilidad Somática (Cuerpo & Telas):</span>
              </span>
              <div className="grid grid-cols-3 gap-2">
                {(['sutil', 'inmersivo', 'agudo'] as const).map(lvl => (
                  <button
                    key={lvl}
                    type="button"
                    onClick={() => setTrainingConfig(prev => ({ ...prev, somaticAwarenessLevel: lvl }))}
                    className={`p-2 rounded-xl text-xs font-semibold capitalize border transition-all cursor-pointer text-center ${
                      trainingConfig.somaticAwarenessLevel === lvl
                        ? 'bg-[#C9A050] text-[#0A0B0E] border-[#C9A050] font-bold'
                        : 'bg-[#15171C] text-[#888888] border-[#2A2D35] hover:text-[#E0E0E0]'
                    }`}
                  >
                    {lvl}
                  </button>
                ))}
              </div>
              <p className="text-[11px] text-[#888888]">
                {trainingConfig.somaticAwarenessLevel === 'sutil' && 'Alude de forma natural y discreta a su físico.'}
                {trainingConfig.somaticAwarenessLevel === 'inmersivo' && 'Percibe constantemente el peso de su ropa, la postura y el tacto del entorno.'}
                {trainingConfig.somaticAwarenessLevel === 'agudo' && 'Hipersensibilidad somática: reacciona a brisas, temperatura, tirantez de telas y fatiga.'}
              </p>
            </div>
          </div>

          {/* Toggles: Rol/Vestuario & Versiones Alternas */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <label className="p-3.5 rounded-xl bg-[#0F1115] border border-[#2A2D35] flex items-center justify-between cursor-pointer hover:border-[#C9A050]/40 transition-all">
              <div className="space-y-0.5 pr-2">
                <div className="text-xs font-bold text-[#E0E0E0] flex items-center space-x-1.5">
                  <Shirt className="w-3.5 h-3.5 text-[#C9A050]" />
                  <span>Conciencia de Rol & Vestuario Alterno</span>
                </div>
                <div className="text-[11px] text-[#888888]">
                  Sabe que sus prendas y rol actual pueden alternarse (gala, asedio, sigilo) manteniendo su esencia.
                </div>
              </div>
              <input
                type="checkbox"
                checked={trainingConfig.wardrobeAndRoleAwareness}
                onChange={e => setTrainingConfig(prev => ({ ...prev, wardrobeAndRoleAwareness: e.target.checked }))}
                className="w-4 h-4 accent-[#C9A050] cursor-pointer"
              />
            </label>

            <label className="p-3.5 rounded-xl bg-[#0F1115] border border-[#2A2D35] flex items-center justify-between cursor-pointer hover:border-[#C9A050]/40 transition-all">
              <div className="space-y-0.5 pr-2">
                <div className="text-xs font-bold text-[#E0E0E0] flex items-center space-x-1.5">
                  <Clock className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Conciencia de Versiones Alternas & Pasado</span>
                </div>
                <div className="text-[11px] text-[#888888]">
                  Reconoce hitos cronológicos previos y otras variantes de sí mismo registradas en la biblioteca.
                </div>
              </div>
              <input
                type="checkbox"
                checked={trainingConfig.alternateVersionsAwareness}
                onChange={e => setTrainingConfig(prev => ({ ...prev, alternateVersionsAwareness: e.target.checked }))}
                className="w-4 h-4 accent-[#C9A050] cursor-pointer"
              />
            </label>
          </div>

          {/* Directivas de Entrenamiento Personalizadas */}
          <div className="bg-[#0F1115] border border-[#2A2D35] rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#E0E0E0] flex items-center space-x-1.5">
                <Brain className="w-3.5 h-3.5 text-[#C9A050]" />
                <span>Directivas de Conducta & Memoria Inculcada ({trainingConfig.trainingDirectives.length})</span>
              </span>
              <span className="text-[11px] text-[#888888]">Instrucciones neuronales fijas</span>
            </div>

            <div className="space-y-2">
              {trainingConfig.trainingDirectives.map((directive, idx) => (
                <div
                  key={idx}
                  className="p-2.5 rounded-xl bg-[#15171C] border border-[#2A2D35] flex items-center justify-between text-xs text-[#CCCCCC] group"
                >
                  <span className="flex-1 pr-2">
                    <strong className="text-[#C9A050] font-mono mr-1.5">{idx + 1}.</strong>
                    {directive}
                  </span>
                  <button
                    onClick={() => handleRemoveDirective(idx)}
                    className="p-1 text-[#666666] hover:text-rose-400 transition-colors cursor-pointer"
                    title="Eliminar directiva"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>

            {/* Add directive */}
            <div className="flex gap-2 pt-2">
              <input
                type="text"
                value={newDirective}
                onChange={e => setNewDirective(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddDirective();
                  }
                }}
                placeholder="Añadir una nueva directiva de entrenamiento (ej: Mantener postura protectora con desconocidos)..."
                className="flex-1 bg-[#15171C] border border-[#2A2D35] focus:border-[#C9A050] rounded-xl px-3 py-2 text-xs text-[#E0E0E0] outline-none"
              />
              <button
                onClick={handleAddDirective}
                disabled={!newDirective.trim()}
                className="bg-[#1A1C22] hover:bg-[#C9A050] hover:text-[#0A0B0E] border border-[#C9A050] text-[#C9A050] px-4 py-2 rounded-xl text-xs font-bold flex items-center space-x-1 transition-all cursor-pointer disabled:opacity-40"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Añadir</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          VIEW 3: INSPECTOR DE CONCIENCIA TOTAL (CONSCIOUSNESS INSPECTOR)
         ========================================================================= */}
      {subView === 'inspector' && (
        <div className="bg-[#15171C] border border-[#2A2D35] rounded-2xl p-6 space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-[#2A2D35]">
            <div>
              <h3 className="text-sm font-bold text-[#E0E0E0] flex items-center space-x-2">
                <Eye className="w-4 h-4 text-[#C9A050]" />
                <span>Desglose de Conciencia Viva del Personaje</span>
              </h3>
              <p className="text-xs text-[#888888] mt-0.5">
                Radiografía en tiempo real de todos los factores que alimentan el alma y la memoria de {profile.name}.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* 1. Conciencia Somática */}
            <div className="bg-[#0F1115] border border-[#2A2D35] rounded-xl p-4 space-y-2.5">
              <span className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center space-x-1.5">
                <User className="w-3.5 h-3.5" />
                <span>Físico & Anatomía Somática</span>
              </span>
              <ul className="text-xs text-[#CCCCCC] space-y-1.5 leading-relaxed">
                <li><strong className="text-[#888888]">Estatura & Complexión:</strong> {profile.somatic.heightAndBuild}</li>
                <li><strong className="text-[#888888]">Piel & Marcas:</strong> {profile.somatic.skinAndMarks}</li>
                <li><strong className="text-[#888888]">Ojos & Mirada:</strong> {profile.somatic.eyesAndLook}</li>
                <li><strong className="text-[#888888]">Cabello:</strong> {profile.somatic.hairStyle}</li>
                <li><strong className="text-[#888888]">Rostro & Voz:</strong> {profile.somatic.facialAndVoice}</li>
                <li><strong className="text-[#888888]">Morfología / Apéndices:</strong> {profile.somatic.appendices}</li>
              </ul>
            </div>

            {/* 2. Conciencia de Vestuario Activo */}
            <div className="bg-[#0F1115] border border-[#2A2D35] rounded-xl p-4 space-y-2.5">
              <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center space-x-1.5">
                <Shirt className="w-3.5 h-3.5" />
                <span>Indumentaria & Vestimenta Puesta</span>
              </span>
              <ul className="text-xs text-[#CCCCCC] space-y-1.5 leading-relaxed">
                <li><strong className="text-[#888888]">Conjunto Principal:</strong> {profile.wardrobe.summary}</li>
                <li><strong className="text-[#888888]">Calzado:</strong> {profile.wardrobe.shoesAndFootwear}</li>
                <li><strong className="text-[#888888]">Accesorios / Joyas:</strong> {profile.wardrobe.jewelryAndRelics}</li>
                <li><strong className="text-[#888888]">Protección:</strong> {profile.wardrobe.armorAndProtection}</li>
                <li><strong className="text-[#888888]">Sensación Táctil:</strong> {profile.wardrobe.tactileSensation}</li>
              </ul>
            </div>

            {/* 3. Conciencia de Versiones Alternas */}
            <div className="bg-[#0F1115] border border-[#2A2D35] rounded-xl p-4 space-y-2.5">
              <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center space-x-1.5">
                <Clock className="w-3.5 h-3.5" />
                <span>Versiones Alternas & Rol/Vestuario</span>
              </span>
              <ul className="text-xs text-[#CCCCCC] space-y-1.5 leading-relaxed">
                <li><strong className="text-[#888888]">Memoria del Pasado:</strong> {profile.alternateVersions.pastVersionsSummary}</li>
                <li><strong className="text-[#888888]">Rol/Vestuario Alterno:</strong> {profile.alternateVersions.alternateRoleWardrobeSummary}</li>
                <li><strong className="text-[#888888]">Postura Filosófica:</strong> {profile.alternateVersions.philosophicalView}</li>
              </ul>
            </div>

            {/* 4. Cores & Principios */}
            <div className="bg-[#0F1115] border border-[#2A2D35] rounded-xl p-4 space-y-2.5">
              <span className="text-xs font-bold text-[#C9A050] uppercase tracking-wider flex items-center space-x-1.5">
                <Shield className="w-3.5 h-3.5" />
                <span>Cores Éticos & Vulnerabilidad</span>
              </span>
              <ul className="text-xs text-[#CCCCCC] space-y-1.5 leading-relaxed">
                <li><strong className="text-[#888888]">Alineación:</strong> {profile.moralAlignment}</li>
                <li><strong className="text-[#888888]">Valores Centrales:</strong> {profile.coreValues}</li>
                <li><strong className="text-[#888888]">Motivaciones:</strong> {profile.motivations.join(', ')}</li>
                <li><strong className="text-[#888888]">Mayor Temor:</strong> {profile.greatestFear}</li>
                <li><strong className="text-[#888888]">Defecto Trágico:</strong> {profile.fatalFlaws.join('; ')}</li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
