import React, { useState, useEffect, useRef } from 'react';
import {
  CharacterState,
  WorldPlace,
  WorldBuildingConfig,
  MainScreen
} from '../types';
import {
  InteractionSessionState,
  loadAllSavedSessions,
  saveSessionState,
  deleteSavedSession,
  duplicateSavedSession,
  restartSessionHistory,
  characterStateToUnifiedParticipant,
  UnifiedParticipant,
  getActiveSessionId,
  setActiveSessionId,
  exportSessionTranscriptAsText,
  STORAGE_KEY
} from '../utils/interactionLogicEngine';
import {
  EnhancedConversationMemory,
  mergeMemoryUpdates,
  extractMemoryInsightsOffline,
  formatConversationMemoryForPrompt
} from '../utils/conversationMemoryEngine';
import { getSavedCharacters, createDefaultCharacterState } from '../utils/libraryStorage';
import { getSavedPlaces } from '../utils/worldStorage';
import {
  MessageSquare,
  Sparkles,
  Send,
  Plus,
  Trash2,
  Users,
  Compass,
  MapPin,
  ArrowRight,
  RotateCcw,
  Volume2,
  Bot,
  User,
  BookOpen,
  Settings,
  CheckCircle2,
  Copy,
  Edit3,
  Globe,
  Scale,
  ChevronLeft,
  Check,
  AlertCircle,
  Play,
  X,
  Database,
  Download,
  Brain,
  ShieldCheck,
  FileText,
  Terminal,
  Wifi,
  WifiOff,
  Zap,
  Heart,
  Smile,
  Activity,
  MessageCircle,
  RefreshCw,
  Bookmark,
  HelpCircle,
  Layers,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import {
  AgentLogicalMemory,
  initAgentLogicalMemory,
  evaluateAgentReactionWillingness,
  generateOfflineAgentResponse,
  generateInterAgentBanterOffline
} from '../utils/autonomousAgentEngine';
import { generateAutonomousSceneNarration, generateAutonomousSceneNarrationFull } from '../utils/somaticCognitiveEngine';
import { LocalKnowledgeLibraryModal } from './LocalKnowledgeLibraryModal';
import { KnowledgeEntry } from '../utils/localKnowledgeLibrary';

interface UnifiedInteractionScreenProps {
  onNavigate: (screen: MainScreen) => void;
  characterState: CharacterState;
  onUpdateCharacter: (newState: CharacterState) => void;
  activePlace: WorldPlace;
  onSetActivePlace: (place: WorldPlace) => void;
  worldConfig: WorldBuildingConfig;
}

// Canonical archetypal companions available if library needs extra options
const CANONICAL_PRESET_COMPANIONS: Array<{ id: string; name: string; role: string; race: string; personality: string; excerpt: string }> = [
  {
    id: 'npc-valentin',
    name: 'Valentín Montclair',
    role: 'Noble Diplomático & Canciller',
    race: 'Humano',
    personality: 'Refinado, analítico, complaciente con astucia cortesana y palabra medida.',
    excerpt: '«Un placer coincidir contigo en el Oasis. Este palacio encierra más secretos de los que aparenta a simple vista.»'
  },
  {
    id: 'npc-xander',
    name: 'Xander Vaelith',
    role: 'Estratega Táctico & Mediador',
    race: 'Humano',
    personality: 'Sereno, calculador, observador y leal a sus principios tácticos.',
    excerpt: '«Mantén la posición y evalúa el terreno. Cada movimiento en este recinto debe tener un propósito calculado.»'
  },
  {
    id: 'npc-go-pip',
    name: 'Go pip',
    role: 'Pícaro Ingeniero & Artificiero',
    race: 'Goblin',
    personality: 'Vivaz, ingenioso, curioso y siempre listo para abrir cerrojos imposibles.',
    excerpt: '«¡Oye! He encontrado tres engranajes arcanos y una puerta con cerrojo sellado. ¿La abrimos o qué?»'
  }
];

export const UnifiedInteractionScreen: React.FC<UnifiedInteractionScreenProps> = ({
  onNavigate,
  characterState,
  onUpdateCharacter,
  activePlace,
  onSetActivePlace,
  worldConfig
}) => {
  // ----------------------------------------------------------------
  // SCREEN PHASES:
  // 1. 'phase0_sessions': Historial de Sesiones & Charlas (Pantalla 1 - Entrada obligada)
  // 2. 'phase1_config': Configuración de Interacción · Elenco y Entorno (Pantalla 2)
  // 3. 'phase2_chat': Sala de Chat (Pantalla 3)
  // ----------------------------------------------------------------
  const [phase, setPhase] = useState<'phase0_sessions' | 'phase1_config' | 'phase2_chat'>('phase0_sessions');

  // Persistence list of sessions
  const [sessions, setSessions] = useState<InteractionSessionState[]>(() => loadAllSavedSessions());

  // Active session in chat (restored from active pointer or first available)
  const [currentSession, setCurrentSession] = useState<InteractionSessionState | null>(() => {
    const list = loadAllSavedSessions();
    const activeId = getActiveSessionId();
    if (activeId) {
      const found = list.find(s => s.id === activeId);
      if (found) return found;
    }
    return list[0] || null;
  });

  // Action confirmation states for session cards
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [confirmRestartId, setConfirmRestartId] = useState<string | null>(null);
  const [actionFeedbackMessage, setActionFeedbackMessage] = useState<string | null>(null);

  // Modals for Cognitive Memory & Transcript Export
  const [showMemoryModal, setShowMemoryModal] = useState<boolean>(false);
  const [showExportModal, setShowExportModal] = useState<boolean>(false);
  const [copiedTranscript, setCopiedTranscript] = useState<boolean>(false);

  // Advanced Cognitive Memory & Reasoning States
  const [isAnalyzingMemory, setIsAnalyzingMemory] = useState<boolean>(false);
  const [activeMemoryTab, setActiveMemoryTab] = useState<'summary' | 'facts' | 'agreements' | 'questions' | 'theory_of_mind'>('summary');
  const [newFactInput, setNewFactInput] = useState<string>('');
  const [newAgreementInput, setNewAgreementInput] = useState<string>('');
  const [newQuestionInput, setNewQuestionInput] = useState<string>('');
  const [expandedReasoningMsgId, setExpandedReasoningMsgId] = useState<string | null>(null);
  const [expandedNarratorMsgId, setExpandedNarratorMsgId] = useState<string | null>(null);

  // Offline Agent & Terminal Lógico state
  const [isOfflineMode, setIsOfflineMode] = useState<boolean>(() => {
    const active = getActiveSessionId();
    if (active) {
      const list = loadAllSavedSessions();
      const s = list.find(item => item.id === active);
      if (s && typeof s.isOfflineMode === 'boolean') return s.isOfflineMode;
    }
    return false;
  });
  const [activeTerminalCompanionId, setActiveTerminalCompanionId] = useState<string | null>(null);
  const [customGoalInput, setCustomGoalInput] = useState<string>('');
  const [selectedBanterPartnerId, setSelectedBanterPartnerId] = useState<string>('');

  // ----------------------------------------------------------------
  // CONFIGURATION SCREEN (PHASE 1) STATE
  // ----------------------------------------------------------------
  const [configMode, setConfigMode] = useState<'create' | 'edit'>('create');
  const [editingSessionId, setEditingSessionId] = useState<string | null>(null);
  const [sessionTitle, setSessionTitle] = useState<string>('');
  const [selectedProtagonistId, setSelectedProtagonistId] = useState<string>('');
  const [selectedCompanionIds, setSelectedCompanionIds] = useState<string[]>([]);
  const [selectedPlaceId, setSelectedPlaceId] = useState<string>('');
  const [selectedTone, setSelectedTone] = useState<'Romance' | 'R+18' | 'Aventura' | 'Guerra / Política'>('Aventura');

  // Chat stream states (Phase 2)
  const [inputText, setInputText] = useState('');
  const [targetSpeakerId, setTargetSpeakerId] = useState<string>('all');
  const [isGenerating, setIsGenerating] = useState(false);
  const [ttsLoadingId, setTtsLoadingId] = useState<string | null>(null);
  const [currentlyPlayingAudio, setCurrentlyPlayingAudio] = useState<HTMLAudioElement | null>(null);
  const [showWorldLawsModal, setShowWorldLawsModal] = useState<boolean>(false);
  const [showKnowledgeLibraryModal, setShowKnowledgeLibraryModal] = useState<boolean>(false);

  // Library items
  const savedCharacters = getSavedCharacters();
  const savedPlaces = getSavedPlaces();

  const chatEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom when dialogue updates
  useEffect(() => {
    if (phase === 'phase2_chat') {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [currentSession?.dialogueHistory, phase]);

  // Flash feedback toast message
  const showFeedback = (msg: string) => {
    setActionFeedbackMessage(msg);
    setTimeout(() => setActionFeedbackMessage(null), 3000);
  };

  // Helper to extract active laws from worldbuilding
  const getActiveWorldLaws = (): string[] => {
    const list: string[] = [];
    if (worldConfig.laws && Array.isArray(worldConfig.laws)) {
      worldConfig.laws.forEach(l => {
        if (l.isActive) list.push(`${l.title}: ${l.description || l.effect}`);
      });
    }
    if (worldConfig.specialLaws && Array.isArray(worldConfig.specialLaws)) {
      worldConfig.specialLaws.forEach(l => {
        if (l.isActive) list.push(`${l.title}: ${l.effect}`);
      });
    }
    if (list.length === 0) {
      list.push('Principio de Causalidad Espacial: Los efectos mágicos responden a la voluntad y al entorno.');
      list.push('Pacto de Santuario: En zonas habitadas o diplomáticas, la violencia acarrea juicio directo.');
      list.push('Resonancia Arcana: Las palabras y emociones intensifican el flujo etéreo circundante.');
    }
    return list;
  };

  // ----------------------------------------------------------------
  // PANTALLA 1: SESSION MANAGEMENT ACTIONS
  // ----------------------------------------------------------------

  // 1. NUEVA SESIÓN DE CHAT -> Abre Pantalla 2 (Configuración)
  const handleOpenNewSessionConfig = () => {
    setConfigMode('create');
    setEditingSessionId(null);
    const placeName = activePlace?.name || savedPlaces[0]?.name || 'el Escenario';
    setSessionTitle(`Tertulia en ${placeName}`);

    // Default protagonist: current active character or first saved in library
    const defProtagonist = characterState?.id || savedCharacters[0]?.state?.id || 'current-active';
    setSelectedProtagonistId(defProtagonist);

    // Default companion: first available different character in library or preset
    const otherChars = savedCharacters.filter(c => c.state.id !== defProtagonist);
    if (otherChars.length > 0) {
      setSelectedCompanionIds([otherChars[0].state.id]);
    } else {
      setSelectedCompanionIds(['npc-valentin']);
    }

    setSelectedPlaceId(activePlace?.id || savedPlaces[0]?.id || '');
    setSelectedTone(characterState?.nsfw?.isNsfwEnabled ? 'R+18' : 'Aventura');
    setPhase('phase1_config');
  };

  // 2. REANUDAR / INICIAR SESIÓN -> Abre Pantalla 3 (Sala de Chat)
  const handleResumeSession = (session: InteractionSessionState) => {
    setActiveSessionId(session.id);
    setCurrentSession(session);
    if (typeof session.isOfflineMode === 'boolean') {
      setIsOfflineMode(session.isOfflineMode);
    }
    setPhase('phase2_chat');
  };

  // Alternar entre Modo Offline Autónomo y Modo Online
  const handleToggleOfflineMode = () => {
    const nextVal = !isOfflineMode;
    setIsOfflineMode(nextVal);
    if (currentSession) {
      const updated: InteractionSessionState = {
        ...currentSession,
        isOfflineMode: nextVal
      };
      setCurrentSession(updated);
      saveSessionState(updated);
      setSessions(loadAllSavedSessions());
    }
    showFeedback(
      nextVal
        ? '⚡ Modo 100% Offline Activado: Los agentes responderán y pensarán localmente con su terminal lógico.'
        : '🌐 Modo Online Activado: Conectado al modelo remoto con respaldo autónomo local.'
    );
  };

  // Obtener o inicializar memoria lógica del agente
  const getOrInitCompanionMemory = (
    companion: UnifiedParticipant,
    allCompanions: UnifiedParticipant[]
  ): AgentLogicalMemory => {
    if (currentSession?.companionMemories && currentSession.companionMemories[companion.id]) {
      return currentSession.companionMemories[companion.id];
    }
    const otherCompanions = allCompanions.filter(c => c.id !== companion.id);
    const newMem = initAgentLogicalMemory(companion, otherCompanions, currentSession?.protagonist?.name || 'Tú');
    if (currentSession) {
      const updatedMemories = {
        ...(currentSession.companionMemories || {}),
        [companion.id]: newMem
      };
      const updated: InteractionSessionState = {
        ...currentSession,
        companionMemories: updatedMemories
      };
      setCurrentSession(updated);
      saveSessionState(updated);
    }
    return newMem;
  };

  // Forzar reacción offline de un agente específico en la sala
  const handleForceAgentReaction = (agentId: string) => {
    if (!currentSession) return;
    const companions = (
      currentSession.companionAgents && currentSession.companionAgents.length > 0
        ? currentSession.companionAgents
        : [currentSession.npc, ...(currentSession.secondaryAgents || [])]
    ).filter(Boolean);

    const companion = companions.find(c => c.id === agentId);
    if (!companion) return;

    const otherCompanions = companions.filter(c => c.id !== companion.id);
    const currentMem = getOrInitCompanionMemory(companion, companions);
    const lastMsg = currentSession.dialogueHistory.slice(-1)[0];
    const lastText = lastMsg ? lastMsg.text : 'El grupo se encuentra observando el entorno en calma.';
    const lastSpeaker = lastMsg ? lastMsg.speakerName : (currentSession.protagonist?.name || 'Tú');

    const result = generateOfflineAgentResponse({
      agent: companion,
      memory: currentMem,
      lastMessageText: lastText,
      speakerName: lastSpeaker,
      protagonist: currentSession.protagonist,
      otherCompanions,
      place: currentSession.place,
      activeLaws: currentSession.worldBuilding?.laws || getActiveWorldLaws(),
      tone: currentSession.config?.storyTone || 'Aventura'
    });

    const botTimestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const newBotMsg = {
      id: `bot-forced-${Date.now()}`,
      speaker: 'npc' as const,
      speakerName: companion.name,
      speakerId: companion.id,
      text: result.text,
      timestamp: botTimestamp
    };

    const updatedMemories = {
      ...(currentSession.companionMemories || {}),
      [companion.id]: result.updatedMemory
    };

    const updatedSession: InteractionSessionState = {
      ...currentSession,
      companionMemories: updatedMemories,
      dialogueHistory: [...currentSession.dialogueHistory, newBotMsg]
    };

    saveSessionState(updatedSession);
    setCurrentSession(updatedSession);
    setSessions(loadAllSavedSessions());
    showFeedback(`⚡ Reacción autónoma emitida por ${companion.name}.`);
  };

  // Provocar diálogo cruzado (Banter) offline entre dos agentes en la sala
  const handleTriggerBanterBetweenAgents = (agentAId: string, agentBId: string) => {
    if (!currentSession) return;
    const companions = (
      currentSession.companionAgents && currentSession.companionAgents.length > 0
        ? currentSession.companionAgents
        : [currentSession.npc, ...(currentSession.secondaryAgents || [])]
    ).filter(Boolean);

    const compA = companions.find(c => c.id === agentAId);
    const compB = companions.find(c => c.id === agentBId);
    if (!compA || !compB) return;

    const memA = getOrInitCompanionMemory(compA, companions);
    const memB = getOrInitCompanionMemory(compB, companions);
    const lastMsg = currentSession.dialogueHistory.slice(-1)[0];
    const topic = lastMsg ? lastMsg.text : 'la travesía en este enclave';

    const banter = generateInterAgentBanterOffline({
      agentA: compA,
      memoryA: memA,
      agentB: compB,
      memoryB: memB,
      topicText: topic,
      placeName: currentSession.place?.name || 'la sala'
    });

    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const msgA = {
      id: `banter-a-${Date.now()}`,
      speaker: 'npc' as const,
      speakerName: compA.name,
      speakerId: compA.id,
      text: banter.responseA.text,
      timestamp: time
    };

    const msgB = {
      id: `banter-b-${Date.now() + 1}`,
      speaker: 'npc' as const,
      speakerName: compB.name,
      speakerId: compB.id,
      text: banter.responseB.text,
      timestamp: time
    };

    const updatedMemories = {
      ...(currentSession.companionMemories || {}),
      [compA.id]: banter.responseA.updatedMemory,
      [compB.id]: banter.responseB.updatedMemory
    };

    const updatedSession: InteractionSessionState = {
      ...currentSession,
      companionMemories: updatedMemories,
      dialogueHistory: [...currentSession.dialogueHistory, msgA, msgB]
    };

    saveSessionState(updatedSession);
    setCurrentSession(updatedSession);
    setSessions(loadAllSavedSessions());
    showFeedback(`💬 Intercambio cruzado generado entre ${compA.name} y ${compB.name}.`);
  };

  // Actualizar objetivo interno personalizado de un agente desde su Terminal Lógico
  const handleUpdateCompanionGoal = (agentId: string, newGoal: string) => {
    if (!currentSession || !newGoal.trim()) return;
    const companions = (
      currentSession.companionAgents && currentSession.companionAgents.length > 0
        ? currentSession.companionAgents
        : [currentSession.npc, ...(currentSession.secondaryAgents || [])]
    ).filter(Boolean);

    const companion = companions.find(c => c.id === agentId);
    if (!companion) return;

    const currentMemories = { ...(currentSession.companionMemories || {}) };
    const existingMem = currentMemories[agentId] || initAgentLogicalMemory(companion, companions.filter(c => c.id !== agentId), currentSession.protagonist?.name || 'Tú');

    currentMemories[agentId] = {
      ...existingMem,
      innerGoal: newGoal.trim()
    };

    const updatedSession: InteractionSessionState = {
      ...currentSession,
      companionMemories: currentMemories
    };

    saveSessionState(updatedSession);
    setCurrentSession(updatedSession);
    setSessions(loadAllSavedSessions());
    showFeedback(`Objetivo interno de ${companion.name} actualizado.`);
  };

  // 3. REINICIAR SESIÓN -> Limpia el historial de mensajes
  const handleExecuteRestartSession = (sessionId: string) => {
    const restarted = restartSessionHistory(sessionId);
    if (restarted) {
      const refreshed = loadAllSavedSessions();
      setSessions(refreshed);
      if (currentSession?.id === sessionId) {
        setCurrentSession(restarted);
      }
      showFeedback('Conversación reiniciada desde el saludo inicial.');
    }
    setConfirmRestartId(null);
  };

  // 4. EDITAR SESIÓN -> Abre Pantalla 2 con los datos de esta sesión
  const handleEditSessionConfig = (session: InteractionSessionState) => {
    setConfigMode('edit');
    setEditingSessionId(session.id);
    setSessionTitle(session.title);

    setSelectedProtagonistId(session.protagonist?.id || '');

    // Extract all companion IDs
    const existingCompIds: string[] = [];
    if (session.companionAgents && session.companionAgents.length > 0) {
      session.companionAgents.forEach(c => existingCompIds.push(c.id));
    } else {
      if (session.npc?.id) existingCompIds.push(session.npc.id);
      if (session.secondaryAgents) {
        session.secondaryAgents.forEach(a => existingCompIds.push(a.id));
      }
    }
    setSelectedCompanionIds(existingCompIds.length > 0 ? existingCompIds : ['npc-valentin']);

    setSelectedPlaceId(session.place?.id || '');
    setSelectedTone(session.config?.storyTone || 'Aventura');
    setPhase('phase1_config');
  };

  // 5. DUPLICAR SESIÓN -> Crea una copia independiente
  const handleDuplicateSession = (sessionId: string) => {
    const duplicated = duplicateSavedSession(sessionId);
    if (duplicated) {
      const refreshed = loadAllSavedSessions();
      setSessions(refreshed);
      showFeedback(`Sesión duplicada: "${duplicated.title}"`);
    }
  };

  // 6. ELIMINAR SESIÓN -> Borra la sesión
  const handleExecuteDeleteSession = (sessionId: string) => {
    const updated = deleteSavedSession(sessionId);
    setSessions(updated);
    if (currentSession?.id === sessionId) {
      setCurrentSession(updated[0] || null);
    }
    setConfirmDeleteId(null);
    showFeedback('Sesión eliminada con éxito.');
  };

  // ----------------------------------------------------------------
  // PANTALLA 2: TOGGLE / SELECT COMPANIONS & PROTAGONIST
  // ----------------------------------------------------------------
  const toggleCompanionSelection = (companionId: string) => {
    setSelectedCompanionIds(prev => {
      if (prev.includes(companionId)) {
        if (prev.length === 1) {
          // Keep at least one companion
          return prev;
        }
        return prev.filter(id => id !== companionId);
      } else {
        return [...prev, companionId];
      }
    });
  };

  // Convert a character ID into UnifiedParticipant
  const resolveParticipant = (id: string, roleLabel: string): UnifiedParticipant => {
    // Check if in saved characters
    const found = savedCharacters.find(c => c.state.id === id)?.state;
    if (found) {
      return characterStateToUnifiedParticipant(found, roleLabel);
    }
    // Check if matching current active character
    if (characterState && (characterState.id === id || id === 'current-active')) {
      return characterStateToUnifiedParticipant(characterState, roleLabel);
    }
    // Check preset canonical companions
    const preset = CANONICAL_PRESET_COMPANIONS.find(p => p.id === id);
    if (preset) {
      const dummy = createDefaultCharacterState();
      dummy.id = preset.id;
      dummy.name = preset.name;
      dummy.role = preset.role;
      dummy.raceName = preset.race;
      dummy.personality = preset.personality;
      if (dummy.identity) dummy.identity.fullName = preset.name;
      return characterStateToUnifiedParticipant(dummy, roleLabel);
    }
    // Fallback default
    const fallback = createDefaultCharacterState();
    fallback.id = id || `char-${Date.now()}`;
    fallback.name = 'Aventurero';
    return characterStateToUnifiedParticipant(fallback, roleLabel);
  };

  // ----------------------------------------------------------------
  // PANTALLA 2 -> PANTALLA 3: GUARDAR E INICIAR CHAT
  // ----------------------------------------------------------------
  const handleSaveAndLaunchChat = () => {
    const protagonist = resolveParticipant(selectedProtagonistId, 'Protagonista (Usuario)');

    // Resolve all selected companions (Acompañantes Principales / Agentes en Sala)
    const effectiveCompanionIds = selectedCompanionIds.length > 0 ? selectedCompanionIds : ['npc-valentin'];
    const companionParticipants = effectiveCompanionIds.map((cId, idx) =>
      resolveParticipant(cId, idx === 0 ? 'Acompañante Principal' : 'Acompañante Secundario')
    );

    const primaryCompanion = companionParticipants[0];
    const secondaryCompanions = companionParticipants.slice(1);

    // Resolve place
    const chosenPlace = savedPlaces.find(p => p.id === selectedPlaceId) || activePlace || savedPlaces[0];
    if (chosenPlace && onSetActivePlace) {
      onSetActivePlace(chosenPlace);
    }

    const worldLaws = getActiveWorldLaws();

    if (configMode === 'edit' && editingSessionId) {
      // Edit existing session
      const existing = sessions.find(s => s.id === editingSessionId);
      const updatedSession: InteractionSessionState = {
        ...(existing || {} as any),
        id: editingSessionId,
        title: sessionTitle.trim() || `Tertulia en ${chosenPlace?.name || 'el Escenario'}`,
        subtitle: `${protagonist.name} con ${companionParticipants.map(c => c.name).join(', ')}`,
        savedAt: 'Ahora',
        phase: 'phase2_chat',
        protagonist,
        npc: primaryCompanion,
        secondaryAgents: secondaryCompanions,
        companionAgents: companionParticipants,
        worldBuilding: {
          id: worldConfig.id || 'wb-default',
          worldName: worldConfig.worldName || 'Elysium',
          laws: worldLaws,
          summary: worldConfig.history?.origin || 'Mundo de reglas activas y cosmología integrada.'
        },
        place: {
          id: chosenPlace?.id || 'LOC-current',
          name: chosenPlace?.name || 'Recinto de Encuentros',
          zoneName: 'Área Central',
          initialCoords: { x: 0, y: 0 },
          weather: 'Atmósfera característica del entorno',
          hour: '17:00 - Atardecer',
          details: chosenPlace?.description || chosenPlace?.atmosphere || 'Un entorno propicio para el intercambio.'
        },
        config: {
          npcDensity: 'Moderados',
          storyTone: selectedTone,
          battleEnabled: false
        },
        eventLogs: existing?.eventLogs || [
          {
            id: `ev-${Date.now()}`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            category: 'ENTORNO',
            title: 'Elenco actualizado',
            text: `Se reconfiguró la tertulia en ${chosenPlace?.name || 'el escenario'}.`
          }
        ],
        dialogueHistory: existing?.dialogueHistory?.length ? existing.dialogueHistory : [
          {
            id: `dlg-${Date.now()}`,
            speaker: 'npc',
            speakerName: primaryCompanion.name,
            speakerId: primaryCompanion.id,
            text: `*Te recibe con afabilidad en ${chosenPlace?.name || 'este lugar'}.* «Saludos, ${protagonist.name}. Estamos listos para continuar nuestra conversación.»`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]
      };

      saveSessionState(updatedSession);
      setCurrentSession(updatedSession);
      setSessions(loadAllSavedSessions());
      setPhase('phase2_chat');
      showFeedback('Configuración guardada.');
    } else {
      // Create fresh new session
      const newSession: InteractionSessionState = {
        id: `chat-session-${Date.now()}`,
        title: sessionTitle.trim() || `Tertulia en ${chosenPlace?.name || 'el Escenario'}`,
        subtitle: `${protagonist.name} con ${companionParticipants.map(c => c.name).join(', ')}`,
        savedAt: 'Ahora',
        phase: 'phase2_chat',
        protagonist,
        npc: primaryCompanion,
        secondaryAgents: secondaryCompanions,
        companionAgents: companionParticipants,
        worldBuilding: {
          id: worldConfig.id || 'wb-default',
          worldName: worldConfig.worldName || 'Elysium',
          laws: worldLaws,
          summary: worldConfig.history?.origin || 'Mundo de reglas activas y cosmología integrada.'
        },
        place: {
          id: chosenPlace?.id || 'LOC-current',
          name: chosenPlace?.name || 'Recinto de Encuentros',
          zoneName: 'Área Central',
          initialCoords: { x: 0, y: 0 },
          weather: 'Atmósfera característica del entorno',
          hour: '17:00 - Atardecer',
          details: chosenPlace?.description || chosenPlace?.atmosphere || 'Un entorno propicio para el intercambio.'
        },
        config: {
          npcDensity: 'Moderados',
          storyTone: selectedTone,
          battleEnabled: false
        },
        eventLogs: [
          {
            id: `ev-init-${Date.now()}`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            category: 'ENTORNO',
            title: 'Inicio de la interacción',
            text: `Se abre la sala de conversación en ${chosenPlace?.name || 'el escenario'} bajo las leyes de ${worldConfig.worldName || 'Elysium'}.`
          }
        ],
        dialogueHistory: [
          {
            id: `dlg-init-${Date.now()}`,
            speaker: 'npc',
            speakerName: primaryCompanion.name,
            speakerId: primaryCompanion.id,
            text: `*Te saluda con un gesto atento al contemplar ${chosenPlace?.name || 'el entorno'}.* «Bienvenido, ${protagonist.name}. Es un momento propicio para conversar. ¿Qué asunto o curiosidad deseas tratar en ${chosenPlace?.name || 'este lugar'}?»`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]
      };

      saveSessionState(newSession);
      setCurrentSession(newSession);
      setSessions(loadAllSavedSessions());
      setPhase('phase2_chat');
      showFeedback('Nueva sesión de chat iniciada.');
    }
  };

  // ----------------------------------------------------------------
  // PANTALLA 3: CHAT MESSAGE DISPATCHER (MULTI-AGENT)
  // ----------------------------------------------------------------
  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputText).trim();
    if (!text || !currentSession || isGenerating) return;

    setInputText('');

    const userTimestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const userMsgId = `usr-${Date.now()}`;

    // Append user message immediately to session
    const updatedHistory = [
      ...currentSession.dialogueHistory,
      {
        id: userMsgId,
        speaker: 'protagonist' as const,
        speakerName: currentSession.protagonist.name || 'Tú',
        speakerId: currentSession.protagonist.id || 'user',
        text,
        timestamp: userTimestamp
      }
    ];

    const updatedSessionState: InteractionSessionState = {
      ...currentSession,
      dialogueHistory: updatedHistory
    };

    saveSessionState(updatedSessionState);
    setCurrentSession(updatedSessionState);
    setIsGenerating(true);

    try {
      // Si el objetivo es el Narrador de Escena (IA OOC - Escenario, ambiente, objetos, consecuencias)
      if (targetSpeakerId === 'narrator') {
        const botTimestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const companionsPresent: UnifiedParticipant[] = (
          currentSession.companionAgents && currentSession.companionAgents.length > 0
            ? currentSession.companionAgents
            : [currentSession.npc, ...(currentSession.secondaryAgents || [])]
        ).filter(Boolean);

        if (isOfflineMode) {
          const offlineResult = generateAutonomousSceneNarrationFull({
            userAction: text,
            place: {
              name: currentSession.place.name,
              zoneName: currentSession.place.zoneName || activePlace?.region || 'Área Central',
              weather: currentSession.place.weather || 'Clima templado',
              hour: currentSession.place.hour || 'Atardecer',
              details: currentSession.place.details || activePlace?.description || activePlace?.atmosphere,
              atmosphere: activePlace?.atmosphere || currentSession.place.details
            },
            worldBuilding: {
              worldName: currentSession.worldBuilding?.worldName || worldConfig.worldName || 'Elysium',
              laws: currentSession.worldBuilding?.laws || getActiveWorldLaws()
            },
            recentHistory: updatedHistory.slice(-14),
            protagonist: currentSession.protagonist,
            companions: companionsPresent,
            conversationMemory: currentSession.conversationMemory
          });

          const newNarratorMsg = {
            id: `narrator-offline-${Date.now()}`,
            speaker: 'narrator' as const,
            speakerName: 'Narrador',
            text: offlineResult.text,
            timestamp: botTimestamp,
            narratorAnalysis: {
              directorIntent: offlineResult.directorIntent,
              environmentalShift: offlineResult.environmentalShift,
              castReactionsSummary: offlineResult.castReactionsSummary,
              narrativeHooks: offlineResult.narrativeHooks,
              isOocDirectAnswer: offlineResult.isOocDirectAnswer
            }
          };

          const finalSession: InteractionSessionState = {
            ...updatedSessionState,
            isOfflineMode: true,
            dialogueHistory: [...updatedHistory, newNarratorMsg]
          };
          saveSessionState(finalSession);
          setCurrentSession(finalSession);
          setSessions(loadAllSavedSessions());
          setIsGenerating(false);
          return;
        }

        // Modo Online para Narrador OOC con comprensión holística de elenco, mundo y memoria
        const narratorResponse = await fetch('/api/multiagent-chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            isNarrator: true,
            speakerType: 'narrator',
            speakerName: 'Narrador',
            userMessage: text,
            protagonist: currentSession.protagonist,
            npc: currentSession.npc,
            companionAgents: companionsPresent,
            companionMemories: currentSession.companionMemories || {},
            conversationMemory: currentSession.conversationMemory,
            place: {
              name: currentSession.place.name,
              zoneName: currentSession.place.zoneName || activePlace?.region || 'Área Central',
              weather: currentSession.place.weather || 'Clima templado',
              hour: currentSession.place.hour || 'Atardecer',
              details: currentSession.place.details || activePlace?.description || activePlace?.atmosphere,
              atmosphere: activePlace?.atmosphere || currentSession.place.details,
              rhythmOrVibes: activePlace?.rhythmOrVibes || []
            },
            worldBuilding: {
              worldName: currentSession.worldBuilding?.worldName || worldConfig.worldName || 'Elysium',
              laws: currentSession.worldBuilding?.laws || getActiveWorldLaws()
            },
            history: updatedHistory.slice(-28)
          })
        });

        if (!narratorResponse.ok) {
          throw new Error('Error al conectar con el narrador de escena');
        }

        const narratorData = await narratorResponse.json();
        const newNarratorMsg = {
          id: `narrator-${Date.now()}`,
          speaker: 'narrator' as const,
          speakerName: narratorData.speakerName || 'Narrador',
          text: narratorData.text,
          timestamp: botTimestamp,
          narratorAnalysis: {
            directorIntent: narratorData.directorIntent,
            environmentalShift: narratorData.environmentalShift,
            castReactionsSummary: narratorData.castReactionsSummary,
            narrativeHooks: narratorData.narrativeHooks,
            isOocDirectAnswer: narratorData.isOocDirectAnswer
          }
        };

        // Si el narrador reveló un nuevo hecho canónico, sincronizar con la memoria
        let updatedMem = currentSession.conversationMemory;
        if (narratorData.discoveredFact && typeof narratorData.discoveredFact === 'string' && narratorData.discoveredFact.trim()) {
          const fact = narratorData.discoveredFact.trim();
          const existingFacts = updatedMem?.keyFacts || [];
          if (!existingFacts.includes(fact)) {
            updatedMem = {
              ...(updatedMem || { keyFacts: [], agreementsAndPromises: [], openQuestions: [], activeTopics: [] }),
              keyFacts: [...existingFacts, fact]
            };
          }
        }

        const finalSession: InteractionSessionState = {
          ...updatedSessionState,
          conversationMemory: updatedMem,
          dialogueHistory: [...updatedHistory, newNarratorMsg]
        };
        saveSessionState(finalSession);
        setCurrentSession(finalSession);
        setSessions(loadAllSavedSessions());
        setIsGenerating(false);
        return;
      }

      // Determine which companions are present
      const companions: UnifiedParticipant[] = (
        currentSession.companionAgents && currentSession.companionAgents.length > 0
          ? currentSession.companionAgents
          : [currentSession.npc, ...(currentSession.secondaryAgents || [])]
      ).filter(Boolean);

      let targetSpeaker: UnifiedParticipant = companions[0];

      if (targetSpeakerId !== 'all') {
        const found = companions.find(s => s.id === targetSpeakerId || s.name === targetSpeakerId);
        if (found) targetSpeaker = found;
      } else if (companions.length > 1) {
        // If 'all', alternate between companions
        const lastNpcMsg = [...updatedHistory].reverse().find(m => m.speaker === 'npc' || m.speaker === 'agent');
        if (lastNpcMsg && lastNpcMsg.speakerId) {
          const alternate = companions.find(s => s.id !== lastNpcMsg.speakerId);
          if (alternate && Math.random() > 0.35) {
            targetSpeaker = alternate;
          }
        }
      }

      const otherCompanions = companions.filter(c => c.id !== targetSpeaker.id);

      // Si estamos en MODO OFFLINE, ejecutamos el motor autónomo local directamente
      if (isOfflineMode) {
        const currentMemories = { ...(currentSession.companionMemories || {}) };
        const agentMem = currentMemories[targetSpeaker.id] || initAgentLogicalMemory(targetSpeaker, otherCompanions, currentSession.protagonist?.name || 'Tú');

        const offlineResult = generateOfflineAgentResponse({
          agent: targetSpeaker,
          memory: agentMem,
          lastMessageText: text,
          speakerName: currentSession.protagonist?.name || 'Tú',
          protagonist: currentSession.protagonist,
          otherCompanions,
          place: currentSession.place,
          activeLaws: currentSession.worldBuilding?.laws || getActiveWorldLaws(),
          tone: currentSession.config?.storyTone || 'Aventura'
        });

        currentMemories[targetSpeaker.id] = offlineResult.updatedMemory;

        const botTimestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const newBotMsg = {
          id: `bot-offline-${Date.now()}`,
          speaker: 'npc' as const,
          speakerName: targetSpeaker.name,
          speakerId: targetSpeaker.id,
          text: offlineResult.text,
          timestamp: botTimestamp
        };

        const followUpMessages = [newBotMsg];

        // Evaluar si otro compañero en sala desea interponerse o reaccionar autónomamente
        if (targetSpeakerId === 'all' && otherCompanions.length > 0) {
          const secondCompanion = otherCompanions[0];
          const secondMem = currentMemories[secondCompanion.id] || initAgentLogicalMemory(secondCompanion, [targetSpeaker, ...otherCompanions.filter(c => c.id !== secondCompanion.id)], currentSession.protagonist?.name || 'Tú');
          const willing = evaluateAgentReactionWillingness(secondCompanion, secondMem, offlineResult.text, targetSpeaker.name, targetSpeaker.id);

          if (willing.shouldReact && Math.random() > 0.35) {
            const secondResponse = generateOfflineAgentResponse({
              agent: secondCompanion,
              memory: secondMem,
              lastMessageText: offlineResult.text,
              speakerName: targetSpeaker.name,
              protagonist: currentSession.protagonist,
              otherCompanions: [targetSpeaker, ...otherCompanions.filter(c => c.id !== secondCompanion.id)],
              place: currentSession.place,
              activeLaws: currentSession.worldBuilding?.laws || getActiveWorldLaws(),
              tone: currentSession.config?.storyTone || 'Aventura'
            });

            currentMemories[secondCompanion.id] = secondResponse.updatedMemory;
            followUpMessages.push({
              id: `bot-offline-interject-${Date.now()}`,
              speaker: 'npc' as const,
              speakerName: secondCompanion.name,
              speakerId: secondCompanion.id,
              text: secondResponse.text,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            });
          }
        }

        const finalSession: InteractionSessionState = {
          ...updatedSessionState,
          isOfflineMode: true,
          companionMemories: currentMemories,
          dialogueHistory: [...updatedHistory, ...followUpMessages]
        };

        saveSessionState(finalSession);
        setCurrentSession(finalSession);
        setSessions(loadAllSavedSessions());
        setIsGenerating(false);
        return;
      }

      // MODO ONLINE: Llamar al endpoint del servidor
      const response = await fetch('/api/multiagent-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          speakerId: targetSpeaker.id,
          speakerName: targetSpeaker.name,
          speakerRole: targetSpeaker.role,
          speakerArchetype: targetSpeaker.title || targetSpeaker.role,
          speakerPersonality: targetSpeaker.personality || targetSpeaker.personalityTraits?.join(', '),
          speakerRace: targetSpeaker.race || 'Humanoide',
          speakerFaction: targetSpeaker.faction,
          speakerMoralAlignment: targetSpeaker.moralAlignment || 'Neutral',
          speakerMotivations: targetSpeaker.motivations,
          speakerCoreValues: targetSpeaker.coreValues,
          speakerGreatestFear: targetSpeaker.greatestFear,
          speakerHabits: targetSpeaker.habitsAndMannerisms,
          speakerEmotionalState: targetSpeaker.emotionalState || 'Atento y receptivo',
          speakerAffinity: targetSpeaker.affinity,
          speakerDialogueExcerpt: targetSpeaker.dialogueExcerpt,
          speakerSomatic: targetSpeaker.somaticAwareness,
          speakerWardrobe: targetSpeaker.wardrobeAwareness,
          speakerAlternateVersions: targetSpeaker.alternateVersionsAwareness,
          speakerDirectives: targetSpeaker.aiTrainingDirectives,
          speakerAutonomy: targetSpeaker.autonomyLevel,
          protagonist: {
            name: currentSession.protagonist.name,
            title: currentSession.protagonist.title,
            role: currentSession.protagonist.role,
            race: currentSession.protagonist.race || 'Humano',
            personality: currentSession.protagonist.personality || currentSession.protagonist.personalityTraits?.join(', '),
            moralAlignment: currentSession.protagonist.moralAlignment,
            faction: currentSession.protagonist.faction
          },
          npc: {
            name: targetSpeaker.name,
            role: targetSpeaker.role,
            race: targetSpeaker.race
          },
          secondaryAgents: otherCompanions.map(a => ({
            name: a.name,
            role: a.role,
            race: a.race || 'Humano',
            personality: a.personality || a.personalityTraits?.join(', '),
            archetype: a.title || a.role
          })),
          place: {
            name: currentSession.place.name,
            zoneName: currentSession.place.zoneName || activePlace?.region || 'Área Central',
            weather: currentSession.place.weather || 'Clima templado',
            hour: currentSession.place.hour || 'Atardecer',
            details: currentSession.place.details || activePlace?.description || activePlace?.atmosphere,
            atmosphere: activePlace?.atmosphere || currentSession.place.details,
            rhythmOrVibes: activePlace?.rhythmOrVibes || []
          },
          worldBuilding: {
            worldName: currentSession.worldBuilding?.worldName || worldConfig.worldName || 'Elysium',
            laws: currentSession.worldBuilding?.laws || getActiveWorldLaws()
          },
          history: updatedHistory.slice(-28),
          conversationMemory: currentSession.conversationMemory,
          userMessage: text,
          isAmbientEvent: false
        })
      });

      if (!response.ok) {
        throw new Error('Respuesta inválida del servidor');
      }

      const data = await response.json();
      const botTimestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      const newBotMsg = {
        id: `bot-${Date.now()}`,
        speaker: 'npc' as const,
        speakerName: data.speakerName || targetSpeaker.name,
        speakerId: targetSpeaker.id,
        text: data.text,
        timestamp: botTimestamp,
        innerMonologue: data.innerMonologue || undefined,
        somaticObservation: data.somaticObservation || undefined,
        cognitiveTrace: data.cognitiveTrace || undefined
      };

      // Sincronizar memoria del agente en el Terminal Lógico tras respuesta online
      const currentMemories = { ...(currentSession.companionMemories || {}) };
      const agentMem = currentMemories[targetSpeaker.id] || initAgentLogicalMemory(targetSpeaker, otherCompanions, currentSession.protagonist?.name || 'Tú');
      currentMemories[targetSpeaker.id] = {
        ...agentMem,
        episodicEvents: [
          ...agentMem.episodicEvents,
          {
            turn: agentMem.episodicEvents.length + 1,
            speakerName: currentSession.protagonist?.name || 'Tú',
            summary: text.slice(0, 80),
            reactionType: 'acuerdo',
            timestamp: botTimestamp
          }
        ].slice(-30),
        innerMonologueLog: [
          ...agentMem.innerMonologueLog,
          {
            thought: data.innerMonologue || `He respondido a ${currentSession.protagonist?.name || 'Tú'} considerando mis principios de ${targetSpeaker.moralAlignment || 'Neutral'}.`,
            timestamp: botTimestamp,
            trigger: `Intervención de ${currentSession.protagonist?.name || 'Tú'}`
          }
        ].slice(-25)
      };

      // Fusión automática de memoria conversacional a largo plazo si vino en la respuesta
      let updatedConversationMemory = currentSession.conversationMemory;
      if (data.memoryUpdate) {
        updatedConversationMemory = mergeMemoryUpdates(currentSession.conversationMemory, {
          turnCount: updatedHistory.length + 1,
          keyFacts: data.memoryUpdate.keyFacts || [],
          agreementsAndPromises: data.memoryUpdate.agreementsAndPromises || [],
          unresolvedQuestions: data.memoryUpdate.unresolvedQuestions || []
        });
      }

      const finalSession: InteractionSessionState = {
        ...updatedSessionState,
        companionMemories: currentMemories,
        conversationMemory: updatedConversationMemory,
        dialogueHistory: [...updatedHistory, newBotMsg]
      };

      saveSessionState(finalSession);
      setCurrentSession(finalSession);
      setSessions(loadAllSavedSessions());
    } catch (err) {
      console.warn('Fallback message on network error:', err);

      const botTimestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      // Si el objetivo era el Narrador, generamos narración de escena local profunda con elenco y memoria
      if (targetSpeakerId === 'narrator') {
        const companionsPresent: UnifiedParticipant[] = (
          currentSession.companionAgents && currentSession.companionAgents.length > 0
            ? currentSession.companionAgents
            : [currentSession.npc, ...(currentSession.secondaryAgents || [])]
        ).filter(Boolean);

        const offlineResult = generateAutonomousSceneNarrationFull({
          userAction: text,
          place: {
            name: currentSession.place.name,
            zoneName: currentSession.place.zoneName || activePlace?.region || 'Área Central',
            weather: currentSession.place.weather || 'Clima templado',
            hour: currentSession.place.hour || 'Atardecer',
            details: currentSession.place.details || activePlace?.description || activePlace?.atmosphere,
            atmosphere: activePlace?.atmosphere || currentSession.place.details
          },
          worldBuilding: {
            worldName: currentSession.worldBuilding?.worldName || worldConfig.worldName || 'Elysium',
            laws: currentSession.worldBuilding?.laws || getActiveWorldLaws()
          },
          recentHistory: updatedHistory.slice(-14),
          protagonist: currentSession.protagonist,
          companions: companionsPresent,
          conversationMemory: currentSession.conversationMemory
        });

        const fallbackNarratorMsg = {
          id: `narrator-fallback-${Date.now()}`,
          speaker: 'narrator' as const,
          speakerName: 'Narrador',
          text: offlineResult.text,
          timestamp: botTimestamp,
          narratorAnalysis: {
            directorIntent: offlineResult.directorIntent,
            environmentalShift: offlineResult.environmentalShift,
            castReactionsSummary: offlineResult.castReactionsSummary,
            narrativeHooks: offlineResult.narrativeHooks,
            isOocDirectAnswer: offlineResult.isOocDirectAnswer
          }
        };

        const fallbackSession: InteractionSessionState = {
          ...updatedSessionState,
          dialogueHistory: [...updatedHistory, fallbackNarratorMsg]
        };

        saveSessionState(fallbackSession);
        setCurrentSession(fallbackSession);
        setSessions(loadAllSavedSessions());
        showFeedback('Narración de Escena y razonamiento OOC generados localmente por el motor sensorial autónomo.');
        return;
      }

      // Fallback inteligente offline usando el motor local autónomo para personajes
      const companions = (
        currentSession.companionAgents && currentSession.companionAgents.length > 0
          ? currentSession.companionAgents
          : [currentSession.npc, ...(currentSession.secondaryAgents || [])]
      ).filter(Boolean);
      const fallbackCompanion = companions[0] || currentSession.npc;
      const otherCompanions = companions.filter(c => c.id !== fallbackCompanion.id);

      const currentMemories = { ...(currentSession.companionMemories || {}) };
      const agentMem = currentMemories[fallbackCompanion.id] || initAgentLogicalMemory(fallbackCompanion, otherCompanions, currentSession.protagonist?.name || 'Tú');

      const offlineResult = generateOfflineAgentResponse({
        agent: fallbackCompanion,
        memory: agentMem,
        lastMessageText: text,
        speakerName: currentSession.protagonist?.name || 'Tú',
        protagonist: currentSession.protagonist,
        otherCompanions,
        place: currentSession.place,
        activeLaws: currentSession.worldBuilding?.laws || getActiveWorldLaws(),
        tone: currentSession.config?.storyTone || 'Aventura'
      });

      currentMemories[fallbackCompanion.id] = offlineResult.updatedMemory;

      const fallbackMsg = {
        id: `bot-fallback-${Date.now()}`,
        speaker: 'npc' as const,
        speakerName: fallbackCompanion.name,
        speakerId: fallbackCompanion.id,
        text: offlineResult.text,
        timestamp: botTimestamp
      };

      const fallbackSession: InteractionSessionState = {
        ...updatedSessionState,
        companionMemories: currentMemories,
        dialogueHistory: [...updatedHistory, fallbackMsg]
      };

      saveSessionState(fallbackSession);
      setCurrentSession(fallbackSession);
      setSessions(loadAllSavedSessions());
      showFeedback('Sin conexión: Respuesta generada localmente por el Terminal Lógico.');
    } finally {
      setIsGenerating(false);
    }
  };

  // Trigger sensory ambient event
  const handleTriggerAmbientEvent = async () => {
    if (!currentSession || isGenerating) return;
    setIsGenerating(true);

    try {
      const companionsPresent = (
        currentSession.companionAgents && currentSession.companionAgents.length > 0
          ? currentSession.companionAgents
          : [currentSession.npc, ...(currentSession.secondaryAgents || [])]
      ).filter(Boolean);

      let ambientText = '';
      let narratorAnalysisData: any = null;

      if (isOfflineMode) {
        const offlineResult = generateAutonomousSceneNarrationFull({
          userAction: 'El fluir del tiempo, las luces y las corrientes en la estancia',
          place: {
            name: currentSession.place.name,
            zoneName: currentSession.place.zoneName || activePlace?.region || 'Área Central',
            weather: currentSession.place.weather || 'Clima templado',
            hour: currentSession.place.hour || '17:00',
            details: currentSession.place.details || activePlace?.description || activePlace?.atmosphere,
            atmosphere: activePlace?.atmosphere || currentSession.place.details
          },
          worldBuilding: {
            worldName: currentSession.worldBuilding?.worldName || worldConfig.worldName || 'Elysium',
            laws: currentSession.worldBuilding?.laws || getActiveWorldLaws()
          },
          recentHistory: currentSession.dialogueHistory.slice(-14),
          protagonist: currentSession.protagonist,
          companions: companionsPresent,
          conversationMemory: currentSession.conversationMemory
        });
        ambientText = offlineResult.text;
        narratorAnalysisData = {
          directorIntent: offlineResult.directorIntent,
          environmentalShift: offlineResult.environmentalShift,
          castReactionsSummary: offlineResult.castReactionsSummary,
          narrativeHooks: offlineResult.narrativeHooks,
          isOocDirectAnswer: false
        };
      } else {
        const response = await fetch('/api/multiagent-chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            protagonist: currentSession.protagonist,
            npc: currentSession.npc,
            companionAgents: companionsPresent,
            companionMemories: currentSession.companionMemories || {},
            conversationMemory: currentSession.conversationMemory,
            place: {
              name: currentSession.place.name,
              zoneName: currentSession.place.zoneName || activePlace?.region || 'Área Central',
              weather: currentSession.place.weather || 'Clima templado',
              hour: currentSession.place.hour || '17:00',
              details: currentSession.place.details || activePlace?.description || activePlace?.atmosphere,
              atmosphere: activePlace?.atmosphere || currentSession.place.details,
              rhythmOrVibes: activePlace?.rhythmOrVibes || []
            },
            worldBuilding: {
              worldName: currentSession.worldBuilding?.worldName || worldConfig.worldName || 'Elysium',
              laws: currentSession.worldBuilding?.laws || getActiveWorldLaws()
            },
            history: currentSession.dialogueHistory.slice(-28),
            isAmbientEvent: true
          })
        });

        if (!response.ok) {
          throw new Error('Error al solicitar evento ambiental');
        }
        const data = await response.json();
        ambientText = data.text;
        narratorAnalysisData = {
          directorIntent: data.directorIntent,
          environmentalShift: data.environmentalShift,
          castReactionsSummary: data.castReactionsSummary,
          narrativeHooks: data.narrativeHooks,
          isOocDirectAnswer: false
        };
      }

      const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      const updatedWithAmbient: InteractionSessionState = {
        ...currentSession,
        dialogueHistory: [
          ...currentSession.dialogueHistory,
          {
            id: `ambient-${Date.now()}`,
            speaker: 'narrator' as const,
            speakerName: 'Atmósfera',
            text: ambientText,
            timestamp: time,
            narratorAnalysis: narratorAnalysisData
          }
        ]
      };

      saveSessionState(updatedWithAmbient);
      setCurrentSession(updatedWithAmbient);
      setSessions(loadAllSavedSessions());
    } catch (e) {
      console.warn('Error generating ambient event, using autonomous local narration:', e);
      const companionsPresent = (
        currentSession.companionAgents && currentSession.companionAgents.length > 0
          ? currentSession.companionAgents
          : [currentSession.npc, ...(currentSession.secondaryAgents || [])]
      ).filter(Boolean);

      const offlineResult = generateAutonomousSceneNarrationFull({
        userAction: 'El entorno reacciona a la quietud del lugar',
        place: {
          name: currentSession.place.name,
          zoneName: currentSession.place.zoneName || activePlace?.region || 'Área Central',
          weather: currentSession.place.weather || 'Clima templado',
          hour: currentSession.place.hour || '17:00',
          details: currentSession.place.details || activePlace?.description || activePlace?.atmosphere,
          atmosphere: activePlace?.atmosphere || currentSession.place.details
        },
        worldBuilding: {
          worldName: currentSession.worldBuilding?.worldName || worldConfig.worldName || 'Elysium',
          laws: currentSession.worldBuilding?.laws || getActiveWorldLaws()
        },
        recentHistory: currentSession.dialogueHistory.slice(-14),
        protagonist: currentSession.protagonist,
        companions: companionsPresent,
        conversationMemory: currentSession.conversationMemory
      });

      const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      const updatedWithAmbient: InteractionSessionState = {
        ...currentSession,
        dialogueHistory: [
          ...currentSession.dialogueHistory,
          {
            id: `ambient-${Date.now()}`,
            speaker: 'narrator' as const,
            speakerName: 'Atmósfera',
            text: offlineResult.text,
            timestamp: time,
            narratorAnalysis: {
              directorIntent: offlineResult.directorIntent,
              environmentalShift: offlineResult.environmentalShift,
              castReactionsSummary: offlineResult.castReactionsSummary,
              narrativeHooks: offlineResult.narrativeHooks,
              isOocDirectAnswer: false
            }
          }
        ]
      };

      saveSessionState(updatedWithAmbient);
      setCurrentSession(updatedWithAmbient);
      setSessions(loadAllSavedSessions());
    } finally {
      setIsGenerating(false);
    }
  };

  // Text-To-Speech
  const handlePlayTts = async (msgId: string, text: string) => {
    if (currentlyPlayingAudio) {
      currentlyPlayingAudio.pause();
      setCurrentlyPlayingAudio(null);
      if (ttsLoadingId === msgId) {
        setTtsLoadingId(null);
        return;
      }
    }

    setTtsLoadingId(msgId);

    try {
      const cleanSpeech = text.replace(/\*[^*]+\*/g, '').trim() || text;
      const response = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: cleanSpeech, language: 'Spanish' })
      });

      if (!response.ok) throw new Error('TTS falló');
      const data = await response.json();

      if (data.audio) {
        const audioBlob = new Blob([Uint8Array.from(atob(data.audio), c => c.charCodeAt(0))], { type: 'audio/mp3' });
        const audioUrl = URL.createObjectURL(audioBlob);
        const audio = new Audio(audioUrl);
        audio.onended = () => {
          setTtsLoadingId(null);
          setCurrentlyPlayingAudio(null);
        };
        audio.play();
        setCurrentlyPlayingAudio(audio);
      }
    } catch (e) {
      console.warn('Error de TTS:', e);
      setTtsLoadingId(null);
    }
  };

  // Exportar y descargar transcripción persistida
  const handleDownloadTranscript = () => {
    if (!currentSession) return;
    const text = exportSessionTranscriptAsText(currentSession);
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `dialogo_${(currentSession.title || 'sesion').replace(/[^a-zA-Z0-9_-]/g, '_').toLowerCase()}_${Date.now()}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showFeedback('Transcripción descargada exitosamente (.txt).');
  };

  const handleCopyTranscript = async () => {
    if (!currentSession) return;
    const text = exportSessionTranscriptAsText(currentSession);
    try {
      await navigator.clipboard.writeText(text);
      setCopiedTranscript(true);
      setTimeout(() => setCopiedTranscript(false), 3000);
      showFeedback('Transcripción copiada al portapapeles.');
    } catch {
      showFeedback('No se pudo copiar automáticamente.');
    }
  };

  // Consolidación y Razonamiento Profundo de Memoria Episódica
  const handleConsolidateMemory = async () => {
    if (!currentSession) return;
    setIsAnalyzingMemory(true);

    try {
      if (isOfflineMode) {
        // Consolidación heurística determinista local
        const offlineMemory = extractMemoryInsightsOffline({
          dialogueHistory: currentSession.dialogueHistory || [],
          existingMemory: currentSession.conversationMemory,
          placeName: currentSession.place?.name,
          protagonistName: currentSession.protagonist?.name
        });

        const updatedSession: InteractionSessionState = {
          ...currentSession,
          conversationMemory: offlineMemory
        };
        saveSessionState(updatedSession);
        setCurrentSession(updatedSession);
        setSessions(loadAllSavedSessions());
        showFeedback('Memoria cognitiva analizada y consolidada mediante el motor local.');
        return;
      }

      // Llamada al endpoint de análisis y síntesis profunda
      const response = await fetch('/api/analyze-conversation-memory', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dialogueHistory: currentSession.dialogueHistory || [],
          place: currentSession.place,
          worldBuilding: currentSession.worldBuilding,
          currentMemory: currentSession.conversationMemory,
          companions: currentSession.companionAgents || [currentSession.npc, ...(currentSession.secondaryAgents || [])],
          protagonistName: currentSession.protagonist?.name
        })
      });

      if (!response.ok) throw new Error('Fallo al consolidar memoria');
      const data = await response.json();

      if (data.memory) {
        const updatedSession: InteractionSessionState = {
          ...currentSession,
          conversationMemory: data.memory
        };
        saveSessionState(updatedSession);
        setCurrentSession(updatedSession);
        setSessions(loadAllSavedSessions());
        showFeedback(data.source === 'ai_synthesis'
          ? '¡Memoria y razonamiento del elenco consolidados con IA!'
          : 'Memoria y razonamiento del elenco consolidados con éxito.');
      }
    } catch (e) {
      console.warn('Fallback offline para consolidación de memoria:', e);
      const offlineMemory = extractMemoryInsightsOffline({
        dialogueHistory: currentSession.dialogueHistory || [],
        existingMemory: currentSession.conversationMemory,
        placeName: currentSession.place?.name,
        protagonistName: currentSession.protagonist?.name
      });
      const updatedSession: InteractionSessionState = {
        ...currentSession,
        conversationMemory: offlineMemory
      };
      saveSessionState(updatedSession);
      setCurrentSession(updatedSession);
      setSessions(loadAllSavedSessions());
      showFeedback('Memoria consolidada localmente con el analizador heurístico.');
    } finally {
      setIsAnalyzingMemory(false);
    }
  };

  const handleAddFact = (factText: string) => {
    if (!currentSession || !factText.trim()) return;
    const currentMem = currentSession.conversationMemory || {
      turnCount: currentSession.dialogueHistory?.length || 0,
      summary: '',
      keyFacts: [],
      agreementsAndPromises: [],
      unresolvedQuestions: [],
      activeTopics: [],
      characterPerspectives: {},
      lastUpdatedTimestamp: new Date().toLocaleTimeString()
    };

    const updatedMem: EnhancedConversationMemory = {
      ...currentMem,
      keyFacts: [...(currentMem.keyFacts || []), factText.trim()],
      lastUpdatedTimestamp: new Date().toLocaleTimeString()
    };

    const updatedSession: InteractionSessionState = {
      ...currentSession,
      conversationMemory: updatedMem
    };
    saveSessionState(updatedSession);
    setCurrentSession(updatedSession);
    setSessions(loadAllSavedSessions());
    setNewFactInput('');
    showFeedback('Hecho canónico registrado en la memoria a largo plazo.');
  };

  const handleRemoveFact = (index: number) => {
    if (!currentSession || !currentSession.conversationMemory) return;
    const currentFacts = [...(currentSession.conversationMemory.keyFacts || [])];
    currentFacts.splice(index, 1);

    const updatedMem: EnhancedConversationMemory = {
      ...currentSession.conversationMemory,
      keyFacts: currentFacts,
      lastUpdatedTimestamp: new Date().toLocaleTimeString()
    };

    const updatedSession: InteractionSessionState = {
      ...currentSession,
      conversationMemory: updatedMem
    };
    saveSessionState(updatedSession);
    setCurrentSession(updatedSession);
    setSessions(loadAllSavedSessions());
  };

  const handleAddAgreement = (agreementText: string) => {
    if (!currentSession || !agreementText.trim()) return;
    const currentMem = currentSession.conversationMemory || {
      turnCount: currentSession.dialogueHistory?.length || 0,
      summary: '',
      keyFacts: [],
      agreementsAndPromises: [],
      unresolvedQuestions: [],
      activeTopics: [],
      characterPerspectives: {},
      lastUpdatedTimestamp: new Date().toLocaleTimeString()
    };

    const updatedMem: EnhancedConversationMemory = {
      ...currentMem,
      agreementsAndPromises: [...(currentMem.agreementsAndPromises || []), agreementText.trim()],
      lastUpdatedTimestamp: new Date().toLocaleTimeString()
    };

    const updatedSession: InteractionSessionState = {
      ...currentSession,
      conversationMemory: updatedMem
    };
    saveSessionState(updatedSession);
    setCurrentSession(updatedSession);
    setSessions(loadAllSavedSessions());
    setNewAgreementInput('');
    showFeedback('Pacto o acuerdo inmutable registrado.');
  };

  const handleRemoveAgreement = (index: number) => {
    if (!currentSession || !currentSession.conversationMemory) return;
    const currentAgreements = [...(currentSession.conversationMemory.agreementsAndPromises || [])];
    currentAgreements.splice(index, 1);

    const updatedMem: EnhancedConversationMemory = {
      ...currentSession.conversationMemory,
      agreementsAndPromises: currentAgreements,
      lastUpdatedTimestamp: new Date().toLocaleTimeString()
    };

    const updatedSession: InteractionSessionState = {
      ...currentSession,
      conversationMemory: updatedMem
    };
    saveSessionState(updatedSession);
    setCurrentSession(updatedSession);
    setSessions(loadAllSavedSessions());
  };

  const handleAddQuestion = (questionText: string) => {
    if (!currentSession || !questionText.trim()) return;
    const currentMem = currentSession.conversationMemory || {
      turnCount: currentSession.dialogueHistory?.length || 0,
      summary: '',
      keyFacts: [],
      agreementsAndPromises: [],
      unresolvedQuestions: [],
      activeTopics: [],
      characterPerspectives: {},
      lastUpdatedTimestamp: new Date().toLocaleTimeString()
    };

    const updatedMem: EnhancedConversationMemory = {
      ...currentMem,
      unresolvedQuestions: [...(currentMem.unresolvedQuestions || []), questionText.trim()],
      lastUpdatedTimestamp: new Date().toLocaleTimeString()
    };

    const updatedSession: InteractionSessionState = {
      ...currentSession,
      conversationMemory: updatedMem
    };
    saveSessionState(updatedSession);
    setCurrentSession(updatedSession);
    setSessions(loadAllSavedSessions());
    setNewQuestionInput('');
    showFeedback('Pregunta o misterio abierto registrado.');
  };

  const handleRemoveQuestion = (index: number) => {
    if (!currentSession || !currentSession.conversationMemory) return;
    const currentQuestions = [...(currentSession.conversationMemory.unresolvedQuestions || [])];
    currentQuestions.splice(index, 1);

    const updatedMem: EnhancedConversationMemory = {
      ...currentSession.conversationMemory,
      unresolvedQuestions: currentQuestions,
      lastUpdatedTimestamp: new Date().toLocaleTimeString()
    };

    const updatedSession: InteractionSessionState = {
      ...currentSession,
      conversationMemory: updatedMem
    };
    saveSessionState(updatedSession);
    setCurrentSession(updatedSession);
    setSessions(loadAllSavedSessions());
  };

  // ================================================================
  // PANTALLA 1: HISTORIAL DE SESIONES & CHARLAS
  // ================================================================
  if (phase === 'phase0_sessions') {
    return (
      <div className="max-w-6xl mx-auto px-4 py-8 space-y-8 animate-fadeIn">
        {/* Toast Feedback */}
        {actionFeedbackMessage && (
          <div className="fixed top-20 right-6 z-50 bg-[#171A24] border border-[#C9A050] text-[#E5C378] px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 text-xs font-medium animate-fadeIn">
            <CheckCircle2 className="w-4 h-4 text-[#C9A050]" />
            <span>{actionFeedbackMessage}</span>
          </div>
        )}

        {/* Encabezado Principal de Pantalla 1 */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[#22242D] pb-6">
          <div>
            <div className="flex items-center gap-2 text-[#C9A050] text-xs font-mono uppercase tracking-widest mb-1.5">
              <MessageSquare className="w-4 h-4" />
              <span>Módulo de Interacción · Sala de Conversación</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
              Historial de Sesiones & Charlas
            </h1>
            <p className="text-sm text-[#8A8F9E] mt-1">
              Selecciona una sesión para reanudar el diálogo o inicia una nueva configurando el elenco y el entorno.
            </p>
          </div>

          <button
            id="btn-new-chat-session"
            onClick={handleOpenNewSessionConfig}
            className="bg-[#C9A050] hover:bg-[#b58e45] text-black font-bold px-5 py-2.5 rounded-xl flex items-center gap-2 text-sm shadow-md transition-all cursor-pointer shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Nueva Sesión de Chat</span>
          </button>
        </div>

        {/* Lista de Sesiones Existentes */}
        {sessions.length === 0 ? (
          <div className="bg-[#12141A] border border-[#22242E] rounded-2xl p-12 text-center space-y-4">
            <div className="w-16 h-16 rounded-2xl bg-[#C9A050]/15 border border-[#C9A050]/30 text-[#C9A050] flex items-center justify-center mx-auto">
              <MessageSquare className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold text-white">No hay sesiones activas guardadas</h3>
            <p className="text-sm text-[#8A8F9E] max-w-md mx-auto">
              Comienza tu primera interacción seleccionando el protagonista, los acompañantes y el escenario.
            </p>
            <button
              onClick={handleOpenNewSessionConfig}
              className="bg-[#C9A050] hover:bg-[#b58e45] text-black font-bold px-6 py-3 rounded-xl text-sm inline-flex items-center gap-2 cursor-pointer shadow-lg"
            >
              <Plus className="w-4 h-4" />
              <span>Crear Nueva Sesión de Chat</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sessions.map(s => {
              // Extract companions list
              const companions = s.companionAgents && s.companionAgents.length > 0
                ? s.companionAgents
                : [s.npc, ...(s.secondaryAgents || [])].filter(Boolean);

              const isConfirmingDelete = confirmDeleteId === s.id;
              const isConfirmingRestart = confirmRestartId === s.id;

              return (
                <div
                  key={s.id}
                  className="bg-[#12141A] border border-[#232633] hover:border-[#C9A050]/50 rounded-2xl p-5 flex flex-col justify-between space-y-4 transition-all shadow-md group relative"
                >
                  <div className="space-y-3">
                    {/* Header meta: Lugar y Hora */}
                    <div className="flex items-center justify-between text-xs text-[#8A8F9E]">
                      <span className="flex items-center gap-1.5 text-[#C9A050] font-mono font-medium">
                        <MapPin className="w-3.5 h-3.5 shrink-0" />
                        <span className="truncate max-w-[170px]">{s.place?.name || 'Escenario'}</span>
                      </span>
                      <span className="font-mono text-[11px]">{s.savedAt || 'Guardado'}</span>
                    </div>

                    {/* Título y Subtítulo */}
                    <div>
                      <h3 className="text-base font-bold text-white group-hover:text-[#C9A050] transition-colors line-clamp-1">
                        {s.title}
                      </h3>
                      <p className="text-xs text-[#8A8F9E] mt-1 line-clamp-1">
                        {s.subtitle || `${s.protagonist?.name || 'Protagonista'} y acompañantes`}
                      </p>
                    </div>

                    {/* Ficha Resumen de Elenco y Entorno */}
                    <div className="bg-[#0B0C10] rounded-xl p-3 border border-[#1E202B] space-y-2 text-xs">
                      {/* Protagonista */}
                      <div className="flex items-center justify-between">
                        <span className="text-[#7A7E8D] flex items-center gap-1.5">
                          <User className="w-3 h-3 text-[#C9A050]" />
                          <span>Protagonista:</span>
                        </span>
                        <span className="font-semibold text-white truncate max-w-[130px]">
                          {s.protagonist?.name}
                        </span>
                      </div>

                      {/* Acompañantes Principales */}
                      <div className="flex items-start justify-between">
                        <span className="text-[#7A7E8D] flex items-center gap-1.5 shrink-0 mt-0.5">
                          <Users className="w-3 h-3 text-amber-400" />
                          <span>Acompañantes:</span>
                        </span>
                        <div className="text-right">
                          <span className="font-semibold text-amber-300">
                            {companions.map(c => c.name).join(', ') || 'Ninguno'}
                          </span>
                        </div>
                      </div>

                      {/* Worldbuilding & Mensajes */}
                      <div className="pt-2 border-t border-[#1C1E26] flex items-center justify-between text-[11px] text-[#666666]">
                        <span className="flex items-center gap-1">
                          <Globe className="w-3 h-3 text-[#8A8F9E]" />
                          <span>{s.worldBuilding?.worldName || worldConfig.worldName || 'Elysium'}</span>
                        </span>
                        <span>{s.dialogueHistory?.length || 0} mensajes</span>
                      </div>
                    </div>
                  </div>

                  {/* ZONA DE ACCIONES SOLICITADAS:
                      1. Reanudar / Iniciar
                      2. Reiniciar
                      3. Editar
                      4. Duplicar
                      5. Eliminar
                  */}
                  <div className="pt-3 border-t border-[#1C1E28] space-y-2">
                    {/* Reanudar / Iniciar (Botón Principal Destacado) */}
                    <button
                      id={`btn-resume-${s.id}`}
                      onClick={() => handleResumeSession(s)}
                      className="w-full bg-[#1B1E29] hover:bg-[#C9A050] hover:text-black text-white font-bold py-2 rounded-xl text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-xs"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>Reanudar / Iniciar Chat</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>

                    {/* Barra de 4 botones secundarios: Reiniciar, Editar, Duplicar, Eliminar */}
                    <div className="grid grid-cols-4 gap-1.5">
                      {/* Reiniciar */}
                      <button
                        onClick={() => {
                          if (isConfirmingRestart) {
                            handleExecuteRestartSession(s.id);
                          } else {
                            setConfirmRestartId(s.id);
                            setConfirmDeleteId(null);
                          }
                        }}
                        className={`py-1.5 px-2 rounded-lg text-[11px] font-medium flex items-center justify-center gap-1 transition-all cursor-pointer ${
                          isConfirmingRestart
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50'
                            : 'bg-[#151720] hover:bg-[#1E2230] text-[#9A9EAE] border border-[#232635]'
                        }`}
                        title="Reiniciar diálogo desde cero"
                      >
                        <RotateCcw className="w-3 h-3" />
                        <span className="truncate">{isConfirmingRestart ? '¿Seguro?' : 'Reiniciar'}</span>
                      </button>

                      {/* Editar */}
                      <button
                        onClick={() => handleEditSessionConfig(s)}
                        className="bg-[#151720] hover:bg-[#1E2230] text-[#9A9EAE] hover:text-white border border-[#232635] py-1.5 px-2 rounded-lg text-[11px] font-medium flex items-center justify-center gap-1 transition-all cursor-pointer"
                        title="Editar elenco, acompañantes y escenario"
                      >
                        <Edit3 className="w-3 h-3 text-[#C9A050]" />
                        <span className="truncate">Editar</span>
                      </button>

                      {/* Duplicar */}
                      <button
                        onClick={() => handleDuplicateSession(s.id)}
                        className="bg-[#151720] hover:bg-[#1E2230] text-[#9A9EAE] hover:text-white border border-[#232635] py-1.5 px-2 rounded-lg text-[11px] font-medium flex items-center justify-center gap-1 transition-all cursor-pointer"
                        title="Duplicar sesión"
                      >
                        <Copy className="w-3 h-3 text-blue-400" />
                        <span className="truncate">Duplicar</span>
                      </button>

                      {/* Eliminar */}
                      <button
                        onClick={() => {
                          if (isConfirmingDelete) {
                            handleExecuteDeleteSession(s.id);
                          } else {
                            setConfirmDeleteId(s.id);
                            setConfirmRestartId(null);
                          }
                        }}
                        className={`py-1.5 px-2 rounded-lg text-[11px] font-medium flex items-center justify-center gap-1 transition-all cursor-pointer ${
                          isConfirmingDelete
                            ? 'bg-red-500/25 text-red-300 border border-red-500/60'
                            : 'bg-[#151720] hover:bg-red-950/20 text-[#9A9EAE] hover:text-red-400 border border-[#232635]'
                        }`}
                        title="Eliminar sesión"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span className="truncate">{isConfirmingDelete ? '¿Borrar?' : 'Eliminar'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    );
  }

  // ================================================================
  // PANTALLA 2: CONFIGURACIÓN DE INTERACCIÓN · ELENCO Y ENTORNO
  // ================================================================
  if (phase === 'phase1_config') {
    // Collect all candidates for Protagonist & Companions: saved characters + canonical presets
    const allCandidateCharacters = [
      ...savedCharacters.map(sc => ({
        id: sc.state.id,
        name: sc.state.identity?.fullName || sc.state.name,
        role: sc.state.role || 'Aventurero',
        race: sc.state.raceName || 'Humano',
        personality: sc.state.personality || 'Determinado',
        isPreset: false
      })),
      ...CANONICAL_PRESET_COMPANIONS.map(p => ({
        id: p.id,
        name: p.name,
        role: p.role,
        race: p.race,
        personality: p.personality,
        isPreset: true
      }))
    ];

    // Selected protagonist profile
    const activeProtagonistCard = allCandidateCharacters.find(c => c.id === selectedProtagonistId) || allCandidateCharacters[0];

    // Selected place object
    const chosenPlaceObj = savedPlaces.find(p => p.id === selectedPlaceId) || activePlace || savedPlaces[0];

    const activeLaws = getActiveWorldLaws();

    return (
      <div className="max-w-4xl mx-auto px-4 py-8 space-y-8 animate-fadeIn">
        {/* Encabezado de Pantalla 2 */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[#22242D] pb-6">
          <div>
            <div className="flex items-center gap-2 text-[#C9A050] text-xs font-mono uppercase tracking-widest mb-1.5">
              <Settings className="w-4 h-4" />
              <span>Configuración de Interacción</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
              Elenco y Entorno de Conversación
            </h1>
            <p className="text-xs sm:text-sm text-[#8A8F9E] mt-1">
              Define el Personaje del Usuario (Protagonista), los Acompañantes Principales (agentes complejos), el Escenario y el Worldbuilding.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setPhase('phase0_sessions')}
              className="bg-[#181A22] hover:bg-[#20232E] border border-[#282B38] text-[#8A8F9E] hover:text-white px-3.5 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Historial</span>
            </button>
            <button
              id="btn-launch-chat"
              onClick={handleSaveAndLaunchChat}
              className="bg-[#C9A050] hover:bg-[#b58e45] text-black font-bold px-5 py-2.5 rounded-xl text-xs sm:text-sm flex items-center gap-2 transition-all shadow-lg cursor-pointer"
            >
              <span>{configMode === 'edit' ? 'Guardar y Entrar al Chat' : 'Iniciar Chat'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Campo Título de la Sesión */}
        <div className="bg-[#12141A] border border-[#232633] rounded-2xl p-4 space-y-2">
          <label className="text-xs font-mono uppercase text-[#C9A050] font-bold">
            Título de la Sesión de Conversación:
          </label>
          <input
            type="text"
            value={sessionTitle}
            onChange={e => setSessionTitle(e.target.value)}
            placeholder="Ej: Tertulia en el Gran Salón Arcana..."
            className="w-full bg-[#161822] border border-[#282C3D] focus:border-[#C9A050] text-white rounded-xl px-3.5 py-2.5 text-sm focus:outline-none transition-all"
          />
        </div>

        {/* SECCIÓN 1: PERSONAJE DEL USUARIO (PROTAGONISTA) */}
        <div className="bg-[#12141A] border border-[#232633] rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-white font-bold text-base">
              <User className="w-5 h-5 text-[#C9A050]" />
              <span>1. Personaje del Usuario (Protagonista)</span>
            </div>
            <span className="text-[11px] font-mono text-[#8A8F9E]">
              El personaje que encarnas en el chat
            </span>
          </div>

          <p className="text-xs text-[#8A8F9E]">
            Selecciona cuál de tus personajes creados y guardados en la biblioteca encarnará el usuario en esta tertulia:
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {allCandidateCharacters.map(char => {
              const isSelected = selectedProtagonistId === char.id;
              return (
                <div
                  key={char.id}
                  onClick={() => {
                    setSelectedProtagonistId(char.id);
                    // If selected as protagonist, remove from companions
                    setSelectedCompanionIds(prev => prev.filter(id => id !== char.id));
                  }}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer relative ${
                    isSelected
                      ? 'bg-[#1C1F2C] border-[#C9A050] shadow-md ring-1 ring-[#C9A050]/50'
                      : 'bg-[#141620] border-[#222533] hover:border-[#2F344A]'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="font-bold text-sm text-white">{char.name}</div>
                      <div className="text-xs text-[#C9A050] font-medium">{char.role}</div>
                      <div className="text-[11px] text-[#8A8F9E]">{char.race}</div>
                    </div>
                    {isSelected && (
                      <span className="w-5 h-5 rounded-full bg-[#C9A050] text-black flex items-center justify-center text-xs">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-[#777A8C] italic mt-2 line-clamp-1">
                    "{char.personality}"
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* SECCIÓN 2: ACOMPAÑANTES PRINCIPALES (AGENTES COMPLEJOS EN SALA) */}
        <div className="bg-[#12141A] border border-[#232633] rounded-2xl p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
            <div className="flex items-center gap-2 text-white font-bold text-base">
              <Users className="w-5 h-5 text-amber-400" />
              <span>2. Acompañantes Principales (Agentes Complejos en Sala)</span>
            </div>
            <span className="text-xs font-mono text-amber-300 font-bold bg-amber-500/10 px-2.5 py-1 rounded-full border border-amber-500/20">
              {selectedCompanionIds.length} seleccionados
            </span>
          </div>

          <p className="text-xs text-[#8A8F9E]">
            Combina los personajes secundarios y agentes en sala: selecciona uno o múltiples personajes de tu biblioteca para que dialoguen como interlocutores activos.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {allCandidateCharacters
              .filter(char => char.id !== selectedProtagonistId)
              .map(char => {
                const isSelected = selectedCompanionIds.includes(char.id);
                return (
                  <div
                    key={char.id}
                    onClick={() => toggleCompanionSelection(char.id)}
                    className={`p-3.5 rounded-xl border transition-all cursor-pointer relative ${
                      isSelected
                        ? 'bg-[#18202A] border-amber-400 shadow-md ring-1 ring-amber-400/40'
                        : 'bg-[#141620] border-[#222533] hover:border-[#2F344A]'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="font-bold text-sm text-white">{char.name}</div>
                        <div className="text-xs text-amber-300 font-medium">{char.role}</div>
                        <div className="text-[11px] text-[#8A8F9E]">{char.race}</div>
                      </div>
                      <div
                        className={`w-5 h-5 rounded-lg border flex items-center justify-center text-xs transition-all ${
                          isSelected
                            ? 'bg-amber-400 border-amber-400 text-black'
                            : 'border-[#333748] bg-[#0E1017]'
                        }`}
                      >
                        {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                      </div>
                    </div>
                    <p className="text-[11px] text-[#777A8C] italic mt-2 line-clamp-1">
                      "{char.personality}"
                    </p>
                  </div>
                );
              })}
          </div>
        </div>

        {/* SECCIÓN 3: ESCENARIO ACTUAL */}
        <div className="bg-[#12141A] border border-[#232633] rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-white font-bold text-base">
              <Compass className="w-5 h-5 text-[#C9A050]" />
              <span>3. Escenario Actual</span>
            </div>
            <span className="text-[11px] font-mono text-[#8A8F9E]">
              Entorno físico de la tertulia
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {savedPlaces.map(place => {
              const isSelected = selectedPlaceId === place.id;
              return (
                <div
                  key={place.id}
                  onClick={() => setSelectedPlaceId(place.id)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#1C1F2C] border-[#C9A050] shadow-md ring-1 ring-[#C9A050]/50'
                      : 'bg-[#141620] border-[#222533] hover:border-[#2F344A]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-sm text-white truncate">{place.name}</span>
                    {isSelected && (
                      <span className="w-4 h-4 rounded-full bg-[#C9A050] text-black flex items-center justify-center text-[10px]">
                        <Check className="w-3 h-3 stroke-[3]" />
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-[#8A8F9E] line-clamp-2">
                    {place.atmosphere || place.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* SECCIÓN 4: WORLDBUILDING & REGLAS GLOBALES */}
        <div className="bg-[#12141A] border border-[#232633] rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-white font-bold text-base">
              <Globe className="w-5 h-5 text-blue-400" />
              <span>4. Worldbuilding & Reglas Globales</span>
            </div>
            <span className="text-xs font-mono text-[#C9A050] bg-[#C9A050]/10 border border-[#C9A050]/30 px-2.5 py-0.5 rounded-full">
              Mundo: {worldConfig.worldName || 'Elysium'}
            </span>
          </div>

          <p className="text-xs text-[#8A8F9E]">
            La conversación de los agentes en el chat se supedita estrictamente a las leyes activas y a la cosmología de este mundo:
          </p>

          <div className="bg-[#0B0C10] rounded-xl p-4 border border-[#1E202B] space-y-2.5">
            <div className="text-xs font-mono uppercase text-[#AAAAAA] flex items-center gap-1.5">
              <Scale className="w-3.5 h-3.5 text-[#C9A050]" />
              <span>Leyes Activas que Condicionan a la IA:</span>
            </div>
            <ul className="space-y-1.5 text-xs text-[#D8D8E0]">
              {activeLaws.map((law, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#C9A050] mt-1.5 shrink-0" />
                  <span>{law}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Selector de Tono Narrativo */}
          <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-t border-[#1F212D]">
            <span className="text-xs text-[#AAAAAA] font-mono">Tono general de la interacción:</span>
            <div className="flex flex-wrap gap-2">
              {(['Aventura', 'Casual / Recuentos de la vida', 'Romance', 'Guerra / Política', ...(characterState?.nsfw?.isNsfwEnabled ? ['R+18' as const] : [])]).map(tone => (
                <button
                  key={tone}
                  onClick={() => setSelectedTone(tone)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-all cursor-pointer ${
                    selectedTone === tone
                      ? 'bg-[#C9A050] text-black border-[#C9A050] font-bold'
                      : 'bg-[#141620] text-[#AAAAAA] border-[#222533] hover:text-white'
                  }`}
                >
                  {tone}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Botones de Pie */}
        <div className="flex items-center justify-between pt-4 border-t border-[#22242D]">
          <button
            onClick={() => setPhase('phase0_sessions')}
            className="text-xs text-[#8A8F9E] hover:text-white transition-colors cursor-pointer flex items-center gap-1"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Volver al Historial de Sesiones</span>
          </button>

          <button
            onClick={handleSaveAndLaunchChat}
            className="bg-[#C9A050] hover:bg-[#b58e45] text-black font-bold px-7 py-3 rounded-xl text-sm flex items-center gap-2 transition-all shadow-xl cursor-pointer"
          >
            <span>{configMode === 'edit' ? 'Guardar Cambios y Entrar al Chat' : 'Iniciar Chat'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  // ================================================================
  // PANTALLA 3: SALA DE CHAT MULTI-AGENTE
  // ================================================================
  if (!currentSession) {
    return (
      <div className="max-w-md mx-auto py-20 px-4 text-center space-y-4">
        <MessageSquare className="w-12 h-12 text-[#C9A050] mx-auto opacity-70" />
        <h2 className="text-xl font-bold text-white">No hay sesión activa seleccionada</h2>
        <p className="text-sm text-[#888888]">Regresa al historial de sesiones para abrir o crear una nueva.</p>
        <button
          onClick={() => setPhase('phase0_sessions')}
          className="bg-[#C9A050] hover:bg-[#b58e45] text-black font-bold px-6 py-2.5 rounded-xl text-sm cursor-pointer shadow-md"
        >
          Ver Historial de Sesiones
        </button>
      </div>
    );
  }

  // Companions present in chat
  const presentCompanions: UnifiedParticipant[] = (
    currentSession.companionAgents && currentSession.companionAgents.length > 0
      ? currentSession.companionAgents
      : [currentSession.npc, ...(currentSession.secondaryAgents || [])]
  ).filter(Boolean);

  const activeLaws = currentSession.worldBuilding?.laws || getActiveWorldLaws();

  return (
    <div className="max-w-6xl mx-auto px-3 sm:px-6 py-4 flex flex-col h-[calc(100vh-5.5rem)] min-h-[620px] animate-fadeIn">
      {/* MODAL DE LEYES DEL WORLDBUILDING */}
      {showWorldLawsModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-[#12141A] border border-[#C9A050]/50 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl relative">
            <button
              onClick={() => setShowWorldLawsModal(false)}
              className="absolute top-4 right-4 text-[#888888] hover:text-white p-1 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 text-[#C9A050] font-mono text-xs uppercase">
              <Scale className="w-4 h-4" />
              <span>Arquitectura & Leyes del Mundo</span>
            </div>

            <h3 className="text-lg font-bold text-white">
              Leyes Globales de {currentSession.worldBuilding?.worldName || worldConfig.worldName || 'Elysium'}
            </h3>

            <p className="text-xs text-[#8A8F9E]">
              Estas reglas condicionan las respuestas, acciones y límites ético-físicos de los agentes en este escenario:
            </p>

            <div className="bg-[#0B0C10] rounded-xl p-4 border border-[#1E202B] max-h-60 overflow-y-auto space-y-2.5">
              {activeLaws.map((law, idx) => (
                <div key={idx} className="text-xs text-[#E0E2EC] flex items-start gap-2 border-b border-[#1A1C26] pb-2 last:border-b-0">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#C9A050] mt-1.5 shrink-0" />
                  <span>{law}</span>
                </div>
              ))}
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setShowWorldLawsModal(false)}
                className="bg-[#C9A050] hover:bg-[#b58e45] text-black font-bold px-4 py-2 rounded-xl text-xs cursor-pointer"
              >
                Cerrar Visor
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL DE BIBLIOTECA ONTOLÓGICA Y CONOCIMIENTOS LOCALES */}
      <LocalKnowledgeLibraryModal
        isOpen={showKnowledgeLibraryModal}
        onClose={() => setShowKnowledgeLibraryModal(false)}
        onSelectKnowledgeToPrompt={(entry: KnowledgeEntry) => {
          setInputText(prev => {
            const prefix = prev.trim() ? `${prev}\n` : '';
            return `${prefix}[Considerar principio: ${entry.title} - ${entry.summary}]`;
          });
          setShowKnowledgeLibraryModal(false);
        }}
      />

      {/* MODAL DE MEMORIA COGNITIVA & CONTEXTO DEL ELENCO */}
      {showMemoryModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
          <div className="bg-[#101218] border border-[#C9A050]/60 rounded-2xl max-w-3xl w-full p-5 sm:p-6 space-y-4 shadow-2xl relative max-h-[90vh] flex flex-col">
            <button
              onClick={() => setShowMemoryModal(false)}
              className="absolute top-4 right-4 text-[#888888] hover:text-white p-1 cursor-pointer transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header con botón de consolidación con IA */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#202330] pb-3 pr-8">
              <div>
                <div className="flex items-center gap-2 text-[#C9A050] font-mono text-xs uppercase tracking-wider">
                  <Brain className="w-4 h-4 text-[#C9A050]" />
                  <span>Núcleo de Memoria Cognitiva & Razonamiento Continuo</span>
                </div>
                <h3 className="text-lg font-bold text-white mt-0.5">
                  Centro de Inteligencia & Contexto a Largo Plazo
                </h3>
                <p className="text-[11px] text-[#8A8F9E]">
                  Mantiene coherencia narrativa, teoría de la mente y recuerdos inquebrantables a través de conversaciones extensas.
                </p>
              </div>

              {/* Botón de análisis profundo con IA */}
              <button
                onClick={handleConsolidateMemory}
                disabled={isAnalyzingMemory}
                className="bg-gradient-to-r from-[#C9A050] to-[#E5C378] hover:from-[#b58e45] hover:to-[#C9A050] text-black font-bold text-xs px-3.5 py-2 rounded-xl flex items-center gap-2 shadow-md cursor-pointer disabled:opacity-50 shrink-0 transition-all"
                title="Sintetizar la conversación completa, extraer compromisos, verdades inmutables y estados psicológicos"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isAnalyzingMemory ? 'animate-spin' : ''}`} />
                <span>{isAnalyzingMemory ? 'Analizando Memoria...' : 'Analizar & Consolidar con IA'}</span>
              </button>
            </div>

            {/* Selector de pestañas */}
            <div className="flex items-center gap-1 overflow-x-auto no-scrollbar border-b border-[#1E212D] pb-2 text-xs">
              <button
                onClick={() => setActiveMemoryTab('summary')}
                className={`px-3 py-1.5 rounded-lg font-medium transition-all cursor-pointer shrink-0 flex items-center gap-1.5 ${
                  activeMemoryTab === 'summary'
                    ? 'bg-[#1F2332] text-amber-300 border border-amber-500/40'
                    : 'text-[#888888] hover:text-white'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>Arco Narrativo</span>
              </button>

              <button
                onClick={() => setActiveMemoryTab('facts')}
                className={`px-3 py-1.5 rounded-lg font-medium transition-all cursor-pointer shrink-0 flex items-center gap-1.5 ${
                  activeMemoryTab === 'facts'
                    ? 'bg-[#1F2332] text-amber-300 border border-amber-500/40'
                    : 'text-[#888888] hover:text-white'
                }`}
              >
                <Bookmark className="w-3.5 h-3.5" />
                <span>Hechos Canónicos ({currentSession.conversationMemory?.keyFacts?.length || 0})</span>
              </button>

              <button
                onClick={() => setActiveMemoryTab('agreements')}
                className={`px-3 py-1.5 rounded-lg font-medium transition-all cursor-pointer shrink-0 flex items-center gap-1.5 ${
                  activeMemoryTab === 'agreements'
                    ? 'bg-[#1F2332] text-amber-300 border border-amber-500/40'
                    : 'text-[#888888] hover:text-white'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Pactos & Promesas ({currentSession.conversationMemory?.agreementsAndPromises?.length || 0})</span>
              </button>

              <button
                onClick={() => setActiveMemoryTab('questions')}
                className={`px-3 py-1.5 rounded-lg font-medium transition-all cursor-pointer shrink-0 flex items-center gap-1.5 ${
                  activeMemoryTab === 'questions'
                    ? 'bg-[#1F2332] text-amber-300 border border-amber-500/40'
                    : 'text-[#888888] hover:text-white'
                }`}
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>Preguntas Abiertas ({currentSession.conversationMemory?.unresolvedQuestions?.length || 0})</span>
              </button>

              <button
                onClick={() => setActiveMemoryTab('theory_of_mind')}
                className={`px-3 py-1.5 rounded-lg font-medium transition-all cursor-pointer shrink-0 flex items-center gap-1.5 ${
                  activeMemoryTab === 'theory_of_mind'
                    ? 'bg-[#1F2332] text-amber-300 border border-amber-500/40'
                    : 'text-[#888888] hover:text-white'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                <span>Teoría de la Mente & Elenco</span>
              </button>
            </div>

            {/* Contenido de la pestaña activa */}
            <div className="flex-1 overflow-y-auto space-y-4 pr-1 text-xs">
              {/* TAB 1: RESUMEN DEL ARCO */}
              {activeMemoryTab === 'summary' && (
                <div className="space-y-3">
                  <div className="bg-[#0B0D12] rounded-xl p-4 border border-[#1E212E] space-y-2">
                    <div className="flex items-center justify-between text-[#C9A050] font-mono text-[11px] font-bold">
                      <span>Resumen Cronológico de la Trama</span>
                      <span className="text-[#6D7282] font-normal">
                        Turnos: {currentSession.dialogueHistory?.length || 0}
                      </span>
                    </div>
                    <p className="text-white text-xs sm:text-[13px] leading-relaxed whitespace-pre-line bg-[#141722] p-3 rounded-lg border border-[#232738]">
                      {currentSession.conversationMemory?.summary ||
                        'La conversación aún no ha sido sintetizada. Pulsa "Analizar & Consolidar con IA" o continúa dialogando; el motor irá capturando el hilo de los sucesos automáticamente.'}
                    </p>
                    {currentSession.conversationMemory?.narrativeTone && (
                      <div className="flex items-center gap-2 pt-1 text-[11px] text-[#A6ABB9]">
                        <span className="text-[#6D7282]">Tono narrativo predominante:</span>
                        <span className="font-semibold text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                          {currentSession.conversationMemory.narrativeTone}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Temas Activos */}
                  <div className="bg-[#0B0D12] rounded-xl p-3.5 border border-[#1E212E] space-y-2">
                    <span className="text-[#C9A050] font-mono text-[11px] font-bold uppercase">
                      Temas Activos en la Conversación
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {currentSession.conversationMemory?.activeTopics && currentSession.conversationMemory.activeTopics.length > 0 ? (
                        currentSession.conversationMemory.activeTopics.map((topic, i) => (
                          <span
                            key={i}
                            className="bg-[#161924] text-amber-200 border border-amber-500/20 px-2.5 py-1 rounded-lg text-xs"
                          >
                            #{topic}
                          </span>
                        ))
                      ) : (
                        <span className="text-[#666666] italic text-xs">
                          Observación del entorno, diálogo introductorio y exploración.
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: HECHOS CANÓNICOS */}
              {activeMemoryTab === 'facts' && (
                <div className="space-y-3">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={newFactInput}
                      onChange={(e) => setNewFactInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') handleAddFact(newFactInput);
                      }}
                      placeholder="Registrar nuevo hecho indiscutible (ej: «Se encontró la llave arcana en el cofre»)..."
                      className="flex-1 bg-[#131620] border border-[#232738] rounded-xl px-3 py-2 text-xs text-white placeholder-[#555555] focus:outline-none focus:border-[#C9A050]"
                    />
                    <button
                      onClick={() => handleAddFact(newFactInput)}
                      disabled={!newFactInput.trim()}
                      className="bg-[#C9A050] hover:bg-[#b58e45] text-black font-bold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer disabled:opacity-40 shrink-0"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Añadir</span>
                    </button>
                  </div>

                  <div className="space-y-2">
                    {currentSession.conversationMemory?.keyFacts && currentSession.conversationMemory.keyFacts.length > 0 ? (
                      currentSession.conversationMemory.keyFacts.map((fact, idx) => (
                        <div
                          key={idx}
                          className="bg-[#0B0D12] border border-[#1E212E] hover:border-amber-500/30 rounded-xl p-3 flex items-start justify-between gap-3 group transition-all"
                        >
                          <div className="flex items-start gap-2.5 text-white text-xs">
                            <span className="w-2 h-2 rounded-full bg-amber-400 mt-1.5 shrink-0" />
                            <span className="leading-relaxed">{fact}</span>
                          </div>
                          <button
                            onClick={() => handleRemoveFact(idx)}
                            className="text-[#555555] hover:text-rose-400 p-1 cursor-pointer transition-colors opacity-0 group-hover:opacity-100"
                            title="Eliminar hecho de la memoria"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-6 text-[#666666] bg-[#0B0D12] rounded-xl border border-[#1E212E] space-y-1">
                        <Bookmark className="w-6 h-6 mx-auto text-[#444444]" />
                        <p>No hay hechos canónicos registrados aún.</p>
                        <p className="text-[10px]">Añade hechos clave arriba o pulsa "Analizar & Consolidar con IA".</p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB 3: PACTOS & PROMESAS */}
              {activeMemoryTab === 'agreements' && (
                <div className="space-y-3">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={newAgreementInput}
                      onChange={(e) => setNewAgreementInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') handleAddAgreement(newAgreementInput);
                      }}
                      placeholder="Registrar pacto, acuerdo o promesa (ej: «Prometieron proteger el relicario juntos»)..."
                      className="flex-1 bg-[#131620] border border-[#232738] rounded-xl px-3 py-2 text-xs text-white placeholder-[#555555] focus:outline-none focus:border-[#C9A050]"
                    />
                    <button
                      onClick={() => handleAddAgreement(newAgreementInput)}
                      disabled={!newAgreementInput.trim()}
                      className="bg-[#C9A050] hover:bg-[#b58e45] text-black font-bold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer disabled:opacity-40 shrink-0"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Registrar</span>
                    </button>
                  </div>

                  <div className="space-y-2">
                    {currentSession.conversationMemory?.agreementsAndPromises && currentSession.conversationMemory.agreementsAndPromises.length > 0 ? (
                      currentSession.conversationMemory.agreementsAndPromises.map((agr, idx) => (
                        <div
                          key={idx}
                          className="bg-[#0B0D12] border border-[#1E212E] hover:border-emerald-500/30 rounded-xl p-3 flex items-start justify-between gap-3 group transition-all"
                        >
                          <div className="flex items-start gap-2.5 text-white text-xs">
                            <ShieldCheck className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                            <span className="leading-relaxed">{agr}</span>
                          </div>
                          <button
                            onClick={() => handleRemoveAgreement(idx)}
                            className="text-[#555555] hover:text-rose-400 p-1 cursor-pointer transition-colors opacity-0 group-hover:opacity-100"
                            title="Eliminar acuerdo"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-6 text-[#666666] bg-[#0B0D12] rounded-xl border border-[#1E212E] space-y-1">
                        <ShieldCheck className="w-6 h-6 mx-auto text-[#444444]" />
                        <p>No hay pactos ni promesas registrados todavía.</p>
                        <p className="text-[10px]">Los juramentos acordados en el diálogo se preservarán aquí sin caducar.</p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB 4: PREGUNTAS ABIERTAS */}
              {activeMemoryTab === 'questions' && (
                <div className="space-y-3">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={newQuestionInput}
                      onChange={(e) => setNewQuestionInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') handleAddQuestion(newQuestionInput);
                      }}
                      placeholder="Registrar enigma o pregunta abierta (ej: «¿Quién activó la alarma del templo?»)..."
                      className="flex-1 bg-[#131620] border border-[#232738] rounded-xl px-3 py-2 text-xs text-white placeholder-[#555555] focus:outline-none focus:border-[#C9A050]"
                    />
                    <button
                      onClick={() => handleAddQuestion(newQuestionInput)}
                      disabled={!newQuestionInput.trim()}
                      className="bg-[#C9A050] hover:bg-[#b58e45] text-black font-bold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer disabled:opacity-40 shrink-0"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Registrar</span>
                    </button>
                  </div>

                  <div className="space-y-2">
                    {currentSession.conversationMemory?.unresolvedQuestions && currentSession.conversationMemory.unresolvedQuestions.length > 0 ? (
                      currentSession.conversationMemory.unresolvedQuestions.map((q, idx) => (
                        <div
                          key={idx}
                          className="bg-[#0B0D12] border border-[#1E212E] hover:border-blue-500/30 rounded-xl p-3 flex items-start justify-between gap-3 group transition-all"
                        >
                          <div className="flex items-start gap-2.5 text-white text-xs">
                            <HelpCircle className="w-4 h-4 text-blue-400 mt-0.5 shrink-0" />
                            <span className="leading-relaxed">{q}</span>
                          </div>
                          <button
                            onClick={() => handleRemoveQuestion(idx)}
                            className="text-[#555555] hover:text-rose-400 p-1 cursor-pointer transition-colors opacity-0 group-hover:opacity-100"
                            title="Marcar como resuelta / eliminar"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-6 text-[#666666] bg-[#0B0D12] rounded-xl border border-[#1E212E] space-y-1">
                        <HelpCircle className="w-6 h-6 mx-auto text-[#444444]" />
                        <p>No hay preguntas abiertas registradas.</p>
                        <p className="text-[10px]">Cualquier misterio o duda abierta durante la trama se listará aquí.</p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB 5: TEORÍA DE LA MENTE & ELENCO */}
              {activeMemoryTab === 'theory_of_mind' && (
                <div className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {presentCompanions.map(companion => {
                      const mem = currentSession.companionMemories?.[companion.id];
                      const perspective = currentSession.conversationMemory?.characterPerspectives?.[companion.name] ||
                        currentSession.conversationMemory?.characterPerspectives?.[companion.id];

                      const affinity = perspective?.perceivedAffinity ?? mem?.affinityWithUser ?? 50;
                      const trust = perspective?.trustLevel ?? mem?.trustLevel ?? 50;
                      const observation = perspective?.internalObservation || mem?.innerGoal || 'Observando el comportamiento y las palabras del interlocutor con serenidad.';

                      return (
                        <div key={companion.id} className="bg-[#0B0D12] border border-[#1E212E] rounded-xl p-3.5 space-y-2.5">
                          <div className="flex items-center justify-between">
                            <div className="font-bold text-white text-xs">{companion.name}</div>
                            <span className="text-[10px] font-mono text-amber-300 bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20">
                              {companion.role}
                            </span>
                          </div>

                          {/* Barras de métrica */}
                          <div className="space-y-1.5 text-[10px]">
                            <div className="flex items-center justify-between text-[#8A8F9E]">
                              <span>Afinidad percibida:</span>
                              <span className="font-mono text-amber-300">{affinity}%</span>
                            </div>
                            <div className="w-full bg-[#161822] h-1.5 rounded-full overflow-hidden">
                              <div
                                className="bg-gradient-to-r from-amber-600 to-amber-400 h-full rounded-full transition-all duration-300"
                                style={{ width: `${affinity}%` }}
                              />
                            </div>

                            <div className="flex items-center justify-between text-[#8A8F9E] pt-0.5">
                              <span>Confianza táctica:</span>
                              <span className="font-mono text-blue-300">{trust}%</span>
                            </div>
                            <div className="w-full bg-[#161822] h-1.5 rounded-full overflow-hidden">
                              <div
                                className="bg-gradient-to-r from-blue-600 to-blue-400 h-full rounded-full transition-all duration-300"
                                style={{ width: `${trust}%` }}
                              />
                            </div>
                          </div>

                          {/* Observación psicológica interna */}
                          <div className="bg-[#12141C] p-2.5 rounded-lg border border-[#1E202C] text-[11px] text-[#C2C6D4] italic leading-relaxed">
                            "{observation}"
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Footer de cierre y estado */}
            <div className="flex flex-col sm:flex-row justify-between items-center gap-2 pt-3 border-t border-[#1F222E] text-[11px] text-[#777777]">
              <div className="flex items-center gap-2">
                <Database className="w-3.5 h-3.5 text-emerald-400" />
                <span>Sincronizado en tiempo real con <span className="font-mono text-[#AAAAAA]">localStorage</span></span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleDownloadTranscript}
                  className="bg-[#181B24] hover:bg-[#222532] text-[#B5B9C9] hover:text-white px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 border border-[#2A2E3E] cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Descargar Transcripción</span>
                </button>

                <button
                  onClick={() => setShowMemoryModal(false)}
                  className="bg-[#C9A050] hover:bg-[#b58e45] text-black font-bold px-4 py-1.5 rounded-xl text-xs cursor-pointer"
                >
                  Cerrar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL DE EXPORTACIÓN DE TRANSCRIPCIÓN */}
      {showExportModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-[#12141A] border border-[#C9A050]/50 rounded-2xl max-w-2xl w-full p-5 sm:p-6 space-y-4 shadow-2xl relative max-h-[85vh] flex flex-col">
            <button
              onClick={() => setShowExportModal(false)}
              className="absolute top-4 right-4 text-[#888888] hover:text-white p-1 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 text-[#C9A050] font-mono text-xs uppercase">
              <FileText className="w-4 h-4" />
              <span>Transcripción de Sesión</span>
            </div>

            <div>
              <h3 className="text-lg font-bold text-white">
                Registro del Diálogo Persistido
              </h3>
              <p className="text-xs text-[#8A8F9E]">
                {currentSession.dialogueHistory?.length || 0} mensajes registrados en el escenario «{currentSession.place?.name}».
              </p>
            </div>

            <textarea
              readOnly
              value={exportSessionTranscriptAsText(currentSession)}
              className="w-full flex-1 min-h-[260px] bg-[#0A0B0E] border border-[#222533] rounded-xl p-3 font-mono text-xs text-[#C8CCD9] leading-relaxed resize-none focus:outline-none"
            />

            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-[#1F222E]">
              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopyTranscript}
                  className="bg-[#C9A050] hover:bg-[#b58e45] text-black font-bold px-3.5 py-1.5 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copiedTranscript ? '¡Copiado!' : 'Copiar Texto'}</span>
                </button>

                <button
                  onClick={handleDownloadTranscript}
                  className="bg-[#181B24] hover:bg-[#222532] text-[#B5B9C9] hover:text-white px-3.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 border border-[#2A2E3E] cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Descargar (.txt)</span>
                </button>
              </div>

              <button
                onClick={() => setShowExportModal(false)}
                className="bg-[#161822] hover:bg-[#20232E] text-white px-4 py-1.5 rounded-xl text-xs cursor-pointer border border-[#2A2E3E]"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: TERMINAL LÓGICO DEL AGENTE AUTÓNOMO OFFLINE */}
      {activeTerminalCompanionId && (() => {
        const agent = presentCompanions.find(c => c.id === activeTerminalCompanionId);
        if (!agent) return null;
        const mem = getOrInitCompanionMemory(agent, presentCompanions);
        const otherAgents = presentCompanions.filter(c => c.id !== agent.id);

        return (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
            <div className="bg-[#101218] border border-[#C9A050]/60 rounded-2xl max-w-2xl w-full p-5 sm:p-6 space-y-4 shadow-2xl relative max-h-[88vh] flex flex-col">
              <button
                onClick={() => setActiveTerminalCompanionId(null)}
                className="absolute top-4 right-4 text-[#888888] hover:text-white p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Header del Terminal */}
              <div className="flex items-center justify-between gap-3 pr-8">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 font-bold text-base flex items-center justify-center">
                    {agent.name.charAt(0)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-bold text-white">{agent.name}</h3>
                      <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full text-[10px] font-mono">
                        Agente Autónomo
                      </span>
                    </div>
                    <p className="text-xs text-[#8A8F9E]">
                      {agent.role} · {agent.race || 'Humano'} · {agent.moralAlignment || 'Neutral'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 bg-[#171922] px-2.5 py-1 rounded-xl border border-[#262938] text-xs font-mono text-amber-300">
                  <Activity className="w-3.5 h-3.5 text-amber-400" />
                  <span>Humor: {mem.currentMood}</span>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto space-y-4 pr-1 text-xs">
                {/* 1. Métricas Vinculares & Estado Psicológico */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* Afinidad con Protagonista */}
                  <div className="bg-[#0C0E13] border border-[#1E212E] rounded-xl p-3 space-y-1.5">
                    <div className="flex items-center justify-between text-white font-semibold">
                      <div className="flex items-center gap-1.5 text-amber-400">
                        <Heart className="w-3.5 h-3.5" />
                        <span>Afinidad con Protagonista</span>
                      </div>
                      <span className="font-mono text-amber-300">{mem.affinityWithUser}%</span>
                    </div>
                    <div className="w-full bg-[#1A1D27] h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-gradient-to-r from-amber-600 to-amber-400 h-full rounded-full transition-all duration-300"
                        style={{ width: `${mem.affinityWithUser}%` }}
                      />
                    </div>
                    <p className="text-[10px] text-[#7A7E8D]">
                      Nivel de empatía y compenetración con {currentSession.protagonist?.name || 'el protagonista'}.
                    </p>
                  </div>

                  {/* Confianza Táctica */}
                  <div className="bg-[#0C0E13] border border-[#1E212E] rounded-xl p-3 space-y-1.5">
                    <div className="flex items-center justify-between text-white font-semibold">
                      <div className="flex items-center gap-1.5 text-blue-400">
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>Confianza Táctica</span>
                      </div>
                      <span className="font-mono text-blue-300">{mem.trustLevel}%</span>
                    </div>
                    <div className="w-full bg-[#1A1D27] h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-gradient-to-r from-blue-600 to-blue-400 h-full rounded-full transition-all duration-300"
                        style={{ width: `${mem.trustLevel}%` }}
                      />
                    </div>
                    <p className="text-[10px] text-[#7A7E8D]">
                      Seguridad en las directivas y estabilidad del grupo.
                    </p>
                  </div>
                </div>

                {/* 2. Objetivo Interno Actual */}
                <div className="bg-[#0C0E13] border border-[#1E212E] rounded-xl p-3 space-y-2">
                  <div className="flex items-center justify-between text-[#C9A050] font-mono text-[11px] uppercase tracking-wider font-bold">
                    <span>Objetivo Interno en la Escena</span>
                    <span className="text-[10px] font-normal text-[#8A8F9E]">Propósito Cognitivo</span>
                  </div>
                  <p className="text-white bg-[#141722] p-2.5 rounded-lg border border-[#232738] font-medium leading-relaxed">
                    {mem.innerGoal}
                  </p>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Asignar nuevo objetivo interno..."
                      value={customGoalInput}
                      onChange={(e) => setCustomGoalInput(e.target.value)}
                      className="flex-1 bg-[#141722] border border-[#232738] rounded-lg px-2.5 py-1 text-xs text-white placeholder-[#555555] focus:outline-none focus:border-[#C9A050]"
                    />
                    <button
                      onClick={() => {
                        handleUpdateCompanionGoal(agent.id, customGoalInput);
                        setCustomGoalInput('');
                      }}
                      className="bg-[#C9A050] hover:bg-[#b58e45] text-black font-bold px-3 py-1 rounded-lg text-xs cursor-pointer shrink-0"
                    >
                      Asignar
                    </button>
                  </div>
                </div>

                {/* 3. Pensamientos Privados / Monólogo Interno (Terminal Lógico) */}
                <div className="bg-[#090B0F] border border-[#1E212E] rounded-xl p-3 space-y-2">
                  <div className="flex items-center justify-between text-amber-300 font-mono text-[11px] uppercase tracking-wider font-bold">
                    <div className="flex items-center gap-1.5">
                      <Terminal className="w-3.5 h-3.5 text-amber-400" />
                      <span>Monólogo Interno & Pensamientos Privados</span>
                    </div>
                    <span className="text-[10px] text-[#6A6E7D]">({mem.innerMonologueLog?.length || 0} registros)</span>
                  </div>
                  <div className="space-y-2 max-h-36 overflow-y-auto font-mono text-[11px] text-[#A2A7B8] pr-1">
                    {mem.innerMonologueLog && mem.innerMonologueLog.length > 0 ? (
                      mem.innerMonologueLog.slice().reverse().map((thought, idx) => (
                        <div key={idx} className="bg-[#12141D] p-2 rounded-lg border border-[#202330] space-y-1">
                          <div className="flex items-center justify-between text-[10px] text-[#6C7182]">
                            <span>{thought.trigger || 'Reflexión espontánea'}</span>
                            <span>{thought.timestamp}</span>
                          </div>
                          <p className="text-[#D3D7E5] italic">
                            "{thought.thought}"
                          </p>
                        </div>
                      ))
                    ) : (
                      <p className="text-[11px] text-[#666666] italic py-1">
                        El agente está observando el entorno en silencio sin reflexiones registradas.
                      </p>
                    )}
                  </div>
                </div>

                {/* 4. Memoria Episódica Reciente */}
                <div className="bg-[#0C0E13] border border-[#1E212E] rounded-xl p-3 space-y-2">
                  <div className="flex items-center justify-between text-[#C9A050] font-mono text-[11px] uppercase tracking-wider font-bold">
                    <div className="flex items-center gap-1.5">
                      <Brain className="w-3.5 h-3.5 text-[#C9A050]" />
                      <span>Memoria Episódica Registrada</span>
                    </div>
                    <span className="text-[10px] text-[#6A6E7D]">({mem.episodicEvents?.length || 0} eventos)</span>
                  </div>
                  {mem.episodicEvents && mem.episodicEvents.length > 0 ? (
                    <div className="space-y-1.5 max-h-32 overflow-y-auto pr-1">
                      {mem.episodicEvents.slice().reverse().map((ev, idx) => (
                        <div key={idx} className="flex items-center justify-between bg-[#12141D] p-2 rounded-lg border border-[#1F222F] text-[11px]">
                          <div className="min-w-0 flex-1 pr-2">
                            <span className="font-bold text-amber-300">{ev.speakerName}: </span>
                            <span className="text-[#B2B6C6] truncate">"{ev.summary}"</span>
                          </div>
                          <div className="flex items-center gap-2 shrink-0">
                            <span className="font-mono text-[10px] text-[#6E7385] bg-[#181B26] px-1.5 py-0.5 rounded">
                              {ev.reactionType}
                            </span>
                            <span className="text-[10px] text-[#555555]">{ev.timestamp}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-[11px] text-[#666666] italic">
                      No hay eventos episódicos registrados aún. Se añadirán conforme el diálogo avance.
                    </p>
                  )}
                </div>

                {/* 5. Relaciones Percibidas con otros Acompañantes en Sala */}
                {otherAgents.length > 0 && (
                  <div className="bg-[#0C0E13] border border-[#1E212E] rounded-xl p-3 space-y-2">
                    <div className="flex items-center justify-between text-blue-300 font-mono text-[11px] uppercase tracking-wider font-bold">
                      <div className="flex items-center gap-1.5">
                        <Users className="w-3.5 h-3.5 text-blue-400" />
                        <span>Percepción de Otros Acompañantes</span>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {otherAgents.map(other => {
                        const rel = mem.perceivedRelationships?.[other.id] || { affinity: 50, trust: 50, opinion: 'Compañero en la expedición.' };
                        return (
                          <div key={other.id} className="bg-[#12141D] border border-[#1F222F] rounded-lg p-2 space-y-1">
                            <div className="flex items-center justify-between font-bold text-white text-[11px]">
                              <span>{other.name}</span>
                              <span className="text-[10px] font-mono text-amber-300">Afinidad: {rel.affinity}%</span>
                            </div>
                            <p className="text-[10px] text-[#8A8F9E] italic">
                              "{rel.opinion}"
                            </p>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>

              {/* Acciones Rápidas del Terminal */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-[#1E212E]">
                <div className="flex items-center flex-wrap gap-2">
                  <button
                    onClick={() => {
                      handleForceAgentReaction(agent.id);
                    }}
                    className="bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs"
                    title="Forzar una intervención o reacción de este agente en el chat inmediatamente"
                  >
                    <Zap className="w-3.5 h-3.5 text-amber-400" />
                    <span>Forzar Reacción en Sala</span>
                  </button>

                  {otherAgents.length > 0 && (
                    <div className="flex items-center gap-1.5">
                      <select
                        value={selectedBanterPartnerId || otherAgents[0]?.id || ''}
                        onChange={(e) => setSelectedBanterPartnerId(e.target.value)}
                        className="bg-[#141722] border border-[#242838] text-white text-xs rounded-xl px-2 py-1.5 focus:outline-none"
                      >
                        {otherAgents.map(o => (
                          <option key={o.id} value={o.id}>Con {o.name}</option>
                        ))}
                      </select>
                      <button
                        onClick={() => {
                          const partnerId = selectedBanterPartnerId || otherAgents[0]?.id;
                          if (partnerId) {
                            handleTriggerBanterBetweenAgents(agent.id, partnerId);
                          }
                        }}
                        className="bg-[#181B26] hover:bg-[#222536] text-[#B5B9C9] hover:text-white border border-[#2B2F42] px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                        title="Generar intercambio de opiniones entre este agente y el compañero seleccionado"
                      >
                        <MessageCircle className="w-3.5 h-3.5 text-blue-400" />
                        <span>Diálogo Cruzado</span>
                      </button>
                    </div>
                  )}
                </div>

                <button
                  onClick={() => setActiveTerminalCompanionId(null)}
                  className="bg-[#C9A050] hover:bg-[#b58e45] text-black font-bold px-4 py-1.5 rounded-xl text-xs cursor-pointer"
                >
                  Cerrar Terminal
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* HEADER DE SALA DE CHAT (PANTALLA 3) */}
      <div className="bg-[#12141A] border border-[#232633] rounded-2xl p-3 sm:p-3.5 mb-3 flex flex-wrap items-center justify-between gap-3 shadow-md shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#C9A050]/20 border border-[#C9A050]/40 flex items-center justify-center text-[#C9A050] shadow-xs">
            <MessageSquare className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm sm:text-base font-bold text-white tracking-wide">
                {currentSession.place?.name || 'Escenario'}
              </h2>
              <button
                onClick={() => setShowWorldLawsModal(true)}
                className="bg-[#1A1D27] hover:bg-[#252938] text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-full text-[10px] font-mono flex items-center gap-1 transition-all cursor-pointer"
                title="Ver arquitectura y reglas del Worldbuilding"
              >
                <Globe className="w-3 h-3" />
                <span>{currentSession.worldBuilding?.worldName || worldConfig.worldName || 'Elysium'} ({activeLaws.length} leyes)</span>
              </button>
            </div>
            <div className="flex items-center gap-2 text-[11px] text-[#8A8F9E] mt-0.5">
              <span>{currentSession.place?.weather || 'Clima templado'}</span>
              <span>·</span>
              <span>{currentSession.place?.hour || 'Tarde'}</span>
              <span>·</span>
              {/* Badge de persistencia localStorage */}
              <div className="inline-flex items-center gap-1 text-emerald-400 font-mono text-[10px]">
                <Database className="w-3 h-3" />
                <span>Guardado ({currentSession.dialogueHistory?.length || 0})</span>
              </div>
            </div>
          </div>
        </div>

        {/* Acciones Rápidas del Header */}
        <div className="flex items-center flex-wrap gap-2">
          {/* Alternar Modo Offline Autónomo / Online */}
          <button
            onClick={handleToggleOfflineMode}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer border ${
              isOfflineMode
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-xs'
                : 'bg-[#181A22] hover:bg-[#20232E] border-[#282B38] text-[#8A8F9E] hover:text-white'
            }`}
            title="Alternar entre Motor de Agentes 100% Offline (Terminal Lógico local) y Conexión Online con respaldo"
          >
            {isOfflineMode ? (
              <>
                <Zap className="w-3.5 h-3.5 text-emerald-400" />
                <span className="font-mono">⚡ Modo Offline</span>
              </>
            ) : (
              <>
                <Wifi className="w-3.5 h-3.5 text-blue-400" />
                <span className="font-mono">🌐 Online</span>
              </>
            )}
          </button>

          {/* Memoria del Elenco */}
          <button
            onClick={() => setShowMemoryModal(true)}
            className="bg-[#181A22] hover:bg-[#20232E] border border-amber-500/30 text-amber-300 hover:text-amber-200 px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
            title="Ver memoria cognitiva, identidades y detalles que los agentes retienen"
          >
            <Brain className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Memoria del Elenco</span>
          </button>

          {/* Biblioteca Ontológica Local (0ms latencia) */}
          <button
            id="open-knowledge-library-btn"
            onClick={() => setShowKnowledgeLibraryModal(true)}
            className="bg-[#181A22] hover:bg-[#20232E] border border-cyan-500/30 text-cyan-300 hover:text-cyan-200 px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
            title="Biblioteca Ontológica & Leyes Locales (Física lag/ripple, telas, arquitectura, anatomía)"
          >
            <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">Ontología & Leyes</span>
          </button>

          {/* Exportar Diálogo */}
          <button
            onClick={() => setShowExportModal(true)}
            className="bg-[#181A22] hover:bg-[#20232E] border border-[#282B38] text-[#AAAAAA] hover:text-white px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
            title="Exportar transcripción del diálogo"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden lg:inline">Exportar</span>
          </button>

          {/* Atmósfera Ambiental */}
          <button
            onClick={handleTriggerAmbientEvent}
            disabled={isGenerating}
            className="bg-[#1A1D28] hover:bg-[#242838] border border-[#30354A] text-amber-300 px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs disabled:opacity-50"
            title="Generar suceso sensorial o ambiental del escenario y worldbuilding"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Atmósfera</span>
          </button>

          {/* Reiniciar Diálogo */}
          <button
            onClick={() => {
              if (confirmRestartId === currentSession.id) {
                handleExecuteRestartSession(currentSession.id);
              } else {
                setConfirmRestartId(currentSession.id);
                setTimeout(() => setConfirmRestartId(null), 4000);
              }
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer border ${
              confirmRestartId === currentSession.id
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 animate-pulse'
                : 'bg-[#181A22] hover:bg-[#20232E] border-[#282B38] text-[#AAAAAA] hover:text-white'
            }`}
            title="Reiniciar diálogo de esta sala y sincronizar en localStorage"
          >
            <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
            <span>{confirmRestartId === currentSession.id ? '¿Confirmar?' : 'Reiniciar'}</span>
          </button>

          {/* Configurar Elenco y Entorno (Regresa a Pantalla 2) */}
          <button
            onClick={() => handleEditSessionConfig(currentSession)}
            className="bg-[#181A22] hover:bg-[#20232E] border border-[#282B38] text-[#AAAAAA] hover:text-white px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
            title="Ajustar acompañantes, protagonista y escenario"
          >
            <Settings className="w-3.5 h-3.5 text-[#C9A050]" />
            <span className="hidden sm:inline">Elenco</span>
          </button>

          {/* Volver a Historial de Sesiones (Regresa a Pantalla 1) */}
          <button
            onClick={() => setPhase('phase0_sessions')}
            className="bg-[#181A22] hover:bg-[#20232E] border border-[#282B38] text-[#AAAAAA] hover:text-white px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
            title="Volver al Historial de Sesiones"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Sesiones</span>
          </button>
        </div>
      </div>

      {/* ÁREA PRINCIPAL: PANEL DE PARTICIPANTES + STREAM DE CHAT */}
      <div className="flex-1 min-h-0 flex flex-col md:flex-row gap-3">
        {/* Panel Lateral: Elenco Presente en Sala */}
        <div className="hidden md:flex flex-col w-64 bg-[#101218] border border-[#20222D] rounded-2xl p-3.5 space-y-3 shrink-0 overflow-y-auto">
          <div className="text-[11px] font-mono uppercase tracking-wider text-[#C9A050] font-bold flex items-center justify-between">
            <span>Elenco en Sala</span>
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          </div>

          {/* Protagonista Card */}
          <div className="bg-[#161822] border border-[#2A2E3E] rounded-xl p-2.5 space-y-1">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-300 font-bold text-xs flex items-center justify-center border border-amber-500/40">
                {currentSession.protagonist?.name?.charAt(0) || 'U'}
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-xs font-bold text-white truncate">{currentSession.protagonist?.name}</div>
                <div className="text-[10px] text-amber-300/80 truncate">Tú · {currentSession.protagonist?.role}</div>
              </div>
            </div>
          </div>

          {/* Acompañantes Principales (Agentes Complejos) */}
          <div className="space-y-2">
            <span className="text-[10px] font-mono text-[#666666] uppercase">Acompañantes ({presentCompanions.length}):</span>
            {presentCompanions.map(agent => {
              const mem = currentSession.companionMemories?.[agent.id];
              const mood = mem?.currentMood || 'Sereno';
              return (
                <div
                  key={agent.id}
                  onClick={() => setTargetSpeakerId(agent.id)}
                  className={`p-2.5 rounded-xl border transition-all cursor-pointer space-y-1.5 ${
                    targetSpeakerId === agent.id
                      ? 'bg-[#1C2030] border-[#C9A050] shadow-sm'
                      : 'bg-[#12141C] border-[#1F222E] hover:border-[#2C3142]'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-lg bg-blue-500/20 text-blue-300 font-bold text-[11px] flex items-center justify-center border border-blue-500/30 shrink-0">
                      {agent.name.charAt(0)}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-semibold text-white truncate">{agent.name}</div>
                      <div className="text-[10px] text-[#888888] truncate">{agent.role}</div>
                    </div>
                  </div>

                  {/* Estado Anímico & Botón Terminal Lógico */}
                  <div className="flex items-center justify-between pt-1 border-t border-[#1B1D28] text-[10px]">
                    <span className="font-mono text-amber-300/90 bg-amber-500/10 px-1.5 py-0.2 rounded border border-amber-500/20">
                      {mood}
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveTerminalCompanionId(agent.id);
                      }}
                      className="text-[#8A8F9E] hover:text-amber-300 flex items-center gap-1 font-mono transition-colors p-0.5 cursor-pointer"
                      title="Abrir Terminal Lógico, memoria y pensamientos de este agente"
                    >
                      <Terminal className="w-3 h-3 text-[#C9A050]" />
                      <span>Terminal</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Worldbuilding & Escenario Mini-Card */}
          <div className="mt-auto pt-3 border-t border-[#1C1F2A] text-[11px] text-[#888888] space-y-1">
            <div className="font-mono text-[#AAAAAA] flex items-center gap-1">
              <Compass className="w-3 h-3 text-[#C9A050]" />
              <span className="truncate">{currentSession.place?.name}</span>
            </div>
            <p className="line-clamp-2 text-[10px] text-[#777777] italic leading-normal">
              {currentSession.place?.details}
            </p>
          </div>
        </div>

        {/* Stream de Chat & Formulario de Entrada */}
        <div className="flex-1 flex flex-col bg-[#0E1015] border border-[#20222D] rounded-2xl overflow-hidden shadow-xl">
          {/* Mensajes */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3.5 selection:bg-[#C9A050] selection:text-black">
            {currentSession.dialogueHistory?.map((msg, idx) => {
              const isUser = msg.speaker === 'protagonist';
              const isNarrator = msg.speaker === 'narrator';
              const isSystem = msg.speaker === 'system';

              if (isNarrator) {
                const analysis = msg.narratorAnalysis;
                const isExpanded = expandedNarratorMsgId === msg.id;
                return (
                  <div key={msg.id || idx} className="flex justify-center my-3 animate-fadeIn px-2 sm:px-6">
                    <div className="bg-[#141622]/95 border border-amber-500/35 rounded-2xl px-5 py-3.5 max-w-2xl w-full text-left shadow-lg transition-all">
                      <div className="flex items-center justify-between gap-1.5 text-amber-400 text-[10px] font-mono uppercase tracking-widest mb-2 border-b border-amber-500/20 pb-1.5">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                          <span className="font-semibold text-amber-300">{msg.speakerName || 'Narración de Escenario'}</span>
                          {analysis?.isOocDirectAnswer && (
                            <span className="bg-amber-400/20 text-amber-300 text-[9px] px-2 py-0.5 rounded-full border border-amber-400/30">
                              Respuesta OOC
                            </span>
                          )}
                        </div>
                        <span className="text-[#888899]">{msg.timestamp}</span>
                      </div>
                      <div className="text-xs sm:text-[13px] text-[#E0E2EC] italic leading-relaxed whitespace-pre-line font-serif">
                        {msg.text}
                      </div>

                      {/* Barra de acciones del Narrador */}
                      <div className="mt-3 pt-2 border-t border-amber-500/20 flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handlePlayTts(msg.id, msg.text)}
                            className="text-[10px] text-amber-300/80 hover:text-amber-200 flex items-center gap-1 transition-colors cursor-pointer"
                            title="Escuchar locución del narrador"
                          >
                            {ttsLoadingId === msg.id ? (
                              <>
                                <Volume2 className="w-3 h-3 text-amber-400 animate-bounce" />
                                <span className="text-amber-300">Locución en curso...</span>
                              </>
                            ) : (
                              <>
                                <Volume2 className="w-3 h-3" />
                                <span>Voz</span>
                              </>
                            )}
                          </button>

                          {(analysis?.directorIntent || analysis?.environmentalShift || analysis?.castReactionsSummary || (analysis?.narrativeHooks && analysis.narrativeHooks.length > 0)) && (
                            <button
                              type="button"
                              onClick={() => setExpandedNarratorMsgId(isExpanded ? null : msg.id)}
                              className="text-[10px] text-amber-300/90 hover:text-amber-100 flex items-center gap-1 transition-all cursor-pointer bg-amber-500/10 hover:bg-amber-500/20 px-2 py-0.5 rounded border border-amber-500/30 font-sans font-medium"
                              title="Ver análisis del Director de Juego OOC: intención dramática, física y elenco"
                            >
                              <Brain className="w-3 h-3 text-amber-400" />
                              <span>Visión del Director (IA OOC)</span>
                              {isExpanded ? <ChevronUp className="w-2.5 h-2.5" /> : <ChevronDown className="w-2.5 h-2.5" />}
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Panel desplegable con la Visión del Director */}
                      {isExpanded && analysis && (
                        <div className="mt-3 pt-2.5 border-t border-amber-500/20 text-[11px] font-sans space-y-2.5 animate-fadeIn bg-[#0D0F17]/90 p-3 rounded-xl border border-amber-500/20">
                          {analysis.directorIntent && (
                            <div>
                              <span className="text-amber-400 font-semibold uppercase tracking-wider text-[9px] block mb-0.5 font-mono">
                                Intención Dramática:
                              </span>
                              <p className="text-amber-100/90 italic">{analysis.directorIntent}</p>
                            </div>
                          )}

                          {analysis.environmentalShift && (
                            <div>
                              <span className="text-blue-300 font-semibold uppercase tracking-wider text-[9px] block mb-0.5 font-mono">
                                Estado Físico & Escenario:
                              </span>
                              <p className="text-[#C5CADB]">{analysis.environmentalShift}</p>
                            </div>
                          )}

                          {analysis.castReactionsSummary && (
                            <div>
                              <span className="text-emerald-400 font-semibold uppercase tracking-wider text-[9px] block mb-0.5 font-mono">
                                Presencia & Reacciones del Elenco:
                              </span>
                              <p className="text-[#C5CADB]">{analysis.castReactionsSummary}</p>
                            </div>
                          )}

                          {analysis.narrativeHooks && analysis.narrativeHooks.length > 0 && (
                            <div className="pt-1">
                              <span className="text-amber-400/90 font-semibold uppercase tracking-wider text-[9px] block mb-1 font-mono">
                                Ganchos Narrativos Disponibles:
                              </span>
                              <div className="flex flex-col gap-1">
                                {analysis.narrativeHooks.map((hook, hIdx) => (
                                  <button
                                    key={hIdx}
                                    type="button"
                                    onClick={() => setInputText(hook)}
                                    className="text-left text-[11px] text-amber-200/80 hover:text-white bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20 rounded-lg px-2.5 py-1.5 transition-all cursor-pointer flex items-center justify-between group"
                                  >
                                    <span>👉 {hook}</span>
                                    <span className="text-[9px] text-amber-400 opacity-0 group-hover:opacity-100 transition-opacity font-mono">Cargar en texto</span>
                                  </button>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                );
              }

              if (isSystem) {
                return (
                  <div key={msg.id || idx} className="flex justify-center my-1">
                    <span className="bg-[#12141C] text-[#888888] border border-[#20222C] text-[11px] px-3 py-1 rounded-full font-mono">
                      {msg.text}
                    </span>
                  </div>
                );
              }

              return (
                <div
                  key={msg.id || idx}
                  className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} animate-fadeIn`}
                >
                  <div className="flex items-center gap-1.5 mb-1 px-1 text-[11px] text-[#7A7E8D]">
                    <span className={isUser ? 'font-bold text-[#C9A050]' : 'font-bold text-[#8FB2FF]'}>
                      {msg.speakerName}
                    </span>
                    <span>·</span>
                    <span>{msg.timestamp || 'Ahora'}</span>
                  </div>

                  <div
                    className={`max-w-[85%] sm:max-w-xl rounded-2xl p-3.5 text-xs sm:text-sm leading-relaxed shadow-md relative group ${
                      isUser
                        ? 'bg-[#221F14] border border-[#C9A050]/50 text-[#F0EBE0] rounded-tr-xs'
                        : 'bg-[#14161F] border border-[#252838] text-[#E0E2EC] rounded-tl-xs'
                    }`}
                  >
                    <p className="whitespace-pre-wrap">{msg.text}</p>

                    {/* Botones de acción del mensaje */}
                    {!isUser && (
                      <div className="mt-2.5 flex flex-wrap items-center gap-2.5 pt-1.5 border-t border-[#1C1F2B]">
                        <button
                          onClick={() => handlePlayTts(msg.id, msg.text)}
                          className="text-[10px] text-[#888888] hover:text-[#C9A050] flex items-center gap-1 transition-colors cursor-pointer"
                          title="Escuchar locución de audio"
                        >
                          {ttsLoadingId === msg.id ? (
                            <>
                              <Volume2 className="w-3 h-3 text-[#C9A050] animate-bounce" />
                              <span className="text-[#C9A050]">Generando voz...</span>
                            </>
                          ) : (
                            <>
                              <Volume2 className="w-3 h-3" />
                              <span>Voz</span>
                            </>
                          )}
                        </button>

                        {/* Botón para desplegar Razonamiento y Monólogo Interior */}
                        {(msg.innerMonologue || msg.somaticObservation || msg.cognitiveTrace) && (
                          <button
                            onClick={() => setExpandedReasoningMsgId(expandedReasoningMsgId === msg.id ? null : msg.id)}
                            className="text-[10px] text-amber-300/90 hover:text-amber-200 flex items-center gap-1 transition-all cursor-pointer bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/25"
                            title="Ver monólogo íntimo, percepción somática y trazabilidad cognitiva de este personaje"
                          >
                            <Brain className="w-3 h-3 text-amber-400" />
                            <span>Razonamiento & Presencia</span>
                            {expandedReasoningMsgId === msg.id ? (
                              <ChevronUp className="w-2.5 h-2.5" />
                            ) : (
                              <ChevronDown className="w-2.5 h-2.5" />
                            )}
                          </button>
                        )}

                        {/* Terminal Lógico del Agente */}
                        {msg.speakerId && (
                          <button
                            onClick={() => setActiveTerminalCompanionId(msg.speakerId || null)}
                            className="text-[10px] text-[#8A8F9E] hover:text-amber-300 flex items-center gap-1 transition-colors cursor-pointer"
                            title="Inspeccionar el Terminal Lógico, estado anímico y pensamientos de este agente"
                          >
                            <Terminal className="w-3 h-3 text-[#C9A050]" />
                            <span>Terminal</span>
                          </button>
                        )}
                      </div>
                    )}

                    {/* Acordeón Desplegable de Razonamiento, Monólogo y Percepción Somática */}
                    {!isUser && expandedReasoningMsgId === msg.id && (
                      <div className="mt-3 pt-2.5 border-t border-amber-500/20 space-y-2 text-[11px] bg-[#0A0C11]/90 rounded-xl p-3 border animate-fadeIn">
                        {/* Monólogo Íntimo */}
                        {msg.innerMonologue && (
                          <div className="space-y-0.5">
                            <div className="text-[10px] font-mono text-amber-400 font-bold flex items-center gap-1 uppercase">
                              <span>💭 Monólogo Interior (Subtexto)</span>
                            </div>
                            <p className="text-[#D0D4E4] italic bg-[#13151F] p-2 rounded-lg border border-[#202332]">
                              "{msg.innerMonologue}"
                            </p>
                          </div>
                        )}

                        {/* Percepción Somática */}
                        {msg.somaticObservation && (
                          <div className="space-y-0.5">
                            <div className="text-[10px] font-mono text-emerald-400 font-bold flex items-center gap-1 uppercase">
                              <span>⚡ Percepción Somática & Centro de Gravedad</span>
                            </div>
                            <p className="text-[#AAB2C8] bg-[#10151C] p-2 rounded-lg border border-[#1B2430]">
                              {msg.somaticObservation}
                            </p>
                          </div>
                        )}

                        {/* Trazabilidad Cognitiva */}
                        {msg.cognitiveTrace && (
                          <div className="space-y-1 pt-1 border-t border-[#1C1F2B] text-[10px] text-[#8E93A6]">
                            {msg.cognitiveTrace.detectedIntent && (
                              <div>
                                <span className="text-[#C9A050]">Intención percibida en el usuario:</span> {msg.cognitiveTrace.detectedIntent}
                              </div>
                            )}
                            {msg.cognitiveTrace.selfAwarenessAssessment && (
                              <div>
                                <span className="text-[#8FB2FF]">Autonomía y postura propia:</span> {msg.cognitiveTrace.selfAwarenessAssessment}
                              </div>
                            )}
                            {msg.cognitiveTrace.relationalAssessment && (
                              <div>
                                <span className="text-emerald-400">Evaluación del vínculo:</span> {msg.cognitiveTrace.relationalAssessment}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {/* Indicador de escritura */}
            {isGenerating && (
              <div className="flex items-center gap-2 text-xs text-[#8A8F9E] italic py-2 px-1">
                <span className="w-2 h-2 rounded-full bg-[#C9A050] animate-ping" />
                <span>Los personajes están dialogando en el escenario...</span>
              </div>
            )}

            <div ref={chatEndRef} />
          </div>

          {/* Sugerencias Rápidas */}
          <div className="px-3.5 py-2 bg-[#0B0C10] border-t border-[#1B1D26] flex items-center gap-1.5 overflow-x-auto no-scrollbar shrink-0">
            <span className="text-[10px] font-mono text-[#666666] shrink-0">
              {targetSpeakerId === 'narrator' ? '📜 Consultas OOC / Escena:' : 'Sugerencias:'}
            </span>
            {(targetSpeakerId === 'narrator'
              ? [
                  'OOC: ¿Qué anomalías, objetos o accesos clave hay aquí?',
                  'OOC: ¿Cómo reacciona el elenco a la atmósfera y tensión?',
                  'OOC: ¿Qué consecuencias físicas y riesgos tengo si avanzo?',
                  'El tiempo avanza y el clima evoluciona en el lugar.',
                  'Avanzo sigilosamente inspeccionando el terreno.'
                ]
              : [
                  'Saludar cordialmente al grupo',
                  '¿Qué opinan de este escenario?',
                  'Compartir una reflexión en voz baja',
                  'Inspeccionar los accesos juntos',
                  '¿Cuáles son las reglas de este lugar?'
                ]
            ).map(sug => (
              <button
                key={sug}
                type="button"
                onClick={() => handleSendMessage(sug)}
                disabled={isGenerating}
                className={`border text-[11px] px-2.5 py-1 rounded-lg shrink-0 transition-all cursor-pointer disabled:opacity-50 ${
                  targetSpeakerId === 'narrator'
                    ? 'bg-amber-500/10 hover:bg-amber-500/20 border-amber-500/30 text-amber-200 hover:text-white'
                    : 'bg-[#141620] hover:bg-[#1C1F2D] border-[#232636] text-[#AAAAAA] hover:text-white'
                }`}
              >
                {sug}
              </button>
            ))}
          </div>

          {/* Formulario de Entrada */}
          <div className="p-3 bg-[#111319] border-t border-[#20222D] shrink-0">
            <form
              onSubmit={e => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="flex flex-col gap-2"
            >
              <div className="flex items-center justify-between text-[11px] text-[#7A7E8D] px-1">
                <div className="flex items-center gap-2">
                  <span>Dirigirse a:</span>
                  <select
                    value={targetSpeakerId}
                    onChange={e => setTargetSpeakerId(e.target.value)}
                    className="bg-[#171923] border border-[#272B3B] rounded-lg px-2 py-0.5 text-xs text-amber-300 focus:outline-none cursor-pointer"
                  >
                    <option value="all">⚡ Todo el grupo (Orgánico)</option>
                    <option value="narrator">📜 Narrador de Escena (IA OOC - Escenario & Mundo)</option>
                    {presentCompanions.map(a => (
                      <option key={a.id} value={a.id}>
                        {a.name} ({a.role})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleToggleOfflineMode}
                    className={`flex items-center gap-1 font-mono text-[10px] px-2 py-0.5 rounded-md border transition-all cursor-pointer ${
                      isOfflineMode
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                        : 'bg-[#171923] text-[#8A8F9E] border-[#272B3B] hover:text-white'
                    }`}
                    title="Alternar entre modo 100% offline y modo online"
                  >
                    {isOfflineMode ? (
                      <>
                        <Zap className="w-3 h-3 text-emerald-400" />
                        <span>Motor 100% Offline</span>
                      </>
                    ) : (
                      <>
                        <Wifi className="w-3 h-3 text-blue-400" />
                        <span>Online (con respaldo)</span>
                      </>
                    )}
                  </button>
                  <span className="text-[10px] text-[#666666] hidden sm:inline">
                    Enter para enviar · Shift+Enter para nueva línea
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <textarea
                  value={inputText}
                  onChange={e => setInputText(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage();
                    }
                  }}
                  placeholder={
                    targetSpeakerId === 'narrator'
                      ? 'Describe una acción o solicita al Narrador OOC el estado del entorno (ej: camina hacia la ventana, examina los alrededores, ¿qué consecuencias hay?)...'
                      : `Habla o describe una acción como ${currentSession.protagonist?.name || 'tu personaje'}... (ej: *mira a su alrededor con cautela* «¿Alguien más sintió ese cambio en el aire?»)`
                  }
                  rows={2}
                  disabled={isGenerating}
                  className="flex-1 bg-[#171923] border border-[#282B3A] focus:border-[#C9A050] rounded-xl p-2.5 text-xs sm:text-sm text-white placeholder-[#5A5E6E] focus:outline-none resize-none transition-all disabled:opacity-50"
                />

                <button
                  type="submit"
                  disabled={!inputText.trim() || isGenerating}
                  className="h-12 px-5 rounded-xl bg-[#C9A050] hover:bg-[#b58e45] text-black font-bold flex items-center justify-center gap-1.5 transition-all shadow-md cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
                >
                  <Send className="w-4 h-4" />
                  <span className="hidden sm:inline">Enviar</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
