import React, { useState } from 'react';
import { CharacterState, OrientalFantasyConfig } from '../../types';
import {
  ALL_STYLE_THEMATIC_DATA,
  StyleThematicDataPackage,
  StyleThematicTradition,
  StyleThematicPieceOption,
  StyleWeaponOption,
  StyleAccentMineral
} from '../../data';
import {
  Shield,
  Gem,
  Flame,
  Wind,
  Sword,
  Check,
  Plus,
  X,
  Compass,
  Palette,
  RotateCcw,
  Sparkles,
  Layers,
  Sliders,
  Crown,
  Zap,
  Tag
} from 'lucide-react';

interface StyleThematicSectionProps {
  state: CharacterState;
  setState: React.Dispatch<React.SetStateAction<CharacterState>>;
  triggerFeedback?: (msg: string) => void;
}

type TabType = 'TRADITIONS' | 'ARMOR' | 'ACCESSORIES' | 'SYMBOLISM' | 'WEAPONS';

export const StyleThematicSection: React.FC<StyleThematicSectionProps> = ({
  state,
  setState,
  triggerFeedback
}) => {
  const activeStyleFromState = state.styleVisual || 'Fantasía Oriental';
  const [browsingStyle, setBrowsingStyle] = useState<string>(activeStyleFromState);
  const [activeTab, setActiveTab] = useState<TabType>('TRADITIONS');
  const [armorCategoryFilter, setArmorCategoryFilter] = useState<string>('ALL');
  const [accessoryCategoryFilter, setAccessoryCategoryFilter] = useState<string>('ALL');

  // Retrieve current thematic package
  const currentPackage: StyleThematicDataPackage =
    ALL_STYLE_THEMATIC_DATA[browsingStyle] ||
    ALL_STYLE_THEMATIC_DATA['Fantasía Oriental'] ||
    ALL_STYLE_THEMATIC_DATA['Fantasía Tradicional'];

  // Current selections stored in orientalFantasy (the unified thematic container)
  const thematicData: OrientalFantasyConfig = state.orientalFantasy || {
    tradition: '',
    armorPieces: [],
    culturalAccessories: [],
    spiritualMotif: '',
    silkPattern: '',
    jadeAccentColor: '',
    energyAura: '',
    weaponStyle: ''
  };

  const totalSelectedCount =
    (thematicData.armorPieces?.length || 0) +
    (thematicData.culturalAccessories?.length || 0) +
    (thematicData.tradition ? 1 : 0) +
    (thematicData.spiritualMotif ? 1 : 0) +
    (thematicData.silkPattern ? 1 : 0) +
    (thematicData.jadeAccentColor ? 1 : 0) +
    (thematicData.energyAura && thematicData.energyAura !== 'Sin Aura (Aspecto Natural Puramente Físico)' ? 1 : 0);

  const updateThematic = (updates: Partial<OrientalFantasyConfig>) => {
    setState(prev => ({
      ...prev,
      orientalFantasy: {
        ...(prev.orientalFantasy || {}),
        ...updates
      }
    }));
  };

  const handleApplyTradition = (tradition: StyleThematicTradition) => {
    setState(prev => {
      const currentWeapons = prev.equipment.weapons || [];
      const hasWeapon = currentWeapons.includes(tradition.suggestedWeapon);
      const newWeapons = hasWeapon ? currentWeapons : [...currentWeapons, tradition.suggestedWeapon];

      return {
        ...prev,
        styleVisual: browsingStyle,
        orientalFantasy: {
          tradition: tradition.name,
          armorPieces: tradition.suggestedArmor,
          culturalAccessories: tradition.suggestedAccessories,
          spiritualMotif: tradition.suggestedMotif,
          silkPattern: tradition.suggestedSilk,
          jadeAccentColor: tradition.suggestedJade,
          energyAura: tradition.suggestedAura,
          weaponStyle: tradition.suggestedWeapon
        },
        equipment: {
          ...prev.equipment,
          weapons: newWeapons
        }
      };
    });

    if (triggerFeedback) {
      triggerFeedback(`Arquetipo '${tradition.name}' (${browsingStyle}) aplicado con éxito.`);
    }
  };

  const toggleArmorPiece = (pieceName: string) => {
    const current = thematicData.armorPieces || [];
    const isSelected = current.includes(pieceName);
    const newPieces = isSelected ? current.filter(p => p !== pieceName) : [...current, pieceName];
    updateThematic({ armorPieces: newPieces });
  };

  const toggleAccessory = (accName: string) => {
    const current = thematicData.culturalAccessories || [];
    const isSelected = current.includes(accName);
    const newAccs = isSelected ? current.filter(a => a !== accName) : [...current, accName];
    updateThematic({ culturalAccessories: newAccs });
  };

  const toggleWeaponToArsenal = (weaponName: string) => {
    const currentWeapons = state.equipment.weapons || [];
    const isSelected = currentWeapons.includes(weaponName);
    const newWeapons = isSelected ? currentWeapons.filter(w => w !== weaponName) : [...currentWeapons, weaponName];

    setState(prev => ({
      ...prev,
      equipment: {
        ...prev.equipment,
        weapons: newWeapons
      },
      orientalFantasy: {
        ...(prev.orientalFantasy || {}),
        weaponStyle: isSelected ? '' : weaponName
      }
    }));

    if (triggerFeedback) {
      triggerFeedback(isSelected ? `Arma '${weaponName}' retirada del arsenal.` : `Arma '${weaponName}' añadida al arsenal.`);
    }
  };

  const handleClearAllThematic = () => {
    setState(prev => ({
      ...prev,
      orientalFantasy: {
        tradition: '',
        armorPieces: [],
        culturalAccessories: [],
        spiritualMotif: '',
        silkPattern: '',
        jadeAccentColor: '',
        energyAura: '',
        weaponStyle: ''
      }
    }));
    if (triggerFeedback) {
      triggerFeedback('Configuración temática de armaduras y accesorios restablecida.');
    }
  };

  const armorCategories = Array.from(new Set(currentPackage.armorPieces.map(p => p.category)));
  const filteredArmorPieces =
    armorCategoryFilter === 'ALL'
      ? currentPackage.armorPieces
      : currentPackage.armorPieces.filter(p => p.category === armorCategoryFilter);

  const accessoryCategories = Array.from(new Set(currentPackage.culturalAccessories.map(a => a.category)));
  const filteredAccessories =
    accessoryCategoryFilter === 'ALL'
      ? currentPackage.culturalAccessories
      : currentPackage.culturalAccessories.filter(a => a.category === accessoryCategoryFilter);

  const allAvailableStyles = Object.keys(ALL_STYLE_THEMATIC_DATA);

  return (
    <div id="section-4-2-style-thematic" className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs relative overflow-hidden">
      {/* Top Banner & Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-5 pb-4 border-b border-[#222222]">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-[#C9A050]/10 border border-[#C9A050]/30 text-[#C9A050]">
              <Shield className="w-5 h-5" />
            </span>
            <div>
              <h3 className="text-lg font-serif italic text-[#C9A050] flex items-center gap-2">
                <span>4.2 Armadura y Accesorios por Estilo</span>
                {totalSelectedCount > 0 && (
                  <span className="text-[10px] font-mono not-italic px-2 py-0.5 rounded-full bg-[#C9A050] text-[#0A0B0E] font-bold">
                    {totalSelectedCount} seleccionados
                  </span>
                )}
              </h3>
              <p className="text-xs text-[#888888] mt-0.5">
                Piezas de armadura, blindaje, reliquias culturales, gadgets, patrones y motivos especializados para todos los estilos estéticos.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {totalSelectedCount > 0 && (
            <button
              onClick={handleClearAllThematic}
              className="px-2.5 py-1.5 rounded-lg border border-[#333333] hover:border-red-500/50 bg-[#15171C] text-[#888888] hover:text-red-400 text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Limpiar todas las selecciones temáticas"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Limpiar</span>
            </button>
          )}
        </div>
      </div>

      {/* Style Selector Bar */}
      <div className="mb-6 bg-[#15171C] border border-[#2A2D35] rounded-xl p-3.5">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-2.5">
          <div className="flex items-center gap-2">
            <Palette className="w-4 h-4 text-[#C9A050]" />
            <span className="text-xs font-bold text-[#E0E0E0]">Estilo Temático Seleccionado:</span>
            <span className="text-xs font-serif italic text-[#C9A050] font-semibold">
              {browsingStyle}
            </span>
            {browsingStyle === state.styleVisual ? (
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                Estilo Global Activo
              </span>
            ) : (
              <button
                onClick={() => {
                  setState(prev => ({ ...prev, styleVisual: browsingStyle }));
                  if (triggerFeedback) triggerFeedback(`Estilo global del personaje actualizado a '${browsingStyle}'.`);
                }}
                className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#C9A050]/15 text-[#C9A050] border border-[#C9A050]/40 hover:bg-[#C9A050] hover:text-[#0A0B0E] transition-all cursor-pointer"
              >
                Hacer Estilo Principal
              </button>
            )}
          </div>
          <span className="text-[11px] text-[#888888] font-mono">
            {allAvailableStyles.length} estilos con catálogo temático completo
          </span>
        </div>

        {/* Style Selector Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1.5 scrollbar-thin">
          {allAvailableStyles.map(sName => {
            const isBrowsing = browsingStyle === sName;
            const isMain = state.styleVisual === sName;
            return (
              <button
                key={sName}
                onClick={() => setBrowsingStyle(sName)}
                className={`px-3 py-1.5 rounded-lg text-xs whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
                  isBrowsing
                    ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-md shadow-[#C9A050]/20'
                    : isMain
                    ? 'bg-[#1A1C22] text-[#C9A050] border border-[#C9A050]/50 hover:border-[#C9A050]'
                    : 'bg-[#0F1115] text-[#888888] border border-[#222222] hover:text-[#E0E0E0] hover:border-[#444]'
                }`}
              >
                <span>{sName}</span>
                {isMain && !isBrowsing && (
                  <span className="w-1.5 h-1.5 rounded-full bg-[#C9A050]" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-[#222222] pb-3 mb-6 overflow-x-auto">
        <button
          onClick={() => setActiveTab('TRADITIONS')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'TRADITIONS'
              ? 'bg-[#C9A050] text-[#0A0B0E] shadow-sm'
              : 'bg-[#15171C] text-[#888888] hover:text-[#E0E0E0]'
          }`}
        >
          <Compass className="w-4 h-4" />
          <span>Arquetipos & Tradiciones</span>
          {thematicData.tradition && (
            <span className="w-2 h-2 rounded-full bg-[#0A0B0E]" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('ARMOR')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'ARMOR'
              ? 'bg-[#C9A050] text-[#0A0B0E] shadow-sm'
              : 'bg-[#15171C] text-[#888888] hover:text-[#E0E0E0]'
          }`}
        >
          <Shield className="w-4 h-4" />
          <span>Armaduras & Blindajes</span>
          {(thematicData.armorPieces?.length || 0) > 0 && (
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
              activeTab === 'ARMOR' ? 'bg-[#0A0B0E] text-[#C9A050]' : 'bg-[#C9A050] text-[#0A0B0E]'
            }`}>
              {thematicData.armorPieces?.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('ACCESSORIES')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'ACCESSORIES'
              ? 'bg-[#C9A050] text-[#0A0B0E] shadow-sm'
              : 'bg-[#15171C] text-[#888888] hover:text-[#E0E0E0]'
          }`}
        >
          <Gem className="w-4 h-4" />
          <span>Accesorios & Reliquias</span>
          {(thematicData.culturalAccessories?.length || 0) > 0 && (
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
              activeTab === 'ACCESSORIES' ? 'bg-[#0A0B0E] text-[#C9A050]' : 'bg-[#C9A050] text-[#0A0B0E]'
            }`}>
              {thematicData.culturalAccessories?.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('SYMBOLISM')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'SYMBOLISM'
              ? 'bg-[#C9A050] text-[#0A0B0E] shadow-sm'
              : 'bg-[#15171C] text-[#888888] hover:text-[#E0E0E0]'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>Simbolismo, Tejidos & Auras</span>
          {(thematicData.spiritualMotif || thematicData.silkPattern || thematicData.jadeAccentColor || thematicData.energyAura) && (
            <span className="w-2 h-2 rounded-full bg-[#C9A050]" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('WEAPONS')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'WEAPONS'
              ? 'bg-[#C9A050] text-[#0A0B0E] shadow-sm'
              : 'bg-[#15171C] text-[#888888] hover:text-[#E0E0E0]'
          }`}
        >
          <Sword className="w-4 h-4" />
          <span>Armamento Especializado</span>
          {thematicData.weaponStyle && (
            <span className="w-2 h-2 rounded-full bg-[#C9A050]" />
          )}
        </button>
      </div>

      {/* TAB 1: ARQUETIPOS Y TRADICIONES */}
      {activeTab === 'TRADITIONS' && (
        <div className="space-y-4">
          <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-4 flex items-center justify-between">
            <div>
              <h4 className="text-sm font-bold text-[#E0E0E0]">
                Arquetipos Canónicos de {browsingStyle}
              </h4>
              <p className="text-xs text-[#888888]">
                Al seleccionar un arquetipo se aplicará un conjunto armónico de armaduras, accesorios, patrones y auras.
              </p>
            </div>
            {thematicData.tradition && (
              <div className="text-right">
                <span className="text-[10px] text-[#888888] font-mono block">Arquetipo Actual:</span>
                <span className="text-xs font-bold text-[#C9A050]">{thematicData.tradition}</span>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {currentPackage.traditions.map(tradition => {
              const isSelected = thematicData.tradition === tradition.name;
              return (
                <div
                  key={tradition.id}
                  className={`rounded-xl p-4 border transition-all relative flex flex-col justify-between ${
                    isSelected
                      ? 'bg-[#1A1C22] border-[#C9A050] shadow-md shadow-[#C9A050]/10'
                      : 'bg-[#15171C] border-[#2A2D35] hover:border-[#444]'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <h5 className="text-sm font-bold text-[#FFFFFF]">{tradition.name}</h5>
                          {isSelected && (
                            <span className="text-[10px] font-mono bg-[#C9A050] text-[#0A0B0E] px-1.5 py-0.2 rounded font-bold">
                              Activo
                            </span>
                          )}
                        </div>
                        <span className="text-[11px] font-mono text-[#C9A050] block mt-0.5">
                          {tradition.subtitle}
                        </span>
                      </div>
                      <span className="text-xs font-mono text-[#888888] bg-[#0F1115] px-2 py-0.5 rounded border border-[#222222]">
                        {tradition.iconTag || tradition.category}
                      </span>
                    </div>

                    <p className="text-xs text-[#A0A0A0] mb-3 leading-relaxed">
                      {tradition.description}
                    </p>

                    {/* Key Attributes preview */}
                    <div className="space-y-1.5 text-[11px] bg-[#0F1115] p-2.5 rounded-lg border border-[#222222] mb-3">
                      <div className="flex items-center justify-between text-[#888888]">
                        <span className="font-mono">Arma Clave:</span>
                        <span className="text-[#E0E0E0] font-medium">{tradition.suggestedWeapon}</span>
                      </div>
                      <div className="flex items-center justify-between text-[#888888]">
                        <span className="font-mono">Motivo / Emblema:</span>
                        <span className="text-[#E0E0E0] font-medium">{tradition.suggestedMotif}</span>
                      </div>
                      <div className="flex items-center justify-between text-[#888888]">
                        <span className="font-mono">Aura / Atmósfera:</span>
                        <span className="text-[#C9A050] font-medium truncate max-w-[200px]">{tradition.suggestedAura}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => handleApplyTradition(tradition)}
                    className={`w-full py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                      isSelected
                        ? 'bg-[#C9A050] text-[#0A0B0E]'
                        : 'bg-[#1F222A] hover:bg-[#C9A050] hover:text-[#0A0B0E] text-[#E0E0E0] border border-[#333333]'
                    }`}
                  >
                    {isSelected ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Arquetipo Aplicado</span>
                      </>
                    ) : (
                      <>
                        <Plus className="w-3.5 h-3.5" />
                        <span>Aplicar Todo el Conjunto ({tradition.name})</span>
                      </>
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: ARMADURAS Y BLINDAJES */}
      {activeTab === 'ARMOR' && (
        <div className="space-y-4">
          {/* Category Filter */}
          <div className="flex flex-wrap items-center gap-1.5 bg-[#15171C] border border-[#2A2D35] rounded-xl p-2">
            <button
              onClick={() => setArmorCategoryFilter('ALL')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                armorCategoryFilter === 'ALL'
                  ? 'bg-[#C9A050] text-[#0A0B0E]'
                  : 'bg-[#0F1115] text-[#888888] hover:text-[#E0E0E0]'
              }`}
            >
              Todas ({currentPackage.armorPieces.length})
            </button>
            {armorCategories.map(cat => (
              <button
                key={cat}
                onClick={() => setArmorCategoryFilter(cat)}
                className={`px-3 py-1 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                  armorCategoryFilter === cat
                    ? 'bg-[#C9A050] text-[#0A0B0E] font-bold'
                    : 'bg-[#0F1115] text-[#888888] hover:text-[#E0E0E0]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Armor Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {filteredArmorPieces.map(piece => {
              const isSelected = (thematicData.armorPieces || []).includes(piece.name);
              return (
                <div
                  key={piece.id}
                  onClick={() => toggleArmorPiece(piece.name)}
                  className={`rounded-xl p-3 border transition-all cursor-pointer flex flex-col justify-between ${
                    isSelected
                      ? 'bg-[#1A1C22] border-[#C9A050] shadow-md shadow-[#C9A050]/15'
                      : 'bg-[#15171C] border-[#2A2D35] hover:border-[#444]'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <h5 className={`text-xs font-bold ${isSelected ? 'text-[#C9A050]' : 'text-[#FFFFFF]'}`}>
                        {piece.name}
                      </h5>
                      <div className={`w-4 h-4 rounded flex items-center justify-center border text-[9px] shrink-0 ${
                        isSelected
                          ? 'bg-[#C9A050] border-[#C9A050] text-[#0A0B0E] font-bold'
                          : 'border-[#444] bg-[#0F1115]'
                      }`}>
                        {isSelected && <Check className="w-3 h-3" />}
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-[#888888] bg-[#0F1115] px-1.5 py-0.5 rounded border border-[#222222] inline-block mb-2">
                      {piece.category} • {piece.culturalOrigin}
                    </span>
                    <p className="text-[11px] text-[#A0A0A0] leading-relaxed mb-2">
                      {piece.description}
                    </p>
                  </div>
                  <div className="text-[10px] font-mono text-[#C9A050]/80 pt-2 border-t border-[#222222] flex items-center justify-between">
                    <span>Origen / Categoría:</span>
                    <span className="text-[#E0E0E0] truncate max-w-[140px]">{piece.culturalOrigin}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: ACCESORIOS Y RELIQUIAS */}
      {activeTab === 'ACCESSORIES' && (
        <div className="space-y-4">
          {/* Category Filter */}
          <div className="flex flex-wrap items-center gap-1.5 bg-[#15171C] border border-[#2A2D35] rounded-xl p-2">
            <button
              onClick={() => setAccessoryCategoryFilter('ALL')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                accessoryCategoryFilter === 'ALL'
                  ? 'bg-[#C9A050] text-[#0A0B0E]'
                  : 'bg-[#0F1115] text-[#888888] hover:text-[#E0E0E0]'
              }`}
            >
              Todos ({currentPackage.culturalAccessories.length})
            </button>
            {accessoryCategories.map(cat => (
              <button
                key={cat}
                onClick={() => setAccessoryCategoryFilter(cat)}
                className={`px-3 py-1 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                  accessoryCategoryFilter === cat
                    ? 'bg-[#C9A050] text-[#0A0B0E] font-bold'
                    : 'bg-[#0F1115] text-[#888888] hover:text-[#E0E0E0]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Accessories Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {filteredAccessories.map(acc => {
              const isSelected = (thematicData.culturalAccessories || []).includes(acc.name);
              return (
                <div
                  key={acc.id}
                  onClick={() => toggleAccessory(acc.name)}
                  className={`rounded-xl p-3 border transition-all cursor-pointer flex flex-col justify-between ${
                    isSelected
                      ? 'bg-[#1A1C22] border-[#C9A050] shadow-md shadow-[#C9A050]/15'
                      : 'bg-[#15171C] border-[#2A2D35] hover:border-[#444]'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <h5 className={`text-xs font-bold ${isSelected ? 'text-[#C9A050]' : 'text-[#FFFFFF]'}`}>
                        {acc.name}
                      </h5>
                      <div className={`w-4 h-4 rounded flex items-center justify-center border text-[9px] shrink-0 ${
                        isSelected
                          ? 'bg-[#C9A050] border-[#C9A050] text-[#0A0B0E] font-bold'
                          : 'border-[#444] bg-[#0F1115]'
                      }`}>
                        {isSelected && <Check className="w-3 h-3" />}
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-[#888888] bg-[#0F1115] px-1.5 py-0.5 rounded border border-[#222222] inline-block mb-2">
                      {acc.category} • {acc.culturalOrigin}
                    </span>
                    <p className="text-[11px] text-[#A0A0A0] leading-relaxed mb-2">
                      {acc.description}
                    </p>
                  </div>
                  <div className="text-[10px] font-mono text-[#C9A050]/80 pt-2 border-t border-[#222222] flex items-center justify-between">
                    <span>Origen / Categoría:</span>
                    <span className="text-[#E0E0E0] truncate max-w-[140px]">{acc.culturalOrigin}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 4: SIMBOLISMO, TEJIDOS & AURAS */}
      {activeTab === 'SYMBOLISM' && (
        <div className="space-y-6">
          {/* Sub-section 1: Motivos y Emblemas */}
          <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-4">
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-[#2A2D35]">
              <div className="flex items-center gap-2">
                <Crown className="w-4 h-4 text-[#C9A050]" />
                <h4 className="text-xs font-bold text-[#E0E0E0]">1. Motivo, Emblema o Sello de Estilo</h4>
              </div>
              {thematicData.spiritualMotif && (
                <button
                  onClick={() => updateThematic({ spiritualMotif: '' })}
                  className="text-[10px] text-red-400 hover:underline cursor-pointer"
                >
                  Quitar Motivo
                </button>
              )}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
              {currentPackage.spiritualMotifs.map((motif, idx) => {
                const isSelected = thematicData.spiritualMotif === motif;
                return (
                  <button
                    key={`${motif}-${idx}`}
                    onClick={() => updateThematic({ spiritualMotif: isSelected ? '' : motif })}
                    className={`p-3 rounded-lg border text-left transition-all cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? 'bg-[#1A1C22] border-[#C9A050] text-[#FFFFFF]'
                        : 'bg-[#0F1115] border-[#222222] text-[#888888] hover:text-[#E0E0E0] hover:border-[#444]'
                    }`}
                  >
                    <span className="text-xs font-bold">{motif}</span>
                    {isSelected && <Check className="w-3.5 h-3.5 text-[#C9A050]" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Sub-section 2: Patrón Textil / Textura */}
          <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-4">
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-[#2A2D35]">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#C9A050]" />
                <h4 className="text-xs font-bold text-[#E0E0E0]">2. Patrón de Tejido, Brocado o Textura Táctil</h4>
              </div>
              {thematicData.silkPattern && (
                <button
                  onClick={() => updateThematic({ silkPattern: '' })}
                  className="text-[10px] text-red-400 hover:underline cursor-pointer"
                >
                  Quitar Patrón
                </button>
              )}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
              {currentPackage.silkPatterns.map((pattern, idx) => {
                const isSelected = thematicData.silkPattern === pattern;
                return (
                  <button
                    key={`${pattern}-${idx}`}
                    onClick={() => updateThematic({ silkPattern: isSelected ? '' : pattern })}
                    className={`p-3 rounded-lg border text-left transition-all cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? 'bg-[#1A1C22] border-[#C9A050] text-[#FFFFFF]'
                        : 'bg-[#0F1115] border-[#222222] text-[#888888] hover:text-[#E0E0E0] hover:border-[#444]'
                    }`}
                  >
                    <span className="text-xs font-bold">{pattern}</span>
                    {isSelected && <Check className="w-3.5 h-3.5 text-[#C9A050]" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Sub-section 3: Mineral / Metal / Color de Acento */}
          <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-4">
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-[#2A2D35]">
              <div className="flex items-center gap-2">
                <Palette className="w-4 h-4 text-[#C9A050]" />
                <h4 className="text-xs font-bold text-[#E0E0E0]">3. Mineral, Metal o Color de Acento</h4>
              </div>
              {thematicData.jadeAccentColor && (
                <button
                  onClick={() => updateThematic({ jadeAccentColor: '' })}
                  className="text-[10px] text-red-400 hover:underline cursor-pointer"
                >
                  Quitar Acento
                </button>
              )}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
              {currentPackage.jadeColors.map(jade => {
                const isSelected = thematicData.jadeAccentColor === jade.name;
                return (
                  <button
                    key={jade.id}
                    onClick={() => updateThematic({ jadeAccentColor: isSelected ? '' : jade.name })}
                    className={`p-2.5 rounded-lg border text-left transition-all cursor-pointer flex items-center gap-3 ${
                      isSelected
                        ? 'bg-[#1A1C22] border-[#C9A050] text-[#FFFFFF]'
                        : 'bg-[#0F1115] border-[#222222] text-[#888888] hover:text-[#E0E0E0] hover:border-[#444]'
                    }`}
                  >
                    <div
                      className="w-6 h-6 rounded-full border border-white/20 shrink-0 shadow-inner"
                      style={{ backgroundColor: jade.hex }}
                    />
                    <div className="overflow-hidden">
                      <div className="text-xs font-bold text-[#E0E0E0] truncate">{jade.name}</div>
                      <div className="text-[10px] text-[#888888] truncate">{jade.desc}</div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Sub-section 4: Auras y Efectos Atmosféricos */}
          <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-4">
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-[#2A2D35]">
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-[#C9A050]" />
                <h4 className="text-xs font-bold text-[#E0E0E0]">4. Aura Visual / Atmósfera Energética</h4>
              </div>
              {thematicData.energyAura && (
                <button
                  onClick={() => updateThematic({ energyAura: '' })}
                  className="text-[10px] text-red-400 hover:underline cursor-pointer"
                >
                  Quitar Aura
                </button>
              )}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {currentPackage.auras.map((aura, idx) => {
                const isSelected = thematicData.energyAura === aura;
                return (
                  <button
                    key={`${aura}-${idx}`}
                    onClick={() => updateThematic({ energyAura: isSelected ? '' : aura })}
                    className={`p-3 rounded-lg border text-left transition-all cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? 'bg-[#1A1C22] border-[#C9A050] text-[#FFFFFF]'
                        : 'bg-[#0F1115] border-[#222222] text-[#888888] hover:text-[#E0E0E0] hover:border-[#444]'
                    }`}
                  >
                    <span className={`text-xs font-bold ${isSelected ? 'text-[#C9A050]' : 'text-[#E0E0E0]'}`}>
                      {aura}
                    </span>
                    {isSelected && <Check className="w-3.5 h-3.5 text-[#C9A050]" />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: ARMAMENTO ESPECIALIZADO */}
      {activeTab === 'WEAPONS' && (
        <div className="space-y-4">
          <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-4 flex items-center justify-between">
            <div>
              <h4 className="text-sm font-bold text-[#E0E0E0]">
                Armamento Canónico de {browsingStyle}
              </h4>
              <p className="text-xs text-[#888888]">
                Haz clic en cualquier arma para equiparla o removerla de las armas activas del personaje (sección 4.4).
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {currentPackage.weapons.map((w, idx) => {
              const isEquipped = (state.equipment.weapons || []).includes(w.name);
              return (
                <div
                  key={`${w.name}-${idx}`}
                  className={`rounded-xl p-3.5 border transition-all flex flex-col justify-between ${
                    isEquipped
                      ? 'bg-[#1A1C22] border-[#C9A050] shadow-md shadow-[#C9A050]/15'
                      : 'bg-[#15171C] border-[#2A2D35] hover:border-[#444]'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-1.5">
                      <h5 className={`text-xs font-bold ${isEquipped ? 'text-[#C9A050]' : 'text-[#FFFFFF]'}`}>
                        {w.name}
                      </h5>
                      <span className="text-[10px] font-mono text-[#888888] bg-[#0F1115] px-1.5 py-0.5 rounded border border-[#222222]">
                        {w.type}
                      </span>
                    </div>
                    <p className="text-[11px] text-[#A0A0A0] leading-relaxed mb-3">
                      {w.desc}
                    </p>
                  </div>

                  <button
                    onClick={() => toggleWeaponToArsenal(w.name)}
                    className={`w-full py-1.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                      isEquipped
                        ? 'bg-[#C9A050] text-[#0A0B0E]'
                        : 'bg-[#1F222A] hover:bg-[#C9A050] hover:text-[#0A0B0E] text-[#E0E0E0] border border-[#333333]'
                    }`}
                  >
                    {isEquipped ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Equipada en Arsenal</span>
                      </>
                    ) : (
                      <>
                        <Plus className="w-3.5 h-3.5" />
                        <span>Equipar Arma</span>
                      </>
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
