import React, { useState, useMemo } from 'react';
import {
  BookOpen,
  Search,
  X,
  Sparkles,
  Activity,
  Layers,
  Zap,
  Globe2,
  Brain,
  Castle,
  Mountain,
  Scroll,
  ArrowRight,
  ShieldCheck,
  Check
} from 'lucide-react';
import {
  KnowledgeDomain,
  KnowledgeEntry,
  KNOWLEDGE_CORPUS,
  retrieveKnowledge
} from '../utils/localKnowledgeLibrary';

interface LocalKnowledgeLibraryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectKnowledgeToPrompt?: (entry: KnowledgeEntry) => void;
}

const DOMAIN_METADATA: Record<
  KnowledgeDomain,
  { label: string; icon: React.ComponentType<{ className?: string }>; color: string; desc: string }
> = {
  anatomy: {
    label: 'Anatomía & Biomecánica',
    icon: Activity,
    color: 'text-rose-400 border-rose-500/30 bg-rose-500/10',
    desc: 'Centro de gravedad, fatiga de apoyos, microexpresiones faciales y cascadas somáticas autónomas.'
  },
  clothing: {
    label: 'Ropa & Vestuario',
    icon: Layers,
    color: 'text-amber-400 border-amber-500/30 bg-amber-500/10',
    desc: 'Drapeado, gramajes, caída de telas, rigidez por clima, roce sonoro y absorción de agua.'
  },
  physics: {
    label: 'Física (Lag & Ripple)',
    icon: Zap,
    color: 'text-cyan-400 border-cyan-500/30 bg-cyan-500/10',
    desc: 'Efectos de retardo e inercia (lag), ondas concéntricas (ripple), acústica y corrientes de convección.'
  },
  culture: {
    label: 'Cultura & Protocolo',
    icon: Globe2,
    color: 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10',
    desc: 'Proxémica de estatus, distancias corporales, hospitalidad, juramentos y tabúes de sangre.'
  },
  psychology: {
    label: 'Psicología & Razonamiento',
    icon: Brain,
    color: 'text-indigo-400 border-indigo-500/30 bg-indigo-500/10',
    desc: 'Procesamiento dual Sistema 1 y 2, Teoría de la Mente, modelo dimensional PAD y sesgos lógicos.'
  },
  architecture: {
    label: 'Arquitectura & Masa',
    icon: Castle,
    color: 'text-orange-400 border-orange-500/30 bg-orange-500/10',
    desc: 'Bóvedas de sillería, cantería, escaleras defensivas, resonancia de muros y claroscuros.'
  },
  geology: {
    label: 'Geología & Topografía',
    icon: Mountain,
    color: 'text-lime-400 border-lime-500/30 bg-lime-500/10',
    desc: 'Litología de sustratos, tracción sobre arcilla o pizarra, canchales y cavidades kársticas.'
  },
  literature: {
    label: 'Tono Narrativo & Literatura',
    icon: Scroll,
    color: 'text-purple-400 border-purple-500/30 bg-purple-500/10',
    desc: 'Prosodia, cadencia oracional percusiva vs pausada, sinestesia sensorial y subtexto velado.'
  }
};

export const LocalKnowledgeLibraryModal: React.FC<LocalKnowledgeLibraryModalProps> = ({
  isOpen,
  onClose,
  onSelectKnowledgeToPrompt
}) => {
  const [selectedDomain, setSelectedDomain] = useState<KnowledgeDomain | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedEntryId, setSelectedEntryId] = useState<string>('phys_lag_hysteresis');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const allEntries = useMemo(() => {
    const list: KnowledgeEntry[] = [];
    (Object.keys(KNOWLEDGE_CORPUS) as KnowledgeDomain[]).forEach(dom => {
      list.push(...KNOWLEDGE_CORPUS[dom]);
    });
    return list;
  }, []);

  const filteredEntries = useMemo(() => {
    if (searchQuery.trim()) {
      const domains = selectedDomain === 'all' ? undefined : [selectedDomain];
      return retrieveKnowledge(searchQuery, domains);
    }
    if (selectedDomain === 'all') {
      return allEntries;
    }
    return KNOWLEDGE_CORPUS[selectedDomain] || [];
  }, [searchQuery, selectedDomain, allEntries]);

  const activeEntry = useMemo(() => {
    return allEntries.find(e => e.id === selectedEntryId) || filteredEntries[0] || allEntries[0];
  }, [selectedEntryId, allEntries, filteredEntries]);

  if (!isOpen) return null;

  const handleApplyToScene = (entry: KnowledgeEntry) => {
    if (onSelectKnowledgeToPrompt) {
      onSelectKnowledgeToPrompt(entry);
    }
    setCopiedId(entry.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div
      id="local-knowledge-library-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md"
      onClick={onClose}
    >
      <div
        id="local-knowledge-library-modal-card"
        className="relative flex flex-col w-full max-w-5xl h-[90vh] bg-neutral-900 border border-neutral-700/80 rounded-2xl shadow-2xl overflow-hidden text-neutral-200"
        onClick={e => e.stopPropagation()}
      >
        {/* CABECERA */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-950/70">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-semibold tracking-wide text-neutral-100">
                  Biblioteca Ontológica & Conocimientos Locales
                </h2>
                <span className="px-2 py-0.5 text-xs font-mono font-medium rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" /> 0ms Latencia • 100% Offline
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                Corpus de leyes físicas (lag, ripple), anatomía, vestuario, psicología, arquitectura, geología y literatura.
              </p>
            </div>
          </div>
          <button
            id="close-knowledge-library-btn"
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-neutral-100 rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* BARRA DE BÚSQUEDA Y FILTROS POR DOMINIO */}
        <div className="px-6 py-3 border-b border-neutral-800 bg-neutral-900/90 flex flex-col sm:flex-row gap-3 items-center">
          <div className="relative w-full sm:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
            <input
              id="search-knowledge-input"
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Buscar lag, ripple, seda, bóvedas, cadencia..."
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-neutral-800 border border-neutral-700 rounded-lg text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-cyan-500"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-200 text-xs"
              >
                ✕
              </button>
            )}
          </div>

          {/* Filtros por pestaña de dominio */}
          <div className="flex items-center gap-1.5 overflow-x-auto w-full pb-1 sm:pb-0 scrollbar-thin">
            <button
              onClick={() => setSelectedDomain('all')}
              className={`px-3 py-1 text-xs font-medium rounded-lg whitespace-nowrap transition-all ${
                selectedDomain === 'all'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                  : 'bg-neutral-800/80 text-neutral-400 hover:text-neutral-200 border border-neutral-700/50'
              }`}
            >
              Todos ({allEntries.length})
            </button>
            {(Object.keys(DOMAIN_METADATA) as KnowledgeDomain[]).map(dom => {
              const meta = DOMAIN_METADATA[dom];
              const Icon = meta.icon;
              const isSelected = selectedDomain === dom;
              return (
                <button
                  key={dom}
                  onClick={() => setSelectedDomain(dom)}
                  className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-lg whitespace-nowrap transition-all ${
                    isSelected
                      ? meta.color
                      : 'bg-neutral-800/60 text-neutral-400 hover:text-neutral-200 border border-neutral-700/40'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{meta.label.split(' ')[0]}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* CUERPO PRINCIPAL: PANEL DUAL (LISTA IZQUIERDA + DETALLE DERECHA) */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          {/* LISTA DE ENTRADAS */}
          <div className="w-full md:w-80 border-r border-neutral-800 bg-neutral-950/40 overflow-y-auto p-3 space-y-2">
            {filteredEntries.length === 0 ? (
              <div className="p-6 text-center text-xs text-neutral-500">
                No se encontraron principios con ese criterio. Prueba con palabras como "inercia", "capa", "suelo" o "ritmo".
              </div>
            ) : (
              filteredEntries.map(entry => {
                const isSelected = activeEntry?.id === entry.id;
                const meta = DOMAIN_METADATA[entry.domain];
                const Icon = meta.icon;
                return (
                  <div
                    key={entry.id}
                    id={`knowledge-item-${entry.id}`}
                    onClick={() => setSelectedEntryId(entry.id)}
                    className={`p-3 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-neutral-800 border-cyan-500/60 text-neutral-100 shadow-md shadow-cyan-500/5'
                        : 'bg-neutral-900/60 border-neutral-800/80 text-neutral-300 hover:border-neutral-700 hover:bg-neutral-800/50'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className={`flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-md ${meta.color}`}>
                        <Icon className="w-3 h-3" />
                        {meta.label.split(' ')[0]}
                      </span>
                    </div>
                    <h3 className="text-xs font-semibold text-neutral-100 line-clamp-1 mb-1">
                      {entry.title}
                    </h3>
                    <p className="text-[11px] text-neutral-400 line-clamp-2 leading-relaxed">
                      {entry.summary}
                    </p>
                  </div>
                );
              })
            )}
          </div>

          {/* DETALLE COMPLETO DE LA ENTRADA SELECCIONADA */}
          {activeEntry ? (
            <div className="flex-1 overflow-y-auto p-6 bg-neutral-900/80 space-y-6">
              {/* Encabezado de la entrada */}
              <div className="border-b border-neutral-800 pb-4">
                <div className="flex items-center justify-between gap-4 mb-2">
                  <div className="flex items-center gap-2">
                    {(() => {
                      const meta = DOMAIN_METADATA[activeEntry.domain];
                      const Icon = meta.icon;
                      return (
                        <span className={`flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-lg ${meta.color}`}>
                          <Icon className="w-3.5 h-3.5" />
                          {meta.label}
                        </span>
                      );
                    })()}
                  </div>
                  {onSelectKnowledgeToPrompt && (
                    <button
                      id="apply-knowledge-btn"
                      onClick={() => handleApplyToScene(activeEntry)}
                      className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white transition-all shadow-sm"
                    >
                      {copiedId === activeEntry.id ? (
                        <>
                          <Check className="w-3.5 h-3.5" /> Aplicado al Chat
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-3.5 h-3.5" /> Aplicar a la Escena
                        </>
                      )}
                    </button>
                  )}
                </div>
                <h1 className="text-lg font-bold text-neutral-100 mb-2">
                  {activeEntry.title}
                </h1>
                <p className="text-xs text-neutral-300 leading-relaxed italic bg-neutral-950/40 p-3 rounded-lg border border-neutral-800/80">
                  «{activeEntry.summary}»
                </p>
              </div>

              {/* Mecánica Detallada */}
              <div className="space-y-2">
                <h4 className="text-xs font-semibold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5" /> Mecánica Ontológica & Dinámica
                </h4>
                <div className="p-3.5 rounded-xl bg-neutral-950/60 border border-neutral-800 text-xs text-neutral-300 leading-relaxed space-y-2">
                  <p>{activeEntry.detailedMechanics}</p>
                </div>
              </div>

              {/* Manifestaciones Sensoriales (Visual, Auditiva, Táctil, Cinestésica) */}
              <div className="space-y-2">
                <h4 className="text-xs font-semibold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5" /> Manifestaciones Sensoriales
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="p-3 rounded-xl bg-neutral-950/50 border border-neutral-800/80">
                    <span className="text-[10px] uppercase font-bold text-neutral-400 block mb-1">
                      Percepción Visual
                    </span>
                    <p className="text-xs text-neutral-300 leading-relaxed">
                      {activeEntry.sensoryManifestations.visual}
                    </p>
                  </div>
                  {activeEntry.sensoryManifestations.auditory && (
                    <div className="p-3 rounded-xl bg-neutral-950/50 border border-neutral-800/80">
                      <span className="text-[10px] uppercase font-bold text-neutral-400 block mb-1">
                        Resonancia Acústica
                      </span>
                      <p className="text-xs text-neutral-300 leading-relaxed">
                        {activeEntry.sensoryManifestations.auditory}
                      </p>
                    </div>
                  )}
                  {activeEntry.sensoryManifestations.tactile && (
                    <div className="p-3 rounded-xl bg-neutral-950/50 border border-neutral-800/80">
                      <span className="text-[10px] uppercase font-bold text-neutral-400 block mb-1">
                        Respuesta Táctil / Fricción
                      </span>
                      <p className="text-xs text-neutral-300 leading-relaxed">
                        {activeEntry.sensoryManifestations.tactile}
                      </p>
                    </div>
                  )}
                  {activeEntry.sensoryManifestations.kinesthetic && (
                    <div className="p-3 rounded-xl bg-neutral-950/50 border border-neutral-800/80">
                      <span className="text-[10px] uppercase font-bold text-neutral-400 block mb-1">
                        Cinestesia & Masa
                      </span>
                      <p className="text-xs text-neutral-300 leading-relaxed">
                        {activeEntry.sensoryManifestations.kinesthetic}
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Reglas Causales de Razonamiento */}
              <div className="space-y-2">
                <h4 className="text-xs font-semibold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5" /> Reglas Causales de Razonamiento
                </h4>
                <ul className="space-y-1.5">
                  {activeEntry.reasoningRules.map((rule, idx) => (
                    <li
                      key={idx}
                      className="p-2.5 rounded-lg bg-emerald-950/10 border border-emerald-900/30 text-xs text-neutral-300 flex items-start gap-2"
                    >
                      <ArrowRight className="w-3.5 h-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
                      <span>{rule}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Aplicación Narrativa */}
              <div className="space-y-2">
                <h4 className="text-xs font-semibold text-purple-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Scroll className="w-3.5 h-3.5" /> Aplicación Literaria & Estilística
                </h4>
                <div className="p-3 rounded-xl bg-purple-950/10 border border-purple-900/30 text-xs text-neutral-300 leading-relaxed">
                  {activeEntry.narrativeApplication}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center p-6 text-neutral-500 text-xs">
              Selecciona una entrada para explorar sus leyes fenomenológicas.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
