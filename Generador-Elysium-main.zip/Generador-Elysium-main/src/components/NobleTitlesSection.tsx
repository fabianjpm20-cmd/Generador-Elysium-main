import React, { useState } from 'react';
import { CharacterState } from '../types';
import {
  NOBLE_TITLES_CATALOG,
  NOBLE_FIEF_SUGGESTIONS,
  NobleTitleOption
} from '../data/nobleTitlesData';
import {
  Crown,
  Sparkles,
  Check,
  Building2,
  Shield,
  Award,
  Scroll,
  X,
  Plus,
  Compass,
  Layers,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { InfoTooltip } from './ui/InfoTooltip';

interface NobleTitlesSectionProps {
  state: CharacterState;
  setState: React.Dispatch<React.SetStateAction<CharacterState>>;
  triggerFeedback: (msg: string) => void;
  onEquipPiece: (pieceName: string, slotId?: string, categoryType?: string, visualDesc?: string) => void;
}

export const NobleTitlesSection: React.FC<NobleTitlesSectionProps> = ({
  state,
  setState,
  triggerFeedback,
  onEquipPiece
}) => {
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string>('ALL');
  const [genderMode, setGenderMode] = useState<'auto' | 'male' | 'female' | 'neutral'>('auto');
  const [customTitleInput, setCustomTitleInput] = useState<string>('');
  const [isCustomOpen, setIsCustomOpen] = useState<boolean>(false);
  const [isDetailsExpanded, setIsDetailsExpanded] = useState<boolean>(true);

  const isFemale =
    state.anatomy?.sexBase?.toLowerCase().includes('mujer') ||
    state.anatomy?.sexBase?.toLowerCase().includes('femenino') ||
    state.anatomy?.sexBase?.startsWith('2');

  const effectiveGender: 'male' | 'female' | 'neutral' =
    genderMode === 'auto' ? (isFemale ? 'female' : 'male') : genderMode;

  const currentNobleTitle = state.nobleTitle || '';
  const currentHouse = state.nobleHouseOrDomain || '';

  // Find matching catalog entry if any
  const matchedTitleOption = NOBLE_TITLES_CATALOG.find(
    opt =>
      opt.name === currentNobleTitle ||
      opt.maleTitle === currentNobleTitle ||
      opt.femaleTitle === currentNobleTitle ||
      opt.neutralTitle === currentNobleTitle ||
      currentNobleTitle.toLowerCase().includes(opt.maleTitle.toLowerCase()) ||
      currentNobleTitle.toLowerCase().includes(opt.femaleTitle.toLowerCase())
  );

  const getDisplayTitleName = (option: NobleTitleOption) => {
    if (effectiveGender === 'male') return option.maleTitle;
    if (effectiveGender === 'female') return option.femaleTitle;
    return option.neutralTitle;
  };

  const handleSelectTitle = (option: NobleTitleOption) => {
    const formattedName = getDisplayTitleName(option);
    const defaultHouse = currentHouse || option.fiefExamples[0] || 'de Valgrave';

    setState(prev => ({
      ...prev,
      nobleTitle: formattedName,
      nobleHouseOrDomain: defaultHouse
    }));

    triggerFeedback(`Título nobiliario "${formattedName}" seleccionado.`);
  };

  const handleApplyCustomTitle = () => {
    if (!customTitleInput.trim()) return;
    setState(prev => ({
      ...prev,
      nobleTitle: customTitleInput.trim(),
      nobleHouseOrDomain: prev.nobleHouseOrDomain || 'de la Alta Corte'
    }));
    triggerFeedback(`Título personalizado "${customTitleInput.trim()}" asignado.`);
    setCustomTitleInput('');
    setIsCustomOpen(false);
  };

  const handleClearTitle = () => {
    setState(prev => ({
      ...prev,
      nobleTitle: '',
      nobleHouseOrDomain: ''
    }));
    triggerFeedback('Título nobiliario removido.');
  };

  const handleEquipCoronet = () => {
    if (!matchedTitleOption) return;
    const piece = matchedTitleOption.suggestedPiece;
    onEquipPiece(piece, 'P1', 'role', `Insignia de rango nobiliario correspondiente al título de ${currentNobleTitle}: ${matchedTitleOption.heraldicCoronet}`);
    triggerFeedback(`Tocado/Insignia "${piece}" equipada en ranura P1.`);
  };

  const categories = [
    { id: 'ALL', label: 'Todos los Títulos', count: NOBLE_TITLES_CATALOG.length },
    { id: 'Alta Nobleza Soberana', label: 'Alta Nobleza Soberana', count: NOBLE_TITLES_CATALOG.filter(t => t.rankCategory === 'Alta Nobleza Soberana').length },
    { id: 'Nobleza Titulada Clásica', label: 'Nobleza Titulada Clásica', count: NOBLE_TITLES_CATALOG.filter(t => t.rankCategory === 'Nobleza Titulada Clásica').length },
    { id: 'Dignidad Feudal & Cortesana', label: 'Dignidad Feudal & Cortesana', count: NOBLE_TITLES_CATALOG.filter(t => t.rankCategory === 'Dignidad Feudal & Cortesana').length }
  ];

  const filteredTitles = NOBLE_TITLES_CATALOG.filter(t => {
    if (activeCategoryFilter === 'ALL') return true;
    return t.rankCategory === activeCategoryFilter;
  });

  return (
    <div
      id="noble-titles-exclusive-section"
      className="bg-gradient-to-br from-[#1C1811] via-[#14151B] to-[#121319] border-2 border-[#C9A050]/70 rounded-2xl p-5 md:p-6 space-y-5 shadow-xl relative overflow-hidden transition-all"
    >
      {/* Decorative Heraldic Background Ornament */}
      <div className="absolute top-0 right-0 -mt-10 -mr-10 w-44 h-44 bg-[#C9A050]/5 rounded-full blur-2xl pointer-events-none" />

      {/* Header with Heraldic Theme */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#C9A050]/30 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#C9A050] to-[#8C6D2B] p-0.5 shadow-md flex items-center justify-center">
            <div className="w-full h-full bg-[#0E1015] rounded-[10px] flex items-center justify-center">
              <Crown className="w-5 h-5 text-[#C9A050]" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base md:text-lg font-serif font-bold text-amber-200 tracking-wide flex items-center gap-2">
                <span>Títulos Nobiliarios & Dignidad Feudal</span>
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-[#C9A050]/20 text-[#C9A050] border border-[#C9A050]/40">
                Exclusivo Rol: Noble
              </span>
            </div>
            <p className="text-xs text-[#A0A0A0] mt-0.5">
              Define la jerarquía aristocrática, tratamiento protocolario de corte, corona o insignia heráldica y feudo patrimonial.
            </p>
          </div>
        </div>

        {/* Gender / Presentation Toggle */}
        <div className="flex items-center gap-1.5 bg-[#0A0B0E] p-1 rounded-xl border border-[#2A2D35] text-xs">
          <span className="text-[10px] font-mono text-[#888888] px-2 hidden sm:inline">Formato:</span>
          <button
            type="button"
            onClick={() => setGenderMode('auto')}
            className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-all cursor-pointer ${
              genderMode === 'auto'
                ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                : 'text-[#888888] hover:text-[#E0E0E0]'
            }`}
            title="Se ajusta automáticamente según la base anatómica del personaje"
          >
            Auto ({isFemale ? 'Fem.' : 'Masc.'})
          </button>
          <button
            type="button"
            onClick={() => setGenderMode('male')}
            className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-all cursor-pointer ${
              genderMode === 'male'
                ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                : 'text-[#888888] hover:text-[#E0E0E0]'
            }`}
          >
            Masc.
          </button>
          <button
            type="button"
            onClick={() => setGenderMode('female')}
            className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-all cursor-pointer ${
              genderMode === 'female'
                ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                : 'text-[#888888] hover:text-[#E0E0E0]'
            }`}
          >
            Fem.
          </button>
          <button
            type="button"
            onClick={() => setGenderMode('neutral')}
            className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-all cursor-pointer ${
              genderMode === 'neutral'
                ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                : 'text-[#888888] hover:text-[#E0E0E0]'
            }`}
          >
            Completo
          </button>
        </div>
      </div>

      {/* ACTIVE NOBLE TITLE HERO BANNER */}
      {currentNobleTitle ? (
        <div className="bg-gradient-to-r from-[#241F14] via-[#1A1C23] to-[#12141A] border border-[#C9A050]/50 rounded-xl p-4 shadow-md space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#C9A050]/20">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Crown className="w-4 h-4 text-[#C9A050]" />
                <span className="text-[10px] font-mono text-[#C9A050] uppercase tracking-wider font-bold">
                  Título Nobiliario Activo
                </span>
                {matchedTitleOption && (
                  <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-amber-950/40 border border-amber-500/40 text-amber-300">
                    {matchedTitleOption.rankCategory} (Rango {matchedTitleOption.precedenceLevel})
                  </span>
                )}
              </div>
              <h4 className="text-lg md:text-xl font-serif font-bold text-amber-100 flex items-baseline gap-2 flex-wrap">
                <span>{currentNobleTitle}</span>
                {currentHouse && (
                  <span className="text-amber-300/90 font-normal italic text-base">
                    {currentHouse}
                  </span>
                )}
              </h4>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {matchedTitleOption && (
                <button
                  type="button"
                  onClick={handleEquipCoronet}
                  className="px-3 py-1.5 bg-[#C9A050] hover:bg-[#D4AF37] text-[#0A0B0E] font-bold text-xs rounded-lg flex items-center gap-1.5 transition-all shadow-md cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5 fill-current" />
                  <span>Equipar Tocado ({matchedTitleOption.suggestedPiece.split(' ')[0]})</span>
                </button>
              )}
              <button
                type="button"
                onClick={handleClearTitle}
                className="px-2.5 py-1.5 bg-[#15171C] hover:bg-red-950/40 hover:text-red-300 border border-[#2A2D35] hover:border-red-500/40 text-[#888888] text-xs rounded-lg flex items-center gap-1 transition-all cursor-pointer font-mono"
              >
                <X className="w-3.5 h-3.5" />
                <span>Quitar</span>
              </button>
            </div>
          </div>

          {matchedTitleOption && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 text-xs">
              <div className="bg-[#0A0B0E]/60 p-2.5 rounded-lg border border-[#222222] space-y-1">
                <span className="text-amber-400 font-bold text-[10px] uppercase font-mono block flex items-center gap-1">
                  <Scroll className="w-3 h-3 text-amber-400" />
                  Tratamiento Protocolario de Corte:
                </span>
                <span className="text-amber-200 font-serif italic text-xs font-semibold block">
                  «{matchedTitleOption.treatment}»
                </span>
                <p className="text-[11px] text-[#888888] leading-tight mt-1">
                  {matchedTitleOption.description}
                </p>
              </div>

              <div className="bg-[#0A0B0E]/60 p-2.5 rounded-lg border border-[#222222] space-y-1">
                <span className="text-cyan-400 font-bold text-[10px] uppercase font-mono block flex items-center gap-1">
                  <Award className="w-3 h-3 text-cyan-400" />
                  Insignia Heráldica / Corona de Rango:
                </span>
                <span className="text-[#CCCCCC] text-xs block">
                  {matchedTitleOption.heraldicCoronet}
                </span>
                <div className="pt-1 flex items-center gap-2 text-[10px] text-[#888888]">
                  <span className="font-mono">Pieza sugerida:</span>
                  <span className="text-amber-300 font-semibold">{matchedTitleOption.suggestedPiece}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="bg-[#0F1115] border border-dashed border-[#C9A050]/40 rounded-xl p-3.5 text-center text-xs text-[#888888] flex items-center justify-center gap-2">
          <Crown className="w-4 h-4 text-[#C9A050]" />
          <span>No hay un título nobiliario seleccionado. Elige uno del catálogo a continuación para conferir rango dinástico.</span>
        </div>
      )}

      {/* Casa Nobiliaria, Señorío o Feudo (Input & Quick Suggestions) */}
      <div className="bg-[#0F1115] border border-[#222222] rounded-xl p-4 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <label className="text-xs font-mono text-[#C9A050] font-bold uppercase tracking-wider flex items-center gap-1.5">
            <Building2 className="w-3.5 h-3.5 text-[#C9A050]" />
            <span>Feudo, Señorío o Casa Dinástica (Sufijo Territorial)</span>
            <InfoTooltip text="Especifica la casa o dominio nobiliario del personaje, por ejemplo: 'de Valgrave', 'de Rosavalle', 'de la Casa Solaris'." />
          </label>
          {state.name && (
            <span className="text-[11px] text-[#888888] font-mono">
              Fórmula completa: <strong className="text-amber-200">{currentNobleTitle || 'Noble'} {state.name} {currentHouse}</strong>
            </span>
          )}
        </div>

        <div className="flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            value={state.nobleHouseOrDomain || ''}
            onChange={e => setState(prev => ({ ...prev, nobleHouseOrDomain: e.target.value }))}
            placeholder="ej. de Valgrave, de Rosavalle, de las Tierras Altas, de la Casa Solaris..."
            className="flex-1 bg-[#0A0B0E] border border-[#2A2D35] focus:border-[#C9A050] text-[#E0E0E0] text-xs px-3 py-2 rounded-lg outline-hidden font-serif"
          />
          {state.nobleHouseOrDomain && (
            <button
              type="button"
              onClick={() => setState(prev => ({ ...prev, nobleHouseOrDomain: '' }))}
              className="px-2.5 py-1.5 bg-[#15171C] text-[#888888] hover:text-[#E0E0E0] border border-[#2A2D35] rounded-lg text-xs font-mono cursor-pointer"
            >
              Borrar feudo
            </button>
          )}
        </div>

        {/* Fief quick suggestions */}
        <div className="pt-1">
          <span className="text-[10px] text-[#777777] font-mono block mb-1.5">Sugerencias rápidas de feudos y casas:</span>
          <div className="flex flex-wrap gap-1.5">
            {(matchedTitleOption?.fiefExamples || NOBLE_FIEF_SUGGESTIONS).map(fief => {
              const isSelected = state.nobleHouseOrDomain === fief;
              return (
                <button
                  key={fief}
                  type="button"
                  onClick={() => setState(prev => ({ ...prev, nobleHouseOrDomain: fief }))}
                  className={`px-2 py-0.5 rounded text-[11px] font-serif transition-all cursor-pointer border ${
                    isSelected
                      ? 'bg-[#C9A050] border-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                      : 'bg-[#15171C] border-[#2A2D35] text-[#AAAAAA] hover:text-amber-200 hover:border-[#555]'
                  }`}
                >
                  {fief}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Category Filter Tabs */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex flex-wrap gap-1.5">
            {categories.map(cat => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setActiveCategoryFilter(cat.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeCategoryFilter === cat.id
                    ? 'bg-[#C9A050] border-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                    : 'bg-[#0F1115] border-[#222222] text-[#888888] hover:text-[#CCCCCC] hover:border-[#444]'
                }`}
              >
                <span>{cat.label}</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                  activeCategoryFilter === cat.id ? 'bg-[#0A0B0E]/20 text-[#0A0B0E]' : 'bg-[#1A1C22] text-[#777]'
                }`}>
                  {cat.count}
                </span>
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => setIsCustomOpen(prev => !prev)}
            className="px-2.5 py-1 rounded-lg text-xs font-mono text-[#C9A050] hover:text-amber-200 border border-[#C9A050]/40 hover:border-[#C9A050] bg-[#C9A050]/10 transition-all cursor-pointer flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ Título Personalizado</span>
          </button>
        </div>

        {/* Custom Title Input Modal/Panel */}
        {isCustomOpen && (
          <div className="bg-[#0A0B0E] border border-amber-500/40 rounded-xl p-3.5 space-y-2.5 animate-fade-in">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono text-amber-300 font-bold flex items-center gap-1.5">
                <Crown className="w-3.5 h-3.5 text-amber-400" />
                Escribir Título Nobiliario Personalizado
              </span>
              <button
                type="button"
                onClick={() => setIsCustomOpen(false)}
                className="text-xs text-[#888888] hover:text-[#CCCCCC] cursor-pointer"
              >
                ✕
              </button>
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={customTitleInput}
                onChange={e => setCustomTitleInput(e.target.value)}
                placeholder="ej. Margrave, Dux, Conde Palatino, Gran Chambelán..."
                className="flex-1 bg-[#15171C] border border-[#2A2D35] focus:border-amber-400 text-[#E0E0E0] text-xs px-3 py-1.5 rounded-lg outline-hidden font-serif"
                onKeyDown={e => {
                  if (e.key === 'Enter') handleApplyCustomTitle();
                }}
              />
              <button
                type="button"
                onClick={handleApplyCustomTitle}
                className="px-3 py-1.5 bg-[#C9A050] hover:bg-[#D4AF37] text-[#0A0B0E] font-bold text-xs rounded-lg transition-all cursor-pointer shrink-0 font-mono"
              >
                Asignar
              </button>
            </div>
          </div>
        )}

        {/* NOBLE TITLES CATALOG GRID */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {filteredTitles.map(option => {
            const displayTitle = getDisplayTitleName(option);
            const isSelected =
              currentNobleTitle === displayTitle ||
              currentNobleTitle === option.name ||
              currentNobleTitle === option.maleTitle ||
              currentNobleTitle === option.femaleTitle ||
              currentNobleTitle === option.neutralTitle;

            return (
              <div
                key={option.id}
                onClick={() => handleSelectTitle(option)}
                className={`p-3.5 rounded-xl border transition-all cursor-pointer flex flex-col justify-between relative group ${
                  isSelected
                    ? 'bg-gradient-to-br from-[#241F14] to-[#161820] border-[#C9A050] shadow-md ring-1 ring-[#C9A050]'
                    : 'bg-[#0F1115] border-[#222222] hover:border-[#C9A050]/50 hover:bg-[#13151B]'
                }`}
              >
                <div>
                  {/* Top Bar with Badge & Check */}
                  <div className="flex items-center justify-between gap-1 mb-1.5">
                    <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded border ${
                      option.rankCategory === 'Alta Nobleza Soberana'
                        ? 'bg-purple-950/40 border-purple-500/40 text-purple-300'
                        : option.rankCategory === 'Nobleza Titulada Clásica'
                        ? 'bg-amber-950/40 border-amber-500/40 text-amber-300'
                        : 'bg-cyan-950/40 border-cyan-500/40 text-cyan-300'
                    }`}>
                      {option.rankCategory}
                    </span>
                    <div className="flex items-center gap-1">
                      <span className="text-[9px] font-mono text-[#777777]">
                        Rango {option.precedenceLevel}
                      </span>
                      {isSelected && (
                        <span className="w-4 h-4 rounded-full bg-[#C9A050] text-[#0A0B0E] flex items-center justify-center text-[10px] font-bold">
                          ✓
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Title Name */}
                  <h5 className={`text-sm font-serif font-bold mb-1 transition-colors ${
                    isSelected ? 'text-amber-200' : 'text-[#E0E0E0] group-hover:text-amber-300'
                  }`}>
                    {displayTitle}
                  </h5>

                  {/* Treatment */}
                  <div className="text-[11px] font-serif italic text-[#C9A050] mb-1.5 flex items-center gap-1">
                    <Scroll className="w-3 h-3 shrink-0" />
                    <span className="truncate">{option.treatment}</span>
                  </div>

                  {/* Description */}
                  <p className="text-[11px] text-[#888888] leading-tight line-clamp-2 mb-2">
                    {option.description}
                  </p>
                </div>

                {/* Footer Coronet & Quick Select */}
                <div className="pt-2 border-t border-[#222222] flex items-center justify-between text-[10px] text-[#777777]">
                  <span className="truncate max-w-[190px] text-[#999999]" title={option.heraldicCoronet}>
                    👑 {option.heraldicCoronet.split(',')[0]}
                  </span>
                  <span className={`font-mono text-[10px] font-semibold ${
                    isSelected ? 'text-amber-300' : 'text-[#666666] group-hover:text-[#AAAAAA]'
                  }`}>
                    {isSelected ? 'Seleccionado' : 'Elegir'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
