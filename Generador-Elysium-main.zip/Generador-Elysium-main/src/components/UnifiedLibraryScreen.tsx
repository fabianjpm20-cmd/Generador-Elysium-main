import React, { useState } from 'react';
import {
  CharacterState,
  SavedCharacterEntry,
  WorldPlace,
  WorldBuildingConfig,
  MainScreen
} from '../types';
import {
  getSavedCharacters,
  deleteCharacterFromLibrary,
  duplicateCharacterInLibrary,
  saveCharacterToLibrary,
  getCharacterVariantGroups,
  CharacterVariantGroup,
  createAlternateVersion,
  compileAndLinkExistingCharactersAsVariants,
  unlinkCharacterFromVariantGroup
} from '../utils/libraryStorage';
import { generateCharacterSheetText } from '../utils/characterPromptUtils';
import { LoadCharacterSheetModal } from './LoadCharacterSheetModal';
import { useModuloSync } from '../hooks/useModuloSync';
import {
  getSavedPlaces,
  deletePlace,
  duplicatePlace,
  exportSinglePlaceJson,
  toggleWorldLaw,
  exportEcosystemToJson,
  importEcosystemFromJson,
  getSavedWorldConfigs,
  duplicateWorldBuilding,
  deleteWorldBuilding,
  saveWorldBuildingConfig
} from '../utils/worldStorage';
import {
  BookMarked,
  Users,
  MapPin,
  ScrollText,
  Download,
  Upload,
  Plus,
  Trash2,
  Copy,
  Edit3,
  Heart,
  Shield,
  Check,
  Search,
  Layers,
  ArrowRight,
  X,
  Sparkles,
  GitBranch,
  Play,
  UserCheck,
  Compass,
  FileDown,
  FileText,
  FileCode,
  Eye,
  AlertTriangle,
  CheckCircle,
  ExternalLink,
  Link2
} from 'lucide-react';

interface UnifiedLibraryScreenProps {
  onNavigate: (screen: MainScreen) => void;
  // Characters
  onSelectCharacterForInteraction: (character: CharacterState) => void;
  onSelectCharacterForEdit: (character: CharacterState, step?: number) => void;
  onCreateNewCharacter: () => void;
  onSelectProtagonist: (character: CharacterState) => void;
  // Places
  activePlaceId?: string;
  onSetActivePlace: (place: WorldPlace) => void;
  onSelectPlaceForEdit: (place: WorldPlace) => void;
  onCreateNewPlace: () => void;
  // Worldbuilding
  onSetActiveWorld: (config: WorldBuildingConfig) => void;
  onSelectWorldForEdit: (config: WorldBuildingConfig) => void;
  onCreateNewWorldBuilding: () => void;
  onReloadCounts?: () => void;
}

interface DeleteConfirmTarget {
  type: 'character' | 'place' | 'world';
  id: string;
  name: string;
}

export const UnifiedLibraryScreen: React.FC<UnifiedLibraryScreenProps> = ({
  onNavigate,
  onSelectCharacterForInteraction,
  onSelectCharacterForEdit,
  onCreateNewCharacter,
  onSelectProtagonist,
  activePlaceId,
  onSetActivePlace,
  onSelectPlaceForEdit,
  onCreateNewPlace,
  onSetActiveWorld,
  onSelectWorldForEdit,
  onCreateNewWorldBuilding,
  onReloadCounts
}) => {
  const [activeTab, setActiveTab] = useState<'characters' | 'places' | 'worldbuilding' | 'backup'>('characters');

  // Real-time synchronization hook
  const {
    savedCharacters: characters,
    savedPlaces: places,
    worldConfig,
    deleteFromLibrary,
    duplicateInLibrary,
    updateWorldConfig,
    triggerGlobalSync
  } = useModuloSync({ source: 'library' });

  // List of all saved world configs
  const [savedWorldList, setSavedWorldList] = useState<WorldBuildingConfig[]>(() => getSavedWorldConfigs());

  const [searchTerm, setSearchTerm] = useState('');
  const [importJsonText, setImportJsonText] = useState('');
  const [importStatus, setImportStatus] = useState<string | null>(null);
  const [actionNotice, setActionNotice] = useState<{ message: string; actionText?: string; onAction?: () => void } | null>(null);

  // Variant modal state: when a character group is clicked
  const [selectedGroupForVariants, setSelectedGroupForVariants] = useState<CharacterVariantGroup | null>(null);
  // Modal to add or compile variants for a character
  const [variantModalTargetCharId, setVariantModalTargetCharId] = useState<string | null>(null);
  const [variantModalTab, setVariantModalTab] = useState<'select_existing' | 'create_new'>('select_existing');
  const [selectedCandidateIds, setSelectedCandidateIds] = useState<string[]>([]);
  const [candidateVariantLabels, setCandidateVariantLabels] = useState<Record<string, string>>({});
  const [candidateSearchTerm, setCandidateSearchTerm] = useState('');
  const [autoLinkCanonicalRelationships, setAutoLinkCanonicalRelationships] = useState(true);
  const [customCreationLabel, setCustomCreationLabel] = useState('');

  const openVariantModalForCharacter = (charId: string, initialTab: 'select_existing' | 'create_new' = 'select_existing') => {
    setVariantModalTargetCharId(charId);
    setVariantModalTab(initialTab);
    setSelectedCandidateIds([]);
    setCandidateVariantLabels({});
    setCandidateSearchTerm('');
    setCustomCreationLabel('');
  };

  // In-app delete confirmation state (prevents iframe alert/confirm blocking)
  const [deleteConfirmTarget, setDeleteConfirmTarget] = useState<DeleteConfirmTarget | null>(null);

  // Canonical sheet preview modal
  const [previewSheetCharacter, setPreviewSheetCharacter] = useState<CharacterState | null>(null);
  const [sheetCopied, setSheetCopied] = useState(false);

  // Load canonical sheet modal
  const [showLoadSheetModal, setShowLoadSheetModal] = useState(false);

  const showNotice = (message: string, actionText?: string, onAction?: () => void) => {
    setActionNotice({ message, actionText, onAction });
    setTimeout(() => {
      setActionNotice(prev => (prev?.message === message ? null : prev));
    }, 4500);
  };

  const refreshData = () => {
    triggerGlobalSync();
    setSavedWorldList(getSavedWorldConfigs());
    if (onReloadCounts) onReloadCounts();
  };

  // ==========================================
  // NON-BLOCKING DELETION EXECUTION
  // ==========================================
  const handleExecuteDelete = () => {
    if (!deleteConfirmTarget) return;
    const { type, id, name } = deleteConfirmTarget;

    if (type === 'character') {
      deleteFromLibrary(id);
      refreshData();
      if (selectedGroupForVariants) {
        const remaining = selectedGroupForVariants.allEntries.filter(e => e.id !== id);
        if (remaining.length <= 1) {
          setSelectedGroupForVariants(null);
        } else {
          setSelectedGroupForVariants(prev => prev ? {
            ...prev,
            variants: prev.variants.filter(e => e.id !== id),
            allEntries: remaining
          } : null);
        }
      }
      showNotice(`Personaje «${name}» eliminado de la biblioteca.`);
    } else if (type === 'place') {
      deletePlace(id);
      refreshData();
      showNotice(`Escenario «${name}» eliminado.`);
    } else if (type === 'world') {
      deleteWorldBuilding(id);
      refreshData();
      showNotice(`Worldbuilding «${name}» eliminado.`);
    }

    setDeleteConfirmTarget(null);
  };

  // ==========================================
  // CHARACTER HANDLERS
  // ==========================================
  const handleDeleteCharacter = (id: string, name: string) => {
    setDeleteConfirmTarget({ type: 'character', id, name });
  };

  const handleDuplicateCharacter = (id: string) => {
    duplicateInLibrary(id);
    refreshData();
    showNotice('Personaje duplicado exitosamente.');
  };

  const handleCreateVariant = (originalId: string, variantType: 'Rol/Vestuario' | 'Futuro' | 'Pasado' | 'Personalizada') => {
    const newEntry = createAlternateVersion(originalId, variantType);
    if (newEntry) {
      refreshData();
      setVariantModalTargetCharId(null);
      setCustomCreationLabel('');
      showNotice(`Variante (${variantType}) creada exitosamente.`, 'Editar ahora', () => {
        onSelectCharacterForEdit(newEntry.state, 1);
        onNavigate('creation');
      });
      // Update open variant drawer if open
      const updatedGroups = getCharacterVariantGroups(getSavedCharacters());
      const currentGroup = updatedGroups.find(g => g.groupId === newEntry.variantGroupId || g.allEntries.some(e => e.id === originalId));
      if (currentGroup) {
        setSelectedGroupForVariants(currentGroup);
      }
    }
  };

  const handleCompileExistingVariants = (targetCharId: string) => {
    if (selectedCandidateIds.length === 0) return;
    const res = compileAndLinkExistingCharactersAsVariants(
      targetCharId,
      selectedCandidateIds,
      candidateVariantLabels,
      autoLinkCanonicalRelationships
    );
    if (res.success) {
      refreshData();
      setVariantModalTargetCharId(null);
      setSelectedCandidateIds([]);
      setCandidateVariantLabels({});
      setCandidateSearchTerm('');
      
      const updatedGroups = getCharacterVariantGroups(getSavedCharacters());
      const currentGroup = updatedGroups.find(g => g.groupId === res.groupId || g.allEntries.some(e => e.id === targetCharId));
      if (currentGroup) {
        setSelectedGroupForVariants(currentGroup);
      }
      showNotice(
        `Se han compilado y juntado ${res.modifiedCount} personaje(s) como variantes exitosamente.`,
        'Ver Variantes',
        () => {
          if (currentGroup) setSelectedGroupForVariants(currentGroup);
        }
      );
    }
  };

  // Group characters by variant group
  const characterGroups = getCharacterVariantGroups(characters);

  const filteredGroups = characterGroups.filter(g => {
    const q = searchTerm.toLowerCase();
    const matchesGroupName = g.groupName.toLowerCase().includes(q);
    const matchesAnyMember = g.allEntries.some(entry => {
      const name = (entry.state.identity?.fullName || entry.state.name || '').toLowerCase();
      const race = (entry.state.identity?.race || entry.state.raceName || '').toLowerCase();
      const role = (entry.state.archetype || entry.state.role || '').toLowerCase();
      return name.includes(q) || race.includes(q) || role.includes(q);
    });
    return matchesGroupName || matchesAnyMember;
  });

  // ==========================================
  // PLACE HANDLERS
  // ==========================================
  const handleDeletePlace = (id: string, name: string) => {
    setDeleteConfirmTarget({ type: 'place', id, name });
  };

  const handleDuplicatePlace = (id: string) => {
    const dup = duplicatePlace(id);
    if (dup) {
      refreshData();
      showNotice(`Escenario «${dup.name}» duplicado exitosamente.`);
    }
  };

  const handleLoadPlace = (place: WorldPlace) => {
    onSetActivePlace(place);
    showNotice(`Escenario «${place.name}» cargado como entorno activo.`, 'Ir a Interacción', () => {
      onNavigate('interaction');
    });
  };

  const filteredPlaces = places.filter(p => {
    const q = searchTerm.toLowerCase();
    return p.name.toLowerCase().includes(q) || p.region.toLowerCase().includes(q) || p.environmentType.toLowerCase().includes(q);
  });

  // ==========================================
  // WORLDBUILDING HANDLERS
  // ==========================================
  const handleLoadWorld = (config: WorldBuildingConfig) => {
    saveWorldBuildingConfig(config);
    onSetActiveWorld(config);
    refreshData();
    showNotice(`Worldbuilding «${config.worldName}» cargado como macro-mundo activo.`);
  };

  const handleDuplicateWorld = (id: string) => {
    const dup = duplicateWorldBuilding(id);
    if (dup) {
      refreshData();
      showNotice(`Worldbuilding «${dup.worldName}» duplicado exitosamente.`);
    }
  };

  const handleDeleteWorld = (id: string, name: string) => {
    setDeleteConfirmTarget({ type: 'world', id, name });
  };

  const handleToggleLaw = (lawId: string) => {
    const updated = toggleWorldLaw(lawId);
    updateWorldConfig(updated);
    refreshData();
  };

  // ==========================================
  // BACKUP EXPORT & IMPORT
  // ==========================================
  const handleExportJson = () => {
    const jsonStr = exportEcosystemToJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `elysium_ecosystem_${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleImportJson = () => {
    if (!importJsonText.trim()) return;
    const res = importEcosystemFromJson(importJsonText);
    if (res.success) {
      setImportStatus(`¡Importación exitosa! (${res.characterCount} personajes, ${res.placeCount} lugares cargados)`);
      refreshData();
      setImportJsonText('');
    } else {
      setImportStatus(`Error: ${res.error || 'JSON inválido'}`);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Toast notification */}
      {actionNotice && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-3 bg-[#13151C] border border-[#D4AF37]/50 text-[#F3F4F6] px-4 py-3 rounded-2xl shadow-2xl animate-in fade-in slide-in-from-bottom-3">
          <Sparkles className="w-4 h-4 text-[#D4AF37] shrink-0" />
          <span className="text-xs font-semibold">{actionNotice.message}</span>
          {actionNotice.actionText && actionNotice.onAction && (
            <button
              type="button"
              onClick={actionNotice.onAction}
              className="px-2.5 py-1 rounded-lg bg-[#D4AF37] text-black text-[11px] font-bold hover:bg-yellow-400 cursor-pointer"
            >
              {actionNotice.actionText}
            </button>
          )}
          <button
            type="button"
            onClick={() => setActionNotice(null)}
            className="text-[#8A8F9E] hover:text-white p-1"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Header & Main Entity Switcher */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[#232630] pb-6">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-[#D4AF37]">
              <BookMarked className="w-4 h-4" />
            </div>
            <h1 className="text-2xl font-serif italic text-[#F3F4F6]">2. Biblioteca Central</h1>
          </div>
          <p className="text-xs text-[#8A8F9E] mt-1">
            Punto de partida: Carga, edita, duplica o elimina personajes, escenarios y worldbuildings ya terminados, o crea uno nuevo para tu universo.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex flex-wrap items-center gap-2 bg-[#12141A] p-1.5 rounded-2xl border border-[#262934]">
          <button
            type="button"
            onClick={() => setActiveTab('characters')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'characters'
                ? 'bg-[#1C1F28] text-[#D4AF37] border border-[#3A3F4E] shadow-sm'
                : 'text-[#8A8F9E] hover:text-[#E0E0E0]'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Personajes ({characters.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('places')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'places'
                ? 'bg-[#1C1F28] text-indigo-400 border border-[#3A3F4E] shadow-sm'
                : 'text-[#8A8F9E] hover:text-[#E0E0E0]'
            }`}
          >
            <MapPin className="w-4 h-4" />
            <span>Escenarios ({places.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('worldbuilding')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'worldbuilding'
                ? 'bg-[#1C1F28] text-emerald-400 border border-[#3A3F4E] shadow-sm'
                : 'text-[#8A8F9E] hover:text-[#E0E0E0]'
            }`}
          >
            <ScrollText className="w-4 h-4" />
            <span>Worldbuilding ({savedWorldList.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('backup')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'backup'
                ? 'bg-[#1C1F28] text-rose-400 border border-[#3A3F4E] shadow-sm'
                : 'text-[#8A8F9E] hover:text-[#E0E0E0]'
            }`}
          >
            <Download className="w-4 h-4" />
            <span>Copia .JSON</span>
          </button>
        </div>
      </div>

      {/* ========================================================
          1. TAB PERSONAJES (CON SOPORTE DE VARIANTES AGRUPADAS)
         ======================================================== */}
      {activeTab === 'characters' && (
        <div className="space-y-6">
          {/* Top Actions: Search + Pegar/Cargar Ficha Canónica + Crear Nuevo Personaje */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-[#13151C] p-4 rounded-2xl border border-[#262934]">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 absolute left-3.5 top-3 text-[#6B7280]" />
              <input
                type="text"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                placeholder="Buscar por nombre, raza o rol..."
                className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl pl-10 pr-4 py-2 text-xs text-[#E5E7EB] placeholder-[#6B7280] outline-hidden focus:border-[#D4AF37]"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2.5 w-full sm:w-auto">
              <button
                type="button"
                onClick={() => setShowLoadSheetModal(true)}
                className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#181A22] hover:bg-[#222530] text-[#D4AF37] border border-[#373C4E] hover:border-[#D4AF37] font-bold text-xs shadow-sm cursor-pointer transition-all"
                title="Cargar o pegar una Ficha Canónica (.md o .json) a la biblioteca"
              >
                <FileText className="w-4 h-4 text-[#D4AF37]" />
                <span>Pegar / Cargar Ficha Canónica</span>
              </button>

              <button
                type="button"
                onClick={onCreateNewCharacter}
                className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-yellow-500 hover:from-amber-500 hover:to-yellow-400 text-black font-bold text-xs shadow-md cursor-pointer transition-all"
              >
                <Plus className="w-4 h-4 text-black stroke-[3]" />
                <span>Crear Nuevo Personaje (Taller 3)</span>
              </button>
            </div>
          </div>

          {/* Groups Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredGroups.map(group => {
              const baseChar = group.baseCharacter.state;
              const hasMultipleVariants = group.allEntries.length > 1;
              const name = group.groupName || baseChar.name || 'Sin Nombre';
              const race = baseChar.identity?.race || baseChar.raceName || 'Desconocida';
              const role = baseChar.archetype || baseChar.role || 'Aventurero';
              const sexBase = baseChar.anatomy?.sexBase || '2 Mujer';
              const wardrobeCount = (baseChar.wardrobes || []).length;
              const motivation = baseChar.background?.coreValues || baseChar.background?.motivation || baseChar.personality || 'Explorador del canon';

              return (
                <div
                  key={group.groupId}
                  className="bg-[#13151C] border border-[#262934] hover:border-[#3E4354] rounded-2xl p-5 flex flex-col justify-between space-y-4 shadow-lg transition-all"
                >
                  <div className="space-y-3">
                    {/* Header */}
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-[10px] uppercase font-bold text-[#D4AF37] tracking-wider block">
                            {race}
                          </span>
                          {hasMultipleVariants && (
                            <span className="px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-[#D4AF37] text-[9px] font-bold flex items-center gap-1">
                              <Layers className="w-3 h-3" />
                              {group.allEntries.length} Variantes
                            </span>
                          )}
                        </div>
                        <h3 className="text-base font-bold text-[#F3F4F6] mt-0.5">{name}</h3>
                        <p className="text-xs text-[#8A8F9E]">{role}</p>
                      </div>

                      <span className="px-2 py-0.5 rounded-full bg-[#1A1E29] border border-[#333849] text-[#CBD1DE] text-[9px] font-semibold shrink-0">
                        {sexBase}
                      </span>
                    </div>

                    {/* Canonical Specifications (Clean Lore & Identity Profile) */}
                    <div className="bg-[#181A22] rounded-xl p-3 border border-[#232630] space-y-2 text-xs">
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-[#8A8F9E]">Sexo Base (A.2.1.1):</span>
                        <span className="text-[#D4AF37] font-semibold">{sexBase}</span>
                      </div>
                      <div className="flex items-center justify-between text-[11px] pt-1.5 border-t border-[#232630]">
                        <span className="text-[#8A8F9E]">Vestuarios Registrados:</span>
                        <span className="text-[#CBD1DE] font-medium">{wardrobeCount} prendas</span>
                      </div>
                      <div className="pt-1.5 border-t border-[#232630]">
                        <span className="text-[10px] uppercase font-bold text-[#A0A5B5] block">Valores / Motivación:</span>
                        <p className="text-[11px] text-[#C9A050] italic truncate mt-0.5">
                          «{motivation}»
                        </p>
                      </div>
                    </div>

                    {/* Variants list preview if multi-variant */}
                    {hasMultipleVariants && (
                      <div className="bg-[#161821] rounded-xl p-2.5 border border-[#282B38] space-y-1.5">
                        <div className="flex items-center justify-between text-[10px] text-[#8A8F9E] font-bold uppercase tracking-wider">
                          <span>Variantes almacenadas:</span>
                          <span className="text-[#D4AF37]">{group.allEntries.length} disponibles</span>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {group.allEntries.map(entry => (
                            <span
                              key={entry.id}
                              className="px-2 py-0.5 rounded-md bg-[#222530] text-[10px] font-medium text-[#DCDFE6] border border-[#2E3342]"
                            >
                              {entry.variantLabel || entry.state.variantLabel || 'Base'}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Actions according to single vs multi-variant requirement */}
                  <div className="space-y-2 pt-2 border-t border-[#232630]">
                    {hasMultipleVariants ? (
                      /* Multi-variant character: Primary action is to select among variants */
                      <div className="space-y-2">
                        <button
                          type="button"
                          onClick={() => setSelectedGroupForVariants(group)}
                          className="w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-600 to-yellow-500 hover:from-amber-500 hover:to-yellow-400 text-black font-bold text-xs shadow-sm cursor-pointer transition-all"
                        >
                          <Layers className="w-4 h-4 text-black" />
                          <span>Seleccionar Variante ({group.allEntries.length})</span>
                        </button>

                        <div className="grid grid-cols-3 gap-1.5">
                          <button
                            type="button"
                            onClick={() => {
                              onSelectCharacterForInteraction(baseChar);
                              onNavigate('interaction');
                            }}
                            className="flex items-center justify-center gap-1 py-1.5 px-1.5 rounded-xl bg-[#1A1C24] hover:bg-[#222632] text-[#E0E0E0] border border-[#2D303C] text-[11px] font-medium cursor-pointer"
                            title="Cargar versión Base directamente"
                          >
                            <Play className="w-3 h-3 text-emerald-400" />
                            <span>Cargar</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => setPreviewSheetCharacter(baseChar)}
                            className="flex items-center justify-center gap-1 py-1.5 px-1.5 rounded-xl bg-[#1A1C24] hover:bg-[#222632] text-[#D4AF37] border border-[#2D303C] text-[11px] font-medium cursor-pointer"
                            title="Ver Ficha Técnica Canónica"
                          >
                            <FileText className="w-3 h-3 text-[#D4AF37]" />
                            <span>Ficha</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => onSelectCharacterForEdit(baseChar, 6)}
                            className="flex items-center justify-center gap-1 py-1.5 px-1.5 rounded-xl bg-[#1A1C24] hover:bg-[#222632] text-amber-300 border border-[#2D303C] text-[11px] font-medium cursor-pointer"
                            title="Abrir en Compilador (Paso 6)"
                          >
                            <Sparkles className="w-3 h-3 text-amber-400" />
                            <span>Compilar</span>
                          </button>
                        </div>

                        <div className="flex items-center justify-between gap-1 pt-1">
                          <button
                            type="button"
                            onClick={() => openVariantModalForCharacter(group.baseCharacter.id, 'select_existing')}
                            className="flex items-center gap-1 text-[11px] text-amber-400 hover:text-amber-300 p-1 cursor-pointer"
                            title="Gestionar, compilar o crear variantes de este personaje"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            <span>+ Variante</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleDeleteCharacter(group.baseCharacter.id, name)}
                            className="flex items-center gap-1 text-[11px] text-rose-400 hover:text-rose-300 p-1 cursor-pointer"
                            title="Eliminar este grupo de personaje"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Eliminar</span>
                          </button>
                        </div>
                      </div>
                    ) : (
                      /* Single variant character: Actions with canonical compilation, sheet viewer and deletion */
                      <div className="space-y-2">
                        <div className="grid grid-cols-3 gap-1.5">
                          <button
                            type="button"
                            onClick={() => {
                              onSelectCharacterForInteraction(baseChar);
                              onNavigate('interaction');
                            }}
                            className="flex items-center justify-center gap-1 py-2 px-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-[11px] cursor-pointer shadow-sm transition-all"
                            title="Cargar personaje para interactuar"
                          >
                            <Play className="w-3.5 h-3.5 fill-current" />
                            <span>Cargar</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => onSelectCharacterForEdit(baseChar, 1)}
                            className="flex items-center justify-center gap-1 py-2 px-1.5 rounded-xl bg-[#1A1C24] hover:bg-[#222632] text-[#D4AF37] border border-[#2D303C] font-bold text-[11px] cursor-pointer transition-all"
                            title="Editar en el Taller de Creación (Paso 1)"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>Editar</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => onSelectCharacterForEdit(baseChar, 6)}
                            className="flex items-center justify-center gap-1 py-2 px-1.5 rounded-xl bg-gradient-to-r from-amber-600/90 to-yellow-600/90 hover:from-amber-500 hover:to-yellow-500 text-black font-bold text-[11px] cursor-pointer transition-all shadow-sm"
                            title="Compilar Ficha Técnica Canónica (Paso 6: Ficha Maestra)"
                          >
                            <Sparkles className="w-3.5 h-3.5 text-black" />
                            <span>Compilar</span>
                          </button>
                        </div>

                        <div className="flex items-center justify-between gap-1 pt-1">
                          <button
                            type="button"
                            onClick={() => setPreviewSheetCharacter(baseChar)}
                            className="flex items-center gap-1 text-[11px] text-[#D4AF37] hover:text-[#F3D59B] p-1.5 cursor-pointer font-medium"
                            title="Ver Ficha Técnica Canónica Completa"
                          >
                            <FileText className="w-3.5 h-3.5" />
                            <span>Ficha Canónica</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleDuplicateCharacter(group.baseCharacter.id)}
                            className="flex items-center gap-1 text-[11px] text-[#8A8F9E] hover:text-[#E0E0E0] p-1.5 cursor-pointer"
                            title="Duplicar ficha de personaje"
                          >
                            <Copy className="w-3.5 h-3.5" />
                            <span>Duplicar</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => openVariantModalForCharacter(group.baseCharacter.id, 'select_existing')}
                            className="flex items-center gap-1 text-[11px] text-amber-400 hover:text-amber-300 p-1.5 cursor-pointer"
                            title="Gestionar, compilar o crear variantes de este personaje"
                          >
                            <GitBranch className="w-3.5 h-3.5" />
                            <span>+ Variante</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleDeleteCharacter(group.baseCharacter.id, name)}
                            className="flex items-center gap-1 text-[11px] text-rose-400 hover:text-rose-300 p-1.5 cursor-pointer"
                            title="Eliminar personaje"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Eliminar</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================
          2. TAB ESCENARIOS Y LUGARES (CON CARGAR, EDITAR, DUPLICAR, ELIMINAR)
         ======================================================== */}
      {activeTab === 'places' && (
        <div className="space-y-6">
          {/* Top Actions: Search + Crear Nuevo Escenario */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-[#13151C] p-4 rounded-2xl border border-[#262934]">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 absolute left-3.5 top-3 text-[#6B7280]" />
              <input
                type="text"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                placeholder="Buscar escenario por nombre o región..."
                className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl pl-10 pr-4 py-2 text-xs text-[#E5E7EB] placeholder-[#6B7280] outline-hidden focus:border-indigo-500"
              />
            </div>

            <button
              type="button"
              onClick={onCreateNewPlace}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md cursor-pointer transition-all"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>Crear Nuevo Escenario (Taller 3)</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {filteredPlaces.map(place => {
              const isActive = activePlaceId === place.id;
              const dangerColors = {
                Seguro: 'bg-emerald-950/70 border-emerald-700 text-emerald-300',
                Neutral: 'bg-blue-950/70 border-blue-700 text-blue-300',
                Disputado: 'bg-amber-950/70 border-amber-700 text-amber-300',
                Hostil: 'bg-rose-950/70 border-rose-700 text-rose-300',
                Mortal: 'bg-purple-950/70 border-purple-700 text-purple-300'
              };

              return (
                <div
                  key={place.id}
                  className={`bg-[#13151C] border rounded-2xl p-5 transition-all flex flex-col justify-between space-y-4 shadow-lg ${
                    isActive ? 'border-indigo-500 bg-[#161823]' : 'border-[#262934] hover:border-[#3A3E4E]'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-[10px] uppercase font-bold text-indigo-400 tracking-wider">
                          {place.region} • {place.environmentType}
                        </span>
                        <h3 className="text-lg font-bold text-[#F3F4F6] mt-0.5">{place.name}</h3>
                      </div>
                      <span className={`px-2.5 py-0.5 rounded-full border text-[10px] font-bold ${dangerColors[place.dangerLevel] || dangerColors.Neutral}`}>
                        {place.dangerLevel}
                      </span>
                    </div>

                    <p className="text-xs text-[#8A8F9E] leading-relaxed">
                      {place.description}
                    </p>

                    <div className="bg-[#181A22] rounded-xl p-3 border border-[#232630] space-y-1.5">
                      <span className="text-[10px] uppercase font-bold text-[#A0A5B5] block">Atmósfera & Puntos Clave:</span>
                      <p className="text-xs text-[#E5E7EB] italic">«{place.atmosphere}»</p>
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        {place.pointsOfInterest.map((poi, idx) => (
                          <span key={idx} className="text-[10px] px-2 py-0.5 rounded-md bg-[#222530] text-[#D4AF37]">
                            • {poi}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* 4 Required Actions: Cargar, Editar, Duplicar, Eliminar */}
                  <div className="space-y-2 pt-3 border-t border-[#232630]">
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => handleLoadPlace(place)}
                        className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                          isActive
                            ? 'bg-emerald-600 text-white shadow-md'
                            : 'bg-indigo-600 hover:bg-indigo-500 text-white'
                        }`}
                      >
                        {isActive ? <Check className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
                        <span>{isActive ? 'Cargado (Activo)' : 'Cargar Escenario'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => onSelectPlaceForEdit(place)}
                        className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-[#1A1C24] hover:bg-[#222632] text-indigo-300 border border-[#2D303C] font-bold text-xs cursor-pointer transition-all"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>Editar</span>
                      </button>
                    </div>

                    <div className="flex items-center justify-between gap-1 pt-1">
                      <button
                        type="button"
                        onClick={() => handleDuplicatePlace(place.id)}
                        className="flex items-center gap-1 text-[11px] text-[#8A8F9E] hover:text-[#E0E0E0] p-1.5 cursor-pointer"
                        title="Duplicar escenario"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        <span>Duplicar</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          const jsonStr = exportSinglePlaceJson(place);
                          const blob = new Blob([jsonStr], { type: 'application/json' });
                          const url = URL.createObjectURL(blob);
                          const a = document.createElement('a');
                          a.href = url;
                          a.download = `${place.name.replace(/\s+/g, '_')}.json`;
                          a.click();
                          URL.revokeObjectURL(url);
                        }}
                        className="flex items-center gap-1 text-[11px] text-[#8A8F9E] hover:text-[#E0E0E0] p-1.5 cursor-pointer"
                        title="Exportar archivo JSON"
                      >
                        <FileDown className="w-3.5 h-3.5" />
                        <span>Exportar</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleDeletePlace(place.id, place.name)}
                        className="flex items-center gap-1 text-[11px] text-rose-400 hover:text-rose-300 p-1.5 cursor-pointer"
                        title="Eliminar lugar"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Eliminar</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================
          3. TAB WORLDBUILDING (LISTADO CON CARGAR, EDITAR, DUPLICAR, ELIMINAR)
         ======================================================== */}
      {activeTab === 'worldbuilding' && (
        <div className="space-y-6">
          {/* Top Actions: Search + Crear Nuevo Worldbuilding */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-[#13151C] p-4 rounded-2xl border border-[#262934]">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 absolute left-3.5 top-3 text-[#6B7280]" />
              <input
                type="text"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                placeholder="Buscar worldbuilding por nombre..."
                className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl pl-10 pr-4 py-2 text-xs text-[#E5E7EB] placeholder-[#6B7280] outline-hidden focus:border-emerald-500"
              />
            </div>

            <button
              type="button"
              onClick={onCreateNewWorldBuilding}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md cursor-pointer transition-all"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>Crear Nuevo Worldbuilding (Taller 3)</span>
            </button>
          </div>

          {/* List of Worldbuilding entries */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {savedWorldList
              .filter(w => !searchTerm || w.worldName.toLowerCase().includes(searchTerm.toLowerCase()))
              .map(world => {
                const isActive = worldConfig.id === world.id || worldConfig.worldName === world.worldName;

                return (
                  <div
                    key={world.id}
                    className={`bg-[#13151C] border rounded-2xl p-5 transition-all flex flex-col justify-between space-y-4 shadow-lg ${
                      isActive ? 'border-emerald-500 bg-[#131A18]' : 'border-[#262934] hover:border-[#3A3E4E]'
                    }`}
                  >
                    <div className="space-y-3">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider">
                              {world.eraOrTone}
                            </span>
                            <span className="text-[10px] px-2 py-0.2 rounded-md bg-[#222530] text-[#D4AF37] border border-[#2C3040]">
                              {world.version || 'v1.0'}
                            </span>
                          </div>
                          <h3 className="text-lg font-bold text-[#F3F4F6] mt-0.5">{world.worldName}</h3>
                        </div>

                        {isActive && (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-700 text-emerald-300 text-[10px] font-bold">
                            Activo
                          </span>
                        )}
                      </div>

                      <div className="bg-[#181A22] rounded-xl p-3 border border-[#232630] space-y-2 text-xs">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="text-[#8A8F9E]">Nivel de Magia:</span>
                          <span className="text-emerald-400 font-bold">{world.magicLevel}</span>
                        </div>
                        <div className="flex items-center justify-between text-[11px] pt-1 border-t border-[#232630]">
                          <span className="text-[#8A8F9E]">Facciones:</span>
                          <span className="text-[#F3F4F6] font-semibold">{world.factions?.length || 0} registradas</span>
                        </div>
                        <div className="flex items-center justify-between text-[11px] pt-1 border-t border-[#232630]">
                          <span className="text-[#8A8F9E]">Leyes vigentes:</span>
                          <span className="text-[#D4AF37] font-semibold">{world.laws?.filter(l => l.isActive).length || 0} activas</span>
                        </div>
                      </div>
                    </div>

                    {/* 4 Required Actions: Cargar, Editar, Duplicar, Eliminar */}
                    <div className="space-y-2 pt-3 border-t border-[#232630]">
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => handleLoadWorld(world)}
                          className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                            isActive
                              ? 'bg-emerald-600 text-white shadow-md'
                              : 'bg-emerald-700 hover:bg-emerald-600 text-white'
                          }`}
                        >
                          {isActive ? <Check className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
                          <span>{isActive ? 'Cargado (Vigente)' : 'Cargar Worldbuilding'}</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => onSelectWorldForEdit(world)}
                          className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-[#1A1C24] hover:bg-[#222632] text-emerald-300 border border-[#2D303C] font-bold text-xs cursor-pointer transition-all"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>Editar</span>
                        </button>
                      </div>

                      <div className="flex items-center justify-between gap-1 pt-1">
                        <button
                          type="button"
                          onClick={() => handleDuplicateWorld(world.id)}
                          className="flex items-center gap-1 text-[11px] text-[#8A8F9E] hover:text-[#E0E0E0] p-1.5 cursor-pointer"
                          title="Duplicar configuración de Worldbuilding"
                        >
                          <Copy className="w-3.5 h-3.5" />
                          <span>Duplicar</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleDeleteWorld(world.id, world.worldName)}
                          className="flex items-center gap-1 text-[11px] text-rose-400 hover:text-rose-300 p-1.5 cursor-pointer"
                          title="Eliminar configuración de worldbuilding"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Eliminar</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>

          {/* Active Laws & Factions quick toggle panel */}
          <div className="bg-[#13151C] border border-[#262934] rounded-2xl p-6 space-y-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-[#D4AF37] flex items-center gap-2">
              <ScrollText className="w-4 h-4" />
              <span>Leyes Activas del Worldbuilding en Uso ({worldConfig.laws.length})</span>
            </h3>
            <p className="text-xs text-[#8A8F9E]">
              Modifican en tiempo real la conducta y respuestas de los Agentes Lite.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {worldConfig.laws.map(law => (
                <div
                  key={law.id}
                  className={`p-3 rounded-xl border flex items-center justify-between gap-3 ${
                    law.isActive ? 'bg-[#181A22] border-emerald-600/50' : 'bg-[#12141A] border-[#222530] opacity-60'
                  }`}
                >
                  <div className="space-y-0.5">
                    <span className="text-xs font-bold text-[#F3F4F6] block">{law.title}</span>
                    <span className="text-[11px] text-emerald-400">{law.modifierDescription}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleToggleLaw(law.id)}
                    className={`px-2.5 py-1 rounded-lg text-[10px] font-bold cursor-pointer shrink-0 ${
                      law.isActive ? 'bg-emerald-600 text-white' : 'bg-[#222530] text-[#8A8F9E]'
                    }`}
                  >
                    {law.isActive ? 'Activa' : 'Pausada'}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          4. TAB BACKUP Y COPIA .JSON
         ======================================================== */}
      {activeTab === 'backup' && (
        <div className="bg-[#13151C] border border-[#262934] rounded-2xl p-6 space-y-6 max-w-3xl">
          <div>
            <h2 className="text-lg font-bold text-[#F3F4F6] flex items-center gap-2">
              <Download className="w-5 h-5 text-rose-400" />
              <span>Copia de Seguridad del Ecosistema Elysium</span>
            </h2>
            <p className="text-xs text-[#8A8F9E] mt-1 leading-relaxed">
              Exporta o importa todos tus personajes (Agentes Lite con sus variantes), escenarios y worldbuildings en un único archivo JSON local. Tus datos nunca salen de tu navegador.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <button
              type="button"
              onClick={handleExportJson}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-yellow-500 hover:from-amber-500 hover:to-yellow-400 text-black font-bold text-xs shadow-md cursor-pointer transition-all"
            >
              <Download className="w-4 h-4 text-black" />
              <span>Descargar Archivo .JSON Completo</span>
            </button>
          </div>

          <div className="pt-4 border-t border-[#232630] space-y-3">
            <label className="text-xs font-bold text-[#D4AF37] block">
              Restaurar / Importar desde Texto JSON:
            </label>
            <textarea
              rows={5}
              value={importJsonText}
              onChange={e => setImportJsonText(e.target.value)}
              placeholder="Pega aquí el contenido JSON exportado previamente..."
              className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl p-3 text-xs text-[#E5E7EB] font-mono outline-hidden focus:border-rose-500"
            />

            {importStatus && (
              <div className={`p-3 rounded-xl text-xs font-bold ${
                importStatus.includes('exitosa')
                  ? 'bg-emerald-950/50 border border-emerald-700 text-emerald-300'
                  : 'bg-rose-950/50 border border-rose-700 text-rose-300'
              }`}>
                {importStatus}
              </div>
            )}

            <button
              type="button"
              onClick={handleImportJson}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-md cursor-pointer transition-all"
            >
              <Upload className="w-4 h-4" />
              <span>Importar y Aplicar al Ecosistema</span>
            </button>
          </div>
        </div>
      )}

      {/* ========================================================
          MODAL: SELECCIÓN ENTRE VARIANTES DE UN MISMO PERSONAJE
         ======================================================== */}
      {selectedGroupForVariants && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-[#13151C] border border-[#3E4354] rounded-3xl max-w-2xl w-full max-h-[85vh] overflow-hidden flex flex-col shadow-2xl animate-in zoom-in-95">
            {/* Modal Header */}
            <div className="p-5 border-b border-[#262934] flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] uppercase font-bold text-[#D4AF37] tracking-wider">
                    Variantes Almacenadas ({selectedGroupForVariants.allEntries.length})
                  </span>
                </div>
                <h2 className="text-xl font-bold text-[#F3F4F6] mt-0.5">
                  «{selectedGroupForVariants.groupName}»
                </h2>
                <p className="text-xs text-[#8A8F9E] mt-0.5">
                  Selecciona la versión a cargar en interacción, editar en el taller 3, duplicar o eliminar.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSelectedGroupForVariants(null)}
                className="p-2 rounded-xl text-[#8A8F9E] hover:text-white hover:bg-[#1E212B] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body: List of Variants with canonical sheet actions and specifications */}
            <div className="p-5 overflow-y-auto space-y-4 flex-1">
              {selectedGroupForVariants.allEntries.map((entry, idx) => {
                const char = entry.state;
                const vLabel = entry.variantLabel || char.variantLabel || (idx === 0 ? 'Base' : 'Variante');
                const vRole = char.archetype || char.role || 'Aventurero';
                const vSexBase = char.anatomy?.sexBase || '2 Mujer';
                const vWardrobes = (char.wardrobes || []).length;
                const vMotivation = char.background?.coreValues || char.background?.motivation || char.personality || 'Explorador del canon';

                return (
                  <div
                    key={entry.id}
                    className="bg-[#181A22] border border-[#282B38] hover:border-[#3E4354] rounded-2xl p-4 space-y-3 transition-all shadow-md"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="px-2.5 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-[#D4AF37] text-[10px] font-bold">
                            {vLabel}
                          </span>
                          <span className="text-xs text-[#8A8F9E]">• {vRole}</span>
                        </div>
                        <h4 className="text-base font-bold text-[#F3F4F6] mt-1">{char.name || selectedGroupForVariants.groupName}</h4>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <span className="px-2.5 py-1 rounded-full bg-[#1F232E] border border-[#333849] text-[#CBD1DE] text-[10px] font-semibold">
                          {vSexBase}
                        </span>
                        <span className="px-2 py-1 rounded-md bg-[#161821] text-[10px] text-[#A0A5B5] border border-[#262934]">
                          {vWardrobes} prendas
                        </span>
                      </div>
                    </div>

                    <p className="text-xs text-[#A0A5B5] italic bg-[#13151C] p-2.5 rounded-xl border border-[#222530]">
                      «{vMotivation}»
                    </p>

                    {/* Canonical Actions for this Variant */}
                    <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 pt-2 border-t border-[#232630]">
                      {/* 1. Cargar */}
                      <button
                        type="button"
                        onClick={() => {
                          onSelectCharacterForInteraction(char);
                          setSelectedGroupForVariants(null);
                          onNavigate('interaction');
                        }}
                        className="flex items-center justify-center gap-1 py-2 px-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs cursor-pointer shadow-sm"
                        title="Cargar variante para interactuar"
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>Cargar</span>
                      </button>

                      {/* 2. Editar */}
                      <button
                        type="button"
                        onClick={() => {
                          onSelectCharacterForEdit(char, 1);
                          setSelectedGroupForVariants(null);
                          onNavigate('creation');
                        }}
                        className="flex items-center justify-center gap-1 py-2 px-2 rounded-xl bg-[#1F232E] hover:bg-[#282D3B] text-[#D4AF37] border border-[#3A3F50] font-bold text-xs cursor-pointer"
                        title="Editar variante en el taller (Paso 1)"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>Editar</span>
                      </button>

                      {/* 3. Compilar */}
                      <button
                        type="button"
                        onClick={() => {
                          onSelectCharacterForEdit(char, 6);
                          setSelectedGroupForVariants(null);
                          onNavigate('creation');
                        }}
                        className="flex items-center justify-center gap-1 py-2 px-2 rounded-xl bg-gradient-to-r from-amber-600/90 to-yellow-600/90 hover:from-amber-500 hover:to-yellow-500 text-black font-bold text-xs cursor-pointer shadow-sm"
                        title="Abrir y compilar en Ficha Maestra (Paso 6)"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-black" />
                        <span>Compilar</span>
                      </button>

                      {/* 4. Ficha Canónica */}
                      <button
                        type="button"
                        onClick={() => setPreviewSheetCharacter(char)}
                        className="flex items-center justify-center gap-1 py-2 px-2 rounded-xl bg-[#161821] hover:bg-[#20232E] text-[#D4AF37] border border-[#2E3342] font-semibold text-xs cursor-pointer"
                        title="Ver Ficha Técnica Canónica"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>Ficha</span>
                      </button>

                      {/* 5. Duplicar */}
                      <button
                        type="button"
                        onClick={() => {
                          handleDuplicateCharacter(entry.id);
                        }}
                        className="flex items-center justify-center gap-1 py-2 px-2 rounded-xl bg-[#1A1C24] hover:bg-[#222632] text-[#E0E0E0] border border-[#2D303C] font-semibold text-xs cursor-pointer"
                        title="Duplicar variante"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        <span>Duplicar</span>
                      </button>

                      {/* 6. Desvincular si hay más de 1 miembro */}
                      {selectedGroupForVariants.allEntries.length > 1 && (
                        <button
                          type="button"
                          onClick={() => {
                            unlinkCharacterFromVariantGroup(entry.id);
                            refreshData();
                            const updatedGroups = getCharacterVariantGroups(getSavedCharacters());
                            const currentGroup = updatedGroups.find(g => g.groupId === selectedGroupForVariants.groupId);
                            setSelectedGroupForVariants(currentGroup || null);
                            showNotice(`«${char.name || vLabel}» ha sido desvinculado del grupo.`);
                          }}
                          className="flex items-center justify-center gap-1 py-2 px-2 rounded-xl bg-[#181A22] hover:bg-[#222532] text-amber-300/90 hover:text-amber-200 border border-[#2D303C] font-semibold text-xs cursor-pointer"
                          title="Desvincular del grupo (volver personaje independiente en la biblioteca)"
                        >
                          <GitBranch className="w-3.5 h-3.5" />
                          <span>Desvincular</span>
                        </button>
                      )}

                      {/* 7. Eliminar */}
                      <button
                        type="button"
                        onClick={() => handleDeleteCharacter(entry.id, char.name || vLabel)}
                        className="flex items-center justify-center gap-1 py-2 px-2 rounded-xl bg-rose-950/40 hover:bg-rose-900/50 text-rose-300 border border-rose-800/50 font-semibold text-xs cursor-pointer"
                        title="Eliminar esta variante"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Eliminar</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-[#262934] bg-[#111217] flex items-center justify-between">
              <button
                type="button"
                onClick={() => {
                  openVariantModalForCharacter(selectedGroupForVariants.baseCharacter.id, 'select_existing');
                  setSelectedGroupForVariants(null);
                }}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-[#D4AF37] border border-amber-500/30 text-xs font-bold cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>+ Variantes de {selectedGroupForVariants.groupName} (Juntar o Crear)</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedGroupForVariants(null)}
                className="px-4 py-2 rounded-xl bg-[#1E212B] text-[#E0E0E0] hover:bg-[#272B38] text-xs font-semibold cursor-pointer"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          MODAL: GESTOR Y COMPILADOR DE VARIANTES DE UN PERSONAJE
         ======================================================== */}
      {variantModalTargetCharId && (() => {
        const targetEntry = characters.find(c => c.id === variantModalTargetCharId);
        const targetChar = targetEntry?.state;
        const targetGroupId = targetEntry?.variantGroupId || targetChar?.variantGroupId;
        const targetName = targetChar?.identity?.fullName || targetChar?.name || 'Personaje Base';

        // Candidates: other characters in library not in this character's variant group
        const candidateCharacters = characters.filter(c => {
          if (c.id === variantModalTargetCharId) return false;
          if (targetGroupId && (c.variantGroupId === targetGroupId || c.state?.variantGroupId === targetGroupId)) {
            return false;
          }
          return true;
        });

        const filteredCandidates = candidateCharacters.filter(c => {
          if (!candidateSearchTerm.trim()) return true;
          const q = candidateSearchTerm.toLowerCase();
          const name = (c.state?.identity?.fullName || c.state?.name || '').toLowerCase();
          const race = (c.state?.identity?.race || c.state?.raceName || '').toLowerCase();
          const role = (c.state?.archetype || c.state?.role || '').toLowerCase();
          return name.includes(q) || race.includes(q) || role.includes(q);
        });

        const toggleCandidate = (charId: string) => {
          setSelectedCandidateIds(prev => {
            if (prev.includes(charId)) {
              return prev.filter(id => id !== charId);
            } else {
              // Set default label if not set
              if (!candidateVariantLabels[charId]) {
                const found = candidateCharacters.find(c => c.id === charId);
                const defaultLabel = found?.variantLabel || found?.state?.variantLabel || 'Variante Alterna';
                setCandidateVariantLabels(v => ({ ...v, [charId]: defaultLabel }));
              }
              return [...prev, charId];
            }
          });
        };

        const selectAllFiltered = () => {
          const idsToAdd = filteredCandidates.map(c => c.id);
          setSelectedCandidateIds(prev => Array.from(new Set([...prev, ...idsToAdd])));
          // Initialize labels for all
          setCandidateVariantLabels(prev => {
            const next = { ...prev };
            filteredCandidates.forEach(c => {
              if (!next[c.id]) {
                next[c.id] = c.variantLabel || c.state?.variantLabel || 'Variante Alterna';
              }
            });
            return next;
          });
        };

        const clearSelection = () => {
          setSelectedCandidateIds([]);
        };

        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xs animate-in fade-in">
            <div className="bg-[#111319] border border-[#3E4354] rounded-3xl max-w-2xl w-full max-h-[92vh] flex flex-col shadow-2xl animate-in zoom-in-95 overflow-hidden">
              {/* Header */}
              <div className="p-5 border-b border-[#262934] flex items-center justify-between bg-[#151720]">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-[#D4AF37]">
                    <GitBranch className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] uppercase font-bold text-[#D4AF37] tracking-wider">
                        Compilación de Variantes Canónicas
                      </span>
                      {targetChar?.archetype && (
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#1F232E] border border-[#333846] text-[#CBD1DE]">
                          {targetChar.archetype}
                        </span>
                      )}
                    </div>
                    <h2 className="text-lg font-bold text-[#F3F4F6] mt-0.5">
                      Variantes de «{targetName}»
                    </h2>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setVariantModalTargetCharId(null)}
                  className="p-1.5 rounded-xl text-[#8A8F9E] hover:text-white hover:bg-[#1E212B] cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Tabs Bar */}
              <div className="flex items-center border-b border-[#262934] bg-[#13151D] px-5 pt-3 gap-2">
                <button
                  type="button"
                  onClick={() => setVariantModalTab('select_existing')}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs font-bold transition-all border-b-2 cursor-pointer ${
                    variantModalTab === 'select_existing'
                      ? 'border-[#D4AF37] text-[#D4AF37] bg-[#181A24]'
                      : 'border-transparent text-[#8A8F9E] hover:text-[#DCDFE6] hover:bg-[#161822]'
                  }`}
                >
                  <Users className="w-4 h-4" />
                  <span>Seleccionar de la Biblioteca</span>
                  <span className="px-1.5 py-0.2 rounded-full bg-amber-500/20 text-[#D4AF37] text-[10px]">
                    {candidateCharacters.length}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setVariantModalTab('create_new')}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs font-bold transition-all border-b-2 cursor-pointer ${
                    variantModalTab === 'create_new'
                      ? 'border-[#D4AF37] text-[#D4AF37] bg-[#181A24]'
                      : 'border-transparent text-[#8A8F9E] hover:text-[#DCDFE6] hover:bg-[#161822]'
                  }`}
                >
                  <Sparkles className="w-4 h-4" />
                  <span>+ Forjar Nueva Variante</span>
                </button>
              </div>

              {/* Tab Body */}
              {variantModalTab === 'select_existing' ? (
                <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-[#0D0E13]">
                  {/* Explanatory Banner */}
                  <div className="p-3.5 rounded-2xl bg-[#161822] border border-[#272B3B] text-xs text-[#CBD1DE] flex items-start gap-3">
                    <Link2 className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                    <div>
                      <span className="font-semibold text-white block">
                        Juntar personajes existentes como variantes de «{targetName}»
                      </span>
                      <p className="text-[11px] text-[#8A8F9E] mt-0.5 leading-relaxed">
                        Selecciona otros personajes de la Biblioteca Central para compilarlos dentro del mismo grupo de variantes. Compartirán la ficha canónica con pestañas de versiones y reflejos existenciales mutuos.
                      </p>
                    </div>
                  </div>

                  {/* Search and Quick Filters */}
                  <div className="flex flex-wrap items-center justify-between gap-2.5">
                    <div className="relative flex-1 min-w-[220px]">
                      <Search className="absolute left-3 top-2.5 w-4 h-4 text-[#6B7280]" />
                      <input
                        type="text"
                        value={candidateSearchTerm}
                        onChange={e => setCandidateSearchTerm(e.target.value)}
                        placeholder="Buscar en la biblioteca por nombre, rol o raza..."
                        className="w-full pl-9 pr-8 py-2 rounded-xl bg-[#14161F] border border-[#2B2F3E] text-xs text-[#F3F4F6] placeholder-[#6B7280] focus:outline-none focus:border-[#D4AF37]"
                      />
                      {candidateSearchTerm && (
                        <button
                          type="button"
                          onClick={() => setCandidateSearchTerm('')}
                          className="absolute right-2.5 top-2.5 text-[#8A8F9E] hover:text-white"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>

                    {candidateCharacters.length > 0 && (
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={selectAllFiltered}
                          className="px-2.5 py-1.5 rounded-xl bg-[#1A1C26] hover:bg-[#222634] text-[#DCDFE6] border border-[#2D3142] text-[11px] font-semibold cursor-pointer transition-all"
                        >
                          Seleccionar visibles ({filteredCandidates.length})
                        </button>
                        {selectedCandidateIds.length > 0 && (
                          <button
                            type="button"
                            onClick={clearSelection}
                            className="px-2.5 py-1.5 rounded-xl bg-[#1A1C26] hover:bg-[#222634] text-rose-300 border border-rose-900/50 text-[11px] font-semibold cursor-pointer transition-all"
                          >
                            Limpiar ({selectedCandidateIds.length})
                          </button>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Candidates List */}
                  {candidateCharacters.length === 0 ? (
                    <div className="py-12 px-4 text-center rounded-2xl bg-[#12141C] border border-[#222532]">
                      <Users className="w-10 h-10 text-[#4B5263] mx-auto mb-2" />
                      <h4 className="text-sm font-bold text-[#E0E0E0]">No hay otros personajes disponibles</h4>
                      <p className="text-xs text-[#8A8F9E] mt-1 max-w-md mx-auto">
                        Actualmente no hay más personajes independientes en la Biblioteca Central. Puedes forjar una nueva variante en la pestaña adyacente o crear otro personaje en el taller.
                      </p>
                    </div>
                  ) : filteredCandidates.length === 0 ? (
                    <div className="py-10 px-4 text-center rounded-2xl bg-[#12141C] border border-[#222532]">
                      <Search className="w-8 h-8 text-[#4B5263] mx-auto mb-2" />
                      <h4 className="text-xs font-bold text-[#E0E0E0]">Sin resultados para «{candidateSearchTerm}»</h4>
                      <p className="text-[11px] text-[#8A8F9E] mt-1">
                        Intenta con otro término o limpia el buscador.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-2.5 max-h-[340px] overflow-y-auto pr-1">
                      {filteredCandidates.map(candidate => {
                        const isSelected = selectedCandidateIds.includes(candidate.id);
                        const cChar = candidate.state;
                        const cName = cChar?.identity?.fullName || cChar?.name || 'Sin Nombre';
                        const cRace = cChar?.identity?.race || cChar?.raceName || 'Desconocida';
                        const cRole = cChar?.archetype || cChar?.role || 'Canon';
                        const currentLabel = candidateVariantLabels[candidate.id] || candidate.variantLabel || 'Variante Alterna';

                        return (
                          <div
                            key={candidate.id}
                            className={`p-3.5 rounded-2xl border transition-all ${
                              isSelected
                                ? 'bg-[#171A24] border-[#D4AF37]/60 shadow-lg'
                                : 'bg-[#13151D] border-[#222530] hover:border-[#353949]'
                            }`}
                          >
                            <div className="flex items-center justify-between gap-3">
                              {/* Left: Checkbox + Avatar + Basic Details */}
                              <div
                                onClick={() => toggleCandidate(candidate.id)}
                                className="flex items-center gap-3 cursor-pointer select-none flex-1 min-w-0"
                              >
                                <div
                                  className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-all shrink-0 ${
                                    isSelected
                                      ? 'bg-[#D4AF37] border-[#D4AF37] text-black'
                                      : 'border-[#4B5263] bg-[#1A1C24]'
                                  }`}
                                >
                                  {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                                </div>

                                <div className="w-9 h-9 rounded-xl bg-[#1C1F2B] border border-[#2D3140] overflow-hidden flex items-center justify-center shrink-0">
                                  {candidate.thumbnailUrl ? (
                                    <img
                                      src={candidate.thumbnailUrl}
                                      alt={cName}
                                      className="w-full h-full object-cover"
                                      referrerPolicy="no-referrer"
                                    />
                                  ) : (
                                    <span className="text-xs font-bold text-[#D4AF37]">
                                      {cName.charAt(0).toUpperCase()}
                                    </span>
                                  )}
                                </div>

                                <div className="min-w-0 flex-1">
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <h4 className="text-xs font-bold text-[#F3F4F6] truncate">
                                      {cName}
                                    </h4>
                                    <span className="text-[10px] px-2 py-0.2 rounded-md bg-[#1B1E28] border border-[#2C303E] text-[#CBD1DE]">
                                      {cRole}
                                    </span>
                                    <span className="text-[10px] text-[#8A8F9E]">
                                      {cRace}
                                    </span>
                                  </div>
                                  {candidate.variantGroupId && candidate.variantGroupId !== targetGroupId && (
                                    <span className="text-[10px] text-amber-400/90 flex items-center gap-1 mt-0.5">
                                      <GitBranch className="w-3 h-3" />
                                      Actualmente en otro grupo (se trasladará aquí)
                                    </span>
                                  )}
                                </div>
                              </div>

                              {/* Right: Badge or Toggle action */}
                              <button
                                type="button"
                                onClick={() => toggleCandidate(candidate.id)}
                                className={`px-2.5 py-1 rounded-xl text-[11px] font-bold cursor-pointer transition-all ${
                                  isSelected
                                    ? 'bg-amber-500/20 text-[#D4AF37] border border-amber-500/40'
                                    : 'bg-[#1E212D] text-[#A0A5B5] hover:text-white border border-[#2D3140]'
                                }`}
                              >
                                {isSelected ? 'Seleccionado' : 'Seleccionar'}
                              </button>
                            </div>

                            {/* When Selected: Label configuration row */}
                            {isSelected && (
                              <div className="mt-3 pt-3 border-t border-[#262A38] space-y-2 animate-in fade-in">
                                <div className="flex items-center justify-between">
                                  <span className="text-[11px] font-semibold text-[#CBD1DE]">
                                    Clasificación de esta variante:
                                  </span>
                                  <span className="text-[10px] text-[#8A8F9E]">
                                    Etiqueta que aparecerá en la ficha
                                  </span>
                                </div>

                                <div className="flex flex-wrap items-center gap-1.5">
                                  {[
                                    'Rol/Vestuario',
                                    'Pasado',
                                    'Futuro',
                                    'Variante Alterna'
                                  ].map(lbl => (
                                    <button
                                      key={lbl}
                                      type="button"
                                      onClick={() =>
                                        setCandidateVariantLabels(prev => ({ ...prev, [candidate.id]: lbl }))
                                      }
                                      className={`px-2.5 py-1 rounded-lg text-[10px] font-semibold transition-all cursor-pointer ${
                                        currentLabel === lbl
                                          ? 'bg-[#D4AF37] text-black font-bold'
                                          : 'bg-[#1E212D] text-[#C4C9D6] hover:bg-[#282C3C] border border-[#2D3140]'
                                      }`}
                                    >
                                      {lbl}
                                    </button>
                                  ))}
                                </div>

                                {/* Custom Label Input */}
                                <div className="flex items-center gap-2 pt-1">
                                  <span className="text-[10px] text-[#8A8F9E] shrink-0">Personalizada:</span>
                                  <input
                                    type="text"
                                    value={currentLabel}
                                    onChange={e =>
                                      setCandidateVariantLabels(prev => ({
                                        ...prev,
                                        [candidate.id]: e.target.value
                                      }))
                                    }
                                    placeholder="Ej. Armadura Carmesí, Archiduque, etc."
                                    className="flex-1 px-2.5 py-1 rounded-lg bg-[#111218] border border-[#2C303E] text-xs text-[#F3F4F6] focus:outline-none focus:border-[#D4AF37]"
                                  />
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Reciprocal Relationships Option */}
                  {selectedCandidateIds.length > 0 && (
                    <div
                      onClick={() => setAutoLinkCanonicalRelationships(prev => !prev)}
                      className="p-3 rounded-2xl bg-[#151722] border border-[#272B3C] flex items-center gap-3 cursor-pointer select-none"
                    >
                      <div
                        className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-all shrink-0 ${
                          autoLinkCanonicalRelationships
                            ? 'bg-[#D4AF37] border-[#D4AF37] text-black'
                            : 'border-[#4B5263] bg-[#1A1C24]'
                        }`}
                      >
                        {autoLinkCanonicalRelationships && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                      </div>
                      <div>
                        <span className="text-xs font-bold text-[#F3F4F6] block">
                          Generar vínculos y relaciones canónicas recíprocas (Estado 5.1)
                        </span>
                        <span className="text-[11px] text-[#8A8F9E]">
                          Genera automáticamente perspectivas y lazos mutuos en el trasfondo canónico entre «{targetName}» y las variantes compiladas.
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                /* Tab 2: Create New Variant Flow */
                <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-[#0D0E13]">
                  <p className="text-xs text-[#8A8F9E]">
                    Elige el tipo de variante para bifurcar a partir de «{targetName}». Se creará una nueva entidad vinculada al grupo con relaciones recíprocas:
                  </p>

                  <div className="grid grid-cols-1 gap-2.5">
                    {[
                      {
                        type: 'Rol/Vestuario' as const,
                        title: 'Rol / Vestuario de Combate',
                        desc: 'Versión especializada (ej. armadura de guerra, hábito ritual o vestimenta civil).'
                      },
                      {
                        type: 'Pasado' as const,
                        title: 'Línea Temporal: Pasado / Orígenes',
                        desc: 'Versión más joven, aprendiz o antes del evento desencadenante.'
                      },
                      {
                        type: 'Futuro' as const,
                        title: 'Línea Temporal: Futuro / Veterano/a',
                        desc: 'Versión madura, matriarca, comandante o con mayor poder místico.'
                      },
                      {
                        type: 'Personalizada' as const,
                        title: 'Variante Libre Personalizada',
                        desc: 'Bifurcación alterna sin restricciones narrativas prefijadas.'
                      }
                    ].map(opt => (
                      <button
                        key={opt.type}
                        type="button"
                        onClick={() => handleCreateVariant(variantModalTargetCharId, opt.type)}
                        className="flex flex-col text-left p-3.5 rounded-2xl bg-[#14161F] hover:bg-[#1C1F2B] border border-[#252836] hover:border-[#D4AF37]/50 transition-all cursor-pointer group"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-[#F3F4F6] group-hover:text-[#D4AF37]">
                            {opt.title}
                          </span>
                          <ArrowRight className="w-3.5 h-3.5 text-[#6B7280] group-hover:text-[#D4AF37] transition-all" />
                        </div>
                        <span className="text-[11px] text-[#8A8F9E] mt-1">{opt.desc}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Modal Footer */}
              <div className="p-4 border-t border-[#262934] bg-[#111217] flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => setVariantModalTargetCharId(null)}
                  className="px-4 py-2 rounded-xl bg-[#1E212B] text-[#E0E0E0] hover:bg-[#272B38] text-xs font-semibold cursor-pointer transition-all"
                >
                  Cancelar
                </button>

                {variantModalTab === 'select_existing' ? (
                  <button
                    type="button"
                    onClick={() => handleCompileExistingVariants(variantModalTargetCharId)}
                    disabled={selectedCandidateIds.length === 0}
                    className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold transition-all shadow-md ${
                      selectedCandidateIds.length > 0
                        ? 'bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-black cursor-pointer shadow-amber-500/10'
                        : 'bg-[#1C1E26] text-[#6B7280] border border-[#2B2E3C] cursor-not-allowed'
                    }`}
                  >
                    <Link2 className="w-4 h-4" />
                    <span>
                      Compilar y Juntar como Variantes ({selectedCandidateIds.length})
                    </span>
                  </button>
                ) : (
                  <span className="text-xs text-[#8A8F9E]">
                    Selecciona una opción arriba para crear
                  </span>
                )}
              </div>
            </div>
          </div>
        );
      })()}

      {/* ========================================================
          MODAL: CONFIRMACIÓN DE ELIMINACIÓN NO BLOQUEANTE
         ======================================================== */}
      {deleteConfirmTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-in fade-in">
          <div className="bg-[#13151C] border border-rose-900/50 rounded-3xl max-w-md w-full p-6 shadow-2xl animate-in zoom-in-95 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-rose-950/60 border border-rose-800 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5 text-rose-400" />
              </div>
              <div>
                <h3 className="text-base font-bold text-[#F3F4F6]">Confirmar Eliminación</h3>
                <span className="text-xs text-rose-400 font-medium">Esta acción no se puede deshacer</span>
              </div>
            </div>

            <p className="text-xs text-[#A0A5B5] leading-relaxed">
              ¿Estás seguro de que deseas eliminar permanentemente a{' '}
              <strong className="text-[#F3F4F6]">«{deleteConfirmTarget.name}»</strong>{' '}
              {deleteConfirmTarget.type === 'character' && 'de la biblioteca central?'}
              {deleteConfirmTarget.type === 'place' && 'de los escenarios registrados?'}
              {deleteConfirmTarget.type === 'world' && 'de los mundos del ecosistema?'}
            </p>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#232630]">
              <button
                type="button"
                onClick={() => setDeleteConfirmTarget(null)}
                className="px-4 py-2 rounded-xl bg-[#1E212B] hover:bg-[#282D3B] text-[#E0E0E0] text-xs font-semibold cursor-pointer transition-all"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleExecuteDelete}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-md cursor-pointer transition-all"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Eliminar Definitivamente</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          MODAL: VISOR Y EXPORTADOR DE FICHA TÉCNICA CANÓNICA
         ======================================================== */}
      {previewSheetCharacter && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xs animate-in fade-in">
          <div className="bg-[#111319] border border-[#3E4354] rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl animate-in zoom-in-95 overflow-hidden">
            {/* Header */}
            <div className="p-5 border-b border-[#262934] flex items-center justify-between bg-[#151720]">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-[#D4AF37]">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] uppercase font-bold text-[#D4AF37] tracking-wider">
                      Ficha Técnica Canónica
                    </span>
                    {previewSheetCharacter.anatomy?.sexBase && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#1F232E] border border-[#333846] text-[#CBD1DE]">
                        {previewSheetCharacter.anatomy.sexBase}
                      </span>
                    )}
                  </div>
                  <h2 className="text-lg font-bold text-[#F3F4F6] mt-0.5">
                    «{previewSheetCharacter.name || 'Sin Nombre'}»
                  </h2>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const charId = previewSheetCharacter.id;
                    setPreviewSheetCharacter(null);
                    openVariantModalForCharacter(charId, 'select_existing');
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-[#D4AF37] border border-amber-500/30 text-xs font-bold cursor-pointer transition-all"
                  title="Gestionar, compilar o crear variantes para este personaje"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Variantes</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const sheetText = generateCharacterSheetText(previewSheetCharacter);
                    navigator.clipboard.writeText(sheetText);
                    setSheetCopied(true);
                    setTimeout(() => setSheetCopied(false), 2500);
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#1C1F2A] hover:bg-[#252938] text-xs font-bold text-[#D4AF37] border border-[#3A3F50] cursor-pointer transition-all"
                >
                  {sheetCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{sheetCopied ? '¡Copiada!' : 'Copiar Ficha'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const sheetText = generateCharacterSheetText(previewSheetCharacter);
                    const blob = new Blob([sheetText], { type: 'text/markdown;charset=utf-8' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `${(previewSheetCharacter.name || 'Personaje').replace(/\s+/g, '_')}_Ficha_Canonico.md`;
                    a.click();
                    URL.revokeObjectURL(url);
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#1C1F2A] hover:bg-[#252938] text-xs font-bold text-[#E0E0E0] border border-[#3A3F50] cursor-pointer transition-all"
                  title="Descargar archivo Markdown"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>.MD</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const jsonStr = JSON.stringify(previewSheetCharacter, null, 2);
                    const blob = new Blob([jsonStr], { type: 'application/json' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `${(previewSheetCharacter.name || 'Personaje').replace(/\s+/g, '_')}.json`;
                    a.click();
                    URL.revokeObjectURL(url);
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#1C1F2A] hover:bg-[#252938] text-xs font-bold text-[#E0E0E0] border border-[#3A3F50] cursor-pointer transition-all"
                  title="Descargar archivo JSON"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>.JSON</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPreviewSheetCharacter(null)}
                  className="p-1.5 rounded-xl text-[#8A8F9E] hover:text-white hover:bg-[#1E212B] cursor-pointer ml-2"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Body: Scrollable Sheet */}
            <div className="p-6 overflow-y-auto flex-1 bg-[#0D0E13] select-text">
              <pre className="whitespace-pre-wrap font-mono text-xs bg-[#13151D] p-5 rounded-2xl border border-[#222530] text-[#DCDFE6] leading-relaxed selection:bg-[#D4AF37] selection:text-black">
                {generateCharacterSheetText(previewSheetCharacter)}
              </pre>
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-[#262934] bg-[#111217] flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    onSelectCharacterForEdit(previewSheetCharacter, 6);
                    setPreviewSheetCharacter(null);
                    onNavigate('creation');
                  }}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-amber-600 to-yellow-500 hover:from-amber-500 hover:to-yellow-400 text-black text-xs font-bold shadow-md cursor-pointer transition-all"
                >
                  <Sparkles className="w-4 h-4 text-black" />
                  <span>Cargar en Compilador (Paso 6: Ficha Maestra)</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    onSelectCharacterForEdit(previewSheetCharacter, 1);
                    setPreviewSheetCharacter(null);
                    onNavigate('creation');
                  }}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#1E212B] hover:bg-[#282D3B] text-[#D4AF37] border border-[#3A3F50] text-xs font-bold cursor-pointer transition-all"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Editar en Taller (Paso 1)</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const charId = previewSheetCharacter.id;
                    setPreviewSheetCharacter(null);
                    openVariantModalForCharacter(charId, 'select_existing');
                  }}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-[#D4AF37] border border-amber-500/30 text-xs font-bold cursor-pointer transition-all"
                  title="Gestionar, compilar o crear variantes de este personaje"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Variantes</span>
                </button>
              </div>

              <button
                type="button"
                onClick={() => setPreviewSheetCharacter(null)}
                className="px-4 py-2 rounded-xl bg-[#1E212B] text-[#E0E0E0] hover:bg-[#272B38] text-xs font-semibold cursor-pointer"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          MODAL: CARGAR / PEGAR FICHA CANÓNICA A LA BIBLIOTECA
         ======================================================== */}
      <LoadCharacterSheetModal
        isOpen={showLoadSheetModal}
        onClose={() => setShowLoadSheetModal(false)}
        initialTab="paste"
        onLoadCharacter={(loadedChar) => {
          saveCharacterToLibrary(loadedChar);
          refreshData();
          setShowLoadSheetModal(false);
          showNotice(`Ficha de «${loadedChar.name || 'Personaje'}» importada a la biblioteca.`, 'Compilar', () => {
            onSelectCharacterForEdit(loadedChar, 6);
            onNavigate('creation');
          });
        }}
      />
    </div>
  );
};
