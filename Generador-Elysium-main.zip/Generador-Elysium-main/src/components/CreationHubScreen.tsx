import React from 'react';
import {
  CharacterState,
  MainScreen,
  WorldPlace,
  WorldBuildingConfig
} from '../types';
import { PlaceMasterSheetEditor } from './PlaceMasterSheetEditor';
import { WorldbuildingMasterSheetEditor } from './WorldbuildingMasterSheetEditor';
import {
  Wand2,
  Users,
  MapPin,
  ScrollText,
  ArrowLeft,
  Sparkles,
  BookMarked
} from 'lucide-react';

export type CreationTargetType = 'character' | 'places' | 'worldbuilding';

interface CreationHubScreenProps {
  onNavigate: (screen: MainScreen) => void;
  creationTarget: CreationTargetType;
  onSetCreationTarget: (target: CreationTargetType) => void;
  characterState: CharacterState;
  onUpdateCharacter: (newState: CharacterState) => void;
  editingPlace?: WorldPlace | null;
  onPlaceSaved?: (place: WorldPlace) => void;
  editingWorldConfig?: WorldBuildingConfig | null;
  onWorldConfigSaved?: (config: WorldBuildingConfig) => void;
  renderGuidedCharacterWizard: () => React.ReactNode;
}

export const CreationHubScreen: React.FC<CreationHubScreenProps> = ({
  onNavigate,
  creationTarget,
  onSetCreationTarget,
  characterState,
  onUpdateCharacter,
  editingPlace,
  onPlaceSaved,
  editingWorldConfig,
  onWorldConfigSaved,
  renderGuidedCharacterWizard
}) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Top Navigation & Context Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[#232630] pb-6">
        <div className="space-y-1">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => onNavigate('library')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#161822] hover:bg-[#1E2230] text-[#D4AF37] border border-[#2D3142] text-xs font-bold transition-all cursor-pointer shadow-sm group"
              title="Regresar a la Biblioteca Central"
            >
              <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-0.5 transition-transform" />
              <span>← Volver a 2. Biblioteca</span>
            </button>

            <div className="h-4 w-px bg-[#262934]" />

            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-[#D4AF37]">
                <Wand2 className="w-3.5 h-3.5" />
              </div>
              <h1 className="text-xl font-serif italic text-[#F3F4F6]">
                3. Taller de Creación
              </h1>
            </div>
          </div>

          <p className="text-xs text-[#8A8F9E] pl-1">
            {creationTarget === 'character' && (
              <span>Editor de Personaje desplegado: Modela identidad, anatomía, vestuario, armadura, historia y Agente Lite.</span>
            )}
            {creationTarget === 'places' && (
              <span>Editor de Escenario desplegado: Modela identidad espacial, arquitectura, ecosistema, vivienda y puntos clave.</span>
            )}
            {creationTarget === 'worldbuilding' && (
              <span>Editor de Worldbuilding desplegado: Modela cosmología, leyes físicas y mágicas, facciones y reglas del mundo.</span>
            )}
          </p>
        </div>

        {/* 3 Main Target Switchers (Allows changing active editor) */}
        <div className="flex items-center gap-1.5 bg-[#12141A] p-1.5 rounded-2xl border border-[#262934] shrink-0">
          <button
            type="button"
            onClick={() => onSetCreationTarget('character')}
            className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              creationTarget === 'character'
                ? 'bg-[#1C1F28] text-[#D4AF37] border border-[#3A3F4E] shadow-sm'
                : 'text-[#8A8F9E] hover:text-[#E0E0E0]'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Personaje</span>
          </button>

          <button
            type="button"
            onClick={() => onSetCreationTarget('places')}
            className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              creationTarget === 'places'
                ? 'bg-[#1C1F28] text-indigo-400 border border-[#3A3F4E] shadow-sm'
                : 'text-[#8A8F9E] hover:text-[#E0E0E0]'
            }`}
          >
            <MapPin className="w-4 h-4" />
            <span>Escenario</span>
          </button>

          <button
            type="button"
            onClick={() => onSetCreationTarget('worldbuilding')}
            className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              creationTarget === 'worldbuilding'
                ? 'bg-[#1C1F28] text-emerald-400 border border-[#3A3F4E] shadow-sm'
                : 'text-[#8A8F9E] hover:text-[#E0E0E0]'
            }`}
          >
            <ScrollText className="w-4 h-4" />
            <span>Worldbuilding</span>
          </button>
        </div>
      </div>

      {/* ========================================================
          BRANCH 1: CREACIÓN DE PERSONAJE (FICHA MAESTRA / ASISTENTE)
          Se despliega SOLO si creationTarget === 'character'
         ======================================================== */}
      {creationTarget === 'character' && (
        <div className="bg-[#13151C] border border-[#262934] rounded-2xl p-6 shadow-xl">
          {renderGuidedCharacterWizard()}
        </div>
      )}

      {/* ========================================================
          BRANCH 2: FICHA MAESTRA DE ESCENARIO Y VIVIENDA (LUGAR)
          Se despliega SOLO si creationTarget === 'places'
         ======================================================== */}
      {creationTarget === 'places' && (
        <div className="space-y-4">
          <PlaceMasterSheetEditor
            initialPlace={editingPlace}
            onPlaceSaved={onPlaceSaved}
          />
        </div>
      )}

      {/* ========================================================
          BRANCH 3: WORLDBUILDING (REGLAS DEL MUNDO)
          Se despliega SOLO si creationTarget === 'worldbuilding'
         ======================================================== */}
      {creationTarget === 'worldbuilding' && (
        <div className="space-y-4">
          <WorldbuildingMasterSheetEditor
            initialConfig={editingWorldConfig}
            onSaved={onWorldConfigSaved}
            onBackToLibrary={() => onNavigate('library')}
          />
        </div>
      )}
    </div>
  );
};
