import React from 'react';
import { StyleThematicSection } from '../style/StyleThematicSection';
import { CharacterState } from '../../types';

interface OrientalFantasySectionProps {
  state: CharacterState;
  setState: React.Dispatch<React.SetStateAction<CharacterState>>;
  triggerFeedback?: (msg: string) => void;
}

export const OrientalFantasySection: React.FC<OrientalFantasySectionProps> = (props) => {
  return <StyleThematicSection {...props} />;
};

export default OrientalFantasySection;
