import React, { useState } from 'react';
import { CharacterState } from '../types';
import {
  FileText,
  Copy,
  Check,
  Sparkles,
  ArrowLeft,
  ArrowRight,
  Palette,
  Wand2,
  Terminal,
  Layers,
  Download,
  Upload,
  Shield,
  User,
  Eye,
  Shirt,
  Sword,
  Gem,
  Bookmark,
  RotateCcw,
  BookMarked,
  CheckCircle,
  AlertTriangle,
  Crown,
  ExternalLink,
  Edit3,
  FileCode,
  FileUp,
  Flame,
  Brain,
  Zap
} from 'lucide-react';
import {
  generateCharacterSheetText,
  getCompiledPromptString,
  hasValidArmorProtection,
  resolveColorName,
  cleanVal,
  isRoleNull,
  isStyleNull,
  formatHairLength,
  formatMarkDescription,
  formatLocationSpan
} from '../utils/characterPromptUtils';
import { BODY_SENSITIVITIES } from '../data/nsfwData';
import { saveCharacterToLibrary } from '../utils/libraryStorage';
import { LoadCharacterSheetModal } from './LoadCharacterSheetModal';
import { CharacterAITrainingPanel } from './CharacterAITrainingPanel';

interface State7Props {
  state: CharacterState;
  setState: React.Dispatch<React.SetStateAction<CharacterState>>;
  onBack: () => void;
  onNext?: () => void;
  onFinish?: () => void;
  onNavigateToState?: (stateNum: number) => void;
  onResetCharacter?: () => void;
}

export const State7Compilation: React.FC<State7Props> = ({
  state,
  setState,
  onBack,
  onNext,
  onFinish,
  onNavigateToState,
  onResetCharacter
}) => {
  const [activeTab, setActiveTab] = useState<'sheet' | 'visual' | 'prompt' | 'fullPrompt' | 'aiTraining'>('sheet');
  const [copiedType, setCopiedType] = useState<string | null>(null);
  const [saveSuccessMessage, setSaveSuccessMessage] = useState<string | null>(null);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [showLoadModal, setShowLoadModal] = useState(false);
  const [loadModalInitialTab, setLoadModalInitialTab] = useState<'paste' | 'file' | 'library' | 'seeds'>('paste');

  const isRoleCivil = isRoleNull(state.role);
  const isStyleGeneric = isStyleNull(state.styleVisual);
  const isNoneOutfit = !state.armor?.type || /^ninguna?$/i.test(state.armor.type) || isRoleCivil;

  const characterSheet = generateCharacterSheetText(state);
  const compactPrompt = getCompiledPromptString(state);
  const fullAiPrompt = `[contemporary anime digital illustration, manhwa visual novel aesthetic, otome gacha character art, fine variable linework, thicker outer silhouette contour, soft inner lines, low to moderate color saturation, muted palette, clean silhouette, 4k resolution, sharp focus.]\n+\n[${compactPrompt}]\n+\n[photorealistic, western comic style, hyperrealistic anatomy, heavy black clothing outlines, 3D render, oversaturated colors, noisy texture, blurry, low resolution, western cartoon, low quality, blurry, deformed hands, deformed feet, bad anatomy, extra limbs, watermark, logo, ugly, disfigured, poor lighting, oversaturated, grainy]`;

  const handleCopy = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopiedType(type);
    setTimeout(() => setCopiedType(null), 2000);
  };

  const handleDownloadSheet = () => {
    const filename = `${(state.name || 'personaje').toLowerCase().replace(/\s+/g, '_')}_ficha_tecnica.md`;
    const blob = new Blob([characterSheet], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleDownloadJson = () => {
    const filename = `${(state.name || 'personaje').toLowerCase().replace(/\s+/g, '_')}_ficha_canonica.json`;
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleSaveToLibrary = () => {
    const savedEntry = saveCharacterToLibrary(state);
    setState(prev => ({
      ...prev,
      id: savedEntry.id
    }));
    setSaveSuccessMessage(`¡Personaje "${savedEntry.state.name || 'Sin Nombre'}" guardado con éxito en la Biblioteca!`);
    setTimeout(() => setSaveSuccessMessage(null), 4000);
  };

  const handleLoadCharacterSheet = (loadedState: CharacterState) => {
    setState(loadedState);
    setSaveSuccessMessage(`¡Ficha técnica de "${loadedState.name || 'Personaje'}" cargada con éxito!`);
    setTimeout(() => setSaveSuccessMessage(null), 4500);
  };

  const handleConfirmReset = () => {
    if (onResetCharacter) {
      onResetCharacter();
    }
    setShowResetConfirm(false);
  };

  // Filter items
  const validWardrobes = (state.wardrobes || []).filter(w => Boolean(cleanVal(w.name, false)));
  const wardrobeCount = validWardrobes.length;

  const validRolePieces = isRoleCivil
    ? []
    : (state.armor?.pieces || []).filter(rawPiece => {
        const cleanName = cleanVal(rawPiece.replace(/^P\d+\.?\d*\s*/, '').replace(/^P-Custom:\s*/, ''), false);
        return Boolean(cleanName);
      });
  const rolePiecesCount = validRolePieces.length;

  const validWeapons = (state.equipment?.weapons || []).filter(w => Boolean(cleanVal(w, false)));
  const validBags = (state.equipment?.bags || []).filter(b => Boolean(cleanVal(b, false)));
  const validItems = (state.equipment?.items || []).filter(i => Boolean(cleanVal(i, false)));
  const weaponsCount = validWeapons.length + validBags.length + validItems.length;

  const tokenDescriptorsCount = compactPrompt ? compactPrompt.split(',').length : 0;
  const of = state.orientalFantasy;

  // Intimate Anatomy checks (2.6 R+18)
  const hasIntimateAnatomy = Boolean(
    state.nsfw?.isNsfwEnabled ||
    state.nsfw?.areolaColor ||
    state.nsfw?.areolaSize ||
    state.nsfw?.nippleType ||
    state.nsfw?.pubicHairStyle ||
    state.nsfw?.genitalType ||
    state.nsfw?.genitalSize ||
    (Array.isArray(state.nsfw?.genitalDetails) ? state.nsfw.genitalDetails.length > 0 : Boolean(state.nsfw?.genitalDetails)) ||
    (state.nsfw?.bodySensitivities && state.nsfw.bodySensitivities.length > 0) ||
    state.nsfw?.intimatePersonality
  );

  const rawGDetails = state.nsfw?.genitalDetails;
  const gDetailsList: string[] = Array.isArray(rawGDetails)
    ? rawGDetails.map(d => cleanVal(d, false)).filter(Boolean)
    : (typeof rawGDetails === 'string' && cleanVal(rawGDetails, false) ? [cleanVal(rawGDetails, false)] : []);

  const rawSens = state.nsfw?.bodySensitivities || [];
  const resolvedSensitivities = rawSens.map(idOrName => {
    const found = BODY_SENSITIVITIES.find(b => b.id === idOrName || b.name === idOrName);
    return found ? found.name : cleanVal(idOrName, false);
  }).filter(Boolean);

  const validTraits = (state.personalityTraits || []).map(t => cleanVal(t, false)).filter(Boolean);
  const basePers = cleanVal(state.personality, false);
  const combinedPersList: string[] = [];
  if (validTraits.length > 0) {
    if (basePers && !validTraits.some(t => t.toLowerCase() === basePers.toLowerCase())) {
      combinedPersList.push(basePers);
    }
    combinedPersList.push(...validTraits);
  } else if (basePers) {
    combinedPersList.push(basePers);
  }
  const personalityDisplay = combinedPersList.join(', ');

  const validMarks = (state.appendices?.markTypes || []).map(m => {
    const shape = (state.appendices?.markShapes || {})[m];
    const color = (state.appendices?.markColors || {})[m];
    const secondaryColor = (state.appendices?.markSecondaryColors || {})[m];
    const locs = ((state.appendices?.markLocations || {})[m] || []).map(formatLocationSpan).filter(Boolean);
    const text = state.appendices?.markTexts?.[m];
    const emblemConfig = state.appendices?.markEmblemConfigs?.[m];
    const finish = state.appendices?.markFinishes?.[m];
    return formatMarkDescription(m, shape, color, locs, false, text, emblemConfig, finish, secondaryColor);
  }).filter(Boolean);

  const hornsForm = cleanVal(state.appendices?.hornsForm, false);
  const wingsType = cleanVal(state.appendices?.wingsType, false);
  const tailsType = cleanVal(state.appendices?.tailsType, false);
  const hasAppendices = Boolean(hornsForm || wingsType || tailsType);

  const hasMakeup = Boolean(
    state.makeup && (
      (state.makeup.lipstickStyle && !/labios naturales|ningun/i.test(state.makeup.lipstickStyle)) ||
      (state.makeup.blushStyle && !/ningun/i.test(state.makeup.blushStyle)) ||
      (state.makeup.nailStyle && !/u[ñn]as naturales|ningun/i.test(state.makeup.nailStyle)) ||
      (state.makeup.eyeshadowStyle && !/natural|ningun/i.test(state.makeup.eyeshadowStyle)) ||
      (state.makeup.eyelinerStyle && !/ningun/i.test(state.makeup.eyelinerStyle)) ||
      (state.makeup.faceAccent && !/ningun/i.test(state.makeup.faceAccent))
    )
  );

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      {/* Toast Save Notification */}
      {saveSuccessMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#0F1115] border border-[#C9A050] text-[#E0E0E0] px-5 py-3.5 rounded-2xl shadow-2xl flex items-center space-x-3 animate-fade-in">
          <CheckCircle className="w-5 h-5 text-[#C9A050]" />
          <div>
            <span className="text-sm font-bold block text-[#C9A050]">¡Guardado Exitoso!</span>
            <span className="text-xs text-[#CCCCCC]">{saveSuccessMessage}</span>
          </div>
          {onNavigateToState && (
            <button
              onClick={() => onNavigateToState(0)}
              className="ml-3 px-3 py-1 bg-[#1A1C22] hover:bg-[#C9A050] hover:text-[#0A0B0E] border border-[#C9A050] rounded-xl text-xs font-semibold transition-colors cursor-pointer"
            >
              Ver en Biblioteca
            </button>
          )}
        </div>
      )}

      {/* Hero Header with Save & Reset Controls */}
      <div className="bg-[#0F1115] border border-[#222222] rounded-3xl p-8 text-[#E0E0E0] shadow-xl mb-8 relative">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-[#1A1C22] border border-[#2A2D35] text-[#C9A050] text-xs font-medium">
            <FileText className="w-3.5 h-3.5 text-[#C9A050]" />
            <span>ESTADO 6: FICHA TÉCNICA, GUARDADO & PROMPT CANÓNICO</span>
          </div>

          {/* Action Header Buttons: Cargar, Guardar & Reiniciar */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => {
                setLoadModalInitialTab('paste');
                setShowLoadModal(true);
              }}
              className="bg-[#1A1C22] hover:bg-[#252830] border border-[#C9A050] text-[#C9A050] px-4 py-2.5 rounded-xl font-bold text-xs flex items-center space-x-1.5 transition-all shadow-sm cursor-pointer"
              title="Pegar ficha técnica o JSON para mapear en los estados"
            >
              <FileText className="w-4 h-4 text-[#C9A050]" />
              <span>📋 Pegar Ficha o JSON</span>
            </button>

            <button
              onClick={() => {
                setLoadModalInitialTab('file');
                setShowLoadModal(true);
              }}
              className="bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050] text-[#E0E0E0] px-4 py-2.5 rounded-xl font-semibold text-xs flex items-center space-x-1.5 transition-all shadow-sm cursor-pointer"
              title="Cargar archivo .md o .json de ficha técnica"
            >
              <FileUp className="w-4 h-4 text-[#C9A050]" />
              <span>📁 Cargar Archivo (.md / .json)</span>
            </button>

            <button
              onClick={handleSaveToLibrary}
              className="bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] px-5 py-2.5 rounded-xl font-bold text-xs flex items-center space-x-2 transition-all shadow-md cursor-pointer"
              title="Guardar personaje actual en la biblioteca persistente"
            >
              <Bookmark className="w-4 h-4" />
              <span>{state.id ? 'Actualizar en Biblioteca' : 'Guardar en Biblioteca'}</span>
            </button>

            {onNavigateToState && (
              <button
                onClick={() => onNavigateToState(0)}
                className="bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] text-[#C9A050] px-4 py-2.5 rounded-xl font-medium text-xs flex items-center space-x-1.5 transition-all cursor-pointer"
                title="Abrir biblioteca de personajes"
              >
                <BookMarked className="w-4 h-4" />
                <span>Biblioteca (Estado 0)</span>
              </button>
            )}

            <button
              onClick={() => setShowResetConfirm(true)}
              className="bg-[#15171C] hover:bg-red-950/40 border border-[#2A2D35] hover:border-red-500/50 text-[#888888] hover:text-red-400 px-3.5 py-2.5 rounded-xl font-medium text-xs flex items-center space-x-1.5 transition-all cursor-pointer"
              title="Borrar todas las selecciones y reiniciar personaje"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reiniciar</span>
            </button>
          </div>
        </div>

        <h2 className="text-3xl font-serif italic text-[#C9A050] tracking-tight mb-2">
          Ficha Técnica & Compilación Canónica
        </h2>
        <p className="text-[#888888] text-sm leading-relaxed mb-6">
          Documentación canónica estructurada y compilación determinista del personaje. Puedes guardar el personaje en tu biblioteca para conservarlo o reutilizarlo en futuras sesiones, hacer cambios de vestuario o reiniciar las selecciones.
        </p>

        {/* Quick Modification Shortcuts */}
        {onNavigateToState && (
          <div className="flex flex-wrap items-center gap-2 mb-6 p-3 bg-[#15171C] rounded-2xl border border-[#2A2D35]">
            <span className="text-xs text-[#888888] font-mono mr-1">Modificar directamente:</span>
            <button
              onClick={() => onNavigateToState(3)}
              className="px-3 py-1 bg-[#0F1115] hover:bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050] text-[#C9A050] rounded-lg text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Shirt className="w-3 h-3" />
              <span>Cambio de Vestuario (Estado 3)</span>
            </button>
            <button
              onClick={() => onNavigateToState(2)}
              className="px-3 py-1 bg-[#0F1115] hover:bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050] text-[#E0E0E0] rounded-lg text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <User className="w-3 h-3" />
              <span>Anatomía & Facial (Estado 2)</span>
            </button>
            {hasIntimateAnatomy && (
              <button
                onClick={() => onNavigateToState(2)}
                className="px-3 py-1 bg-rose-950/40 hover:bg-rose-900/50 border border-rose-500/40 hover:border-rose-400 text-rose-300 rounded-lg text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Flame className="w-3 h-3 text-rose-400" />
                <span>Anatomía Íntima (2.6 R+18)</span>
              </button>
            )}
            <button
              onClick={() => onNavigateToState(5)}
              className="px-3 py-1 bg-[#0F1115] hover:bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050] text-[#E0E0E0] rounded-lg text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Edit3 className="w-3 h-3" />
              <span>Relaciones & Trasfondo (Estado 5)</span>
            </button>
          </div>
        )}

        {/* Quick Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-[#222222]">
          <div className="bg-[#15171C] p-3 rounded-xl border border-[#2A2D35]">
            <span className="text-[10px] text-[#888888] block uppercase font-mono">Rol / Estilo</span>
            <span className="text-xs font-bold text-[#C9A050] truncate block">
              {isRoleCivil ? 'Civil' : state.role}
            </span>
          </div>
          <div className="bg-[#15171C] p-3 rounded-xl border border-[#2A2D35]">
            <span className="text-[10px] text-[#888888] block uppercase font-mono">Prendas de Vestuario</span>
            <span className="text-xs font-bold text-[#E0E0E0]">{wardrobeCount} prendas</span>
          </div>
          <div className="bg-[#15171C] p-3 rounded-xl border border-[#2A2D35]">
            <span className="text-[10px] text-[#888888] block uppercase font-mono">Piezas de Rol / Armadura</span>
            <span className="text-xs font-bold text-[#E0E0E0]">{rolePiecesCount} piezas</span>
          </div>
          <div className="bg-[#15171C] p-3 rounded-xl border border-[#2A2D35]">
            <span className="text-[10px] text-[#888888] block uppercase font-mono">Armas & Bolsas</span>
            <span className="text-xs font-bold text-[#E0E0E0]">{weaponsCount} elementos</span>
          </div>
        </div>
      </div>

      {/* Confirmation Modal for Reset */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#0F1115] border border-red-500/40 rounded-3xl max-w-md w-full p-6 shadow-2xl animate-scale-up">
            <div className="flex items-center space-x-3 mb-4 text-red-400">
              <AlertTriangle className="w-6 h-6" />
              <h3 className="text-lg font-serif italic font-bold">¿Reiniciar todas las selecciones?</h3>
            </div>
            <p className="text-xs text-[#888888] mb-6 leading-relaxed">
              Esta acción borrará todas las selecciones actuales (raza, anatomía, vestuario, equipamiento, trasfondo) y restablecerá el personaje a los valores por defecto.
              {state.id ? ' El personaje guardado en tu biblioteca no se eliminará.' : ' Te recomendamos guardar el personaje en la biblioteca antes si deseas conservarlo.'}
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="px-4 py-2 rounded-xl text-xs font-medium text-[#888888] hover:text-[#E0E0E0] bg-[#15171C] border border-[#2A2D35] cursor-pointer"
              >
                Cancelar
              </button>
              <button
                onClick={handleConfirmReset}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-red-600 hover:bg-red-700 transition-colors cursor-pointer"
              >
                Sí, Reiniciar Todo
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tabs Navigation */}
      <div className="flex flex-wrap gap-2 border-b border-[#222222] pb-4 mb-6 justify-between items-center">
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setActiveTab('sheet')}
            className={`px-4 py-2.5 rounded-xl text-xs font-medium transition-all flex items-center space-x-2 cursor-pointer ${
              activeTab === 'sheet'
                ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-md'
                : 'bg-[#15171C] border border-[#2A2D35] text-[#888888] hover:text-[#E0E0E0] hover:border-[#C9A050]'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Ficha Técnica Completa</span>
          </button>

          <button
            onClick={() => setActiveTab('visual')}
            className={`px-4 py-2.5 rounded-xl text-xs font-medium transition-all flex items-center space-x-2 cursor-pointer ${
              activeTab === 'visual'
                ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-md'
                : 'bg-[#15171C] border border-[#2A2D35] text-[#888888] hover:text-[#E0E0E0] hover:border-[#C9A050]'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Resumen Visual Desglosado</span>
          </button>

          <button
            onClick={() => setActiveTab('prompt')}
            className={`px-4 py-2.5 rounded-xl text-xs font-medium transition-all flex items-center space-x-2 cursor-pointer ${
              activeTab === 'prompt'
                ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-md'
                : 'bg-[#15171C] border border-[#2A2D35] text-[#888888] hover:text-[#E0E0E0] hover:border-[#C9A050]'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>Prompt Compacto</span>
          </button>

          <button
            onClick={() => setActiveTab('fullPrompt')}
            className={`px-4 py-2.5 rounded-xl text-xs font-medium transition-all flex items-center space-x-2 cursor-pointer ${
              activeTab === 'fullPrompt'
                ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-md'
                : 'bg-[#15171C] border border-[#2A2D35] text-[#888888] hover:text-[#E0E0E0] hover:border-[#C9A050]'
            }`}
          >
            <Wand2 className="w-4 h-4" />
            <span>Prompt Completo con Estilo</span>
          </button>

          <button
            onClick={() => setActiveTab('aiTraining')}
            className={`px-4 py-2.5 rounded-xl text-xs font-medium transition-all flex items-center space-x-2 cursor-pointer shadow-md ${
              activeTab === 'aiTraining'
                ? 'bg-gradient-to-r from-[#C9A050] via-amber-400 to-[#C9A050] text-[#0A0B0E] font-extrabold shadow-amber-500/20'
                : 'bg-[#181B22] border border-[#C9A050]/50 text-[#C9A050] hover:text-white hover:bg-[#202430] hover:border-[#C9A050]'
            }`}
          >
            <Brain className="w-4 h-4" />
            <span>🧠 Probar & Entrenar IA</span>
          </button>
        </div>

        {/* Global Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {activeTab === 'sheet' && (
            <>
              <button
                onClick={() => {
                  setLoadModalInitialTab('paste');
                  setShowLoadModal(true);
                }}
                className="bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050] text-[#C9A050] px-3 py-2 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition-all cursor-pointer"
                title="Pegar ficha técnica o JSON y mapear a los estados"
              >
                <FileText className="w-3.5 h-3.5 text-[#C9A050]" />
                <span>📋 Pegar Ficha</span>
              </button>

              <button
                onClick={() => {
                  setLoadModalInitialTab('file');
                  setShowLoadModal(true);
                }}
                className="bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050] text-[#E0E0E0] px-3 py-2 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition-all cursor-pointer"
                title="Cargar archivo .md o .json"
              >
                <FileUp className="w-3.5 h-3.5 text-[#C9A050]" />
                <span>📁 Cargar Archivo</span>
              </button>

              <button
                onClick={handleDownloadJson}
                className="bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050] text-[#E0E0E0] px-3 py-2 rounded-xl text-xs font-medium flex items-center space-x-1.5 transition-all cursor-pointer"
                title="Descargar datos canónicos en formato JSON"
              >
                <Download className="w-3.5 h-3.5 text-[#C9A050]" />
                <span>Exportar .json</span>
              </button>

              <button
                onClick={handleDownloadSheet}
                className="bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050] text-[#E0E0E0] px-3 py-2 rounded-xl text-xs font-medium flex items-center space-x-1.5 transition-all cursor-pointer"
                title="Descargar ficha técnica en formato Markdown (.md)"
              >
                <Download className="w-3.5 h-3.5 text-[#C9A050]" />
                <span>Descargar .md</span>
              </button>
            </>
          )}

          <button
            onClick={() => {
              if (activeTab === 'sheet') handleCopy(characterSheet, 'sheet');
              else if (activeTab === 'prompt') handleCopy(compactPrompt, 'prompt');
              else if (activeTab === 'fullPrompt') handleCopy(fullAiPrompt, 'fullPrompt');
              else handleCopy(characterSheet, 'sheet');
            }}
            className="bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] text-[#C9A050] px-3.5 py-2 rounded-xl text-xs font-medium flex items-center space-x-1.5 transition-all cursor-pointer"
          >
            {copiedType ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">¡Copiado!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copiar Contenido</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Tab Content */}
      <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs">
        {/* Tab 1: Ficha Técnica */}
        {activeTab === 'sheet' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between text-xs text-[#888888]">
              <span>Formato canónico estructurado en Markdown con jerarquía completa y sin atributos vacíos.</span>
              <span className="font-mono text-[#C9A050]">{characterSheet.split('\n').length} líneas</span>
            </div>
            <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-6 font-mono text-xs text-[#E0E0E0] select-all leading-relaxed whitespace-pre-wrap overflow-x-auto max-h-[600px]">
              {characterSheet}
            </div>
          </div>
        )}

        {/* Tab 2: Resumen Visual Desglosado */}
        {activeTab === 'visual' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Identity & Psychological Profile */}
              <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-5 space-y-3">
                <div className="flex items-center space-x-2 text-[#C9A050] font-mono text-xs font-semibold">
                  <User className="w-4 h-4" />
                  <span>IDENTIDAD & PSICOLOGÍA</span>
                </div>
                <div className="space-y-1.5 text-xs text-[#E0E0E0]">
                  <div><span className="text-[#888888]">Nombre:</span> <span className="font-semibold text-[#C9A050]">{state.name || 'Sin Nombre'}</span></div>
                  <div>
                    <span className="text-[#888888]">Raza:</span> {state.raceName || 'Humano'}
                    {state.isHybrid && state.secondaryRaceName && (
                      <span className="text-[#C4B5FD] font-medium ml-1">
                        (Híbrido × {state.secondaryRaceName.split('(')[0].trim()})
                      </span>
                    )}
                  </div>
                  {state.archetype && state.archetype !== 'Genérico' && (
                    <div><span className="text-[#888888]">Arquetipo:</span> {state.archetype}</div>
                  )}
                  {personalityDisplay && (
                    <div><span className="text-[#888888]">Rasgos:</span> {personalityDisplay}</div>
                  )}
                  {state.background?.coreValues && (
                    <div><span className="text-[#888888]">Core de Valores:</span> {state.background.coreValues}</div>
                  )}
                </div>
              </div>

              {/* Anatomy & Morphological Structure */}
              <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-5 space-y-3">
                <div className="flex items-center space-x-2 text-[#C9A050] font-mono text-xs font-semibold">
                  <Eye className="w-4 h-4" />
                  <span>ANATOMÍA & RASGOS FACIALES</span>
                </div>
                <div className="space-y-1.5 text-xs text-[#E0E0E0]">
                  <div><span className="text-[#888888]">Base Sexual & Edad:</span> {state.anatomy.sexBase}, {state.anatomy.age}</div>
                  <div><span className="text-[#888888]">Complexión & Altura:</span> {state.anatomy.complexion}, {state.anatomy.height}</div>
                  <div><span className="text-[#888888]">Ojos:</span> {state.facial.eyeColor} ({state.facial.eyesCategory})</div>
                  <div><span className="text-[#888888]">Cabello:</span> {state.hair.hairColor}, {formatHairLength(state.hair.length)}, {state.hair.cut}</div>
                  {hasMakeup && (
                    <div><span className="text-[#888888]">Cosmética:</span> Activa</div>
                  )}
                </div>
              </div>

              {/* Intimate Anatomy Card (Estado 2.6 R+18) */}
              {hasIntimateAnatomy && (
                <div className="bg-[#15171C] border border-rose-500/30 rounded-xl p-5 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2 text-rose-400 font-mono text-xs font-semibold">
                      <Flame className="w-4 h-4 text-rose-400" />
                      <span>ANATOMÍA ÍNTIMA (2.6 R+18)</span>
                    </div>
                    <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-rose-950/60 border border-rose-600/40 text-rose-300">
                      Modo R+18 Activo
                    </span>
                  </div>
                  <div className="space-y-1.5 text-xs text-[#E0E0E0]">
                    {state.nsfw?.areolaColor && (
                      <div>
                        <span className="text-[#888888]">Areolas:</span>{' '}
                        <span className="text-rose-200">{state.nsfw.areolaColor}</span>
                        {state.nsfw.areolaSize && <span className="text-[#888888]"> ({state.nsfw.areolaSize})</span>}
                      </div>
                    )}
                    {state.nsfw?.nippleType && (
                      <div>
                        <span className="text-[#888888]">Pezones:</span>{' '}
                        <span>{state.nsfw.nippleType}</span>
                      </div>
                    )}
                    {state.nsfw?.pubicHairStyle && (
                      <div>
                        <span className="text-[#888888]">Vello Púbico:</span>{' '}
                        <span>{state.nsfw.pubicHairStyle}</span>
                      </div>
                    )}
                    {state.nsfw?.genitalType && (
                      <div>
                        <span className="text-[#888888]">Genitales:</span>{' '}
                        <span className="text-rose-300 font-semibold">{state.nsfw.genitalType}</span>
                        {state.nsfw.genitalSize && <span className="text-[#888888]"> • {state.nsfw.genitalSize}</span>}
                      </div>
                    )}
                    {gDetailsList.length > 0 && (
                      <div>
                        <span className="text-[#888888]">Acabados Íntimos:</span>{' '}
                        <span className="text-rose-100/90">{gDetailsList.join(', ')}</span>
                      </div>
                    )}
                    {resolvedSensitivities.length > 0 && (
                      <div>
                        <span className="text-[#888888]">Zonas Hipersensibles:</span>{' '}
                        <span className="text-amber-200/90">{resolvedSensitivities.join(', ')}</span>
                      </div>
                    )}
                    {state.nsfw?.intimatePersonality && (
                      <div>
                        <span className="text-[#888888]">Personalidad Íntima:</span>{' '}
                        <span className="italic text-[#CCCCCC]">{state.nsfw.intimatePersonality}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Wardrobe Breakdown */}
              <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-5 space-y-3">
                <div className="flex items-center space-x-2 text-[#C9A050] font-mono text-xs font-semibold">
                  <Shirt className="w-4 h-4" />
                  <span>VESTUARIO ({wardrobeCount} prendas)</span>
                </div>
                {validWardrobes.length === 0 ? (
                  <p className="text-xs text-[#888888] italic">Sin prendas de vestuario configuradas.</p>
                ) : (
                  <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                    {validWardrobes.map((w, idx) => (
                      <div key={w.id || idx} className="bg-[#0F1115] p-2.5 rounded-lg border border-[#222222] text-xs">
                        <div className="font-semibold text-[#C9A050]">{w.name}</div>
                        <div className="text-[11px] text-[#888888]">
                          {w.cut && `Corte ${w.cut}`} {w.material && `• ${w.material}`} {w.color && `• Color ${resolveColorName(w.color)}`}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Role Equipment & Weapons */}
              <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-5 space-y-3">
                <div className="flex items-center space-x-2 text-[#C9A050] font-mono text-xs font-semibold">
                  <Sword className="w-4 h-4" />
                  <span>ROL & EQUIPAMIENTO</span>
                </div>
                <div className="space-y-1.5 text-xs text-[#E0E0E0]">
                  <div>
                    <span className="text-[#888888]">Rol Canónico:</span>{' '}
                    <span className="font-semibold text-[#C9A050]">{isRoleCivil ? 'Civil' : state.role}</span>
                    {state.subRole && !isRoleNull(state.subRole) && state.subRole !== state.role && (
                      <span className="text-cyan-400 font-mono text-[11px] ml-1">
                        + Sub-Rol ({state.subRole})
                      </span>
                    )}
                  </div>
                  {state.nobleTitle && (
                    <div className="flex items-center gap-1.5 bg-[#0F1115] border border-amber-500/30 rounded-md px-2 py-1 text-amber-200">
                      <Crown className="w-3.5 h-3.5 text-[#C9A050] shrink-0" />
                      <div>
                        <span className="text-[10px] text-[#888888] uppercase font-mono block">Título Nobiliario:</span>
                        <span className="font-serif font-bold text-xs text-amber-300">
                          {state.nobleTitle} {state.nobleHouseOrDomain || ''}
                        </span>
                      </div>
                    </div>
                  )}
                  {state.hybridRoleTitle && state.hybridRoleTitle !== state.role && (
                    <div>
                      <span className="text-[#888888]">Rol Híbrido:</span>{' '}
                      <span className="text-amber-300 font-semibold">{state.hybridRoleTitle}</span>
                    </div>
                  )}
                  <div>
                    <span className="text-[#888888]">Estilo Visual:</span>{' '}
                    <span>{isStyleGeneric ? 'Fantasía Tradicional' : state.styleVisual}</span>
                    {state.subStyleVisual && !isStyleNull(state.subStyleVisual) && state.subStyleVisual !== state.styleVisual && (
                      <span className="text-purple-400 font-mono text-[11px] ml-1">
                        + Sub-Estilo ({state.subStyleVisual})
                      </span>
                    )}
                  </div>
                  {state.styleFusionTitle && state.styleFusionTitle !== state.styleVisual && (
                    <div>
                      <span className="text-[#888888]">Fusión Estética:</span>{' '}
                      <span className="text-purple-300 font-semibold">{state.styleFusionTitle}</span>
                    </div>
                  )}
                  {weaponsCount > 0 && (
                    <div><span className="text-[#888888]">Armas / Objetos:</span> {weaponsCount} registrados</div>
                  )}
                  {rolePiecesCount > 0 && (
                    <div><span className="text-[#888888]">Piezas de Rol:</span> {rolePiecesCount} piezas activas</div>
                  )}
                </div>
              </div>

              {/* Background, Relationships & Behavior Tiers */}
              <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-5 space-y-3 md:col-span-2">
                <div className="flex items-center space-x-2 text-[#C9A050] font-mono text-xs font-semibold">
                  <BookMarked className="w-4 h-4" />
                  <span>TRASFONDO, LÍNEA TEMPORAL & COMPORTAMIENTO</span>
                </div>

                {state.background?.narrativeTimeline && (
                  <div className="bg-[#0F1115] border border-[#2A2D35] rounded-xl p-3.5 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-[#C9A050] flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-[#C9A050]" />
                        Línea Temporal & Trayectoria Multiversal
                      </span>
                      {state.background.narrativeTimeline.thematicArc && (
                        <span className="px-2 py-0.5 rounded-full bg-[#1A1C22] border border-[#C9A050]/40 text-[#C9A050] text-[10px] italic">
                          «{state.background.narrativeTimeline.thematicArc}»
                        </span>
                      )}
                    </div>
                    {state.background.narrativeTimeline.overview && (
                      <p className="text-[11px] text-[#CCCCCC] italic leading-relaxed">
                        {state.background.narrativeTimeline.overview}
                      </p>
                    )}
                    {state.background.narrativeTimeline.milestones && state.background.narrativeTimeline.milestones.length > 0 && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 mt-2">
                        {state.background.narrativeTimeline.milestones.map((m, idx) => (
                          <div key={idx} className="p-2.5 rounded-lg bg-[#15171C] border border-[#222222] text-[11px] space-y-1">
                            <div className="flex items-center justify-between text-[10px]">
                              <span className={`px-1.5 py-0.2 rounded font-bold ${
                                m.era === 'Pasado' ? 'bg-blue-950/80 text-blue-400 border border-blue-800/60' :
                                m.era === 'Presente' ? 'bg-amber-950/80 text-amber-300 border border-amber-800/60' :
                                m.era === 'Futuro' ? 'bg-purple-950/80 text-purple-300 border border-purple-800/60' :
                                'bg-emerald-950/80 text-emerald-300 border border-emerald-800/60'
                              }`}>
                                {m.era}
                              </span>
                              <span className="text-[#888888]">{m.periodOrAge}</span>
                            </div>
                            <div className="font-semibold text-[#E0E0E0]">{m.title}</div>
                            <div className="text-[#AAAAAA] text-[10px] line-clamp-2">{m.summary}</div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-[#E0E0E0]">
                  <div className="space-y-2">
                    {state.background?.backstory && (
                      <div>
                        <span className="text-[#888888] block text-[11px]">Historia de Origen:</span>
                        <p className="italic text-[#AAAAAA] line-clamp-3 bg-[#0F1115] p-2 rounded border border-[#222222]">
                          «{state.background.backstory}»
                        </p>
                      </div>
                    )}
                    {state.background?.motivation && (
                      <div>
                        <span className="text-[#888888] block text-[11px]">Motivación:</span>
                        <p className="text-[#E0E0E0]">{state.background.motivation}</p>
                      </div>
                    )}
                    {state.background?.secret && (
                      <div>
                        <span className="text-[#888888] block text-[11px]">Secreto / Carga Oculta:</span>
                        <p className="text-zinc-400 italic text-[11px] bg-[#0F1115] p-2 rounded border border-[#222222]">
                          «{state.background.secret}»
                        </p>
                      </div>
                    )}
                    {state.background?.uniqueDetails && state.background.uniqueDetails.length > 0 && (
                      <div>
                        <span className="text-[#888888] block text-[11px]">Detalles Únicos & Singularidades:</span>
                        <ul className="list-disc list-inside text-zinc-300 space-y-0.5 mt-1 bg-[#0F1115] p-2 rounded border border-[#222222]">
                          {state.background.uniqueDetails.map((detail, dIdx) => (
                            <li key={dIdx} className="text-[11px]">{detail}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                    {state.background?.relationships && state.background.relationships.length > 0 && (
                      <div>
                        <span className="text-[#888888] block text-[11px]">Vínculos Registrados ({state.background.relationships.length}):</span>
                        <div className="space-y-1.5 mt-1">
                          {state.background.relationships.map(rel => (
                            <div key={rel.id} className="bg-[#0F1115] p-2 rounded border border-[#222222] text-[11px]">
                              <div className="flex items-center justify-between text-[#C9A050] font-bold">
                                <span>{rel.targetCharacterName}</span>
                                <span className="font-mono text-[10px] text-[#888888]">{rel.relationshipType}</span>
                              </div>
                              <div className="text-[#AAAAAA] italic">«{rel.interactionDynamic}»</div>
                              {rel.feelingsTowards && (
                                <div className="text-[10px] text-[#C9A050]/90 mt-0.5">❤️ Sentimientos: {rel.feelingsTowards}</div>
                              )}
                              {rel.opinionOn && (
                                <div className="text-[10px] text-blue-300/90 mt-0.5">💭 Opinión: {rel.opinionOn}</div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    {state.background?.advancedCustomization && (
                      <>
                        {state.background.advancedCustomization.voiceTone && (
                          <div><span className="text-[#888888]">Tono de Voz:</span> {state.background.advancedCustomization.voiceTone}</div>
                        )}
                        {state.background.advancedCustomization.speechStyle && (
                          <div><span className="text-[#888888]">Registro de Habla:</span> {state.background.advancedCustomization.speechStyle}</div>
                        )}
                        {state.background.advancedCustomization.skills && state.background.advancedCustomization.skills.length > 0 && (
                          <div>
                            <span className="text-[#888888] block text-[11px]">Habilidades & Talentos:</span>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {state.background.advancedCustomization.skills.map((sk, idx) => (
                                <span key={idx} className="px-2 py-0.5 bg-[#0F1115] border border-[#2A2D35] rounded text-[10px] text-[#E0E0E0]">
                                  {sk}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                        {state.background.advancedCustomization.specificInteractions && (
                          <div>
                            <span className="text-[#888888] block text-[11px]">Trato por Rangos / Tipos de Personaje:</span>
                            <ul className="space-y-1 text-[11px] text-[#AAAAAA] mt-1 bg-[#0F1115] p-2.5 rounded border border-[#222222]">
                              {state.background.advancedCustomization.specificInteractions.withAuthority && (
                                <li><strong className="text-[#C9A050]">Superiores:</strong> {state.background.advancedCustomization.specificInteractions.withAuthority}</li>
                              )}
                              {state.background.advancedCustomization.specificInteractions.withPeers && (
                                <li><strong className="text-[#C9A050]">Compañeros (Pares):</strong> {state.background.advancedCustomization.specificInteractions.withPeers}</li>
                              )}
                              {state.background.advancedCustomization.specificInteractions.withFriends && (
                                <li><strong className="text-[#C9A050]">Amigos / Aliados:</strong> {state.background.advancedCustomization.specificInteractions.withFriends}</li>
                              )}
                              {state.background.advancedCustomization.specificInteractions.withSubordinates && (
                                <li><strong className="text-[#C9A050]">Subordinados:</strong> {state.background.advancedCustomization.specificInteractions.withSubordinates}</li>
                              )}
                              {state.background.advancedCustomization.specificInteractions.withStrangers && (
                                <li><strong className="text-[#C9A050]">Desconocidos:</strong> {state.background.advancedCustomization.specificInteractions.withStrangers}</li>
                              )}
                              {state.background.advancedCustomization.specificInteractions.withEnemies && (
                                <li><strong className="text-[#C9A050]">Enemigos:</strong> {state.background.advancedCustomization.specificInteractions.withEnemies}</li>
                              )}
                            </ul>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Prompt Compacto */}
        {activeTab === 'prompt' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between text-xs text-[#888888]">
              <span>Texto conciso optimizado para modelos de difusión y generación de personajes.</span>
              <span className="font-mono text-[#C9A050]">{tokenDescriptorsCount} descriptores activos</span>
            </div>
            <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-6 text-sm font-mono text-[#C9A050] select-all leading-relaxed whitespace-pre-wrap overflow-x-auto max-h-[550px]">
              {compactPrompt}
            </div>
          </div>
        )}

        {/* Tab 4: Prompt Completo con Estilo */}
        {activeTab === 'fullPrompt' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between text-xs text-[#888888]">
              <span>Prompt enriquecido con directivas de renderizado digital anime/manhwa y negative prompt estricto.</span>
            </div>
            <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-6 text-xs font-mono text-[#E0E0E0] select-all leading-relaxed whitespace-pre-wrap overflow-x-auto max-h-[550px] space-y-4">
              <div>
                <span className="text-[#C9A050] font-bold block mb-1">PROMPT POSITIVO DE ESTILO:</span>
                <p className="text-[#AAAAAA]">[contemporary anime digital illustration, manhwa visual novel aesthetic, otome gacha character art, fine variable linework, thicker outer silhouette contour, soft inner lines, low to moderate color saturation, muted palette, clean silhouette, 4k resolution, sharp focus.]</p>
              </div>
              <div className="pt-3 border-t border-[#222222]">
                <span className="text-[#C9A050] font-bold block mb-1">DESCRIPTORES DEL PERSONAJE:</span>
                <p className="text-[#E0E0E0] bg-[#0F1115] p-3 rounded-lg border border-[#2A2D35] font-mono">[{compactPrompt}]</p>
              </div>
              <div className="pt-3 border-t border-[#222222]">
                <span className="text-red-400 font-bold block mb-1">NEGATIVE PROMPT:</span>
                <p className="text-[#888888]">[photorealistic, western comic style, hyperrealistic anatomy, heavy black clothing outlines, 3D render, oversaturated colors, noisy texture, blurry, low resolution, western cartoon, low quality, blurry, deformed hands, deformed feet, bad anatomy, extra limbs, watermark, logo, ugly, disfigured, poor lighting, oversaturated, grainy]</p>
              </div>
            </div>
          </div>
        )}

        {/* Tab 5: Probar & Entrenar IA */}
        {activeTab === 'aiTraining' && (
          <CharacterAITrainingPanel
            state={state}
            setState={setState}
          />
        )}

      </div>

      {/* Navigation Footer */}
      <div className="mt-10 flex flex-wrap justify-between items-center gap-4">
        <button
          onClick={onBack}
          className="bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] text-[#E0E0E0] px-6 py-3 rounded-xl font-semibold text-sm flex items-center space-x-2 transition-all cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Volver a Antecedentes (Estado 5)</span>
        </button>

        <div className="flex flex-wrap gap-3">
          <button
            onClick={handleSaveToLibrary}
            className="bg-[#1A1C22] hover:bg-[#C9A050] hover:text-[#0A0B0E] border border-[#C9A050] text-[#C9A050] px-5 py-3 rounded-xl font-bold text-sm flex items-center space-x-2 transition-all cursor-pointer"
          >
            <Bookmark className="w-4 h-4" />
            <span>Guardar en Biblioteca</span>
          </button>

          {(onFinish || onNext) && (
            <button
              onClick={onFinish || onNext}
              className="bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] px-6 py-3 rounded-xl font-bold text-sm flex items-center space-x-2 transition-all shadow-md cursor-pointer"
            >
              <CheckCircle className="w-4 h-4" />
              <span>Finalizar & Ir a Interacción</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Load Character Sheet Modal */}
      <LoadCharacterSheetModal
        isOpen={showLoadModal}
        initialTab={loadModalInitialTab}
        onClose={() => setShowLoadModal(false)}
        onLoadCharacter={handleLoadCharacterSheet}
        currentState={state}
        onNavigateToState={onNavigateToState}
      />
    </div>
  );
};
