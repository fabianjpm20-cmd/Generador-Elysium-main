import React from 'react';
import { Type, Sparkles } from 'lucide-react';

interface CalligraphyTextInputProps {
  value?: string;
  onChange: (newText: string) => void;
  label?: string;
  placeholder?: string;
  hint?: string;
  optionContext?: string;
}

const SAMPLE_TEXT_PRESETS = [
  { label: 'Kanjis: Luz y Sombra', text: '光と影' },
  { label: 'Kanjis: Indomable', text: '不撓不屈' },
  { label: 'Kanjis: Alma de Dragón', text: '龍魂' },
  { label: 'Latín: Memento Mori', text: 'Memento Mori' },
  { label: 'Latín: Hacia las estrellas', text: 'Ad Astra Per Aspera' },
  { label: 'Latín: Vencer o Morir', text: 'Vincere Aut Mori' },
  { label: 'Ciberpunk: Neo-Tokyo', text: 'NEO-TOKYO // SEC-09' },
  { label: 'Táctico: Serial Code', text: 'UNIT-07 // OPR-K9' },
  { label: 'Runas: Futhark Arcano', text: '᚛᚛ᚠᚢᚦᚨᚱᚲ᚛᚛' },
  { label: 'Gótico: Invicta', text: 'Semper Invicta' }
];

export const CalligraphyTextInput: React.FC<CalligraphyTextInputProps> = ({
  value = '',
  onChange,
  label = 'Texto / Caracteres Escritos',
  placeholder = "Introduce el texto exacto, kanjis, frase en latín o runas (ej. 'Memento Mori', '光と影', 'NEO-2099')...",
  hint = 'Solo visible al seleccionar caligrafía, texto o tipografía.',
  optionContext
}) => {
  return (
    <div className="bg-[#12141A] border border-[#C9A050]/50 rounded-xl p-3.5 space-y-2.5 animate-fade-in shadow-inner">
      <div className="flex flex-wrap items-center justify-between gap-1.5 pb-1.5 border-b border-[#2A2D35]/60">
        <label className="text-xs font-mono text-[#C9A050] font-bold flex items-center gap-1.5">
          <Type className="w-3.5 h-3.5 text-[#C9A050]" />
          <span>{label}</span>
        </label>
        {optionContext && (
          <span className="text-[10px] text-[#A0A0A0] font-mono bg-[#1A1C22] px-2 py-0.5 rounded border border-[#2A2D35]">
            {optionContext}
          </span>
        )}
      </div>

      <p className="text-[11px] text-[#888888] leading-tight">
        {hint} Define con exactitud las palabras, letras, caracteres orientales o códigos que se inscribirán visualmente.
      </p>

      <div className="space-y-2">
        <input
          type="text"
          value={value}
          onChange={e => onChange(e.target.value)}
          placeholder={placeholder}
          className="w-full bg-[#0A0B0E] border border-[#C9A050]/40 focus:border-[#C9A050] rounded-lg px-3 py-2 text-xs text-[#FFFFFF] placeholder-[#666666] outline-none font-sans transition-colors"
        />

        {/* Quick Inspiration Presets */}
        <div className="space-y-1">
          <div className="flex items-center gap-1 text-[10px] font-mono text-[#888888]">
            <Sparkles className="w-3 h-3 text-[#C9A050]" />
            <span>Ejemplos rápidos para inspirarte o autocompletar:</span>
          </div>
          <div className="flex flex-wrap gap-1">
            {SAMPLE_TEXT_PRESETS.map(preset => {
              const isSelected = value === preset.text;
              return (
                <button
                  key={preset.label}
                  type="button"
                  onClick={() => onChange(preset.text)}
                  className={`px-2 py-0.5 rounded text-[10px] border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#C9A050] text-[#0A0B0E] font-bold border-[#C9A050]'
                      : 'bg-[#1A1C22] text-[#A0A0A0] border-[#2A2D35] hover:border-[#C9A050]/60 hover:text-[#E0E0E0]'
                  }`}
                >
                  {preset.label}
                </button>
              );
            })}
          </div>
        </div>

        {value && (
          <div className="pt-1.5 flex items-center justify-between text-[10px] text-[#A0A0A0] font-mono bg-[#0A0B0E] px-2.5 py-1 rounded border border-[#222222]">
            <span>Texto visual activo:</span>
            <strong className="text-[#C9A050] font-serif italic text-xs tracking-wider">"{value}"</strong>
          </div>
        )}
      </div>
    </div>
  );
};
