import React, { useState } from 'react';
import { Shield, Sparkles, Sliders, Edit3, Check, RefreshCw } from 'lucide-react';
import { EmblemBuilderConfig } from '../../types';

interface LogoSealEmblemBuilderProps {
  config?: EmblemBuilderConfig;
  onChange: (newConfig: EmblemBuilderConfig) => void;
  label?: string;
  hint?: string;
  contextTitle?: string;
}

export const EMBLEM_SYMBOLS = [
  'Águila Imperial Bicéfala Coronada',
  'Dragón Heráldico Alado Rampante',
  'León Real con Corona de Oro',
  'Círculo de Transmutación Alquímica',
  'Pentagrama Sagrado con Runas Celestiales',
  'Símbolo Corporativo Hexagonal con Circuitos',
  'Ojo Místico de la Providencia / Ojo Arcano',
  'Flor de Lis Real Dorada',
  'Rosa de los Vientos / Brújula Astral',
  'Calavera con Huesos / Espadas Cruzadas',
  'Lobo Mitológico Aullando a la Luna',
  'Fénix Resurgente Envuelto en Llamas',
  'Espadas Gemelas Cruzadas con Corona',
  'Árbol Sagrado de la Vida / Yggdrasil',
  'Serpiente Ouroboros Comiéndose la Cola',
  'Ancla Naval con Alas Desplegadas',
  'Sol Radiante con Rostro Alquímico Antiguo',
  'Escorpión Cibernético Mecanizado'
];

export const EMBLEM_FRAMES = [
  'Escudo Gótico Medieval Apuntado',
  'Escudo Francés Heráldico Clásico',
  'Círculo de Sello Arcano con Anillos Concéntricos y Glifos',
  'Sello de Cera Lacrada Oval con Borde Irregular',
  'Pentágono Táctico Militar en Relieve',
  'Diamante / Rombo Heráldico Nobiliario',
  'Insignia Oval Laureada con Marco Metálico',
  'Escudo Español Redondeado con Borde Remachado',
  'Escudo Suizo Clásico con Muesca de Lanza',
  'Hexágono Cyberpunk con Borde Biselado'
];

export const EMBLEM_SUPPORTS = [
  'Ramas de Laurel de Oro Entrelazadas',
  'Corona Imperial Superior con Gemas',
  'Espadas Cruzadas en el Fondo del Escudo',
  'Alas de Ángel Desplegadas Envolventes',
  'Alas de Dragón Membranosas de Soporte',
  'Filigrana Barroca de Oro en Relieve',
  'Cadenas de Hierro y Rosas Perimetrales',
  'Resplandor de Rayos Solares Radiantes',
  'Filamentos de Neón y Glitch Holográfico',
  'Cintas Heráldicas Flotantes en la Base',
  'Sin Adornos / Marco Minimalista Puro'
];

export const EMBLEM_PRESETS: Array<{
  name: string;
  icon: string;
  config: EmblemBuilderConfig;
}> = [
  {
    name: 'Escudo Noble Imperial',
    icon: '🛡️',
    config: {
      symbol: 'Águila Imperial Bicéfala Coronada',
      frame: 'Escudo Gótico Medieval Apuntado',
      motto: 'Semper Invicta // Rex et Patria',
      supportOrnaments: 'Ramas de Laurel de Oro Entrelazadas',
      description: 'Blasón nobiliario con águila bicéfala bordada en hilo de oro sobre fondo carmesí, rodeada de laureles dorados y corona superior.'
    }
  },
  {
    name: 'Sello de Invocación Arcana',
    icon: '✨',
    config: {
      symbol: 'Círculo de Transmutación Alquímica',
      frame: 'Círculo de Sello Arcano con Anillos Concéntricos y Glifos',
      motto: 'Astra Inclinant, Non Necessitant',
      supportOrnaments: 'Resplandor de Rayos Solares Radiantes',
      description: 'Sello mágico circular con doble anillo de runas concéntricas que resplandecen en energía luminosa cian emisiva.'
    }
  },
  {
    name: 'Logotipo Cyberpunk Megacorp',
    icon: '🏢',
    config: {
      symbol: 'Símbolo Corporativo Hexagonal con Circuitos',
      frame: 'Hexágono Cyberpunk con Borde Biselado',
      motto: 'SYNDICATE DYNAMICS // NEO-2099',
      supportOrnaments: 'Filamentos de Neón y Glitch Holográfico',
      description: 'Logotipo corporativo minimalista de líneas geométricas afiladas, grabado en cromo pulido con acentos de luz neón cian y magenta.'
    }
  },
  {
    name: 'Insignia Militar Táctica',
    icon: '⚔️',
    config: {
      symbol: 'Espadas Gemelas Cruzadas con Corona',
      frame: 'Pentágono Táctico Militar en Relieve',
      motto: 'UNIT-01 // NO SURRENDER',
      supportOrnaments: 'Cintas Heráldicas Flotantes en la Base',
      description: 'Parche táctico bordado de alta resistencia con velcro, espadas cruzadas en relieve negro mate sobre fondo verde oliva táctico.'
    }
  },
  {
    name: 'Sello Alquímico Hermético',
    icon: '⚗️',
    config: {
      symbol: 'Sol Radiante con Rostro Alquímico Antiguo',
      frame: 'Sello de Cera Lacrada Oval con Borde Irregular',
      motto: 'Solve et Coagula',
      supportOrnaments: 'Serpiente Ouroboros Comiéndose la Cola',
      description: 'Sello alquímico de cera carmesí profunda con la efigie del sol solar radiante y ouroboros grabado en relieve envejecido.'
    }
  },
  {
    name: 'Calavera / Jolly Roger Corsario',
    icon: '☠️',
    config: {
      symbol: 'Calavera con Huesos / Espadas Cruzadas',
      frame: 'Escudo Francés Heráldico Clásico',
      motto: 'Memento Mori // Libertas',
      supportOrnaments: 'Cadenas de Hierro y Rosas Perimetrales',
      description: 'Emblema oscuro con calavera de marfil detallada y sables cruzados, enmarcado con cadenas oxidadas y rosas negras.'
    }
  }
];

export const LogoSealEmblemBuilder: React.FC<LogoSealEmblemBuilderProps> = ({
  config = {} as EmblemBuilderConfig,
  onChange,
  label = 'Constructor de Logo, Escudo o Sello',
  hint = 'Solo visible al seleccionar opciones de logo, escudo, sello o blasón.',
  contextTitle
}) => {
  const currentConfig: EmblemBuilderConfig = config || {};
  const [activeTab, setActiveTab] = useState<'BUILDER' | 'DESCRIPTION'>('BUILDER');

  const handleUpdate = (field: keyof EmblemBuilderConfig, val: string) => {
    onChange({
      ...currentConfig,
      [field]: val
    });
  };

  const handleApplyPreset = (preset: EmblemBuilderConfig) => {
    onChange({ ...preset });
  };

  const isConfigured = Boolean(
    currentConfig.symbol || currentConfig.frame || currentConfig.motto || currentConfig.supportOrnaments || currentConfig.description
  );

  return (
    <div className="bg-[#101217] border border-[#C9A050]/60 rounded-2xl p-4 sm:p-5 space-y-4 animate-fade-in shadow-xl">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-[#2A2D35]">
        <div className="flex items-center space-x-2">
          <div className="w-7 h-7 rounded-lg bg-[#C9A050]/20 border border-[#C9A050] flex items-center justify-center text-[#C9A050]">
            <Shield className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-[#E0E0E0] uppercase tracking-wide flex items-center gap-1.5">
              <span>{label}</span>
            </h4>
            <p className="text-[10px] text-[#888888]">{hint}</p>
          </div>
        </div>

        {contextTitle && (
          <span className="text-[10px] font-mono text-[#C9A050] bg-[#1A1C22] px-2.5 py-1 rounded-md border border-[#2A2D35]">
            {contextTitle}
          </span>
        )}
      </div>

      {/* Quick Archetype Presets */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between text-[11px] font-mono text-[#888888]">
          <span className="flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-[#C9A050]" />
            <span>Plantillas rápidas de Escudos, Sellos y Logos:</span>
          </span>
          {isConfigured && (
            <button
              type="button"
              onClick={() => onChange({})}
              className="text-[10px] text-[#888888] hover:text-rose-400 cursor-pointer underline"
            >
              Reiniciar configuración
            </button>
          )}
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
          {EMBLEM_PRESETS.map(preset => {
            const isMatch = currentConfig.symbol === preset.config.symbol && currentConfig.frame === preset.config.frame;
            return (
              <button
                key={preset.name}
                type="button"
                onClick={() => handleApplyPreset(preset.config)}
                className={`p-2 rounded-xl text-left text-[11px] transition-all flex items-center justify-between border cursor-pointer ${
                  isMatch
                    ? 'bg-[#C9A050]/20 text-[#C9A050] border-[#C9A050] font-bold shadow-xs'
                    : 'bg-[#15171C] text-[#A0A0A0] border-[#2A2D35] hover:border-[#C9A050]/60 hover:text-[#E0E0E0]'
                }`}
              >
                <div className="flex items-center gap-1.5 truncate">
                  <span className="text-sm shrink-0">{preset.icon}</span>
                  <span className="truncate">{preset.name}</span>
                </div>
                {isMatch && <Check className="w-3 h-3 text-[#C9A050] shrink-0" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* Tabs: Visual Modular Builder vs Written Description */}
      <div className="flex items-center space-x-2 border-b border-[#2A2D35] pt-1">
        <button
          type="button"
          onClick={() => setActiveTab('BUILDER')}
          className={`px-3 py-1.5 text-xs font-mono font-bold transition-all border-b-2 cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'BUILDER'
              ? 'text-[#C9A050] border-[#C9A050]'
              : 'text-[#888888] border-transparent hover:text-[#E0E0E0]'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>1. Construir por Componentes (Figura, Marco, Lema)</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('DESCRIPTION')}
          className={`px-3 py-1.5 text-xs font-mono font-bold transition-all border-b-2 cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'DESCRIPTION'
              ? 'text-[#C9A050] border-[#C9A050]'
              : 'text-[#888888] border-transparent hover:text-[#E0E0E0]'
          }`}
        >
          <Edit3 className="w-3.5 h-3.5" />
          <span>2. Introducir Descripción Escrita Libre</span>
        </button>
      </div>

      {/* TAB 1: MODULAR BUILDER */}
      {activeTab === 'BUILDER' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 animate-fade-in">
          {/* 1. Central Symbol / Figure */}
          <div className="space-y-1.5">
            <label className="block text-[11px] font-mono text-[#C9A050] font-bold">
              1. Figura / Símbolo Central Principal:
            </label>
            <select
              value={currentConfig.symbol || ''}
              onChange={e => handleUpdate('symbol', e.target.value)}
              className="w-full bg-[#15171C] border border-[#2A2D35] focus:border-[#C9A050] rounded-xl p-2 text-xs text-[#E0E0E0] outline-none"
            >
              <option value="">-- Selecciona figura del logo/escudo/sello --</option>
              {EMBLEM_SYMBOLS.map(sym => (
                <option key={sym} value={sym}>{sym}</option>
              ))}
            </select>
            <input
              type="text"
              value={currentConfig.symbol || ''}
              onChange={e => handleUpdate('symbol', e.target.value)}
              placeholder="O escribe un símbolo personalizado (ej. Serpiente con corona de espinas)..."
              className="w-full bg-[#0A0B0E] border border-[#2A2D35] focus:border-[#C9A050] rounded-lg px-2.5 py-1.5 text-[11px] text-[#E0E0E0] placeholder-[#555] outline-none"
            />
          </div>

          {/* 2. Frame / Boundary */}
          <div className="space-y-1.5">
            <label className="block text-[11px] font-mono text-[#C9A050] font-bold">
              2. Forma del Marco / Escudo / Sello:
            </label>
            <select
              value={currentConfig.frame || ''}
              onChange={e => handleUpdate('frame', e.target.value)}
              className="w-full bg-[#15171C] border border-[#2A2D35] focus:border-[#C9A050] rounded-xl p-2 text-xs text-[#E0E0E0] outline-none"
            >
              <option value="">-- Selecciona morfología o marco del blasón --</option>
              {EMBLEM_FRAMES.map(f => (
                <option key={f} value={f}>{f}</option>
              ))}
            </select>
            <input
              type="text"
              value={currentConfig.frame || ''}
              onChange={e => handleUpdate('frame', e.target.value)}
              placeholder="O escribe un marco personalizado (ej. Escudo heráldico en punta de diamante)..."
              className="w-full bg-[#0A0B0E] border border-[#2A2D35] focus:border-[#C9A050] rounded-lg px-2.5 py-1.5 text-[11px] text-[#E0E0E0] placeholder-[#555] outline-none"
            />
          </div>

          {/* 3. Motto / Inscription */}
          <div className="space-y-1.5">
            <label className="block text-[11px] font-mono text-[#C9A050] font-bold">
              3. Lema / Texto / Inscripción Grabada o Bordada:
            </label>
            <input
              type="text"
              value={currentConfig.motto || ''}
              onChange={e => handleUpdate('motto', e.target.value)}
              placeholder="Ej. 'Semper Fidelis', 'Astra Inclinant', 'CYBERDYNE-01', 'Rex Invictus'..."
              className="w-full bg-[#15171C] border border-[#2A2D35] focus:border-[#C9A050] rounded-xl px-3 py-2 text-xs text-[#E0E0E0] placeholder-[#555] outline-none"
            />
          </div>

          {/* 4. Support / Heraldic Ornaments */}
          <div className="space-y-1.5">
            <label className="block text-[11px] font-mono text-[#C9A050] font-bold">
              4. Adornos / Soportes Perimetrales:
            </label>
            <select
              value={currentConfig.supportOrnaments || ''}
              onChange={e => handleUpdate('supportOrnaments', e.target.value)}
              className="w-full bg-[#15171C] border border-[#2A2D35] focus:border-[#C9A050] rounded-xl p-2 text-xs text-[#E0E0E0] outline-none"
            >
              <option value="">-- Selecciona adornos o soportes heráldicos --</option>
              {EMBLEM_SUPPORTS.map(sup => (
                <option key={sup} value={sup}>{sup}</option>
              ))}
            </select>
          </div>
        </div>
      )}

      {/* TAB 2: WRITTEN DESCRIPTION */}
      {activeTab === 'DESCRIPTION' && (
        <div className="space-y-2 animate-fade-in">
          <label className="block text-[11px] font-mono text-[#C9A050] font-bold">
            Descripción Visual Completa de Cómo es el Logo, Sello o Escudo:
          </label>
          <textarea
            value={currentConfig.description || ''}
            onChange={e => handleUpdate('description', e.target.value)}
            rows={3}
            placeholder="Describe con precisión cómo está compuesto el logo/sello/escudo: colores heráldicos, particiones, detalles del bordado o relieve metálico, estética (antiguo, futurista, arcano, desgastado)..."
            className="w-full bg-[#0A0B0E] border border-[#2A2D35] focus:border-[#C9A050] rounded-xl p-3 text-xs text-[#E0E0E0] placeholder-[#666] outline-none transition-colors"
          />
        </div>
      )}

      {/* Active Synthesis Card */}
      {isConfigured && (
        <div className="bg-[#0A0B0E] border border-[#C9A050]/40 rounded-xl p-3 space-y-1.5 text-xs text-[#E0E0E0]">
          <div className="flex items-center justify-between text-[11px] font-mono text-[#C9A050] pb-1 border-b border-[#222222]">
            <span className="flex items-center gap-1 font-bold">
              <Shield className="w-3.5 h-3.5" />
              <span>Configuración Activa del Logo / Escudo / Sello:</span>
            </span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1 text-[11px]">
            {currentConfig.symbol && (
              <div><strong className="text-[#888888]">Figura:</strong> <span className="text-[#C9A050]">{currentConfig.symbol}</span></div>
            )}
            {currentConfig.frame && (
              <div><strong className="text-[#888888]">Marco:</strong> <span>{currentConfig.frame}</span></div>
            )}
            {currentConfig.motto && (
              <div><strong className="text-[#888888]">Lema / Texto:</strong> <span className="text-[#C9A050] font-serif italic">"{currentConfig.motto}"</span></div>
            )}
            {currentConfig.supportOrnaments && (
              <div><strong className="text-[#888888]">Soporte:</strong> <span>{currentConfig.supportOrnaments}</span></div>
            )}
          </div>
          {currentConfig.description && (
            <div className="text-[11px] text-[#A0A0A0] pt-1 border-t border-[#1A1C22]">
              <strong className="text-[#888888]">Descripción:</strong> <em>"{currentConfig.description}"</em>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
