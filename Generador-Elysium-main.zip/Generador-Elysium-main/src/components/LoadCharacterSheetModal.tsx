import React, { useState, useEffect, useMemo } from 'react';
import { CharacterState, SavedCharacterEntry, AppState } from '../types';
import {
  getSavedCharacters,
  saveCharacterToLibrary,
  importLibraryFromJson,
  deleteCharacterFromLibrary,
  PRELOADED_SEED_CHARACTERS
} from '../utils/libraryStorage';
import { parseCharacterData, StateTranslationBreakdown } from '../utils/characterSheetLoader';
import { generateCharacterSheetText } from '../utils/characterPromptUtils';
import {
  Upload,
  Bookmark,
  Sparkles,
  X,
  Check,
  AlertCircle,
  Search,
  User,
  Shield,
  ArrowRight,
  Eye,
  CheckCircle2,
  FileCode,
  FileUp,
  BookMarked,
  Layers,
  Wand2,
  BookOpen,
  ArrowUpRight,
  Sparkle,
  Download,
  Copy,
  Trash2,
  ClipboardPaste,
  FileText
} from 'lucide-react';

export interface LoadCharacterSheetModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoadCharacter: (loadedState: CharacterState) => void;
  currentState?: CharacterState;
  onNavigateToState?: (state: AppState) => void;
  onSaveToLibrary?: (savedEntry: SavedCharacterEntry) => void;
  initialTab?: 'paste' | 'file' | 'library' | 'seeds';
}

export const LoadCharacterSheetModal: React.FC<LoadCharacterSheetModalProps> = ({
  isOpen,
  onClose,
  onLoadCharacter,
  currentState,
  onNavigateToState,
  onSaveToLibrary,
  initialTab = 'paste'
}) => {
  const [activeTab, setActiveTab] = useState<'paste' | 'file' | 'library' | 'seeds'>(initialTab);
  const [savedCharacters, setSavedCharacters] = useState<SavedCharacterEntry[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Paste text state
  const [pasteContent, setPasteContent] = useState('');
  const [batchCountDetected, setBatchCountDetected] = useState<number | null>(null);
  const [parsedPreview, setParsedPreview] = useState<{
    state?: CharacterState;
    format?: string;
    breakdown?: StateTranslationBreakdown;
    error?: string;
  } | null>(null);

  // File upload state
  const [dragActive, setDragActive] = useState(false);
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);
  const [fileParseError, setFileParseError] = useState<string | null>(null);
  const [fileParsedState, setFileParsedState] = useState<CharacterState | null>(null);
  const [fileBreakdown, setFileBreakdown] = useState<StateTranslationBreakdown | null>(null);
  const [fileBatchCount, setFileBatchCount] = useState<number | null>(null);
  const [rawFileContent, setRawFileContent] = useState<string>('');

  // Selected library entry for preview
  const [selectedLibraryId, setSelectedLibraryId] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  useEffect(() => {
    if (isOpen) {
      setActiveTab(initialTab);
      const chars = getSavedCharacters();
      setSavedCharacters(chars);
      if (chars.length > 0) {
        setSelectedLibraryId(chars[0].id);
      }
      setPasteContent('');
      setParsedPreview(null);
      setBatchCountDetected(null);
      setUploadedFileName(null);
      setFileParseError(null);
      setFileParsedState(null);
      setFileBreakdown(null);
      setFileBatchCount(null);
      setRawFileContent('');
    }
  }, [isOpen, initialTab]);

  // Filtered saved library characters
  const filteredLibrary = useMemo(() => {
    if (!searchQuery.trim()) return savedCharacters;
    const q = searchQuery.toLowerCase();
    return savedCharacters.filter(c =>
      c.state.name?.toLowerCase().includes(q) ||
      c.state.raceName?.toLowerCase().includes(q) ||
      c.state.role?.toLowerCase().includes(q) ||
      c.variantLabel?.toLowerCase().includes(q)
    );
  }, [savedCharacters, searchQuery]);

  const selectedLibraryEntry = useMemo(() => {
    return savedCharacters.find(c => c.id === selectedLibraryId) || savedCharacters[0] || null;
  }, [savedCharacters, selectedLibraryId]);

  if (!isOpen) return null;

  // Handle Text / JSON Parsing
  const handleAnalyzePaste = (contentToParse?: string) => {
    const text = (contentToParse !== undefined ? contentToParse : pasteContent).trim();
    if (!text) {
      setParsedPreview({ error: 'Por favor pega el contenido de la ficha técnica o el JSON del personaje.' });
      setBatchCountDetected(null);
      return;
    }

    // Check if pasted content is a JSON array of multiple characters
    if (text.startsWith('[') && text.endsWith(']')) {
      try {
        const parsed = JSON.parse(text);
        if (Array.isArray(parsed) && parsed.length > 1) {
          setBatchCountDetected(parsed.length);
        } else {
          setBatchCountDetected(null);
        }
      } catch (e) {
        setBatchCountDetected(null);
      }
    } else {
      setBatchCountDetected(null);
    }

    const result = parseCharacterData(text);
    if (result.success && result.state) {
      setParsedPreview({
        state: result.state,
        format: result.sourceFormat === 'json' ? 'JSON Estructurado Canónico' : 'Ficha Técnica Markdown / Texto',
        breakdown: result.stateBreakdown
      });
    } else {
      setParsedPreview({ error: result.error || 'No se pudo interpretar el formato proporcionado.' });
    }
  };

  // Handle Clipboard Paste directly via API
  const handlePasteFromClipboard = async () => {
    try {
      if (navigator.clipboard && navigator.clipboard.readText) {
        const text = await navigator.clipboard.readText();
        if (text) {
          setPasteContent(text);
          handleAnalyzePaste(text);
          showToast('¡Texto pegado y analizado automáticamente desde el portapapeles!');
        }
      }
    } catch (e) {
      // Browser permission prompt or fallback
    }
  };

  // Handle File Upload
  const handleFileProcess = (file: File) => {
    setUploadedFileName(file.name);
    setFileParseError(null);
    setFileParsedState(null);
    setFileBreakdown(null);
    setFileBatchCount(null);

    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      if (text) {
        setRawFileContent(text);
        
        // Check for batch JSON
        if (text.trim().startsWith('[') && text.trim().endsWith(']')) {
          try {
            const parsed = JSON.parse(text);
            if (Array.isArray(parsed) && parsed.length > 1) {
              setFileBatchCount(parsed.length);
            }
          } catch (err) {
            // Ignore
          }
        }

        const result = parseCharacterData(text);
        if (result.success && result.state) {
          setFileParsedState(result.state);
          setFileBreakdown(result.stateBreakdown || null);
        } else {
          setFileParseError(result.error || 'Error al procesar el archivo.');
        }
      }
    };
    reader.onerror = () => {
      setFileParseError('Error de lectura del archivo.');
    };
    reader.readAsText(file);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileProcess(e.dataTransfer.files[0]);
    }
  };

  // Apply to active editor state
  const handleApplyState = (targetState: CharacterState, jumpTo?: AppState) => {
    onLoadCharacter(targetState);
    if (jumpTo !== undefined && onNavigateToState) {
      onNavigateToState(jumpTo);
    }
    onClose();
  };

  // Save to Library directly from modal
  const handleSaveToLibraryDirect = (targetState: CharacterState) => {
    const saved = saveCharacterToLibrary(targetState);
    const updated = getSavedCharacters();
    setSavedCharacters(updated);
    if (onSaveToLibrary) {
      onSaveToLibrary(saved);
    }
    showToast(`¡Personaje "${saved.state.name || 'Personaje'}" guardado en la Biblioteca!`);
  };

  // Import batch JSON to Library
  const handleImportBatch = (rawJson: string) => {
    const res = importLibraryFromJson(rawJson);
    if (res.success) {
      const updated = getSavedCharacters();
      setSavedCharacters(updated);
      showToast(`¡Se importaron con éxito ${res.count} personajes a la Biblioteca!`);
      setActiveTab('library');
    } else {
      showToast(`Error: ${res.error}`);
    }
  };

  // Download Character MD
  const handleDownloadSheet = (targetState: CharacterState) => {
    const sheetText = generateCharacterSheetText(targetState);
    const filename = `${(targetState.name || 'personaje').toLowerCase().replace(/\s+/g, '_')}_ficha_tecnica.md`;
    const blob = new Blob([sheetText], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showToast(`Descargando "${filename}"...`);
  };

  // Download Character JSON
  const handleDownloadJson = (targetState: CharacterState) => {
    const filename = `${(targetState.name || 'personaje').toLowerCase().replace(/\s+/g, '_')}_ficha_canonica.json`;
    const blob = new Blob([JSON.stringify(targetState, null, 2)], { type: 'application/json;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showToast(`Descargando "${filename}"...`);
  };

  // Copy Sheet to Clipboard
  const handleCopySheet = (targetState: CharacterState) => {
    const sheetText = generateCharacterSheetText(targetState);
    navigator.clipboard.writeText(sheetText);
    showToast('¡Ficha técnica copiada al portapapeles!');
  };

  // Delete saved entry
  const handleDeleteFromLibrary = (id: string, name: string) => {
    deleteCharacterFromLibrary(id);
    const updated = getSavedCharacters();
    setSavedCharacters(updated);
    if (selectedLibraryId === id) {
      setSelectedLibraryId(updated[0]?.id || null);
    }
    showToast(`Personaje "${name}" eliminado.`);
  };

  // State translation matrix renderer
  const renderStateTranslationMatrix = (breakdown: StateTranslationBreakdown, state: CharacterState) => {
    return (
      <div className="space-y-3 bg-[#0F1115] border border-[#2A2D35] rounded-2xl p-4">
        <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-[#222222]">
          <div className="flex items-center space-x-2">
            <Sparkles className="w-4 h-4 text-[#C9A050]" />
            <span className="text-xs font-bold text-[#C9A050]">
              Matriz de Traducción Canónica en los Estados
            </span>
          </div>
          <span className="text-[10px] text-emerald-400 font-mono bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/50">
            ✓ {breakdown.totalParsedFields} parámetros mapeados
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 text-xs">
          {/* State 1 */}
          <div className="p-3 bg-[#15171C] rounded-xl border border-[#222222] space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-[#E0E0E0] flex items-center gap-1.5 text-[11px]">
                <User className="w-3.5 h-3.5 text-blue-400" />
                <span>1. Raza, Subtipo & Anatomía</span>
              </span>
              {onNavigateToState && (
                <button
                  onClick={() => handleApplyState(state, 1)}
                  className="text-[10px] text-[#C9A050] hover:underline flex items-center gap-0.5 cursor-pointer"
                  title="Cargar e ir directamente a Raza y Anatomía"
                >
                  <span>Abrir Estado 1</span>
                  <ArrowUpRight className="w-3 h-3" />
                </button>
              )}
            </div>
            <div className="text-[10px] text-[#888888] space-y-0.5">
              {breakdown.state1.details.length > 0 ? (
                breakdown.state1.details.slice(0, 4).map((d, i) => (
                  <div key={i} className="truncate text-[#AAAAAA]">✓ {d}</div>
                ))
              ) : (
                <div className="text-[#666666] italic">Valores anatómicos estándar</div>
              )}
            </div>
          </div>

          {/* State 2 */}
          <div className="p-3 bg-[#15171C] rounded-xl border border-[#222222] space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-[#E0E0E0] flex items-center gap-1.5 text-[11px]">
                <Eye className="w-3.5 h-3.5 text-purple-400" />
                <span>2. Rostro, Cabello & Apéndices</span>
              </span>
              {onNavigateToState && (
                <button
                  onClick={() => handleApplyState(state, 2)}
                  className="text-[10px] text-[#C9A050] hover:underline flex items-center gap-0.5 cursor-pointer"
                  title="Cargar e ir directamente a Rostro y Cabello"
                >
                  <span>Abrir Estado 2</span>
                  <ArrowUpRight className="w-3 h-3" />
                </button>
              )}
            </div>
            <div className="text-[10px] text-[#888888] space-y-0.5">
              {breakdown.state2.details.length > 0 ? (
                breakdown.state2.details.slice(0, 4).map((d, i) => (
                  <div key={i} className="truncate text-[#AAAAAA]">✓ {d}</div>
                ))
              ) : (
                <div className="text-[#666666] italic">Configuración facial básica</div>
              )}
            </div>
          </div>

          {/* State 3 */}
          <div className="p-3 bg-[#15171C] rounded-xl border border-[#222222] space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-[#E0E0E0] flex items-center gap-1.5 text-[11px]">
                <Layers className="w-3.5 h-3.5 text-amber-400" />
                <span>3. Vestuario & Atuendos ({breakdown.state3.count})</span>
              </span>
              {onNavigateToState && (
                <button
                  onClick={() => handleApplyState(state, 3)}
                  className="text-[10px] text-[#C9A050] hover:underline flex items-center gap-0.5 cursor-pointer"
                  title="Cargar e ir directamente a Gestión de Vestuarios"
                >
                  <span>Abrir Estado 3</span>
                  <ArrowUpRight className="w-3 h-3" />
                </button>
              )}
            </div>
            <div className="text-[10px] text-[#888888] space-y-0.5">
              {breakdown.state3.details.length > 0 ? (
                breakdown.state3.details.slice(0, 3).map((d, i) => (
                  <div key={i} className="truncate text-[#AAAAAA]">👗 {d}</div>
                ))
              ) : (
                <div className="text-[#666666] italic">Sin prendas personalizadas</div>
              )}
            </div>
          </div>

          {/* State 4 */}
          <div className="p-3 bg-[#15171C] rounded-xl border border-[#222222] space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-[#E0E0E0] flex items-center gap-1.5 text-[11px]">
                <Shield className="w-3.5 h-3.5 text-emerald-400" />
                <span>4. Rol, Blindaje & Equipamiento</span>
              </span>
              {onNavigateToState && (
                <button
                  onClick={() => handleApplyState(state, 4)}
                  className="text-[10px] text-[#C9A050] hover:underline flex items-center gap-0.5 cursor-pointer"
                  title="Cargar e ir directamente a Rol y Armas"
                >
                  <span>Abrir Estado 4</span>
                  <ArrowUpRight className="w-3 h-3" />
                </button>
              )}
            </div>
            <div className="text-[10px] text-[#888888] space-y-0.5">
              {breakdown.state4.details.length > 0 ? (
                breakdown.state4.details.slice(0, 3).map((d, i) => (
                  <div key={i} className="truncate text-[#AAAAAA]">⚔️ {d}</div>
                ))
              ) : (
                <div className="text-[#666666] italic">Rol estándar / Civil</div>
              )}
            </div>
          </div>
        </div>

        {/* State 5 */}
        <div className="p-3 bg-[#15171C] rounded-xl border border-[#222222] space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="font-bold text-[#E0E0E0] flex items-center gap-1.5 text-[11px]">
              <BookOpen className="w-3.5 h-3.5 text-rose-400" />
              <span>5. Trasfondo, Cronología de Vida & Relaciones</span>
            </span>
            {onNavigateToState && (
              <button
                onClick={() => handleApplyState(state, 5)}
                className="text-[10px] text-[#C9A050] hover:underline flex items-center gap-0.5 cursor-pointer"
                title="Cargar e ir directamente a Trasfondo y Vínculos"
              >
                <span>Abrir Estado 5</span>
                <ArrowUpRight className="w-3 h-3" />
              </button>
            )}
          </div>
          <div className="flex flex-wrap gap-1.5 text-[10px]">
            {breakdown.state5.details.length > 0 ? (
              breakdown.state5.details.map((d, i) => (
                <span key={i} className="px-2 py-0.5 bg-[#0F1115] border border-[#2A2D35] rounded-md text-[#CCCCCC]">
                  {d}
                </span>
              ))
            ) : (
              <span className="text-[#666666] italic">Personalidad estándar configurada</span>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-6 right-6 z-60 bg-[#1A1C22] border border-[#C9A050] text-[#E0E0E0] px-5 py-3 rounded-2xl shadow-2xl flex items-center space-x-3 animate-fade-in">
          <CheckCircle2 className="w-5 h-5 text-[#C9A050]" />
          <span className="text-xs font-semibold">{toastMessage}</span>
        </div>
      )}

      <div className="bg-[#0F1115] border border-[#2A2D35] rounded-3xl max-w-4xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-scale-up">
        
        {/* Modal Header */}
        <div className="p-6 border-b border-[#222222] flex items-center justify-between bg-gradient-to-r from-[#15171C] to-[#0F1115]">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-[#1A1C22] border border-[#C9A050]/50 flex items-center justify-center text-[#C9A050]">
              <FileUp className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-serif italic font-bold text-[#C9A050]">
                Cargar & Mapear Ficha Técnica en Estados
              </h2>
              <p className="text-xs text-[#888888]">
                Importa archivos (.json / .md / .txt) o pega fichas técnicas. Los parámetros se traducen automáticamente en opciones activas en los Estados 1 al 6.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-[#888888] hover:text-[#E0E0E0] hover:bg-[#1A1C22] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Navigation Tabs */}
        <div className="flex border-b border-[#222222] bg-[#121418] px-6 gap-2 pt-3 overflow-x-auto">
          <button
            onClick={() => setActiveTab('paste')}
            className={`pb-3 px-4 text-xs font-semibold flex items-center space-x-2 border-b-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'paste'
                ? 'border-[#C9A050] text-[#C9A050]'
                : 'border-transparent text-[#888888] hover:text-[#CCCCCC]'
            }`}
          >
            <ClipboardPaste className="w-4 h-4" />
            <span>📋 Pegar Ficha o JSON</span>
          </button>

          <button
            onClick={() => setActiveTab('file')}
            className={`pb-3 px-4 text-xs font-semibold flex items-center space-x-2 border-b-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'file'
                ? 'border-[#C9A050] text-[#C9A050]'
                : 'border-transparent text-[#888888] hover:text-[#CCCCCC]'
            }`}
          >
            <FileCode className="w-4 h-4" />
            <span>📁 Cargar Archivo (.json / .md / .txt)</span>
          </button>

          <button
            onClick={() => setActiveTab('library')}
            className={`pb-3 px-4 text-xs font-semibold flex items-center space-x-2 border-b-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'library'
                ? 'border-[#C9A050] text-[#C9A050]'
                : 'border-transparent text-[#888888] hover:text-[#CCCCCC]'
            }`}
          >
            <BookMarked className="w-4 h-4" />
            <span>📚 Biblioteca Guardada ({savedCharacters.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('seeds')}
            className={`pb-3 px-4 text-xs font-semibold flex items-center space-x-2 border-b-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'seeds'
                ? 'border-[#C9A050] text-[#C9A050]'
                : 'border-transparent text-[#888888] hover:text-[#CCCCCC]'
            }`}
          >
            <Sparkle className="w-4 h-4" />
            <span>✨ Plantillas Canónicas ({PRELOADED_SEED_CHARACTERS.length})</span>
          </button>
        </div>

        {/* Modal Body Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">

          {/* TAB 1: PEGAR FICHA O JSON */}
          {activeTab === 'paste' && (
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-[#E0E0E0] flex items-center gap-1.5">
                    <span>Pega el contenido en formato Markdown (.md), Ficha Técnica o JSON:</span>
                  </label>
                  <button
                    onClick={handlePasteFromClipboard}
                    className="text-[11px] text-[#C9A050] hover:underline flex items-center gap-1 cursor-pointer font-medium"
                    title="Pegar automáticamente lo copiado en el portapapeles"
                  >
                    <ClipboardPaste className="w-3.5 h-3.5" />
                    <span>Pegar del Portapapeles</span>
                  </button>
                </div>
                <textarea
                  value={pasteContent}
                  onChange={(e) => {
                    setPasteContent(e.target.value);
                    if (parsedPreview) setParsedPreview(null);
                    setBatchCountDetected(null);
                  }}
                  rows={8}
                  placeholder={`Ejemplo (Ficha Técnica):\n# Ficha Técnica Canónica: Aeloria\n- Raza: Alto Elfo Solar\n- Rol Canónico Principal: Maga Arcana\n- Título Nobiliario: Duquesa de Valerius\n\n## Vestuario y Atuendo\n- Vestido Arcano (Capa Base):\n  • Textil y Color: Seda color Azul Zafiro\n...\n\nO también puedes pegar JSON canónico o un arreglo de respaldo.`}
                  className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-4 text-xs font-mono text-[#E0E0E0] placeholder-[#555555] focus:border-[#C9A050] focus:outline-none leading-relaxed"
                />
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3">
                <span className="text-[11px] text-[#888888]">
                  Soporta formato canónico (.md), comentarios embebidos, objetos JSON individuales y arreglos multi-personaje.
                </span>
                <div className="flex items-center gap-2">
                  {pasteContent && (
                    <button
                      onClick={() => {
                        setPasteContent('');
                        setParsedPreview(null);
                        setBatchCountDetected(null);
                      }}
                      className="px-3 py-2 bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] text-[#888888] rounded-xl text-xs cursor-pointer"
                    >
                      Limpiar
                    </button>
                  )}
                  <button
                    onClick={() => handleAnalyzePaste()}
                    className="bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] px-5 py-2.5 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all shadow-md cursor-pointer"
                  >
                    <Eye className="w-4 h-4" />
                    <span>Analizar y Mapear en Estados</span>
                  </button>
                </div>
              </div>

              {batchCountDetected && (
                <div className="p-4 bg-amber-950/40 border border-amber-500/50 rounded-2xl text-xs text-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <span className="font-bold block text-sm text-[#C9A050]">📦 Respaldo de Biblioteca Detectado</span>
                    <span>Se detectó un arreglo JSON con <strong>{batchCountDetected} personajes</strong>. Puedes importarlos todos a la Biblioteca directamente.</span>
                  </div>
                  <button
                    onClick={() => handleImportBatch(pasteContent)}
                    className="bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] font-bold px-4 py-2 rounded-xl text-xs flex items-center space-x-1.5 transition-all shrink-0 cursor-pointer shadow-md"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Importar los {batchCountDetected} a Biblioteca</span>
                  </button>
                </div>
              )}

              {parsedPreview?.error && (
                <div className="p-4 bg-red-950/40 border border-red-500/50 rounded-xl text-xs text-red-300 flex items-start space-x-2.5">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold block">Error de interpretación:</span>
                    <span>{parsedPreview.error}</span>
                  </div>
                </div>
              )}

              {parsedPreview?.state && parsedPreview.breakdown && (
                <div className="bg-[#15171C] border border-[#C9A050] rounded-2xl p-5 space-y-4 animate-fade-in">
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#222222] pb-3">
                    <div className="flex items-center space-x-2 text-emerald-400 text-xs font-bold">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Formato detectado: {parsedPreview.format}</span>
                    </div>
                    <span className="text-xs text-[#C9A050] font-bold font-serif italic">
                      «{parsedPreview.state.name || 'Personaje Importado'}»
                    </span>
                  </div>

                  {renderStateTranslationMatrix(parsedPreview.breakdown, parsedPreview.state)}

                  <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-[#222222]">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleSaveToLibraryDirect(parsedPreview.state!)}
                        className="bg-[#1A1C22] hover:bg-[#252830] border border-[#C9A050]/60 text-[#C9A050] px-4 py-2.5 rounded-xl font-semibold text-xs flex items-center space-x-1.5 transition-all cursor-pointer shadow-xs"
                        title="Guardar en la biblioteca persistente para usarlo cuando quieras"
                      >
                        <Bookmark className="w-3.5 h-3.5 text-[#C9A050]" />
                        <span>Guardar en Biblioteca</span>
                      </button>
                      <button
                        onClick={() => handleDownloadSheet(parsedPreview.state!)}
                        className="bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] text-[#AAAAAA] hover:text-[#E0E0E0] px-3 py-2.5 rounded-xl text-xs font-medium flex items-center space-x-1.5 transition-all cursor-pointer"
                        title="Descargar Ficha .md"
                      >
                        <Download className="w-3.5 h-3.5 text-[#C9A050]" />
                        <span>.md</span>
                      </button>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          handleSaveToLibraryDirect(parsedPreview.state!);
                          handleApplyState(parsedPreview.state!, 6);
                        }}
                        className="bg-[#1A1C22] hover:bg-[#252830] border border-[#C9A050] text-[#E0E0E0] px-4 py-2.5 rounded-xl font-bold text-xs flex items-center space-x-1.5 transition-all cursor-pointer"
                      >
                        <span>Cargar & Guardar</span>
                      </button>
                      <button
                        onClick={() => handleApplyState(parsedPreview.state!, 6)}
                        className="bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] px-6 py-2.5 rounded-xl font-bold text-xs flex items-center space-x-2 transition-all shadow-md cursor-pointer"
                      >
                        <Check className="w-4 h-4" />
                        <span>⚡ Cargar en Editor (Estados 1 al 6)</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: CARGAR ARCHIVO (.JSON / .MD / .TXT) */}
          {activeTab === 'file' && (
            <div className="space-y-4">
              <div
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
                className={`border-2 border-dashed rounded-3xl p-8 text-center transition-all flex flex-col items-center justify-center space-y-4 ${
                  dragActive
                    ? 'border-[#C9A050] bg-[#C9A050]/10 scale-101'
                    : 'border-[#2A2D35] bg-[#15171C] hover:border-[#888888]'
                }`}
              >
                <div className="w-14 h-14 rounded-2xl bg-[#1A1C22] border border-[#2A2D35] flex items-center justify-center text-[#C9A050]">
                  <Upload className="w-7 h-7" />
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-bold text-[#E0E0E0]">
                    Arrastra y suelta tu archivo de Ficha Técnica (.md, .json, .txt) aquí
                  </p>
                  <p className="text-xs text-[#888888]">
                    Compatible con Fichas Técnicas canónicas, exportaciones JSON y respaldos de biblioteca completos.
                  </p>
                </div>

                <label className="bg-[#1A1C22] hover:bg-[#252830] border border-[#C9A050] text-[#C9A050] px-5 py-2.5 rounded-xl font-bold text-xs flex items-center space-x-2 cursor-pointer transition-all shadow-sm">
                  <FileCode className="w-4 h-4" />
                  <span>Explorar Archivos en tu Dispositivo</span>
                  <input
                    type="file"
                    accept=".json,.md,.txt"
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        handleFileProcess(e.target.files[0]);
                      }
                    }}
                    className="hidden"
                  />
                </label>
              </div>

              {uploadedFileName && (
                <div className="flex items-center justify-between p-3 bg-[#15171C] rounded-xl border border-[#2A2D35] text-xs">
                  <div className="flex items-center space-x-2">
                    <FileText className="w-4 h-4 text-[#C9A050]" />
                    <span className="font-mono text-[#E0E0E0]">{uploadedFileName}</span>
                  </div>
                  <span className="text-[10px] text-emerald-400 font-mono">Archivo cargado</span>
                </div>
              )}

              {fileBatchCount && rawFileContent && (
                <div className="p-4 bg-amber-950/40 border border-amber-500/50 rounded-2xl text-xs text-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <span className="font-bold block text-sm text-[#C9A050]">📦 Archivo de Respaldo de Biblioteca Detectado</span>
                    <span>El archivo contiene <strong>{fileBatchCount} personajes</strong> guardados.</span>
                  </div>
                  <button
                    onClick={() => handleImportBatch(rawFileContent)}
                    className="bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] font-bold px-4 py-2 rounded-xl text-xs flex items-center space-x-1.5 transition-all shrink-0 cursor-pointer shadow-md"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Importar los {fileBatchCount} a Biblioteca</span>
                  </button>
                </div>
              )}

              {fileParseError && (
                <div className="p-4 bg-red-950/40 border border-red-500/50 rounded-xl text-xs text-red-300 flex items-start space-x-2.5">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold block">Error al procesar archivo:</span>
                    <span>{fileParseError}</span>
                  </div>
                </div>
              )}

              {fileParsedState && fileBreakdown && (
                <div className="bg-[#15171C] border border-[#C9A050] rounded-2xl p-5 space-y-4 animate-fade-in">
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#222222] pb-3">
                    <div className="flex items-center space-x-2 text-emerald-400 text-xs font-bold">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Ficha técnica lista para aplicar</span>
                    </div>
                    <span className="text-xs text-[#C9A050] font-bold font-serif italic">
                      «{fileParsedState.name || 'Personaje'}»
                    </span>
                  </div>

                  {renderStateTranslationMatrix(fileBreakdown, fileParsedState)}

                  <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-[#222222]">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleSaveToLibraryDirect(fileParsedState)}
                        className="bg-[#1A1C22] hover:bg-[#252830] border border-[#C9A050]/60 text-[#C9A050] px-4 py-2.5 rounded-xl font-semibold text-xs flex items-center space-x-1.5 transition-all cursor-pointer shadow-xs"
                      >
                        <Bookmark className="w-3.5 h-3.5 text-[#C9A050]" />
                        <span>Guardar en Biblioteca</span>
                      </button>
                      <button
                        onClick={() => handleDownloadSheet(fileParsedState)}
                        className="bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] text-[#AAAAAA] hover:text-[#E0E0E0] px-3 py-2.5 rounded-xl text-xs font-medium flex items-center space-x-1.5 transition-all cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5 text-[#C9A050]" />
                        <span>.md</span>
                      </button>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          handleSaveToLibraryDirect(fileParsedState);
                          handleApplyState(fileParsedState, 6);
                        }}
                        className="bg-[#1A1C22] hover:bg-[#252830] border border-[#C9A050] text-[#E0E0E0] px-4 py-2.5 rounded-xl font-bold text-xs flex items-center space-x-1.5 transition-all cursor-pointer"
                      >
                        <span>Cargar & Guardar</span>
                      </button>
                      <button
                        onClick={() => handleApplyState(fileParsedState, 6)}
                        className="bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] px-6 py-2.5 rounded-xl font-bold text-xs flex items-center space-x-2 transition-all shadow-md cursor-pointer"
                      >
                        <Check className="w-4 h-4" />
                        <span>⚡ Cargar en Editor (Estados 1 al 6)</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: BIBLIOTECA DE PERSONAJES */}
          {activeTab === 'library' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between gap-4">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 absolute left-3.5 top-3 text-[#888888]" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Buscar por nombre, raza o rol..."
                    className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl pl-10 pr-4 py-2 text-xs text-[#E0E0E0] placeholder-[#666666] focus:border-[#C9A050] focus:outline-none"
                  />
                </div>
              </div>

              {filteredLibrary.length === 0 ? (
                <div className="text-center py-12 bg-[#15171C] rounded-2xl border border-[#2A2D35]">
                  <BookMarked className="w-8 h-8 text-[#888888] mx-auto mb-2 opacity-50" />
                  <p className="text-xs text-[#888888]">No se encontraron personajes guardados en la biblioteca.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Characters List */}
                  <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
                    {filteredLibrary.map((entry) => {
                      const isSelected = selectedLibraryId === entry.id;
                      return (
                        <div
                          key={entry.id}
                          onClick={() => setSelectedLibraryId(entry.id)}
                          className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                            isSelected
                              ? 'bg-[#1A1C22] border-[#C9A050] shadow-md'
                              : 'bg-[#15171C] border-[#2A2D35] hover:border-[#888888]'
                          }`}
                        >
                          <div className="space-y-0.5 truncate pr-2">
                            <div className="flex items-center space-x-2">
                              <span className="font-bold text-xs text-[#E0E0E0] truncate">
                                {entry.state.name || 'Sin Nombre'}
                              </span>
                              {entry.variantLabel && (
                                <span className="px-1.5 py-0.2 rounded text-[10px] bg-[#0F1115] border border-[#C9A050]/40 text-[#C9A050]">
                                  {entry.variantLabel}
                                </span>
                              )}
                            </div>
                            <div className="text-[11px] text-[#888888] truncate">
                              {entry.state.raceName || 'Humano'} • {entry.state.role || 'Civil'}
                            </div>
                          </div>
                          <div className="shrink-0 flex items-center gap-1">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleApplyState(entry.state, 6);
                              }}
                              className="px-3 py-1.5 bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] font-bold rounded-lg text-xs flex items-center gap-1 transition-colors cursor-pointer"
                              title="Cargar esta ficha inmediatamente en el editor"
                            >
                              <span>Cargar</span>
                              <ArrowRight className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Character Summary Preview */}
                  {selectedLibraryEntry ? (
                    <div className="bg-[#15171C] border border-[#2A2D35] rounded-2xl p-5 flex flex-col justify-between space-y-4">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between border-b border-[#222222] pb-3">
                          <div>
                            <span className="text-[10px] text-[#888888] uppercase font-mono block">Vista Previa Ficha</span>
                            <h3 className="text-sm font-bold text-[#C9A050]">
                              {selectedLibraryEntry.state.name || 'Sin Nombre'}
                            </h3>
                          </div>
                          <span className="text-[10px] text-[#888888] font-mono">
                            {new Date(selectedLibraryEntry.savedAt).toLocaleDateString()}
                          </span>
                        </div>

                        <div className="grid grid-cols-2 gap-2 text-xs">
                          <div className="bg-[#0F1115] p-2.5 rounded-lg border border-[#222222]">
                            <span className="text-[10px] text-[#888888] block">Raza</span>
                            <span className="font-medium text-[#E0E0E0] truncate block">
                              {selectedLibraryEntry.state.raceName || 'Humano'}
                              {selectedLibraryEntry.state.isHybrid && selectedLibraryEntry.state.secondaryRaceName ? ` × ${selectedLibraryEntry.state.secondaryRaceName.split('(')[0].trim()}` : ''}
                            </span>
                          </div>
                          <div className="bg-[#0F1115] p-2.5 rounded-lg border border-[#222222]">
                            <span className="text-[10px] text-[#888888] block">Rol & Estilo</span>
                            <span className="font-medium text-[#E0E0E0] truncate block">
                              {selectedLibraryEntry.state.role || 'Civil'}
                            </span>
                          </div>
                        </div>

                        <div className="bg-[#0F1115] p-2.5 rounded-lg border border-[#222222] text-xs space-y-1">
                          <div className="text-[11px] text-[#AAAAAA]">
                            <strong className="text-[#C9A050]">Anatomía:</strong> {selectedLibraryEntry.state.anatomy?.sexBase}, {selectedLibraryEntry.state.anatomy?.age}
                          </div>
                          <div className="text-[11px] text-[#AAAAAA]">
                            <strong className="text-[#C9A050]">Vestuario:</strong> {selectedLibraryEntry.state.wardrobes?.length || 0} prendas configuradas
                          </div>
                          {selectedLibraryEntry.state.background?.coreValues && (
                            <div className="text-[11px] text-[#AAAAAA]">
                              <strong className="text-[#C9A050]">Valores:</strong> {selectedLibraryEntry.state.background.coreValues}
                            </div>
                          )}
                        </div>

                        {/* Individual Export Actions */}
                        <div className="flex items-center justify-between pt-2 border-t border-[#222222] text-xs">
                          <div className="flex gap-1.5">
                            <button
                              onClick={() => handleDownloadSheet(selectedLibraryEntry.state)}
                              className="px-2.5 py-1 bg-[#0F1115] hover:bg-[#1A1C22] border border-[#2A2D35] text-[#AAAAAA] hover:text-[#C9A050] rounded-lg text-[11px] flex items-center gap-1 cursor-pointer"
                              title="Descargar Ficha .md"
                            >
                              <Download className="w-3 h-3 text-[#C9A050]" />
                              <span>.md</span>
                            </button>
                            <button
                              onClick={() => handleDownloadJson(selectedLibraryEntry.state)}
                              className="px-2.5 py-1 bg-[#0F1115] hover:bg-[#1A1C22] border border-[#2A2D35] text-[#AAAAAA] hover:text-[#C9A050] rounded-lg text-[11px] flex items-center gap-1 cursor-pointer"
                              title="Exportar JSON"
                            >
                              <Download className="w-3 h-3 text-[#C9A050]" />
                              <span>.json</span>
                            </button>
                            <button
                              onClick={() => handleCopySheet(selectedLibraryEntry.state)}
                              className="px-2.5 py-1 bg-[#0F1115] hover:bg-[#1A1C22] border border-[#2A2D35] text-[#AAAAAA] hover:text-[#C9A050] rounded-lg text-[11px] flex items-center gap-1 cursor-pointer"
                              title="Copiar Ficha al Portapapeles"
                            >
                              <Copy className="w-3 h-3" />
                              <span>Copiar</span>
                            </button>
                          </div>

                          <button
                            onClick={() => handleDeleteFromLibrary(selectedLibraryEntry.id, selectedLibraryEntry.state.name || 'Personaje')}
                            className="p-1 text-[#888888] hover:text-red-400 hover:bg-red-950/30 rounded-lg cursor-pointer transition-colors"
                            title="Eliminar de la biblioteca"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      <button
                        onClick={() => handleApplyState(selectedLibraryEntry.state, 6)}
                        className="w-full bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] py-2.5 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all shadow-md cursor-pointer"
                      >
                        <Check className="w-4 h-4" />
                        <span>Cargar Ficha de "{selectedLibraryEntry.state.name || 'Personaje'}"</span>
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center justify-center p-8 bg-[#15171C] rounded-2xl border border-[#2A2D35] text-xs text-[#888888]">
                      Selecciona un personaje para ver su resumen.
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: PLANTILLAS CANÓNICAS */}
          {activeTab === 'seeds' && (
            <div className="space-y-4">
              <p className="text-xs text-[#888888]">
                Selecciona una plantilla canónica de alta fidelidad pre-configurada para cargar su ficha técnica completa al instante:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[380px] overflow-y-auto pr-1">
                {PRELOADED_SEED_CHARACTERS.map((seed) => (
                  <div
                    key={seed.id}
                    className="bg-[#15171C] border border-[#2A2D35] hover:border-[#C9A050] rounded-2xl p-4 transition-all flex flex-col justify-between space-y-3 group"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="text-xs font-bold text-[#E0E0E0] group-hover:text-[#C9A050] transition-colors">
                          {seed.state.name}
                        </h4>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#0F1115] border border-[#2A2D35] text-[#C9A050]">
                          {seed.state.raceName}
                        </span>
                      </div>
                      <p className="text-[11px] text-[#888888] line-clamp-2">
                        {seed.state.background?.backstory || `${seed.state.role} con estilo ${seed.state.styleVisual}.`}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-[#222222] flex items-center justify-between">
                      <span className="text-[10px] text-[#888888] font-mono">
                        {seed.state.wardrobes?.length || 0} prendas • {seed.state.anatomy?.sexBase}
                      </span>
                      <button
                        onClick={() => handleApplyState(seed.state, 6)}
                        className="px-3 py-1.5 bg-[#1A1C22] hover:bg-[#C9A050] hover:text-[#0A0B0E] border border-[#C9A050] text-[#C9A050] rounded-lg text-xs font-bold flex items-center space-x-1 transition-all cursor-pointer"
                      >
                        <span>Cargar</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-[#15171C] border-t border-[#222222] flex items-center justify-between text-xs text-[#888888]">
          <span>Los datos importados se traducen directamente en selecciones activas en cada pantalla.</span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#0F1115] hover:bg-[#1A1C22] border border-[#2A2D35] rounded-xl text-[#CCCCCC] text-xs font-medium cursor-pointer"
          >
            Cerrar
          </button>
        </div>

      </div>
    </div>
  );
};
