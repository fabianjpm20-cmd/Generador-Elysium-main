import React, { useState, useMemo } from 'react';
import { CharacterState } from '../types';
import {
  RACE_GROUPS,
  ROLES_CATALOG,
  VISUAL_STYLES,
  CHARACTER_ARCHETYPES,
  PERSONALITIES,
  SEX_BASES
} from '../data';
import {
  getCompatibleSubRoles,
  getCompatibleSubStyles,
  computeRoleHybrid,
  computeStyleFusion
} from '../data/styleRoleFusionEngine';
import {
  QuickCreationInput,
  THEMATIC_QUICK_PRESETS,
  getRandomQuickInput,
  generateQuickCharacter,
  ThematicPreset
} from '../utils/quickCreationEngine';
import { saveCharacterToLibrary } from '../utils/libraryStorage';
import {
  Zap,
  Sparkles,
  Dice5,
  X,
  Check,
  User,
  Shield,
  Palette,
  Heart,
  BookOpen,
  Shirt,
  Flame,
  ArrowRight,
  Save,
  Layers,
  Sparkle,
  Compass,
  CheckCircle2,
  RefreshCw,
  Search,
  Eye,
  Crown
} from 'lucide-react';

interface QuickCreationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyCharacter: (generatedState: CharacterState, targetState?: number) => void;
}

export const QuickCreationModal: React.FC<QuickCreationModalProps> = ({
  isOpen,
  onClose,
  onApplyCharacter
}) => {
  const [selectedPresetId, setSelectedPresetId] = useState<string>('paladin-solar');
  const [activeTab, setActiveTab] = useState<'form' | 'presets'>('form');
  const [raceSearch, setRaceSearch] = useState('');
  const [roleSearch, setRoleSearch] = useState('');
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // Form State
  const [inputState, setInputState] = useState<QuickCreationInput>(() => {
    return THEMATIC_QUICK_PRESETS[0].input;
  });

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  };

  // Live Auto-Synthesized Character
  const synthesizedCharacter = useMemo(() => {
    return generateQuickCharacter(inputState);
  }, [inputState]);

  if (!isOpen) return null;

  const handleApplyPreset = (preset: ThematicPreset) => {
    setSelectedPresetId(preset.id);
    setInputState({ ...preset.input });
    setActiveTab('form');
    showToast(`Plantilla "${preset.title}" cargada.`);
  };

  const handleRandomize = () => {
    const randomInput = getRandomQuickInput();
    setInputState(randomInput);
    setSelectedPresetId('');
    showToast('¡Configuración aleatoria inteligente generada!');
  };

  const handleSaveToLibrary = () => {
    const saved = saveCharacterToLibrary(synthesizedCharacter);
    showToast(`Personaje "${synthesizedCharacter.name}" guardado en la Biblioteca.`);
  };

  const handleApplyAndFinish = (targetState: number = 6) => {
    onApplyCharacter(synthesizedCharacter, targetState);
    onClose();
  };

  const handleTraitToggle = (trait: string) => {
    setInputState(prev => {
      const exists = prev.personalityTraits.includes(trait);
      let nextTraits = exists
        ? prev.personalityTraits.filter(t => t !== trait)
        : [...prev.personalityTraits, trait];
      if (nextTraits.length === 0) nextTraits = [trait];
      return { ...prev, personalityTraits: nextTraits };
    });
  };

  // Flattened races for fast filtering
  const allRaces = RACE_GROUPS.flatMap(g => g.races.map(r => ({ ...r, groupTitle: g.title })));
  const filteredRaces = allRaces.filter(r =>
    r.name.toLowerCase().includes(raceSearch.toLowerCase()) ||
    r.groupTitle.toLowerCase().includes(raceSearch.toLowerCase())
  );

  const allRolesFlat = ROLES_CATALOG.flatMap(c => c.roles.map(r => ({ name: r, cat: c.cat })));
  const filteredRoles = allRolesFlat.filter(r =>
    r.name.toLowerCase().includes(roleSearch.toLowerCase()) ||
    r.cat.toLowerCase().includes(roleSearch.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div
        className="bg-[#0F1115] border border-[#C9A050]/40 rounded-2xl w-full max-w-7xl max-h-[94vh] flex flex-col shadow-2xl overflow-hidden relative"
        onClick={e => e.stopPropagation()}
      >
        {/* TOP BAR / HEADER */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#222222] bg-[#15171C]">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#C9A050] to-[#E5C17D] flex items-center justify-center text-[#0A0B0E] font-bold shadow-lg">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-serif italic text-[#C9A050] font-bold">
                  Menú de Creación Rápida
                </h2>
                <span className="text-[10px] uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-[#C9A050]/15 text-[#C9A050] border border-[#C9A050]/30 font-sans font-bold">
                  Auto-Síntesis V7.4
                </span>
              </div>
              <p className="text-xs text-[#888888]">
                Define los 7 pilares esenciales; la anatomía fisonómica y el vestuario multicapa se generan automáticamente.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleRandomize}
              className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050]/60 text-[#E0E0E0] hover:text-[#C9A050] text-xs font-semibold transition-all cursor-pointer shadow-xs active:scale-95"
              title="Generar combinación armónica aleatoria"
            >
              <Dice5 className="w-4 h-4 text-[#C9A050]" />
              <span className="hidden sm:inline">Aleatorio Inteligente</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 text-[#888888] hover:text-white hover:bg-[#1A1C22] rounded-xl transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* TOAST MESSAGE NOTIFICATION */}
        {toastMsg && (
          <div className="absolute top-20 right-6 z-40 bg-[#1A1C22] border border-[#C9A050] text-[#E0E0E0] px-4 py-2 rounded-xl shadow-xl flex items-center gap-2 text-xs animate-bounce">
            <CheckCircle2 className="w-4 h-4 text-[#C9A050]" />
            <span>{toastMsg}</span>
          </div>
        )}

        {/* SUB-HEADER TABS (CONFIGURADOR vs PLANTILLAS) */}
        <div className="flex items-center justify-between px-6 py-2.5 bg-[#121418] border-b border-[#222222]">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setActiveTab('form')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'form'
                  ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                  : 'text-[#888888] hover:text-white hover:bg-[#1A1C22]'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Configuración de los 7 Pilares</span>
            </button>

            <button
              onClick={() => setActiveTab('presets')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'presets'
                  ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                  : 'text-[#888888] hover:text-white hover:bg-[#1A1C22]'
              }`}
            >
              <Flame className="w-3.5 h-3.5" />
              <span>Plantillas Temáticas Curadas ({THEMATIC_QUICK_PRESETS.length})</span>
            </button>
          </div>

          <div className="hidden md:flex items-center gap-2 text-xs text-[#888888]">
            <span>Personaje resultante:</span>
            <span className="font-semibold text-[#E0E0E0] px-2 py-0.5 rounded bg-[#1A1C22] border border-[#2A2D35]">
              {synthesizedCharacter.name || 'Sin nombre'}
            </span>
          </div>
        </div>

        {/* MAIN BODY: 2-COLUMN GRID (LEFT: INPUTS / RIGHT: LIVE INSPECTOR) */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 scrollbar-thin">
          
          {/* TAB 1: FORM INPUTS (7 PILARES) */}
          {activeTab === 'form' ? (
            <div className="lg:col-span-7 space-y-6">

              {/* 1. NOMBRE & SEXO BASE */}
              <div className="bg-[#15171C] p-4 rounded-xl border border-[#222222] space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold uppercase tracking-wider text-[#C9A050] flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5" />
                    <span>1. Identidad & Sexo Base</span>
                  </label>
                  <span className="text-[10px] text-[#888888]">Pilar 1</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <span className="text-[11px] text-[#888888] block mb-1">Nombre del Personaje</span>
                    <input
                      type="text"
                      value={inputState.name || ''}
                      onChange={e => setInputState(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Ej. Lady Valeria Solkrest"
                      className="w-full bg-[#0A0B0E] border border-[#2A2D35] focus:border-[#C9A050] text-[#E0E0E0] text-xs px-3 py-2 rounded-lg outline-hidden"
                    />
                  </div>

                  <div>
                    <span className="text-[11px] text-[#888888] block mb-1">Sexo / Base Anatómica</span>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                      {SEX_BASES.map(sex => (
                        <button
                          key={sex}
                          type="button"
                          onClick={() => setInputState(prev => ({ ...prev, sexBase: sex }))}
                          className={`py-2 px-2 rounded-lg text-xs font-medium text-center transition-all cursor-pointer border ${
                            inputState.sexBase === sex
                              ? 'bg-[#C9A050]/20 border-[#C9A050] text-[#C9A050] font-bold shadow-xs'
                              : 'bg-[#0A0B0E] border-[#2A2D35] text-[#888888] hover:text-[#E0E0E0]'
                          }`}
                        >
                          {sex.replace(/^[0-9]\s*/, '')}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* 2. RAZA & GRUPO RACIAL */}
              <div className="bg-[#15171C] p-4 rounded-xl border border-[#222222] space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold uppercase tracking-wider text-[#C9A050] flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>2. Raza / Fenotipo</span>
                  </label>
                  <div className="relative w-40">
                    <Search className="w-3 h-3 absolute left-2 top-2 text-[#888888]" />
                    <input
                      type="text"
                      placeholder="Buscar raza..."
                      value={raceSearch}
                      onChange={e => setRaceSearch(e.target.value)}
                      className="w-full bg-[#0A0B0E] border border-[#2A2D35] text-[11px] pl-6 pr-2 py-1 rounded-md text-[#E0E0E0] outline-hidden focus:border-[#C9A050]"
                    />
                  </div>
                </div>

                <div className="max-h-36 overflow-y-auto space-y-1 pr-1 scrollbar-thin">
                  {filteredRaces.map(race => {
                    const isSelected = inputState.raceId === race.id;
                    return (
                      <button
                        key={race.id}
                        type="button"
                        onClick={() => setInputState(prev => ({ ...prev, raceId: race.id }))}
                        className={`w-full text-left p-2 rounded-lg text-xs flex items-center justify-between transition-all cursor-pointer border ${
                          isSelected
                            ? 'bg-[#C9A050]/15 border-[#C9A050] text-[#E0E0E0]'
                            : 'bg-[#0A0B0E]/60 border-[#222222] text-[#888888] hover:text-[#E0E0E0] hover:bg-[#1A1C22]'
                        }`}
                      >
                        <div>
                          <span className={`font-semibold ${isSelected ? 'text-[#C9A050]' : ''}`}>
                            {race.name}
                          </span>
                          <span className="text-[10px] text-[#666666] block">
                            {race.groupTitle}
                          </span>
                        </div>
                        {isSelected && <Check className="w-4 h-4 text-[#C9A050]" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 3. ROL PRINCIPAL & SUB-ROL MODIFICADOR + ESTILO & SUB-ESTILO */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* ROL PRINCIPAL & SUB-ROL */}
                <div className="bg-[#15171C] p-4 rounded-xl border border-[#222222] space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold uppercase tracking-wider text-[#C9A050] flex items-center gap-1.5">
                      <Shield className="w-3.5 h-3.5" />
                      <span>3. Rol Canónico Principal</span>
                    </label>
                  </div>

                  <div className="relative">
                    <Search className="w-3 h-3 absolute left-2.5 top-2 text-[#888888]" />
                    <input
                      type="text"
                      placeholder="Filtrar rol..."
                      value={roleSearch}
                      onChange={e => setRoleSearch(e.target.value)}
                      className="w-full bg-[#0A0B0E] border border-[#2A2D35] text-xs pl-7 pr-2 py-1.5 rounded-lg text-[#E0E0E0] outline-hidden focus:border-[#C9A050] mb-2"
                    />
                  </div>

                  <div className="max-h-36 overflow-y-auto space-y-1 pr-1 scrollbar-thin">
                    {filteredRoles.map(r => {
                      const isSelected = inputState.role === r.name;
                      return (
                        <button
                          key={r.name}
                          type="button"
                          onClick={() => setInputState(prev => ({ ...prev, role: r.name }))}
                          className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs flex items-center justify-between transition-all cursor-pointer border ${
                            isSelected
                              ? 'bg-[#C9A050]/20 border-[#C9A050] text-[#C9A050] font-bold'
                              : 'bg-[#0A0B0E] border-[#222222] text-[#888888] hover:text-[#E0E0E0]'
                          }`}
                        >
                          <span className="truncate">{r.name}</span>
                          <span className="text-[9px] text-[#666666] ml-2 shrink-0">{r.cat}</span>
                        </button>
                      );
                    })}
                  </div>

                  {/* Sub-Role Selector (Optimized on-demand) */}
                  {!inputState.subRole ? (
                    <div className="pt-2 border-t border-[#222222] flex items-center justify-between text-xs">
                      <span className="text-[11px] text-[#888888] font-mono flex items-center gap-1">
                        <Crown className="w-3 h-3 text-[#666]" />
                        <span>Rol Puro ({inputState.role})</span>
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          const firstSub = getCompatibleSubRoles(inputState.role)[0]?.name || '';
                          const hybrid = firstSub ? computeRoleHybrid(inputState.role, firstSub) : null;
                          setInputState(prev => ({
                            ...prev,
                            subRole: firstSub,
                            hybridRoleTitle: hybrid?.hybridTitle
                          }));
                        }}
                        className="text-[11px] text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1 cursor-pointer"
                      >
                        <Zap className="w-3 h-3" />
                        <span>+ Añadir Sub-Rol Híbrido</span>
                      </button>
                    </div>
                  ) : (
                    <div className="pt-2 border-t border-[#222222] space-y-1.5 animate-fade-in">
                      <div className="flex items-center justify-between">
                        <label className="text-[11px] font-bold text-cyan-400 flex items-center gap-1">
                          <Crown className="w-3 h-3" />
                          <span>Sub-Rol Modificador (Híbrido)</span>
                        </label>
                        <button
                          type="button"
                          onClick={() => setInputState(prev => ({ ...prev, subRole: undefined, hybridRoleTitle: undefined }))}
                          className="text-[10px] text-[#888888] hover:text-red-400 cursor-pointer"
                        >
                          × Quitar (Rol Puro)
                        </button>
                      </div>
                      <select
                        value={inputState.subRole || ''}
                        onChange={e => {
                          const val = e.target.value || undefined;
                          const hybrid = val ? computeRoleHybrid(inputState.role, val) : null;
                          setInputState(prev => ({
                            ...prev,
                            subRole: val,
                            hybridRoleTitle: hybrid ? hybrid.hybridTitle : undefined
                          }));
                        }}
                        className="w-full bg-[#0A0B0E] border border-[#2A2D35] focus:border-cyan-400 text-xs text-[#E0E0E0] px-2.5 py-1.5 rounded-lg outline-hidden"
                      >
                        <option value="">-- Sin Sub-Rol (Rol Puro) --</option>
                        <optgroup label="⚡ Sub-Roles Recomendados / Sinergias Clave">
                          {getCompatibleSubRoles(inputState.role).map(c => (
                            <option key={c.id || c.name} value={c.name}>
                              {c.name} → {c.hybridTitle} ({c.synergyTags.join(', ')})
                            </option>
                          ))}
                        </optgroup>
                        <optgroup label="Todos los demás roles">
                          {ROLES_CATALOG.flatMap(c => c.roles).filter(r => r !== inputState.role).map(r => (
                            <option key={r} value={r}>{r}</option>
                          ))}
                        </optgroup>
                      </select>
                      {inputState.subRole && (
                        <p className="text-[10px] text-amber-300 font-serif italic">
                          → Título Híbrido: <strong>{inputState.hybridRoleTitle || computeRoleHybrid(inputState.role, inputState.subRole).hybridTitle}</strong>
                        </p>
                      )}
                    </div>
                  )}
                </div>

                {/* ESTILO VISUAL & SUB-ESTILO */}
                <div className="bg-[#15171C] p-4 rounded-xl border border-[#222222] space-y-3">
                  <label className="text-xs font-bold uppercase tracking-wider text-[#C9A050] flex items-center gap-1.5">
                    <Palette className="w-3.5 h-3.5" />
                    <span>4. Estilo Visual Principal</span>
                  </label>

                  <div className="max-h-36 overflow-y-auto grid grid-cols-2 gap-1.5 pr-1 scrollbar-thin">
                    {VISUAL_STYLES.map(style => {
                      const isSelected = inputState.styleVisual === style;
                      return (
                        <button
                          key={style}
                          type="button"
                          onClick={() => setInputState(prev => ({ ...prev, styleVisual: style }))}
                          className={`p-1.5 rounded-lg text-xs text-left transition-all cursor-pointer border truncate ${
                            isSelected
                              ? 'bg-[#C9A050]/20 border-[#C9A050] text-[#C9A050] font-bold shadow-xs'
                              : 'bg-[#0A0B0E] border-[#222222] text-[#888888] hover:text-[#E0E0E0]'
                          }`}
                          title={style}
                        >
                          {style}
                        </button>
                      );
                    })}
                  </div>

                  {/* Sub-Style Selector (Optimized on-demand) */}
                  {!inputState.subStyleVisual ? (
                    <div className="pt-2 border-t border-[#222222] flex items-center justify-between text-xs">
                      <span className="text-[11px] text-[#888888] font-mono flex items-center gap-1">
                        <Sparkle className="w-3 h-3 text-[#666]" />
                        <span>Estilo Puro ({inputState.styleVisual})</span>
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          const firstSub = getCompatibleSubStyles(inputState.styleVisual)[0]?.name || '';
                          const fusion = firstSub ? computeStyleFusion(inputState.styleVisual, firstSub) : null;
                          setInputState(prev => ({
                            ...prev,
                            subStyleVisual: firstSub,
                            styleFusionTitle: fusion?.fusedTitle
                          }));
                        }}
                        className="text-[11px] text-purple-300 hover:text-purple-200 font-semibold flex items-center gap-1 cursor-pointer"
                      >
                        <Sparkles className="w-3 h-3" />
                        <span>+ Fusionar Sub-Estilo</span>
                      </button>
                    </div>
                  ) : (
                    <div className="pt-2 border-t border-[#222222] space-y-1.5 animate-fade-in">
                      <div className="flex items-center justify-between">
                        <label className="text-[11px] font-bold text-purple-300 flex items-center gap-1">
                          <Sparkle className="w-3 h-3" />
                          <span>Sub-Estilo Estético (Fusión)</span>
                        </label>
                        <button
                          type="button"
                          onClick={() => setInputState(prev => ({ ...prev, subStyleVisual: undefined, styleFusionTitle: undefined }))}
                          className="text-[10px] text-[#888888] hover:text-red-400 cursor-pointer"
                        >
                          × Quitar (Estilo Puro)
                        </button>
                      </div>
                      <select
                        value={inputState.subStyleVisual || ''}
                        onChange={e => {
                          const val = e.target.value || undefined;
                          const fusion = val ? computeStyleFusion(inputState.styleVisual, val) : null;
                          setInputState(prev => ({
                            ...prev,
                            subStyleVisual: val,
                            styleFusionTitle: fusion ? fusion.fusedTitle : undefined
                          }));
                        }}
                        className="w-full bg-[#0A0B0E] border border-[#2A2D35] focus:border-purple-400 text-xs text-[#E0E0E0] px-2.5 py-1.5 rounded-lg outline-hidden"
                      >
                        <option value="">-- Sin Sub-Estilo (Estilo Puro) --</option>
                        <optgroup label="⚡ Sub-Estilos Recomendados con Alta Sinergia">
                          {getCompatibleSubStyles(inputState.styleVisual).map(s => (
                            <option key={s.id || s.name} value={s.name}>
                              {s.name} → {s.fusedTitle} ({s.styleTags.join(', ')})
                            </option>
                          ))}
                        </optgroup>
                        <optgroup label="Todos los demás estilos">
                          {VISUAL_STYLES.filter(s => s !== inputState.styleVisual).map(s => (
                            <option key={s} value={s}>{s}</option>
                          ))}
                        </optgroup>
                      </select>
                      {inputState.subStyleVisual && (
                        <p className="text-[10px] text-purple-300 italic">
                          → Fusión: <strong>{inputState.styleFusionTitle || computeStyleFusion(inputState.styleVisual, inputState.subStyleVisual).fusedTitle}</strong>
                        </p>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* 4. ARQUETIPO & PERSONALIDAD */}
              <div className="bg-[#15171C] p-4 rounded-xl border border-[#222222] space-y-4">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold uppercase tracking-wider text-[#C9A050] flex items-center gap-1.5">
                    <Heart className="w-3.5 h-3.5" />
                    <span>5. Arquetipo & 6. Personalidad</span>
                  </label>
                  <span className="text-[10px] text-[#888888]">Pilares 5 & 6</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Arquetipo */}
                  <div>
                    <span className="text-[11px] text-[#888888] block mb-1.5">Tipo de Personaje / Arquetipo</span>
                    <select
                      value={inputState.archetype}
                      onChange={e => setInputState(prev => ({ ...prev, archetype: e.target.value }))}
                      className="w-full bg-[#0A0B0E] border border-[#2A2D35] focus:border-[#C9A050] text-[#E0E0E0] text-xs px-3 py-2 rounded-lg outline-hidden"
                    >
                      {CHARACTER_ARCHETYPES.map(arc => (
                        <option key={arc} value={arc}>
                          {arc}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Personalidad Base */}
                  <div>
                    <span className="text-[11px] text-[#888888] block mb-1.5">Personalidad Base</span>
                    <select
                      value={inputState.personality}
                      onChange={e => setInputState(prev => ({ ...prev, personality: e.target.value }))}
                      className="w-full bg-[#0A0B0E] border border-[#2A2D35] focus:border-[#C9A050] text-[#E0E0E0] text-xs px-3 py-2 rounded-lg outline-hidden"
                    >
                      {PERSONALITIES.map(p => (
                        <option key={p} value={p}>
                          {p}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Chips de Rasgos de Personalidad */}
                <div>
                  <span className="text-[11px] text-[#888888] block mb-1.5">
                    Rasgos Clave de Personalidad (Selecciona varios)
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {[
                      'Alegre', 'Serio', 'Frío/Calculador', 'Estoico', 'Orgulloso', 'Rebelde',
                      'Carismático', 'Tímido', 'Leal', 'Meticuloso', 'Protector', 'Enérgico',
                      'Curioso', 'Astuto', 'Melancólico', 'Honorable', 'Indomable', 'Juguetón'
                    ].map(trait => {
                      const isSelected = inputState.personalityTraits.includes(trait);
                      return (
                        <button
                          key={trait}
                          type="button"
                          onClick={() => handleTraitToggle(trait)}
                          className={`px-2.5 py-1 rounded-full text-xs font-medium transition-all cursor-pointer border ${
                            isSelected
                              ? 'bg-[#C9A050] text-[#0A0B0E] border-[#C9A050] font-bold shadow-xs'
                              : 'bg-[#0A0B0E] border-[#2A2D35] text-[#888888] hover:text-[#E0E0E0]'
                          }`}
                        >
                          {trait}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* 5. CORE DE PERSONAJE & VALORES */}
              <div className="bg-[#15171C] p-4 rounded-xl border border-[#222222] space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold uppercase tracking-wider text-[#C9A050] flex items-center gap-1.5">
                    <BookOpen className="w-3.5 h-3.5" />
                    <span>7. Core de Personaje & Valores Morales</span>
                  </label>
                  <span className="text-[10px] text-[#888888]">Pilar 7</span>
                </div>

                <div className="space-y-3">
                  <div>
                    <span className="text-[11px] text-[#888888] block mb-1">
                      Principios Morales & Brújula Ética
                    </span>
                    <input
                      type="text"
                      value={inputState.coreValues}
                      onChange={e => setInputState(prev => ({ ...prev, coreValues: e.target.value }))}
                      placeholder="Ej. Honor inquebrantable y lealtad a los suyos por encima de la ley..."
                      className="w-full bg-[#0A0B0E] border border-[#2A2D35] focus:border-[#C9A050] text-[#E0E0E0] text-xs px-3 py-2 rounded-lg outline-hidden"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <span className="text-[11px] text-[#888888] block mb-1">Motivación Intrínseca</span>
                      <input
                        type="text"
                        value={inputState.motivation || ''}
                        onChange={e => setInputState(prev => ({ ...prev, motivation: e.target.value }))}
                        placeholder="Ej. Restaurar el honor de su linaje caído..."
                        className="w-full bg-[#0A0B0E] border border-[#2A2D35] focus:border-[#C9A050] text-[#E0E0E0] text-xs px-3 py-1.5 rounded-lg outline-hidden"
                      />
                    </div>
                    <div>
                      <span className="text-[11px] text-[#888888] block mb-1">Secreto / Conflicto Oculto</span>
                      <input
                        type="text"
                        value={inputState.secret || ''}
                        onChange={e => setInputState(prev => ({ ...prev, secret: e.target.value }))}
                        placeholder="Ej. Posee una marca prohibida en el pecho..."
                        className="w-full bg-[#0A0B0E] border border-[#2A2D35] focus:border-[#C9A050] text-[#E0E0E0] text-xs px-3 py-1.5 rounded-lg outline-hidden"
                      />
                    </div>
                  </div>
                </div>
              </div>

            </div>
          ) : (
            /* TAB 2: PLANTILLAS TEMÁTICAS (PRESETS) */
            <div className="lg:col-span-7 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {THEMATIC_QUICK_PRESETS.map(preset => {
                  const isSelected = selectedPresetId === preset.id;
                  return (
                    <div
                      key={preset.id}
                      onClick={() => handleApplyPreset(preset)}
                      className={`p-4 rounded-xl border transition-all cursor-pointer flex flex-col justify-between space-y-3 ${
                        isSelected
                          ? 'bg-[#C9A050]/15 border-[#C9A050] shadow-lg ring-1 ring-[#C9A050]'
                          : 'bg-[#15171C] border-[#222222] hover:border-[#C9A050]/50 hover:bg-[#1A1C22]'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-[#0A0B0E] text-[#C9A050] border border-[#C9A050]/30">
                            {preset.badge}
                          </span>
                          {isSelected && <CheckCircle2 className="w-4 h-4 text-[#C9A050]" />}
                        </div>
                        <h4 className="text-sm font-bold text-[#E0E0E0] font-serif">{preset.title}</h4>
                        <p className="text-xs text-[#888888] mt-1">{preset.tagline}</p>
                      </div>

                      <div className="pt-2 border-t border-[#222222] flex items-center justify-between text-[11px] text-[#A0A0A0]">
                        <span>{preset.input.role}</span>
                        <span className="text-[#C9A050] font-semibold">{preset.input.styleVisual}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* RIGHT COLUMN: LIVE AUTO-SYNTHESIS INSPECTOR */}
          <div className="lg:col-span-5 flex flex-col space-y-4">
            
            <div className="bg-[#121418] rounded-xl border border-[#C9A050]/40 p-4 shadow-xl flex-1 flex flex-col justify-between space-y-4">
              
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-[#222222]">
                  <div className="flex items-center gap-2">
                    <Sparkle className="w-4 h-4 text-[#C9A050] animate-pulse" />
                    <h3 className="text-xs font-bold uppercase tracking-wider text-[#C9A050]">
                      Auto-Síntesis en Tiempo Real
                    </h3>
                  </div>
                  <span className="text-[10px] text-[#888888] bg-[#0A0B0E] px-2 py-0.5 rounded border border-[#2A2D35]">
                    {synthesizedCharacter.raceName} • {synthesizedCharacter.anatomy.sexBase.replace(/^[0-9]\s*/, '')}
                  </span>
                </div>

                {/* PREVIEW SECTIONS */}
                <div className="space-y-4 mt-4">

                  {/* 0. ROL HÍBRIDO & FUSIÓN ESTÉTICA (IF ACTIVE) */}
                  {(synthesizedCharacter.subRole || synthesizedCharacter.subStyleVisual) && (
                    <div className="bg-gradient-to-r from-purple-950/30 via-[#0A0B0E] to-cyan-950/30 p-3 rounded-lg border border-[#C9A050]/50 space-y-2">
                      <span className="text-[10px] uppercase font-bold text-[#C9A050] flex items-center gap-1.5">
                        <Sparkles className="w-3 h-3 text-purple-400" />
                        Sinergia & Fusión Activa
                      </span>
                      {synthesizedCharacter.subRole && (
                        <div className="text-xs">
                          <span className="text-cyan-400 font-bold font-serif">
                            👑 {synthesizedCharacter.hybridRoleTitle || synthesizedCharacter.role}
                          </span>
                          <span className="text-[10px] text-[#888888] block">
                            Base: {synthesizedCharacter.role} + Modificador: {synthesizedCharacter.subRole}
                          </span>
                        </div>
                      )}
                      {synthesizedCharacter.subStyleVisual && (
                        <div className="text-xs pt-1 border-t border-[#222222]">
                          <span className="text-purple-300 font-semibold">
                            ✨ {synthesizedCharacter.styleFusionTitle || `${synthesizedCharacter.styleVisual} + ${synthesizedCharacter.subStyleVisual}`}
                          </span>
                        </div>
                      )}
                    </div>
                  )}
                  
                  {/* 1. ANATOMÍA Y ROSTRO */}
                  <div className="bg-[#0A0B0E] p-3 rounded-lg border border-[#1F2228] space-y-2">
                    <span className="text-[10px] uppercase font-bold text-[#C9A050] flex items-center gap-1.5">
                      <User className="w-3 h-3" />
                      Anatomía & Fisonomía Automática
                    </span>
                    <div className="grid grid-cols-2 gap-x-2 gap-y-1 text-xs text-[#888888]">
                      <div><span className="text-[#666666]">Estatura:</span> <span className="text-[#E0E0E0]">{synthesizedCharacter.anatomy.height.split(' ')[1] || 'Estándar'}</span></div>
                      <div><span className="text-[#666666]">Complexión:</span> <span className="text-[#E0E0E0]">{synthesizedCharacter.anatomy.complexion.replace(/^[0-9]\s*/, '')}</span></div>
                      <div><span className="text-[#666666]">Pecho / Silueta:</span> <span className="text-[#E0E0E0]">{synthesizedCharacter.anatomy.breastDevelopment.replace(/^[A-Z]\s*/, '')}</span></div>
                      <div><span className="text-[#666666]">Ojos / Iris:</span> <span className="text-[#E0E0E0]">{synthesizedCharacter.facial.eyeColor}</span></div>
                      <div><span className="text-[#666666]">Peinado:</span> <span className="text-[#E0E0E0]">{synthesizedCharacter.hair.style.replace(/^[A-Z0-9]+\s*/, '')}</span></div>
                      <div><span className="text-[#666666]">Color Pelo:</span> <span className="text-[#E0E0E0]">{synthesizedCharacter.hair.hairColor}</span></div>
                    </div>
                  </div>

                  {/* 2. VESTUARIO MULTICAPA */}
                  <div className="bg-[#0A0B0E] p-3 rounded-lg border border-[#1F2228] space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] uppercase font-bold text-[#C9A050] flex items-center gap-1.5">
                        <Shirt className="w-3 h-3" />
                        Vestuario Completo ({synthesizedCharacter.wardrobes.length} Prendas)
                      </span>
                      <span className="text-[9px] text-[#888888]">{synthesizedCharacter.styleVisual}</span>
                    </div>

                    <div className="space-y-1 max-h-36 overflow-y-auto pr-1 scrollbar-thin">
                      {synthesizedCharacter.wardrobes.map((w, idx) => (
                        <div
                          key={w.id || idx}
                          className="flex items-center justify-between text-[11px] p-1.5 rounded bg-[#15171C] border border-[#222222]"
                        >
                          <div className="flex items-center gap-2 truncate">
                            <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: w.color || '#C9A050' }} />
                            <span className="text-[#E0E0E0] truncate">{w.name}</span>
                          </div>
                          <span className="text-[9px] text-[#666666] shrink-0 ml-2">{w.categoryId}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* 3. EQUIPO, VOZ & COMPORTAMIENTO */}
                  <div className="bg-[#0A0B0E] p-3 rounded-lg border border-[#1F2228] space-y-1.5 text-xs">
                    <span className="text-[10px] uppercase font-bold text-[#C9A050] flex items-center gap-1.5">
                      <Shield className="w-3 h-3" />
                      Armamento & Matriz de Voz
                    </span>
                    <div className="text-[11px] text-[#888888] space-y-1">
                      <div>
                        <span className="text-[#666666]">Arma Principal:</span>{' '}
                        <span className="text-[#E0E0E0]">{synthesizedCharacter.equipment.weapons[0] || 'Ninguna'}</span>
                      </div>
                      <div>
                        <span className="text-[#666666]">Tono de Voz:</span>{' '}
                        <span className="text-[#E0E0E0]">{synthesizedCharacter.background.advancedCustomization.voiceTone}</span>
                      </div>
                      <div>
                        <span className="text-[#666666]">Muletilla / Frase:</span>{' '}
                        <span className="text-[#C9A050] italic">{synthesizedCharacter.background.advancedCustomization.catchphrasesOrIdioms}</span>
                      </div>
                    </div>
                  </div>

                </div>
              </div>

              {/* ACTION BUTTONS (GENERATE & APPLY) */}
              <div className="space-y-2 pt-2 border-t border-[#222222]">
                <button
                  onClick={() => handleApplyAndFinish(6)}
                  className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#C9A050] to-[#E5C17D] hover:from-[#D4AF37] hover:to-[#F3D59B] text-[#0A0B0E] font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg cursor-pointer transition-all active:scale-98"
                >
                  <Zap className="w-4 h-4 fill-current" />
                  <span>⚡ Aplicar y Ver Ficha Completa (Estado 6)</span>
                </button>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => handleApplyAndFinish(1)}
                    className="py-2 px-3 rounded-lg bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050] text-[#E0E0E0] text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                  >
                    <ArrowRight className="w-3.5 h-3.5" />
                    <span>Ajustar Manualmente</span>
                  </button>

                  <button
                    onClick={handleSaveToLibrary}
                    className="py-2 px-3 rounded-lg bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050] text-[#E0E0E0] text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                  >
                    <Save className="w-3.5 h-3.5 text-[#C9A050]" />
                    <span>Guardar en Biblioteca</span>
                  </button>
                </div>
              </div>

            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
