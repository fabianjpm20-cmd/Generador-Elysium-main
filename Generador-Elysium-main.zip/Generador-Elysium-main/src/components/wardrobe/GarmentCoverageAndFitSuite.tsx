import React, { useState } from 'react';
import {
  Layers,
  Shield,
  Check,
  X,
  Plus,
  ChevronDown,
  ChevronUp,
  Scissors,
  UserCheck
} from 'lucide-react';
import {
  COVERAGE_ZONES_BY_CATEGORY,
  COVERAGE_ADJUSTMENT_STYLES
} from '../../data/coverageZonesData';
import { GarmentConfig } from '../../types';
import { InfoTooltip } from '../ui/InfoTooltip';

interface GarmentCoverageAndFitSuiteProps {
  currentGarment: GarmentConfig;
  setCurrentGarment: React.Dispatch<React.SetStateAction<GarmentConfig>>;
  activeOptions: {
    cut: string[];
    length: string[];
    sleeve: string[];
    neckline?: string[];
    location: string[];
    wearStyle?: string[];
    shoeSoles?: string[];
    shoeHeels?: string[];
  };
  isAccCat: boolean;
  isShoesCat: boolean;
  categoryName?: string;
  triggerToast?: (msg: string) => void;
}

export const GarmentCoverageAndFitSuite: React.FC<GarmentCoverageAndFitSuiteProps> = ({
  currentGarment,
  setCurrentGarment,
  activeOptions,
  isAccCat,
  isShoesCat,
  categoryName = 'Prenda',
  triggerToast
}) => {
  const [showFullAnatomy, setShowFullAnatomy] = useState(false);
  const [customZoneInput, setCustomZoneInput] = useState('');

  // Active coverage zones (unified with location for seamless sync)
  const activeZones: string[] = (currentGarment.coverageZones && currentGarment.coverageZones.length > 0)
    ? currentGarment.coverageZones
    : (Array.isArray(currentGarment.location) ? currentGarment.location : []);

  // Update active zones on currentGarment
  const updateZones = (newZones: string[]) => {
    setCurrentGarment(prev => ({
      ...prev,
      coverageZones: newZones,
      location: newZones
    }));
  };

  const handleToggleZone = (zone: string) => {
    const isPresent = activeZones.includes(zone);
    const updated = isPresent
      ? activeZones.filter(z => z !== zone)
      : [...activeZones, zone];
    updateZones(updated);
  };

  const handleRemoveZone = (zoneToRemove: string) => {
    updateZones(activeZones.filter(z => z !== zoneToRemove));
  };

  const handleAddCustomZone = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = customZoneInput.trim();
    if (!trimmed) return;
    if (!activeZones.includes(trimmed)) {
      updateZones([...activeZones, trimmed]);
      if (triggerToast) triggerToast(`Zona "${trimmed}" añadida a la cobertura.`);
    }
    setCustomZoneInput('');
  };

  // Recommended quick zones contextually based on item category and activeOptions.location
  const recommendedZones: string[] = Array.from(
    new Set([
      ...(activeOptions.location || []),
      ...(isAccCat
        ? ['Cuello y Garganta', 'Clavículas y Hombros', 'Antebrazos y Muñecas', 'Manos y Palmas', 'Dedos y Nudillos', 'Orejas y Zonas Temporales', 'Pretina / Cintura Pélvica']
        : isShoesCat
        ? ['Tobillos y Tendones de Aquiles', 'Pies y Empeine', 'Plantas y Talones', 'Pantorrillas y Espinillas Tibiales']
        : ['Pecho / Busto Frontal', 'Torso y Pectoral Completo', 'Clavículas y Hombros', 'Espalda Alta y Omóplatos', 'Cintura y Abdomen', 'Pretina / Cintura Pélvica', 'Muslos / Zona Femoral'])
    ])
  ).slice(0, 10);

  // Combined selected cut / coverage style value
  const selectedCutOrStyle =
    (activeOptions.cut && activeOptions.cut.find(c => c === currentGarment.cut)) ||
    COVERAGE_ADJUSTMENT_STYLES.find(s => s === currentGarment.coverageStyle) ||
    COVERAGE_ADJUSTMENT_STYLES.find(s => s === currentGarment.cut) ||
    currentGarment.cut ||
    currentGarment.coverageStyle ||
    (activeOptions.cut && activeOptions.cut[0]) ||
    COVERAGE_ADJUSTMENT_STYLES[0];

  return (
    <div className="bg-[#111318] border border-[#C9A050]/40 rounded-2xl p-5 space-y-6 shadow-md transition-all">
      {/* Header & Badges */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#2A2D35] pb-4">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-xl bg-[#C9A050]/15 border border-[#C9A050]/30 text-[#C9A050]">
            <UserCheck className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h4 className="text-sm font-bold uppercase tracking-wider text-[#C9A050] flex items-center gap-1.5">
                <span>Zona de Cobertura & Silueta Anatómica</span>
                <InfoTooltip text="Configura la zona anatómica exacta del cuerpo que viste, cubre o protege esta pieza, junto con su silueta, proporciones y estilo de corte unificado." />
              </h4>
            </div>
            <p className="text-xs text-[#A0A0A0] mt-0.5">
              Ajuste ergonómico, proporciones y porte exclusivo para: <span className="text-[#E0E0E0] font-semibold">{currentGarment.name}</span>
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <span className="text-[11px] font-mono bg-[#1A1C22] text-[#C9A050] px-2.5 py-1 rounded-lg border border-[#C9A050]/30">
            {activeZones.length} {activeZones.length === 1 ? 'zona activa' : 'zonas activas'}
          </span>
          <span className="text-[11px] font-mono bg-[#15171C] text-[#888888] px-2.5 py-1 rounded-lg border border-[#2A2D35]">
            {categoryName}
          </span>
        </div>
      </div>

      {/* 1. SECCIÓN: ZONA DE AJUSTE / COBERTURA CORPORAL */}
      <div className="space-y-4 bg-[#0D0F14] border border-[#22252D] rounded-xl p-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <label className="text-xs font-mono font-bold text-[#E0E0E0] flex items-center space-x-2">
            <Layers className="w-3.5 h-3.5 text-[#C9A050]" />
            <span>Zonas Anatómicas Asignadas a esta Pieza</span>
          </label>
          <span className="text-[11px] text-[#888888]">
            Haz clic en los chips sugeridos o explora el catálogo completo
          </span>
        </div>

        {/* Active Zone Badges */}
        <div className="min-h-[44px] p-2.5 bg-[#14161D] border border-[#2A2D35] rounded-xl flex flex-wrap items-center gap-2">
          {activeZones.length === 0 ? (
            <span className="text-xs text-[#666666] italic px-1">
              Sin zonas corporales asignadas aún. Selecciona una zona recomendada o añade una personalizada.
            </span>
          ) : (
            activeZones.map(zone => (
              <span
                key={zone}
                className="inline-flex items-center space-x-1.5 bg-[#1F232D] border border-[#C9A050]/50 text-[#E0E0E0] text-xs px-2.5 py-1 rounded-lg shadow-xs animate-fadeIn"
              >
                <Check className="w-3 h-3 text-[#C9A050]" />
                <span>{zone}</span>
                <button
                  type="button"
                  onClick={() => handleRemoveZone(zone)}
                  className="text-[#888888] hover:text-[#FF5555] transition-colors p-0.5 ml-1"
                  title={`Quitar ${zone}`}
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            ))
          )}
        </div>

        {/* Quick Recommended Suggestions */}
        <div>
          <span className="block text-[11px] font-mono text-[#888888] mb-2 uppercase tracking-wider">
            Sugerencias Rápidas para {currentGarment.name || 'esta pieza'}:
          </span>
          <div className="flex flex-wrap gap-1.5">
            {recommendedZones.map(zone => {
              const isSelected = activeZones.includes(zone);
              return (
                <button
                  key={zone}
                  type="button"
                  onClick={() => handleToggleZone(zone)}
                  className={`text-xs px-2.5 py-1 rounded-lg border transition-all flex items-center space-x-1.5 ${
                    isSelected
                      ? 'bg-[#C9A050]/20 border-[#C9A050] text-[#E0E0E0] font-medium shadow-xs'
                      : 'bg-[#15171C] border-[#2A2D35] text-[#A0A0A0] hover:border-[#4A4D55] hover:text-[#E0E0E0]'
                  }`}
                >
                  {isSelected && <Check className="w-3 h-3 text-[#C9A050]" />}
                  <span>{zone}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Collapsible Full Anatomy Catalog */}
        <div className="pt-1">
          <button
            type="button"
            onClick={() => setShowFullAnatomy(prev => !prev)}
            className="w-full flex items-center justify-between text-xs font-mono text-[#C9A050] bg-[#15171C] hover:bg-[#1A1D24] border border-[#2A2D35] p-2.5 rounded-xl transition-colors"
          >
            <span className="flex items-center space-x-2">
              <Shield className="w-3.5 h-3.5" />
              <span>Explorador de Anatomía Completa por Regiones (6 Categorías)</span>
            </span>
            {showFullAnatomy ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>

          {showFullAnatomy && (
            <div className="mt-3 p-3 bg-[#13151C] border border-[#2A2D35] rounded-xl space-y-4 animate-fadeIn">
              {COVERAGE_ZONES_BY_CATEGORY.map(cat => (
                <div key={cat.id} className="space-y-1.5">
                  <div className="text-[11px] font-mono text-[#C9A050] font-semibold border-b border-[#22252D] pb-1">
                    {cat.categoryName}
                  </div>
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {cat.zones.map(zone => {
                      const isSelected = activeZones.includes(zone);
                      return (
                        <button
                          key={zone}
                          type="button"
                          onClick={() => handleToggleZone(zone)}
                          className={`text-xs px-2.5 py-1 rounded-lg border transition-all flex items-center space-x-1 ${
                            isSelected
                              ? 'bg-[#C9A050]/20 border-[#C9A050] text-[#E0E0E0] font-medium'
                              : 'bg-[#181A20] border-[#2A2D35] text-[#909090] hover:text-[#E0E0E0] hover:border-[#4A4D55]'
                          }`}
                        >
                          {isSelected && <Check className="w-3 h-3 text-[#C9A050]" />}
                          <span>{zone}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Custom Zone Input */}
        <form onSubmit={handleAddCustomZone} className="flex items-center space-x-2 pt-1">
          <input
            type="text"
            placeholder="Añadir zona anatómica personalizada (ej: Muñeca dominante, Costado intercostal izquierdo)..."
            value={customZoneInput}
            onChange={e => setCustomZoneInput(e.target.value)}
            className="flex-1 bg-[#15171C] border border-[#2A2D35] rounded-xl px-3 py-2 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050] transition-colors"
          />
          <button
            type="submit"
            disabled={!customZoneInput.trim()}
            className="bg-[#1C2029] hover:bg-[#252A36] disabled:opacity-40 text-[#C9A050] border border-[#C9A050]/40 px-3 py-2 rounded-xl text-xs font-mono font-medium flex items-center space-x-1.5 transition-colors shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Añadir</span>
          </button>
        </form>
      </div>

      {/* 2. SECCIÓN: SILUETA, CORTE UNIFICADO, PROPORCIÓN & PORTE */}
      <div className="space-y-4">
        <div className="flex items-center space-x-2 text-xs font-mono text-[#C9A050] border-b border-[#2A2D35] pb-2">
          <Scissors className="w-3.5 h-3.5 text-[#C9A050]" />
          <span className="font-bold uppercase tracking-wider">Parámetros de Silueta, Corte & Porte Anatómico</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {/* Combinado: Corte / Ajuste al Cuerpo & Estilo de Ajuste y Compresión */}
          <div>
            <label className="block text-xs font-mono text-[#888888] mb-1">
              {isAccCat
                ? 'Estilo de Forma & Ajuste'
                : isShoesCat
                ? 'Ajuste, Caña & Compresión'
                : 'Corte & Estilo de Ajuste al Cuerpo'}{' '}
              <InfoTooltip text="Combina la silueta, entallado anatómico y grado de compresión de la prenda respecto al cuerpo (slim, segunda piel, ergonómico táctico, regular, holgado, oversize, etc.)." />
            </label>
            <select
              value={selectedCutOrStyle}
              onChange={e => {
                const val = e.target.value;
                setCurrentGarment(prev => ({
                  ...prev,
                  cut: val,
                  coverageStyle: val
                }));
              }}
              className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none"
            >
              {activeOptions.cut && activeOptions.cut.length > 0 && (
                <optgroup label="Corte Específico de la Prenda">
                  {activeOptions.cut.map(o => (
                    <option key={`cut-${o}`} value={o}>{o}</option>
                  ))}
                </optgroup>
              )}
              <optgroup label="Modelos Anatómicos de Ajuste & Compresión">
                {COVERAGE_ADJUSTMENT_STYLES.map(style => (
                  <option key={`cov-${style}`} value={style}>{style}</option>
                ))}
              </optgroup>
            </select>
          </div>

          {/* Largo / Proporción */}
          {activeOptions.length && activeOptions.length.length > 0 && (
            <div>
              <label className="block text-xs font-mono text-[#888888] mb-1">
                Largo / Proporción <InfoTooltip text="Longitud anatómica de la prenda o accesorio respecto a la estatura del personaje." />
              </label>
              <select
                value={
                  activeOptions.length.find(l => l === currentGarment.length) ||
                  activeOptions.length.find(l => l.toLowerCase().startsWith(currentGarment.length?.toLowerCase() || '')) ||
                  activeOptions.length.find(l => currentGarment.length && (l.toLowerCase().includes(currentGarment.length.toLowerCase()) || currentGarment.length.toLowerCase().includes(l.toLowerCase()))) ||
                  activeOptions.length[0] || ''
                }
                onChange={e => setCurrentGarment(prev => ({ ...prev, length: e.target.value }))}
                className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none"
              >
                {activeOptions.length.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
          )}

          {/* Manga */}
          {activeOptions.sleeve && activeOptions.sleeve.length > 0 && (
            <div>
              <label className="block text-xs font-mono text-[#888888] mb-1">
                Manga <InfoTooltip text="Extensión y confección de la manga (corta, larga, sisa, acampanada, ranglan, etc.)." />
              </label>
              <select
                value={
                  activeOptions.sleeve.find(s => s === currentGarment.sleeve) ||
                  activeOptions.sleeve.find(s => s.toLowerCase().startsWith(currentGarment.sleeve?.toLowerCase() || '')) ||
                  activeOptions.sleeve.find(s => currentGarment.sleeve && (s.toLowerCase().includes(currentGarment.sleeve.toLowerCase()) || currentGarment.sleeve.toLowerCase().includes(s.toLowerCase()))) ||
                  activeOptions.sleeve[0] || ''
                }
                onChange={e => setCurrentGarment(prev => ({ ...prev, sleeve: e.target.value }))}
                className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none"
              >
                {activeOptions.sleeve.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
          )}

          {/* Cuello / Escote */}
          {activeOptions.neckline && activeOptions.neckline.length > 0 && (
            <div>
              <label className="block text-xs font-mono text-[#888888] mb-1">
                Cuello / Escote <InfoTooltip text="Tipo de cuello, escote o solapa (redondo, en V, alto militar, cisne, barco, solapa cruzada, etc.)." />
              </label>
              <select
                value={
                  activeOptions.neckline.find(n => n === currentGarment.neckline) ||
                  activeOptions.neckline.find(n => n.toLowerCase().startsWith(currentGarment.neckline?.toLowerCase() || '')) ||
                  activeOptions.neckline.find(n => currentGarment.neckline && (n.toLowerCase().includes(currentGarment.neckline.toLowerCase()) || currentGarment.neckline.toLowerCase().includes(n.toLowerCase()))) ||
                  activeOptions.neckline[0] || ''
                }
                onChange={e => setCurrentGarment(prev => ({ ...prev, neckline: e.target.value }))}
                className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none"
              >
                {activeOptions.neckline.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
          )}

          {/* Porte y Ajuste (para prendas no calzado) */}
          {!isShoesCat && !isAccCat && activeOptions.wearStyle && activeOptions.wearStyle.length > 0 && (
            <div>
              <label className="block text-xs font-mono text-[#888888] mb-1">
                Porte y Ajuste <InfoTooltip text="Forma en que el personaje viste la prenda (Abotonada, Abierta, Al hombro, Remangada, Fajada, Ceñida, etc.)." />
              </label>
              <select
                value={currentGarment.wearStyle || activeOptions.wearStyle[0]}
                onChange={e => setCurrentGarment(prev => ({ ...prev, wearStyle: e.target.value }))}
                className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none"
              >
                {activeOptions.wearStyle.map(w => <option key={w} value={w}>{w}</option>)}
              </select>
            </div>
          )}

          {/* Suela y Tacón para Calzado */}
          {isShoesCat && (
            <>
              {activeOptions.shoeSoles && activeOptions.shoeSoles.length > 0 && (
                <div>
                  <label className="block text-xs font-mono text-[#888888] mb-1">
                    Tipo de Suela <InfoTooltip text="Construcción y huella de la suela del calzado." />
                  </label>
                  <select
                    value={currentGarment.soleType || activeOptions.shoeSoles[0]}
                    onChange={e => setCurrentGarment(prev => ({ ...prev, soleType: e.target.value }))}
                    className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none"
                  >
                    {activeOptions.shoeSoles.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              )}
              {activeOptions.shoeHeels && activeOptions.shoeHeels.length > 0 && (
                <div>
                  <label className="block text-xs font-mono text-[#888888] mb-1">
                    Tipo de Tacón / Elevación <InfoTooltip text="Altura y perfil del tacón." />
                  </label>
                  <select
                    value={currentGarment.heelType || activeOptions.shoeHeels[0]}
                    onChange={e => setCurrentGarment(prev => ({ ...prev, heelType: e.target.value }))}
                    className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none"
                  >
                    {activeOptions.shoeHeels.map(h => <option key={h} value={h}>{h}</option>)}
                  </select>
                </div>
              )}
            </>
          )}

          {/* Estilo de Caída / Ajuste para Accesorios */}
          {isAccCat && (
            <div>
              <label className="block text-xs font-mono text-[#888888] mb-1">
                Comportamiento de Porte <InfoTooltip text="Comportamiento del accesorio sobre la anatomía (Ceñido a la piel, Caída libre, Escalonado, etc.)." />
              </label>
              <select
                value={currentGarment.fitStyle || 'Ceñido / Pegado a la piel'}
                onChange={e => setCurrentGarment(prev => ({ ...prev, fitStyle: e.target.value }))}
                className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none"
              >
                {['Ceñido / Pegado a la piel', 'Caída Libre / Suelto', 'Suspendido / Flotante', 'Escalonado / Múltiples Vueltas', 'Rígido / Estructurado'].map(fs => (
                  <option key={fs} value={fs}>{fs}</option>
                ))}
              </select>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
