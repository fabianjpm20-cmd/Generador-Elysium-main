import React, { useState, useEffect } from 'react';
import { CharacterState, CharacterNarrativeTimeline, NarrativeTimelineMilestone } from '../../types';
import { getSavedCharacters } from '../../utils/libraryStorage';
import { 
  History, 
  Sparkles, 
  Clock, 
  Calendar, 
  Layers, 
  Milestone, 
  RefreshCw, 
  Check, 
  Plus, 
  Trash2, 
  Edit3, 
  ChevronRight, 
  BookOpen, 
  Compass, 
  Zap, 
  ShieldAlert, 
  Eye, 
  Flame,
  FileText,
  Copy,
  Wand2
} from 'lucide-react';
import { InfoTooltip } from '../ui/InfoTooltip';

interface NarrativeTimelineToolProps {
  state: CharacterState;
  setState: React.Dispatch<React.SetStateAction<CharacterState>>;
}

export const NarrativeTimelineTool: React.FC<NarrativeTimelineToolProps> = ({ state, setState }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [focusMode, setFocusMode] = useState<string>('canonical_progression');
  const [relatedVariants, setRelatedVariants] = useState<any[]>([]);
  const [editingMilestoneId, setEditingMilestoneId] = useState<string | null>(null);
  const [copiedNotification, setCopiedNotification] = useState(false);

  // Load variant history from library
  useEffect(() => {
    try {
      const allSaved = getSavedCharacters();
      // Find variants with matching variantGroupId or matching base character ID or same name
      const variants = allSaved.filter(c => {
        if (!c || c.id === state.id) return false;
        const sameGroup = state.variantGroupId && c.variantGroupId === state.variantGroupId;
        const sameName = c.state.name && state.name && c.state.name.toLowerCase().trim() === state.name.toLowerCase().trim();
        const linkedBase = c.baseCharacterId && (c.baseCharacterId === state.id || c.baseCharacterId === state.baseCharacterId);
        return sameGroup || sameName || linkedBase;
      }).map(c => ({
        id: c.id,
        name: c.state.name,
        role: c.state.role,
        raceName: c.state.raceName,
        variantLabel: c.variantLabel || 'Versión Alterna',
        backstory: c.state.background?.backstory,
        state: c.state
      }));

      setRelatedVariants(variants);
    } catch (e) {
      console.warn("Could not load library variants:", e);
    }
  }, [state.id, state.variantGroupId, state.name]);

  const timeline = state.narrativeTimeline;

  const handleGenerateTimeline = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const payload = {
        currentCharacter: {
          name: state.name || 'Sin Nombre',
          raceName: state.raceName || 'Humano',
          role: state.role || 'Aventurero',
          archetype: state.archetype || 'Genérico',
          personalityTraits: state.personalityTraits || [],
          coreValues: state.background?.coreValues || '',
          styleVisual: state.styleVisual || 'Fantasía Tradicional',
          backstory: state.background?.backstory || '',
          motivation: state.background?.motivation || '',
          secret: state.background?.secret || '',
          variantLabel: state.variantLabel || 'Presente / Canónico'
        },
        relatedVariants: relatedVariants.map(v => ({
          name: v.name,
          role: v.role,
          raceName: v.raceName,
          variantLabel: v.variantLabel,
          backstory: v.backstory
        })),
        focusMode,
        depth: 'detailed'
      };

      const res = await fetch('/api/generate-timeline', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        throw new Error('Error al contactar con el generador de línea temporal');
      }

      const data = await res.json();
      
      const newTimeline: CharacterNarrativeTimeline = {
        overview: data.overview || 'Línea temporal narrativa que unifica las eras del personaje.',
        thematicArc: data.thematicArc || 'Evolución y metamorfosis del destino.',
        pivotalTurningPoints: data.pivotalTurningPoints || [],
        milestones: (data.milestones || []).map((m: any, idx: number) => ({
          id: `m-${Date.now()}-${idx}`,
          era: m.era || 'Presente',
          title: m.title || `Hito #${idx + 1}`,
          periodOrAge: m.periodOrAge || 'Era Actual',
          summary: m.summary || '',
          keyEvents: m.keyEvents || [],
          psychologicalEvolution: m.psychologicalEvolution || '',
          roleAndAppearanceNote: m.roleAndAppearanceNote || '',
          linkedVariantName: m.linkedVariantName || undefined
        })),
        generatedAt: new Date().toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }),
        focusMode
      };

      setState(prev => ({
        ...prev,
        narrativeTimeline: newTimeline
      }));
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Error al generar la línea temporal narrativa');
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearTimeline = () => {
    setState(prev => ({
      ...prev,
      narrativeTimeline: undefined
    }));
  };

  const handleUpdateMilestone = (id: string, field: keyof NarrativeTimelineMilestone, value: any) => {
    if (!timeline) return;
    const updated = timeline.milestones.map(m => {
      if (m.id === id) {
        return { ...m, [field]: value };
      }
      return m;
    });
    setState(prev => ({
      ...prev,
      narrativeTimeline: prev.narrativeTimeline ? {
        ...prev.narrativeTimeline,
        milestones: updated
      } : undefined
    }));
  };

  const handleAddCustomMilestone = () => {
    const newM: NarrativeTimelineMilestone = {
      id: `m-${Date.now()}`,
      era: 'Presente',
      title: 'Nuevo Hito Narrativo',
      periodOrAge: 'Edad / Período',
      summary: 'Descripción de los sucesos y revelaciones clave en este punto del viaje.',
      keyEvents: ['Suceso clave 1', 'Suceso clave 2'],
      psychologicalEvolution: 'Impacto psicológico o cambio de perspectiva.'
    };

    setState(prev => {
      const current = prev.narrativeTimeline?.milestones || [];
      return {
        ...prev,
        narrativeTimeline: prev.narrativeTimeline ? {
          ...prev.narrativeTimeline,
          milestones: [...current, newM]
        } : {
          overview: 'Línea temporal personalizada creada manualmente.',
          thematicArc: 'Arco narrativo del personaje.',
          pivotalTurningPoints: [],
          milestones: [newM],
          generatedAt: new Date().toLocaleDateString('es-ES')
        }
      };
    });
  };

  const handleRemoveMilestone = (id: string) => {
    if (!timeline) return;
    setState(prev => ({
      ...prev,
      narrativeTimeline: prev.narrativeTimeline ? {
        ...prev.narrativeTimeline,
        milestones: prev.narrativeTimeline.milestones.filter(m => m.id !== id)
      } : undefined
    }));
  };

  const handleApplyToBackstory = () => {
    if (!timeline) return;
    const compiledText = `[LÍNEA TEMPORAL NARRATIVA]\n${timeline.overview}\n\n[ARCO TEMÁTICO]\n${timeline.thematicArc}\n\n` +
      timeline.milestones.map(m => `• ${m.era.toUpperCase()} (${m.periodOrAge}): ${m.title}\n${m.summary}\nImpacto Psicológico: ${m.psychologicalEvolution}`).join('\n\n');

    setState(prev => ({
      ...prev,
      background: {
        ...prev.background,
        backstory: prev.background?.backstory 
          ? `${prev.background.backstory}\n\n${compiledText}` 
          : compiledText
      }
    }));

    setCopiedNotification(true);
    setTimeout(() => setCopiedNotification(false), 3000);
  };

  const getEraBadgeColor = (era: string) => {
    switch (era) {
      case 'Pasado':
        return 'bg-[#1E293B] border-[#38BDF8]/40 text-[#7DD3FC]';
      case 'Presente':
        return 'bg-[#2E1065] border-[#C084FC]/40 text-[#E9D5FF]';
      case 'Futuro':
        return 'bg-[#3B1219] border-[#FB7185]/40 text-[#FECDD3]';
      case 'Variante Alterna':
        return 'bg-[#142A1E] border-[#34D399]/40 text-[#A7F3D0]';
      default:
        return 'bg-[#1A1C22] border-[#C9A050]/40 text-[#C9A050]';
    }
  };

  return (
    <div className="bg-[#0F1115] border border-[#C9A050]/40 rounded-3xl p-6 md:p-8 space-y-6 shadow-xl relative overflow-hidden">
      <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-80 h-80 bg-[#C9A050]/5 rounded-full blur-3xl pointer-events-none"></div>

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#2A2D35] pb-5 relative z-10">
        <div className="flex items-center space-x-3.5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#C9A050]/20 to-[#7C3AED]/20 border border-[#C9A050]/50 flex items-center justify-center text-[#C9A050] shadow-md">
            <History className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-[11px] font-mono text-[#C9A050] uppercase tracking-wider font-semibold">
                Herramienta de Trasfondo Narrativo
              </span>
              <span className="px-2 py-0.5 rounded-full bg-[#7C3AED]/20 border border-[#7C3AED]/50 text-[#C4B5FD] text-[10px] font-bold">
                IA & Multiverso
              </span>
            </div>
            <h3 className="text-xl md:text-2xl font-serif italic text-[#E0E0E0] font-bold">
              Línea Temporal Narrativa (Pasado, Presente & Futuro)
            </h3>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          {timeline && (
            <button
              type="button"
              onClick={handleClearTimeline}
              className="px-3 py-1.5 rounded-xl bg-[#1A1C22] border border-[#2A2D35] text-xs text-[#888888] hover:text-rose-400 transition-all cursor-pointer"
            >
              Reiniciar
            </button>
          )}
          <button
            type="button"
            onClick={handleGenerateTimeline}
            disabled={isLoading}
            className="bg-gradient-to-r from-[#C9A050] via-[#D4AF37] to-[#B58E45] hover:brightness-110 disabled:opacity-50 text-[#0A0B0E] px-5 py-2.5 rounded-xl font-bold text-xs flex items-center space-x-2 shadow-lg transition-all active:scale-[0.98] cursor-pointer"
          >
            {isLoading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin text-[#0A0B0E]" />
                <span>Tejiendo Línea Temporal...</span>
              </>
            ) : (
              <>
                <Wand2 className="w-4 h-4 text-[#0A0B0E]" />
                <span>{timeline ? 'Regenerar Línea Temporal' : 'Generar Línea Temporal con IA'}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Mode and Variants Context Banner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 relative z-10 text-xs">
        {/* Focus Mode Selector */}
        <div className="bg-[#15171C] border border-[#2A2D35] p-3.5 rounded-2xl space-y-1.5">
          <label className="block text-[11px] font-mono text-[#888888] font-bold flex items-center justify-between">
            <span>Enfoque Narrativo:</span>
            <InfoTooltip text="Define el hilo conductor que priorizará el modelo de lenguaje al articular los hitos temporales." />
          </label>
          <select
            value={focusMode}
            onChange={(e) => setFocusMode(e.target.value)}
            className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050]"
          >
            <option value="canonical_progression">Progresión Cronológica Natural (Juventud → Cénit → Legado)</option>
            <option value="psychological_evolution">Evolución Psicológica, Traumas & Redención</option>
            <option value="epic_destiny">Destino Épico & Despertar de Poderes Trascendentes</option>
            <option value="multiverse_echoes">Ecos Multiversales & Resonancia de Versiones Alternas</option>
          </select>
        </div>

        {/* Variants in Library Indicator */}
        <div className="bg-[#15171C] border border-[#2A2D35] p-3.5 rounded-2xl space-y-1.5 md:col-span-2 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono text-[#888888] font-bold flex items-center space-x-1.5">
              <Layers className="w-3.5 h-3.5 text-[#C9A050]" />
              <span>Versiones Alternas Detectadas en Biblioteca ({relatedVariants.length}):</span>
            </span>
            <span className="text-[10px] text-[#A1A1AA]">
              {relatedVariants.length > 0 ? 'Conexión multiversal habilitada' : 'Línea temporal individual'}
            </span>
          </div>
          <div className="flex flex-wrap gap-1.5 mt-1">
            {relatedVariants.length > 0 ? (
              relatedVariants.map((v, i) => (
                <span
                  key={v.id || i}
                  className="px-2 py-0.5 rounded-md bg-[#1A1C22] border border-[#2A2D35] text-[10px] text-[#C9A050] font-mono"
                  title={`${v.name} (${v.role}) - ${v.variantLabel}`}
                >
                  [{v.variantLabel}] {v.name} ({v.role})
                </span>
              ))
            ) : (
              <span className="text-[11px] text-[#666666] italic">
                Crea y guarda versiones alternas (Pasado/Futuro) en la Biblioteca para conectar sus historias automáticamente.
              </span>
            )}
          </div>
        </div>
      </div>

      {error && (
        <div className="bg-rose-950/40 border border-rose-800/60 p-4 rounded-2xl text-xs text-rose-200 flex items-center space-x-2">
          <ShieldAlert className="w-4 h-4 text-rose-400 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Timeline Content */}
      {timeline ? (
        <div className="space-y-6 pt-2 relative z-10 animate-fadeIn">
          {/* Overview & Arc Card */}
          <div className="bg-[#15171C] border border-[#C9A050]/30 rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-[#2A2D35] pb-2.5">
              <div className="flex items-center space-x-2">
                <Compass className="w-4 h-4 text-[#C9A050]" />
                <h4 className="font-bold text-sm text-[#E0E0E0]">Arco Temático & Sinopsis General</h4>
              </div>
              {timeline.generatedAt && (
                <span className="text-[10px] font-mono text-[#888888]">
                  Generada: {timeline.generatedAt}
                </span>
              )}
            </div>
            <p className="text-xs text-[#E0E0E0] leading-relaxed italic">
              "{timeline.overview}"
            </p>
            {timeline.thematicArc && (
              <div className="bg-[#0F1115] border border-[#2A2D35] p-3 rounded-xl">
                <span className="text-[10px] font-mono text-[#C9A050] uppercase font-bold block mb-1">
                  Arco de Transformación:
                </span>
                <span className="text-xs text-[#A1A1AA] leading-relaxed">
                  {timeline.thematicArc}
                </span>
              </div>
            )}

            {/* Pivotal Turning Points */}
            {timeline.pivotalTurningPoints && timeline.pivotalTurningPoints.length > 0 && (
              <div className="pt-2">
                <span className="text-[10px] font-mono text-[#888888] uppercase font-bold block mb-1.5">
                  Puntos de Inflexión Críticos:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {timeline.pivotalTurningPoints.map((tp, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 rounded-lg bg-[#0F1115] border border-[#2A2D35] text-[11px] text-[#C9A050]"
                    >
                      ⚡ {tp}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Chronological Milestones Flow */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-sm text-[#C9A050] flex items-center space-x-2">
                <Milestone className="w-4 h-4" />
                <span>Hitos Temporales & Eras del Personaje ({timeline.milestones.length})</span>
              </h4>
              <button
                type="button"
                onClick={handleAddCustomMilestone}
                className="px-2.5 py-1 rounded-lg bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050] text-[#E0E0E0] hover:text-[#C9A050] text-[11px] font-semibold flex items-center space-x-1 cursor-pointer transition-all"
              >
                <Plus className="w-3 h-3 text-[#C9A050]" />
                <span>Añadir Hito Manual</span>
              </button>
            </div>

            <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-3 before:bottom-3 before:w-0.5 before:bg-gradient-to-b before:from-[#38BDF8] via-[#C084FC] to-[#FB7185]">
              {timeline.milestones.map((milestone, idx) => {
                const badgeStyle = getEraBadgeColor(milestone.era);
                const isEditing = editingMilestoneId === milestone.id;

                return (
                  <div key={milestone.id || idx} className="relative group">
                    {/* Node Dot */}
                    <div className="absolute -left-6 top-4 w-3.5 h-3.5 rounded-full bg-[#0F1115] border-2 border-[#C9A050] group-hover:scale-125 transition-all"></div>

                    <div className="bg-[#15171C] border border-[#2A2D35] hover:border-[#C9A050]/50 rounded-2xl p-5 space-y-3 transition-all">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#2A2D35] pb-2.5">
                        <div className="flex items-center space-x-2 flex-wrap gap-1">
                          <span className={`px-2.5 py-0.5 rounded-full border text-[10px] font-mono font-bold uppercase tracking-wider ${badgeStyle}`}>
                            {milestone.era}
                          </span>
                          <span className="text-xs font-mono text-[#C9A050]">
                            • {milestone.periodOrAge}
                          </span>
                          {milestone.linkedVariantName && (
                            <span className="px-2 py-0.5 rounded bg-[#1A1C22] border border-[#2A2D35] text-[10px] text-[#A1A1AA] font-mono">
                              Variante: {milestone.linkedVariantName}
                            </span>
                          )}
                        </div>

                        <div className="flex items-center space-x-1.5 self-end sm:self-auto">
                          <button
                            type="button"
                            onClick={() => setEditingMilestoneId(isEditing ? null : milestone.id || null)}
                            className="p-1 rounded bg-[#0F1115] text-[#888888] hover:text-[#C9A050] text-xs cursor-pointer"
                            title="Editar Hito"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleRemoveMilestone(milestone.id || '')}
                            className="p-1 rounded bg-[#0F1115] text-[#888888] hover:text-rose-400 text-xs cursor-pointer"
                            title="Eliminar Hito"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {isEditing ? (
                        <div className="space-y-3 pt-2 text-xs">
                          <div>
                            <label className="block text-[10px] font-mono text-[#888888] mb-1">Título del Hito:</label>
                            <input
                              type="text"
                              value={milestone.title}
                              onChange={(e) => handleUpdateMilestone(milestone.id || '', 'title', e.target.value)}
                              className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] font-mono text-[#888888] mb-1">Era / Período:</label>
                            <input
                              type="text"
                              value={milestone.periodOrAge}
                              onChange={(e) => handleUpdateMilestone(milestone.id || '', 'periodOrAge', e.target.value)}
                              className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] font-mono text-[#888888] mb-1">Resumen Narrativo:</label>
                            <textarea
                              rows={3}
                              value={milestone.summary}
                              onChange={(e) => handleUpdateMilestone(milestone.id || '', 'summary', e.target.value)}
                              className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] font-mono text-[#888888] mb-1">Evolución Psicológica:</label>
                            <input
                              type="text"
                              value={milestone.psychologicalEvolution}
                              onChange={(e) => handleUpdateMilestone(milestone.id || '', 'psychologicalEvolution', e.target.value)}
                              className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                            />
                          </div>
                        </div>
                      ) : (
                        <>
                          <h5 className="font-bold text-sm text-[#E0E0E0]">
                            {milestone.title}
                          </h5>
                          <p className="text-xs text-[#A1A1AA] leading-relaxed">
                            {milestone.summary}
                          </p>

                          {milestone.keyEvents && milestone.keyEvents.length > 0 && (
                            <div className="bg-[#0F1115] rounded-xl p-3 border border-[#2A2D35] space-y-1">
                              <span className="text-[10px] font-mono text-[#888888] uppercase font-bold block">
                                Sucesos Clave:
                              </span>
                              <ul className="list-disc list-inside text-xs text-[#CCCCCC] space-y-0.5">
                                {milestone.keyEvents.map((ev, i) => (
                                  <li key={i}>{ev}</li>
                                ))}
                              </ul>
                            </div>
                          )}

                          {milestone.psychologicalEvolution && (
                            <div className="flex items-start space-x-2 text-xs text-[#C4B5FD] bg-[#1F162B] p-2.5 rounded-xl border border-[#7C3AED]/30">
                              <Flame className="w-3.5 h-3.5 text-[#A78BFA] flex-shrink-0 mt-0.5" />
                              <div>
                                <span className="font-bold text-[10px] uppercase font-mono block text-[#E9D5FF]">Metamorfosis Psicológica:</span>
                                <span>{milestone.psychologicalEvolution}</span>
                              </div>
                            </div>
                          )}

                          {milestone.roleAndAppearanceNote && (
                            <p className="text-[11px] text-[#888888] italic">
                              Indumentaria / Rol en esta era: {milestone.roleAndAppearanceNote}
                            </p>
                          )}
                        </>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Apply to Backstory Action */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-[#15171C] border border-[#2A2D35] p-4 rounded-2xl">
            <div className="text-xs text-[#888888]">
              Integra estos hitos cronológicos al texto de Biografía y Antecedentes (5.2) del personaje.
            </div>
            <button
              type="button"
              onClick={handleApplyToBackstory}
              className="px-4 py-2 rounded-xl bg-[#1A1C22] border border-[#C9A050] hover:bg-[#C9A050] hover:text-[#0A0B0E] text-xs font-bold text-[#C9A050] flex items-center space-x-1.5 transition-all cursor-pointer shadow-sm"
            >
              {copiedNotification ? (
                <>
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span>¡Integrado al Trasfondo!</span>
                </>
              ) : (
                <>
                  <FileText className="w-4 h-4" />
                  <span>Anexar Línea Temporal a la Biografía</span>
                </>
              )}
            </button>
          </div>
        </div>
      ) : (
        /* Empty State */
        <div className="bg-[#15171C] border border-dashed border-[#2A2D35] rounded-2xl p-8 text-center space-y-3 relative z-10">
          <div className="w-12 h-12 rounded-full bg-[#1A1C22] border border-[#2A2D35] flex items-center justify-center text-[#C9A050] mx-auto">
            <Clock className="w-6 h-6" />
          </div>
          <h4 className="text-base font-bold text-[#E0E0E0]">
            Sin Línea Temporal Generada
          </h4>
          <p className="text-xs text-[#888888] max-w-md mx-auto leading-relaxed">
            Pulsa el botón superior para articular una cronología narrativa (Pasado formativo, Presente activo y Futuro trascendente) que conecte las versiones alternas de tu personaje con el modelo de lenguaje.
          </p>
        </div>
      )}
    </div>
  );
};
