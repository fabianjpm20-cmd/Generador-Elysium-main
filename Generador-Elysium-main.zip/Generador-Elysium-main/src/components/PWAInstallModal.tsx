import React, { useState } from 'react';
import {
  Download,
  Monitor,
  Smartphone,
  Apple,
  X,
  CheckCircle2,
  Wifi,
  WifiOff,
  Zap,
  HardDrive,
  Cpu,
  Share,
  PlusSquare,
  ShieldCheck,
  ChevronRight
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type TabType = 'pc' | 'android' | 'ios';

export const PWAInstallModal: React.FC<PWAInstallModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, isDesktop, isOnline, install } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<TabType>(
    isIOS ? 'ios' : isAndroid ? 'android' : 'pc'
  );
  const [installing, setInstalling] = useState(false);
  const [installSuccess, setInstallSuccess] = useState(false);

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    setInstalling(true);
    const success = await install();
    setInstalling(false);
    if (success) {
      setInstallSuccess(true);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
      <div className="bg-[#0E1017] border border-[#C9A050]/60 rounded-3xl max-w-2xl w-full p-5 sm:p-7 shadow-2xl relative max-h-[92vh] flex flex-col overflow-hidden">
        {/* Glow ambient background */}
        <div className="absolute -right-20 -top-20 w-60 h-60 rounded-full bg-[#C9A050]/10 blur-3xl pointer-events-none" />
        <div className="absolute -left-20 -bottom-20 w-60 h-60 rounded-full bg-blue-600/10 blur-3xl pointer-events-none" />

        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#888888] hover:text-white p-2 rounded-xl hover:bg-[#181B26] transition-colors cursor-pointer z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-start gap-3.5 pr-8 shrink-0">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#C9A050] to-[#E5C17D] flex items-center justify-center text-black font-bold shadow-lg shrink-0">
            <Download className="w-6 h-6 text-black" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl sm:text-2xl font-serif italic text-white tracking-tight">
                Descargar e Instalar <span className="text-[#D4AF37]">Elysium</span>
              </h2>
              {isInstalled && (
                <span className="bg-emerald-500/15 border border-emerald-500/40 text-emerald-400 text-[10px] font-mono px-2 py-0.5 rounded-full flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  Instalada
                </span>
              )}
            </div>
            <p className="text-xs text-[#8A8F9E] mt-0.5">
              Aplicación progresiva multiplataforma (PWA) nativa para PC, Mac, Linux, Android e iOS.
            </p>
          </div>
        </div>

        {/* Quick Offline Capability Callout */}
        <div className="mt-4 p-3 rounded-2xl bg-[#141722] border border-[#252A3D] flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
              <Zap className="w-4 h-4" />
            </div>
            <div className="min-w-0 text-xs">
              <div className="font-bold text-white flex items-center gap-1.5">
                <span>Funcionamiento 100% Offline Garantizado</span>
              </div>
              <p className="text-[11px] text-[#8A8F9E] truncate">
                Creación, biblioteca, terminal de agentes y chat funcionan sin conexión a internet.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 font-mono text-[10px] px-2.5 py-1 rounded-xl bg-[#0D0F16] border border-[#262A3C] shrink-0">
            {isOnline ? (
              <>
                <Wifi className="w-3 h-3 text-emerald-400" />
                <span className="text-emerald-300">Conectado</span>
              </>
            ) : (
              <>
                <WifiOff className="w-3 h-3 text-amber-400" />
                <span className="text-amber-300">Modo Offline</span>
              </>
            )}
          </div>
        </div>

        {/* Success Banner if Installed */}
        {(installSuccess || isInstalled) && (
          <div className="mt-3 p-3.5 rounded-2xl bg-emerald-500/15 border border-emerald-500/50 flex items-center gap-3 shrink-0">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shrink-0">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-white">¡Aplicación instalada y lista para funcionar offline!</div>
              <p className="text-[11px] text-emerald-200/80">
                Puedes abrir Elysium desde tu escritorio o pantalla de inicio en cualquier momento, incluso en modo avión.
              </p>
            </div>
          </div>
        )}

        {/* Main 1-Click Install Action if browser supports it */}
        {isInstallable && !isInstalled && !installSuccess && (
          <div className="mt-3 p-3.5 rounded-2xl bg-gradient-to-r from-[#C9A050]/20 via-[#C9A050]/10 to-transparent border border-[#C9A050]/60 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
            <div className="space-y-0.5 text-center sm:text-left">
              <div className="text-xs font-bold text-white flex items-center justify-center sm:justify-start gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#C9A050]" />
                <span>Tu navegador permite la instalación directa con 1 clic</span>
              </div>
              <p className="text-[11px] text-[#A0A5B5]">
                Se integrará a tu sistema como una aplicación de escritorio o app móvil nativa.
              </p>
            </div>

            <button
              onClick={handleInstallClick}
              disabled={installing}
              className="w-full sm:w-auto bg-[#C9A050] hover:bg-[#D4AF37] text-black font-bold text-xs px-5 py-2.5 rounded-xl flex items-center justify-center gap-2 cursor-pointer transition-all shadow-md active:scale-95 shrink-0"
            >
              <Download className="w-4 h-4" />
              <span>{installing ? 'Instalando...' : 'Instalar Aplicación Ahora'}</span>
            </button>
          </div>
        )}

        {/* Platform Selector Tabs */}
        <div className="mt-4 flex items-center gap-1.5 p-1 rounded-xl bg-[#12141D] border border-[#222636] shrink-0">
          <button
            onClick={() => setActiveTab('pc')}
            className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'pc'
                ? 'bg-[#1D212F] text-white border border-[#383D54] shadow-sm'
                : 'text-[#8A8F9E] hover:text-white'
            }`}
          >
            <Monitor className="w-4 h-4 text-blue-400" />
            <span>PC (Windows / Mac / Linux)</span>
          </button>

          <button
            onClick={() => setActiveTab('android')}
            className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'android'
                ? 'bg-[#1D212F] text-white border border-[#383D54] shadow-sm'
                : 'text-[#8A8F9E] hover:text-white'
            }`}
          >
            <Smartphone className="w-4 h-4 text-emerald-400" />
            <span>Android</span>
          </button>

          <button
            onClick={() => setActiveTab('ios')}
            className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'ios'
                ? 'bg-[#1D212F] text-white border border-[#383D54] shadow-sm'
                : 'text-[#8A8F9E] hover:text-white'
            }`}
          >
            <Apple className="w-4 h-4 text-zinc-300" />
            <span>iPhone / iPad (iOS)</span>
          </button>
        </div>

        {/* Tab Contents: Step-by-Step Instructions */}
        <div className="flex-1 overflow-y-auto mt-4 pr-1 space-y-3.5 text-xs text-[#A0A5B5]">
          {/* TAB 1: PC */}
          {activeTab === 'pc' && (
            <div className="space-y-3 animate-fadeIn">
              <div className="bg-[#12141D] border border-[#222634] rounded-2xl p-4 space-y-3">
                <div className="flex items-center gap-2 text-white font-bold">
                  <Monitor className="w-4 h-4 text-[#C9A050]" />
                  <span>Instalación en Ordenador (Chrome, Edge, Brave, Opera)</span>
                </div>

                <ol className="space-y-2.5 text-xs">
                  <li className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-[#1F2230] text-[#D4AF37] font-bold text-[11px] flex items-center justify-center shrink-0 border border-[#31364A]">
                      1
                    </span>
                    <div>
                      <strong className="text-white">Opción directa con 1 clic:</strong> Si ves el botón dorado superior, púlsalo. En Chrome/Edge también puedes hacer clic en el icono de instalación <strong>⊕</strong> o <strong>icono de ordenador</strong> que aparece a la derecha de la barra de direcciones URL.
                    </div>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-[#1F2230] text-[#D4AF37] font-bold text-[11px] flex items-center justify-center shrink-0 border border-[#31364A]">
                      2
                    </span>
                    <div>
                      <strong className="text-white">Desde el menú del navegador:</strong> Abre el menú de tres puntos (<strong>⋮</strong> o <strong>⋯</strong>) en la esquina superior derecha y selecciona <strong>«Instalar Elysium...»</strong>.
                    </div>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-[#1F2230] text-[#D4AF37] font-bold text-[11px] flex items-center justify-center shrink-0 border border-[#31364A]">
                      3
                    </span>
                    <div>
                      <strong className="text-white">Acceso directo en el Escritorio:</strong> Se creará una ventana independiente sin barras de navegador, con su propio icono de alta resolución en tu escritorio y barra de tareas.
                    </div>
                  </li>
                </ol>
              </div>

              {/* Beneficios en PC */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div className="bg-[#10121A] border border-[#1E212E] rounded-xl p-3 space-y-1">
                  <div className="flex items-center gap-1.5 text-white font-semibold">
                    <HardDrive className="w-3.5 h-3.5 text-blue-400" />
                    <span>Caché Local Inmediata</span>
                  </div>
                  <p className="text-[11px] text-[#7A7E8D]">
                    Se precargan todos los assets, estilos e interfaces para abrir la app al instante incluso sin conexión.
                  </p>
                </div>
                <div className="bg-[#10121A] border border-[#1E212E] rounded-xl p-3 space-y-1">
                  <div className="flex items-center gap-1.5 text-white font-semibold">
                    <Cpu className="w-3.5 h-3.5 text-amber-400" />
                    <span>Agentes Autónomos Offline</span>
                  </div>
                  <p className="text-[11px] text-[#7A7E8D]">
                    El motor de inferencia local procesa los estados anímicos y diálogos de los acompañantes sin internet.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: ANDROID */}
          {activeTab === 'android' && (
            <div className="space-y-3 animate-fadeIn">
              <div className="bg-[#12141D] border border-[#222634] rounded-2xl p-4 space-y-3">
                <div className="flex items-center gap-2 text-white font-bold">
                  <Smartphone className="w-4 h-4 text-emerald-400" />
                  <span>Instalación en Dispositivos Móviles Android (Chrome, Samsung Internet)</span>
                </div>

                <ol className="space-y-2.5 text-xs">
                  <li className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-[#1F2230] text-emerald-400 font-bold text-[11px] flex items-center justify-center shrink-0 border border-[#31364A]">
                      1
                    </span>
                    <div>
                      <strong className="text-white">Botón de Instalación Rápida:</strong> Haz clic en el botón superior «Instalar Aplicación Ahora» si está visible.
                    </div>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-[#1F2230] text-emerald-400 font-bold text-[11px] flex items-center justify-center shrink-0 border border-[#31364A]">
                      2
                    </span>
                    <div>
                      <strong className="text-white">Menú de Chrome:</strong> Toca el icono de tres puntos verticales (<strong>⋮</strong>) en la esquina superior derecha del navegador.
                    </div>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-[#1F2230] text-emerald-400 font-bold text-[11px] flex items-center justify-center shrink-0 border border-[#31364A]">
                      3
                    </span>
                    <div>
                      <strong className="text-white">Instalar o Añadir:</strong> Selecciona <strong>«Instalar aplicación»</strong> o <strong>«Agregar a la pantalla principal»</strong> y confirma.
                    </div>
                  </li>
                </ol>
              </div>

              {/* Beneficios en Android */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div className="bg-[#10121A] border border-[#1E212E] rounded-xl p-3 space-y-1">
                  <div className="flex items-center gap-1.5 text-white font-semibold">
                    <Zap className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Modo Standalone 60 FPS</span>
                  </div>
                  <p className="text-[11px] text-[#7A7E8D]">
                    Se ejecuta a pantalla completa, eliminando la barra de navegación del navegador para una inmersión total.
                  </p>
                </div>
                <div className="bg-[#10121A] border border-[#1E212E] rounded-xl p-3 space-y-1">
                  <div className="flex items-center gap-1.5 text-white font-semibold">
                    <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
                    <span>Persistencia Local Blindada</span>
                  </div>
                  <p className="text-[11px] text-[#7A7E8D]">
                    Tus personajes y conversaciones se conservan en el almacenamiento local del dispositivo.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: iOS (iPhone / iPad) */}
          {activeTab === 'ios' && (
            <div className="space-y-3 animate-fadeIn">
              <div className="bg-[#12141D] border border-[#222634] rounded-2xl p-4 space-y-3">
                <div className="flex items-center gap-2 text-white font-bold">
                  <Apple className="w-4 h-4 text-zinc-300" />
                  <span>Instalación en iPhone / iPad (Safari en iOS)</span>
                </div>

                <p className="text-[11px] text-[#8A8F9E]">
                  En dispositivos Apple iOS, la instalación se realiza a través de la opción nativa de Safari en 3 sencillos pasos:
                </p>

                <ol className="space-y-2.5 text-xs">
                  <li className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-[#1F2230] text-zinc-300 font-bold text-[11px] flex items-center justify-center shrink-0 border border-[#31364A]">
                      1
                    </span>
                    <div>
                      <strong className="text-white flex items-center gap-1">
                        Toca el botón «Compartir» de Safari <Share className="w-3.5 h-3.5 text-blue-400 inline" />:
                      </strong>
                      En la barra inferior de Safari, pulsa el icono cuadrado con la flecha hacia arriba.
                    </div>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-[#1F2230] text-zinc-300 font-bold text-[11px] flex items-center justify-center shrink-0 border border-[#31364A]">
                      2
                    </span>
                    <div>
                      <strong className="text-white flex items-center gap-1">
                        Selecciona «Agregar a pantalla de inicio» <PlusSquare className="w-3.5 h-3.5 text-amber-400 inline" />:
                      </strong>
                      Desliza hacia abajo en la lista de opciones y selecciona dicha acción.
                    </div>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-[#1F2230] text-zinc-300 font-bold text-[11px] flex items-center justify-center shrink-0 border border-[#31364A]">
                      3
                    </span>
                    <div>
                      <strong className="text-white">Confirmar «Agregar»:</strong>
                      Pulsa «Agregar» en la esquina superior derecha. Elysium aparecerá con su icono dorado en tu pantalla de inicio y funcionará sin conexión.
                    </div>
                  </li>
                </ol>
              </div>
            </div>
          )}

          {/* Offline Architecture Explanation */}
          <div className="bg-[#0C0E14] border border-[#1D202D] rounded-2xl p-4 space-y-2">
            <div className="flex items-center gap-2 text-white font-bold text-xs">
              <HardDrive className="w-4 h-4 text-[#C9A050]" />
              <span>¿Por qué funciona 100% Offline una vez instalada?</span>
            </div>
            <p className="text-[11px] text-[#8A8F9E] leading-relaxed">
              Elysium utiliza un <strong>Service Worker con precaché Workbox</strong> que descarga de forma segura los scripts, fuentes, iconografía y plantillas de diseño. Además, integra un <strong>Terminal Lógico y Motor de Agentes Autónomos</strong> en el cliente que no requiere servidores externos para gestionar el estado psicológico, memorias episódicas y diálogos deterministas.
            </p>
          </div>
        </div>

        {/* Footer actions */}
        <div className="mt-4 pt-3 border-t border-[#1F2332] flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2 text-[11px] text-[#7A7E8D]">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Compatible con modo avión y sin conexión</span>
          </div>

          <button
            onClick={onClose}
            className="bg-[#181A22] hover:bg-[#222532] text-white border border-[#2B2F40] font-bold text-xs px-4 py-2 rounded-xl cursor-pointer transition-colors"
          >
            Entendido, cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
