import React, { useState, useEffect } from 'react';
import { CharacterState, SavedPortrait } from '../types';
import {
  Sparkles,
  Download,
  Copy,
  Check,
  Trash2,
  ExternalLink,
  Sliders,
  Image as ImageIcon,
  Palette,
  AlertCircle,
  RefreshCw,
  Eye
} from 'lucide-react';

interface GalleryAndExporterProps {
  state: CharacterState;
  onBackToInteraction: () => void;
}

export const GalleryAndExporter: React.FC<GalleryAndExporterProps> = ({
  state,
  onBackToInteraction
}) => {
  const [targetModel, setTargetModel] = useState<'sd' | 'comfy' | 'novelai' | 'pony'>('pony');
  const [isCopied, setIsCopied] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationError, setGenerationError] = useState<string | null>(null);
  const [savedPortraits, setSavedPortraits] = useState<SavedPortrait[]>([]);
  const [selectedPortrait, setSelectedPortrait] = useState<SavedPortrait | null>(null);

  const isNsfw = state?.nsfw?.isNsfwEnabled ?? false;
  const charName = state?.identity?.fullName || state?.identity?.firstName || state?.name || 'Character';
  const race = state?.identity?.race || state?.raceName || 'Humano';
  const hair = state?.hair?.hairColor || 'Negro';
  const eyes = state?.facial?.eyeColor || 'Marrón';
  const skin = state?.anatomy?.skinColor || 'Clara';
  const top = state?.wardrobes?.find(w => w.categoryId === 'B1')?.name || 'halter top';
  const skirt = state?.wardrobes?.find(w => w.categoryId === 'B2')?.name || 'flowing skirt';

  // Load saved portraits from local storage
  useEffect(() => {
    try {
      const stored = localStorage.getItem('elysium_saved_portraits');
      if (stored) {
        setSavedPortraits(JSON.parse(stored));
      }
    } catch (e) {
      console.error('Error loading portraits', e);
    }
  }, []);

  // Save portraits to local storage
  const savePortraitsToStorage = (updated: SavedPortrait[]) => {
    setSavedPortraits(updated);
    try {
      localStorage.setItem('elysium_saved_portraits', JSON.stringify(updated));
    } catch (e) {
      console.error('Error saving portraits', e);
    }
  };

  // Build the universal prompt string
  const generatePromptText = () => {
    const nsfwTags = isNsfw
      ? ', (heavy blush:1.2), parted lips, (heavy breathing:1.1), flushed skin, sweat glisten, detailed collarbone, sensual gaze'
      : ', elegant expression, refined pose, gentle smile';

    if (targetModel === 'pony') {
      return `score_9, score_8_up, score_7_up, source_anime, 1girl, solo, ${charName}, ${race}, ${eyes} eyes, ${hair} hair, ${skin} skin, (${top}:1.2), (${skirt}:1.1), gold armlets, choker, oasis palace interior, dim cinematic lighting, high contrast, masterpiece${nsfwTags}`;
    }

    if (targetModel === 'novelai') {
      return `{{{masterpiece}}}, {{{best quality}}}, 1girl, ${charName}, ${race}, ${eyes} eyes, ${hair} hair, ${skin} skin, (${top}), (${skirt}), gold jewelry, ornate palace, atmospheric lighting, volumetric smoke${nsfwTags}`;
    }

    if (targetModel === 'comfy') {
      return `(masterpiece:1.2), (high quality:1.2), 1girl, ${charName}, ${race}, beautiful detailed face, ${eyes} eyes, ${hair} long hair, ${skin} skin, (${top}:1.15), (${skirt}:1.1), gold filigree jewelry, palace hall, cinematic glow, 8k uhd, photorealistic anime${nsfwTags}`;
    }

    // Default SD WebUI / Forge
    return `(masterpiece, best quality:1.2), 1girl, ${charName}, ${race}, (${eyes} eyes:1.1), ${hair} hair, ${skin} skin, (${top}:1.1), (${skirt}:1.1), (exposed shoulders:1.2), gold armlets, detailed collarbone, oasis palace background, luxury rugs, dim lantern lighting${nsfwTags}`;
  };

  const getNegativePrompt = () => {
    if (targetModel === 'pony') {
      return 'score_4, score_5, score_6, ugly, bad anatomy, deformed limbs, extra fingers, text, watermark, low quality, bad hands, blurry';
    }
    return '(worst quality, low quality:1.4), (deformed, distorted, disfigured:1.3), poorly drawn, bad anatomy, wrong anatomy, extra limb, missing limb, floating limbs, mutated hands and fingers, text, watermark, signature';
  };

  const getRecommendedSettings = () => {
    switch (targetModel) {
      case 'pony':
        return { cfg: 6.5, steps: 28, sampler: 'Euler a / DPM++ 2M Karras', size: '832x1216' };
      case 'novelai':
        return { cfg: 5.0, steps: 28, sampler: 'Euler Ancestral', size: '832x1216' };
      case 'comfy':
        return { cfg: 7.0, steps: 30, sampler: 'dpmpp_2m_sde_gpu', size: '1024x1024' };
      default:
        return { cfg: 7.0, steps: 25, sampler: 'DPM++ 2M Karras', size: '768x1152' };
    }
  };

  // Copy prompt to clipboard
  const handleCopyPrompt = () => {
    navigator.clipboard.writeText(generatePromptText());
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  // Generate artistic portrait via lightweight asynchronous bridge (Pollinations or Canvas snapshot fallback)
  const handleGenerateArtisticPortrait = async () => {
    setIsGenerating(true);
    setGenerationError(null);

    const prompt = generatePromptText();
    const cleanPrompt = encodeURIComponent(prompt.slice(0, 400));
    const width = 768;
    const height = 1024;
    const seed = Math.floor(Math.random() * 999999);
    const pollinationsUrl = `https://image.pollinations.ai/prompt/${cleanPrompt}?width=${width}&height=${height}&seed=${seed}&nologo=true`;

    try {
      // Test-fetch image with 8s timeout to guarantee instant responsiveness
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8500);

      const response = await fetch(pollinationsUrl, { signal: controller.signal });
      clearTimeout(timeoutId);

      if (response.ok) {
        const blob = await response.blob();
        const localBlobUrl = URL.createObjectURL(blob);

        const newPortrait: SavedPortrait = {
          id: `prt-${Date.now()}`,
          characterName: charName,
          characterRace: race,
          imageUrl: localBlobUrl,
          promptUsed: prompt,
          negativePrompt: getNegativePrompt(),
          cfgScale: getRecommendedSettings().cfg,
          sampler: getRecommendedSettings().sampler,
          steps: getRecommendedSettings().steps,
          modelTarget: targetModel,
          timestamp: new Date().toLocaleDateString([], { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }),
          isNsfw
        };

        savePortraitsToStorage([newPortrait, ...savedPortraits]);
      } else {
        throw new Error('Endpoint no disponible');
      }
    } catch (err) {
      console.warn('Network image bridge unavailable or offline, generating procedural canvas HD portrait fallback.');
      
      // Standalone Offline Canvas HD Fallback
      const offscreen = document.createElement('canvas');
      offscreen.width = width;
      offscreen.height = height;
      const ctx = offscreen.getContext('2d');

      if (ctx) {
        const grad = ctx.createLinearGradient(0, 0, width, height);
        grad.addColorStop(0, '#13111C');
        grad.addColorStop(0.5, '#2A2035');
        grad.addColorStop(1, '#0C0A10');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, width, height);

        // Ambient lights & glow
        ctx.fillStyle = 'rgba(201, 160, 80, 0.15)';
        ctx.beginPath();
        ctx.arc(width / 2, height / 2.5, 260, 0, Math.PI * 2);
        ctx.fill();

        // Architectural arches
        ctx.strokeStyle = 'rgba(201, 160, 80, 0.35)';
        ctx.lineWidth = 4;
        ctx.strokeRect(60, 60, width - 120, height - 120);

        // Portrait text badge
        ctx.fillStyle = '#C9A050';
        ctx.font = 'bold 36px serif';
        ctx.textAlign = 'center';
        ctx.fillText(charName, width / 2, height / 2 - 20);

        ctx.fillStyle = '#E0D0B5';
        ctx.font = '22px sans-serif';
        ctx.fillText(`${race} • ${top}`, width / 2, height / 2 + 30);

        ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
        ctx.font = '16px monospace';
        ctx.fillText('Elysium HD Canvas Snapshot (Offline Mode)', width / 2, height - 120);

        const dataUrl = offscreen.toDataURL('image/png');
        const fallbackPortrait: SavedPortrait = {
          id: `prt-${Date.now()}`,
          characterName: charName,
          characterRace: race,
          imageUrl: dataUrl,
          promptUsed: prompt,
          negativePrompt: getNegativePrompt(),
          cfgScale: getRecommendedSettings().cfg,
          sampler: getRecommendedSettings().sampler,
          steps: getRecommendedSettings().steps,
          modelTarget: targetModel,
          timestamp: new Date().toLocaleDateString([], { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }),
          isNsfw
        };

        savePortraitsToStorage([fallbackPortrait, ...savedPortraits]);
      }
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDeletePortrait = (id: string) => {
    const filtered = savedPortraits.filter(p => p.id !== id);
    savePortraitsToStorage(filtered);
    if (selectedPortrait?.id === id) {
      setSelectedPortrait(null);
    }
  };

  const settings = getRecommendedSettings();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      {/* Header Banner */}
      <div className="bg-[#12141A] border border-[#262832] rounded-2xl p-5 flex flex-wrap items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#C9A050] to-[#E5C17D] flex items-center justify-center text-[#0A0B0E] font-bold shadow-md">
            <Palette className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-serif text-[#C9A050] font-semibold tracking-tight">
              Galería & Exportador Universal
            </h2>
            <p className="text-xs text-[#8A8F9E]">
              Generador de retratos artísticos y sintaxis optimizada para SD, ComfyUI, NovelAI y PonyXL
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onBackToInteraction}
          className="px-4 py-2 rounded-xl bg-[#1A1C24] hover:bg-[#252834] text-[#C9A050] border border-[#C9A050]/40 text-xs font-semibold cursor-pointer transition-all shadow-xs"
        >
          ← Volver a la Sala de Interacción
        </button>
      </div>

      {/* Main Grid: Exporter Controls (Left) & Portrait Gallery (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Universal Prompt Exporter & Generator */}
        <div className="lg:col-span-6 space-y-6">
          {/* Target Model Tabs */}
          <div className="bg-[#12141A] border border-[#262832] rounded-2xl p-5 shadow-xl">
            <h3 className="text-xs font-bold uppercase tracking-widest text-[#C9A050] mb-3 flex items-center gap-2">
              <Sliders className="w-4 h-4" />
              <span>Formato de Exportación</span>
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4">
              <button
                type="button"
                onClick={() => setTargetModel('pony')}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                  targetModel === 'pony'
                    ? 'bg-[#2A2635] text-[#C9A050] border-[#C9A050]'
                    : 'bg-[#181A22] text-[#8A8F9E] border-[#282B36] hover:text-[#E0E0E0]'
                }`}
              >
                PonyXL / SDXL
              </button>
              <button
                type="button"
                onClick={() => setTargetModel('sd')}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                  targetModel === 'sd'
                    ? 'bg-[#2A2635] text-[#C9A050] border-[#C9A050]'
                    : 'bg-[#181A22] text-[#8A8F9E] border-[#282B36] hover:text-[#E0E0E0]'
                }`}
              >
                SD WebUI / Forge
              </button>
              <button
                type="button"
                onClick={() => setTargetModel('comfy')}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                  targetModel === 'comfy'
                    ? 'bg-[#2A2635] text-[#C9A050] border-[#C9A050]'
                    : 'bg-[#181A22] text-[#8A8F9E] border-[#282B36] hover:text-[#E0E0E0]'
                }`}
              >
                ComfyUI
              </button>
              <button
                type="button"
                onClick={() => setTargetModel('novelai')}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                  targetModel === 'novelai'
                    ? 'bg-[#2A2635] text-[#C9A050] border-[#C9A050]'
                    : 'bg-[#181A22] text-[#8A8F9E] border-[#282B36] hover:text-[#E0E0E0]'
                }`}
              >
                NovelAI V3
              </button>
            </div>

            {/* Recommended Parameters Box */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 bg-[#181A22] border border-[#262832] p-3 rounded-xl text-xs mb-4">
              <div>
                <span className="text-[10px] uppercase text-[#7A7F90] block">Sampler</span>
                <span className="font-semibold text-[#E0E0E0] truncate block">{settings.sampler}</span>
              </div>
              <div>
                <span className="text-[10px] uppercase text-[#7A7F90] block">CFG Scale</span>
                <span className="font-semibold text-[#C9A050]">{settings.cfg}</span>
              </div>
              <div>
                <span className="text-[10px] uppercase text-[#7A7F90] block">Steps</span>
                <span className="font-semibold text-[#E0E0E0]">{settings.steps}</span>
              </div>
              <div>
                <span className="text-[10px] uppercase text-[#7A7F90] block">Resolución</span>
                <span className="font-semibold text-[#E0E0E0]">{settings.size}</span>
              </div>
            </div>

            {/* Positive Prompt Textarea */}
            <div className="space-y-1.5 mb-4">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-[#A0A5B5]">Prompt Positivo (+18 R-rated)</label>
                <button
                  type="button"
                  onClick={handleCopyPrompt}
                  className="flex items-center gap-1 text-xs text-[#C9A050] hover:underline cursor-pointer"
                >
                  {isCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{isCopied ? '¡Copiado!' : 'Copiar Prompt'}</span>
                </button>
              </div>
              <textarea
                readOnly
                rows={5}
                value={generatePromptText()}
                className="w-full bg-[#181A22] border border-[#282B36] rounded-xl p-3 text-xs text-[#E0E0E0] font-mono leading-relaxed outline-hidden select-all resize-none"
              />
            </div>

            {/* Negative Prompt Textarea */}
            <div className="space-y-1.5 mb-5">
              <label className="text-xs font-bold text-[#A0A5B5]">Negative Prompt Recomendado</label>
              <textarea
                readOnly
                rows={2}
                value={getNegativePrompt()}
                className="w-full bg-[#181A22] border border-[#282B36] rounded-xl p-3 text-xs text-[#8A8F9E] font-mono leading-relaxed outline-hidden select-all resize-none"
              />
            </div>

            {/* Generate Portrait CTA Button */}
            <button
              type="button"
              onClick={handleGenerateArtisticPortrait}
              disabled={isGenerating}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-[#C9A050] to-[#E5C17D] hover:from-[#D4AF37] hover:to-[#F3D59B] text-[#0A0B0E] font-bold text-sm shadow-md transition-all cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Generando Retrato Artístico...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 fill-current" />
                  <span>Generar Retrato Artístico Ahora</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Local Portrait Gallery */}
        <div className="lg:col-span-6 space-y-6">
          <div className="bg-[#12141A] border border-[#262832] rounded-2xl p-5 shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xs font-bold uppercase tracking-widest text-[#C9A050] flex items-center gap-2">
                <ImageIcon className="w-4 h-4" />
                <span>Galería Local de Retratos</span>
              </h3>
              <span className="text-xs text-[#8A8F9E]">
                {savedPortraits.length} {savedPortraits.length === 1 ? 'retrato guardado' : 'retratos guardados'}
              </span>
            </div>

            {savedPortraits.length === 0 ? (
              <div className="border-2 border-dashed border-[#282B36] rounded-xl p-8 text-center text-[#7A7F90] space-y-2">
                <ImageIcon className="w-8 h-8 mx-auto opacity-40" />
                <p className="text-xs">No hay retratos guardados todavía.</p>
                <p className="text-[11px] text-[#6A6F80]">
                  Haz clic en «Generar Retrato Artístico Ahora» para crear una ilustración del personaje actual.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {savedPortraits.map((portrait) => (
                  <div
                    key={portrait.id}
                    className="group relative bg-[#181A22] border border-[#282B36] rounded-xl overflow-hidden hover:border-[#C9A050]/50 transition-all shadow-md flex flex-col"
                  >
                    <div
                      className="aspect-3/4 w-full bg-[#0E0F14] relative cursor-pointer overflow-hidden"
                      onClick={() => setSelectedPortrait(portrait)}
                    >
                      <img
                        src={portrait.imageUrl}
                        alt={portrait.characterName}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <Eye className="w-6 h-6 text-white" />
                      </div>
                    </div>

                    <div className="p-2 flex items-center justify-between bg-[#12141A]">
                      <div className="truncate">
                        <span className="text-[11px] font-bold text-[#E0E0E0] block truncate">
                          {portrait.characterName}
                        </span>
                        <span className="text-[10px] text-[#7A7F90]">{portrait.timestamp}</span>
                      </div>
                      <div className="flex items-center space-x-1 shrink-0">
                        <a
                          href={portrait.imageUrl}
                          download={`elysium_${portrait.characterName}.png`}
                          className="p-1 rounded-md text-[#8A8F9E] hover:text-[#C9A050] transition-colors"
                          title="Descargar imagen"
                        >
                          <Download className="w-3.5 h-3.5" />
                        </a>
                        <button
                          type="button"
                          onClick={() => handleDeletePortrait(portrait.id)}
                          className="p-1 rounded-md text-[#8A8F9E] hover:text-red-400 transition-colors cursor-pointer"
                          title="Eliminar retrato"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Portrait Fullscreen Modal */}
      {selectedPortrait && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#12141A] border border-[#2D3039] rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#262832] pb-3">
              <div>
                <h3 className="text-base font-bold text-[#C9A050]">{selectedPortrait.characterName}</h3>
                <span className="text-xs text-[#8A8F9E]">{selectedPortrait.timestamp}</span>
              </div>
              <button
                type="button"
                onClick={() => setSelectedPortrait(null)}
                className="text-[#8A8F9E] hover:text-[#E0E0E0] text-sm font-bold px-2 py-1 cursor-pointer"
              >
                ✕ Cerrar
              </button>
            </div>

            <div className="rounded-xl overflow-hidden bg-[#0A0B0E] flex items-center justify-center max-h-[500px]">
              <img
                src={selectedPortrait.imageUrl}
                alt={selectedPortrait.characterName}
                className="max-h-[500px] w-auto object-contain"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-[#A0A5B5]">Prompt utilizado:</label>
              <p className="text-xs font-mono bg-[#181A22] p-3 rounded-xl border border-[#262832] text-[#D0D4E0] select-all">
                {selectedPortrait.promptUsed}
              </p>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <a
                href={selectedPortrait.imageUrl}
                download={`elysium_${selectedPortrait.characterName}.png`}
                className="px-4 py-2 rounded-xl bg-[#C9A050] text-[#0A0B0E] font-bold text-xs flex items-center gap-1.5"
              >
                <Download className="w-4 h-4" />
                <span>Descargar PNG</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
