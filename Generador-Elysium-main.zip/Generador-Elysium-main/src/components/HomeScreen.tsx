import React from 'react';
import { MainScreen, CharacterState, WorldPlace, WorldBuildingConfig } from '../types';
import {
  BookMarked,
  Wand2,
  Heart,
  Flame,
  Shield,
  MapPin,
  Sparkles,
  Users,
  Compass,
  Swords,
  ScrollText,
  ArrowRight,
  Zap,
  MessageSquare,
  Download,
  Monitor,
  Smartphone,
  HardDrive
} from 'lucide-react';

interface HomeScreenProps {
  onNavigate: (screen: MainScreen) => void;
  activeCharacter: CharacterState;
  activePlace?: WorldPlace;
  worldConfig: WorldBuildingConfig;
  savedCharactersCount: number;
  savedPlacesCount: number;
  isNsfwEnabled?: boolean;
  onToggleNsfw?: () => void;
  onOpenQuickCreation?: () => void;
  onOpenInstallModal?: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onNavigate,
  activeCharacter,
  activePlace,
  worldConfig,
  savedCharactersCount,
  savedPlacesCount,
  isNsfwEnabled,
  onToggleNsfw,
  onOpenQuickCreation,
  onOpenInstallModal
}) => {
  const charName = activeCharacter?.identity?.fullName || activeCharacter?.name || 'Personaje Activo';
  const charRace = activeCharacter?.identity?.race || activeCharacter?.raceName || 'Humana';
  const charRole = activeCharacter?.archetype || activeCharacter?.role || 'Danzarina';
  const placeName = activePlace?.name || 'Oasis Sagrado de Al-Zahra';

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-fade-in">
      {/* Hero Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#181B22] via-[#12141A] to-[#0A0B0E] border border-[#2D3039] p-6 sm:p-10 shadow-2xl">
        <div className="absolute -right-20 -top-20 w-80 h-80 rounded-full bg-[#C9A050]/10 blur-3xl pointer-events-none" />
        <div className="absolute -left-20 -bottom-20 w-80 h-80 rounded-full bg-rose-600/10 blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#1F222B] border border-[#313542] text-xs font-semibold text-[#D4AF37]">
              <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Elysium v2.0 • Simulador de Vínculo & Agentes Lite</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-serif italic text-[#F0F2F8] tracking-tight">
              Bienvenido al Santuario de <span className="text-[#D4AF37]">Elysium</span>
            </h1>
            <p className="text-sm text-[#9CA3AF] max-w-2xl leading-relaxed">
              Plataforma integral de simulación y diálogo interactivo. Forja mundos vivos con leyes activas, crea personajes con personalidades ricas y participa en conversaciones multi-agente entre tu protagonista, acompañantes y NPCs en escenarios vivos.
            </p>
          </div>

          {/* Quick CTA Actions */}
          <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
            {onOpenInstallModal && (
              <button
                type="button"
                onClick={onOpenInstallModal}
                className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#C9A050] to-[#E5C17D] hover:from-[#D4AF37] hover:to-[#F3D59B] text-black text-xs font-bold transition-all cursor-pointer shadow-md active:scale-95"
                title="Instalar aplicación para PC y Móvil (100% Offline)"
              >
                <Download className="w-4 h-4 text-black" />
                <span>Descargar App</span>
              </button>
            )}

            {onOpenQuickCreation && (
              <button
                type="button"
                onClick={onOpenQuickCreation}
                className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#20232B] hover:bg-[#282C37] text-[#D4AF37] border border-[#3A3F4E] text-xs font-bold transition-all cursor-pointer shadow-md"
              >
                <Zap className="w-4 h-4 fill-current" />
                <span>Creación Rápida</span>
              </button>
            )}

            {onToggleNsfw && (
              <button
                type="button"
                onClick={onToggleNsfw}
                className={`flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold border transition-all cursor-pointer shadow-md ${
                  isNsfwEnabled
                    ? 'bg-rose-950/70 border-rose-600 text-rose-300 hover:bg-rose-900/80 shadow-rose-950/50'
                    : 'bg-[#181A22] border-[#2A2E38] text-[#8A8F9E] hover:text-[#E0E0E0]'
                }`}
                title="Activar o desactivar opciones R+18"
              >
                <Flame className={`w-4 h-4 ${isNsfwEnabled ? 'text-rose-400 fill-current animate-pulse' : 'text-[#8A8F9E]'}`} />
                <span>{isNsfwEnabled ? 'Modo R+18 Activo' : 'Habilitar R+18'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Live Active Session Bar */}
        <div className="mt-8 pt-6 border-t border-[#232630] grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="flex items-center gap-3 bg-[#161820]/80 p-3 rounded-2xl border border-[#262934]">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-600 to-yellow-500 flex items-center justify-center text-black font-bold text-sm shadow-md">
              <Users className="w-5 h-5 text-black" />
            </div>
            <div className="min-w-0">
              <span className="text-[10px] uppercase font-bold text-[#8A8F9E] block">Compañera / Agente</span>
              <p className="text-xs font-bold text-[#E5E7EB] truncate">{charName}</p>
              <span className="text-[10px] text-[#C9A050] truncate block">{charRace} • {charRole}</span>
            </div>
          </div>

          <div className="flex items-center gap-3 bg-[#161820]/80 p-3 rounded-2xl border border-[#262934]">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-500 flex items-center justify-center text-white font-bold text-sm shadow-md">
              <MapPin className="w-5 h-5 text-white" />
            </div>
            <div className="min-w-0">
              <span className="text-[10px] uppercase font-bold text-[#8A8F9E] block">Escenario Fijado</span>
              <p className="text-xs font-bold text-[#E5E7EB] truncate">{placeName}</p>
              <span className="text-[10px] text-indigo-400 truncate block">{activePlace?.region || 'Tierras Sagradas'}</span>
            </div>
          </div>

          <div className="flex items-center gap-3 bg-[#161820]/80 p-3 rounded-2xl border border-[#262934]">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white font-bold text-sm shadow-md">
              <ScrollText className="w-5 h-5 text-white" />
            </div>
            <div className="min-w-0">
              <span className="text-[10px] uppercase font-bold text-[#8A8F9E] block">Mundo & Facciones</span>
              <p className="text-xs font-bold text-[#E5E7EB] truncate">{worldConfig.worldName}</p>
              <span className="text-[10px] text-emerald-400 truncate block">
                {worldConfig.factions.length} Facciones • {worldConfig.laws.filter(l => l.isActive).length} Leyes activas
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* PWA & Offline Feature Card */}
      <div className="relative overflow-hidden rounded-3xl bg-[#12141C] border border-[#C9A050]/30 p-5 sm:p-6 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
        <div className="flex items-start sm:items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#C9A050]/20 to-[#E5C17D]/20 border border-[#C9A050]/50 flex items-center justify-center text-[#D4AF37] shrink-0 shadow-lg">
            <Download className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                <span>Instalar Elysium en tu PC o Dispositivo Móvil</span>
              </h3>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-[10px] font-mono font-semibold">
                100% Offline
              </span>
            </div>
            <p className="text-xs text-[#8A8F9E] max-w-2xl leading-relaxed">
              Instala la aplicación para acceder en cualquier momento sin conexión a internet. Los acompañantes, bots en sala, el historial determinista, los generadores y el motor de rol se ejecutan localmente en tu dispositivo.
            </p>
            <div className="flex items-center gap-3 pt-1 text-[11px] text-[#A0A5B5] flex-wrap">
              <span className="flex items-center gap-1"><Monitor className="w-3.5 h-3.5 text-blue-400" /> Windows / Mac / Linux</span>
              <span className="flex items-center gap-1"><Smartphone className="w-3.5 h-3.5 text-emerald-400" /> Android / iOS</span>
              <span className="flex items-center gap-1"><HardDrive className="w-3.5 h-3.5 text-amber-400" /> Almacenamiento Local</span>
            </div>
          </div>
        </div>

        {onOpenInstallModal && (
          <button
            type="button"
            onClick={onOpenInstallModal}
            className="w-full md:w-auto px-5 py-3 rounded-2xl bg-[#C9A050] hover:bg-[#D4AF37] text-black font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg active:scale-95 shrink-0"
          >
            <Download className="w-4 h-4" />
            <span>Descargar e Instalar</span>
          </button>
        )}
      </div>

      {/* The 3 Main Access Pillars */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-bold text-[#F3F4F6] flex items-center gap-2">
              <Compass className="w-5 h-5 text-[#D4AF37]" />
              <span>Pilares del Sistema</span>
            </h2>
            <p className="text-xs text-[#8A8F9E]">
              Selecciona una de las tres áreas principales de la aplicación.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Card 1: Biblioteca */}
          <div
            onClick={() => onNavigate('library')}
            className="group relative bg-[#13151C] hover:bg-[#161923] border border-[#262934] hover:border-[#D4AF37]/50 rounded-3xl p-6 transition-all duration-300 cursor-pointer shadow-xl flex flex-col justify-between"
          >
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-[#D4AF37] group-hover:scale-110 transition-transform">
                <BookMarked className="w-6 h-6" />
              </div>

              <div>
                <span className="text-[10px] uppercase tracking-wider font-bold text-[#C9A050]">Archivo & Códice</span>
                <h3 className="text-xl font-bold text-[#F3F4F6] mt-0.5 group-hover:text-[#D4AF37] transition-colors">
                  2. Biblioteca
                </h3>
                <p className="text-xs text-[#8A8F9E] mt-2 leading-relaxed">
                  Repositorio centralizado donde se guardan y administran tus personajes (Agentes Lite), escenarios creados y el archivo de worldbuilding.
                </p>
              </div>

              <div className="pt-3 border-t border-[#222530] flex flex-wrap gap-2 text-[11px] text-[#A0A5B5]">
                <span className="px-2.5 py-1 rounded-lg bg-[#1A1C24] border border-[#2B2F3C]">
                  👥 {savedCharactersCount} Personajes
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-[#1A1C24] border border-[#2B2F3C]">
                  🏛️ {savedPlacesCount} Lugares
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-[#1A1C24] border border-[#2B2F3C]">
                  ⚖️ {worldConfig.laws.length} Leyes
                </span>
              </div>
            </div>

            <div className="mt-6 flex items-center justify-between text-xs font-bold text-[#D4AF37]">
              <span>Explorar Biblioteca</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
            </div>
          </div>

          {/* Card 2: Creación */}
          <div
            onClick={() => onNavigate('creation')}
            className="group relative bg-[#13151C] hover:bg-[#161923] border border-[#262934] hover:border-indigo-500/50 rounded-3xl p-6 transition-all duration-300 cursor-pointer shadow-xl flex flex-col justify-between"
          >
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400 group-hover:scale-110 transition-transform">
                <Wand2 className="w-6 h-6" />
              </div>

              <div>
                <span className="text-[10px] uppercase tracking-wider font-bold text-indigo-400">Forja & Taller</span>
                <h3 className="text-xl font-bold text-[#F3F4F6] mt-0.5 group-hover:text-indigo-300 transition-colors">
                  3. Creación
                </h3>
                <p className="text-xs text-[#8A8F9E] mt-2 leading-relaxed">
                  Taller dividido en 3 vertientes: Forja de Personajes (con lógica de Agente Lite y vestimenta por capas), Diseño de Lugares y Worldbuilding.
                </p>
              </div>

              <div className="pt-3 border-t border-[#222530] flex flex-wrap gap-2 text-[11px] text-[#A0A5B5]">
                <span className="px-2.5 py-1 rounded-lg bg-[#1A1C24] border border-[#2B2F3C]">
                  👤 Agentes Lite
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-[#1A1C24] border border-[#2B2F3C]">
                  🗺️ Escenarios
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-[#1A1C24] border border-[#2B2F3C]">
                  📜 Reglas de Mundo
                </span>
              </div>
            </div>

            <div className="mt-6 flex items-center justify-between text-xs font-bold text-indigo-400">
              <span>Abrir Taller de Creación</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
            </div>
          </div>

          {/* Card 3: Interacción */}
          <div
            onClick={() => onNavigate('interaction')}
            className="group relative bg-[#13151C] hover:bg-[#161923] border border-[#262934] hover:border-rose-500/50 rounded-3xl p-6 transition-all duration-300 cursor-pointer shadow-xl flex flex-col justify-between"
          >
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400 group-hover:scale-110 transition-transform">
                <MessageSquare className="w-6 h-6" />
              </div>

              <div>
                <span className="text-[10px] uppercase tracking-wider font-bold text-rose-400">Chatbot & Diálogo</span>
                <h3 className="text-xl font-bold text-[#F3F4F6] mt-0.5 group-hover:text-rose-300 transition-colors">
                  4. Interacción
                </h3>
                <p className="text-xs text-[#8A8F9E] mt-2 leading-relaxed">
                  Sala de chat conversacional multi-agente entre tu personaje (protagonista), personajes secundarios (agentes) y NPCs dentro del escenario y worldbuilding activos.
                </p>
              </div>

              <div className="pt-3 border-t border-[#222530] flex flex-wrap gap-2 text-[11px] text-[#A0A5B5]">
                <span className="px-2.5 py-1 rounded-lg bg-[#1A1C24] border border-[#2B2F3C]">
                  💬 Chat Multi-Agente
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-[#1A1C24] border border-[#2B2F3C]">
                  🤖 NPCs Reactivos
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-[#1A1C24] border border-[#2B2F3C]">
                  ✨ Atmósfera Viva
                </span>
              </div>
            </div>

            <div className="mt-6 flex items-center justify-between text-xs font-bold text-rose-400">
              <span>Entrar al Chat</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
