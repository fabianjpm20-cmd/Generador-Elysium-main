import React, { useState } from 'react';
import { CharacterState } from '../types';
import { 
  RACE_GROUPS, 
  applyRaceSuggestedTraits, 
  RACE_PRESET_TRAITS,
  isEligibleForHybridPrimary,
  applyHybridRaceMixing,
  HybridInheritanceOptions
} from '../data';
import { Shield, ArrowRight, Sparkles, CheckCircle2, Dna, Info, X } from 'lucide-react';
import { InfoTooltip } from './ui/InfoTooltip';

interface State1Props {
  state: CharacterState;
  setState: React.Dispatch<React.SetStateAction<CharacterState>>;
  onNext: () => void;
}

export const State1Raza: React.FC<State1Props> = ({ state, setState, onNext }) => {
  const currentPreset = state.raceId ? RACE_PRESET_TRAITS[state.raceId] : undefined;
  const isPrimaryEligible = state.raceId ? isEligibleForHybridPrimary(state.raceId) : false;

  const [hybridOptions, setHybridOptions] = useState<HybridInheritanceOptions>({
    inheritAppendices: true,
    inheritFacialAndEyes: true,
    inheritSkinAndStructure: true,
    inheritHairElemental: true
  });

  const [selectedSecondaryId, setSelectedSecondaryId] = useState<string>(state.secondaryRaceId || '4.1');
  const [hybridDominance, setHybridDominance] = useState<string>(state.hybridDominance || '50/50 Híbrido Equilibrado');

  const handleSelectRace = (groupId: string, groupTitle: string, raceId: string, raceName: string) => {
    setState((prev) => {
      const updated = applyRaceSuggestedTraits(raceId, undefined, prev);
      const isStillHybridEligible = isEligibleForHybridPrimary(raceId);
      return {
        ...prev,
        ...updated,
        raceGroup: groupTitle,
        raceId: raceId,
        raceName: raceName,
        subtype: undefined,
        subtypeName: undefined,
        isHybrid: isStillHybridEligible ? prev.isHybrid : false,
        secondaryRaceId: isStillHybridEligible ? prev.secondaryRaceId : undefined,
        secondaryRaceName: isStillHybridEligible ? prev.secondaryRaceName : undefined,
        secondarySubtype: undefined,
        secondarySubtypeName: undefined,
        hybridDominance: isStillHybridEligible ? prev.hybridDominance : undefined,
      };
    });
  };

  const handleApplyHybrid = () => {
    if (!state.raceId || !selectedSecondaryId) return;

    // Find secondary race name
    let secName = '';
    for (const group of RACE_GROUPS) {
      const found = group.races.find(r => r.id === selectedSecondaryId);
      if (found) {
        secName = found.name;
        break;
      }
    }

    setState(prev => {
      const mixed = applyHybridRaceMixing(
        prev.raceId, 
        selectedSecondaryId, 
        hybridOptions, 
        prev, 
        undefined, 
        undefined, 
        hybridDominance
      );

      return {
        ...prev,
        ...mixed,
        isHybrid: true,
        secondaryRaceId: selectedSecondaryId,
        secondaryRaceName: secName,
        secondarySubtype: undefined,
        secondarySubtypeName: undefined,
        hybridDominance: hybridDominance,
        hybridFeaturesNote: `Híbrido de ${prev.raceName} con ${secName} (${hybridDominance})`
      };
    });
  };

  const handleRemoveHybrid = () => {
    setState(prev => {
      const restored = applyRaceSuggestedTraits(prev.raceId, undefined, prev);
      return {
        ...prev,
        ...restored,
        isHybrid: false,
        secondaryRaceId: undefined,
        secondaryRaceName: undefined,
        secondarySubtype: undefined,
        secondarySubtypeName: undefined,
        hybridDominance: undefined,
        hybridFeaturesNote: undefined
      };
    });
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      {/* Hero Welcome banner */}
      <div className="bg-[#0F1115] border border-[#222222] rounded-3xl p-8 md:p-12 text-[#E0E0E0] shadow-xl mb-10 relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-96 h-96 bg-[#C9A050]/5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-[#1A1C22] border border-[#2A2D35] text-[#C9A050] text-xs font-medium mb-4">
            <Shield className="w-3.5 h-3.5 text-[#C9A050]" />
            <span>ESTADO 1: SELECCIÓN DE RAZA Y RASGOS SUGERIDOS</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-serif italic text-[#C9A050] tracking-tight mb-4">
            Define la estirpe y origen biológico
          </h2>
          <p className="text-[#888888] text-base md:text-lg mb-6 leading-relaxed">
            Al seleccionar una raza o especie, el sistema aplica automáticamente sus rasgos peculiares sugeridos (esclerótica, hocico, estructura inferior, pelaje, núcleo, alas o cabellos elementales), listos para personalizarse en los siguientes estados.
          </p>
        </div>
      </div>

      {/* Selected Race & Suggested Traits Banner */}
      {state.raceId && currentPreset && (
        <div className="bg-[#12141A] border border-[#C9A050]/40 rounded-2xl p-6 shadow-lg mb-8 animate-fadeIn">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#2A2D35] pb-4 mb-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-xl bg-[#C9A050]/15 border border-[#C9A050]/40 flex items-center justify-center text-[#C9A050]">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-mono text-[#C9A050]">{state.raceId}</span>
                  {state.isHybrid && (
                    <span className="px-2 py-0.5 rounded-md bg-[#7C3AED]/20 border border-[#7C3AED]/50 text-[#C4B5FD] text-[11px] font-semibold flex items-center space-x-1">
                      <Dna className="w-3 h-3 text-[#A78BFA]" />
                      <span>HÍBRIDO: {state.secondaryRaceName?.split('(')[0].trim()}</span>
                    </span>
                  )}
                </div>
                <h3 className="text-lg font-bold text-[#E0E0E0]">
                  {state.raceName}
                  {state.isHybrid && state.secondaryRaceName && (
                    <span className="text-[#C9A050] font-normal text-sm ml-2 font-mono">
                      × {state.secondaryRaceName.split('(')[0].trim()}
                    </span>
                  )}
                </h3>
              </div>
            </div>
            <div className="flex items-center space-x-2 text-xs text-[#C9A050] bg-[#1A1C22] px-3 py-1.5 rounded-lg border border-[#2A2D35]">
              <CheckCircle2 className="w-4 h-4 text-[#C9A050]" />
              <span>{state.isHybrid ? 'Rasgos Fusión Híbrida Activa' : 'Rasgos Peculiares Sugeridos Aplicados'}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
            {currentPreset.scleraColor && (
              <div className="bg-[#181A20] p-3 rounded-xl border border-[#2A2D35]">
                <span className="text-[#888888] block mb-0.5">Color de Esclerótica:</span>
                <span className="text-[#E0E0E0] font-medium">{state.facial.scleraColor || currentPreset.scleraColor}</span>
              </div>
            )}
            {state.facial.facialMorphology && state.facial.facialMorphology !== 'Ninguno / Humanoide Estándar' && (
              <div className="bg-[#181A20] p-3 rounded-xl border border-[#2A2D35]">
                <span className="text-[#888888] block mb-0.5">Morfología Facial / Hocico:</span>
                <span className="text-[#E0E0E0] font-medium">{state.facial.facialMorphology}</span>
              </div>
            )}
            {state.anatomy.lowerBodyStructure && state.anatomy.lowerBodyStructure !== 'SIL01 Bípedo Humanoide Estándar (Piernas)' && (
              <div className="bg-[#181A20] p-3 rounded-xl border border-[#2A2D35]">
                <span className="text-[#888888] block mb-0.5">Estructura Inferior del Cuerpo:</span>
                <span className="text-[#C9A050] font-medium">{state.anatomy.lowerBodyStructure}</span>
              </div>
            )}
            {state.anatomy.neckFeature && state.anatomy.neckFeature !== 'NCK00 Ninguno (Cuello Estándar)' && (
              <div className="bg-[#181A20] p-3 rounded-xl border border-[#2A2D35]">
                <span className="text-[#888888] block mb-0.5">Rasgo de Cuello / Pelaje:</span>
                <span className="text-[#E0E0E0] font-medium">{state.anatomy.neckFeature}</span>
              </div>
            )}
            {state.anatomy.chestCore && state.anatomy.chestCore !== 'COR00 Ninguno (Torso Orgánico Estándar)' && (
              <div className="bg-[#181A20] p-3 rounded-xl border border-[#2A2D35]">
                <span className="text-[#888888] block mb-0.5">Núcleo en el Pecho:</span>
                <span className="text-[#C9A050] font-medium">{state.anatomy.chestCore}</span>
              </div>
            )}
            {state.hair.hairElemental && state.hair.hairElemental !== 'Cabello Orgánico Natural' && (
              <div className="bg-[#181A20] p-3 rounded-xl border border-[#2A2D35]">
                <span className="text-[#888888] block mb-0.5">Cabello Elemental:</span>
                <span className="text-[#C9A050] font-medium">{state.hair.hairElemental}</span>
              </div>
            )}
            {state.appendices.wingsType && state.appendices.wingsType !== 'Ninguno' && (
              <div className="bg-[#181A20] p-3 rounded-xl border border-[#2A2D35]">
                <span className="text-[#888888] block mb-0.5">Tipo de Alas:</span>
                <span className="text-[#E0E0E0] font-medium">{state.appendices.wingsType}</span>
              </div>
            )}
            {state.appendices.tailsType && state.appendices.tailsType !== 'Ninguno' && (
              <div className="bg-[#181A20] p-3 rounded-xl border border-[#2A2D35]">
                <span className="text-[#888888] block mb-0.5">Tipo de Cola:</span>
                <span className="text-[#E0E0E0] font-medium">{state.appendices.tailsType}</span>
              </div>
            )}
            {state.appendices.hornsForm && state.appendices.hornsForm !== 'Ninguno' && (
              <div className="bg-[#181A20] p-3 rounded-xl border border-[#2A2D35]">
                <span className="text-[#888888] block mb-0.5">Cuernos:</span>
                <span className="text-[#C9A050] font-medium">{state.appendices.hornsForm}</span>
              </div>
            )}
            {state.facial.kemonoEars && state.facial.kemonoEars !== 'Ninguno' && (
              <div className="bg-[#181A20] p-3 rounded-xl border border-[#2A2D35]">
                <span className="text-[#888888] block mb-0.5">Orejas Kemono:</span>
                <span className="text-[#C9A050] font-medium">{state.facial.kemonoEars}</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 🧬 HYBRID RACE MIXING TOOL */}
      <div className="mb-10">
        {isPrimaryEligible ? (
          <div className="bg-radial from-[#181224] to-[#0F1115] border-2 border-[#7C3AED]/40 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#2A223B]">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-[#7C3AED]/20 border border-[#7C3AED]/50 flex items-center justify-center text-[#A78BFA]">
                  <Dna className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-serif italic text-[#C4B5FD] font-bold flex items-center space-x-2">
                    <span>Mezcla de Razas para Híbridos Raciales</span>
                    <span className="text-[10px] font-sans px-2 py-0.5 rounded-full bg-[#7C3AED]/30 text-[#E9D5FF] uppercase tracking-wider font-semibold">
                      Matriz Compatible
                    </span>
                  </h3>
                  <p className="text-xs text-[#A1A1AA]">
                    Fusión genética multirracial disponible para linajes base <span className="text-[#E9D5FF] font-semibold">Humano (1.1)</span> y <span className="text-[#E9D5FF] font-semibold">Incubiformia / Súcubo / Íncubo (5.2)</span>.
                  </p>
                </div>
              </div>
              {state.isHybrid && (
                <button
                  type="button"
                  onClick={handleRemoveHybrid}
                  className="self-start sm:self-auto flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-[#24142D] border border-[#581C87] text-xs text-[#F472B6] hover:bg-[#3B0764] transition-all cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                  <span>Desactivar Híbrido (Pura Sangre)</span>
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Secondary Race Selection */}
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-[#E9D5FF] flex items-center justify-between mb-1">
                    <span>1. Selecciona la Raza Secundaria para el Cruce:</span>
                    <InfoTooltip text="Elige la especie con la que se cruza tu personaje base para heredar sus rasgos sobrenaturales." />
                  </label>
                  <select
                    value={selectedSecondaryId}
                    onChange={(e) => setSelectedSecondaryId(e.target.value)}
                    className="w-full bg-[#14121F] border border-[#4C1D95] rounded-xl p-3 text-xs text-[#F5F3FF] focus:border-[#A78BFA] outline-none"
                  >
                    {RACE_GROUPS.map((group) => (
                      <optgroup key={group.id} label={group.title}>
                        {group.races
                          .filter(r => r.id !== state.raceId)
                          .map(race => (
                            <option key={race.id} value={race.id}>
                              {race.id} - {race.name}
                            </option>
                          ))}
                      </optgroup>
                    ))}
                  </select>
                </div>

                {/* Dominance selection */}
                <div>
                  <label className="block text-xs font-semibold text-[#E9D5FF] mb-1.5">
                    2. Balance de Dominancia Genética:
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      '50/50 Híbrido Equilibrado',
                      '75/25 Dominancia Primaria',
                      '25/75 Dominancia Secundaria'
                    ].map(dom => {
                      const isSel = hybridDominance === dom;
                      return (
                        <button
                          key={dom}
                          type="button"
                          onClick={() => setHybridDominance(dom)}
                          className={`p-2.5 rounded-xl border text-center text-xs transition-all cursor-pointer ${
                            isSel
                              ? 'bg-[#3B0764] border-[#A78BFA] text-[#F5F3FF] font-semibold shadow-sm ring-1 ring-[#A78BFA]'
                              : 'bg-[#14121F] border-[#2A223B] text-[#A1A1AA] hover:text-[#E9D5FF]'
                          }`}
                        >
                          {dom.split(' ')[0]}
                          <span className="block text-[10px] text-[#A78BFA] font-normal">{dom.split(' ').slice(1).join(' ')}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Inherited Trait Selection */}
              <div className="space-y-3">
                <label className="block text-xs font-semibold text-[#E9D5FF]">
                  3. Rasgos a Heredar de la Raza Secundaria:
                </label>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <label className="flex items-center space-x-2 bg-[#14121F] border border-[#2A223B] p-2.5 rounded-xl cursor-pointer hover:border-[#7C3AED]">
                    <input
                      type="checkbox"
                      checked={hybridOptions.inheritAppendices}
                      onChange={(e) => setHybridOptions(prev => ({ ...prev, inheritAppendices: e.target.checked }))}
                      className="accent-[#7C3AED] rounded"
                    />
                    <span className="text-[#E0E0E0] text-[11px]">Apéndices (Alas, Colas, Cuernos, Orejas)</span>
                  </label>
                  <label className="flex items-center space-x-2 bg-[#14121F] border border-[#2A223B] p-2.5 rounded-xl cursor-pointer hover:border-[#7C3AED]">
                    <input
                      type="checkbox"
                      checked={hybridOptions.inheritFacialAndEyes}
                      onChange={(e) => setHybridOptions(prev => ({ ...prev, inheritFacialAndEyes: e.target.checked }))}
                      className="accent-[#7C3AED] rounded"
                    />
                    <span className="text-[#E0E0E0] text-[11px]">Rostro & Ojos (Esclerótica, Iris, Colmillos)</span>
                  </label>
                  <label className="flex items-center space-x-2 bg-[#14121F] border border-[#2A223B] p-2.5 rounded-xl cursor-pointer hover:border-[#7C3AED]">
                    <input
                      type="checkbox"
                      checked={hybridOptions.inheritSkinAndStructure}
                      onChange={(e) => setHybridOptions(prev => ({ ...prev, inheritSkinAndStructure: e.target.checked }))}
                      className="accent-[#7C3AED] rounded"
                    />
                    <span className="text-[#E0E0E0] text-[11px]">Piel, Escamas, Núcleo y Cuello</span>
                  </label>
                  <label className="flex items-center space-x-2 bg-[#14121F] border border-[#2A223B] p-2.5 rounded-xl cursor-pointer hover:border-[#7C3AED]">
                    <input
                      type="checkbox"
                      checked={hybridOptions.inheritHairElemental}
                      onChange={(e) => setHybridOptions(prev => ({ ...prev, inheritHairElemental: e.target.checked }))}
                      className="accent-[#7C3AED] rounded"
                    />
                    <span className="text-[#E0E0E0] text-[11px]">Cabello Elemental / Magia</span>
                  </label>
                </div>

                {/* Apply button */}
                <button
                  type="button"
                  onClick={handleApplyHybrid}
                  className="w-full mt-2 bg-gradient-to-r from-[#7C3AED] to-[#9333EA] hover:from-[#6D28D9] hover:to-[#7E22CE] text-white p-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 shadow-lg cursor-pointer transition-all active:scale-[0.99]"
                >
                  <Dna className="w-4 h-4" />
                  <span>{state.isHybrid ? 'Actualizar Fusión de Rasgos Híbridos' : '🧬 Aplicar Fusión de Rasgos al Personaje'}</span>
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-[#12141A] border border-[#2A2D35] rounded-2xl p-4 flex items-center space-x-3 text-xs text-[#888888]">
            <Info className="w-4 h-4 text-[#C9A050] flex-shrink-0" />
            <p>
              <strong className="text-[#C9A050]">Regla de Hibridación Racial:</strong> La mezcla genética multirracial está disponible seleccionando como raza primaria <strong className="text-[#E0E0E0]">Humanos (1.1)</strong> o <strong className="text-[#E0E0E0]">Incubiformia / Súcubo / Íncubo (5.2)</strong> debido a su maleabilidad biológica universal.
            </p>
          </div>
        )}
      </div>

      <div className="space-y-8">
        <div className="flex items-center space-x-2 my-4">
          <h3 className="text-xl font-serif italic text-[#C9A050] tracking-tight">
            1.0 Especie y Raza Base
          </h3>
        </div>

        {RACE_GROUPS.map((group) => (
          <div key={group.id} className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs">
            <div className="mb-4 pb-3 border-b border-[#222222]">
              <h3 className="text-lg font-serif italic text-[#C9A050]">
                {group.title} <InfoTooltip text={group.description} />
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {group.races.map((race) => {
                const isSelected = state.raceId === race.id;
                const preset = RACE_PRESET_TRAITS[race.id];
                return (
                  <div
                    key={race.id}
                    onClick={() => handleSelectRace(group.id, group.title, race.id, race.name)}
                    className={`p-4 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                      isSelected
                        ? 'bg-[#1A1C22] border-[#C9A050] shadow-md ring-1 ring-[#C9A050]'
                        : 'bg-[#15171C] border-[#2A2D35] hover:border-[#C9A050]/50'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-mono text-[#C9A050] px-2 py-0.5 rounded bg-[#0F1115] border border-[#2A2D35]">
                          {race.id}
                        </span>
                        {isSelected && <span className="text-xs font-semibold text-[#C9A050]">✓ Seleccionado</span>}
                      </div>
                      <h4 className="font-bold text-sm text-[#E0E0E0] mb-1">{race.name}</h4>
                      <p className="text-xs text-[#888888] leading-relaxed mb-3">{race.description}</p>
                      
                      {/* Key Peculiar Traits Pill Preview */}
                      {preset && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {preset.lowerBodyStructure && preset.lowerBodyStructure !== 'Bípedo Estándar (Dos Piernas)' && (
                            <span className="px-1.5 py-0.5 bg-[#C9A050]/10 border border-[#C9A050]/30 rounded text-[10px] text-[#C9A050]">
                              {preset.lowerBodyStructure.split(' ')[0]}
                            </span>
                          )}
                          {preset.chestCore && preset.chestCore !== 'Ninguno' && (
                            <span className="px-1.5 py-0.5 bg-[#C9A050]/10 border border-[#C9A050]/30 rounded text-[10px] text-[#C9A050]">
                              Núcleo Pecho
                            </span>
                          )}
                          {preset.neckFeature && preset.neckFeature !== 'Ninguno / Cuello Estándar' && (
                            <span className="px-1.5 py-0.5 bg-[#C9A050]/10 border border-[#C9A050]/30 rounded text-[10px] text-[#C9A050]">
                              Cuello Pelaje
                            </span>
                          )}
                          {preset.scleraColor && preset.scleraColor !== 'Blanco Estándar' && (
                            <span className="px-1.5 py-0.5 bg-[#C9A050]/10 border border-[#C9A050]/30 rounded text-[10px] text-[#C9A050]">
                              Escl. {preset.scleraColor.split(' ')[0]}
                            </span>
                          )}
                          {preset.hairElemental && preset.hairElemental !== 'Ninguno (Cabello Orgánico Normal)' && (
                            <span className="px-1.5 py-0.5 bg-[#C9A050]/10 border border-[#C9A050]/30 rounded text-[10px] text-[#C9A050]">
                              Pelo Elemental
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Footer next button */}
      <div className="mt-10 flex justify-end">
        <button
          onClick={onNext}
          disabled={!state.raceName}
          className="bg-[#C9A050] hover:bg-[#b58e45] disabled:opacity-50 text-[#0A0B0E] px-6 py-3 rounded-xl font-semibold text-sm flex items-center space-x-2 transition-all shadow-md cursor-pointer"
        >
          <span>Siguiente: Anatomía y Facial</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
