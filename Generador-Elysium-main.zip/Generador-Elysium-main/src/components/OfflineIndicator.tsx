import React from 'react';
import { WifiOff, Zap } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const OfflineIndicator: React.FC = () => {
  const { isOnline } = usePWAInstall();

  if (isOnline) return null;

  return (
    <div className="fixed bottom-4 left-4 z-50 flex items-center gap-2.5 rounded-2xl bg-[#141722]/95 border border-emerald-500/50 px-3.5 py-2 text-xs font-medium text-emerald-300 shadow-2xl backdrop-blur-md animate-fadeIn">
      <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
      <div className="flex items-center gap-1.5">
        <WifiOff className="w-3.5 h-3.5 text-emerald-400" />
        <span className="font-semibold text-white">Modo Offline Activo</span>
      </div>
      <span className="text-[#8A8F9E] text-[11px] hidden sm:inline border-l border-[#2B2F40] pl-2">
        Operando con memoria local y agentes autónomos
      </span>
    </div>
  );
};
