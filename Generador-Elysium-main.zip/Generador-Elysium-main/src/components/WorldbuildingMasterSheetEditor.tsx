import React, { useState, useEffect, useMemo } from 'react';
import {
  WorldBuildingConfig,
  WorldFaction,
  FactionRelationship,
  WorldSpecialLaw,
  WorldPlace,
  CharacterState
} from '../types';
import {
  getWorldBuildingConfig,
  saveWorldBuildingConfig,
  exportWorldBuildingJson
} from '../utils/worldStorage';
import { SUGGESTIONS_BANK, WorldPreset } from '../data/creationHubPresets';
import { syncWorldConfig, calculateWorldCompleteness } from './worldbuilding/worldSyncUtils';
import { WorldPresetModal } from './worldbuilding/WorldPresetModal';
import { WorldPillarsNav } from './worldbuilding/WorldPillarsNav';
import { WorldFactionsEditor } from './worldbuilding/WorldFactionsEditor';
import { WorldSpecialLawsEditor } from './worldbuilding/WorldSpecialLawsEditor';
import { WorldConsolidatedSheet } from './worldbuilding/WorldConsolidatedSheet';
import {
  ScrollText,
  Shield,
  Coins,
  Cpu,
  Sparkles,
  HeartHandshake,
  AlertTriangle,
  Layers,
  Scale,
  BookOpen,
  Ban,
  Save,
  Plus,
  Copy,
  Download,
  Upload,
  RotateCcw,
  CheckCircle2,
  ChevronRight,
  Compass,
  Wand2,
  Eye,
  Check
} from 'lucide-react';

interface WorldbuildingMasterSheetEditorProps {
  initialConfig?: WorldBuildingConfig | null;
  activePlace?: WorldPlace | null;
  characterState?: CharacterState | null;
  onSaved?: (config: WorldBuildingConfig) => void;
  onBackToLibrary?: () => void;
}

export const WorldbuildingMasterSheetEditor: React.FC<WorldbuildingMasterSheetEditorProps> = ({
  initialConfig,
  activePlace,
  characterState,
  onSaved,
  onBackToLibrary
}) => {
  const [worldConfig, setWorldConfig] = useState<WorldBuildingConfig>(() => {
    if (initialConfig) return syncWorldConfig(initialConfig);
    return syncWorldConfig(getWorldBuildingConfig());
  });

  useEffect(() => {
    if (initialConfig) {
      setWorldConfig(syncWorldConfig(initialConfig));
    }
  }, [initialConfig?.id]);

  const [activeCategory, setActiveCategory] = useState<number>(1);
  const [showConflictInspector, setShowConflictInspector] = useState(false);
  const [showPresetModal, setShowPresetModal] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3500);
  };

  // Porcentaje de completitud
  const completeness = useMemo(() => calculateWorldCompleteness(worldConfig), [worldConfig]);

  // Mapa de categorías completas
  const completenessByCat = useMemo(() => {
    return {
      1: Boolean(worldConfig.history?.origin && worldConfig.history?.eras),
      2: Boolean((worldConfig.geographyHierarchy?.continents?.length || 0) > 0),
      3: Boolean((worldConfig.politics?.factions?.length || 0) > 0),
      4: Boolean(worldConfig.economy?.currency),
      5: worldConfig.religionAndCulture?.isApplicable === false || Boolean((worldConfig.religionAndCulture?.religions?.length || 0) > 0),
      6: Boolean(worldConfig.technology?.level),
      7: worldConfig.magicSystem?.hasMagic === false || Boolean(worldConfig.magicSystem?.source),
      8: Boolean(worldConfig.physicalRules?.gravity && worldConfig.physicalRules?.healing),
      9: Boolean(worldConfig.socialRules?.hierarchies || (worldConfig.socialRules?.acceptedBehaviors?.length || 0) > 0),
      10: Boolean((worldConfig.specialLaws?.length || 0) > 0),
      11: Boolean((worldConfig.canon?.facts?.length || 0) > 0),
      12: Boolean((worldConfig.narrativeRestrictions?.forbiddenTech?.length || 0) > 0),
      13: true
    };
  }, [worldConfig]);

  // Acciones de Guardado y Gestión
  const handleSave = () => {
    const synced = syncWorldConfig(worldConfig);
    saveWorldBuildingConfig(synced);
    setWorldConfig(synced);
    if (onSaved) onSaved(synced);
    showNotification('¡Worldbuilding guardado y sincronizado con éxito!');
  };

  const handleSaveAsNewVersion = () => {
    const curVer = worldConfig.version || 'v1.0';
    const num = parseFloat(curVer.replace('v', '')) || 1.0;
    const nextVer = `v${(num + 0.1).toFixed(1)}`;
    const newConfig: WorldBuildingConfig = syncWorldConfig({
      ...worldConfig,
      id: `WORLD-${Date.now()}`,
      worldName: `${worldConfig.worldName} (${nextVer})`,
      version: nextVer
    });
    saveWorldBuildingConfig(newConfig);
    setWorldConfig(newConfig);
    if (onSaved) onSaved(newConfig);
    showNotification(`¡Guardado como nueva versión ${nextVer}!`);
  };

  const handleDuplicate = () => {
    const dup: WorldBuildingConfig = syncWorldConfig({
      ...JSON.parse(JSON.stringify(worldConfig)),
      id: `WORLD-${Date.now()}`,
      worldName: `${worldConfig.worldName} (Copia)`,
      version: 'v1.0'
    });
    saveWorldBuildingConfig(dup);
    setWorldConfig(dup);
    if (onSaved) onSaved(dup);
    showNotification('¡Mundo duplicado con éxito!');
  };

  const handleExportJson = () => {
    const jsonStr = exportWorldBuildingJson(syncWorldConfig(worldConfig));
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${(worldConfig.worldName || 'Mundo').replace(/\s+/g, '_')}_Worldbuilding.json`;
    a.click();
    URL.revokeObjectURL(url);
    showNotification('¡Archivo JSON de Worldbuilding exportado!');
  };

  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = evt => {
      try {
        const parsed = JSON.parse(evt.target?.result as string);
        if (parsed && typeof parsed === 'object') {
          const synced = syncWorldConfig({
            ...parsed,
            id: parsed.id || `WORLD-${Date.now()}`
          });
          setWorldConfig(synced);
          saveWorldBuildingConfig(synced);
          if (onSaved) onSaved(synced);
          showNotification('✓ ¡Ficha de Worldbuilding importada exitosamente!');
        }
      } catch (err) {
        showNotification('Error: El archivo JSON no tiene un formato válido.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleDiscardChanges = () => {
    const original = syncWorldConfig(getWorldBuildingConfig());
    setWorldConfig(original);
    showNotification('Cambios descartados. Se restauró el último estado guardado.');
  };

  const handleApplyPreset = (preset: WorldPreset) => {
    const merged: WorldBuildingConfig = syncWorldConfig({
      ...worldConfig,
      ...preset.config,
      id: worldConfig.id || `WORLD-${Date.now()}`,
      version: worldConfig.version || 'v1.0'
    });
    setWorldConfig(merged);
    showNotification(`✓ ¡Arquetipo "${preset.name}" cargado! Todas las categorías han sido configuradas.`);
  };

  return (
    <div className="space-y-6">
      {/* 1. CABECERA PRINCIPAL */}
      <div className="bg-[#11131A] border border-[#232632] rounded-3xl p-6 shadow-2xl space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
                <ScrollText className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300">
                    Worldbuilding • Reglas del Motor
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#1F232F] text-[#A0A5B5] border border-[#2D3242]">
                    {worldConfig.version || 'v1.0'}
                  </span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-950/40 text-emerald-300 border border-emerald-700/40">
                    {completeness}% Configurado
                  </span>
                </div>
                <div className="flex items-center gap-2 mt-1">
                  <input
                    type="text"
                    value={worldConfig.worldName}
                    onChange={e => setWorldConfig({ ...worldConfig, worldName: e.target.value })}
                    className="text-xl font-bold text-[#F3F4F6] bg-transparent border-b border-transparent hover:border-[#383E54] focus:border-emerald-500 outline-hidden transition-all"
                    placeholder="Nombre del Mundo..."
                  />
                </div>
              </div>
            </div>
            <p className="text-xs text-[#8A8F9E] mt-2 max-w-2xl leading-relaxed">
              Conjunto de reglas y leyes constitutivas que gobiernan la simulación interactiva, condicionan el comportamiento de los NPCs y restringen la generación narrativa.
            </p>
          </div>

          {/* Barra de Acciones */}
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setShowPresetModal(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 font-bold text-xs transition-all cursor-pointer shadow-sm"
              title="Cargar un arquetipo completo de mundo"
            >
              <Wand2 className="w-4 h-4 text-indigo-400" />
              <span>Arquetipos</span>
            </button>

            <button
              type="button"
              onClick={handleSave}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition-all cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Guardar</span>
            </button>

            <button
              type="button"
              onClick={handleSaveAsNewVersion}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#1A1D27] hover:bg-[#232736] border border-[#2F3446] text-[#E0E2EC] font-bold text-xs transition-all cursor-pointer"
              title="Guardar como nueva versión incremental"
            >
              <Plus className="w-3.5 h-3.5 text-emerald-400" />
              <span>Nueva Versión</span>
            </button>

            <button
              type="button"
              onClick={handleDuplicate}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#1A1D27] hover:bg-[#232736] border border-[#2F3446] text-[#A0A5B5] hover:text-[#F3F4F6] text-xs transition-all cursor-pointer"
              title="Duplicar este mundo"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>Duplicar</span>
            </button>

            <button
              type="button"
              onClick={handleExportJson}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#1A1D27] hover:bg-[#232736] border border-[#2F3446] text-[#A0A5B5] hover:text-[#F3F4F6] text-xs transition-all cursor-pointer"
              title="Descargar archivo JSON del mundo"
            >
              <Download className="w-3.5 h-3.5" />
              <span>JSON</span>
            </button>

            <label className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#1A1D27] hover:bg-[#232736] border border-[#2F3446] text-[#A0A5B5] hover:text-[#F3F4F6] text-xs transition-all cursor-pointer">
              <Upload className="w-3.5 h-3.5" />
              <span>Importar</span>
              <input type="file" accept=".json" onChange={handleImportJson} className="hidden" />
            </label>

            <button
              type="button"
              onClick={handleDiscardChanges}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#1A1D27] hover:bg-rose-950/40 border border-[#2F3446] text-[#8A8F9E] hover:text-rose-300 text-xs transition-all cursor-pointer"
              title="Descartar cambios no guardados"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Descartar</span>
            </button>
          </div>
        </div>

        {/* Barra de Progreso de Completitud */}
        <div className="space-y-1">
          <div className="flex items-center justify-between text-[11px] text-[#8A8F9E]">
            <span>Progreso de Especificación del Mundo:</span>
            <span className="font-mono text-emerald-400 font-bold">{completeness}%</span>
          </div>
          <div className="w-full h-1.5 bg-[#1C1F2B] rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-emerald-600 via-teal-500 to-amber-500 transition-all duration-500"
              style={{ width: `${completeness}%` }}
            />
          </div>
        </div>
      </div>

      {/* 2. ADVERTENCIA & SISTEMA DE PRIORIDADES */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        <div className="md:col-span-5 bg-amber-950/30 border border-amber-500/30 rounded-2xl p-4 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="text-xs text-amber-200/90 leading-relaxed">
            <strong className="text-amber-300 font-bold uppercase tracking-wider block mb-0.5">
              Regla Fundamental de Simulación
            </strong>
            El Worldbuilding no es meramente descriptivo: <strong>es parte activa del motor de simulación</strong> de Elysium. Afecta directamente las elecciones de los NPCs y las consecuencias de las tiradas.
          </div>
        </div>

        <div className="md:col-span-7 bg-[#12141C] border border-[#252836] rounded-2xl p-4 space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Scale className="w-4 h-4 text-[#D4AF37]" />
              <span className="text-xs font-bold uppercase tracking-wider text-[#F3F4F6]">
                Jerarquía de Prioridades del Motor
              </span>
            </div>
            <button
              type="button"
              onClick={() => setShowConflictInspector(!showConflictInspector)}
              className="text-[11px] font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer"
            >
              <span>{showConflictInspector ? 'Ocultar' : 'Ver'} Conflictos</span>
              <ChevronRight className={`w-3 h-3 transition-transform ${showConflictInspector ? 'rotate-90' : ''}`} />
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-1.5 text-[10px] font-mono text-[#A0A5B5] bg-[#171923] p-2 rounded-xl border border-[#232634]">
            <span className="px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 font-bold">1. CANON</span>
            <span className="text-gray-500">&gt;</span>
            <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold">2. LEYES ESPECIALES</span>
            <span className="text-gray-500">&gt;</span>
            <span className="px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 font-bold">3. REGLAS FÍSICAS</span>
            <span className="text-gray-500">&gt;</span>
            <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">4. REGLAS SOCIALES</span>
            <span className="text-gray-500">&gt;</span>
            <span className="px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 font-bold">5. CONFIGURACIÓN</span>
            <span className="text-gray-500">&gt;</span>
            <span className="px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-bold">6. ESCENARIO</span>
            <span className="text-gray-500">&gt;</span>
            <span className="px-1.5 py-0.5 rounded bg-gray-500/20 text-gray-300 font-bold">7. EVENTO</span>
          </div>

          {showConflictInspector && (
            <div className="pt-2 border-t border-[#232634] space-y-1.5 text-xs animate-in fade-in">
              <div className="p-2 rounded-lg bg-[#181B26] border border-[#2B2F3E] flex items-center justify-between">
                <div>
                  <span className="font-bold text-emerald-400 text-[11px]">✓ Coherencia de Leyes vs Facciones</span>
                  <p className="text-[10px] text-[#A0A5B5]">Las leyes activas de nivel 10 tienen primacía sobre las hostilidades locales.</p>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-700 text-emerald-300">
                  Consistente
                </span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Notificación temporal */}
      {notification && (
        <div className="flex items-center gap-2 p-3 bg-emerald-950/70 border border-emerald-600 text-emerald-300 rounded-2xl text-xs animate-in fade-in">
          <CheckCircle2 className="w-4 h-4" />
          <span>{notification}</span>
        </div>
      )}

      {/* 3. NAVEGACIÓN MODULAR DE LAS 12 CATEGORÍAS + FICHA CONSOLIDADA */}
      <WorldPillarsNav
        activeCategory={activeCategory}
        onSelectCategory={setActiveCategory}
        completenessByCat={completenessByCat}
      />

      {/* 4. FORMULARIOS DE LAS CATEGORÍAS */}
      <div className="bg-[#12141C] border border-[#262934] rounded-3xl p-6 shadow-xl text-xs space-y-6">

        {/* 01 HISTORIA DEL MUNDO */}
        {activeCategory === 1 && (
          <div className="space-y-4 animate-in fade-in">
            <h3 className="text-base font-bold text-[#F3F4F6] flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-emerald-400" />
              <span>01. Historia del Mundo & Cronología</span>
            </h3>

            <div className="space-y-4">
              <div>
                <label className="text-[#8A8F9E] block mb-1 font-bold">Origen o Creación Cosmogónica:</label>
                <textarea
                  rows={3}
                  value={worldConfig.history?.origin || ''}
                  onChange={e => setWorldConfig({
                    ...worldConfig,
                    history: { ...(worldConfig.history || { origin: '', eras: '', keyEvents: [], wars: [], catastrophes: [], politicalChanges: [], fundamentalEvents: [] }), origin: e.target.value }
                  })}
                  placeholder="Cómo se originó el mundo, los dioses creadores o el cataclismo primigenio..."
                  className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl p-3 text-[#E0E2EC] outline-hidden focus:border-emerald-500/50"
                />
              </div>

              <div>
                <label className="text-[#8A8F9E] block mb-1 font-bold">Eras Cronológicas:</label>
                <input
                  type="text"
                  value={worldConfig.history?.eras || ''}
                  onChange={e => setWorldConfig({
                    ...worldConfig,
                    history: { ...(worldConfig.history || { origin: '', eras: '', keyEvents: [], wars: [], catastrophes: [], politicalChanges: [], fundamentalEvents: [] }), eras: e.target.value }
                  })}
                  placeholder="Era del Génesis → Era de los Reyes → Fractura → Era Actual..."
                  className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden focus:border-emerald-500/50"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-[#8A8F9E] block mb-1 font-bold">Guerras Históricas (Separadas por comas):</label>
                  <input
                    type="text"
                    value={(worldConfig.history?.wars || []).join(', ')}
                    onChange={e => setWorldConfig({
                      ...worldConfig,
                      history: { ...(worldConfig.history || { origin: '', eras: '', keyEvents: [], wars: [], catastrophes: [], politicalChanges: [], fundamentalEvents: [] }), wars: e.target.value.split(',').map(s => s.trim()).filter(Boolean) }
                    })}
                    placeholder="Guerra de los Cien Velos, Purga de la Sangre Impura..."
                    className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
                  />
                </div>

                <div>
                  <label className="text-[#8A8F9E] block mb-1 font-bold">Catástrofes Históricas (Separadas por comas):</label>
                  <input
                    type="text"
                    value={(worldConfig.history?.catastrophes || []).join(', ')}
                    onChange={e => setWorldConfig({
                      ...worldConfig,
                      history: { ...(worldConfig.history || { origin: '', eras: '', keyEvents: [], wars: [], catastrophes: [], politicalChanges: [], fundamentalEvents: [] }), catastrophes: e.target.value.split(',').map(s => s.trim()).filter(Boolean) }
                    })}
                    placeholder="El Gran Colapso, La Sequía de Maná, El Virus Neural..."
                    className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 02 GEOGRAFÍA */}
        {activeCategory === 2 && (
          <div className="space-y-4 animate-in fade-in">
            <h3 className="text-base font-bold text-[#F3F4F6] flex items-center gap-2">
              <Compass className="w-5 h-5 text-emerald-400" />
              <span>02. Geografía & Jerarquía Territorial</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-[#8A8F9E] block mb-1 font-bold">Continentes (Separados por comas):</label>
                <input
                  type="text"
                  value={(worldConfig.geographyHierarchy?.continents || []).join(', ')}
                  onChange={e => setWorldConfig({
                    ...worldConfig,
                    geographyHierarchy: {
                      ...(worldConfig.geographyHierarchy || { continents: [], countries: [], regions: [], cities: [], climates: [], resources: [], specialZones: [], hierarchy: [] }),
                      continents: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                    }
                  })}
                  className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
                />
              </div>
              <div>
                <label className="text-[#8A8F9E] block mb-1 font-bold">Países / Reinos (Separados por comas):</label>
                <input
                  type="text"
                  value={(worldConfig.geographyHierarchy?.countries || []).join(', ')}
                  onChange={e => setWorldConfig({
                    ...worldConfig,
                    geographyHierarchy: {
                      ...(worldConfig.geographyHierarchy || { continents: [], countries: [], regions: [], cities: [], climates: [], resources: [], specialZones: [], hierarchy: [] }),
                      countries: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                    }
                  })}
                  className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
                />
              </div>
              <div>
                <label className="text-[#8A8F9E] block mb-1 font-bold">Ciudades Notables (Separadas por comas):</label>
                <input
                  type="text"
                  value={(worldConfig.geographyHierarchy?.cities || []).join(', ')}
                  onChange={e => setWorldConfig({
                    ...worldConfig,
                    geographyHierarchy: {
                      ...(worldConfig.geographyHierarchy || { continents: [], countries: [], regions: [], cities: [], climates: [], resources: [], specialZones: [], hierarchy: [] }),
                      cities: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                    }
                  })}
                  className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
                />
              </div>
            </div>

            {/* Climas y Sugerencias */}
            <div className="space-y-2 pt-2">
              <label className="text-[#8A8F9E] block font-bold">Climas Predominantes:</label>
              <div className="flex flex-wrap gap-1.5 mb-2">
                {SUGGESTIONS_BANK.worldClimates.map((climate, i) => {
                  const currentList = worldConfig.geographyHierarchy?.climates || [];
                  const isSelected = currentList.includes(climate);
                  return (
                    <button
                      key={i}
                      type="button"
                      onClick={() => {
                        const updated = isSelected
                          ? currentList.filter(c => c !== climate)
                          : [...currentList, climate];
                        setWorldConfig({
                          ...worldConfig,
                          geographyHierarchy: {
                            ...(worldConfig.geographyHierarchy || { continents: [], countries: [], regions: [], cities: [], climates: [], resources: [], specialZones: [], hierarchy: [] }),
                            climates: updated
                          }
                        });
                      }}
                      className={`text-[10px] px-2.5 py-1 rounded-lg border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 font-bold'
                          : 'bg-[#181B26] text-[#8A8F9E] border-[#2B2F3D] hover:text-[#E0E2EC]'
                      }`}
                    >
                      {isSelected ? '✓ ' : '+ '}
                      {climate}
                    </button>
                  );
                })}
              </div>
              <input
                type="text"
                value={(worldConfig.geographyHierarchy?.climates || []).join(', ')}
                onChange={e => setWorldConfig({
                  ...worldConfig,
                  geographyHierarchy: {
                    ...(worldConfig.geographyHierarchy || { continents: [], countries: [], regions: [], cities: [], climates: [], resources: [], specialZones: [], hierarchy: [] }),
                    climates: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                  }
                })}
                placeholder="Personalizar climas..."
                className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
              />
            </div>

            {/* Recursos Estratégicos */}
            <div className="space-y-2 pt-2">
              <label className="text-[#8A8F9E] block font-bold">Recursos Naturales & Estratégicos:</label>
              <div className="flex flex-wrap gap-1.5 mb-2">
                {SUGGESTIONS_BANK.worldResources.map((res, i) => {
                  const currentList = worldConfig.geographyHierarchy?.resources || [];
                  const isSelected = currentList.includes(res);
                  return (
                    <button
                      key={i}
                      type="button"
                      onClick={() => {
                        const updated = isSelected
                          ? currentList.filter(c => c !== res)
                          : [...currentList, res];
                        setWorldConfig({
                          ...worldConfig,
                          geographyHierarchy: {
                            ...(worldConfig.geographyHierarchy || { continents: [], countries: [], regions: [], cities: [], climates: [], resources: [], specialZones: [], hierarchy: [] }),
                            resources: updated
                          }
                        });
                      }}
                      className={`text-[10px] px-2.5 py-1 rounded-lg border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 font-bold'
                          : 'bg-[#181B26] text-[#8A8F9E] border-[#2B2F3D] hover:text-[#E0E2EC]'
                      }`}
                    >
                      {isSelected ? '✓ ' : '+ '}
                      {res}
                    </button>
                  );
                })}
              </div>
              <input
                type="text"
                value={(worldConfig.geographyHierarchy?.resources || []).join(', ')}
                onChange={e => setWorldConfig({
                  ...worldConfig,
                  geographyHierarchy: {
                    ...(worldConfig.geographyHierarchy || { continents: [], countries: [], regions: [], cities: [], climates: [], resources: [], specialZones: [], hierarchy: [] }),
                    resources: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                  }
                })}
                placeholder="Personalizar recursos..."
                className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
              />
            </div>
          </div>
        )}

        {/* 03 POLÍTICA & FACCIONES */}
        {activeCategory === 3 && (
          <div className="space-y-4 animate-in fade-in">
            <h3 className="text-base font-bold text-[#F3F4F6] flex items-center gap-2">
              <Shield className="w-5 h-5 text-emerald-400" />
              <span>03. Política, Facciones & Diplomacia</span>
            </h3>

            <WorldFactionsEditor
              governments={worldConfig.politics?.governments || []}
              conflicts={worldConfig.politics?.conflicts || []}
              factions={worldConfig.politics?.factions || []}
              relationships={worldConfig.politics?.relationships || []}
              onUpdateGovernments={governments => setWorldConfig({
                ...worldConfig,
                politics: { ...(worldConfig.politics || { governments: [], factions: [], organizations: [], relationships: [], conflicts: [], hierarchies: [] }), governments }
              })}
              onUpdateConflicts={conflicts => setWorldConfig({
                ...worldConfig,
                politics: { ...(worldConfig.politics || { governments: [], factions: [], organizations: [], relationships: [], conflicts: [], hierarchies: [] }), conflicts }
              })}
              onUpdateFactions={factions => {
                setWorldConfig({
                  ...worldConfig,
                  factions,
                  politics: { ...(worldConfig.politics || { governments: [], factions: [], organizations: [], relationships: [], conflicts: [], hierarchies: [] }), factions }
                });
              }}
              onUpdateRelationships={relationships => setWorldConfig({
                ...worldConfig,
                politics: { ...(worldConfig.politics || { governments: [], factions: [], organizations: [], relationships: [], conflicts: [], hierarchies: [] }), relationships }
              })}
            />
          </div>
        )}

        {/* 04 ECONOMÍA */}
        {activeCategory === 4 && (
          <div className="space-y-4 animate-in fade-in">
            <h3 className="text-base font-bold text-[#F3F4F6] flex items-center gap-2">
              <Coins className="w-5 h-5 text-emerald-400" />
              <span>04. Economía & Mercados</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-[#8A8F9E] block font-bold">Moneda / Divisas Oficiales:</label>
                <div className="flex flex-wrap gap-1.5 mb-2">
                  {SUGGESTIONS_BANK.worldCurrencies.map((cur, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setWorldConfig({
                        ...worldConfig,
                        economy: { ...(worldConfig.economy || { currency: '', resources: [], trade: '', markets: [], keyGoods: [], scarcity: [], wealth: '', systems: [] }), currency: cur }
                      })}
                      className="text-[10px] px-2 py-0.5 rounded bg-[#181A24] border border-[#2A2E3D] text-[#A0A5B5] hover:text-emerald-300 hover:border-emerald-500/40 cursor-pointer"
                    >
                      {cur}
                    </button>
                  ))}
                </div>
                <input
                  type="text"
                  value={worldConfig.economy?.currency || ''}
                  onChange={e => setWorldConfig({
                    ...worldConfig,
                    economy: { ...(worldConfig.economy || { currency: '', resources: [], trade: '', markets: [], keyGoods: [], scarcity: [], wealth: '', systems: [] }), currency: e.target.value }
                  })}
                  className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
                />
              </div>

              <div>
                <label className="text-[#8A8F9E] block mb-1 font-bold">Rutas de Comercio & Logística:</label>
                <input
                  type="text"
                  value={worldConfig.economy?.trade || ''}
                  onChange={e => setWorldConfig({
                    ...worldConfig,
                    economy: { ...(worldConfig.economy || { currency: '', resources: [], trade: '', markets: [], keyGoods: [], scarcity: [], wealth: '', systems: [] }), trade: e.target.value }
                  })}
                  placeholder="Caravanas del desierto, barcazas fluviales, redes P2P..."
                  className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div>
                <label className="text-[#8A8F9E] block mb-1 font-bold">Bienes de Alto Valor / Mercados:</label>
                <input
                  type="text"
                  value={(worldConfig.economy?.keyGoods || []).join(', ')}
                  onChange={e => setWorldConfig({
                    ...worldConfig,
                    economy: {
                      ...(worldConfig.economy || { currency: '', resources: [], trade: '', markets: [], keyGoods: [], scarcity: [], wealth: '', systems: [] }),
                      keyGoods: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                    }
                  })}
                  placeholder="Seda, cristales de maná, armas de acero..."
                  className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
                />
              </div>
              <div>
                <label className="text-[#8A8F9E] block mb-1 font-bold">Bienes Escasos / Carestías:</label>
                <input
                  type="text"
                  value={(worldConfig.economy?.scarcity || []).join(', ')}
                  onChange={e => setWorldConfig({
                    ...worldConfig,
                    economy: {
                      ...(worldConfig.economy || { currency: '', resources: [], trade: '', markets: [], keyGoods: [], scarcity: [], wealth: '', systems: [] }),
                      scarcity: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                    }
                  })}
                  placeholder="Agua dulce, madera noble, antibióticos..."
                  className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
                />
              </div>
            </div>
          </div>
        )}

        {/* 05 RELIGIÓN / CULTURA */}
        {activeCategory === 5 && (
          <div className="space-y-4 animate-in fade-in">
            <div className="flex items-center justify-between border-b border-[#222530] pb-3">
              <h3 className="text-base font-bold text-[#F3F4F6] flex items-center gap-2">
                <HeartHandshake className="w-5 h-5 text-emerald-400" />
                <span>05. Religión & Cultura (Opcional / Conmutable)</span>
              </h3>
              <label className="flex items-center gap-2 font-bold cursor-pointer bg-[#1A1D27] px-3 py-1.5 rounded-xl border border-[#2F3446]">
                <input
                  type="checkbox"
                  checked={worldConfig.religionAndCulture?.isApplicable ?? true}
                  onChange={e => setWorldConfig({
                    ...worldConfig,
                    religionAndCulture: {
                      ...(worldConfig.religionAndCulture || { isApplicable: true, religions: [], traditions: [], customs: [], festivities: [], taboos: [], values: [], culturalNorms: [] }),
                      isApplicable: e.target.checked
                    }
                  })}
                  className="accent-emerald-500 rounded"
                />
                <span className="text-[#E0E2EC]">Aplica a este mundo</span>
              </label>
            </div>

            {worldConfig.religionAndCulture?.isApplicable !== false ? (
              <div className="space-y-4">
                <div>
                  <label className="text-[#8A8F9E] block mb-1 font-bold">Religiones & Cultos (Separados por comas):</label>
                  <input
                    type="text"
                    value={(worldConfig.religionAndCulture?.religions || []).join(', ')}
                    onChange={e => setWorldConfig({
                      ...worldConfig,
                      religionAndCulture: {
                        ...(worldConfig.religionAndCulture || { isApplicable: true, religions: [], traditions: [], customs: [], festivities: [], taboos: [], values: [], culturalNorms: [] }),
                        religions: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                      }
                    })}
                    placeholder="Culto a las Tres Lunas, Orden de la Llama Santa..."
                    className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
                  />
                </div>

                {/* Tabúes y Sugerencias */}
                <div className="space-y-2">
                  <label className="text-[#8A8F9E] block font-bold">Tabúes & Prohibiciones Morales Innegociables:</label>
                  <div className="flex flex-wrap gap-1.5 mb-2">
                    {SUGGESTIONS_BANK.tabooOptions.map((taboo, i) => {
                      const current = worldConfig.religionAndCulture?.taboos || [];
                      const isSelected = current.includes(taboo);
                      return (
                        <button
                          key={i}
                          type="button"
                          onClick={() => {
                            const updated = isSelected ? current.filter(t => t !== taboo) : [...current, taboo];
                            setWorldConfig({
                              ...worldConfig,
                              religionAndCulture: {
                                ...(worldConfig.religionAndCulture || { isApplicable: true, religions: [], traditions: [], customs: [], festivities: [], taboos: [], values: [], culturalNorms: [] }),
                                taboos: updated
                              }
                            });
                          }}
                          className={`text-[10px] px-2 py-0.5 rounded border transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-rose-500/20 text-rose-300 border-rose-500/50 font-bold'
                              : 'bg-[#181A24] text-[#8A8F9E] border-[#2A2E3D] hover:text-[#E0E2EC]'
                          }`}
                        >
                          {isSelected ? '✓ ' : '+ '}
                          {taboo}
                        </button>
                      );
                    })}
                  </div>
                  <input
                    type="text"
                    value={(worldConfig.religionAndCulture?.taboos || []).join(', ')}
                    onChange={e => setWorldConfig({
                      ...worldConfig,
                      religionAndCulture: {
                        ...(worldConfig.religionAndCulture || { isApplicable: true, religions: [], traditions: [], customs: [], festivities: [], taboos: [], values: [], culturalNorms: [] }),
                        taboos: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                      }
                    })}
                    placeholder="Personalizar tabúes..."
                    className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
                  />
                </div>

                {/* Tradiciones y Sugerencias */}
                <div className="space-y-2">
                  <label className="text-[#8A8F9E] block font-bold">Tradiciones & Rituales de Convivencia:</label>
                  <div className="flex flex-wrap gap-1.5 mb-2">
                    {SUGGESTIONS_BANK.traditionOptions.map((trad, i) => {
                      const current = worldConfig.religionAndCulture?.traditions || [];
                      const isSelected = current.includes(trad);
                      return (
                        <button
                          key={i}
                          type="button"
                          onClick={() => {
                            const updated = isSelected ? current.filter(t => t !== trad) : [...current, trad];
                            setWorldConfig({
                              ...worldConfig,
                              religionAndCulture: {
                                ...(worldConfig.religionAndCulture || { isApplicable: true, religions: [], traditions: [], customs: [], festivities: [], taboos: [], values: [], culturalNorms: [] }),
                                traditions: updated
                              }
                            });
                          }}
                          className={`text-[10px] px-2 py-0.5 rounded border transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 font-bold'
                              : 'bg-[#181A24] text-[#8A8F9E] border-[#2A2E3D] hover:text-[#E0E2EC]'
                          }`}
                        >
                          {isSelected ? '✓ ' : '+ '}
                          {trad}
                        </button>
                      );
                    })}
                  </div>
                  <input
                    type="text"
                    value={(worldConfig.religionAndCulture?.traditions || []).join(', ')}
                    onChange={e => setWorldConfig({
                      ...worldConfig,
                      religionAndCulture: {
                        ...(worldConfig.religionAndCulture || { isApplicable: true, religions: [], traditions: [], customs: [], festivities: [], taboos: [], values: [], culturalNorms: [] }),
                        traditions: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                      }
                    })}
                    placeholder="Personalizar tradiciones..."
                    className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
                  />
                </div>
              </div>
            ) : (
              <p className="text-center py-6 text-[#8A8F9E]">
                Categoría marcada como <strong>NO APLICA</strong> en este mundo. Los acontecimientos no generarán dinámicas religiosas ni morales eclesiásticas.
              </p>
            )}
          </div>
        )}

        {/* 06 TECNOLOGÍA */}
        {activeCategory === 6 && (
          <div className="space-y-4 animate-in fade-in">
            <h3 className="text-base font-bold text-[#F3F4F6] flex items-center gap-2">
              <Cpu className="w-5 h-5 text-emerald-400" />
              <span>06. Nivel Tecnológico & Restricciones</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-[#8A8F9E] block mb-1 font-bold">Nivel Tecnológico Global:</label>
                <select
                  value={worldConfig.technology?.level || 'Medieval'}
                  onChange={e => setWorldConfig({
                    ...worldConfig,
                    technology: {
                      ...(worldConfig.technology || { level: 'Medieval', allowedTech: [], forbiddenTech: [] }),
                      level: e.target.value as any
                    }
                  })}
                  className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden focus:border-emerald-500/50"
                >
                  {SUGGESTIONS_BANK.techLevels.map(lvl => (
                    <option key={lvl} value={lvl}>{lvl}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[#8A8F9E] block mb-1 font-bold">Tecnologías Permitidas (Separadas por comas):</label>
                <input
                  type="text"
                  value={(worldConfig.technology?.allowedTech || []).join(', ')}
                  onChange={e => setWorldConfig({
                    ...worldConfig,
                    technology: {
                      ...(worldConfig.technology || { level: 'Medieval', allowedTech: [], forbiddenTech: [] }),
                      allowedTech: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                    }
                  })}
                  placeholder="Forja de acero, molinos de viento, acueductos..."
                  className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
                />
              </div>
            </div>

            {/* Tecnologías Prohibidas con Chips */}
            <div className="space-y-2 pt-2">
              <label className="text-rose-400 block font-bold">
                Tecnologías Prohibidas (El motor censurará su aparición):
              </label>
              <div className="flex flex-wrap gap-1.5 mb-2">
                {SUGGESTIONS_BANK.forbiddenTechOptions.map((ftech, i) => {
                  const current = worldConfig.technology?.forbiddenTech || [];
                  const isSelected = current.includes(ftech);
                  return (
                    <button
                      key={i}
                      type="button"
                      onClick={() => {
                        const updated = isSelected ? current.filter(f => f !== ftech) : [...current, ftech];
                        setWorldConfig({
                          ...worldConfig,
                          technology: {
                            ...(worldConfig.technology || { level: 'Medieval', allowedTech: [], forbiddenTech: [] }),
                            forbiddenTech: updated
                          }
                        });
                      }}
                      className={`text-[10px] px-2.5 py-1 rounded-lg border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-rose-500/20 text-rose-300 border-rose-500/50 font-bold'
                          : 'bg-[#181A24] text-[#8A8F9E] border-[#2A2E3D] hover:text-[#E0E2EC]'
                      }`}
                    >
                      {isSelected ? '✓ Prohibida: ' : '+ Prohibir: '}
                      {ftech}
                    </button>
                  );
                })}
              </div>
              <input
                type="text"
                value={(worldConfig.technology?.forbiddenTech || []).join(', ')}
                onChange={e => setWorldConfig({
                  ...worldConfig,
                  technology: {
                    ...(worldConfig.technology || { level: 'Medieval', allowedTech: [], forbiddenTech: [] }),
                    forbiddenTech: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                  }
                })}
                placeholder="Pólvora, Teléfonos, IA, Armamento de fuego..."
                className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
              />
            </div>
          </div>
        )}

        {/* 07 MAGIA */}
        {activeCategory === 7 && (
          <div className="space-y-4 animate-in fade-in">
            <div className="flex items-center justify-between border-b border-[#222530] pb-3">
              <h3 className="text-base font-bold text-[#F3F4F6] flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-emerald-400" />
                <span>07. Sistema de Magia</span>
              </h3>
              <div className="flex items-center gap-4">
                <label className="flex items-center gap-2 font-bold cursor-pointer bg-[#1A1D27] px-3 py-1.5 rounded-xl border border-[#2F3446]">
                  <input
                    type="checkbox"
                    checked={worldConfig.magicSystem?.hasMagic ?? true}
                    onChange={e => setWorldConfig({
                      ...worldConfig,
                      magicSystem: {
                        ...(worldConfig.magicSystem || { hasMagic: true, source: '', rules: [], limitations: [], cost: '', users: '', types: [], effects: [], restrictions: [] }),
                        hasMagic: e.target.checked
                      }
                    })}
                    className="accent-emerald-500 rounded"
                  />
                  <span className="text-[#E0E2EC]">¿Existe Magia en el Mundo?</span>
                </label>
              </div>
            </div>

            {worldConfig.magicSystem?.hasMagic !== false ? (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[#8A8F9E] block mb-1 font-bold">Fuente del Poder Mágico:</label>
                    <input
                      type="text"
                      value={worldConfig.magicSystem?.source || ''}
                      onChange={e => setWorldConfig({
                        ...worldConfig,
                        magicSystem: { ...(worldConfig.magicSystem || { hasMagic: true, source: '', rules: [], limitations: [], cost: '', users: '', types: [], effects: [], restrictions: [] }), source: e.target.value }
                      })}
                      placeholder="Manantiales cósmicos, sangre de dragón, radiación estelar..."
                      className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
                    />
                  </div>
                  <div>
                    <label className="text-[#8A8F9E] block mb-1 font-bold">Usuarios Autorizados / Portadores:</label>
                    <input
                      type="text"
                      value={worldConfig.magicSystem?.users || ''}
                      onChange={e => setWorldConfig({
                        ...worldConfig,
                        magicSystem: { ...(worldConfig.magicSystem || { hasMagic: true, source: '', rules: [], limitations: [], cost: '', users: '', types: [], effects: [], restrictions: [] }), users: e.target.value }
                      })}
                      placeholder="Sacerdotisas del Velo, Magos de Academia..."
                      className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
                    />
                  </div>
                </div>

                {/* Coste de la Magia con Sugerencias */}
                <div className="space-y-2">
                  <label className="text-[#8A8F9E] block font-bold">Coste & Consecuencias del Uso Mágico:</label>
                  <div className="flex flex-wrap gap-1.5 mb-2">
                    {SUGGESTIONS_BANK.magicCosts.map((cost, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => setWorldConfig({
                          ...worldConfig,
                          magicSystem: { ...(worldConfig.magicSystem || { hasMagic: true, source: '', rules: [], limitations: [], cost: '', users: '', types: [], effects: [], restrictions: [] }), cost }
                        })}
                        className="text-[10px] px-2 py-0.5 rounded bg-[#181A24] border border-[#2A2E3D] text-[#A0A5B5] hover:text-amber-300 hover:border-amber-500/40 cursor-pointer"
                      >
                        {cost}
                      </button>
                    ))}
                  </div>
                  <input
                    type="text"
                    value={worldConfig.magicSystem?.cost || ''}
                    onChange={e => setWorldConfig({
                      ...worldConfig,
                      magicSystem: { ...(worldConfig.magicSystem || { hasMagic: true, source: '', rules: [], limitations: [], cost: '', users: '', types: [], effects: [], restrictions: [] }), cost: e.target.value }
                    })}
                    placeholder="Personalizar coste..."
                    className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
                  />
                </div>

                {/* Escuelas y Tipos */}
                <div className="space-y-2">
                  <label className="text-[#8A8F9E] block font-bold">Escuelas / Tipos de Magia Permitidos:</label>
                  <div className="flex flex-wrap gap-1.5 mb-2">
                    {SUGGESTIONS_BANK.magicSchools.map((school, i) => {
                      const current = worldConfig.magicSystem?.types || [];
                      const isSelected = current.includes(school);
                      return (
                        <button
                          key={i}
                          type="button"
                          onClick={() => {
                            const updated = isSelected ? current.filter(s => s !== school) : [...current, school];
                            setWorldConfig({
                              ...worldConfig,
                              magicSystem: {
                                ...(worldConfig.magicSystem || { hasMagic: true, source: '', rules: [], limitations: [], cost: '', users: '', types: [], effects: [], restrictions: [] }),
                                types: updated
                              }
                            });
                          }}
                          className={`text-[10px] px-2.5 py-1 rounded-lg border transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 font-bold'
                              : 'bg-[#181A24] text-[#8A8F9E] border-[#2A2E3D] hover:text-[#E0E2EC]'
                          }`}
                        >
                          {isSelected ? '✓ ' : '+ '}
                          {school}
                        </button>
                      );
                    })}
                  </div>
                  <input
                    type="text"
                    value={(worldConfig.magicSystem?.types || []).join(', ')}
                    onChange={e => setWorldConfig({
                      ...worldConfig,
                      magicSystem: {
                        ...(worldConfig.magicSystem || { hasMagic: true, source: '', rules: [], limitations: [], cost: '', users: '', types: [], effects: [], restrictions: [] }),
                        types: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                      }
                    })}
                    placeholder="Personalizar escuelas..."
                    className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
                  />
                </div>
              </div>
            ) : (
              <p className="text-center py-6 text-[#8A8F9E]">
                La magia está <strong>DESHABILITADA</strong> en este mundo. Todas las resoluciones se resolverán mediante leyes físicas y habilidades mundanas.
              </p>
            )}
          </div>
        )}

        {/* 08 REGLAS FÍSICAS */}
        {activeCategory === 8 && (
          <div className="space-y-4 animate-in fade-in">
            <h3 className="text-base font-bold text-[#F3F4F6] flex items-center gap-2">
              <Layers className="w-5 h-5 text-emerald-400" />
              <span>08. Reglas Físicas (Tienen Prioridad sobre Acontecimientos)</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-[#8A8F9E] block mb-1 font-bold">Gravedad & Entorno:</label>
                <input
                  type="text"
                  value={worldConfig.physicalRules?.gravity || '1.0G'}
                  onChange={e => setWorldConfig({
                    ...worldConfig,
                    physicalRules: { ...(worldConfig.physicalRules || { gravity: '1.0G', biology: '', healing: '', death: '', travel: '', time: '', space: '', energy: '', supernaturalPhenomena: '' }), gravity: e.target.value }
                  })}
                  className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
                />
              </div>

              <div>
                <label className="text-[#8A8F9E] block mb-1 font-bold">Viaje & Transporte:</label>
                <input
                  type="text"
                  value={worldConfig.physicalRules?.travel || ''}
                  onChange={e => setWorldConfig({
                    ...worldConfig,
                    physicalRules: { ...(worldConfig.physicalRules || { gravity: '1.0G', biology: '', healing: '', death: '', travel: '', time: '', space: '', energy: '', supernaturalPhenomena: '' }), travel: e.target.value }
                  })}
                  placeholder="A pie, monturas acorazadas, carretas, monorriel..."
                  className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
                />
              </div>

              <div>
                <label className="text-[#8A8F9E] block mb-1 font-bold">Biología & Curación de Heridas:</label>
                <textarea
                  rows={2}
                  value={worldConfig.physicalRules?.healing || ''}
                  onChange={e => setWorldConfig({
                    ...worldConfig,
                    physicalRules: { ...(worldConfig.physicalRules || { gravity: '1.0G', biology: '', healing: '', death: '', travel: '', time: '', space: '', energy: '', supernaturalPhenomena: '' }), healing: e.target.value }
                  })}
                  placeholder="Velocidad de recuperación, secuelas, apósitos o infusiones..."
                  className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl p-2.5 text-[#E0E2EC] outline-hidden"
                />
              </div>

              <div>
                <label className="text-[#8A8F9E] block mb-1 font-bold">Muerte & Reversibilidad:</label>
                <textarea
                  rows={2}
                  value={worldConfig.physicalRules?.death || ''}
                  onChange={e => setWorldConfig({
                    ...worldConfig,
                    physicalRules: { ...(worldConfig.physicalRules || { gravity: '1.0G', biology: '', healing: '', death: '', travel: '', time: '', space: '', energy: '', supernaturalPhenomena: '' }), death: e.target.value }
                  })}
                  placeholder="La muerte es definitiva e irreversible, o existen copias de seguridad corticales..."
                  className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl p-2.5 text-[#E0E2EC] outline-hidden"
                />
              </div>
            </div>
          </div>
        )}

        {/* 09 REGLAS SOCIALES */}
        {activeCategory === 9 && (
          <div className="space-y-4 animate-in fade-in">
            <h3 className="text-base font-bold text-[#F3F4F6] flex items-center gap-2">
              <HeartHandshake className="w-5 h-5 text-emerald-400" />
              <span>09. Reglas Sociales & Protocolos</span>
            </h3>

            <div className="space-y-4">
              <div>
                <label className="text-[#8A8F9E] block mb-1 font-bold">Jerarquías Sociales:</label>
                <input
                  type="text"
                  value={worldConfig.socialRules?.hierarchies || ''}
                  onChange={e => setWorldConfig({
                    ...worldConfig,
                    socialRules: {
                      ...(worldConfig.socialRules || { hierarchies: '', customs: '', familyRelations: '', socialNorms: '', acceptedBehaviors: [], rejectedBehaviors: [], protocols: [], socialRoles: [] }),
                      hierarchies: e.target.value
                    }
                  })}
                  placeholder="Sacerdotes > Guardianes > Ciudadanos > Viajeros..."
                  className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-[#8A8F9E] block mb-1 font-bold">Conductas Aceptadas / Virtuosas:</label>
                  <input
                    type="text"
                    value={(worldConfig.socialRules?.acceptedBehaviors || []).join(', ')}
                    onChange={e => setWorldConfig({
                      ...worldConfig,
                      socialRules: {
                        ...(worldConfig.socialRules || { hierarchies: '', customs: '', familyRelations: '', socialNorms: '', acceptedBehaviors: [], rejectedBehaviors: [], protocols: [], socialRoles: [] }),
                        acceptedBehaviors: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                      }
                    })}
                    placeholder="Hospitalidad sagrada, valor sin jactancia..."
                    className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
                  />
                </div>

                <div>
                  <label className="text-[#8A8F9E] block mb-1 font-bold">Conductas Rechazadas / Delictivas:</label>
                  <input
                    type="text"
                    value={(worldConfig.socialRules?.rejectedBehaviors || []).join(', ')}
                    onChange={e => setWorldConfig({
                      ...worldConfig,
                      socialRules: {
                        ...(worldConfig.socialRules || { hierarchies: '', customs: '', familyRelations: '', socialNorms: '', acceptedBehaviors: [], rejectedBehaviors: [], protocols: [], socialRoles: [] }),
                        rejectedBehaviors: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                      }
                    })}
                    placeholder="Usura abusiva, agresión sin aviso..."
                    className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 10 LEYES ESPECIALES */}
        {activeCategory === 10 && (
          <div className="space-y-4 animate-in fade-in">
            <WorldSpecialLawsEditor
              specialLaws={worldConfig.specialLaws || []}
              onUpdateSpecialLaws={laws => {
                setWorldConfig({
                  ...worldConfig,
                  specialLaws: laws,
                  laws: laws.map(sl => ({
                    id: sl.id,
                    title: sl.title,
                    description: `[Alcance: ${sl.scope}] ${sl.condition} -> ${sl.effect}`,
                    impactTag: 'social',
                    modifierDescription: sl.effect,
                    isActive: sl.isActive
                  }))
                });
              }}
            />
          </div>
        )}

        {/* 11 CANON */}
        {activeCategory === 11 && (
          <div className="space-y-4 animate-in fade-in">
            <h3 className="text-base font-bold text-[#F3F4F6] flex items-center gap-2">
              <Shield className="w-5 h-5 text-emerald-400" />
              <span>11. Canon del Mundo (Inviolable por el Motor)</span>
            </h3>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <p className="text-[#8A8F9E]">
                Hechos, personajes y verdades absolutas que ninguna generación ni acontecimiento aleatorio puede contradecir.
              </p>

              {(activePlace?.name || characterState?.name) && (
                <button
                  type="button"
                  onClick={() => {
                    const currentCanon = worldConfig.canon || { characters: [], facts: [], relationships: [], places: [], events: [], rules: [], historicalData: [] };
                    const places = [...(currentCanon.places || [])];
                    const characters = [...(currentCanon.characters || [])];
                    const facts = [...(currentCanon.facts || [])];

                    if (activePlace?.name && !places.includes(activePlace.name)) {
                      places.push(activePlace.name);
                    }
                    if (characterState?.name && !characters.includes(characterState.name)) {
                      characters.push(characterState.name);
                    }
                    if (activePlace?.name && !facts.some(f => f.includes(activePlace.name))) {
                      facts.push(`El escenario «${activePlace.name}» es un enclave geográfico inmutable en ${activePlace.region || 'la región'}.`);
                    }

                    setWorldConfig({
                      ...worldConfig,
                      canon: {
                        ...currentCanon,
                        places,
                        characters,
                        facts
                      }
                    });
                    showNotification(`✓ Canon actualizado con: ${[activePlace?.name, characterState?.name].filter(Boolean).join(' y ')}`);
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 font-bold text-xs transition-all cursor-pointer whitespace-nowrap"
                  title="Incorpora el personaje y escenario del taller actual al canon inviolable"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>⚡ Sincronizar Taller al Canon</span>
                </button>
              )}
            </div>

            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[#8A8F9E] block font-bold">Hechos Canónicos Fundamentales (Uno por línea):</label>
                  <div className="flex items-center gap-1">
                    {['Las leyes arcanas no pueden violarse.', 'La dinastía fundadora mantiene el linaje intacto.', 'El corazón del manantial no puede ser corrompido.'].map((sample, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => {
                          const currentFacts = worldConfig.canon?.facts || [];
                          if (!currentFacts.includes(sample)) {
                            setWorldConfig({
                              ...worldConfig,
                              canon: {
                                ...(worldConfig.canon || { characters: [], facts: [], relationships: [], places: [], events: [], rules: [], historicalData: [] }),
                                facts: [...currentFacts, sample]
                              }
                            });
                          }
                        }}
                        className="text-[10px] px-2 py-0.5 rounded bg-[#181A24] border border-[#2B2F3D] text-[#8A8F9E] hover:text-emerald-300 cursor-pointer"
                      >
                        + Hecho {idx + 1}
                      </button>
                    ))}
                  </div>
                </div>
                <textarea
                  rows={4}
                  value={(worldConfig.canon?.facts || []).join('\n')}
                  onChange={e => setWorldConfig({
                    ...worldConfig,
                    canon: {
                      ...(worldConfig.canon || { characters: [], facts: [], relationships: [], places: [], events: [], rules: [], historicalData: [] }),
                      facts: e.target.value.split('\n').filter(Boolean)
                    }
                  })}
                  placeholder="El Oasis Sagrado nunca se ha secado.&#10;La magia requiere concentración y no puede revivir muertos..."
                  className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl p-3 text-[#E0E2EC] outline-hidden"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-[#8A8F9E] block mb-1 font-bold">Personajes Canónicos Inmutables:</label>
                  <input
                    type="text"
                    value={(worldConfig.canon?.characters || []).join(', ')}
                    onChange={e => setWorldConfig({
                      ...worldConfig,
                      canon: {
                        ...(worldConfig.canon || { characters: [], facts: [], relationships: [], places: [], events: [], rules: [], historicalData: [] }),
                        characters: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                      }
                    })}
                    placeholder="Alta Sacerdotisa Zehra, Comandante Tariq..."
                    className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
                  />
                </div>

                <div>
                  <label className="text-[#8A8F9E] block mb-1 font-bold">Lugares Canónicos Protegidos:</label>
                  <input
                    type="text"
                    value={(worldConfig.canon?.places || []).join(', ')}
                    onChange={e => setWorldConfig({
                      ...worldConfig,
                      canon: {
                        ...(worldConfig.canon || { characters: [], facts: [], relationships: [], places: [], events: [], rules: [], historicalData: [] }),
                        places: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                      }
                    })}
                    placeholder="Oasis de las Tres Lunas, Bastión Central..."
                    className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 12 RESTRICCIONES */}
        {activeCategory === 12 && (
          <div className="space-y-4 animate-in fade-in">
            <h3 className="text-base font-bold text-[#F3F4F6] flex items-center gap-2">
              <Ban className="w-5 h-5 text-rose-400" />
              <span>12. Restricciones Narrativas & Filtros de Coherencia</span>
            </h3>

            <div className="space-y-4">
              <div>
                <label className="text-[#8A8F9E] block mb-1 font-bold">Personajes No Autorizados (El motor no los generará):</label>
                <div className="flex flex-wrap gap-1.5 mb-2">
                  {['Viajeros dimensionales anacrónicos', 'Dioses omnipotentes sin reglas', 'Androides hiper-tecnológicos', 'Criaturas cómicas fuera de tono'].map((sample, i) => {
                    const current = worldConfig.narrativeRestrictions?.unauthorizedCharacters || [];
                    const isSel = current.includes(sample);
                    return (
                      <button
                        key={i}
                        type="button"
                        onClick={() => {
                          const updated = isSel ? current.filter(x => x !== sample) : [...current, sample];
                          setWorldConfig({
                            ...worldConfig,
                            narrativeRestrictions: {
                              ...(worldConfig.narrativeRestrictions || { forbiddenTech: [], unauthorizedCharacters: [], incompatibleEvents: [], arbitraryRuleChanges: [] }),
                              unauthorizedCharacters: updated
                            }
                          });
                        }}
                        className={`text-[10px] px-2 py-0.5 rounded border transition-all cursor-pointer ${
                          isSel ? 'bg-rose-500/20 text-rose-300 border-rose-500/50 font-bold' : 'bg-[#181A24] text-[#8A8F9E] border-[#2B2F3D] hover:text-[#E0E2EC]'
                        }`}
                      >
                        {isSel ? '✓ ' : '+ '}
                        {sample}
                      </button>
                    );
                  })}
                </div>
                <input
                  type="text"
                  value={(worldConfig.narrativeRestrictions?.unauthorizedCharacters || []).join(', ')}
                  onChange={e => setWorldConfig({
                    ...worldConfig,
                    narrativeRestrictions: {
                      ...(worldConfig.narrativeRestrictions || { forbiddenTech: [], unauthorizedCharacters: [], incompatibleEvents: [], arbitraryRuleChanges: [] }),
                      unauthorizedCharacters: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                    }
                  })}
                  placeholder="Alienígenas de ciencia ficción dura, superhéroes modernos..."
                  className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
                />
              </div>

              <div>
                <label className="text-[#8A8F9E] block mb-1 font-bold">Acontecimientos Incompatibles con la Trama:</label>
                <div className="flex flex-wrap gap-1.5 mb-2">
                  {['Destrucción total del mundo súbita', 'Resurrección instantánea sin consecuencias', 'Viajes en el tiempo que rompan la causalidad', 'Cambios arbitrarios de lealtad sin motivación'].map((sample, i) => {
                    const current = worldConfig.narrativeRestrictions?.incompatibleEvents || [];
                    const isSel = current.includes(sample);
                    return (
                      <button
                        key={i}
                        type="button"
                        onClick={() => {
                          const updated = isSel ? current.filter(x => x !== sample) : [...current, sample];
                          setWorldConfig({
                            ...worldConfig,
                            narrativeRestrictions: {
                              ...(worldConfig.narrativeRestrictions || { forbiddenTech: [], unauthorizedCharacters: [], incompatibleEvents: [], arbitraryRuleChanges: [] }),
                              incompatibleEvents: updated
                            }
                          });
                        }}
                        className={`text-[10px] px-2 py-0.5 rounded border transition-all cursor-pointer ${
                          isSel ? 'bg-rose-500/20 text-rose-300 border-rose-500/50 font-bold' : 'bg-[#181A24] text-[#8A8F9E] border-[#2B2F3D] hover:text-[#E0E2EC]'
                        }`}
                      >
                        {isSel ? '✓ ' : '+ '}
                        {sample}
                      </button>
                    );
                  })}
                </div>
                <input
                  type="text"
                  value={(worldConfig.narrativeRestrictions?.incompatibleEvents || []).join(', ')}
                  onChange={e => setWorldConfig({
                    ...worldConfig,
                    narrativeRestrictions: {
                      ...(worldConfig.narrativeRestrictions || { forbiddenTech: [], unauthorizedCharacters: [], incompatibleEvents: [], arbitraryRuleChanges: [] }),
                      incompatibleEvents: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                    }
                  })}
                  placeholder="Bombardeos atómicos, resurrección masiva instantánea sin coste..."
                  className="w-full bg-[#181A22] border border-[#2B2F3C] rounded-xl px-3 py-2 text-[#E0E2EC] outline-hidden"
                />
              </div>
            </div>
          </div>
        )}

        {/* 13 FICHA CONSOLIDADA */}
        {activeCategory === 13 && (
          <WorldConsolidatedSheet
            worldConfig={worldConfig}
            onExportJson={handleExportJson}
          />
        )}
      </div>

      {/* Modal de Arquetipos */}
      <WorldPresetModal
        isOpen={showPresetModal}
        onClose={() => setShowPresetModal(false)}
        onApplyPreset={handleApplyPreset}
      />
    </div>
  );
};
