import React, { useState, useEffect } from 'react';
import {
  WorldPlace,
  CriticalPointOfInterest,
  ConvergenceZone,
  HousingLevel,
  HousingRoom,
  UniqueElement,
  UniqueElementType,
  WorldBuildingConfig
} from '../types';
import {
  savePlace,
  getSavedPlaces,
  duplicatePlace,
  exportSinglePlaceJson
} from '../utils/worldStorage';
import {
  PLACE_PRESETS,
  PlacePreset,
  SUGGESTIONS_BANK
} from '../data/creationHubPresets';
import {
  MapPin,
  Building,
  Home,
  Shield,
  AlertTriangle,
  Compass,
  Plus,
  Trash2,
  Copy,
  Download,
  Save,
  RotateCcw,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Eye,
  Layers,
  Sparkles,
  Clock,
  DoorClosed,
  Key,
  ShieldAlert,
  ArrowRight,
  ClipboardCopy,
  Zap,
  Check,
  X,
  Palette,
  Users,
  Compass as CompassIcon,
  BookOpen
} from 'lucide-react';

interface PlaceMasterSheetEditorProps {
  initialPlace?: WorldPlace | null;
  worldConfig?: WorldBuildingConfig;
  onPlaceSaved?: (place: WorldPlace) => void;
  onClose?: () => void;
}

// Sincronizador de datos para asegurar compatibilidad absoluta con la biblioteca y la simulación
export const syncPlaceData = (place: WorldPlace): WorldPlace => {
  // Asegurar que pointsOfInterest (array de strings) refleje criticalPointsOfInterest
  const poiNames = (place.criticalPointsOfInterest || [])
    .map(p => p.name?.trim())
    .filter(Boolean);
  
  const mergedPois = Array.from(
    new Set([
      ...(poiNames.length > 0 ? poiNames : (place.pointsOfInterest || []))
    ])
  );

  return {
    ...place,
    pointsOfInterest: mergedPois
  };
};

export const generatePlaceMarkdown = (place: WorldPlace): string => {
  const p = syncPlaceData(place);
  return `# FICHA MAESTRA DE ESCENARIO: ${p.name.toUpperCase()} (${p.version || 'v1.0'})
**ID:** \`${p.id}\` | **Región:** ${p.region} | **Entorno:** ${p.environmentType} | **Peligro:** ${p.dangerLevel}
**Fecha:** ${p.createdAt || new Date().toISOString().slice(0, 10)} | **Última Actualización:** ${p.updatedAt || new Date().toISOString().slice(0, 10)}

---

## 1. IDENTIDAD ESPACIAL & ATMÓSFERA
- **Contexto Geográfico:** ${p.geographicContext || 'Sin definir'}
- **Ritmo & Vibes:** ${p.rhythmOrVibes?.join(', ') || 'Normal'}
- **Descripción General:**
${p.description || 'Sin descripción'}

- **Atmósfera Sensorial:**
> "${p.atmosphere || 'Atmósfera no especificada.'}"

---

## 2. ARQUITECTURA & MATERIALIDAD
- **Estilo Constructivo:** ${p.constructionStyle}
- **Estado de Conservación:** ${p.condition}
- **Materiales Predominantes:** ${p.materials?.join(', ') || 'No especificados'}

---

## 3. ECOSISTEMA URBANO & SERVICIOS
### A. Puntos de Interés Críticos (${p.criticalPointsOfInterest?.length || 0})
${(p.criticalPointsOfInterest || [])
  .map(
    (poi, idx) =>
      `${idx + 1}. **${poi.name}** [${poi.type}] (Importancia: *${poi.importance}*)\n   - **Función:** ${poi.function}\n   - **Propietario / Custodio:** ${poi.owner || 'Comunal / Desconocido'}\n   - **Ubicación:** ${poi.location}\n   - **Descripción:** ${poi.description}`
  )
  .join('\n\n') || '_Sin puntos de interés registrados._'}

### B. Zonas de Convergencia Social (${p.convergenceZones?.length || 0})
${(p.convergenceZones || [])
  .map(
    (z, idx) =>
      `${idx + 1}. **${z.name}** [${z.type}] — Horario: ${z.schedule}\n   - **Densidad NPC:** ${z.npcDensity} | **Seguridad:** ${z.securityLevel}\n   - **Eventos Frecuentes:** ${z.frequentEvents}\n   - **Habitantes habituales:** ${z.associatedCharacters?.join(', ') || 'Población general'}`
  )
  .join('\n\n') || '_Sin zonas de convergencia social registradas._'}

### C. Cultura & Seguridad
- **Autoridad:** ${p.cultureAndSecurity?.authority || 'Sin autoridad definida'}
- **Vigilancia:** ${p.cultureAndSecurity?.surveillance || 'Media'}
- **Conducta Social Predominante:** ${p.cultureAndSecurity?.socialConduct?.join(', ') || 'Estándar'}

---

## 4. VIVIENDA & DISTRIBUCIÓN DE NIVELES
- **¿Dispone de Vivienda?:** ${p.hasHousing ? `Sí (${p.housing?.buildingType || 'Edificación'})` : 'No'}
${
  p.hasHousing && p.housing
    ? `- **Exteriores y Conectividad:** ${p.housing.exteriorsAndConnectivity?.join(', ') || 'Accesos directos'}\n\n` +
      p.housing.levels
        .map(
          lvl =>
            `### Nivel ${lvl.levelNumber}: ${lvl.levelName}\n` +
            (lvl.rooms
              .map(
                (r, ridx) =>
                  `  ${ridx + 1}. **${r.name}** [${r.function}] (${r.location})\n     - **Mobiliario:** ${r.furniture?.join(', ') || 'Básico'}\n     - **Objetos Clave:** ${r.objects?.join(', ') || 'Ninguno'}\n     - **Accesos:** ${r.accesses?.join(', ') || 'Puerta estándar'}\n     - **Detalle:** ${r.description}`
              )
              .join('\n\n') || '  _Sin habitaciones en este nivel._')
        )
        .join('\n\n')
    : '_Este escenario no incluye un habitáculo o vivienda modelada._'
}

---

## 5. ELEMENTOS ÚNICOS & ANOMALÍAS (${p.uniqueElements?.length || 0})
${(p.uniqueElements || [])
  .map(
    (el, idx) =>
      `${idx + 1}. **${el.name}** [Tipo: ${el.type}] (*${el.importance}*)\n   - **Descripción:** ${el.description}\n   - **Comportamiento / Efecto:** ${el.behavior}`
  )
  .join('\n\n') || '_Sin elementos únicos registrados._'}
`;
};

export const PlaceMasterSheetEditor: React.FC<PlaceMasterSheetEditorProps> = ({
  initialPlace,
  worldConfig,
  onPlaceSaved,
  onClose
}) => {
  const existingPlaces = getSavedPlaces();
  const basePlace = initialPlace || existingPlaces[0];

  const [currentPlace, setCurrentPlace] = useState<WorldPlace>(() => {
    if (basePlace) {
      const cloned: WorldPlace = JSON.parse(JSON.stringify(basePlace));
      // Si no tiene criticalPointsOfInterest pero sí pointsOfInterest, creamos POIs básicos
      if (!cloned.criticalPointsOfInterest || cloned.criticalPointsOfInterest.length === 0) {
        if (cloned.pointsOfInterest && cloned.pointsOfInterest.length > 0) {
          cloned.criticalPointsOfInterest = cloned.pointsOfInterest.map((pName, i) => ({
            id: `POI-INIT-${i + 1}`,
            name: pName,
            type: 'Punto de Interés',
            function: 'Ubicación relevante del entorno',
            owner: 'Comunidad local',
            location: 'Sector principal',
            description: `Punto de interés destacado en ${cloned.name}.`,
            importance: 'Media'
          }));
        }
      }
      return syncPlaceData(cloned);
    }
    // Preset por defecto si no hay nada
    const def = PLACE_PRESETS[0].data as WorldPlace;
    return syncPlaceData({
      ...def,
      id: `LOC-${Date.now()}`,
      version: 'v1.0',
      createdAt: new Date().toISOString().slice(0, 10),
      updatedAt: new Date().toISOString()
    });
  });

  useEffect(() => {
    if (initialPlace) {
      const cloned = JSON.parse(JSON.stringify(initialPlace));
      if (!cloned.criticalPointsOfInterest || cloned.criticalPointsOfInterest.length === 0) {
        if (cloned.pointsOfInterest && cloned.pointsOfInterest.length > 0) {
          cloned.criticalPointsOfInterest = cloned.pointsOfInterest.map((pName: string, i: number) => ({
            id: `POI-INIT-${i + 1}`,
            name: pName,
            type: 'Punto de Interés',
            function: 'Ubicación relevante del entorno',
            owner: 'Comunidad local',
            location: 'Sector principal',
            description: `Punto de interés destacado en ${cloned.name}.`,
            importance: 'Media'
          }));
        }
      }
      setCurrentPlace(syncPlaceData(cloned));
    }
  }, [initialPlace?.id]);

  const [activeTab, setActiveTab] = useState<
    'identidad' | 'arquitectura' | 'ecosistema' | 'vivienda' | 'elementos' | 'consolidada'
  >('identidad');

  const [notification, setNotification] = useState<string | null>(null);
  const [showPresetModal, setShowPresetModal] = useState(false);
  const [customMaterialInput, setCustomMaterialInput] = useState('');
  const [customConductInput, setCustomConductInput] = useState('');

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3500);
  };

  // 1. Acciones de Guardado y Sincronización
  const handleSaveOverwrite = () => {
    const updated = syncPlaceData({
      ...currentPlace,
      updatedAt: new Date().toISOString()
    });
    savePlace(updated);
    setCurrentPlace(updated);
    if (onPlaceSaved) onPlaceSaved(updated);
    showNotification('✓ ¡Ficha Maestra guardada y sincronizada correctamente con la Biblioteca!');
  };

  const handleSaveAsNewVersion = () => {
    const curVer = currentPlace.version || 'v1.0';
    const num = parseFloat(curVer.replace('v', '')) || 1.0;
    const nextVer = `v${(num + 0.1).toFixed(1)}`;
    const newPlace = syncPlaceData({
      ...currentPlace,
      id: `LOC-${Date.now()}`,
      name: `${currentPlace.name} (${nextVer})`,
      version: nextVer,
      createdAt: new Date().toISOString().slice(0, 10),
      updatedAt: new Date().toISOString()
    });
    savePlace(newPlace);
    setCurrentPlace(newPlace);
    if (onPlaceSaved) onPlaceSaved(newPlace);
    showNotification(`✓ ¡Guardado como nueva versión ${nextVer}!`);
  };

  const handleDuplicate = () => {
    const dup = duplicatePlace(currentPlace.id);
    if (dup) {
      const synced = syncPlaceData(dup);
      setCurrentPlace(synced);
      if (onPlaceSaved) onPlaceSaved(synced);
      showNotification('✓ ¡Escenario duplicado con éxito!');
    }
  };

  const handleExportJson = () => {
    const synced = syncPlaceData(currentPlace);
    const jsonStr = exportSinglePlaceJson(synced);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${synced.name.replace(/\s+/g, '_')}_Ficha_Maestra.json`;
    a.click();
    URL.revokeObjectURL(url);
    showNotification('✓ ¡Archivo JSON descargado!');
  };

  const handleCopyMarkdown = () => {
    const md = generatePlaceMarkdown(currentPlace);
    navigator.clipboard.writeText(md);
    showNotification('✓ ¡Ficha Maestra completa copiada al portapapeles en formato Markdown!');
  };

  const handleDiscardChanges = () => {
    const saved = getSavedPlaces().find(p => p.id === currentPlace.id);
    if (saved) {
      setCurrentPlace(syncPlaceData(JSON.parse(JSON.stringify(saved))));
      showNotification('Cambios descartados. Se restauró el último estado guardado.');
    } else {
      showNotification('No hay copia previa guardada para restaurar.');
    }
  };

  // Carga de Plantilla / Arquetipo
  const handleLoadPreset = (preset: PlacePreset) => {
    const loadedData = JSON.parse(JSON.stringify(preset.data));
    const merged: WorldPlace = syncPlaceData({
      ...currentPlace,
      ...loadedData,
      id: currentPlace.id, // Mantener id original o version
      version: currentPlace.version || 'v1.0',
      updatedAt: new Date().toISOString()
    });
    setCurrentPlace(merged);
    setShowPresetModal(false);
    showNotification(`✓ ¡Plantilla "${preset.name}" aplicada al escenario! Todos los campos se han cargado.`);
  };

  // 2. Helpers para POIs
  const handleAddCriticalPoi = () => {
    const newPoi: CriticalPointOfInterest = {
      id: `POI-${Date.now()}`,
      name: 'Nuevo Punto de Interés',
      type: 'Taller / Comercio',
      function: 'Comercio, reunión o servicio clave',
      owner: 'Comunidad local',
      location: 'Sector central',
      description: 'Descripción de la importancia y actividades que se desarrollan aquí.',
      importance: 'Media'
    };
    const updatedPois = [...(currentPlace.criticalPointsOfInterest || []), newPoi];
    setCurrentPlace(syncPlaceData({ ...currentPlace, criticalPointsOfInterest: updatedPois }));
  };

  const handleSuggestPois = () => {
    const suggestions: CriticalPointOfInterest[] = [
      {
        id: `POI-SUG-1-${Date.now()}`,
        name: `Santuario / Mirador de ${currentPlace.region || 'la Colina'}`,
        type: 'Templo / Santuario',
        function: 'Espacio de recogimiento y observación panorámica',
        owner: 'Sacerdocio o Custodios de la Orden',
        location: 'Elevación oriental',
        importance: 'Alta',
        description: 'Construcción con amplia visibilidad, donde acuden lugareños a meditar y buscar consuelo.'
      },
      {
        id: `POI-SUG-2-${Date.now()}`,
        name: 'Mercado de Abasto & Lonja Central',
        type: 'Comercio / Tienda',
        function: 'Distribución de víveres, provisiones ytrueque de manufacturas',
        owner: 'Gremio de Mercaderes',
        location: 'Plaza baja',
        importance: 'Media',
        description: 'Puestos techados con tenderetes de lona donde confluyen caravanas y transeúntes.'
      },
      {
        id: `POI-SUG-3-${Date.now()}`,
        name: 'Torreón de la Guardia & Alerta',
        type: 'Puesto de guardia',
        function: 'Control de accesos y vigilancia perimetral permanente',
        owner: 'Milicia de la Comuna',
        location: 'Arco de entrada norte',
        importance: 'Alta',
        description: 'Estructura fortificada equipada con campana de sitio y troneras de vigilancia.'
      }
    ];

    const mergedPois = [...(currentPlace.criticalPointsOfInterest || []), ...suggestions];
    setCurrentPlace(syncPlaceData({ ...currentPlace, criticalPointsOfInterest: mergedPois }));
    showNotification('✓ ¡Se han añadido 3 Puntos de Interés contextuales sugeridos!');
  };

  const handleUpdateCriticalPoi = (index: number, field: keyof CriticalPointOfInterest, value: any) => {
    const pois = [...(currentPlace.criticalPointsOfInterest || [])];
    pois[index] = { ...pois[index], [field]: value };
    setCurrentPlace(syncPlaceData({ ...currentPlace, criticalPointsOfInterest: pois }));
  };

  const handleRemoveCriticalPoi = (index: number) => {
    const pois = (currentPlace.criticalPointsOfInterest || []).filter((_, i) => i !== index);
    setCurrentPlace(syncPlaceData({ ...currentPlace, criticalPointsOfInterest: pois }));
  };

  // 3. Helpers para Zonas de Convergencia
  const handleAddConvergenceZone = () => {
    const newZone: ConvergenceZone = {
      id: `ZONE-${Date.now()}`,
      name: 'Nueva Zona de Convergencia',
      type: 'Plaza',
      schedule: 'Tardes y noches',
      npcDensity: 'Media',
      frequentEvents: 'Charlas, intercambio de rumores y descanso',
      securityLevel: 'Medio',
      associatedCharacters: ['Transeúntes', 'Pobladores']
    };
    setCurrentPlace({
      ...currentPlace,
      convergenceZones: [...(currentPlace.convergenceZones || []), newZone]
    });
  };

  const handleSuggestConvergenceZone = () => {
    const newZone: ConvergenceZone = {
      id: `ZONE-SUG-${Date.now()}`,
      name: 'Ágora del Encuentro Comunal',
      type: 'Plaza',
      schedule: 'Desde el mediodía hasta la medianoche',
      npcDensity: 'Alta',
      frequentEvents: 'Músicos ambulantes, asambleas ciudadanas y tertulias nocturnas',
      securityLevel: 'Medio',
      associatedCharacters: ['Viajeros', 'Artesanos', 'Informantes']
    };
    setCurrentPlace({
      ...currentPlace,
      convergenceZones: [...(currentPlace.convergenceZones || []), newZone]
    });
    showNotification('✓ ¡Zona de convergencia sugerida añadida!');
  };

  const handleUpdateConvergenceZone = (index: number, field: keyof ConvergenceZone, value: any) => {
    const zones = [...(currentPlace.convergenceZones || [])];
    zones[index] = { ...zones[index], [field]: value };
    setCurrentPlace({ ...currentPlace, convergenceZones: zones });
  };

  const handleRemoveConvergenceZone = (index: number) => {
    const zones = (currentPlace.convergenceZones || []).filter((_, i) => i !== index);
    setCurrentPlace({ ...currentPlace, convergenceZones: zones });
  };

  // 4. Helpers para Vivienda & Niveles
  const handleAddLevel = () => {
    if (!currentPlace.housing) return;
    const levels = [...currentPlace.housing.levels];
    const newNum = levels.length;
    levels.push({
      levelNumber: newNum,
      levelName: `NIVEL ${newNum} — PLANTA ${newNum === 1 ? 'ALTA' : newNum === 2 ? 'ÁTICO' : `SUPERIOR ${newNum}`}`,
      rooms: []
    });
    setCurrentPlace({
      ...currentPlace,
      housing: { ...currentPlace.housing, levels }
    });
  };

  const handleAddRoom = (levelIdx: number) => {
    if (!currentPlace.housing) return;
    const levels = [...currentPlace.housing.levels];
    const newRoom: HousingRoom = {
      id: `ROOM-${Date.now()}`,
      name: 'Nueva Habitación',
      function: 'Estancia / Reposo',
      location: `Piso ${levels[levelIdx].levelNumber}`,
      furniture: ['Mesa', 'Silla'],
      objects: ['Farol'],
      accesses: ['Puerta principal'],
      associatedCharacters: [],
      description: 'Espacio detallado para el personaje y sus interacciones.'
    };
    levels[levelIdx].rooms.push(newRoom);
    setCurrentPlace({
      ...currentPlace,
      housing: { ...currentPlace.housing, levels }
    });
  };

  const handleSuggestRooms = (levelIdx: number) => {
    if (!currentPlace.housing) return;
    const levels = [...currentPlace.housing.levels];
    const suggested: HousingRoom[] = [
      {
        id: `ROOM-SUG-1-${Date.now()}`,
        name: 'Aposento Principal de Reposo',
        function: 'Dormitorio principal',
        location: `Ala este - Nivel ${levels[levelIdx].levelNumber}`,
        furniture: ['Cama amplia con dosel', 'Armario ropero', 'Escritorio con sillón'],
        objects: ['Lámpara de noche', 'Baúl con cerradura', 'Espejo biselado'],
        accesses: ['Pasillo central', 'Ventanal balcón'],
        associatedCharacters: [],
        description: 'Habitación privada ventilada, diseñada para la intimidad y la recuperación de energía.'
      },
      {
        id: `ROOM-SUG-2-${Date.now()}`,
        name: 'Taller de Ensamblaje / Estudio',
        function: 'Taller de trabajo',
        location: `Costado norte - Nivel ${levels[levelIdx].levelNumber}`,
        furniture: ['Mesa de trabajo de madera maciza', 'Estanterías de herramientas'],
        objects: ['Herramientas de precisión', 'Frascos con reactivos', 'Planos enrollados'],
        accesses: ['Pasillo central'],
        associatedCharacters: [],
        description: 'Espacio de concentración artesanal o intelectual con iluminación directa.'
      }
    ];

    levels[levelIdx].rooms.push(...suggested);
    setCurrentPlace({
      ...currentPlace,
      housing: { ...currentPlace.housing, levels }
    });
    showNotification('✓ ¡2 habitaciones típicas sugeridas añadidas al nivel!');
  };

  const handleUpdateRoom = (levelIdx: number, roomIdx: number, field: keyof HousingRoom, value: any) => {
    if (!currentPlace.housing) return;
    const levels = [...currentPlace.housing.levels];
    levels[levelIdx].rooms[roomIdx] = {
      ...levels[levelIdx].rooms[roomIdx],
      [field]: value
    };
    setCurrentPlace({
      ...currentPlace,
      housing: { ...currentPlace.housing, levels }
    });
  };

  const handleRemoveRoom = (levelIdx: number, roomIdx: number) => {
    if (!currentPlace.housing) return;
    const levels = [...currentPlace.housing.levels];
    levels[levelIdx].rooms = levels[levelIdx].rooms.filter((_, i) => i !== roomIdx);
    setCurrentPlace({
      ...currentPlace,
      housing: { ...currentPlace.housing, levels }
    });
  };

  // 5. Helpers para Elementos Únicos
  const handleAddUniqueElement = () => {
    const newEl: UniqueElement = {
      id: `UNIQ-${Date.now()}`,
      name: 'Nuevo Elemento Único',
      type: 'OBJETO',
      description: 'Descripción de su naturaleza o peculiaridad en este escenario.',
      behavior: 'Comportamiento, reacción o efecto sobre el entorno.',
      importance: 'Elemento ambiental'
    };
    setCurrentPlace({
      ...currentPlace,
      uniqueElements: [...(currentPlace.uniqueElements || []), newEl]
    });
  };

  const handleSuggestUniqueElement = () => {
    const suggestions: UniqueElement[] = [
      {
        id: `UNIQ-SUG-1-${Date.now()}`,
        name: 'Campana Ancestral de Resonancia',
        type: 'MECANISMO',
        description: 'Estructura de bronce antiguo suspendida sobre el punto más alto del asentamiento.',
        behavior: 'Al sonar a la caída del sol, unifica a la comunidad y dispersa nieblas densas.',
        importance: 'Elemento ambiental'
      },
      {
        id: `UNIQ-SUG-2-${Date.now()}`,
        name: 'Manantial de Aguas Fosforescentes',
        type: 'ANOMALÍA',
        description: 'Pozo natural cuyas aguas emiten un suave brillo esmeralda perceptible en la penumbra.',
        behavior: 'Imbuye calor reconfortante a quienes sumergen sus manos durante unos minutos.',
        importance: 'Clave de trama / Mágico'
      }
    ];

    setCurrentPlace({
      ...currentPlace,
      uniqueElements: [...(currentPlace.uniqueElements || []), ...suggestions]
    });
    showNotification('✓ ¡Elementos únicos misteriosos sugeridos añadidos!');
  };

  const handleUpdateUniqueElement = (index: number, field: keyof UniqueElement, value: any) => {
    const els = [...(currentPlace.uniqueElements || [])];
    els[index] = { ...els[index], [field]: value };
    setCurrentPlace({ ...currentPlace, uniqueElements: els });
  };

  const handleRemoveUniqueElement = (index: number) => {
    const els = (currentPlace.uniqueElements || []).filter((_, i) => i !== index);
    setCurrentPlace({ ...currentPlace, uniqueElements: els });
  };

  // 6. Creadores Asistidos por Arquetipo Rápido (1 clic)
  const handleAddPoiArchetype = (arch: { name: string; type: string; function: string; importance: 'Baja' | 'Media' | 'Alta' | 'Crítica'; owner: string; location: string; description: string }) => {
    const newPoi: CriticalPointOfInterest = {
      id: `POI-ARCH-${Date.now()}`,
      ...arch
    };
    const updated = [...(currentPlace.criticalPointsOfInterest || []), newPoi];
    setCurrentPlace(syncPlaceData({ ...currentPlace, criticalPointsOfInterest: updated }));
    showNotification(`✓ Añadido Punto de Interés: ${arch.name}`);
  };

  const handleAddZoneArchetype = (arch: { name: string; type: string; schedule: string; npcDensity: 'Baja' | 'Media' | 'Alta'; securityLevel: 'Sin vigilancia' | 'Bajo' | 'Medio' | 'Alto' | 'Vigilancia militar'; frequentEvents: string; associatedCharacters?: string[] }) => {
    const newZone: ConvergenceZone = {
      id: `ZONE-ARCH-${Date.now()}`,
      name: arch.name,
      type: arch.type,
      schedule: arch.schedule,
      npcDensity: arch.npcDensity,
      securityLevel: arch.securityLevel,
      frequentEvents: arch.frequentEvents,
      associatedCharacters: arch.associatedCharacters || ['Transeúntes', 'Habitantes']
    };
    setCurrentPlace({
      ...currentPlace,
      convergenceZones: [...(currentPlace.convergenceZones || []), newZone]
    });
    showNotification(`✓ Añadida Zona de Convergencia: ${arch.name}`);
  };

  const handleAddRoomArchetype = (levelIdx: number, arch: { name: string; function: string; location?: string; furniture: string[]; objects: string[]; accesses: string[]; description: string }) => {
    if (!currentPlace.housing) return;
    const levels = [...currentPlace.housing.levels];
    const newRoom: HousingRoom = {
      id: `ROOM-ARCH-${Date.now()}`,
      name: arch.name,
      function: arch.function,
      location: arch.location || `Nivel ${levels[levelIdx].levelNumber}`,
      furniture: arch.furniture,
      objects: arch.objects,
      accesses: arch.accesses,
      associatedCharacters: [],
      description: arch.description
    };
    levels[levelIdx].rooms.push(newRoom);
    setCurrentPlace({
      ...currentPlace,
      housing: { ...currentPlace.housing, levels }
    });
    showNotification(`✓ Añadida estancia: ${arch.name}`);
  };

  const handleAddUniqueElementArchetype = (arch: { name: string; type: UniqueElementType; importance: string; behavior: string; description: string }) => {
    const newEl: UniqueElement = {
      id: `UNIQ-ARCH-${Date.now()}`,
      ...arch
    };
    setCurrentPlace({
      ...currentPlace,
      uniqueElements: [...(currentPlace.uniqueElements || []), newEl]
    });
    showNotification(`✓ Añadido Elemento Único: ${arch.name}`);
  };

  // Toggle rápido de Vibes
  const handleToggleVibe = (vibe: string) => {
    const currentVibes = currentPlace.rhythmOrVibes || [];
    const exists = currentVibes.includes(vibe);
    const updated = exists
      ? currentVibes.filter(v => v !== vibe)
      : [...currentVibes, vibe];
    setCurrentPlace({ ...currentPlace, rhythmOrVibes: updated });
  };

  // Toggle rápido de Materiales
  const handleToggleMaterial = (mat: string) => {
    const cur = currentPlace.materials || [];
    const exists = cur.includes(mat);
    const updated = exists ? cur.filter(m => m !== mat) : [...cur, mat];
    setCurrentPlace({ ...currentPlace, materials: updated });
  };

  // Toggle rápido de Conducta Social
  const handleToggleConduct = (cond: string) => {
    const cur = currentPlace.cultureAndSecurity?.socialConduct || [];
    const exists = cur.includes(cond);
    const updated = exists ? cur.filter(c => c !== cond) : [...cur, cond];
    setCurrentPlace({
      ...currentPlace,
      cultureAndSecurity: {
        ...(currentPlace.cultureAndSecurity || {
          authority: 'Gobierno',
          surveillance: 'Media'
        }),
        socialConduct: updated
      }
    });
  };

  // Toggle rápido de Conectividad de Vivienda
  const handleToggleConnectivity = (tag: string) => {
    if (!currentPlace.housing) return;
    const cur = currentPlace.housing.exteriorsAndConnectivity || [];
    const exists = cur.includes(tag);
    const updated = exists ? cur.filter(t => t !== tag) : [...cur, tag];
    setCurrentPlace({
      ...currentPlace,
      housing: {
        ...currentPlace.housing,
        exteriorsAndConnectivity: updated
      }
    });
  };

  // Cálculo del porcentaje de completitud de la Ficha Maestra
  const calculateCompleteness = () => {
    let score = 0;
    if (currentPlace.name) score += 15;
    if (currentPlace.description) score += 15;
    if (currentPlace.atmosphere) score += 15;
    if (currentPlace.materials && currentPlace.materials.length > 0) score += 15;
    if (currentPlace.criticalPointsOfInterest && currentPlace.criticalPointsOfInterest.length > 0) score += 15;
    if (currentPlace.convergenceZones && currentPlace.convergenceZones.length > 0) score += 10;
    if (!currentPlace.hasHousing || (currentPlace.housing && currentPlace.housing.levels.length > 0)) score += 15;
    return Math.min(100, score);
  };

  const completeness = calculateCompleteness();
  const poiCount = currentPlace.criticalPointsOfInterest?.length || 0;
  const zoneCount = currentPlace.convergenceZones?.length || 0;
  const roomCount = currentPlace.housing?.levels?.reduce((acc, l) => acc + l.rooms.length, 0) || 0;
  const uniqueCount = currentPlace.uniqueElements?.length || 0;

  return (
    <div className="space-y-6">
      {/* Top Banner de Ficha Maestra con Indicadores Inteligentes */}
      <div className="bg-[#111319] border border-[#232632] rounded-3xl p-6 shadow-2xl space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shrink-0 mt-0.5">
              <MapPin className="w-6 h-6" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-[10px] uppercase font-bold tracking-wider px-2.5 py-0.5 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300">
                  Ficha Maestra de Escenario & Vivienda
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#1F232F] text-[#A0A5B5] border border-[#2D3242]">
                  {currentPlace.version || 'v1.0'}
                </span>
                <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-emerald-950/60 border border-emerald-700/60 text-emerald-300 flex items-center gap-1">
                  <Check className="w-3 h-3" />
                  Sincronización Activa con Biblioteca
                </span>
              </div>
              <h2 className="text-2xl font-bold text-[#F3F4F6] mt-1.5 flex items-center gap-2">
                <span>{currentPlace.name || 'Escenario sin nombre'}</span>
              </h2>
              <p className="text-xs text-[#8A8F9E] mt-1 max-w-2xl leading-relaxed">
                Herramienta maestra de diseño espacial para Elysium. Los cambios se sincronizan en tiempo real con las fichas maestras, el selector de escenarios y el motor de simulación.
              </p>
            </div>
          </div>

          {/* Botones de Acción Primarios */}
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            {/* Botón de Cargar Plantilla Rápida */}
            <button
              type="button"
              onClick={() => setShowPresetModal(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 font-bold text-xs transition-all cursor-pointer shadow-sm"
              title="Cargar un arquetipo completo de escenario prefabricado"
            >
              <Zap className="w-4 h-4 text-amber-400" />
              <span>⚡ Cargar Arquetipo</span>
            </button>

            <button
              type="button"
              onClick={handleSaveOverwrite}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md transition-all cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Guardar Ficha</span>
            </button>

            <button
              type="button"
              onClick={handleSaveAsNewVersion}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#1A1D27] hover:bg-[#232736] border border-[#2F3446] text-[#E0E2EC] font-bold text-xs transition-all cursor-pointer"
              title="Guarda una nueva versión incremental (v1.1, v1.2...)"
            >
              <Plus className="w-3.5 h-3.5 text-indigo-400" />
              <span>Guardar Como</span>
            </button>

            <button
              type="button"
              onClick={handleCopyMarkdown}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#1A1D27] hover:bg-[#232736] border border-[#2F3446] text-[#D4AF37] hover:text-[#F3E5AB] text-xs font-bold transition-all cursor-pointer"
              title="Copiar la Ficha Maestra en formato Markdown limpio"
            >
              <ClipboardCopy className="w-3.5 h-3.5" />
              <span>Copiar MD</span>
            </button>

            <button
              type="button"
              onClick={handleExportJson}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#1A1D27] hover:bg-[#232736] border border-[#2F3446] text-[#A0A5B5] hover:text-[#F3F4F6] text-xs transition-all cursor-pointer"
              title="Exportar archivo JSON"
            >
              <Download className="w-3.5 h-3.5" />
              <span>JSON</span>
            </button>

            <button
              type="button"
              onClick={handleDuplicate}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#1A1D27] hover:bg-[#232736] border border-[#2F3446] text-[#A0A5B5] hover:text-[#F3F4F6] text-xs transition-all cursor-pointer"
              title="Duplicar este escenario"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>Duplicar</span>
            </button>

            <button
              type="button"
              onClick={handleDiscardChanges}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#1A1D27] hover:bg-rose-950/40 border border-[#2F3446] hover:border-rose-700/50 text-[#8A8F9E] hover:text-rose-300 text-xs transition-all cursor-pointer"
              title="Descartar cambios no guardados"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Descartar</span>
            </button>
          </div>
        </div>

        {/* Barra de Progreso y Salud de la Ficha Maestra */}
        <div className="bg-[#161823] p-3 rounded-2xl border border-[#262A38] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <span className="font-bold text-[#D0D4E4]">Salud de la Ficha:</span>
            <div className="w-32 bg-[#222533] h-2 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400 transition-all duration-500"
                style={{ width: `${completeness}%` }}
              />
            </div>
            <span className="font-mono text-[#D4AF37] font-bold">{completeness}%</span>
          </div>

          <div className="flex flex-wrap items-center gap-2 text-[11px] text-[#8A8F9E]">
            <span className="px-2 py-0.5 rounded-md bg-[#1F2230] text-indigo-300">
              {poiCount} Puntos de Interés
            </span>
            <span className="px-2 py-0.5 rounded-md bg-[#1F2230] text-emerald-300">
              {zoneCount} Zonas de Encuentro
            </span>
            <span className="px-2 py-0.5 rounded-md bg-[#1F2230] text-amber-300">
              {currentPlace.hasHousing ? `${roomCount} Habs en Vivienda` : 'Sin Vivienda'}
            </span>
            <span className="px-2 py-0.5 rounded-md bg-[#1F2230] text-purple-300">
              {uniqueCount} Elementos Únicos
            </span>
          </div>
        </div>
      </div>

      {/* Notificación temporal con animación */}
      {notification && (
        <div className="flex items-center gap-2.5 p-3.5 bg-emerald-950/80 border border-emerald-500/70 text-emerald-200 rounded-2xl text-xs font-medium shadow-xl animate-in fade-in slide-in-from-top-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{notification}</span>
        </div>
      )}

      {/* Modal de Arquetipos / Plantillas */}
      {showPresetModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#13151D] border border-[#2B2F3D] rounded-3xl max-w-3xl w-full p-6 shadow-2xl space-y-5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-[#232632] pb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-[#F3F4F6]">Cargar Arquetipo Rápido de Escenario</h3>
                  <p className="text-xs text-[#8A8F9E]">
                    Selecciona una plantilla arquitectónica para rellenar de inmediato toda la ficha con coherencia.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowPresetModal(false)}
                className="p-1.5 rounded-xl bg-[#1A1C24] hover:bg-[#252834] text-[#8A8F9E] hover:text-[#FFF] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {PLACE_PRESETS.map(preset => (
                <div
                  key={preset.id}
                  className="bg-[#181A24] border border-[#262936] hover:border-indigo-500/60 rounded-2xl p-4 transition-all flex flex-col justify-between space-y-3 group"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-indigo-500/15 text-indigo-300 border border-indigo-500/30">
                        {preset.badge}
                      </span>
                      <span className="text-xs font-mono text-[#8A8F9E]">
                        {preset.data.environmentType}
                      </span>
                    </div>
                    <h4 className="text-sm font-bold text-[#F3F4F6] group-hover:text-indigo-300 transition-colors">
                      {preset.name}
                    </h4>
                    <p className="text-xs text-[#8A8F9E] leading-relaxed">
                      {preset.description}
                    </p>
                    <div className="text-[11px] text-[#A0A5B5] bg-[#12141C] p-2 rounded-xl border border-[#202330]">
                      <span className="text-[#D4AF37] font-semibold">Atmósfera: </span>
                      «{preset.data.atmosphere?.slice(0, 75)}...»
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleLoadPreset(preset)}
                    className="w-full py-2 px-3 rounded-xl bg-indigo-600/90 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-md mt-2"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Cargar este Arquetipo</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Pestañas de Navegación del Taller de Escenario */}
      <div className="flex items-center gap-1.5 bg-[#12141A] p-1.5 rounded-2xl border border-[#262934] overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveTab('identidad')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'identidad'
              ? 'bg-[#1C1F28] text-indigo-400 border border-[#3A3F4E] shadow-sm'
              : 'text-[#8A8F9E] hover:text-[#E0E0E0]'
          }`}
        >
          <CompassIcon className="w-4 h-4" />
          <span>1. Identidad & Atmósfera</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('arquitectura')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'arquitectura'
              ? 'bg-[#1C1F28] text-indigo-400 border border-[#3A3F4E] shadow-sm'
              : 'text-[#8A8F9E] hover:text-[#E0E0E0]'
          }`}
        >
          <Building className="w-4 h-4" />
          <span>2. Arquitectura & Materiales</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('ecosistema')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'ecosistema'
              ? 'bg-[#1C1F28] text-indigo-400 border border-[#3A3F4E] shadow-sm'
              : 'text-[#8A8F9E] hover:text-[#E0E0E0]'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>3. Ecosistema Urbano ({poiCount} POIs)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('vivienda')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'vivienda'
              ? 'bg-[#1C1F28] text-indigo-400 border border-[#3A3F4E] shadow-sm'
              : 'text-[#8A8F9E] hover:text-[#E0E0E0]'
          }`}
        >
          <Home className="w-4 h-4" />
          <span>4. Vivienda & Niveles ({roomCount} habs)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('elementos')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'elementos'
              ? 'bg-[#1C1F28] text-indigo-400 border border-[#3A3F4E] shadow-sm'
              : 'text-[#8A8F9E] hover:text-[#E0E0E0]'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>5. Elementos Únicos ({uniqueCount})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('consolidada')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'consolidada'
              ? 'bg-[#1C1F28] text-[#D4AF37] border border-[#3A3F4E] shadow-sm'
              : 'text-[#8A8F9E] hover:text-[#E0E0E0]'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>Ficha Consolidada</span>
        </button>
      </div>

      {/* ========================================================
          PESTAÑA 1: IDENTIDAD ESPACIAL & ATMÓSFERA
         ======================================================== */}
      {activeTab === 'identidad' && (
        <div className="bg-[#13151D] border border-[#232632] rounded-3xl p-6 shadow-xl space-y-6">
          <div className="flex items-center justify-between border-b border-[#232632] pb-4">
            <div>
              <h3 className="text-base font-bold text-[#F3F4F6] flex items-center gap-2">
                <CompassIcon className="w-4 h-4 text-indigo-400" />
                <span>1. Identidad Espacial, Región y Atmósfera</span>
              </h3>
              <p className="text-xs text-[#8A8F9E] mt-0.5">
                Define el nombre maestro, la región de pertenencia, el tono ambiental y el grado de peligro para los visitantes.
              </p>
            </div>
            <span className="text-[10px] font-mono px-2.5 py-1 rounded-lg bg-[#181A24] text-[#A0A5B5] border border-[#2B2F3D]">
              ID: {currentPlace.id}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Nombre del Escenario */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-[#D0D4E4] block">
                Nombre del Escenario o Asentamiento *
              </label>
              <input
                type="text"
                value={currentPlace.name}
                onChange={e => setCurrentPlace({ ...currentPlace, name: e.target.value })}
                placeholder="Ej. Oasis de las Tres Lunas, Bastión de Hierro..."
                className="w-full bg-[#181A24] border border-[#2B2F3D] rounded-xl px-3.5 py-2.5 text-xs text-[#F3F4F6] focus:border-indigo-500 outline-hidden font-medium"
              />
            </div>

            {/* Región Geográfica */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-[#D0D4E4] block">
                  Región o Territorio
                </label>
                {worldConfig?.geographyHierarchy && (
                  <span className="text-[10px] text-indigo-400">Desde Worldbuilding</span>
                )}
              </div>
              {worldConfig?.geographyHierarchy && (
                <div className="flex flex-wrap gap-1 mb-1.5">
                  {[
                    ...(worldConfig.geographyHierarchy.regions || []),
                    ...(worldConfig.geographyHierarchy.countries || []),
                    ...(worldConfig.geographyHierarchy.continents || [])
                  ].slice(0, 6).map((geo, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setCurrentPlace({ ...currentPlace, region: geo })}
                      className={`text-[10px] px-2 py-0.5 rounded-md border transition-all cursor-pointer ${
                        currentPlace.region === geo
                          ? 'bg-indigo-600/30 border-indigo-500 text-indigo-200 font-bold'
                          : 'bg-[#1C1F2C] border-[#2F3446] text-indigo-300 hover:bg-indigo-950/40'
                      }`}
                      title={`Establecer ${geo} como región`}
                    >
                      📍 {geo}
                    </button>
                  ))}
                </div>
              )}
              <input
                type="text"
                value={currentPlace.region}
                onChange={e => setCurrentPlace({ ...currentPlace, region: e.target.value })}
                placeholder="Ej. Desierto de las Arenas Susurrantes, Provincia Central..."
                className="w-full bg-[#181A24] border border-[#2B2F3D] rounded-xl px-3.5 py-2.5 text-xs text-[#F3F4F6] focus:border-indigo-500 outline-hidden"
              />
            </div>

            {/* Tipo de Entorno / Ambiente */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-[#D0D4E4] block">
                Tipo de Entorno o Biotopo
              </label>
              <select
                value={currentPlace.environmentType}
                onChange={e => setCurrentPlace({ ...currentPlace, environmentType: e.target.value })}
                className="w-full bg-[#181A24] border border-[#2B2F3D] rounded-xl px-3.5 py-2.5 text-xs text-[#F3F4F6] focus:border-indigo-500 outline-hidden cursor-pointer"
              >
                <option value="Oasis">Oasis / Manantial Sagrado</option>
                <option value="Ciudadela">Ciudadela / Asentamiento Amurallado</option>
                <option value="Bosque">Bosque / Floresta Mística</option>
                <option value="Taberna">Distrito Urbano / Taberna / Zoco</option>
                <option value="Mazmorra">Mazmorra / Subterráneo / Fundición</option>
                <option value="Ruinas">Ruinas Arcanas / Catacumbas</option>
                <option value="Montaña">Fortaleza Montañosa / Acantilado</option>
                <option value="Costero">Puerto Marítimo / Ensenada</option>
              </select>
            </div>

            {/* Nivel de Peligro */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-[#D0D4E4] block">
                Nivel de Peligro para Visitantes
              </label>
              <div className="grid grid-cols-5 gap-1.5">
                {(['Seguro', 'Neutral', 'Disputado', 'Hostil', 'Mortal'] as const).map(lvl => {
                  const isSel = currentPlace.dangerLevel === lvl;
                  const colors = {
                    Seguro: 'bg-emerald-950/70 border-emerald-600 text-emerald-300',
                    Neutral: 'bg-blue-950/70 border-blue-600 text-blue-300',
                    Disputado: 'bg-amber-950/70 border-amber-600 text-amber-300',
                    Hostil: 'bg-rose-950/70 border-rose-600 text-rose-300',
                    Mortal: 'bg-purple-950/70 border-purple-600 text-purple-300'
                  };
                  return (
                    <button
                      key={lvl}
                      type="button"
                      onClick={() => setCurrentPlace({ ...currentPlace, dangerLevel: lvl })}
                      className={`py-2 px-1 text-[11px] font-bold rounded-xl border transition-all cursor-pointer text-center ${
                        isSel ? colors[lvl] : 'bg-[#181A24] border-[#2B2F3D] text-[#8A8F9E] hover:text-[#E0E0E0]'
                      }`}
                    >
                      {lvl}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Contexto Geográfico */}
            <div className="space-y-1.5 md:col-span-2">
              <label className="text-xs font-bold text-[#D0D4E4] block">
                Contexto Geográfico y Emplazamiento
              </label>
              <input
                type="text"
                value={currentPlace.geographicContext}
                onChange={e => setCurrentPlace({ ...currentPlace, geographicContext: e.target.value })}
                placeholder="Ej. Distrito urbano denso, asentamiento aislado en garganta montañosa, etc."
                className="w-full bg-[#181A24] border border-[#2B2F3D] rounded-xl px-3.5 py-2.5 text-xs text-[#F3F4F6] focus:border-indigo-500 outline-hidden"
              />
            </div>

            {/* Ritmo y Vibes (Chips interactivos con 1 clic) */}
            <div className="space-y-2 md:col-span-2 bg-[#181A24] p-4 rounded-2xl border border-[#262936]">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-[#D0D4E4]">
                  Ritmo & Vibes del Escenario (Pulsa para alternar)
                </label>
                <span className="text-[10px] text-[#8A8F9E]">
                  Seleccionados: {currentPlace.rhythmOrVibes?.length || 0}
                </span>
              </div>
              <div className="flex flex-wrap gap-1.5 pt-1">
                {SUGGESTIONS_BANK.vibes.map(vibe => {
                  const isSelected = (currentPlace.rhythmOrVibes || []).includes(vibe);
                  return (
                    <button
                      key={vibe}
                      type="button"
                      onClick={() => handleToggleVibe(vibe)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-indigo-600/30 border-indigo-500 text-indigo-200 font-bold shadow-xs'
                          : 'bg-[#12141C] border-[#2B2F3D] text-[#8A8F9E] hover:text-[#F3F4F6] hover:border-[#3D4357]'
                      }`}
                    >
                      {isSelected ? `✓ ${vibe}` : `+ ${vibe}`}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Atmósfera Sensorial con botón de sugerencia */}
            <div className="space-y-1.5 md:col-span-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-[#D0D4E4]">
                  Atmósfera Sensorial Inmersiva (Sonidos, olores, luces, temperatura)
                </label>
                <button
                  type="button"
                  onClick={() => {
                    const sample = `Brisa templada que transporta notas de especias y leña quemada; el murmullo continuo de transeúntes reverbera contra la piedra pulida bajo un cielo despejado.`;
                    setCurrentPlace({ ...currentPlace, atmosphere: sample });
                    showNotification('✓ ¡Atmósfera sensorial sugerida cargada!');
                  }}
                  className="text-[11px] text-indigo-400 hover:text-indigo-300 font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Sparkles className="w-3 h-3" />
                  <span>Sugerir Atmósfera</span>
                </button>
              </div>
              <textarea
                rows={2}
                value={currentPlace.atmosphere}
                onChange={e => setCurrentPlace({ ...currentPlace, atmosphere: e.target.value })}
                placeholder="Describe qué perciben los sentidos al cruzar el umbral del escenario..."
                className="w-full bg-[#181A24] border border-[#2B2F3D] rounded-xl p-3 text-xs text-[#F3F4F6] focus:border-indigo-500 outline-hidden leading-relaxed italic"
              />
            </div>

            {/* Descripción General de la Ficha */}
            <div className="space-y-1.5 md:col-span-2">
              <label className="text-xs font-bold text-[#D0D4E4] block">
                Descripción General y Función en el Mundo
              </label>
              <textarea
                rows={3}
                value={currentPlace.description}
                onChange={e => setCurrentPlace({ ...currentPlace, description: e.target.value })}
                placeholder="Historia breve, relevancia geopolítica o misterio central..."
                className="w-full bg-[#181A24] border border-[#2B2F3D] rounded-xl p-3 text-xs text-[#F3F4F6] focus:border-indigo-500 outline-hidden leading-relaxed"
              />
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          PESTAÑA 2: ARQUITECTURA & MATERIALES
         ======================================================== */}
      {activeTab === 'arquitectura' && (
        <div className="bg-[#13151D] border border-[#232632] rounded-3xl p-6 shadow-xl space-y-6">
          <div className="border-b border-[#232632] pb-4">
            <h3 className="text-base font-bold text-[#F3F4F6] flex items-center gap-2">
              <Building className="w-4 h-4 text-indigo-400" />
              <span>2. Arquitectura, Estilo y Materialidad</span>
            </h3>
            <p className="text-xs text-[#8A8F9E] mt-0.5">
              Configura el tipo de edificación predominante, su estado físico y los materiales utilizados en la construcción.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Estilo Constructivo */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-[#D0D4E4] block">
                Estilo Constructivo Predominante
              </label>
              <select
                value={currentPlace.constructionStyle}
                onChange={e => setCurrentPlace({ ...currentPlace, constructionStyle: e.target.value })}
                className="w-full bg-[#181A24] border border-[#2B2F3D] rounded-xl px-3.5 py-2.5 text-xs text-[#F3F4F6] focus:border-indigo-500 outline-hidden cursor-pointer"
              >
                <option value="Tradicional">Tradicional / Vernáculo (Piedra y Madera local)</option>
                <option value="Brutalismo">Brutalismo / Militar (Muros gruesos y ángulos rectos)</option>
                <option value="Industrial">Industrial / Fábrica (Vapor, engranajes y tuberías)</option>
                <option value="Mágico">Mágico / Arcana (Runas, cristales flotantes y bioluminiscencia)</option>
                <option value="Rústico">Rústico / Fronterizo (Troncos, paja y adobe)</option>
                <option value="Contemporáneo">Contemporáneo / Señorial (Mármol blanco, vidrio y forja fina)</option>
                <option value="Modular">Modular / Saqueador (Placas metálicas recicladas)</option>
              </select>
            </div>

            {/* Estado de Conservación */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-[#D0D4E4] block">
                Estado de Conservación
              </label>
              <select
                value={currentPlace.condition}
                onChange={e => setCurrentPlace({ ...currentPlace, condition: e.target.value })}
                className="w-full bg-[#181A24] border border-[#2B2F3D] rounded-xl px-3.5 py-2.5 text-xs text-[#F3F4F6] focus:border-indigo-500 outline-hidden cursor-pointer"
              >
                <option value="Prístino">Prístino / Impecable (Mantenimiento perfecto)</option>
                <option value="Conservado">Conservado / Habitual (Buen estado de uso)</option>
                <option value="Deteriorado">Deteriorado / Desgastado (Grietas, óxido y parches)</option>
                <option value="Ruinoso">Ruinoso / Parcialmente destruido</option>
                <option value="Abandonado">Abandonado / Conquistado por la naturaleza</option>
              </select>
            </div>

            {/* Materiales con Chips Interactivos */}
            <div className="space-y-2 md:col-span-2 bg-[#181A24] p-4 rounded-2xl border border-[#262936]">
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-xs font-bold text-[#D0D4E4]">
                    Materiales de Construcción (Pulsa para alternar)
                  </label>
                  <p className="text-[11px] text-[#8A8F9E]">
                    Elige los elementos primordiales de la edificación o añade uno personalizado.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const style = currentPlace.constructionStyle;
                    let mats = ['Piedra', 'Madera'];
                    if (style === 'Brutalismo') mats = ['Piedra', 'Metal', 'Hormigón'];
                    if (style === 'Industrial') mats = ['Metal', 'Hormigón', 'Ladrillo'];
                    if (style === 'Mágico') mats = ['Piedra', 'Cristales arcanos', 'Materiales fantásticos'];
                    if (style === 'Contemporáneo') mats = ['Mármol', 'Vidrio', 'Madera'];
                    setCurrentPlace({ ...currentPlace, materials: mats });
                    showNotification('✓ ¡Materiales sugeridos según estilo aplicados!');
                  }}
                  className="text-[11px] text-indigo-400 hover:text-indigo-300 font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Sparkles className="w-3 h-3" />
                  <span>Sugerir por Estilo</span>
                </button>
              </div>

              <div className="flex flex-wrap gap-1.5 pt-1">
                {SUGGESTIONS_BANK.materials.map(mat => {
                  const isSelected = (currentPlace.materials || []).includes(mat);
                  return (
                    <button
                      key={mat}
                      type="button"
                      onClick={() => handleToggleMaterial(mat)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-indigo-600/30 border-indigo-500 text-indigo-200 font-bold shadow-xs'
                          : 'bg-[#12141C] border-[#2B2F3D] text-[#8A8F9E] hover:text-[#F3F4F6]'
                      }`}
                    >
                      {isSelected ? `✓ ${mat}` : `+ ${mat}`}
                    </button>
                  );
                })}
              </div>

              {/* Agregar material personalizado */}
              <div className="flex items-center gap-2 pt-2">
                <input
                  type="text"
                  value={customMaterialInput}
                  onChange={e => setCustomMaterialInput(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === 'Enter' && customMaterialInput.trim()) {
                      e.preventDefault();
                      handleToggleMaterial(customMaterialInput.trim());
                      setCustomMaterialInput('');
                    }
                  }}
                  placeholder="Añadir otro material (ej. Cuarzo volcánico, Hueso de dragón)..."
                  className="bg-[#12141C] border border-[#2B2F3D] rounded-xl px-3 py-1.5 text-xs text-[#F3F4F6] focus:border-indigo-500 outline-hidden grow"
                />
                <button
                  type="button"
                  onClick={() => {
                    if (customMaterialInput.trim()) {
                      handleToggleMaterial(customMaterialInput.trim());
                      setCustomMaterialInput('');
                    }
                  }}
                  className="px-3 py-1.5 rounded-xl bg-[#232736] hover:bg-[#2F3448] text-xs text-[#E0E2EC] font-bold cursor-pointer"
                >
                  + Añadir
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          PESTAÑA 3: ECOSISTEMA URBANO & SERVICIOS
         ======================================================== */}
      {activeTab === 'ecosistema' && (
        <div className="space-y-6">
          {/* SECCIÓN A: Puntos de Interés Críticos */}
          <div className="bg-[#13151D] border border-[#232632] rounded-3xl p-6 shadow-xl space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#232632] pb-4">
              <div>
                <h3 className="text-base font-bold text-[#F3F4F6] flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-indigo-400" />
                  <span>A. Puntos de Interés Críticos ({poiCount})</span>
                </h3>
                <p className="text-xs text-[#8A8F9E] mt-0.5">
                  Establecimientos, talleres, santuarios y puestos clave que aparecen en el mapa interactivo y la biblioteca.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleSuggestPois}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-500/15 hover:bg-indigo-500/25 border border-indigo-500/40 text-indigo-300 font-bold text-xs cursor-pointer transition-all"
                  title="Añadir automáticamente 3 puntos de interés contextuales"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>✨ Sugerir 3 POIs</span>
                </button>

                <button
                  type="button"
                  onClick={handleAddCriticalPoi}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs cursor-pointer transition-all"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Añadir Punto</span>
                </button>
              </div>
            </div>

            {/* Barra de Arquetipos Rápidos de POI (1 Clic) */}
            <div className="space-y-1.5 bg-[#161822] p-3 rounded-2xl border border-[#232634]">
              <span className="text-[11px] font-bold text-[#8A8F9E] block">
                Arquetipos Rápidos de Puntos de Interés (1 Clic para añadir):
              </span>
              <div className="flex flex-wrap gap-1.5">
                {[
                  {
                    name: 'Taberna del Jabalí Herido',
                    type: 'Comercio / Taberna',
                    function: 'Punto de reunión, comida caliente, rumores y alojamiento',
                    owner: 'Tabernero local',
                    location: 'Plaza baja',
                    importance: 'Alta' as const,
                    description: 'Local cálido de vigas de roble y chimenea central concurrido por forasteros.'
                  },
                  {
                    name: 'Forja y Herrería del Yunque Gris',
                    type: 'Taller / Forja',
                    function: 'Reparación de equipo, forja de herramientas y fundición',
                    owner: 'Maestro herrero',
                    location: 'Sector artesanal',
                    importance: 'Media' as const,
                    description: 'Nave de piedra caliza con fuelles gemelos y olor a carbón de turba.'
                  },
                  {
                    name: 'Santuario de los Vientos Silentes',
                    type: 'Templo / Santuario',
                    function: 'Oración, bendiciones, archivo sacro y ritos funerarios',
                    owner: 'Clérigos o Custodios de la Fe',
                    location: 'Cima o terraza elevada',
                    importance: 'Alta' as const,
                    description: 'Estructura solemne con pebeteros de incienso y columnas grabadas.'
                  },
                  {
                    name: 'Bastión y Puesto de la Guardia',
                    type: 'Puesto de guardia',
                    function: 'Controles fronterizos, calabozo provisional y armería',
                    owner: 'Milicia local',
                    location: 'Puerta principal de acceso',
                    importance: 'Alta' as const,
                    description: 'Torreón de sillería fortificada con troneras y celda abovedada.'
                  },
                  {
                    name: 'Botica y Dispensario Alquímico',
                    type: 'Servicio / Sanatorio',
                    function: 'Elixires medicinales, vendajes y tratamiento de heridas',
                    owner: 'Boticario o Sanador',
                    location: 'Callejón interior',
                    importance: 'Media' as const,
                    description: 'Estantes repletos de frascos de vidrio con raíces secas y ungüentos.'
                  },
                  {
                    name: 'Gran Bazar de Trueque',
                    type: 'Comercio / Mercado',
                    function: 'Intercambio de suministros, especias y equipo exótico',
                    owner: 'Sindicato de Comerciantes',
                    location: 'Bulevar central',
                    importance: 'Media' as const,
                    description: 'Toldos de lona multicolor con mercancías venidas de tierras lejanas.'
                  }
                ].map((arch, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleAddPoiArchetype(arch)}
                    className="text-[10px] px-2.5 py-1 rounded-lg bg-[#1D202D] hover:bg-indigo-600/25 border border-[#2E3345] hover:border-indigo-500/50 text-[#D0D4E4] hover:text-indigo-200 transition-all cursor-pointer font-medium"
                    title={`Añadir ${arch.name}`}
                  >
                    + {arch.name.split(' ')[0]} {arch.name.split(' ')[1]} ({arch.type.split('/')[0].trim()})
                  </button>
                ))}
              </div>
            </div>

            {(!currentPlace.criticalPointsOfInterest || currentPlace.criticalPointsOfInterest.length === 0) ? (
              <div className="p-8 text-center bg-[#181A24] rounded-2xl border border-dashed border-[#2B2F3D] space-y-2">
                <MapPin className="w-8 h-8 text-[#5A6072] mx-auto" />
                <p className="text-xs text-[#8A8F9E]">
                  Aún no hay puntos de interés específicos. Añade uno o usa el generador asistido.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {currentPlace.criticalPointsOfInterest.map((poi, idx) => (
                  <div
                    key={poi.id || idx}
                    className="bg-[#181A24] border border-[#262936] rounded-2xl p-4.5 space-y-3 relative group hover:border-[#383D50] transition-all"
                  >
                    <div className="flex items-center justify-between gap-2 border-b border-[#232632] pb-2.5">
                      <div className="flex items-center gap-2">
                        <span className="w-5 h-5 rounded-full bg-indigo-500/20 text-indigo-400 font-mono text-[10px] flex items-center justify-center font-bold">
                          {idx + 1}
                        </span>
                        <input
                          type="text"
                          value={poi.name}
                          onChange={e => handleUpdateCriticalPoi(idx, 'name', e.target.value)}
                          placeholder="Nombre del Punto de Interés..."
                          className="bg-transparent text-xs font-bold text-[#F3F4F6] focus:border-b focus:border-indigo-500 outline-hidden w-48"
                        />
                      </div>

                      <div className="flex items-center gap-2">
                        <select
                          value={poi.importance}
                          onChange={e => handleUpdateCriticalPoi(idx, 'importance', e.target.value)}
                          className="bg-[#12141C] border border-[#2B2F3D] rounded-lg px-2 py-0.5 text-[10px] font-bold text-amber-300 outline-hidden cursor-pointer"
                        >
                          <option value="Baja">Baja</option>
                          <option value="Media">Media</option>
                          <option value="Alta">Alta</option>
                          <option value="Crítica">Crítica</option>
                        </select>

                        <button
                          type="button"
                          onClick={() => handleRemoveCriticalPoi(idx)}
                          className="p-1 rounded-lg hover:bg-rose-950/50 text-[#8A8F9E] hover:text-rose-400 cursor-pointer"
                          title="Eliminar punto de interés"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <label className="text-[10px] text-[#8A8F9E] block">Tipo</label>
                        <input
                          type="text"
                          value={poi.type}
                          onChange={e => handleUpdateCriticalPoi(idx, 'type', e.target.value)}
                          placeholder="Ej. Taller, Altar, Puesto..."
                          className="w-full bg-[#12141C] border border-[#262936] rounded-lg px-2.5 py-1 text-xs text-[#D0D4E4] outline-hidden focus:border-indigo-500"
                        />
                      </div>

                      <div>
                        <div className="flex items-center justify-between">
                          <label className="text-[10px] text-[#8A8F9E] block">Custodio / Propietario</label>
                          {worldConfig?.politics?.factions && worldConfig.politics.factions.length > 0 && (
                            <span className="text-[9px] text-amber-400">Facciones</span>
                          )}
                        </div>
                        {worldConfig?.politics?.factions && worldConfig.politics.factions.length > 0 && (
                          <div className="flex flex-wrap gap-1 mb-1">
                            {worldConfig.politics.factions.slice(0, 3).map(f => (
                              <button
                                key={f.id}
                                type="button"
                                onClick={() => handleUpdateCriticalPoi(idx, 'owner', f.name)}
                                className="text-[9px] px-1.5 py-0.5 rounded bg-[#1A1D2B] border border-[#2B3042] text-amber-300/90 hover:bg-amber-950/40 cursor-pointer"
                                title={`Asignar ${f.name} como custodio`}
                              >
                                {f.emblemIcon || '🛡️'} {f.name}
                              </button>
                            ))}
                          </div>
                        )}
                        <input
                          type="text"
                          value={poi.owner}
                          onChange={e => handleUpdateCriticalPoi(idx, 'owner', e.target.value)}
                          placeholder="Ej. Gremio, Guardia, Sacerdocio..."
                          className="w-full bg-[#12141C] border border-[#262936] rounded-lg px-2.5 py-1 text-xs text-[#D0D4E4] outline-hidden focus:border-indigo-500"
                        />
                      </div>

                      <div className="col-span-2">
                        <label className="text-[10px] text-[#8A8F9E] block">Función Principal</label>
                        <input
                          type="text"
                          value={poi.function}
                          onChange={e => handleUpdateCriticalPoi(idx, 'function', e.target.value)}
                          placeholder="Ej. Comercio de reliquias, sanación de viajeros..."
                          className="w-full bg-[#12141C] border border-[#262936] rounded-lg px-2.5 py-1 text-xs text-[#D0D4E4] outline-hidden focus:border-indigo-500"
                        />
                      </div>

                      <div className="col-span-2">
                        <label className="text-[10px] text-[#8A8F9E] block">Ubicación Relativa</label>
                        <input
                          type="text"
                          value={poi.location}
                          onChange={e => handleUpdateCriticalPoi(idx, 'location', e.target.value)}
                          placeholder="Ej. Costado norte de la plaza central..."
                          className="w-full bg-[#12141C] border border-[#262936] rounded-lg px-2.5 py-1 text-xs text-[#D0D4E4] outline-hidden focus:border-indigo-500"
                        />
                      </div>

                      <div className="col-span-2">
                        <label className="text-[10px] text-[#8A8F9E] block">Descripción Detallada</label>
                        <textarea
                          rows={2}
                          value={poi.description}
                          onChange={e => handleUpdateCriticalPoi(idx, 'description', e.target.value)}
                          placeholder="Rasgos visuales y ambiente particular..."
                          className="w-full bg-[#12141C] border border-[#262936] rounded-lg p-2 text-xs text-[#D0D4E4] outline-hidden focus:border-indigo-500 leading-relaxed"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* SECCIÓN B: Zonas de Convergencia Social */}
          <div className="bg-[#13151D] border border-[#232632] rounded-3xl p-6 shadow-xl space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#232632] pb-4">
              <div>
                <h3 className="text-base font-bold text-[#F3F4F6] flex items-center gap-2">
                  <Users className="w-4 h-4 text-emerald-400" />
                  <span>B. Zonas de Convergencia Social ({zoneCount})</span>
                </h3>
                <p className="text-xs text-[#8A8F9E] mt-0.5">
                  Plazas, cantinas y bulevares donde los NPCs se congregan espontáneamente según el ciclo horario.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleSuggestConvergenceZone}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/40 text-emerald-300 font-bold text-xs cursor-pointer transition-all"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>✨ Sugerir Zona</span>
                </button>

                <button
                  type="button"
                  onClick={handleAddConvergenceZone}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs cursor-pointer transition-all"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Añadir Zona</span>
                </button>
              </div>
            </div>

            {/* Barra de Arquetipos Rápidos de Zonas de Convergencia (1 Clic) */}
            <div className="space-y-1.5 bg-[#161822] p-3 rounded-2xl border border-[#232634]">
              <span className="text-[11px] font-bold text-[#8A8F9E] block">
                Arquetipos Rápidos de Convergencia Social (1 Clic para añadir):
              </span>
              <div className="flex flex-wrap gap-1.5">
                {[
                  {
                    name: 'Gran Ágora o Plaza Mayor',
                    type: 'Plaza Central',
                    schedule: 'Mediodía y Atardecer',
                    npcDensity: 'Alta' as const,
                    securityLevel: 'Medio' as const,
                    frequentEvents: 'Proclamas, pregones, intercambio de noticias y espectáculos callejeros',
                    associatedCharacters: ['Ciudadanos', 'Mercaderes', 'Músicos']
                  },
                  {
                    name: 'Callejón Umbrío de los Susurros',
                    type: 'Callejón / Bajos Fondos',
                    schedule: 'Medianoche y Madrugada',
                    npcDensity: 'Baja' as const,
                    securityLevel: 'Bajo' as const,
                    frequentEvents: 'Encuentros clandestinos, transacciones discretas y vigilancia silenciosa',
                    associatedCharacters: ['Informantes', 'Contrabandistas']
                  },
                  {
                    name: 'Dársena del Muelle Fluvial',
                    type: 'Puerto / Embarcadero',
                    schedule: 'Amanecer y Mañanas',
                    npcDensity: 'Alta' as const,
                    securityLevel: 'Medio' as const,
                    frequentEvents: 'Descarga de fardos, contratación de marineros y regateo de pescado fresco',
                    associatedCharacters: ['Marineros', 'Estibadores', 'Pescadores']
                  },
                  {
                    name: 'Salón de Tertulias y Porche Comunal',
                    type: 'Terraza / Taberna',
                    schedule: 'Noches y Festivos',
                    npcDensity: 'Media' as const,
                    securityLevel: 'Alto' as const,
                    frequentEvents: 'Partidas de dados, cánticos, brindis y asambleas informales',
                    associatedCharacters: ['Parroquianos', 'Veteranos']
                  }
                ].map((arch, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleAddZoneArchetype(arch)}
                    className="text-[10px] px-2.5 py-1 rounded-lg bg-[#1D202D] hover:bg-emerald-600/25 border border-[#2E3345] hover:border-emerald-500/50 text-[#D0D4E4] hover:text-emerald-200 transition-all cursor-pointer font-medium"
                    title={`Añadir ${arch.name}`}
                  >
                    + {arch.name} ({arch.schedule})
                  </button>
                ))}
              </div>
            </div>

            {(!currentPlace.convergenceZones || currentPlace.convergenceZones.length === 0) ? (
              <div className="p-8 text-center bg-[#181A24] rounded-2xl border border-dashed border-[#2B2F3D] space-y-2">
                <Users className="w-8 h-8 text-[#5A6072] mx-auto" />
                <p className="text-xs text-[#8A8F9E]">
                  Sin zonas de reunión social. Pulsa "+ Añadir Zona" para modelar plazas o mercados.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {currentPlace.convergenceZones.map((zone, idx) => (
                  <div
                    key={zone.id || idx}
                    className="bg-[#181A24] border border-[#262936] rounded-2xl p-4.5 space-y-3"
                  >
                    <div className="flex items-center justify-between gap-2 border-b border-[#232632] pb-2.5">
                      <input
                        type="text"
                        value={zone.name}
                        onChange={e => handleUpdateConvergenceZone(idx, 'name', e.target.value)}
                        placeholder="Nombre de la Zona..."
                        className="bg-transparent text-xs font-bold text-[#F3F4F6] focus:border-b focus:border-emerald-500 outline-hidden w-52"
                      />
                      <button
                        type="button"
                        onClick={() => handleRemoveConvergenceZone(idx)}
                        className="p-1 rounded-lg hover:bg-rose-950/50 text-[#8A8F9E] hover:text-rose-400 cursor-pointer"
                        title="Eliminar zona"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <label className="text-[10px] text-[#8A8F9E] block">Tipo de Espacio</label>
                        <input
                          type="text"
                          value={zone.type}
                          onChange={e => handleUpdateConvergenceZone(idx, 'type', e.target.value)}
                          placeholder="Ej. Plaza, Cantina, Terraza..."
                          className="w-full bg-[#12141C] border border-[#262936] rounded-lg px-2.5 py-1 text-xs text-[#D0D4E4] outline-hidden focus:border-emerald-500"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] text-[#8A8F9E] block">Horario de Mayor Afluencia</label>
                        <input
                          type="text"
                          value={zone.schedule}
                          onChange={e => handleUpdateConvergenceZone(idx, 'schedule', e.target.value)}
                          placeholder="Ej. Tardes y anochecer..."
                          className="w-full bg-[#12141C] border border-[#262936] rounded-lg px-2.5 py-1 text-xs text-[#D0D4E4] outline-hidden focus:border-emerald-500"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] text-[#8A8F9E] block">Densidad NPC</label>
                        <select
                          value={zone.npcDensity}
                          onChange={e => handleUpdateConvergenceZone(idx, 'npcDensity', e.target.value)}
                          className="w-full bg-[#12141C] border border-[#262936] rounded-lg px-2.5 py-1 text-xs text-[#D0D4E4] outline-hidden cursor-pointer"
                        >
                          <option value="Nula">Nula / Desierto</option>
                          <option value="Baja">Baja (Pocos transeúntes)</option>
                          <option value="Media">Media (Grupos moderados)</option>
                          <option value="Alta">Alta (Concurrido)</option>
                          <option value="Frenética">Frenética (Multitud compacta)</option>
                        </select>
                      </div>

                      <div>
                        <label className="text-[10px] text-[#8A8F9E] block">Nivel de Seguridad</label>
                        <input
                          type="text"
                          value={zone.securityLevel}
                          onChange={e => handleUpdateConvergenceZone(idx, 'securityLevel', e.target.value)}
                          placeholder="Ej. Patrullaje medio, Sin vigilancia..."
                          className="w-full bg-[#12141C] border border-[#262936] rounded-lg px-2.5 py-1 text-xs text-[#D0D4E4] outline-hidden focus:border-emerald-500"
                        />
                      </div>

                      <div className="col-span-2">
                        <label className="text-[10px] text-[#8A8F9E] block">Eventos o Dinámicas Frecuentes</label>
                        <input
                          type="text"
                          value={zone.frequentEvents}
                          onChange={e => handleUpdateConvergenceZone(idx, 'frequentEvents', e.target.value)}
                          placeholder="Ej. Trueques, recitales, disputas..."
                          className="w-full bg-[#12141C] border border-[#262936] rounded-lg px-2.5 py-1 text-xs text-[#D0D4E4] outline-hidden focus:border-emerald-500"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* SECCIÓN C: Cultura y Seguridad */}
          <div className="bg-[#13151D] border border-[#232632] rounded-3xl p-6 shadow-xl space-y-5">
            <div className="border-b border-[#232632] pb-4">
              <h3 className="text-base font-bold text-[#F3F4F6] flex items-center gap-2">
                <Shield className="w-4 h-4 text-amber-400" />
                <span>C. Cultura Local & Normas de Seguridad</span>
              </h3>
              <p className="text-xs text-[#8A8F9E] mt-0.5">
                Rige la autoridad que impone el orden y la conducta social aceptada por los habitantes.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-[#D0D4E4] block">
                    Autoridad a Cargo
                  </label>
                  {worldConfig?.politics?.factions && worldConfig.politics.factions.length > 0 && (
                    <span className="text-[10px] text-amber-400">Facciones del Mundo</span>
                  )}
                </div>

                {/* Chips de Facciones del Mundo si existen */}
                {worldConfig?.politics?.factions && worldConfig.politics.factions.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-1.5">
                    {worldConfig.politics.factions.map(f => (
                      <button
                        key={f.id}
                        type="button"
                        onClick={() =>
                          setCurrentPlace({
                            ...currentPlace,
                            cultureAndSecurity: {
                              ...(currentPlace.cultureAndSecurity || { surveillance: 'Media' }),
                              authority: f.name
                            }
                          })
                        }
                        className={`text-[10px] px-2 py-0.5 rounded-md border transition-all cursor-pointer flex items-center gap-1 ${
                          currentPlace.cultureAndSecurity?.authority === f.name
                            ? 'bg-amber-500/25 border-amber-500 text-amber-200 font-bold'
                            : 'bg-[#181A24] border-[#2A2E3D] text-[#8A8F9E] hover:text-amber-300'
                        }`}
                        title={`Asignar ${f.name} como autoridad`}
                      >
                        <span>{f.emblemIcon || '🛡️'}</span>
                        <span>{f.name}</span>
                      </button>
                    ))}
                  </div>
                )}

                <div className="flex items-center gap-2">
                  <select
                    value={
                      ['Gobierno', 'Milicia', 'Sacerdocio', 'Gremios', 'Comunidad', 'Organización criminal', 'Nadie'].includes(
                        currentPlace.cultureAndSecurity?.authority || ''
                      )
                        ? currentPlace.cultureAndSecurity?.authority
                        : 'Personalizada'
                    }
                    onChange={e => {
                      const val = e.target.value;
                      if (val !== 'Personalizada') {
                        setCurrentPlace({
                          ...currentPlace,
                          cultureAndSecurity: {
                            ...(currentPlace.cultureAndSecurity || { surveillance: 'Media' }),
                            authority: val
                          }
                        });
                      }
                    }}
                    className="w-1/2 bg-[#181A24] border border-[#2B2F3D] rounded-xl px-3 py-2 text-xs text-[#F3F4F6] focus:border-indigo-500 outline-hidden cursor-pointer"
                  >
                    <option value="Gobierno">Gobierno Civil / Alcaldía</option>
                    <option value="Milicia">Milicia / Guarnición Militar</option>
                    <option value="Sacerdocio">Sacerdocio / Templo Religioso</option>
                    <option value="Gremios">Gremios Mercantiles y Artesanos</option>
                    <option value="Comunidad">Comunidad Autónoma / Asamblea</option>
                    <option value="Organización criminal">Sindicato Clandestino / Cártel</option>
                    <option value="Nadie">Sin Autoridad / Territorio Sin Ley</option>
                    <option value="Personalizada">Ficción / Específica...</option>
                  </select>

                  <input
                    type="text"
                    value={currentPlace.cultureAndSecurity?.authority || ''}
                    onChange={e =>
                      setCurrentPlace({
                        ...currentPlace,
                        cultureAndSecurity: {
                          ...(currentPlace.cultureAndSecurity || { surveillance: 'Media' }),
                          authority: e.target.value
                        }
                      })
                    }
                    placeholder="Escribir o editar autoridad..."
                    className="w-1/2 bg-[#181A24] border border-[#2B2F3D] rounded-xl px-3 py-2 text-xs text-[#F3F4F6] focus:border-indigo-500 outline-hidden font-medium"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-[#D0D4E4] block">
                  Intensidad de Vigilancia
                </label>
                <select
                  value={currentPlace.cultureAndSecurity?.surveillance || 'Media'}
                  onChange={e =>
                    setCurrentPlace({
                      ...currentPlace,
                      cultureAndSecurity: {
                        ...(currentPlace.cultureAndSecurity || { authority: 'Gobierno' }),
                        surveillance: e.target.value
                      }
                    })
                  }
                  className="w-full bg-[#181A24] border border-[#2B2F3D] rounded-xl px-3.5 py-2.5 text-xs text-[#F3F4F6] focus:border-indigo-500 outline-hidden cursor-pointer"
                >
                  <option value="Nula">Nula (Sin centinelas ni ojos curiosos)</option>
                  <option value="Baja">Baja (Guardias ocasionales)</option>
                  <option value="Media">Media (Rondas regulares y controles en accesos)</option>
                  <option value="Alta">Alta (Patrullas constantes y registro de forasteros)</option>
                  <option value="Extrema">Extrema (Estado de sitio o vigilancia mágica total)</option>
                </select>
              </div>

              {/* Conducta Social (Chips interactivos) */}
              <div className="space-y-2 md:col-span-2 bg-[#181A24] p-4 rounded-2xl border border-[#262936]">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-[#D0D4E4]">
                    Conducta Social Predominante (Pulsa para alternar)
                  </label>
                  <span className="text-[10px] text-[#8A8F9E]">
                    Seleccionadas: {currentPlace.cultureAndSecurity?.socialConduct?.length || 0}
                  </span>
                </div>
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {SUGGESTIONS_BANK.socialConducts.map(cond => {
                    const isSelected = (currentPlace.cultureAndSecurity?.socialConduct || []).includes(cond);
                    return (
                      <button
                        key={cond}
                        type="button"
                        onClick={() => handleToggleConduct(cond)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-amber-600/25 border-amber-500 text-amber-200 font-bold shadow-xs'
                            : 'bg-[#12141C] border-[#2B2F3D] text-[#8A8F9E] hover:text-[#F3F4F6]'
                        }`}
                      >
                        {isSelected ? `✓ ${cond}` : `+ ${cond}`}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          PESTAÑA 4: VIVIENDA & NIVELES
         ======================================================== */}
      {activeTab === 'vivienda' && (
        <div className="bg-[#13151D] border border-[#232632] rounded-3xl p-6 shadow-xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#232632] pb-4">
            <div>
              <h3 className="text-base font-bold text-[#F3F4F6] flex items-center gap-2">
                <Home className="w-4 h-4 text-indigo-400" />
                <span>4. Vivienda, Distribución de Niveles & Habitaciones</span>
              </h3>
              <p className="text-xs text-[#8A8F9E] mt-0.5">
                Estructura el aposento o habitáculo personal dentro de este escenario, con plantas, muebles y objetos interactivos.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <label className="flex items-center gap-2 text-xs font-bold text-[#D0D4E4] cursor-pointer">
                <input
                  type="checkbox"
                  checked={currentPlace.hasHousing}
                  onChange={e => {
                    const has = e.target.checked;
                    if (has && !currentPlace.housing) {
                      setCurrentPlace({
                        ...currentPlace,
                        hasHousing: true,
                        housing: {
                          buildingType: 'Casa',
                          levels: [
                            {
                              levelNumber: 0,
                              levelName: 'NIVEL 0 — PLANTA PRINCIPAL',
                              rooms: []
                            }
                          ],
                          exteriorsAndConnectivity: ['Patios', 'Balcones']
                        }
                      });
                    } else {
                      setCurrentPlace({ ...currentPlace, hasHousing: has });
                    }
                  }}
                  className="rounded-md border-[#3A3F4E] text-indigo-600 focus:ring-0 w-4 h-4 cursor-pointer"
                />
                <span>¿Incluye Vivienda / Aposento Personal?</span>
              </label>
            </div>
          </div>

          {!currentPlace.hasHousing ? (
            <div className="p-10 text-center bg-[#181A24] rounded-2xl border border-dashed border-[#2B2F3D] space-y-3">
              <Home className="w-10 h-10 text-[#5A6072] mx-auto" />
              <div className="space-y-1">
                <p className="text-sm font-bold text-[#D0D4E4]">Escenario sin Vivienda Modelada</p>
                <p className="text-xs text-[#8A8F9E] max-w-md mx-auto">
                  Este escenario funciona como espacio público o salvaje. Si deseas asignar un aposento o residencia para personajes, activa la casilla superior.
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-[#181A24] p-4 rounded-2xl border border-[#262936]">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-[#D0D4E4] block">
                    Tipo de Edificación
                  </label>
                  <select
                    value={currentPlace.housing?.buildingType || 'Casa'}
                    onChange={e => {
                      if (!currentPlace.housing) return;
                      setCurrentPlace({
                        ...currentPlace,
                        housing: { ...currentPlace.housing, buildingType: e.target.value }
                      })
                    }}
                    className="w-full bg-[#12141C] border border-[#2B2F3D] rounded-xl px-3.5 py-2 text-xs text-[#F3F4F6] focus:border-indigo-500 outline-hidden cursor-pointer"
                  >
                    <option value="Casa">Casa / Residencia Independiente</option>
                    <option value="Departamento">Departamento / Estudio Urbano</option>
                    <option value="Triplex">Residencia Triplex Señorial</option>
                    <option value="Búnker">Búnker / Refugio Fortificado</option>
                    <option value="Taller-vivienda">Taller-vivienda / Buhardilla Comercial</option>
                    <option value="Departamento colmena">Cápsula / Departamento Colmena</option>
                  </select>
                </div>

                {/* Chips de Conectividad & Exteriores */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-[#D0D4E4] block">
                    Exteriores & Conectividad Inmediata
                  </label>
                  <div className="flex flex-wrap gap-1">
                    {SUGGESTIONS_BANK.connectivityTags.slice(0, 6).map(tag => {
                      const isSel = (currentPlace.housing?.exteriorsAndConnectivity || []).includes(tag);
                      return (
                        <button
                          key={tag}
                          type="button"
                          onClick={() => handleToggleConnectivity(tag)}
                          className={`px-2 py-1 rounded-lg text-[10px] font-medium border transition-all cursor-pointer ${
                            isSel
                              ? 'bg-indigo-600/30 border-indigo-500 text-indigo-200 font-bold'
                              : 'bg-[#12141C] border-[#2B2F3D] text-[#8A8F9E] hover:text-[#FFF]'
                          }`}
                        >
                          {isSel ? `✓ ${tag}` : `+ ${tag}`}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Lista de Niveles y Habitaciones */}
              <div className="space-y-5">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-[#A0A5B5]">
                    Niveles de la Vivienda ({currentPlace.housing?.levels?.length || 0})
                  </h4>
                  <button
                    type="button"
                    onClick={handleAddLevel}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#222636] hover:bg-[#2D3346] text-xs font-bold text-[#E0E2EC] cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5 text-indigo-400" />
                    <span>+ Añadir Nivel</span>
                  </button>
                </div>

                {currentPlace.housing?.levels.map((lvl, levelIdx) => (
                  <div
                    key={lvl.levelNumber}
                    className="bg-[#181A24] border border-[#2B2F3D] rounded-2xl p-5 space-y-4"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#242734] pb-3">
                      <div className="flex items-center gap-2">
                        <span className="px-2.5 py-1 rounded-lg bg-indigo-500/20 text-indigo-300 font-mono text-xs font-bold">
                          NIVEL {lvl.levelNumber}
                        </span>
                        <input
                          type="text"
                          value={lvl.levelName}
                          onChange={e => {
                            if (!currentPlace.housing) return;
                            const levels = [...currentPlace.housing.levels];
                            levels[levelIdx].levelName = e.target.value;
                            setCurrentPlace({
                              ...currentPlace,
                              housing: { ...currentPlace.housing, levels }
                            });
                          }}
                          placeholder="Nombre del Nivel..."
                          className="bg-transparent text-xs font-bold text-[#F3F4F6] focus:border-b focus:border-indigo-500 outline-hidden w-64"
                        />
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleSuggestRooms(levelIdx)}
                          className="flex items-center gap-1 text-[11px] px-2.5 py-1 rounded-lg bg-indigo-500/15 text-indigo-300 border border-indigo-500/30 hover:bg-indigo-500/25 font-bold cursor-pointer"
                        >
                          <Sparkles className="w-3 h-3" />
                          <span>Sugerir Habitaciones</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleAddRoom(levelIdx)}
                          className="flex items-center gap-1 text-[11px] px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold cursor-pointer"
                        >
                          <Plus className="w-3 h-3" />
                          <span>+ Habitación</span>
                        </button>
                      </div>
                    </div>

                    {/* Arquetipos Rápidos de Estancia (1 Clic) */}
                    <div className="flex flex-wrap items-center gap-1.5 bg-[#141620] p-2.5 rounded-xl border border-[#232634]">
                      <span className="text-[10px] font-bold text-[#8A8F9E] mr-1">Añadir Estancia Rápida:</span>
                      {[
                        {
                          name: 'Dormitorio Principal',
                          function: 'Descanso y privacidad',
                          furniture: ['Cama con dosel', 'Armario de roble', 'Cómoda con espejo'],
                          objects: ['Diario de viaje', 'Candil de aceite'],
                          accesses: ['Pasillo central', 'Balcón exterior'],
                          description: 'Habitación íntima con alfombras gruesas y cortinajes para aislar el frío.'
                        },
                        {
                          name: 'Salón de Estar y Hogar',
                          function: 'Reunión y descanso común',
                          furniture: ['Chimenea de piedra', 'Sillones acolchados', 'Mesa baja de centro'],
                          objects: ['Baraja de naipes', 'Copas de barro'],
                          accesses: ['Entrada principal', 'Comedor'],
                          description: 'Espacio cálido alrededor del fuego central con trofeos y tapices.'
                        },
                        {
                          name: 'Cocina y Despensa',
                          function: 'Preparación de alimentos y víveres',
                          furniture: ['Fogón de leña', 'Mesa de picar', 'Alacena de especias'],
                          objects: ['Cacerolas de cobre', 'Cuchillos forjados', 'Tinajas de grano'],
                          accesses: ['Salón', 'Patio trasero'],
                          description: 'Lugar aromático con ristras de hierbas secas y brasas listas para cocinar.'
                        },
                        {
                          name: 'Taller / Estudio Arcano',
                          function: 'Estudio, trabajo y creación',
                          furniture: ['Escritorio amplio', 'Librería alta', 'Aparador con crisoles'],
                          objects: ['Pergaminos', 'Pluma y tinta violeta', 'Lupa de orfebre'],
                          accesses: ['Pasillo interior'],
                          description: 'Habitación repleta de tomos encuadernados en piel, notas y frascos reactivos.'
                        },
                        {
                          name: 'Armería y Vestidor',
                          function: 'Custodia de pertrechos y armas',
                          furniture: ['Armero de madera', 'Baúl reforzado', 'Perchero de cuero'],
                          objects: ['Piedra de afilar', 'Aceite para cotas', 'Peto ceremonial'],
                          accesses: ['Dormitorio', 'Entrada'],
                          description: 'Estancia austera y ordenada con soportes para hojas, arcos y corazas.'
                        }
                      ].map((arch, aIdx) => (
                        <button
                          key={aIdx}
                          type="button"
                          onClick={() => handleAddRoomArchetype(levelIdx, arch)}
                          className="text-[10px] px-2 py-0.5 rounded-md bg-[#1C1F2C] hover:bg-indigo-600/30 border border-[#2B3042] hover:border-indigo-500/50 text-[#D0D4E4] hover:text-indigo-200 transition-all cursor-pointer font-medium"
                          title={`Añadir ${arch.name}`}
                        >
                          + {arch.name}
                        </button>
                      ))}
                    </div>

                    {lvl.rooms.length === 0 ? (
                      <p className="text-xs text-[#8A8F9E] italic py-2">
                        Este nivel no tiene habitaciones configuradas. Pulsa "+ Habitación" o "Sugerir Habitaciones".
                      </p>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {lvl.rooms.map((room, roomIdx) => (
                          <div
                            key={room.id || roomIdx}
                            className="bg-[#12141C] border border-[#232634] rounded-xl p-3.5 space-y-2.5"
                          >
                            <div className="flex items-center justify-between border-b border-[#1E212D] pb-2">
                              <input
                                type="text"
                                value={room.name}
                                onChange={e => handleUpdateRoom(levelIdx, roomIdx, 'name', e.target.value)}
                                placeholder="Nombre de la Habitación..."
                                className="bg-transparent text-xs font-bold text-[#F3F4F6] focus:border-b focus:border-indigo-500 outline-hidden w-40"
                              />
                              <button
                                type="button"
                                onClick={() => handleRemoveRoom(levelIdx, roomIdx)}
                                className="p-1 text-[#8A8F9E] hover:text-rose-400 cursor-pointer"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>

                            <div className="space-y-1.5 text-xs">
                              <div>
                                <label className="text-[10px] text-[#8A8F9E] block">Función</label>
                                <input
                                  type="text"
                                  value={room.function}
                                  onChange={e => handleUpdateRoom(levelIdx, roomIdx, 'function', e.target.value)}
                                  placeholder="Ej. Dormitorio, Taller, Salón..."
                                  className="w-full bg-[#181A24] border border-[#262936] rounded-md px-2 py-1 text-xs text-[#D0D4E4] outline-hidden"
                                />
                              </div>

                              <div>
                                <label className="text-[10px] text-[#8A8F9E] block">Mobiliario Principal (separado por comas)</label>
                                <input
                                  type="text"
                                  value={room.furniture?.join(', ') || ''}
                                  onChange={e => {
                                    const arr = e.target.value.split(',').map(s => s.trim()).filter(Boolean);
                                    handleUpdateRoom(levelIdx, roomIdx, 'furniture', arr);
                                  }}
                                  placeholder="Ej. Cama dosel, Escritorio, Armario..."
                                  className="w-full bg-[#181A24] border border-[#262936] rounded-md px-2 py-1 text-xs text-[#D0D4E4] outline-hidden"
                                />
                              </div>

                              <div>
                                <label className="text-[10px] text-[#8A8F9E] block">Objetos Clave (separados por comas)</label>
                                <input
                                  type="text"
                                  value={room.objects?.join(', ') || ''}
                                  onChange={e => {
                                    const arr = e.target.value.split(',').map(s => s.trim()).filter(Boolean);
                                    handleUpdateRoom(levelIdx, roomIdx, 'objects', arr);
                                  }}
                                  placeholder="Ej. Farol de noche, Libro de navegación..."
                                  className="w-full bg-[#181A24] border border-[#262936] rounded-md px-2 py-1 text-xs text-[#D0D4E4] outline-hidden"
                                />
                              </div>

                              <div>
                                <label className="text-[10px] text-[#8A8F9E] block">Detalle Ambiental</label>
                                <textarea
                                  rows={2}
                                  value={room.description}
                                  onChange={e => handleUpdateRoom(levelIdx, roomIdx, 'description', e.target.value)}
                                  placeholder="Sensación al entrar a esta habitación..."
                                  className="w-full bg-[#181A24] border border-[#262936] rounded-md p-1.5 text-xs text-[#D0D4E4] outline-hidden"
                                />
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================
          PESTAÑA 5: ELEMENTOS ÚNICOS & ANOMALÍAS
         ======================================================== */}
      {activeTab === 'elementos' && (
        <div className="bg-[#13151D] border border-[#232632] rounded-3xl p-6 shadow-xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#232632] pb-4">
            <div>
              <h3 className="text-base font-bold text-[#F3F4F6] flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-purple-400" />
                <span>5. Elementos Únicos, Mecanismos & Anomalías ({uniqueCount})</span>
              </h3>
              <p className="text-xs text-[#8A8F9E] mt-0.5">
                Reliquias, artefactos mecánicos, fenómenos climáticos persistentes o leyes particulares exclusivas de este lugar.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleSuggestUniqueElement}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-500/15 hover:bg-purple-500/25 border border-purple-500/40 text-purple-300 font-bold text-xs cursor-pointer transition-all"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>✨ Sugerir Elemento</span>
              </button>

              <button
                type="button"
                onClick={handleAddUniqueElement}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs cursor-pointer transition-all"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ Añadir Elemento</span>
              </button>
            </div>
          </div>

          {/* Barra de Arquetipos Rápidos de Elementos Únicos (1 Clic) */}
          <div className="space-y-1.5 bg-[#161822] p-3 rounded-2xl border border-[#232634]">
            <span className="text-[11px] font-bold text-[#8A8F9E] block">
              Arquetipos Rápidos de Elementos & Anomalías (1 Clic para añadir):
            </span>
            <div className="flex flex-wrap gap-1.5">
              {[
                {
                  name: 'Reliquia del Núcleo Rúnico',
                  type: 'OBJETO' as UniqueElementType,
                  importance: 'Clave de trama / Mágico',
                  behavior: 'Emite un zumbido armónico que estabiliza artefactos arcanos en 50m.',
                  description: 'Artefacto esférico de metal estelar suspendido en una hornacina protegida.'
                },
                {
                  name: 'Mecanismo de Elevador Hidráulico',
                  type: 'MECANISMO' as UniqueElementType,
                  importance: 'Elemento ambiental',
                  behavior: 'Opera mediante contrapesos y rueda de agua permitiendo ascender plataformas pesadas.',
                  description: 'Engranajes gigantescos de bronce lubricados con grasa de ballena o linaza.'
                },
                {
                  name: 'Fisura de Bioluminiscencia Etérea',
                  type: 'ANOMALÍA' as UniqueElementType,
                  importance: 'Clave de trama / Mágico',
                  behavior: 'Altera levemente la gravedad local e ilumina la estancia con tonos cian.',
                  description: 'Grieta en la roca viva por donde exhala vapor templado con aroma a ozono.'
                },
                {
                  name: 'Guardián Alado de la Cúpula',
                  type: 'ANIMAL' as UniqueElementType,
                  importance: 'Elemento ambiental',
                  behavior: 'Vigila a los recién llegados desde las vigas superiores y grazna ante hostilidades.',
                  description: 'Ave rapaz de plumaje plateado adiestrada para reconocer a los habitantes legítimos.'
                },
                {
                  name: 'Estela de Leyes Inmutables',
                  type: 'OBJETO' as UniqueElementType,
                  importance: 'Elemento ambiental',
                  behavior: 'Impone un voto tácito de no agresión en el recinto bajo pena de repudio comunal.',
                  description: 'Monolito de basalto negro pulido con decretos arcaicos grabados en oro.'
                }
              ].map((arch, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleAddUniqueElementArchetype(arch)}
                  className="text-[10px] px-2.5 py-1 rounded-lg bg-[#1D202D] hover:bg-purple-600/25 border border-[#2E3345] hover:border-purple-500/50 text-[#D0D4E4] hover:text-purple-200 transition-all cursor-pointer font-medium"
                  title={`Añadir ${arch.name}`}
                >
                  + {arch.name} ({arch.type})
                </button>
              ))}
            </div>
          </div>

          {(!currentPlace.uniqueElements || currentPlace.uniqueElements.length === 0) ? (
            <div className="p-10 text-center bg-[#181A24] rounded-2xl border border-dashed border-[#2B2F3D] space-y-2">
              <Sparkles className="w-8 h-8 text-[#5A6072] mx-auto" />
              <p className="text-xs text-[#8A8F9E]">
                No hay elementos únicos o anomalías configuradas. Pulsa "+ Añadir Elemento" o "Sugerir Elemento".
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {currentPlace.uniqueElements.map((el, idx) => (
                <div
                  key={el.id || idx}
                  className="bg-[#181A24] border border-[#262936] rounded-2xl p-4.5 space-y-3 relative group"
                >
                  <div className="flex items-center justify-between gap-2 border-b border-[#232632] pb-2.5">
                    <input
                      type="text"
                      value={el.name}
                      onChange={e => handleUpdateUniqueElement(idx, 'name', e.target.value)}
                      placeholder="Nombre del Elemento Único..."
                      className="bg-transparent text-xs font-bold text-[#F3F4F6] focus:border-b focus:border-purple-500 outline-hidden w-52"
                    />

                    <div className="flex items-center gap-2">
                      <select
                        value={el.type}
                        onChange={e => handleUpdateUniqueElement(idx, 'type', e.target.value as UniqueElementType)}
                        className="bg-[#12141C] border border-[#2B2F3D] rounded-lg px-2 py-0.5 text-[10px] font-bold text-purple-300 outline-hidden cursor-pointer"
                      >
                        <option value="OBJETO">OBJETO</option>
                        <option value="MECANISMO">MECANISMO</option>
                        <option value="ANOMALÍA">ANOMALÍA</option>
                        <option value="ANIMAL">ANIMAL</option>
                        <option value="PERSONAJE">PERSONAJE</option>
                        <option value="LUGAR">LUGAR</option>
                        <option value="EVENTO PERMANENTE">EVENTO PERMANENTE</option>
                      </select>

                      <button
                        type="button"
                        onClick={() => handleRemoveUniqueElement(idx)}
                        className="p-1 rounded-lg hover:bg-rose-950/50 text-[#8A8F9E] hover:text-rose-400 cursor-pointer"
                        title="Eliminar elemento"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <div className="space-y-2 text-xs">
                    <div>
                      <label className="text-[10px] text-[#8A8F9E] block">Naturaleza / Descripción</label>
                      <textarea
                        rows={2}
                        value={el.description}
                        onChange={e => handleUpdateUniqueElement(idx, 'description', e.target.value)}
                        placeholder="Aspecto físico y origen..."
                        className="w-full bg-[#12141C] border border-[#262936] rounded-lg p-2 text-xs text-[#D0D4E4] outline-hidden focus:border-purple-500 leading-relaxed"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] text-[#8A8F9E] block">Comportamiento / Efecto en el Escenario</label>
                      <input
                        type="text"
                        value={el.behavior}
                        onChange={e => handleUpdateUniqueElement(idx, 'behavior', e.target.value)}
                        placeholder="Ej. Emite calor suave, resuena al contacto..."
                        className="w-full bg-[#12141C] border border-[#262936] rounded-lg px-2.5 py-1.5 text-xs text-[#D0D4E4] outline-hidden focus:border-purple-500"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] text-[#8A8F9E] block">Grado de Importancia</label>
                      <input
                        type="text"
                        value={el.importance}
                        onChange={e => handleUpdateUniqueElement(idx, 'importance', e.target.value)}
                        placeholder="Ej. Elemento ambiental, Peligro / Alerta, Clave de trama..."
                        className="w-full bg-[#12141C] border border-[#262936] rounded-lg px-2.5 py-1.5 text-xs text-[#D0D4E4] outline-hidden focus:border-purple-500"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ========================================================
          PESTAÑA 6: FICHA CONSOLIDADA & EXPORTACIÓN
         ======================================================== */}
      {activeTab === 'consolidada' && (
        <div className="bg-[#13151D] border border-[#232632] rounded-3xl p-6 shadow-xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#232632] pb-5">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase font-bold tracking-wider px-2.5 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300">
                  Vista Maestra Consolidada
                </span>
                <span className="text-[10px] font-mono text-[#8A8F9E]">
                  Formato Universal de Lectura & Simulación
                </span>
              </div>
              <h3 className="text-xl font-bold text-[#F3F4F6] mt-1">
                {currentPlace.name} ({currentPlace.version || 'v1.0'})
              </h3>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleCopyMarkdown}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md transition-all cursor-pointer"
              >
                <ClipboardCopy className="w-4 h-4" />
                <span>Copiar Ficha en Markdown</span>
              </button>

              <button
                type="button"
                onClick={handleExportJson}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#181A24] hover:bg-[#222533] border border-[#2B2F3D] text-[#E0E2EC] font-bold text-xs transition-all cursor-pointer"
              >
                <Download className="w-4 h-4 text-indigo-400" />
                <span>Descargar JSON</span>
              </button>
            </div>
          </div>

          {/* Renderizado Estructurado de la Ficha Maestra */}
          <div className="bg-[#101218] border border-[#202330] rounded-2xl p-6 space-y-6 text-xs text-[#D0D4E4] leading-relaxed font-sans">
            {/* 1. Header Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-xl bg-[#161822] border border-[#262936]">
              <div>
                <span className="text-[10px] uppercase font-bold text-[#8A8F9E] block">Región / Territorio</span>
                <span className="font-semibold text-[#F3F4F6]">{currentPlace.region || 'No especificada'}</span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-[#8A8F9E] block">Biotopo / Entorno</span>
                <span className="font-semibold text-indigo-300">{currentPlace.environmentType}</span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-[#8A8F9E] block">Nivel de Peligro</span>
                <span className="font-semibold text-amber-300">{currentPlace.dangerLevel}</span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-[#8A8F9E] block">Estilo Constructivo</span>
                <span className="font-semibold text-[#F3F4F6]">{currentPlace.constructionStyle} ({currentPlace.condition})</span>
              </div>
            </div>

            {/* Contexto Geográfico & Vibes */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-3.5 rounded-xl bg-[#141620] border border-[#232634]">
              <div>
                <span className="text-[10px] uppercase font-bold text-[#8A8F9E] block">Contexto Geográfico</span>
                <span className="text-[#E0E2EC] font-medium">{currentPlace.geographicContext || 'Sin definir'}</span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-[#8A8F9E] block">Ritmo & Vibes</span>
                <div className="flex flex-wrap gap-1.5 mt-1">
                  {currentPlace.rhythmOrVibes && currentPlace.rhythmOrVibes.length > 0 ? (
                    currentPlace.rhythmOrVibes.map((v, idx) => (
                      <span key={idx} className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/15 border border-indigo-500/30 text-indigo-300 font-medium">
                        {v}
                      </span>
                    ))
                  ) : (
                    <span className="text-[#6C7284] italic">Sin definir</span>
                  )}
                </div>
              </div>
            </div>

            {/* Atmósfera Sensorial y Descripción General */}
            <div className="space-y-2">
              <span className="text-[11px] uppercase font-bold tracking-wider text-indigo-400 block">
                Atmósfera Sensorial & Entorno
              </span>
              <blockquote className="border-l-2 border-indigo-500/60 pl-3.5 italic text-[#E5E7EB] bg-[#141620] py-2 rounded-r-xl">
                «{currentPlace.atmosphere || 'Sin atmósfera especificada.'}»
              </blockquote>
              <p className="text-[#A0A5B5] pt-1">
                {currentPlace.description || 'Sin descripción general.'}
              </p>
            </div>

            {/* Materiales & Arquitectura */}
            <div className="space-y-2 pt-2 border-t border-[#1C1F2A]">
              <span className="text-[11px] uppercase font-bold tracking-wider text-indigo-400 block">
                Arquitectura & Materialidad
              </span>
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="text-[11px] text-[#8A8F9E] mr-1">Materiales predominantes:</span>
                {currentPlace.materials && currentPlace.materials.length > 0 ? (
                  currentPlace.materials.map((m, idx) => (
                    <span key={idx} className="text-[10px] px-2 py-0.5 rounded-md bg-[#181A24] border border-[#2B2F3D] text-[#D0D4E4]">
                      {m}
                    </span>
                  ))
                ) : (
                  <span className="text-[#6C7284] italic">No especificados</span>
                )}
              </div>
            </div>

            {/* Cultura, Autoridad & Seguridad */}
            <div className="space-y-2 pt-2 border-t border-[#1C1F2A]">
              <span className="text-[11px] uppercase font-bold tracking-wider text-indigo-400 block">
                Cultura, Autoridad & Seguridad
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3 rounded-xl bg-[#141620] border border-[#232634]">
                <div>
                  <span className="text-[10px] uppercase font-bold text-[#8A8F9E] block">Autoridad a Cargo</span>
                  <span className="text-[#F3F4F6] font-medium">{currentPlace.cultureAndSecurity?.authority || 'Sin definir'}</span>
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-[#8A8F9E] block">Nivel de Vigilancia</span>
                  <span className="text-amber-300 font-medium">{currentPlace.cultureAndSecurity?.surveillance || 'Media'}</span>
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-[#8A8F9E] block">Conductas Sociales</span>
                  <span className="text-[#D0D4E4]">
                    {currentPlace.cultureAndSecurity?.socialConduct?.join(', ') || 'Estándar'}
                  </span>
                </div>
              </div>
            </div>

            {/* Puntos de Interés Críticos */}
            <div className="space-y-2 pt-2 border-t border-[#1C1F2A]">
              <span className="text-[11px] uppercase font-bold tracking-wider text-indigo-400 block">
                Puntos de Interés Críticos ({poiCount})
              </span>
              {(!currentPlace.criticalPointsOfInterest || currentPlace.criticalPointsOfInterest.length === 0) ? (
                <p className="text-[11px] text-[#6C7284] italic">Sin puntos de interés registrados.</p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {currentPlace.criticalPointsOfInterest.map((poi, i) => (
                    <div key={poi.id || i} className="bg-[#161822] p-3.5 rounded-xl border border-[#232634] space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-[#F3F4F6]">{i + 1}. {poi.name}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded-md bg-[#212433] text-amber-300 font-semibold">
                          {poi.importance}
                        </span>
                      </div>
                      <div className="text-[11px] text-[#8A8F9E] flex flex-wrap gap-x-3 gap-y-0.5">
                        <span><strong className="text-indigo-300">{poi.type}</strong></span>
                        {poi.owner && <span>Custodio: <strong className="text-[#C0C5D6]">{poi.owner}</strong></span>}
                        {poi.location && <span>Ubicación: <strong className="text-[#C0C5D6]">{poi.location}</strong></span>}
                      </div>
                      <p className="text-[11px] text-[#B0B5C6]"><strong className="text-[#D0D4E4]">Función:</strong> {poi.function}</p>
                      {poi.description && <p className="text-[11px] text-[#8A8F9E] italic">{poi.description}</p>}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Zonas de Convergencia Social */}
            <div className="space-y-2 pt-2 border-t border-[#1C1F2A]">
              <span className="text-[11px] uppercase font-bold tracking-wider text-emerald-400 block">
                Zonas de Convergencia Social ({zoneCount})
              </span>
              {zoneCount === 0 ? (
                <p className="text-[11px] text-[#6C7284] italic">Sin zonas de convergencia social registradas.</p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {currentPlace.convergenceZones?.map((z, i) => (
                    <div key={z.id || i} className="bg-[#161822] p-3.5 rounded-xl border border-[#232634] space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-[#F3F4F6]">{i + 1}. {z.name}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded-md bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-semibold">
                          {z.type}
                        </span>
                      </div>
                      <div className="text-[11px] text-[#8A8F9E] flex flex-wrap gap-x-3 gap-y-0.5">
                        <span>Horario: <strong className="text-[#C0C5D6]">{z.schedule}</strong></span>
                        <span>Densidad: <strong className="text-[#C0C5D6]">{z.npcDensity}</strong></span>
                        <span>Seguridad: <strong className="text-[#C0C5D6]">{z.securityLevel}</strong></span>
                      </div>
                      <p className="text-[11px] text-[#D0D4E4]"><strong className="text-[#8A8F9E]">Eventos Frecuentes:</strong> {z.frequentEvents}</p>
                      {z.associatedCharacters && z.associatedCharacters.length > 0 && (
                        <p className="text-[10px] text-[#8A8F9E]">Habitantes habituales: {z.associatedCharacters.join(', ')}</p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Vivienda si existe */}
            <div className="space-y-2 pt-2 border-t border-[#1C1F2A]">
              <span className="text-[11px] uppercase font-bold tracking-wider text-amber-400 block">
                Vivienda Modelada ({currentPlace.hasHousing && currentPlace.housing ? currentPlace.housing.buildingType : 'No modelada'})
              </span>
              {currentPlace.hasHousing && currentPlace.housing ? (
                <div className="space-y-3">
                  {currentPlace.housing.exteriorsAndConnectivity && currentPlace.housing.exteriorsAndConnectivity.length > 0 && (
                    <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
                      <span className="text-[#8A8F9E]">Exteriores y Conectividad:</span>
                      {currentPlace.housing.exteriorsAndConnectivity.map((conn, idx) => (
                        <span key={idx} className="text-[10px] px-2 py-0.5 rounded bg-[#181A24] border border-[#2B2F3D] text-amber-300/90 font-medium">
                          {conn}
                        </span>
                      ))}
                    </div>
                  )}

                  {currentPlace.housing.levels.map(lvl => (
                    <div key={lvl.levelNumber} className="bg-[#161822] p-3.5 rounded-xl border border-[#232634] space-y-2.5">
                      <div className="flex items-center justify-between border-b border-[#232634] pb-1.5">
                        <span className="font-bold text-indigo-300">{lvl.levelName}</span>
                        <span className="text-[10px] text-[#8A8F9E]">{lvl.rooms.length} estancias</span>
                      </div>
                      {lvl.rooms.length === 0 ? (
                        <p className="text-[11px] text-[#6C7284] italic">Sin habitaciones en este nivel.</p>
                      ) : (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                          {lvl.rooms.map(r => (
                            <div key={r.id} className="bg-[#12141C] p-3 rounded-lg border border-[#1E212D] space-y-1">
                              <div className="flex items-center justify-between">
                                <span className="font-semibold text-[#F3F4F6]">{r.name}</span>
                                <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#1A1D2A] text-indigo-300 font-medium">{r.function}</span>
                              </div>
                              {r.location && <p className="text-[10px] text-[#8A8F9E]">Ubicación: <span className="text-[#C0C5D6]">{r.location}</span></p>}
                              <p className="text-[10px] text-[#8A8F9E]">
                                Mobiliario: <span className="text-[#C0C5D6]">{r.furniture?.join(', ') || 'Básico'}</span>
                              </p>
                              {r.objects && r.objects.length > 0 && (
                                <p className="text-[10px] text-[#8A8F9E]">
                                  Objetos Clave: <span className="text-amber-300/80">{r.objects.join(', ')}</span>
                                </p>
                              )}
                              {r.accesses && r.accesses.length > 0 && (
                                <p className="text-[10px] text-[#8A8F9E]">
                                  Accesos: <span className="text-[#A0A5B5]">{r.accesses.join(', ')}</span>
                                </p>
                              )}
                              {r.description && (
                                <p className="text-[10px] text-[#8A8F9E] italic border-t border-[#1C1F2B] pt-1 mt-1">{r.description}</p>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-[11px] text-[#6C7284] italic">Este escenario no incluye un habitáculo o vivienda modelada.</p>
              )}
            </div>

            {/* Elementos Únicos & Anomalías */}
            <div className="space-y-2 pt-2 border-t border-[#1C1F2A]">
              <span className="text-[11px] uppercase font-bold tracking-wider text-purple-400 block">
                Elementos Únicos & Anomalías ({uniqueCount})
              </span>
              {(!currentPlace.uniqueElements || currentPlace.uniqueElements.length === 0) ? (
                <p className="text-[11px] text-[#6C7284] italic">Sin elementos únicos ni anomalías configuradas.</p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {currentPlace.uniqueElements.map((el, i) => (
                    <div key={el.id || i} className="bg-[#161822] p-3.5 rounded-xl border border-[#232634] space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-[#F3F4F6]">{i + 1}. {el.name}</span>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-purple-500/15 border border-purple-500/30 text-purple-300 font-semibold">
                            {el.type}
                          </span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#212433] text-amber-300 font-medium">
                            {el.importance}
                          </span>
                        </div>
                      </div>
                      <p className="text-[11px] text-[#D0D4E4]">{el.description}</p>
                      <p className="text-[10px] text-[#8A8F9E]">
                        <strong className="text-purple-300">Efecto / Reacción:</strong> {el.behavior}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer de Acciones de la Ficha Consolidada */}
            <div className="pt-4 border-t border-[#1C1F2A] flex flex-wrap items-center justify-between gap-3">
              <span className="text-[10px] text-[#8A8F9E]">
                ID: <code className="text-[#A0A5B5]">{currentPlace.id}</code> | Versión: {currentPlace.version || 'v1.0'} | {currentPlace.linkedWorldId ? `Vinculado a Mundo: ${currentPlace.linkedWorldId}` : 'Sin vincular'}
              </span>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleSaveOverwrite}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition-all cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>Guardar Ficha Maestra</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
