import React, { useState, useEffect, useRef } from 'react';
import { CharacterState, GarmentConfig, EmblemBuilderConfig } from '../types';
import { 
  WARDROBE_CATEGORIES, 
  ACCESSORY_SUBCATEGORIES, 
  ACCESSORY_GEM_TYPES, 
  ACCESSORY_ENGRAVINGS, 
  ACCESSORY_SIZE_SCALES, 
  ACCESSORY_FIT_STYLES, 
  getWardrobeOptions, 
  BASIC_COLOR_SWATCHES, 
  GARMENT_PRINT_TYPES, 
  GARMENT_PRINT_LOCATIONS, 
  getGarmentPrintConfig, 
  WARDROBE_DESCRIPTIONS_MAP,
  WEAR_CONDITIONS,
  WEAR_STYLES,
  CULTURAL_ACCESSORY_TRADITIONS,
  SHOE_SOLES,
  SHOE_HEELS
} from '../data';
import { 
  Wand2, 
  ArrowRight, 
  ArrowLeft, 
  Plus, 
  Trash2, 
  Sparkles, 
  Shirt, 
  Tag, 
  Eye, 
  Gem, 
  Sliders, 
  Layers, 
  Filter, 
  Palette,
  Edit3,
  Check,
  CheckCheck,
  X,
  Copy,
  RotateCcw,
  CheckCircle2,
  Flame,
  Heart,
  Lock,
  Unlock,
  Info
} from 'lucide-react';
import { InfoTooltip } from './ui/InfoTooltip';
import { FabricColorCustomizer } from './color/FabricColorCustomizer';
import { CalligraphyTextInput } from './common/CalligraphyTextInput';
import { LogoSealEmblemBuilder } from './common/LogoSealEmblemBuilder';
import { isCalligraphyOrTextOption, isLogoShieldOrSealOption } from '../utils/emblemTextDetectors';
import { formatGarmentDescription, resolveColorName } from '../utils/characterPromptUtils';
import { EXPLICIT_LINGERIE_OPTIONS } from '../data/nsfwData';
import { GarmentCoverageAndFitSuite } from './wardrobe/GarmentCoverageAndFitSuite';
import { GarmentLogicService } from '../services/garmentLogicEngine';

interface State3Props {
  state: CharacterState;
  setState: React.Dispatch<React.SetStateAction<CharacterState>>;
  onNext: () => void;
  onBack: () => void;
}

export const State3Wardrobe: React.FC<State3Props> = ({ state, setState, onNext, onBack }) => {
  const [selectedCat, setSelectedCat] = useState(WARDROBE_CATEGORIES[0].id);
  const [selectedAccSubcat, setSelectedAccSubcat] = useState('Todos');
  const [editingGarmentId, setEditingGarmentId] = useState<string | null>(null);
  const [inspectedDetail, setInspectedDetail] = useState<string | null>(null);
  const [showEngineDetails, setShowEngineDetails] = useState<boolean>(true);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [canonicalCopiedMode, setCanonicalCopiedMode] = useState<'sheet' | 'prompt' | null>(null);
  const [canonicalViewTab, setCanonicalViewTab] = useState<'sheet' | 'prompt' | 'both'>('both');
  const skipCategoryResetRef = useRef(false);
  const toastTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const toggleNsfw = (enable?: boolean) => {
    const nextVal = enable !== undefined ? enable : !state.nsfw?.isNsfwEnabled;
    setState(prev => ({
      ...prev,
      nsfw: {
        areolaColor: prev.nsfw?.areolaColor || 'Rosado Pálido Sakura',
        areolaSize: prev.nsfw?.areolaSize || 'Media',
        nippleType: prev.nsfw?.nippleType || 'Túrgido Firme',
        pubicHairStyle: prev.nsfw?.pubicHairStyle || 'Depilación Total',
        bodySensitivities: prev.nsfw?.bodySensitivities || ['BS1'],
        intimatePersonality: prev.nsfw?.intimatePersonality !== undefined ? prev.nsfw.intimatePersonality : '',
        explicitLingerie: prev.nsfw?.explicitLingerie || [],
        ...prev.nsfw,
        isNsfwEnabled: nextVal
      }
    }));
  };

  const handleToggleExplicitLingerie = (option: { id: string; name: string; description: string }) => {
    const currentExplicit = state.nsfw?.explicitLingerie || [];
    const isEquipped = currentExplicit.includes(option.name);

    if (isEquipped) {
      setState(prev => ({
        ...prev,
        nsfw: {
          ...prev.nsfw,
          isNsfwEnabled: true,
          explicitLingerie: (prev.nsfw?.explicitLingerie || []).filter(n => n !== option.name)
        },
        wardrobes: prev.wardrobes.filter(w => w.name !== option.name)
      }));
      triggerToast(`Prenda íntima "${option.name}" retirada.`);
    } else {
      const newGarment: GarmentConfig = {
        id: `r18-${option.id}-${Date.now()}`,
        categoryId: 'B6',
        itemId: option.id,
        name: option.name,
        cut: 'Íntimo Erótico R+18',
        length: 'Mínimo',
        sleeve: 'Sin Mangas',
        material: 'Encaje / Seda / Cuero Fino',
        color: '#E0115F',
        finish: 'Translúcido & Provocativo',
        details: ['Apertura Erótica', 'Transparencias'],
        variation: 'R+18',
        layer: 'Capa Íntima',
        location: ['Torso', 'Pelvis'],
        detailLocations: {},
        pattern: 'Liso',
        patternDetail: 'Ninguno',
        neckline: 'Escote Pronunciado',
        emblem: 'Ninguno',
        vfx: 'Seducción'
      };

      setState(prev => ({
        ...prev,
        nsfw: {
          ...prev.nsfw,
          isNsfwEnabled: true,
          explicitLingerie: [...(prev.nsfw?.explicitLingerie || []), option.name]
        },
        wardrobes: [...prev.wardrobes.filter(w => w.name !== option.name), newGarment]
      }));
      triggerToast(`Prenda íntima "${option.name}" equipada con éxito.`);
    }
  };

  const triggerToast = (msg: string) => {
    if (toastTimeoutRef.current) clearTimeout(toastTimeoutRef.current);
    setToastMessage(msg);
    toastTimeoutRef.current = setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  const [currentGarment, setCurrentGarment] = useState<{
    itemId: string;
    name: string;
    cut: string;
    length: string;
    sleeve: string;
    material: string;
    color: string;
    finish: string;
    details: string[];
    detailColors?: Record<string, string>;
    variation: string;
    layer: string;
    location: string[];
    detailLocations?: Record<string, string[]>;
    pattern: string;
    patternDetail: string;
    neckline: string;
    emblem: string;
    vfx: string;
    accessorySubcategory?: string;
    gemType?: string;
    gemColor?: string;
    engraving?: string;
    engravingText?: string;
    emblemConfig?: EmblemBuilderConfig;
    sizeScale?: string;
    fitStyle?: string;
    soleType?: string;
    heelType?: string;
    wearCondition?: string;
    wearStyle?: string;
    culturalTradition?: string;
    printTypes?: string[];
    printShapes?: Record<string, string>;
    printColors?: Record<string, string>;
    printLocations?: Record<string, string[]>;
    printTexts?: Record<string, string>;
    printEmblemConfigs?: Record<string, EmblemBuilderConfig>;
  }>({
    itemId: '',
    name: '',
    cut: '',
    length: '',
    sleeve: '',
    material: '',
    color: '#1A1C22',
    finish: '',
    details: [],
    detailColors: {},
    variation: '',
    layer: '',
    location: [],
    detailLocations: {},
    pattern: '',
    patternDetail: '',
    neckline: '',
    emblem: 'Ninguno',
    vfx: 'Ninguno',
    accessorySubcategory: '',
    gemType: '',
    gemColor: '',
    engraving: '',
    engravingText: '',
    emblemConfig: undefined,
    sizeScale: '',
    fitStyle: '',
    soleType: undefined,
    heelType: undefined,
    wearCondition: WEAR_CONDITIONS[0],
    wearStyle: WEAR_STYLES[0],
    culturalTradition: CULTURAL_ACCESSORY_TRADITIONS[0],
    printTypes: [],
    printShapes: {},
    printColors: {},
    printLocations: {},
    printTexts: {},
    printEmblemConfigs: {}
  });

  const activeCategory = WARDROBE_CATEGORIES.find(c => c.id === selectedCat) || WARDROBE_CATEGORIES[0];
  const isAccCat = selectedCat === 'B5';
  const isShoesCat = selectedCat === 'B4';

  const activeOptions = getWardrobeOptions(selectedCat, currentGarment.itemId, currentGarment.name, currentGarment.details);

  const garmentProfile = React.useMemo(() => {
    return GarmentLogicService.getProfile(currentGarment.name, selectedCat, currentGarment.accessorySubcategory);
  }, [currentGarment.name, selectedCat, currentGarment.accessorySubcategory]);

  const compatiblePrintTypes = React.useMemo(() => {
    return GarmentLogicService.filterCompatiblePrints(currentGarment.name, selectedCat, GARMENT_PRINT_TYPES);
  }, [currentGarment.name, selectedCat]);

  const garmentPrintLocations = React.useMemo(() => {
    return GarmentLogicService.getPrintLocationsForGarment(currentGarment.name, selectedCat);
  }, [currentGarment.name, selectedCat]);

  const compatibleDetails = React.useMemo(() => {
    return GarmentLogicService.filterCompatibleDetails(currentGarment.name, selectedCat, activeOptions.details);
  }, [currentGarment.name, selectedCat, activeOptions.details]);

  // Filtered items when in accessories category
  const filteredCategoryItems = activeCategory.items.filter(item => {
    if (!isAccCat || selectedAccSubcat === 'Todos') return true;
    return item.subcategory === selectedAccSubcat;
  });

  const resetCurrentGarmentToCategoryDefault = (catId: string) => {
    const activeCat = WARDROBE_CATEGORIES.find(c => c.id === catId) || WARDROBE_CATEGORIES[0];
    const firstItem = activeCat.items[0];
    const opts = getWardrobeOptions(catId, firstItem.id, firstItem.name);
    const isAccessory = catId === 'B5';
    const isFootwear = catId === 'B4';
    
    setCurrentGarment({
      itemId: firstItem.id,
      name: firstItem.name,
      cut: opts.cut[0] || '',
      length: opts.length[0] || '',
      sleeve: opts.sleeve[0] || '',
      material: opts.material[0] || '',
      color: isAccessory ? '#D4AF37' : '#1A1C22',
      finish: opts.finish[0] || '',
      details: opts.details && opts.details.length > 0 ? [opts.details[0]] : [],
      detailColors: {},
      variation: opts.variation[0] || '',
      layer: opts.layer[0] || (isAccessory ? 'Accesorio Mediano' : 'Base'),
      location: opts.location && opts.location.length > 0 ? [opts.location[0]] : [],
      detailLocations: {},
      pattern: opts.pattern ? opts.pattern[0] || '' : '',
      patternDetail: '',
      neckline: opts.neckline ? opts.neckline[0] || '' : '',
      emblem: opts.emblem ? opts.emblem[0] || 'Ninguno' : 'Ninguno',
      vfx: opts.vfx ? opts.vfx[0] || 'Ninguno' : 'Ninguno',
      accessorySubcategory: isAccessory ? (firstItem.subcategory || '') : '',
      gemType: isAccessory ? 'Sin Gema / Metálico Puro' : '',
      gemColor: '',
      engraving: isAccessory ? 'Sin Grabado / Liso Pulido' : '',
      sizeScale: isAccessory ? 'Estándar Equilibrado' : '',
      fitStyle: isAccessory ? 'Ceñido / Pegado a la piel' : '',
      soleType: isFootwear ? (opts.shoeSoles?.[0] || SHOE_SOLES[0]) : undefined,
      heelType: isFootwear ? (opts.shoeHeels?.[0] || SHOE_HEELS[0]) : undefined,
      wearCondition: WEAR_CONDITIONS[0],
      wearStyle: isFootwear ? undefined : WEAR_STYLES[0],
      culturalTradition: CULTURAL_ACCESSORY_TRADITIONS[0],
      coverageZones: opts.location && opts.location.length > 0 ? [...opts.location] : [],
      coverageStyle: 'Ajuste Ergonómico Táctico con Puntos Articulados',
      coverageDetails: '',
      printTypes: [],
      printShapes: {},
      printColors: {},
      printLocations: {},
      printTexts: {},
      printEmblemConfigs: {}
    });
  };

  useEffect(() => {
    if (skipCategoryResetRef.current) {
      skipCategoryResetRef.current = false;
      return;
    }
    resetCurrentGarmentToCategoryDefault(selectedCat);
  }, [selectedCat]);

  const handleStartEditGarment = (garment: GarmentConfig) => {
    const targetCatId = garment.categoryId || 'B0';
    skipCategoryResetRef.current = true;
    setSelectedCat(targetCatId);
    if (targetCatId === 'B5' && garment.accessorySubcategory) {
      setSelectedAccSubcat(garment.accessorySubcategory);
    }
    setEditingGarmentId(garment.id);

    const isEditingFootwear = targetCatId === 'B4';

    setCurrentGarment({
      itemId: garment.itemId || '',
      name: garment.name || '',
      cut: garment.cut || '',
      length: garment.length || '',
      sleeve: garment.sleeve || '',
      material: garment.material || '',
      color: garment.color || (targetCatId === 'B5' ? '#D4AF37' : '#1A1C22'),
      finish: garment.finish || '',
      details: Array.isArray(garment.details) ? [...garment.details] : [],
      detailColors: garment.detailColors ? { ...garment.detailColors } : {},
      variation: garment.variation || '',
      layer: garment.layer || '',
      location: Array.isArray(garment.location) ? [...garment.location] : [],
      detailLocations: garment.detailLocations ? { ...garment.detailLocations } : {},
      pattern: garment.pattern || '',
      patternDetail: garment.patternDetail || '',
      neckline: garment.neckline || '',
      emblem: garment.emblem || 'Ninguno',
      vfx: garment.vfx || 'Ninguno',
      accessorySubcategory: garment.accessorySubcategory || '',
      gemType: garment.gemType || '',
      gemColor: garment.gemColor || '',
      engraving: garment.engraving || '',
      engravingText: garment.engravingText || '',
      emblemConfig: garment.emblemConfig,
      sizeScale: garment.sizeScale || '',
      fitStyle: garment.fitStyle || '',
      soleType: isEditingFootwear ? (garment.soleType || SHOE_SOLES[0]) : undefined,
      heelType: isEditingFootwear ? (garment.heelType || SHOE_HEELS[0]) : undefined,
      wearCondition: garment.wearCondition || WEAR_CONDITIONS[0],
      wearStyle: isEditingFootwear ? undefined : (garment.wearStyle || WEAR_STYLES[0]),
      culturalTradition: garment.culturalTradition || CULTURAL_ACCESSORY_TRADITIONS[0],
      coverageZones: Array.isArray(garment.coverageZones) && garment.coverageZones.length > 0
        ? [...garment.coverageZones]
        : (Array.isArray(garment.location) ? [...garment.location] : []),
      coverageStyle: garment.coverageStyle || 'Ajuste Ergonómico Táctico con Puntos Articulados',
      coverageDetails: garment.coverageDetails || '',
      printTypes: Array.isArray(garment.printTypes) ? [...garment.printTypes] : [],
      printShapes: garment.printShapes ? { ...garment.printShapes } : {},
      printColors: garment.printColors ? { ...garment.printColors } : {},
      printLocations: garment.printLocations ? { ...garment.printLocations } : {},
      printTexts: garment.printTexts ? { ...garment.printTexts } : {},
      printEmblemConfigs: garment.printEmblemConfigs ? { ...garment.printEmblemConfigs } : {}
    });

    triggerToast(`Pieza "${garment.name}" cargada en el editor. Realiza tus cambios y presiona "Guardar Cambios".`);

    const el = document.getElementById('wardrobe-builder-container');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleSaveGarmentEdit = () => {
    if (!editingGarmentId || !currentGarment.name) return;
    const isAccessory = selectedCat === 'B5';
    const isFootwear = selectedCat === 'B4';

    setState(prev => ({
      ...prev,
      wardrobes: prev.wardrobes.map(g => {
        if (g.id !== editingGarmentId) return g;
        return {
          ...g,
          categoryId: selectedCat,
          ...currentGarment,
          ...(isAccessory ? {} : {
            accessorySubcategory: undefined,
            gemType: undefined,
            gemColor: undefined,
            engraving: undefined,
            sizeScale: undefined,
            fitStyle: undefined
          }),
          ...(isFootwear ? {
            soleType: currentGarment.soleType || SHOE_SOLES[0],
            heelType: currentGarment.heelType || SHOE_HEELS[0],
            wearStyle: undefined
          } : {
            soleType: undefined,
            heelType: undefined,
            wearStyle: currentGarment.wearStyle || WEAR_STYLES[0]
          })
        };
      })
    }));

    triggerToast(`Cambios guardados con éxito en "${currentGarment.name}".`);
    setEditingGarmentId(null);
  };

  const handleCancelEdit = () => {
    setEditingGarmentId(null);
    resetCurrentGarmentToCategoryDefault(selectedCat);
    triggerToast('Edición de pieza cancelada.');
  };

  const handleAddGarment = () => {
    if (!currentGarment.name) return;
    const isAccessory = selectedCat === 'B5';
    const isFootwear = selectedCat === 'B4';
    const newGarment: GarmentConfig = {
      id: Math.random().toString(36).substring(2, 9),
      categoryId: selectedCat,
      ...currentGarment,
      ...(isAccessory ? {} : {
        accessorySubcategory: undefined,
        gemType: undefined,
        gemColor: undefined,
        engraving: undefined,
        sizeScale: undefined,
        fitStyle: undefined
      }),
      ...(isFootwear ? {
        soleType: currentGarment.soleType || SHOE_SOLES[0],
        heelType: currentGarment.heelType || SHOE_HEELS[0],
        wearStyle: undefined
      } : {
        soleType: undefined,
        heelType: undefined,
        wearStyle: currentGarment.wearStyle || WEAR_STYLES[0]
      })
    };
    setState(prev => ({
      ...prev,
      wardrobes: [...prev.wardrobes, newGarment]
    }));

    if (editingGarmentId) {
      triggerToast(`Pieza duplicada y añadida como nueva entrada.`);
      setEditingGarmentId(null);
    } else {
      triggerToast(`"${currentGarment.name}" añadida al atuendo.`);
    }
  };

  const handleRemoveGarment = (id: string) => {
    const removedItem = state.wardrobes.find(g => g.id === id);
    setState(prev => ({
      ...prev,
      wardrobes: prev.wardrobes.filter(g => g.id !== id)
    }));
    if (editingGarmentId === id) {
      setEditingGarmentId(null);
      resetCurrentGarmentToCategoryDefault(selectedCat);
    }
    triggerToast(`Pieza "${removedItem?.name || ''}" eliminada.`);
  };

  return (
    <div id="wardrobe-builder-container" className="max-w-6xl mx-auto px-4 py-8 relative">
      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#15171C] border-2 border-[#C9A050] text-[#E0E0E0] px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-3 animate-bounce-short">
          <CheckCircle2 className="w-5 h-5 text-[#C9A050] shrink-0" />
          <span className="text-xs font-medium">{toastMessage}</span>
        </div>
      )}

      {/* Hero Header */}
      <div className="bg-[#0F1115] border border-[#222222] rounded-3xl p-8 text-[#E0E0E0] shadow-xl mb-8 relative">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-[#1A1C22] border border-[#2A2D35] text-[#C9A050] text-xs font-medium mb-4">
          <Wand2 className="w-3.5 h-3.5 text-[#C9A050]" />
          <span>ESTADO 3: CONSTRUCTOR DE VESTUARIO & ACCESORIOS</span>
        </div>
        <h2 className="text-3xl font-serif italic text-[#C9A050] tracking-tight mb-2">
          Diseño de Atuendo, Capas & Accesorios
        </h2>
        <p className="text-[#888888] text-sm leading-relaxed">
          Selecciona prendas y accesorios de los catálogos B.0 a B.5. En B.5 dispones de 9 subcategorías anatómicas con controles personalizables de gemas, grabados, escala de tamaño, ajuste y metales finos.
        </p>

        {/* Quick R+18 Toggle */}
        <div className="flex items-center justify-between flex-wrap gap-4 mt-6 pt-6 border-t border-[#222222]">
          <p className="text-xs text-[#888888]">
            {state.nsfw?.isNsfwEnabled
              ? '🔥 Modo R+18 Activo: Acceso a lencería explícita, transparencias y desvestido sin restricciones.'
              : 'Modo Estándar: Pulsa para activar el catálogo B.6 de Lencería Erótica y piezas R+18.'}
          </p>
          <button
            type="button"
            onClick={() => toggleNsfw()}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold border transition-all flex items-center gap-2 cursor-pointer ${
              state.nsfw?.isNsfwEnabled
                ? 'bg-rose-950/70 border-rose-600 text-rose-300 hover:bg-rose-900/80 shadow-md shadow-rose-950/40'
                : 'bg-[#15171C] border-[#2A2D35] text-[#888888] hover:text-[#C9A050] hover:border-[#C9A050]/50'
            }`}
          >
            <Flame className={`w-4 h-4 ${state.nsfw?.isNsfwEnabled ? 'text-rose-400 fill-current' : 'text-zinc-500'}`} />
            <span>Modo R+18: {state.nsfw?.isNsfwEnabled ? 'HABILITADO' : 'DESACTIVADO'}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 Cols: Category Selector & Garment Form */}
        <div className="lg:col-span-2 space-y-6">
          {/* Active Editing Mode Banner */}
          {editingGarmentId && (
            <div className="bg-gradient-to-r from-[#241F14] via-[#1A1C22] to-[#12141A] border-2 border-[#C9A050] rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-lg">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-[#C9A050] text-[#0A0B0E] flex items-center justify-center font-bold shadow-md shrink-0">
                  <Edit3 className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono uppercase tracking-wider font-bold text-[#C9A050]">
                      Modo Edición de Pieza
                    </span>
                    <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-amber-950/60 border border-amber-500/40 text-amber-300">
                      ID: {editingGarmentId}
                    </span>
                  </div>
                  <h4 className="text-sm font-serif font-bold text-amber-100 mt-0.5">
                    Modificando: {currentGarment.name || 'Prenda'}
                  </h4>
                </div>
              </div>
              <div className="flex items-center gap-2 self-end sm:self-center">
                <button
                  type="button"
                  onClick={handleCancelEdit}
                  className="px-3 py-1.5 bg-[#15171C] hover:bg-[#1f2229] border border-[#2A2D35] text-[#AAAAAA] hover:text-[#E0E0E0] rounded-xl text-xs font-mono transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <X className="w-3.5 h-3.5" />
                  <span>Cancelar</span>
                </button>
                <button
                  type="button"
                  onClick={handleSaveGarmentEdit}
                  className="px-4 py-1.5 bg-[#C9A050] hover:bg-[#d8ad4f] text-[#0A0B0E] font-bold rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-md cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>Guardar Cambios</span>
                </button>
              </div>
            </div>
          )}

          {/* Category Tabs */}
          <div className="flex flex-wrap gap-2">
            {WARDROBE_CATEGORIES.map(cat => (
              <button
                key={cat.id}
                onClick={() => {
                  setSelectedCat(cat.id);
                  if (cat.id === 'B5') setSelectedAccSubcat('Todos');
                }}
                className={`px-3 py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                  selectedCat === cat.id ? 'bg-[#1A1C22] border-[#C9A050] text-[#C9A050]' : 'bg-[#15171C] border-[#2A2D35] text-[#888888]'
                }`}
              >
                {cat.name.split('/')[0].trim()}
              </button>
            ))}

            {/* B.6 Lingerie Explicit R+18 Tab */}
            <button
              key="B6"
              type="button"
              onClick={() => {
                setSelectedCat('B6');
                if (!state.nsfw?.isNsfwEnabled) toggleNsfw(true);
              }}
              className={`px-3 py-2 rounded-xl text-xs font-semibold border transition-all flex items-center gap-1.5 cursor-pointer ${
                selectedCat === 'B6'
                  ? 'bg-rose-950/80 border-rose-500 text-rose-200 shadow-md shadow-rose-950/40'
                  : state.nsfw?.isNsfwEnabled
                    ? 'bg-[#1c1418] border-rose-900/40 text-rose-300/80 hover:text-rose-200'
                    : 'bg-[#15171C] border-[#2A2D35] text-[#888888] hover:text-rose-400'
              }`}
            >
              <Flame className={`w-3.5 h-3.5 ${state.nsfw?.isNsfwEnabled ? 'text-rose-400 fill-current' : 'text-zinc-500'}`} />
              <span>B.6 Lencería R+18</span>
              {state.nsfw?.isNsfwEnabled && (
                <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse" />
              )}
            </button>
          </div>

          {/* Subcategory Tabs if B.5 Accesorios is active */}
          {isAccCat && (
            <div className="bg-[#12141A] border border-[#2A2D35] rounded-2xl p-4 space-y-2.5">
              <div className="flex items-center space-x-2 text-xs font-mono text-[#C9A050]">
                <Filter className="w-3.5 h-3.5 text-[#C9A050]" />
                <span className="font-bold uppercase tracking-wider">Subcategorías de Accesorios Anatómicos</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {ACCESSORY_SUBCATEGORIES.map(subcat => {
                  const isSubActive = selectedAccSubcat === subcat;
                  return (
                    <button
                      key={subcat}
                      type="button"
                      onClick={() => setSelectedAccSubcat(subcat)}
                      className={`px-2.5 py-1 text-xs rounded-lg transition-all border ${
                        isSubActive
                          ? 'bg-[#C9A050] text-[#0A0B0E] font-bold border-[#C9A050] shadow-sm'
                          : 'bg-[#181A20] text-[#A0A0A0] border-[#2A2D35] hover:border-[#888888] hover:text-[#E0E0E0]'
                      }`}
                    >
                      {subcat}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Garment Item Picker or B.6 Explicit Lingerie Catalog */}
          {selectedCat === 'B6' ? (
            <div className="space-y-6 animate-fadeIn">
              {!state.nsfw?.isNsfwEnabled ? (
                <div className="bg-[#120D14] border border-rose-900/60 rounded-3xl p-8 text-center space-y-4 shadow-2xl">
                  <div className="w-16 h-16 rounded-2xl bg-rose-950/80 border border-rose-600/50 flex items-center justify-center mx-auto text-rose-400">
                    <Flame className="w-8 h-8 fill-current" />
                  </div>
                  <h3 className="text-xl font-serif italic text-rose-200">
                    Modo Adulto R+18 Desactivado
                  </h3>
                  <p className="text-xs text-zinc-400 max-w-lg mx-auto leading-relaxed">
                    Para equipar prendas de lencería explícita, arneses y transparencias eróticas, activa el Modo R+18. Esto también desactivará las restricciones de pudor y resistencia en la sala de interacción.
                  </p>
                  <button
                    type="button"
                    onClick={() => toggleNsfw(true)}
                    className="px-6 py-3 rounded-xl bg-gradient-to-r from-rose-700 to-rose-600 hover:from-rose-600 hover:to-rose-500 text-white font-bold text-xs tracking-wider uppercase transition-all shadow-lg shadow-rose-950/60 cursor-pointer inline-flex items-center gap-2"
                  >
                    <Flame className="w-4 h-4 fill-current" />
                    <span>Habilitar Modo R+18 (+18 Años)</span>
                  </button>
                </div>
              ) : (
                <div className="bg-[#0F1115] border border-rose-950/60 rounded-2xl p-6 space-y-6 shadow-xl">
                  <div className="flex items-center justify-between flex-wrap gap-3 pb-4 border-b border-[#222222]">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <Flame className="w-4 h-4 text-rose-400 fill-current" />
                        <h3 className="text-base font-serif italic text-rose-200">
                          Catálogo B.6: Lencería Explícita, Transparencias y Arneses
                        </h3>
                      </div>
                      <p className="text-xs text-zinc-400">
                        Equipa prendas íntimas eróticas en la muñeca 2D. Se integran en las capas de atuendo y pueden retirarse interactivamente.
                      </p>
                    </div>
                    <span className="text-[11px] font-mono text-rose-400 bg-rose-950/80 px-2.5 py-1 rounded-lg border border-rose-800">
                      {state.nsfw?.explicitLingerie?.length || 0} pieza(s) equipada(s)
                    </span>
                  </div>

                  {/* Grid of Explicit Lingerie */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    {EXPLICIT_LINGERIE_OPTIONS.map(item => {
                      const isEquipped = (state.nsfw?.explicitLingerie || []).includes(item.name);
                      return (
                        <div
                          key={item.id}
                          className={`p-4 rounded-xl border transition-all flex flex-col justify-between space-y-3 ${
                            isEquipped
                              ? 'bg-[#1D121B] border-rose-600 shadow-md shadow-rose-950/40'
                              : 'bg-[#15171C] border-[#2A2D35] hover:border-zinc-700'
                          }`}
                        >
                          <div className="space-y-1.5">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-mono font-bold text-rose-400">{item.id}</span>
                              <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${
                                isEquipped
                                  ? 'bg-rose-950 border-rose-600 text-rose-300 font-bold'
                                  : 'bg-[#0F1115] border-[#222] text-zinc-500'
                              }`}>
                                {isEquipped ? '✓ Equipado' : 'Disponible'}
                              </span>
                            </div>
                            <h4 className="text-xs font-bold text-zinc-100">{item.name}</h4>
                            <p className="text-[11px] text-zinc-400 leading-relaxed">{item.description}</p>
                          </div>

                          <div className="pt-2 border-t border-white/5 flex items-center justify-between">
                            <span className="text-[10px] font-mono text-zinc-500">Capa Íntima R+18</span>
                            <button
                              type="button"
                              onClick={() => handleToggleExplicitLingerie(item)}
                              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                                isEquipped
                                  ? 'bg-rose-950/80 hover:bg-rose-900 border border-rose-600 text-rose-200'
                                  : 'bg-[#1F222C] hover:bg-[#282C38] border border-[#3A3F50] text-zinc-200'
                              }`}
                            >
                              {isEquipped ? (
                                <>
                                  <Unlock className="w-3.5 h-3.5 text-rose-400" />
                                  <span>Quitar Prenda</span>
                                </>
                              ) : (
                                <>
                                  <Lock className="w-3.5 h-3.5 text-[#C9A050]" />
                                  <span>Equipar en Atuendo</span>
                                </>
                              )}
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          ) : (
          <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-serif italic text-[#C9A050]">
                1. Seleccionar {isAccCat ? 'Accesorio' : 'Prenda'} de {activeCategory.name}
              </h3>
              {isAccCat && selectedAccSubcat !== 'Todos' && (
                <span className="text-[11px] font-mono text-[#C9A050] bg-[#1A1C22] px-2 py-0.5 rounded border border-[#C9A050]/40">
                  {selectedAccSubcat} ({filteredCategoryItems.length})
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6 max-h-[380px] overflow-y-auto pr-1">
              {filteredCategoryItems.map(item => {
                const isChosen = currentGarment.itemId === item.id;
                return (
                  <div
                    key={item.id}
                    onClick={() => {
                      const newOpts = getWardrobeOptions(selectedCat, item.id, item.name);
                      const isAccessory = selectedCat === 'B5';
                      setCurrentGarment(prev => ({ 
                        ...prev, 
                        itemId: item.id, 
                        name: item.name,
                        accessorySubcategory: item.subcategory || prev.accessorySubcategory || '',
                        cut: newOpts.cut.includes(prev.cut) ? prev.cut : (newOpts.cut[0] || ''),
                        length: newOpts.length.includes(prev.length) ? prev.length : (newOpts.length[0] || ''),
                        sleeve: newOpts.sleeve.includes(prev.sleeve) ? prev.sleeve : (newOpts.sleeve[0] || ''),
                        material: newOpts.material.includes(prev.material) ? prev.material : (newOpts.material[0] || ''),
                        finish: newOpts.finish.includes(prev.finish) ? prev.finish : (newOpts.finish[0] || ''),
                        details: prev.details && prev.details.filter(d => newOpts.details.includes(d)).length > 0 ? prev.details.filter(d => newOpts.details.includes(d)) : (newOpts.details[0] ? [newOpts.details[0]] : []),
                        variation: newOpts.variation.includes(prev.variation) ? prev.variation : (newOpts.variation[0] || ''),
                        layer: newOpts.layer.includes(prev.layer) ? prev.layer : (newOpts.layer[0] || ''),
                        location: prev.location.filter(l => newOpts.location.includes(l)).length > 0 ? prev.location.filter(l => newOpts.location.includes(l)) : (newOpts.location[0] ? [newOpts.location[0]] : []),
                        detailLocations: {},
                        pattern: newOpts.pattern.includes(prev.pattern) ? prev.pattern : (newOpts.pattern[0] || ''),
                        patternDetail: '',
                        neckline: newOpts.neckline && newOpts.neckline.includes(prev.neckline) ? prev.neckline : (newOpts.neckline ? newOpts.neckline[0] : ''),
                        emblem: newOpts.emblem.includes(prev.emblem) ? prev.emblem : (newOpts.emblem[0] || 'Ninguno'),
                        vfx: newOpts.vfx.includes(prev.vfx) ? prev.vfx : (newOpts.vfx[0] || 'Ninguno'),
                        gemType: isAccessory ? (prev.gemType || 'Sin Gema / Metálico Puro') : '',
                        gemColor: isAccessory ? (prev.gemColor || '') : '',
                        engraving: isAccessory ? (prev.engraving || 'Sin Grabado / Liso Pulido') : '',
                        sizeScale: isAccessory ? (prev.sizeScale || 'Estándar Equilibrado') : '',
                        fitStyle: isAccessory ? (prev.fitStyle || 'Ceñido / Pegado a la piel') : '',
                        coverageZones: (newOpts.location && newOpts.location.length > 0) ? [...newOpts.location] : (prev.coverageZones || []),
                        coverageStyle: prev.coverageStyle || 'Ajuste Ergonómico Táctico con Puntos Articulados',
                        coverageDetails: prev.coverageDetails || ''
                      }));
                    }} className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      isChosen ? 'bg-[#1A1C22] border-[#C9A050] ring-1 ring-[#C9A050]/40' : 'bg-[#15171C] border-[#2A2D35] hover:border-[#4A4D55]'
                    }`}
                  >
                    <div className="flex justify-between items-start mb-1">
                      <span className="text-xs font-mono text-[#C9A050] font-semibold">{item.id}</span>
                      <div className="flex items-center space-x-1">
                        {item.subcategory && (
                          <span className="text-[9px] text-[#888888] bg-[#0F1115] px-1.5 py-0.5 rounded border border-[#222222]">
                            {item.subcategory}
                          </span>
                        )}
                        {isChosen && <span className="text-xs text-[#C9A050] bg-[#1A1C22] px-1.5 rounded font-bold">✓</span>}
                      </div>
                    </div>
                    <h4 className="font-bold text-sm text-[#E0E0E0] mb-0.5">{item.name}</h4>
                    <p className="text-[11px] text-[#888888] leading-relaxed">{item.desc}</p>
                  </div>
                );
              })}
            </div>

            {/* Customization Form */}
            {currentGarment.name && (
              <div className="space-y-6 pt-4 border-t border-[#222222] animate-fadeIn">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-[#C9A050] flex items-center space-x-2">
                    <Sliders className="w-4 h-4 text-[#C9A050]" />
                    <span>Configuración Detallada para: {currentGarment.name}</span>
                  </h4>
                  {currentGarment.accessorySubcategory && (
                    <span className="text-xs font-mono text-[#A0A0A0] bg-[#15171C] px-2.5 py-1 rounded-lg border border-[#2A2D35]">
                      {currentGarment.accessorySubcategory}
                    </span>
                  )}
                </div>

                {/* ========================================================== */}
                {/* MOTOR LÓGICO INTELIGENTE: PERFIL, ONTOLOGÍA & ANATOMÍA     */}
                {/* ========================================================== */}
                <div className="bg-gradient-to-br from-[#16181E] via-[#121419] to-[#0D0F14] border border-[#C9A050]/40 rounded-2xl p-5 space-y-4 shadow-md">
                  <div className="flex items-center justify-between flex-wrap gap-2 border-b border-[#2A2D35] pb-3">
                    <div className="flex items-center space-x-2.5">
                      <div className="w-8 h-8 rounded-lg bg-[#C9A050]/20 border border-[#C9A050]/60 flex items-center justify-center text-[#C9A050]">
                        <Wand2 className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="text-[10px] font-mono uppercase tracking-widest text-[#C9A050] font-bold">
                            Motor Lógico de Indumentaria
                          </span>
                          <span className="text-[9px] font-mono px-2 py-0.5 rounded-full bg-[#1A1C22] border border-[#3A3D46] text-[#A0A0A0]">
                            {garmentProfile.category}
                          </span>
                        </div>
                        <h4 className="text-sm font-serif font-bold text-[#F0E6D2]">
                          Comprensión Ontológica: {garmentProfile.name}
                        </h4>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowEngineDetails(!showEngineDetails)}
                      className="text-xs text-[#C9A050] hover:text-[#E5B869] font-mono flex items-center space-x-1 cursor-pointer"
                    >
                      <span>{showEngineDetails ? 'Ocultar Análisis' : 'Ver Análisis Completo'}</span>
                    </button>
                  </div>

                  {showEngineDetails && (
                    <div className="space-y-4 text-xs">
                      {/* Grid: Qué es & Efecto / Influencia */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                        <div className="bg-[#0F1115] border border-[#22252C] rounded-xl p-3.5 space-y-1.5">
                          <div className="flex items-center space-x-1.5 text-[#C9A050] font-mono text-[11px] font-bold">
                            <Info className="w-3.5 h-3.5" />
                            <span>¿QUÉ ES? (NATURALEZA & CONFECCIÓN)</span>
                          </div>
                          <p className="text-[#C0C4CC] leading-relaxed">
                            {garmentProfile.whatIs}
                          </p>
                        </div>

                        <div className="bg-[#0F1115] border border-[#22252C] rounded-xl p-3.5 space-y-1.5">
                          <div className="flex items-center space-x-1.5 text-amber-300 font-mono text-[11px] font-bold">
                            <Sparkles className="w-3.5 h-3.5" />
                            <span>¿QUÉ EFECTO E INFLUENCIA TIENE?</span>
                          </div>
                          <p className="text-[#C0C4CC] leading-relaxed">
                            {garmentProfile.effectAndInfluence}
                          </p>
                        </div>
                      </div>

                      {/* Anatomía & Cómo se viste */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                        <div className="bg-[#0F1115] border border-[#22252C] rounded-xl p-3 space-y-1">
                          <span className="text-[10px] font-mono text-[#888888] uppercase block">
                            📍 ¿Dónde y en qué parte del cuerpo se viste o usa?
                          </span>
                          <p className="text-[#E0E0E0] text-[11px] leading-relaxed">
                            {garmentProfile.anatomicalPlacement}
                          </p>
                        </div>

                        <div className="bg-[#0F1115] border border-[#22252C] rounded-xl p-3 space-y-1">
                          <span className="text-[10px] font-mono text-[#888888] uppercase block">
                            ⚙️ ¿Cómo se viste o usa? (Mecanismo y sujeción)
                          </span>
                          <p className="text-[#E0E0E0] text-[11px] leading-relaxed">
                            {garmentProfile.howWorn}
                          </p>
                        </div>
                      </div>

                      {/* Partes que la componen */}
                      {garmentProfile.componentParts && garmentProfile.componentParts.length > 0 && (
                        <div className="space-y-1.5">
                          <span className="text-[11px] font-mono text-[#888888] block">
                            🧩 Partes que componen esta prenda:
                          </span>
                          <div className="flex flex-wrap gap-1.5">
                            {garmentProfile.componentParts.map(part => (
                              <span
                                key={part}
                                className="bg-[#15171C] border border-[#2A2D35] text-[#A0A0A0] px-2.5 py-1 rounded-lg text-[11px]"
                              >
                                {part}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Formas de usarse (Modo de Porte interactivo) */}
                      {garmentProfile.wearingStyles && garmentProfile.wearingStyles.length > 0 && (
                        <div className="space-y-2 pt-2 border-t border-[#22252C]">
                          <div className="flex items-center justify-between">
                            <span className="text-[11px] font-mono text-[#C9A050] font-bold">
                              👔 Formas de Usarse (Modo de Porte Activo):
                            </span>
                            <span className="text-[10px] font-mono text-[#888888]">
                              Selección actual: {currentGarment.wearStyle || 'Clásico'}
                            </span>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {garmentProfile.wearingStyles.map(st => {
                              const isStActive = currentGarment.wearStyle === st;
                              return (
                                <button
                                  key={st}
                                  type="button"
                                  onClick={() => setCurrentGarment(prev => ({ ...prev, wearStyle: st }))}
                                  className={`px-3 py-1.5 text-xs rounded-xl border transition-all cursor-pointer flex items-center space-x-1.5 ${
                                    isStActive
                                      ? 'bg-[#C9A050] text-[#0A0B0E] font-bold border-[#C9A050] shadow-md'
                                      : 'bg-[#15171C] text-[#888888] border-[#2A2D35] hover:text-[#E0E0E0] hover:border-[#4A4D55]'
                                  }`}
                                >
                                  {isStActive && <Check className="w-3.5 h-3.5 shrink-0" />}
                                  <span>{st}</span>
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Accessory-Specific Customization Suite */}
                {isAccCat && (
                  <div className="bg-[#12141A] border border-[#C9A050]/30 rounded-2xl p-5 space-y-4 shadow-sm">
                    <div className="flex items-center space-x-2 text-xs font-mono text-[#C9A050]">
                      <Gem className="w-4 h-4 text-[#C9A050]" />
                      <span className="font-bold uppercase tracking-wider">Ajustes Personalizables del Accesorio</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                      {/* Gem Type */}
                      <div>
                        <label className="block text-xs font-mono text-[#888888] mb-1">
                          Gema / Incrustación <InfoTooltip text="Piedra preciosa o gema engarzada en el accesorio." />
                        </label>
                        <select
                          value={currentGarment.gemType || 'Sin Gema / Metálico Puro'}
                          onChange={e => setCurrentGarment(prev => ({ ...prev, gemType: e.target.value }))}
                          className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none"
                        >
                          {ACCESSORY_GEM_TYPES.map(g => <option key={g} value={g}>{g}</option>)}
                        </select>
                      </div>

                      {/* Engraving */}
                      <div>
                        <label className="block text-xs font-mono text-[#888888] mb-1">
                          Grabado / Filigrana <InfoTooltip text="Inscripción, runa o motivo ornamental tallado en el accesorio." />
                        </label>
                        <select
                          value={currentGarment.engraving || 'Sin Grabado / Liso Pulido'}
                          onChange={e => setCurrentGarment(prev => ({ ...prev, engraving: e.target.value }))}
                          className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none"
                        >
                          {ACCESSORY_ENGRAVINGS.map(eng => <option key={eng} value={eng}>{eng}</option>)}
                        </select>
                      </div>

                      {/* Conditional Calligraphy / Emblem Builder for Engravings */}
                      {currentGarment.engraving && !/sin grabado|liso|ningun/i.test(currentGarment.engraving) && (
                        <div className="sm:col-span-2 pt-2">
                          {isLogoShieldOrSealOption(currentGarment.engraving) ? (
                            <LogoSealEmblemBuilder
                              config={currentGarment.emblemConfig}
                              onChange={cfg => setCurrentGarment(prev => ({ ...prev, emblemConfig: cfg }))}
                              contextTitle={`Grabado Heráldico / Sello: ${currentGarment.engraving}`}
                            />
                          ) : isCalligraphyOrTextOption(currentGarment.engraving) ? (
                            <CalligraphyTextInput
                              value={currentGarment.engravingText || ''}
                              onChange={t => setCurrentGarment(prev => ({ ...prev, engravingText: t }))}
                              optionContext={currentGarment.engraving}
                            />
                          ) : null}
                        </div>
                      )}

                      {/* Size Scale */}
                      <div>
                        <label className="block text-xs font-mono text-[#888888] mb-1">
                          Escala / Tamaño <InfoTooltip text="Volumen y proporción visual del accesorio respecto al cuerpo." />
                        </label>
                        <select
                          value={currentGarment.sizeScale || 'Estándar Equilibrado'}
                          onChange={e => setCurrentGarment(prev => ({ ...prev, sizeScale: e.target.value }))}
                          className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none"
                        >
                          {ACCESSORY_SIZE_SCALES.map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                      </div>

                      {/* Fit Style */}
                      <div>
                        <label className="block text-xs font-mono text-[#888888] mb-1">
                          Estilo de Caída / Ajuste <InfoTooltip text="Comportamiento físico del accesorio (ceñido, holgado, escalonado)." />
                        </label>
                        <select
                          value={currentGarment.fitStyle || 'Ceñido / Pegado a la piel'}
                          onChange={e => setCurrentGarment(prev => ({ ...prev, fitStyle: e.target.value }))}
                          className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none"
                        >
                          {ACCESSORY_FIT_STYLES.map(fs => <option key={fs} value={fs}>{fs}</option>)}
                        </select>
                      </div>

                      {/* Gem Color Customizer if Gem Selected */}
                      {currentGarment.gemType && currentGarment.gemType !== 'Sin Gema / Metálico Puro' && (
                        <div className="sm:col-span-2">
                          <label className="block text-xs font-mono text-[#888888] mb-1">
                            Tono o Matiz Específico de la Gema
                          </label>
                          <div className="flex items-center space-x-2">
                            <input
                              type="text"
                              placeholder="Ej: Rojo Sangre Intenso, Azul Hielo Eléctrico"
                              value={currentGarment.gemColor || ''}
                              onChange={e => setCurrentGarment(prev => ({ ...prev, gemColor: e.target.value }))}
                              className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                            />
                            {BASIC_COLOR_SWATCHES.slice(0, 6).map(swatch => (
                              <button
                                key={swatch.id}
                                type="button"
                                title={swatch.name}
                                onClick={() => setCurrentGarment(prev => ({ ...prev, gemColor: swatch.name }))}
                                className="w-6 h-6 rounded-full border border-white/20 hover:scale-110 transition-all shrink-0"
                                style={{ backgroundColor: swatch.hex }}
                              />
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Coverage, Silhouette & Fit Suite */}
                <GarmentCoverageAndFitSuite
                  currentGarment={currentGarment}
                  setCurrentGarment={setCurrentGarment}
                  activeOptions={activeOptions}
                  isAccCat={isAccCat}
                  isShoesCat={isShoesCat}
                  categoryName={WARDROBE_CATEGORIES.find(c => c.id === selectedCat)?.name || 'Prenda'}
                  triggerToast={triggerToast}
                />

                {/* Material, Confección & Simbología */}
                <div className="bg-[#12141A] border border-[#2A2D35] rounded-2xl p-5 space-y-4">
                  <div className="flex items-center space-x-2 text-xs font-mono text-[#C9A050]">
                    <Layers className="w-4 h-4 text-[#C9A050]" />
                    <span className="font-bold uppercase tracking-wider">Material, Confección y Simbología</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-mono text-[#888888] mb-1">
                        {isAccCat ? 'Metal / Material Base' : 'Material'}
                      </label>
                      <select
                        value={currentGarment.material}
                        onChange={e => setCurrentGarment(prev => ({ ...prev, material: e.target.value }))}
                        className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                      >
                        {activeOptions.material.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-mono text-[#888888] mb-1">
                        Acabado <InfoTooltip text="Tratamiento visual y brillo superficial." />
                      </label>
                      <select
                        value={currentGarment.finish}
                        onChange={e => setCurrentGarment(prev => ({ ...prev, finish: e.target.value }))}
                        className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                      >
                        {activeOptions.finish.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-mono text-[#888888] mb-1">
                        Variación <InfoTooltip text="Estilos alternativos de estructura o confección." />
                      </label>
                      <select
                        value={currentGarment.variation}
                        onChange={e => setCurrentGarment(prev => ({ ...prev, variation: e.target.value }))}
                        className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                      >
                        {activeOptions.variation.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-mono text-[#888888] mb-1">
                        Capa <InfoTooltip text="Nivel de superposición anatómica." />
                      </label>
                      <select
                        value={currentGarment.layer}
                        onChange={e => setCurrentGarment(prev => ({ ...prev, layer: e.target.value }))}
                        className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                      >
                        {activeOptions.layer.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                    </div>

                    {activeOptions.pattern && activeOptions.pattern.length > 0 && !isAccCat && (
                      <div>
                        <label className="block text-xs font-mono text-[#888888] mb-1">Patrón / Estampado</label>
                        <select
                          value={currentGarment.pattern || ''}
                          onChange={e => setCurrentGarment(prev => ({ ...prev, pattern: e.target.value }))}
                          className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                        >
                          {activeOptions.pattern.map(o => <option key={o} value={o}>{o}</option>)}
                        </select>
                      </div>
                    )}

                    {currentGarment.pattern === 'Animal Print' && (
                      <div>
                        <label className="block text-xs font-mono text-[#888888] mb-1">Especie (Animal Print)</label>
                        <select
                          value={currentGarment.patternDetail}
                          onChange={e => setCurrentGarment(prev => ({ ...prev, patternDetail: e.target.value }))}
                          className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                        >
                          <option value="">Selecciona...</option>
                          <option value="Leopardo">Leopardo</option>
                          <option value="Guepardo">Guepardo</option>
                          <option value="Cebra">Cebra</option>
                          <option value="Tigre">Tigre</option>
                          <option value="Serpiente">Serpiente</option>
                          <option value="Cocodrilo">Cocodrilo</option>
                          <option value="Vaca">Vaca</option>
                        </select>
                      </div>
                    )}

                    {currentGarment.pattern === 'Logotipo / Texto' && (
                      <div>
                        <label className="block text-xs font-mono text-[#888888] mb-1">Texto o Descripción del Logotipo</label>
                        <input
                          type="text"
                          placeholder="Ej: Logo CyberDyne, Letras 'PUNK'"
                          value={currentGarment.patternDetail}
                          onChange={e => setCurrentGarment(prev => ({ ...prev, patternDetail: e.target.value }))}
                          className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                        />
                      </div>
                    )}

                    {activeOptions.emblem && activeOptions.emblem.length > 0 && (
                      <div>
                        <label className="block text-xs font-mono text-[#888888] mb-1">
                          Emblema / Símbolo <InfoTooltip text="Logos, crestas, runas o marcas singulares grabadas o bordadas." />
                        </label>
                        <select
                          value={currentGarment.emblem || 'Ninguno'}
                          onChange={e => setCurrentGarment(prev => ({ ...prev, emblem: e.target.value }))}
                          className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                        >
                          {activeOptions.emblem.map(o => <option key={o} value={o}>{o}</option>)}
                        </select>
                      </div>
                    )}

                    {/* Conditional Calligraphy / Emblem Builder for Garment Emblem */}
                    {currentGarment.emblem && currentGarment.emblem !== 'Ninguno' && (
                      <div className="col-span-full pt-2">
                        {isLogoShieldOrSealOption(currentGarment.emblem) ? (
                          <LogoSealEmblemBuilder
                            config={currentGarment.emblemConfig}
                            onChange={cfg => setCurrentGarment(prev => ({ ...prev, emblemConfig: cfg }))}
                            contextTitle={`Constructor de Emblema / Sello: ${currentGarment.emblem}`}
                          />
                        ) : isCalligraphyOrTextOption(currentGarment.emblem) ? (
                          <CalligraphyTextInput
                            value={currentGarment.engravingText || ''}
                            onChange={t => setCurrentGarment(prev => ({ ...prev, engravingText: t }))}
                            optionContext={currentGarment.emblem}
                          />
                        ) : null}
                      </div>
                    )}

                    {activeOptions.vfx && activeOptions.vfx.length > 0 && (
                      <div>
                        <label className="block text-xs font-mono text-[#888888] mb-1">
                          Efectos / Condición <InfoTooltip text="Estado físico especial o efectos visuales/mágicos que emite la pieza." />
                        </label>
                        <select
                          value={currentGarment.vfx || 'Ninguno'}
                          onChange={e => setCurrentGarment(prev => ({ ...prev, vfx: e.target.value }))}
                          className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                        >
                          {activeOptions.vfx.map(o => <option key={o} value={o}>{o}</option>)}
                        </select>
                      </div>
                    )}

                    <div>
                      <label className="block text-xs font-mono text-[#888888] mb-1">
                        Estado de Desgaste <InfoTooltip text="Nivel de conservación textil o de armadura (impecable, desgastado en combate, raído, etc.)." />
                      </label>
                      <select
                        value={currentGarment.wearCondition || WEAR_CONDITIONS[0]}
                        onChange={e => setCurrentGarment(prev => ({ ...prev, wearCondition: e.target.value }))}
                        className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                      >
                        {WEAR_CONDITIONS.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-mono text-[#888888] mb-1">
                        Tradición Cultural / Estilo <InfoTooltip text="Raíz e influencia étnica, histórica o de fantasía (Nórdico, Samurai, Mesoamericano, etc.)." />
                      </label>
                      <select
                        value={currentGarment.culturalTradition || CULTURAL_ACCESSORY_TRADITIONS[0]}
                        onChange={e => setCurrentGarment(prev => ({ ...prev, culturalTradition: e.target.value }))}
                        className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                      >
                        {CULTURAL_ACCESSORY_TRADITIONS.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                    </div>
                  </div>
                </div>

                  {/* Bottom Color & Details Customizer */}
                  <div className="space-y-6 pt-4 border-t border-[#222222]">
                    {/* Fabric / Metal Color Customizer */}
                    <div>
                      <FabricColorCustomizer
                        value={currentGarment.color}
                        onChange={newColor => setCurrentGarment(prev => ({ ...prev, color: newColor }))}
                        garmentName={currentGarment.name || (isAccCat ? 'Accesorio' : 'Prenda')}
                      />
                    </div>

                    {/* Garment Print & Graphic Motifs Customizer (A.2.4.5-like textile stamp system) */}
                    <div className="bg-[#15171C] border border-[#2A2D35] p-5 rounded-2xl space-y-5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Palette className="w-4 h-4 text-[#C9A050]" />
                          <label className="block text-sm font-bold text-[#C9A050]">
                            Estampados, Bordados & Diseños Gráficos
                          </label>
                        </div>
                        <InfoTooltip text="Bordados heráldicos, serigrafías de alto impacto, sellos mágicos arcanos, parches militares, patrones o caligrafías colocados con precisión anatómica en la prenda." />
                      </div>
                      
                      {/* Multi-select Type Buttons */}
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <label className="block text-xs font-mono text-[#888888]">
                            Selecciona Tipos de Estampado / Motivo (Múltiple):
                          </label>
                          <span className="text-[10px] font-mono text-[#C9A050] bg-[#0F1115] px-2 py-0.5 rounded border border-[#C9A050]/40">
                            Filtro Lógico Activo: {compatiblePrintTypes.length} motivos compatibles
                          </span>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                          {compatiblePrintTypes.map(printType => {
                            const isSelected = (currentGarment.printTypes || []).includes(printType);
                            return (
                              <button
                                key={printType}
                                type="button"
                                onClick={() => {
                                  setCurrentGarment(prev => {
                                    const types = prev.printTypes || [];
                                    const isIncluded = types.includes(printType);
                                    const nextTypes = isIncluded ? types.filter(t => t !== printType) : [...types, printType];
                                    
                                    const cfg = getGarmentPrintConfig(printType);
                                    const nextShapes = { ...(prev.printShapes || {}) };
                                    const nextColors = { ...(prev.printColors || {}) };
                                    const nextLocs = { ...(prev.printLocations || {}) };
                                    
                                    if (!isIncluded) {
                                      if (!nextShapes[printType]) nextShapes[printType] = cfg.defaultShape;
                                      if (!nextColors[printType]) nextColors[printType] = cfg.defaultColor;
                                      if (!nextLocs[printType] || nextLocs[printType].length === 0) {
                                        nextLocs[printType] = [garmentPrintLocations[0] || 'Frente Central'];
                                      }
                                    } else {
                                      delete nextShapes[printType];
                                      delete nextColors[printType];
                                      delete nextLocs[printType];
                                    }
                                    
                                    return {
                                      ...prev,
                                      printTypes: nextTypes,
                                      printShapes: nextShapes,
                                      printColors: nextColors,
                                      printLocations: nextLocs
                                    };
                                  });
                                }}
                                className={`p-2 rounded-xl text-left text-xs font-medium transition-all flex items-center justify-between border cursor-pointer ${
                                  isSelected
                                    ? 'bg-[#C9A050]/15 text-[#C9A050] border-[#C9A050] ring-1 ring-[#C9A050]/30 font-semibold'
                                    : 'bg-[#0F1115] text-[#A0A0A0] border-[#222222] hover:border-[#4A4D55] hover:text-[#E0E0E0]'
                                }`}
                              >
                                <span className="truncate mr-1">{printType}</span>
                                <span className={`w-3.5 h-3.5 rounded-full flex items-center justify-center text-[9px] shrink-0 border ${
                                  isSelected ? 'bg-[#C9A050] text-[#0A0B0E] border-[#C9A050]' : 'border-[#444444]'
                                }`}>
                                  {isSelected ? '✓' : ''}
                                </span>
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      {/* Adaptive details for each selected print */}
                      {currentGarment.printTypes && currentGarment.printTypes.length > 0 && (
                        <div className="space-y-4 pt-3 border-t border-[#222222]">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-mono text-[#C9A050] font-bold">
                              Configuración Adaptativa por Estampado ({currentGarment.printTypes.length}):
                            </span>
                            <button
                              type="button"
                              onClick={() => {
                                setCurrentGarment(prev => ({
                                  ...prev,
                                  printTypes: [],
                                  printShapes: {},
                                  printColors: {},
                                  printLocations: {}
                                }));
                              }}
                              className="text-[11px] text-[#888888] hover:text-rose-400 cursor-pointer underline"
                            >
                              Limpiar todos los estampados
                            </button>
                          </div>

                          {currentGarment.printTypes.map(printType => {
                            const cfg = getGarmentPrintConfig(printType);
                            const currentShape = (currentGarment.printShapes && currentGarment.printShapes[printType]) || cfg.defaultShape;
                            const currentColor = (currentGarment.printColors && currentGarment.printColors[printType]) || cfg.defaultColor;
                            const currentLocs = (currentGarment.printLocations && currentGarment.printLocations[printType]) || [];

                            return (
                              <div key={printType} className="bg-[#0F1115] border-l-4 border-[#C9A050] border-y border-r border-[#222222] rounded-xl p-4 space-y-3">
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center space-x-2">
                                    <Sparkles className="w-3.5 h-3.5 text-[#C9A050]" />
                                    <span className="font-bold text-xs text-[#E0E0E0]">{printType}</span>
                                  </div>
                                  <span className="text-[10px] font-mono text-[#888888] bg-[#15171C] px-2 py-0.5 rounded border border-[#2A2D35]">
                                    {currentLocs.length} {currentLocs.length === 1 ? 'ubicación' : 'ubicaciones'}
                                  </span>
                                </div>

                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                  {/* Shape */}
                                  <div>
                                    <label className="block text-[11px] font-mono text-[#888888] mb-1">
                                      Diseño / Motivo Específico ({cfg.shapes.length} opciones):
                                    </label>
                                    <select
                                      value={currentShape}
                                      onChange={e => {
                                        const val = e.target.value;
                                        setCurrentGarment(prev => ({
                                          ...prev,
                                          printShapes: {
                                            ...(prev.printShapes || {}),
                                            [printType]: val
                                          }
                                        }));
                                      }}
                                      className="w-full bg-[#15171C] border border-[#2A2D35] rounded-lg p-2 text-xs text-[#E0E0E0] focus:border-[#C9A050]"
                                    >
                                      {cfg.shapes.map(s => <option key={s} value={s}>{s}</option>)}
                                    </select>
                                  </div>

                                  {/* Color */}
                                  <div>
                                    <label className="block text-[11px] font-mono text-[#888888] mb-1">
                                      Color / Acabado Visual ({cfg.colors.length} opciones):
                                    </label>
                                    <select
                                      value={currentColor}
                                      onChange={e => {
                                        const val = e.target.value;
                                        setCurrentGarment(prev => ({
                                          ...prev,
                                          printColors: {
                                            ...(prev.printColors || {}),
                                            [printType]: val
                                          }
                                        }));
                                      }}
                                      className="w-full bg-[#15171C] border border-[#2A2D35] rounded-lg p-2 text-xs text-[#E0E0E0] focus:border-[#C9A050]"
                                    >
                                      {cfg.colors.map(c => <option key={c} value={c}>{c}</option>)}
                                    </select>
                                  </div>
                                </div>

                                {/* Locations */}
                                <div className="pt-2 border-t border-[#1F2228]">
                                  <div className="flex items-center justify-between mb-1.5">
                                    <label className="block text-[11px] font-mono text-[#888888]">
                                      Posición en la Prenda ({currentLocs.length} seleccionadas):
                                    </label>
                                    <span className="text-[10px] font-mono text-[#C9A050]">
                                      Anatomía: {garmentProfile.name}
                                    </span>
                                  </div>
                                  <div className="flex flex-wrap gap-1.5">
                                    {garmentPrintLocations.map(loc => {
                                      const isLocSelected = currentLocs.includes(loc);
                                      return (
                                        <button
                                          key={loc}
                                          type="button"
                                          onClick={() => {
                                            setCurrentGarment(prev => {
                                              const locs = (prev.printLocations && prev.printLocations[printType]) || [];
                                              const nextLocsForType = locs.includes(loc) ? locs.filter(l => l !== loc) : [...locs, loc];
                                              return {
                                                ...prev,
                                                printLocations: {
                                                  ...(prev.printLocations || {}),
                                                  [printType]: nextLocsForType
                                                }
                                              };
                                            });
                                          }}
                                          className={`px-2 py-0.5 text-[10px] rounded-md transition-all cursor-pointer ${
                                            isLocSelected
                                              ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                                              : 'bg-[#15171C] text-[#888888] border border-[#2A2D35] hover:border-[#888888] hover:text-[#E0E0E0]'
                                          }`}
                                        >
                                          {loc}
                                        </button>
                                      );
                                    })}
                                  </div>
                                </div>

                                {/* Conditional Calligraphy / Text Input */}
                                {isCalligraphyOrTextOption(printType, currentShape) && (
                                  <div className="pt-2 border-t border-[#1F2228]">
                                    <CalligraphyTextInput
                                      value={(currentGarment.printTexts && currentGarment.printTexts[printType]) || ''}
                                      onChange={text => {
                                        setCurrentGarment(prev => ({
                                          ...prev,
                                          printTexts: {
                                            ...(prev.printTexts || {}),
                                            [printType]: text
                                          }
                                        }));
                                      }}
                                      optionContext={printType}
                                    />
                                  </div>
                                )}

                                {/* Conditional Logo / Shield / Seal Emblem Builder */}
                                {isLogoShieldOrSealOption(printType, currentShape) && (
                                  <div className="pt-2 border-t border-[#1F2228]">
                                    <LogoSealEmblemBuilder
                                      config={currentGarment.printEmblemConfigs && currentGarment.printEmblemConfigs[printType]}
                                      onChange={cfg => {
                                        setCurrentGarment(prev => ({
                                          ...prev,
                                          printEmblemConfigs: {
                                            ...(prev.printEmblemConfigs || {}),
                                            [printType]: cfg
                                          }
                                        }));
                                      }}
                                      contextTitle={`Constructor Gráfico: ${printType}`}
                                    />
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>

                    {/* Combined: Detalles, Aplicaciones, Adornos & Especificaciones de Ajuste */}
                    <div className="bg-[#15171C] border border-[#2A2D35] p-5 rounded-2xl space-y-5">
                      <div className="flex items-center justify-between flex-wrap gap-2">
                        <div className="flex items-center space-x-2 text-xs font-mono text-[#C9A050]">
                          <Sliders className="w-4 h-4 text-[#C9A050]" />
                          <span className="font-bold uppercase tracking-wider text-sm">
                            Detalles, Aplicaciones, Adornos & Especificaciones de Ajuste
                          </span>
                        </div>
                        <span className="text-[10px] font-mono text-[#C9A050] bg-[#0F1115] px-2.5 py-1 rounded-lg border border-[#C9A050]/40">
                          Filtro Inteligente: {compatibleDetails.length} compatibles
                        </span>
                      </div>

                      {/* Modal / Card de Inspección Ontológica de Detalle */}
                      {inspectedDetail && (() => {
                        const meta = GarmentLogicService.getDetailMeta(inspectedDetail);
                        return (
                          <div className="bg-gradient-to-br from-[#1A1813] via-[#14151B] to-[#0E1017] border-2 border-[#C9A050] rounded-2xl p-5 space-y-3.5 shadow-2xl relative animate-fadeIn">
                            <button
                              type="button"
                              onClick={() => setInspectedDetail(null)}
                              className="absolute top-3.5 right-3.5 text-[#A0A0A0] hover:text-white p-1 rounded-lg hover:bg-white/10 cursor-pointer"
                              title="Cerrar Inspección"
                            >
                              <X className="w-4 h-4" />
                            </button>
                            <div className="flex items-center space-x-2.5 pr-8">
                              <div className="w-7 h-7 rounded-lg bg-[#C9A050]/20 border border-[#C9A050]/50 flex items-center justify-center text-[#C9A050]">
                                <Sparkles className="w-4 h-4" />
                              </div>
                              <div>
                                <span className="text-[10px] font-mono uppercase tracking-widest text-[#C9A050] font-bold block">
                                  Inspección Ontológica de Detalle
                                </span>
                                <h4 className="text-sm font-serif font-bold text-[#F5F0E6]">
                                  {meta.name}
                                </h4>
                              </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs pt-1">
                              <div className="bg-[#0B0D12] p-3 rounded-xl border border-[#22252C] space-y-1">
                                <span className="text-[10px] font-mono text-[#C9A050] uppercase font-bold flex items-center space-x-1">
                                  <span>📖 ¿Qué es?</span>
                                </span>
                                <p className="text-[#C0C4CC] leading-relaxed">{meta.whatIs}</p>
                              </div>
                              <div className="bg-[#0B0D12] p-3 rounded-xl border border-[#22252C] space-y-1">
                                <span className="text-[10px] font-mono text-amber-300 uppercase font-bold flex items-center space-x-1">
                                  <span>💡 ¿Qué significa?</span>
                                </span>
                                <p className="text-[#C0C4CC] leading-relaxed">{meta.whatMeans}</p>
                              </div>
                              <div className="bg-[#0B0D12] p-3 rounded-xl border border-[#22252C] space-y-1">
                                <span className="text-[10px] font-mono text-emerald-400 uppercase font-bold flex items-center space-x-1">
                                  <span>⚙️ ¿Qué función cumple?</span>
                                </span>
                                <p className="text-[#C0C4CC] leading-relaxed">{meta.functionAndMeaning}</p>
                              </div>
                              <div className="bg-[#0B0D12] p-3 rounded-xl border border-[#22252C] space-y-1">
                                <span className="text-[10px] font-mono text-cyan-400 uppercase font-bold flex items-center space-x-1">
                                  <span>🧵 ¿Cómo se aplica?</span>
                                </span>
                                <p className="text-[#C0C4CC] leading-relaxed">{meta.howApplied}</p>
                              </div>
                            </div>
                          </div>
                        );
                      })()}

                      {/* Detalles Selector */}
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <label className="block text-xs font-mono text-[#888888]">
                            Selecciona Detalles / Adornos Compatibles:
                          </label>
                          <span className="text-[10px] font-mono text-[#888888]">
                            Haz clic en ℹ️ para ver ontología completa
                          </span>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {compatibleDetails.map(o => {
                            const isSelected = (currentGarment.details || []).includes(o);
                            return (
                              <div
                                key={o}
                                className={`inline-flex items-center rounded-lg border transition-all overflow-hidden ${
                                  isSelected
                                    ? 'border-[#C9A050] ring-1 ring-[#C9A050]/40 shadow-sm'
                                    : 'border-[#2A2D35] hover:border-[#4A4D55]'
                                }`}
                              >
                                <button
                                  type="button"
                                  onClick={() => {
                                    setCurrentGarment(prev => {
                                      const dets = prev.details || [];
                                      let newDets;
                                      if (dets.includes(o)) {
                                        newDets = dets.filter(d => d !== o);
                                      } else {
                                        newDets = [...dets, o];
                                      }
                                      
                                      const newDetailLocs = { ...prev.detailLocations };
                                      if (!newDets.includes(o)) {
                                        delete newDetailLocs[o];
                                      }
                                      
                                      return { ...prev, details: newDets, detailLocations: newDetailLocs };
                                    });
                                  }}
                                  className={`px-3 py-1.5 text-xs transition-all cursor-pointer font-medium ${
                                    isSelected
                                      ? 'bg-[#C9A050] text-[#0A0B0E] font-bold'
                                      : 'bg-[#1A1C22] text-[#A0A0A0] hover:text-[#E0E0E0]'
                                  }`}
                                >
                                  {o}
                                </button>
                                <button
                                  type="button"
                                  title="Inspección Ontológica (Qué es, función, cómo se aplica)"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setInspectedDetail(o);
                                  }}
                                  className={`px-2 py-1.5 text-[11px] border-l transition-all cursor-pointer ${
                                    isSelected
                                      ? 'bg-[#B58B3E] text-[#0A0B0E] border-[#A27B32] hover:bg-[#A27B32]'
                                      : 'bg-[#14161B] text-[#777777] border-[#2A2D35] hover:text-[#C9A050]'
                                  }`}
                                >
                                  ℹ️
                                </button>
                              </div>
                            );
                          })}
                        </div>
                        {(currentGarment.details || []).includes('Carrera de Botones') && (
                          <div className="mt-2 text-[11px] text-[#C9A050] bg-[#0F1115] border border-[#C9A050]/30 rounded-lg p-2.5 flex items-start space-x-2">
                            <Sparkles className="w-3.5 h-3.5 mt-0.5 shrink-0 text-[#C9A050]" />
                            <p className="leading-relaxed">
                              <strong>Carrera de Botones:</strong> Describe la disposición y la línea en la que se colocan los botones a lo largo de la tapeta. Esta línea determina la cantidad y la distribución de botones en el cuello, pechera y cierre frontal.
                            </p>
                          </div>
                        )}
                      </div>

                      {/* Posiciones Específicas por Detalle */}
                      {!(currentGarment.details || []).includes('Minimalista') && (currentGarment.details || []).length > 0 && (
                        <div className="space-y-3 pt-3 border-t border-[#222222]">
                          <div className="flex items-center justify-between">
                            <label className="block text-xs font-mono text-[#888888]">
                              Posición de Uso Específica por Detalle:
                            </label>
                            <span className="text-[10px] font-mono text-[#C9A050]">
                              Anatómicamente adaptado a {garmentProfile.name}
                            </span>
                          </div>
                          {(currentGarment.details || []).map(det => {
                            const detLocs = (activeOptions.locationMap && activeOptions.locationMap[det] && activeOptions.locationMap[det].length > 0)
                              ? activeOptions.locationMap[det]
                              : GarmentLogicService.getDetailPositionsForGarment(currentGarment.name, selectedCat, det);
                            if (!detLocs || detLocs.length === 0) return null;
                            return (
                              <div key={det} className="bg-[#0F1115] rounded-xl p-3 border border-[#222222] pl-4 border-l-2 border-l-[#C9A050]">
                                <div className="flex items-center justify-between mb-2">
                                  <label className="block text-[11px] font-mono text-[#A0A0A0] uppercase tracking-wide">
                                    Posición para: <span className="text-[#C9A050] font-bold">{det}</span>
                                  </label>
                                  <button
                                    type="button"
                                    onClick={() => setInspectedDetail(det)}
                                    className="text-[10px] text-[#C9A050] hover:underline font-mono cursor-pointer"
                                  >
                                    Ver Significado & Función
                                  </button>
                                </div>
                                <div className="flex flex-wrap gap-2">
                                  {detLocs.map(o => {
                                    const currentDetLocs = (currentGarment.detailLocations && currentGarment.detailLocations[det]) || [];
                                    const isSelected = currentDetLocs.includes(o);
                                    return (
                                      <button
                                        key={o}
                                        type="button"
                                        onClick={() => {
                                          setCurrentGarment(prev => {
                                            const prevDetLocs = (prev.detailLocations && prev.detailLocations[det]) || [];
                                            const newLocs = prevDetLocs.includes(o) ? prevDetLocs.filter(l => l !== o) : [...prevDetLocs, o];
                                            return { ...prev, detailLocations: { ...prev.detailLocations, [det]: newLocs } };
                                          });
                                        }}
                                        className={`px-2.5 py-1 text-[11px] rounded-lg transition-all cursor-pointer ${
                                          isSelected
                                            ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-md'
                                            : 'bg-[#15171C] text-[#888888] border border-[#2A2D35] hover:border-[#888888] hover:text-[#E0E0E0]'
                                        }`}
                                      >
                                        {o}
                                      </button>
                                    );
                                  })}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}

                      {/* Color Sólido por Detalle Seleccionado */}
                      {!(currentGarment.details || []).includes('Minimalista') && (currentGarment.details || []).length > 0 && (
                        <div className="space-y-3 pt-3 border-t border-[#222222]">
                          <label className="block text-xs font-mono text-[#888888] mb-1">Color Sólido por Detalle (Selección Simple):</label>
                          {(currentGarment.details || []).map(det => {
                            const currentColor = (currentGarment.detailColors && currentGarment.detailColors[det]) || '';
                            return (
                              <div key={det} className="bg-[#0F1115] rounded-xl p-3 border border-[#222222] space-y-2">
                                <div className="flex items-center justify-between">
                                  <span className="text-[11px] font-mono font-bold text-[#C9A050]">Color para: {det}</span>
                                  <input
                                    type="text"
                                    placeholder="Color sólido (ej. Dorado, Negro, Azul)"
                                    value={currentColor}
                                    onChange={e => {
                                      const val = e.target.value;
                                      setCurrentGarment(prev => ({
                                        ...prev,
                                        detailColors: {
                                          ...(prev.detailColors || {}),
                                          [det]: val
                                        }
                                      }));
                                    }}
                                    className="bg-[#15171C] border border-[#2A2D35] rounded-lg px-2.5 py-1 text-[11px] text-[#E0E0E0] w-48"
                                  />
                                </div>
                                <div className="flex flex-wrap gap-1.5 pt-1 items-center">
                                  {BASIC_COLOR_SWATCHES.slice(0, 12).map(swatch => (
                                    <button
                                      key={swatch.id}
                                      type="button"
                                      title={swatch.name}
                                      onClick={() => {
                                        setCurrentGarment(prev => ({
                                          ...prev,
                                          detailColors: {
                                            ...(prev.detailColors || {}),
                                            [det]: swatch.name
                                          }
                                        }));
                                      }}
                                      className={`w-5 h-5 rounded-full border transition-all ${
                                        currentColor === swatch.name ? 'ring-2 ring-[#C9A050] scale-110' : 'border-white/20 hover:scale-105'
                                      }`}
                                      style={{ backgroundColor: swatch.hex }}
                                    />
                                  ))}
                                  {currentColor && (
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setCurrentGarment(prev => {
                                          const newColors = { ...(prev.detailColors || {}) };
                                          delete newColors[det];
                                          return { ...prev, detailColors: newColors };
                                        });
                                      }}
                                      className="text-[10px] text-[#888888] hover:text-rose-400 ml-2 underline cursor-pointer"
                                    >
                                      Limpiar
                                    </button>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}

                      {/* Especificaciones y Detalles de Ajuste / Confección Personalizada */}
                      <div className="pt-4 border-t border-[#222222] space-y-2.5">
                        <div className="flex items-center justify-between flex-wrap gap-2">
                          <label className="text-xs font-mono text-[#E0E0E0] font-semibold flex items-center space-x-2">
                            <span>Detalles / Especificaciones de Ajuste & Confección</span>
                            <InfoTooltip text="Costuras antifricción, ribetes elásticos, cremalleras ocultas, cordones regulables, tirantes anatómicos o detalles específicos de sujeción anatómica." />
                          </label>
                          <span className="text-[11px] text-[#888888]">
                            Especificación libre o selecciona una sugerencia rápida
                          </span>
                        </div>
                        <input
                          type="text"
                          placeholder="Ej: Costuras antifricción reforzadas, ribete elástico en puños y pretina, tensión regulable..."
                          value={currentGarment.coverageDetails || ''}
                          onChange={e => setCurrentGarment(prev => ({ ...prev, coverageDetails: e.target.value }))}
                          className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none"
                        />
                        <div className="flex flex-wrap gap-1.5 pt-1">
                          {[
                            'Costuras antifricción reforzadas',
                            'Ribete elástico en puños y pretina',
                            'Cierres magnéticos ocultos',
                            'Tensión regulable con cordones',
                            'Acolchado ergonómico articulado',
                            'Bordes termosellados sin costura',
                            'Refuerzo balístico en articulaciones'
                          ].map(sug => (
                            <button
                              key={sug}
                              type="button"
                              onClick={() => {
                                setCurrentGarment(prev => {
                                  const cur = prev.coverageDetails ? prev.coverageDetails.trim() : '';
                                  if (!cur) return { ...prev, coverageDetails: sug };
                                  if (cur.includes(sug)) return prev;
                                  return { ...prev, coverageDetails: `${cur}, ${sug}` };
                                });
                              }}
                              className="text-[10px] font-mono bg-[#0F1115] hover:bg-[#1A1D24] text-[#A0A0A0] hover:text-[#C9A050] border border-[#2A2D35] hover:border-[#C9A050]/40 px-2 py-0.5 rounded-lg transition-colors cursor-pointer"
                            >
                              + {sug}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                {/* Live Real-Time Garment Description Preview (Combined) */}
                <div className="bg-[#111318] border border-[#C9A050]/40 rounded-2xl p-5 mt-6 space-y-4 shadow-lg">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#2A2D35] pb-3">
                    <div className="flex items-center space-x-2.5">
                      <span className="relative flex h-2.5 w-2.5">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#C9A050] opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#C9A050]"></span>
                      </span>
                      <div className="flex items-center space-x-2">
                        <Sparkles className="w-4 h-4 text-[#C9A050]" />
                        <span className="text-xs font-mono font-bold uppercase tracking-wider text-[#C9A050]">
                          Descripción Canónica en Tiempo Real de esta Pieza
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <div className="flex bg-[#181A20] p-0.5 rounded-lg border border-[#2A2D35] text-[11px] font-mono">
                        <button
                          type="button"
                          onClick={() => setCanonicalViewTab('both')}
                          className={`px-2 py-0.5 rounded-md transition-all cursor-pointer ${canonicalViewTab === 'both' ? 'bg-[#C9A050] text-[#0A0B0E] font-bold' : 'text-[#888888] hover:text-[#E0E0E0]'}`}
                        >
                          Ambas Vistas
                        </button>
                        <button
                          type="button"
                          onClick={() => setCanonicalViewTab('sheet')}
                          className={`px-2 py-0.5 rounded-md transition-all cursor-pointer ${canonicalViewTab === 'sheet' ? 'bg-[#C9A050] text-[#0A0B0E] font-bold' : 'text-[#888888] hover:text-[#E0E0E0]'}`}
                        >
                          Ficha Técnica
                        </button>
                        <button
                          type="button"
                          onClick={() => setCanonicalViewTab('prompt')}
                          className={`px-2 py-0.5 rounded-md transition-all cursor-pointer ${canonicalViewTab === 'prompt' ? 'bg-[#C9A050] text-[#0A0B0E] font-bold' : 'text-[#888888] hover:text-[#E0E0E0]'}`}
                        >
                          Prompt IA
                        </button>
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          const text = formatGarmentDescription({
                            id: editingGarmentId || 'preview',
                            categoryId: selectedCat,
                            ...currentGarment
                          }, false);
                          navigator.clipboard.writeText(text);
                          setCanonicalCopiedMode('sheet');
                          triggerToast('Ficha técnica de la pieza copiada.');
                          setTimeout(() => setCanonicalCopiedMode(null), 2000);
                        }}
                        className="text-[11px] font-mono bg-[#181A20] hover:bg-[#252830] text-[#C9A050] border border-[#C9A050]/40 px-2.5 py-1 rounded-lg flex items-center space-x-1 transition-colors cursor-pointer"
                        title="Copiar Ficha Técnica completa"
                      >
                        {canonicalCopiedMode === 'sheet' ? <CheckCheck className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>Ficha</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          const text = formatGarmentDescription({
                            id: editingGarmentId || 'preview',
                            categoryId: selectedCat,
                            ...currentGarment
                          }, true);
                          navigator.clipboard.writeText(text);
                          setCanonicalCopiedMode('prompt');
                          triggerToast('Prompt canónico de IA copiado.');
                          setTimeout(() => setCanonicalCopiedMode(null), 2000);
                        }}
                        className="text-[11px] font-mono bg-[#181A20] hover:bg-[#252830] text-[#A0A0A0] hover:text-[#E0E0E0] border border-[#2A2D35] px-2.5 py-1 rounded-lg flex items-center space-x-1 transition-colors cursor-pointer"
                        title="Copiar Tokens de Prompt IA"
                      >
                        {canonicalCopiedMode === 'prompt' ? <CheckCheck className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>Prompt</span>
                      </button>
                    </div>
                  </div>

                  {/* Display bodies */}
                  <div className="space-y-3">
                    {(canonicalViewTab === 'both' || canonicalViewTab === 'sheet') && (
                      <div>
                        <div className="text-[10px] font-mono text-[#888888] uppercase tracking-wider mb-1 flex items-center justify-between">
                          <span>Ficha Técnica Canónica (Auditoría de Silueta, Corte, Material y Cobertura):</span>
                        </div>
                        <pre className="text-xs font-mono text-[#E0E0E0] bg-[#0A0C10] p-3.5 rounded-xl border border-[#22252E] whitespace-pre-wrap leading-relaxed max-h-48 overflow-y-auto select-all">
                          {formatGarmentDescription({
                            id: editingGarmentId || 'preview',
                            categoryId: selectedCat,
                            ...currentGarment
                          }, false)}
                        </pre>
                      </div>
                    )}

                    {(canonicalViewTab === 'both' || canonicalViewTab === 'prompt') && (
                      <div>
                        <div className="text-[10px] font-mono text-[#888888] uppercase tracking-wider mb-1">
                          Línea de Prompt IA Visual (Tokens Renderizados en Estado 7):
                        </div>
                        <div className="text-xs font-mono text-[#C9A050] bg-[#0A0C10] p-3 rounded-xl border border-[#22252E] leading-relaxed select-all">
                          {formatGarmentDescription({
                            id: editingGarmentId || 'preview',
                            categoryId: selectedCat,
                            ...currentGarment
                          }, true)}
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="text-[11px] text-[#888888] flex items-center space-x-1.5 pt-1 border-t border-[#1C1F26]">
                    <Eye className="w-3.5 h-3.5 text-[#C9A050]" />
                    <span>Esta redacción canónica exacta se sincronizará directamente en la Ficha Técnica y en el Prompt de IA del Estado 7.</span>
                  </div>
                </div>

                {/* Builder Action Buttons */}
                <div className="pt-2 flex flex-wrap items-center gap-3">
                  {editingGarmentId ? (
                    <>
                      <button
                        type="button"
                        onClick={handleSaveGarmentEdit}
                        className="bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] px-6 py-3 rounded-xl font-bold text-xs flex items-center space-x-2 transition-all shadow-md cursor-pointer"
                      >
                        <Check className="w-4 h-4" />
                        <span>Guardar Cambios en la Pieza</span>
                      </button>

                      <button
                        type="button"
                        onClick={handleCancelEdit}
                        className="bg-[#15171C] hover:bg-[#1f2229] border border-[#2A2D35] text-[#AAAAAA] hover:text-[#E0E0E0] px-4 py-3 rounded-xl font-semibold text-xs flex items-center space-x-1.5 transition-all cursor-pointer"
                      >
                        <X className="w-4 h-4" />
                        <span>Cancelar</span>
                      </button>

                      <button
                        type="button"
                        onClick={handleAddGarment}
                        className="bg-[#1A1C22] hover:bg-[#252830] border border-[#C9A050]/40 text-[#C9A050] hover:text-amber-200 px-4 py-3 rounded-xl font-semibold text-xs flex items-center space-x-1.5 transition-all cursor-pointer ml-auto"
                        title="Guarda como una nueva pieza en el conjunto sin sobreescribir la original"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        <span>Duplicar como Nueva</span>
                      </button>
                    </>
                  ) : (
                    <button
                      type="button"
                      onClick={handleAddGarment}
                      className="bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] px-5 py-3 rounded-xl font-bold text-xs flex items-center space-x-2 transition-all shadow-md cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                      <span>{isAccCat ? 'Añadir Accesorio al Atuendo' : 'Añadir Prenda al Atuendo'}</span>
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
          )}
        </div>

        {/* Right Col: Current Wardrobe List */}
        <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-lg font-serif italic text-[#C9A050]">Prendas & Accesorios ({state.wardrobes.length})</h3>
              <span className="text-[11px] font-mono text-[#888888] bg-[#15171C] px-2 py-0.5 rounded-lg border border-[#2A2D35]">
                {state.wardrobes.length} / 12 máx
              </span>
            </div>
            <p className="text-[11px] text-[#888888] mb-4">
              💡 Haz clic en <span className="text-[#C9A050] font-semibold">"Editar"</span> en cualquier pieza finalizada para modificarla directamente en el configurador.
            </p>

            {state.wardrobes.length === 0 ? (
              <div className="bg-[#15171C] border border-dashed border-[#2A2D35] rounded-xl p-6 text-center text-xs text-[#888888] space-y-2">
                <Shirt className="w-8 h-8 text-[#888888]/40 mx-auto" />
                <p>No hay prendas ni accesorios añadidos aún.</p>
                <p className="text-[11px] text-[#666666]">Configura una pieza a la izquierda y presiona "Añadir al Atuendo".</p>
              </div>
            ) : (
              <div className="space-y-4 max-h-[600px] overflow-y-auto pr-1">
                {state.wardrobes.map(g => {
                  const resolvedColor = resolveColorName(g.color);
                  const isAccessory = g.categoryId === 'B5';
                  const isDressOrTop = !g.categoryId || g.categoryId === 'B0' || g.categoryId === 'B1' || g.categoryId === 'B12' || g.categoryId === 'B12-A';
                  const isBeingEdited = editingGarmentId === g.id;
                  
                  return (
                    <div 
                      key={g.id} 
                      className={`rounded-xl p-4 text-xs space-y-2.5 transition-all ${
                        isBeingEdited 
                          ? 'bg-gradient-to-br from-[#241F14] to-[#15171C] border-2 border-[#C9A050] shadow-lg ring-2 ring-[#C9A050]/40' 
                          : 'bg-[#15171C] border border-[#2A2D35] hover:border-[#C9A050]/50'
                      }`}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-[#E0E0E0] text-sm">{g.name}</span>
                            {isBeingEdited && (
                              <span className="inline-flex items-center gap-1 text-[10px] font-mono font-bold text-[#0A0B0E] bg-[#C9A050] px-2 py-0.5 rounded shadow-xs animate-pulse">
                                <Edit3 className="w-3 h-3" />
                                <span>En Edición</span>
                              </span>
                            )}
                          </div>
                          <div className="flex items-center space-x-1 mt-1">
                            <span className="inline-block text-[10px] font-mono text-[#C9A050] bg-[#0F1115] px-2 py-0.5 rounded border border-[#C9A050]/30">
                              {g.layer || (isAccessory ? 'Accesorio' : 'Capa Base')}
                            </span>
                            {g.accessorySubcategory && (
                              <span className="inline-block text-[9px] font-mono text-[#888888] bg-[#0F1115] px-1.5 py-0.5 rounded border border-[#222222]">
                                {g.accessorySubcategory}
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Action buttons on piece card: Edit & Delete */}
                        <div className="flex items-center space-x-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => {
                              if (isBeingEdited) {
                                handleCancelEdit();
                              } else {
                                handleStartEditGarment(g);
                              }
                            }}
                            className={`px-2.5 py-1 rounded-lg font-mono text-[11px] font-semibold flex items-center space-x-1 transition-all cursor-pointer ${
                              isBeingEdited
                                ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                                : 'bg-[#0F1115] hover:bg-[#C9A050]/20 hover:text-amber-200 border border-[#2A2D35] hover:border-[#C9A050]/50 text-[#C9A050]'
                            }`}
                            title={isBeingEdited ? "Cancelar edición" : "Cargar y editar esta pieza en el configurador"}
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>{isBeingEdited ? 'Editando' : 'Editar'}</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleRemoveGarment(g.id)}
                            className="text-rose-400 hover:text-rose-300 p-1.5 rounded-lg hover:bg-rose-500/10 transition-all cursor-pointer"
                            title="Eliminar pieza"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Main Garment Attributes Pills */}
                      <div className="grid grid-cols-2 gap-1.5 text-[11px] text-[#A0A0A0]">
                        <div className="bg-[#0F1115] px-2 py-1 rounded border border-[#222222]">
                          <span className="text-[#888888]">Color: </span>
                          <span className="text-[#E0E0E0] font-medium">{resolvedColor}</span>
                        </div>
                        <div className="bg-[#0F1115] px-2 py-1 rounded border border-[#222222]">
                          <span className="text-[#888888]">Material: </span>
                          <span className="text-[#E0E0E0] font-medium">{g.material || 'Estándar'}</span>
                        </div>
                        {g.cut && (
                          <div className="bg-[#0F1115] px-2 py-1 rounded border border-[#222222]">
                            <span className="text-[#888888]">{isAccessory ? 'Estilo: ' : 'Corte: '}</span>
                            <span className="text-[#E0E0E0]">{g.cut}</span>
                          </div>
                        )}
                        {g.sizeScale && isAccessory && (
                          <div className="bg-[#0F1115] px-2 py-1 rounded border border-[#222222]">
                            <span className="text-[#888888]">Escala: </span>
                            <span className="text-[#E0E0E0]">{g.sizeScale}</span>
                          </div>
                        )}
                        {g.fitStyle && isAccessory && (
                          <div className="bg-[#0F1115] px-2 py-1 rounded border border-[#222222]">
                            <span className="text-[#888888]">Ajuste: </span>
                            <span className="text-[#E0E0E0]">{g.fitStyle}</span>
                          </div>
                        )}
                        {g.length && !isAccessory && (
                          <div className="bg-[#0F1115] px-2 py-1 rounded border border-[#222222]">
                            <span className="text-[#888888]">Largo: </span>
                            <span className="text-[#E0E0E0]">{g.length}</span>
                          </div>
                        )}
                        {g.sleeve && isDressOrTop && (
                          <div className="bg-[#0F1115] px-2 py-1 rounded border border-[#222222]">
                            <span className="text-[#888888]">Manga: </span>
                            <span className="text-[#E0E0E0]">{g.sleeve}</span>
                          </div>
                        )}
                        {g.neckline && isDressOrTop && (
                          <div className="bg-[#0F1115] px-2 py-1 rounded border border-[#222222]">
                            <span className="text-[#888888]">Cuello: </span>
                            <span className="text-[#E0E0E0]">{g.neckline}</span>
                          </div>
                        )}
                        {g.categoryId === 'B4' && g.soleType && (
                          <div className="bg-[#0F1115] px-2 py-1 rounded border border-[#222222]">
                            <span className="text-[#888888]">Suela: </span>
                            <span className="text-[#E0E0E0]">{g.soleType}</span>
                          </div>
                        )}
                        {g.categoryId === 'B4' && g.heelType && (
                          <div className="bg-[#0F1115] px-2 py-1 rounded border border-[#222222]">
                            <span className="text-[#888888]">Tacón: </span>
                            <span className="text-[#E0E0E0]">{g.heelType}</span>
                          </div>
                        )}
                        {g.categoryId !== 'B4' && g.wearStyle && (
                          <div className="bg-[#0F1115] px-2 py-1 rounded border border-[#222222]">
                            <span className="text-[#888888]">Porte: </span>
                            <span className="text-[#E0E0E0]">{g.wearStyle}</span>
                          </div>
                        )}
                      </div>

                      {/* Gem and Engraving for Accessories */}
                      {isAccessory && ((g.gemType && g.gemType !== 'Sin Gema / Metálico Puro') || (g.engraving && g.engraving !== 'Sin Grabado / Liso Pulido')) && (
                        <div className="pt-2 border-t border-[#222222] flex flex-wrap gap-1">
                          {g.gemType && g.gemType !== 'Sin Gema / Metálico Puro' && (
                            <span className="text-[10px] bg-emerald-950/40 text-emerald-300 border border-emerald-800/40 px-1.5 py-0.5 rounded">
                              💎 {g.gemType}{g.gemColor ? ` (${g.gemColor})` : ''}
                            </span>
                          )}
                          {g.engraving && g.engraving !== 'Sin Grabado / Liso Pulido' && (
                            <span className="text-[10px] bg-amber-950/40 text-amber-300 border border-amber-800/40 px-1.5 py-0.5 rounded">
                              📜 {g.engraving}
                            </span>
                          )}
                        </div>
                      )}

                      {/* Details with locations & colors */}
                      {g.details && g.details.length > 0 && !g.details.includes('Minimalista') && (
                        <div className="pt-2 border-t border-[#222222] space-y-1">
                          <span className="text-[10px] font-mono text-[#888888] block">Detalles y Posiciones:</span>
                          <div className="flex flex-wrap gap-1">
                            {g.details.map(d => {
                              const dColor = g.detailColors && g.detailColors[d] ? resolveColorName(g.detailColors[d]) : '';
                              const dLocs = g.detailLocations && g.detailLocations[d] ? g.detailLocations[d] : [];
                              return (
                                <span key={d} className="bg-[#0F1115] border border-[#2A2D35] text-[10px] px-1.5 py-0.5 rounded text-[#C9A050]">
                                  {d}{dColor ? ` (${dColor})` : ''}{dLocs.length > 0 ? ` @ ${dLocs.join(', ')}` : ''}
                                </span>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {/* Prints / Graphic Designs */}
                      {g.printTypes && g.printTypes.length > 0 && (
                        <div className="pt-2 border-t border-[#222222] space-y-1">
                          <span className="text-[10px] font-mono text-[#888888] block">Estampados y Diseños Gráficos:</span>
                          <div className="flex flex-wrap gap-1">
                            {g.printTypes.map(pType => {
                              const pShape = g.printShapes && g.printShapes[pType];
                              const pColor = g.printColors && g.printColors[pType];
                              const pLocs = g.printLocations && g.printLocations[pType] ? g.printLocations[pType] : [];
                              return (
                                <span key={pType} className="bg-[#0F1115] border border-[#C9A050]/40 text-[10px] px-1.5 py-0.5 rounded text-[#E0E0E0]">
                                  <span className="text-[#C9A050] font-semibold">{pType}</span>
                                  {pShape ? ` • ${pShape}` : ''}
                                  {pColor ? ` (${pColor})` : ''}
                                  {pLocs.length > 0 ? ` @ ${pLocs.join(', ')}` : ''}
                                </span>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {/* General Cobertura */}
                      {g.location && g.location.length > 0 && (
                        <div className="text-[10px] text-[#888888] font-mono">
                          <span>Cobertura: {g.location.join(', ')}</span>
                        </div>
                      )}

                      {/* Pattern, Emblem, VFX */}
                      {((g.pattern && g.pattern !== 'Liso / Sólido') || (g.emblem && g.emblem !== 'Ninguno') || (g.vfx && g.vfx !== 'Ninguno')) && (
                        <div className="flex flex-wrap gap-1 pt-1">
                          {g.pattern && g.pattern !== 'Liso / Sólido' && (
                            <span className="text-[10px] bg-purple-950/40 text-purple-300 border border-purple-800/40 px-1.5 py-0.5 rounded">
                              🎨 {g.pattern}{g.patternDetail ? ` (${g.patternDetail})` : ''}
                            </span>
                          )}
                          {g.emblem && g.emblem !== 'Ninguno' && (
                            <span className="text-[10px] bg-amber-950/40 text-amber-300 border border-amber-800/40 px-1.5 py-0.5 rounded">
                              ⚜️ {g.emblem}
                            </span>
                          )}
                          {g.vfx && g.vfx !== 'Ninguno' && (
                            <span className="text-[10px] bg-cyan-950/40 text-cyan-300 border border-cyan-800/40 px-1.5 py-0.5 rounded">
                              ✨ {g.vfx}
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="pt-6 border-t border-[#222222]">
            <p className="text-[11px] text-[#888888] mb-4">
              💡 Comando [99]: Puedes avanzar al siguiente estado en cualquier momento.
            </p>
          </div>
        </div>
      </div>

      {/* Navigation buttons */}
      <div className="mt-10 flex justify-between">
        <button
          onClick={onBack}
          className="bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] text-[#E0E0E0] px-6 py-3 rounded-xl font-semibold text-sm flex items-center space-x-2 transition-all cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Anterior</span>
        </button>

        <button
          onClick={onNext}
          className="bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] px-6 py-3 rounded-xl font-semibold text-sm flex items-center space-x-2 transition-all shadow-md cursor-pointer"
        >
          <span>Siguiente: Rol, Armadura & Equipo</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
