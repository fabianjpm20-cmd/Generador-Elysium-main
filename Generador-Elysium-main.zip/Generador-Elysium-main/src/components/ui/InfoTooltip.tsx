import React from 'react';
import { Info } from 'lucide-react';

export const InfoTooltip = ({ text }: { text: string }) => {
  return (
    <div className="group relative inline-flex items-center justify-center ml-1.5 align-middle">
      <Info className="w-3.5 h-3.5 text-[#888888] cursor-help hover:text-[#C9A050] transition-colors" />
      <div className="pointer-events-none absolute bottom-full left-1/2 z-50 mb-2 -translate-x-1/2 w-48 opacity-0 transition-opacity group-hover:opacity-100">
        <div className="bg-[#1A1C22] text-[#E0E0E0] text-[11px] leading-relaxed p-2.5 rounded-lg border border-[#2A2D35] shadow-lg text-center">
          {text}
        </div>
        {/* Triangle arrow */}
        <div className="w-2 h-2 bg-[#1A1C22] border-r border-b border-[#2A2D35] rotate-45 absolute left-1/2 -translate-x-1/2 -bottom-1"></div>
      </div>
    </div>
  );
};
