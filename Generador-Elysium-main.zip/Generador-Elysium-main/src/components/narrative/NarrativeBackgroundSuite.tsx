import React, { useState } from 'react';
import { CharacterState, NarrativeTimelineMilestone, CharacterNarrativeTimeline } from '../../types';
import {
  BookOpen,
  Sparkles,
  Shield,
  Heart,
  Globe,
  Flag,
  Clock,
  Milestone,
  Zap,
  Wand2,
  RefreshCw,
  Check,
  Plus,
  Trash2,
  Copy,
  ChevronDown,
  ChevronUp,
  Layers,
  Compass,
  Eye,
  AlertTriangle,
  Flame,
  Edit3,
  Sliders,
  FileText
} from 'lucide-react';
import { InfoTooltip } from '../ui/InfoTooltip';

interface NarrativeBackgroundSuiteProps {
  state: CharacterState;
  setState: React.Dispatch<React.SetStateAction<CharacterState>>;
}

const NARRATIVE_TONES = [
  { id: 'epico', label: 'Épico & Heroico', desc: 'Hazañas legendarias, superación de pruebas colosales y destino trascendental.' },
  { id: 'grimdark', label: 'Oscuro & Trágico (Grimdark)', desc: 'Pérdidas dolorosas, ambigüedad moral, cicatrices imborrables y supervivencia cruda.' },
  { id: 'mistico', label: 'Místico & Arcano', desc: 'Revelaciones esotéricas, susurros ancestrales, dones proféticos y misterios ocultos.' },
  { id: 'ciberpunk', label: 'Distópico / Tecnológico / Callejero', desc: 'Calles de neón, implantes clandestinos, megacorporaciones y rebeldía cibernética.' },
  { id: 'picaresco', label: 'Aventura Picaresca & Sagaz', desc: 'Astucia callejera, golpes de fortuna, ironía, escapes audaces y carisma indómito.' },
  { id: 'aristocratico', label: 'Cortesano & Intrigas Políticas', desc: 'Secretos de palacio, linajes nobles, juegos de poder, lealtades divididas y orgullo dinástico.' },
  { id: 'casual', label: 'Casual / Recuentos de la Vida', desc: 'Rutinas cotidianas, calidez, anécdotas hogareñas, amistades entrañables y sosiego.' },
  { id: 'romance', label: 'Romance & Pasión Afectiva', desc: 'Química emocional, anhelos del corazón, promesas compartidas, devoción y dilemas amorosos.' }
];

const SUGGESTED_HOMELANDS = [
  'Tierras Altas de Solaria',
  'Enclave Silvano de Arvandor',
  'Ducado Central de Valdor',
  'Bajíos y Canales de Puerto Negro',
  'Ciudadela Forjada de Karak',
  'Yermos Olvidados de Ceniza',
  'Baluarte Fronterizo del Norte',
  'Metrópolis Subterránea de Umbra',
  'Oasis de las Bestias de Arena / Tierras Altas del Tótem del Zorro',
  'Distrito Urbano / Barrio Comercial Neón',
  'Islas Flotantes de Aethelgard',
  'Valle Brumoso de los Cerezos Eternos',
  'Sector Cero: Complejo Industrial Megacorp'
];

const SUGGESTED_FACTIONS = [
  'Orden del Fénix Plateado',
  'Inquisición de la Llama Eterna',
  'Círculo Druídico de la Niebla',
  'Sindicato de Comerciantes Libres',
  'Pacto de las Sombras Arcanas',
  'Templo Solar del Cenit',
  'Hermandad de Mercenarios de Hierro',
  'Círculo Chamánico de los Danzantes Espirituales',
  'Gremio de Alquimistas de la Cripta',
  'Red Clandestina de Netrunners',
  'Caballeros de la Espada Quebrada',
  'Independiente / Sin Afiliación'
];

export const NarrativeBackgroundSuite: React.FC<NarrativeBackgroundSuiteProps> = ({ state, setState }) => {
  const [selectedTone, setSelectedTone] = useState('epico');
  const [userNotes, setUserNotes] = useState(state.background?.userNarrativeNotes || '');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generateError, setGenerateError] = useState<string | null>(null);
  const [copiedNotification, setCopiedNotification] = useState(false);
  const [showContextBreakdown, setShowContextBreakdown] = useState(false);
  const [newUniqueDetailInput, setNewUniqueDetailInput] = useState('');
  const [activeTab, setActiveTab] = useState<'sintesis' | 'cronologia' | 'detalles'>('sintesis');

  // Helper summaries of active character configuration
  const raceSummary = `${state.raceName || 'Humano'}${state.subRace ? ` (${state.subRace})` : ''}`;
  const roleSummary = `${state.role || 'Aventurero'}${state.subRole ? ` [${state.subRole}]` : ''}${state.nobleTitle ? ` - ${state.nobleTitle}` : ''}`;
  const visualSummary = `${state.styleVisual || 'Fantasía'}${state.subStyleVisual ? ` / ${state.subStyleVisual}` : ''}`;
  const traitsSummary = state.personalityTraits && state.personalityTraits.length > 0
    ? state.personalityTraits.join(', ')
    : (state.personality || 'Equilibrado');
  const fatalFlawSummary = (state.background?.fatalFlaws && state.background.fatalFlaws.length > 0)
    ? state.background.fatalFlaws.join('; ')
    : (state.background?.fatalFlawOrVulnerability || 'Sin debilidades declaradas');

  const wardrobeSummary = (state.wardrobes && state.wardrobes.length > 0)
    ? state.wardrobes.map(w => `${w.garmentName || 'Prenda'} (${w.primaryFabric || 'tela'} ${w.primaryColor || ''})`).join(', ')
    : 'Atuendo estándar adaptado a su cometido';

  const armorSummary = (state.armor && state.armor.type)
    ? `${state.armor.type} de ${state.armor.material || 'material forjado'} (${(state.armor.pieces || []).join(', ')})`
    : 'Sin armadura pesada visible';

  const weaponsSummary = (state.equipment && state.equipment.weapons && state.equipment.weapons.length > 0)
    ? state.equipment.weapons.join(', ')
    : 'Armas de uso personal';

  const physicalTraits = [
    state.hornsType && state.hornsType !== 'none' ? `Cornamenta: ${state.hornsType}` : null,
    state.wingsType && state.wingsType !== 'none' ? `Alas: ${state.wingsType}` : null,
    state.tailsType && state.tailsType !== 'none' ? `Colas: ${state.tailsType}` : null,
    state.skinAndMarks ? `Piel/Marcas: ${state.skinAndMarks}` : null,
    state.clawsType && state.clawsType !== 'none' ? `Garras: ${state.clawsType}` : null,
    state.specialLimbs ? `Extremidades: ${state.specialLimbs}` : null
  ].filter(Boolean).join(', ') || 'Anatomía humana convencional';

  // Handle user notes update
  const handleUserNotesChange = (val: string) => {
    setUserNotes(val);
    setState(prev => ({
      ...prev,
      background: {
        ...prev.background,
        userNarrativeNotes: val
      }
    }));
  };

  // Unified AI Generation
  const handleUnifiedGenerate = async () => {
    setIsGenerating(true);
    setGenerateError(null);
    try {
      const payload = {
        name: state.name,
        gender: state.gender,
        age: state.age,
        raceName: state.raceName,
        subRace: state.subRace,
        role: state.role,
        subRole: state.subRole,
        hybridRoleTitle: state.hybridRoleTitle,
        nobleTitle: state.nobleTitle,
        archetype: state.archetype,
        personalityTraits: state.personalityTraits,
        coreValues: state.background?.coreValues,
        styleVisual: state.styleVisual,
        homelandOrDomain: state.background?.homelandOrDomain,
        factionOrFaith: state.background?.factionOrFaith,
        fatalFlaws: state.background?.fatalFlaws || (state.background?.fatalFlawOrVulnerability ? [state.background.fatalFlawOrVulnerability] : []),
        physicalDetails: physicalTraits,
        wardrobeSummary,
        equipmentSummary: weaponsSummary,
        userNotes: userNotes.trim(),
        narrativeTone: NARRATIVE_TONES.find(t => t.id === selectedTone)?.label || 'Épico & Heroico'
      };

      const res = await fetch('/api/generate-backstory', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        throw new Error(`Error en el servidor: ${res.statusText}`);
      }

      const data = await res.json();

      setState(prev => ({
        ...prev,
        name: prev.name.trim() ? prev.name : (data.name || prev.name),
        background: {
          ...prev.background,
          homelandOrDomain: data.homelandOrDomain || prev.background?.homelandOrDomain,
          factionOrFaith: data.factionOrFaith || prev.background?.factionOrFaith,
          backstory: data.backstory || prev.background?.backstory,
          motivation: data.motivation || prev.background?.motivation,
          secret: data.secret || prev.background?.secret,
          uniqueDetails: (data.uniqueDetails && Array.isArray(data.uniqueDetails) && data.uniqueDetails.length > 0)
            ? data.uniqueDetails
            : prev.background?.uniqueDetails,
          userNarrativeNotes: userNotes,
          narrativeTimeline: data.timeline ? {
            overview: data.timeline.overview || 'Línea temporal consolidada por el motor narrativo.',
            thematicArc: data.timeline.thematicArc || 'Arco dramático del personaje.',
            pivotalTurningPoints: data.timeline.pivotalTurningPoints || [],
            milestones: (data.timeline.milestones || []).map((m: any, idx: number) => ({
              id: m.id || `m-${Date.now()}-${idx}`,
              era: m.era || 'Pasado',
              title: m.title || `Hito ${idx + 1}`,
              periodOrAge: m.periodOrAge || 'Período no determinado',
              summary: m.summary || '',
              keyEvents: m.keyEvents || [],
              psychologicalEvolution: m.psychologicalEvolution || ''
            })),
            generatedAt: new Date().toISOString()
          } : prev.background?.narrativeTimeline
        },
        narrativeTimeline: data.timeline ? {
          overview: data.timeline.overview || 'Línea temporal consolidada.',
          thematicArc: data.timeline.thematicArc || 'Arco dramático.',
          pivotalTurningPoints: data.timeline.pivotalTurningPoints || [],
          milestones: (data.timeline.milestones || []).map((m: any, idx: number) => ({
            id: m.id || `m-${Date.now()}-${idx}`,
            era: m.era || 'Pasado',
            title: m.title || `Hito ${idx + 1}`,
            periodOrAge: m.periodOrAge || 'Período no determinado',
            summary: m.summary || '',
            keyEvents: m.keyEvents || [],
            psychologicalEvolution: m.psychologicalEvolution || ''
          })),
          generatedAt: new Date().toISOString()
        } : prev.narrativeTimeline
      }));
    } catch (err: any) {
      console.warn("Fallo API IA, ejecutando síntesis local algorítmica:", err);
      setGenerateError(err.message || 'Error al conectar con la IA. Se aplicó la síntesis local algorítmica.');
      handleLocalSynthesis();
    } finally {
      setIsGenerating(false);
    }
  };

  // Local Algorithmic Synthesis (Instant, Offline)
  const handleLocalSynthesis = () => {
    const charName = state.name.trim() || 'Aeloria';
    const domain = state.background?.homelandOrDomain || SUGGESTED_HOMELANDS[Math.floor(Math.random() * SUGGESTED_HOMELANDS.length)];
    const faction = state.background?.factionOrFaith || SUGGESTED_FACTIONS[Math.floor(Math.random() * SUGGESTED_FACTIONS.length)];
    const toneObj = NARRATIVE_TONES.find(t => t.id === selectedTone) || NARRATIVE_TONES[0];
    const core = state.background?.coreValues || 'Honor';
    const notesAddition = userNotes.trim() ? ` En sus memorias personales resalta: "${userNotes.trim()}".` : '';

    let backstoryGenerated = `En los confines de ${domain}, la historia de ${charName} comenzó bajo la influencia de ${visualSummary}. Siendo de linaje ${raceSummary} y manifestando aptitudes naturales como ${roleSummary}, su carácter fue forjado entre los valores de ${core} y rasgos distintivos de [${traitsSummary}].\n\nEl camino que lo/la condujo a vincular su destino con ${faction} estuvo marcado por pruebas decisivas. El atuendo que hoy le identifica (${wardrobeSummary}) y la fiereza de su armamento (${weaponsSummary}) son recordatorios palpables de juramentos que no pueden quebrantarse.${notesAddition}\n\nActualmente, bajo el tono de ${toneObj.label.toLowerCase()}, ${charName} encarna el arquetipo de ${state.archetype || 'Aventurero/a Legendario/a'}, manteniendo siempre a raya su vulnerabilidad ante ${fatalFlawSummary}.`;

    let motivationGenerated = `Honrar los principios de ${core}, defender el legado de ${domain} y culminar la misión encomendada por ${faction}, desafiando cualquier adversidad que amenace su libertad.`;

    let secretGenerated = `Custodia un fragmento de verdad sobre ${domain} que de revelarse, desataría una guerra frontal con los mandatarios de ${faction}.`;

    let uniqueDetailsGenerated = [
      `Porta una marca o distintivo ceremonial forjado en ${domain} que jamás abandona su regazo.`,
      `Sus rasgos físicos (${physicalTraits}) provocan respeto reverencial o recelo instintivo entre los clanes rivales.`,
      `Ha hecho el juramento de no desenvainar su arsenal (${weaponsSummary}) si no es para defender un inocente o sellar un destino ineludible.`,
      `Tiene por hábito examinar los accesos y sombras antes de tomar asiento en cualquier taberna o consejo.`
    ];

    if (selectedTone === 'casual') {
      backstoryGenerated = `En el apacible entorno de ${domain}, la vida de ${charName} transcurre al compás de la cotidianeidad y el aprendizaje constante. Siendo de estirpe ${raceSummary} y desempeñando su vocación como ${roleSummary}, ha sabido conjugar sus obligaciones con un aprecio sincero por la calma, el compañerismo y las pequeñas rutinas hogareñas.\n\nAunque mantiene vínculos de respeto con ${faction}, prefiere la calidez de un hogar seguro y la compañía sincera antes que las grandilocuencias bélicas. Su atuendo habitual (${wardrobeSummary}) refleja comodidad y practicidad, mientras que su equipo (${weaponsSummary}) se mantiene como resguardo preventivo y herramienta de oficio.${notesAddition}\n\nCon una personalidad forjada en [${traitsSummary}] y guiado/a por el valor de ${core}, encuentra su mayor plenitud compartiendo momentos sencillos con las personas que aprecia, procurando mantener bajo control su debilidad ante ${fatalFlawSummary}.`;
      motivationGenerated = `Proteger la paz de su hogar en ${domain}, disfrutar de los pequeños instantes cotidianos y garantizar el bienestar de sus seres queridos sin verse arrastrado/a a conflictos innecesarios.`;
      secretGenerated = `Oculta una afición o anhelo personal sumamente sencillo (como abrir una modesta tienda o taller artesanal en ${domain}) que teme sea considerado poco ambicioso por los más severos miembros de ${faction}.`;
      uniqueDetailsGenerated = [
        `Guarda celosamente un recetario tradicional o recuerdo de la infancia originario de ${domain}.`,
        `Tiene la costumbre de preparar una infusión aromática reconfortante al amanecer antes de iniciar sus labores como ${roleSummary}.`,
        `Su vestimenta (${wardrobeSummary}) lleva pequeñas costuras o arreglos hechos a mano con cariño personal.`,
        `Suele distraerse observando las nubes o alimentando a los animales callejeros durante sus caminatas diarias.`
      ];
    } else if (selectedTone === 'romance') {
      backstoryGenerated = `En los paisajes cargados de promesas de ${domain}, el corazón de ${charName} aprendió a latir con una intensidad que desafía cualquier dogma establecido. Perteneciente al linaje ${raceSummary} y ejerciendo como ${roleSummary}, su historia dio un vuelco definitivo el día en que un vínculo afectivo profundo redefinió todas sus prioridades vitales.\n\nSu lealtad hacia ${faction} se ve constantemente confrontada por la pasión y los anhelos del alma. La indumentaria que viste (${wardrobeSummary}) y las armas que porta (${weaponsSummary}) ya no son meros instrumentos de deber, sino baluartes para salvaguardar a quien más ama en este mundo.${notesAddition}\n\nGuiado/a por ${core} y rasgos pasionales de [${traitsSummary}], su viaje es tanto una búsqueda de realización afectiva como un desafío al destino, siempre vulnerable a los temores que le susurra ${fatalFlawSummary}.`;
      motivationGenerated = `Proteger con su vida a la persona que ama, derribar las barreras impuestas por ${faction} y forjar un futuro compartido donde el amor no deba esconderse en las sombras.`;
      secretGenerated = `Mantiene una promesa o romance secreto sellado bajo las estrellas que, de salir a la luz, pondría en jaque su posición ante ${faction} y los suyos en ${domain}.`;
      uniqueDetailsGenerated = [
        `Lleva junto a su pecho un colgante o listón con un mensaje cifrado que solo su ser amado sabe interpretar.`,
        `Una suave sonrisa inconsciente ilumina su semblante cada vez que alguien menciona ciertas tonadas o rincones de ${domain}.`,
        `Ha prometido que su arma predilecta jamás causará daño a ningún allegado de su amado/a.`,
        `Guarda notas y cartas cuidadosamente dobladas en el forro interno de su atuendo (${wardrobeSummary}).`
      ];
    }

    let timelineMilestones: NarrativeTimelineMilestone[] = [
      {
        id: `local-m1-${Date.now()}`,
        era: 'Pasado',
        title: `Nacimiento y Raíces en ${domain}`,
        periodOrAge: 'Infancia',
        summary: `Primeros años de aprendizaje de las tradiciones de ${raceSummary}, asimilando el valor de ${core}.`,
        keyEvents: ['Despertar de habilidades tempranas', 'Primer rito de paso'],
        psychologicalEvolution: `Desarrolló una lealtad profunda y la base de sus convicciones éticas.`
      },
      {
        id: `local-m2-${Date.now()}`,
        era: 'Pasado',
        title: `Pacto y Consagración en ${faction}`,
        periodOrAge: 'Juventud / Punto de Quiebre',
        summary: `Un acontecimiento trascendental impulsó a ${charName} a consagrarse como ${roleSummary}, asumiendo su uniforme y armas de combate.`,
        keyEvents: ['Juramento formal de iniciación', 'Adquisición de equipo distintivo'],
        psychologicalEvolution: `Madurez forzada ante la realidad del mundo y fijación de su motivación primordial.`
      },
      {
        id: `local-m3-${Date.now()}`,
        era: 'Presente',
        title: 'Caminante de Leyenda',
        periodOrAge: 'Presente Activo',
        summary: `Ejerce su vocación desafiando a las sombras que amenazan ${domain}, forjando una reputación temida y respetada.`,
        keyEvents: ['Consolidación de alianzas estratégicas', 'Defensa de inocentes'],
        psychologicalEvolution: `Determinación serena; vigilancia constante sobre sus puntos ciegos.`
      },
      {
        id: `local-m4-${Date.now()}`,
        era: 'Futuro',
        title: 'La Encrucijada Inevitable',
        periodOrAge: 'Horizonte / Destino',
        summary: `Una confrontación predicha pondrá a prueba su fidelidad entre los lazos de sangre y los dogmas de ${faction}.`,
        keyEvents: ['El juicio final de sus ideales'],
        psychologicalEvolution: `Trascendencia o metamorfosis final de su destino.`
      }
    ];

    if (selectedTone === 'casual') {
      timelineMilestones = [
        {
          id: `local-m1-${Date.now()}`,
          era: 'Pasado',
          title: `Primeros Recuerdos en ${domain}`,
          periodOrAge: 'Infancia',
          summary: `Una niñez serena aprendiendo las costumbres de los ${raceSummary} y la importancia del valor de ${core}.`,
          keyEvents: ['Juegos de infancia y primeras amistades', 'Descubrimiento de pequeñas pasiones cotidianas'],
          psychologicalEvolution: 'Cultivó un espíritu empático y apego a la vida pacífica.'
        },
        {
          id: `local-m2-${Date.now()}`,
          era: 'Pasado',
          title: `Iniciación y Rutinas en ${faction}`,
          periodOrAge: 'Juventud / Primeros Oficios',
          summary: `Adoptó su vocación de ${roleSummary}, aprendiendo a balancear sus responsabilidades con su vida diaria.`,
          keyEvents: ['Adquisición de su primer atuendo de oficio', 'Un día memorable entre compañeros'],
          psychologicalEvolution: 'Madurez basada en el compañerismo y el valor de la constancia.'
        },
        {
          id: `local-m3-${Date.now()}`,
          era: 'Presente',
          title: 'Vida en Armonía Cotidiana',
          periodOrAge: 'Presente Activo',
          summary: `Resuelve los pequeños y grandes dilemas de su comunidad, disfrutando de los instantes de sosiego con los suyos.`,
          keyEvents: ['Reuniones habituales con allegados', 'Mantenimiento de su hogar y herramientas'],
          psychologicalEvolution: 'Serenidad interior y disfrute sincero del presente.'
        },
        {
          id: `local-m4-${Date.now()}`,
          era: 'Futuro',
          title: 'Un Porvenir Cálido y Duradero',
          periodOrAge: 'Horizonte / Madurez',
          summary: `El anhelo de asentarse en un rincón tranquilo de ${domain}, rodeado de memorias gratas y afectos inquebrantables.`,
          keyEvents: ['Traspaso de enseñanzas a una nueva generación'],
          psychologicalEvolution: 'Paz espiritual absoluta y legado entrañable.'
        }
      ];
    } else if (selectedTone === 'romance') {
      timelineMilestones = [
        {
          id: `local-m1-${Date.now()}`,
          era: 'Pasado',
          title: `Raíces y Primeros Despertares en ${domain}`,
          periodOrAge: 'Juventud Temprana',
          summary: `Crecimiento en el seno de ${raceSummary}, forjando ideales de lealtad y el valor de ${core}.`,
          keyEvents: ['Despertar de sentimientos profundos', 'Primeras ilusiones del corazón'],
          psychologicalEvolution: 'Sensibilidad emocional ante la belleza y la fragilidad humana.'
        },
        {
          id: `local-m2-${Date.now()}`,
          era: 'Pasado',
          title: 'El Encuentro que Transformó Todo',
          periodOrAge: 'Juventud / El Encuentro',
          summary: `El instante fortuito en que conoció a la persona que trastocaría su vida y pondría a prueba sus votos con ${faction}.`,
          keyEvents: ['El primer cruce de miradas o palabras', 'La promesa sellada en secreto'],
          psychologicalEvolution: 'Descubrimiento de un propósito superior a cualquier deber ciego.'
        },
        {
          id: `local-m3-${Date.now()}`,
          era: 'Presente',
          title: 'La Lucha por un Amor Trascendente',
          periodOrAge: 'Presente Activo',
          summary: `Navega entre sus responsabilidades como ${roleSummary} y la devoción incansable por salvaguardar su unión afectiva.`,
          keyEvents: ['Encuentros clandestinos o correspondencia secreta', 'Superación de un obstáculo conjunto'],
          psychologicalEvolution: 'Valentía nacida del amor y fidelidad incondicional.'
        },
        {
          id: `local-m4-${Date.now()}`,
          era: 'Futuro',
          title: 'El Triunfo del Corazón',
          periodOrAge: 'Horizonte / Destino',
          summary: `La culminación de sus anhelos: un pacto eterno donde puedan vivir en libertad y paz compartida.`,
          keyEvents: ['Unión definitiva o vida compartida en un nuevo amanecer'],
          psychologicalEvolution: 'Plenitud amorosa y serenidad compartida.'
        }
      ];
    }

    const timelineObj: CharacterNarrativeTimeline = {
      overview: `Trayectoria vital de ${charName}, desde los horizontes de ${domain} hasta su presente como ${roleSummary} en ${faction}.`,
      thematicArc: `La forja de la soberanía individual y el deber hacia ${core}.`,
      pivotalTurningPoints: [`El juramento ante ${faction}`, `La supervivencia en ${domain}`],
      milestones: timelineMilestones,
      generatedAt: new Date().toISOString()
    };

    setState(prev => ({
      ...prev,
      name: prev.name.trim() ? prev.name : charName,
      background: {
        ...prev.background,
        homelandOrDomain: domain,
        factionOrFaith: faction,
        backstory: backstoryGenerated,
        motivation: motivationGenerated,
        secret: secretGenerated,
        uniqueDetails: uniqueDetailsGenerated,
        userNarrativeNotes: userNotes,
        narrativeTimeline: timelineObj
      },
      narrativeTimeline: timelineObj
    }));
  };

  // Add unique detail
  const handleAddUniqueDetail = () => {
    if (!newUniqueDetailInput.trim()) return;
    const current = state.background?.uniqueDetails || [];
    setState(prev => ({
      ...prev,
      background: {
        ...prev.background,
        uniqueDetails: [...current, newUniqueDetailInput.trim()]
      }
    }));
    setNewUniqueDetailInput('');
  };

  const handleRemoveUniqueDetail = (idx: number) => {
    const current = state.background?.uniqueDetails || [];
    setState(prev => ({
      ...prev,
      background: {
        ...prev.background,
        uniqueDetails: current.filter((_, i) => i !== idx)
      }
    }));
  };

  // Copy full narrative sheet to clipboard
  const handleCopyNarrativeSheet = () => {
    const bg = state.background;
    const timeline = bg?.narrativeTimeline || state.narrativeTimeline;

    const sections = [
      `=== TRASFONDO NARRATIVO Y LÍNEA TEMPORAL: ${state.name || 'Sin Nombre'} ===`,
      `• Tierra Natal / Dominio Territorial: ${bg?.homelandOrDomain || 'No especificado'}`,
      `• Facción, Gremio o Fe Devocional: ${bg?.factionOrFaith || 'No especificado'}`,
      `• Tono Narrativo Predilecto: ${NARRATIVE_TONES.find(t => t.id === selectedTone)?.label || 'Épico'}`,
      '',
      `[HISTORIA DE ORIGEN (5.2)]`,
      bg?.backstory || 'Sin historia redactada.',
      '',
      `[MOTIVACIÓN PRINCIPAL (5.3)]`,
      bg?.motivation || 'Sin motivación declarada.',
      '',
      `[SECRETO O CARGA OCULTA]`,
      bg?.secret || 'Ninguno conocido.',
      '',
      `[DETALLES ÚNICOS & PECULIARIDADES]`,
      (bg?.uniqueDetails && bg.uniqueDetails.length > 0)
        ? bg.uniqueDetails.map((d, i) => `${i + 1}. ${d}`).join('\n')
        : 'Sin peculiaridades registradas.',
      ''
    ];

    if (timeline && timeline.milestones && timeline.milestones.length > 0) {
      sections.push(
        `[CRONOLOGÍA Y LÍNEA TEMPORAL NARRATIVA]`,
        `Visión General: ${timeline.overview}`,
        `Arco Temático: ${timeline.thematicArc}`,
        '',
        ...timeline.milestones.map(m => `• [${m.era.toUpperCase()}] ${m.periodOrAge} - ${m.title}:\n  ${m.summary}\n  Impacto: ${m.psychologicalEvolution}`)
      );
    }

    navigator.clipboard.writeText(sections.join('\n'));
    setCopiedNotification(true);
    setTimeout(() => setCopiedNotification(false), 2500);
  };

  const timeline = state.background?.narrativeTimeline || state.narrativeTimeline;

  return (
    <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-sm space-y-6">
      {/* Header & Suite Title */}
      <div className="flex items-center justify-between border-b border-[#222222] pb-4 flex-wrap gap-3">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-[#C9A050]/15 border border-[#C9A050]/40 flex items-center justify-center text-[#C9A050]">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xl font-serif italic text-[#C9A050]">
                5.2 Herramienta Unificada de Trasfondo Narrativo
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-[#C9A050]/20 text-[#C9A050] border border-[#C9A050]/40 font-semibold">
                Suite Integral
              </span>
            </div>
            <p className="text-xs text-[#888888]">
              Síntesis coherente de origen, dominio territorial, facción/fe, historia, motivación, hitos cronológicos y singularidades únicas.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleCopyNarrativeSheet}
            className="px-3 py-1.5 rounded-xl bg-[#15171C] border border-[#2A2D35] hover:border-[#C9A050] text-[#E0E0E0] hover:text-[#C9A050] text-xs font-mono transition-all flex items-center gap-1.5 cursor-pointer"
            title="Copiar Hoja de Trasfondo al Portapapeles"
          >
            {copiedNotification ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedNotification ? 'Copiado' : 'Copiar Hoja'}</span>
          </button>
        </div>
      </div>

      {/* Context Analysis Badge Strip */}
      <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-3.5 space-y-2.5">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2 text-xs font-mono text-[#C9A050]">
            <Zap className="w-3.5 h-3.5" />
            <span className="font-bold uppercase tracking-wider">Atributos Activos Analizados por el Motor:</span>
          </div>
          <button
            type="button"
            onClick={() => setShowContextBreakdown(!showContextBreakdown)}
            className="text-[11px] font-mono text-[#888888] hover:text-[#C9A050] flex items-center gap-1 cursor-pointer transition-colors"
          >
            <span>{showContextBreakdown ? 'Ocultar Desglose' : 'Ver Parámetros Analizados'}</span>
            {showContextBreakdown ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>

        {/* Badges */}
        <div className="flex flex-wrap gap-1.5 text-[11px] font-mono">
          <span className="px-2 py-0.5 rounded-md bg-[#1A1C22] border border-[#333] text-zinc-300">
            <span className="text-[#C9A050] font-semibold">Raza:</span> {raceSummary}
          </span>
          <span className="px-2 py-0.5 rounded-md bg-[#1A1C22] border border-[#333] text-zinc-300">
            <span className="text-[#C9A050] font-semibold">Rol:</span> {roleSummary}
          </span>
          <span className="px-2 py-0.5 rounded-md bg-[#1A1C22] border border-[#333] text-zinc-300">
            <span className="text-[#C9A050] font-semibold">Estilo:</span> {visualSummary}
          </span>
          <span className="px-2 py-0.5 rounded-md bg-[#1A1C22] border border-[#333] text-zinc-300">
            <span className="text-[#C9A050] font-semibold">Arquetipo:</span> {state.archetype || 'Genérico'}
          </span>
          <span className="px-2 py-0.5 rounded-md bg-[#1A1C22] border border-[#333] text-zinc-300">
            <span className="text-[#C9A050] font-semibold">Valores:</span> {state.background?.coreValues || 'Honor'}
          </span>
          {fatalFlawSummary !== 'Sin debilidades declaradas' && (
            <span className="px-2 py-0.5 rounded-md bg-amber-950/30 border border-amber-800/40 text-amber-300">
              <span className="text-amber-400 font-semibold">Talón de Aquiles:</span> {fatalFlawSummary}
            </span>
          )}
        </div>

        {/* Collapsible Deep Context Breakdown */}
        {showContextBreakdown && (
          <div className="pt-2 border-t border-[#222222] grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px] font-mono text-[#AAAAAA] bg-[#0F1115] p-3 rounded-lg">
            <div>
              <span className="text-[#C9A050] font-semibold">Anatomía y Rasgos Físicos:</span> {physicalTraits}
            </div>
            <div>
              <span className="text-[#C9A050] font-semibold">Indumentaria Activa:</span> {wardrobeSummary}
            </div>
            <div>
              <span className="text-[#C9A050] font-semibold">Armadura & Acabado:</span> {armorSummary}
            </div>
            <div>
              <span className="text-[#C9A050] font-semibold">Armamento y Equipo:</span> {weaponsSummary}
            </div>
          </div>
        )}
      </div>

      {/* Control Panel: User Notes, Tone & Generator Actions */}
      <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <label className="text-xs font-mono font-bold text-[#C9A050] uppercase flex items-center gap-2">
            <Sliders className="w-4 h-4" />
            <span>Dirección Creativa, Premisas del Usuario & Tono Narrativo</span>
          </label>
          <InfoTooltip text="Escribe premisas concretas o secretos que desees que el motor teja dentro de la historia, orígenes territoriales, motivación y línea temporal." />
        </div>

        {/* User Notes Input */}
        <div>
          <label className="block text-[11px] font-mono text-[#888888] mb-1.5">
            Detalles adicionales o premisas específicas escritas por el usuario (opcional):
          </label>
          <textarea
            rows={2}
            value={userNotes}
            onChange={(e) => handleUserNotesChange(e.target.value)}
            placeholder="Ej: Proviene de un clan caído que fue traicionado durante el solsticio; busca rescatar a su hermana prisionera; tiene una espada oxidada que perteneció a su mentor..."
            className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-3 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050] transition-colors resize-y leading-relaxed"
          />
        </div>

        {/* Tone Selector */}
        <div>
          <label className="block text-[11px] font-mono text-[#888888] mb-1.5">
            Tono Narrativo Predilecto:
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
            {NARRATIVE_TONES.map(tone => {
              const isSelected = selectedTone === tone.id;
              return (
                <button
                  key={tone.id}
                  type="button"
                  onClick={() => setSelectedTone(tone.id)}
                  className={`p-2 rounded-xl text-left border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#C9A050]/15 border-[#C9A050] text-[#E0E0E0] shadow-xs'
                      : 'bg-[#0F1115] border-[#2A2D35] text-[#888888] hover:border-[#C9A050]/50 hover:text-zinc-300'
                  }`}
                >
                  <div className="text-xs font-semibold flex items-center justify-between">
                    <span className={isSelected ? 'text-[#C9A050]' : ''}>{tone.label}</span>
                    {isSelected && <Check className="w-3.5 h-3.5 text-[#C9A050]" />}
                  </div>
                  <p className="text-[10px] text-[#777777] line-clamp-1 mt-0.5">
                    {tone.desc}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Generator Buttons */}
        <div className="flex flex-wrap gap-2.5 pt-2 border-t border-[#222222]">
          <button
            type="button"
            onClick={handleUnifiedGenerate}
            disabled={isGenerating}
            className="bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] px-4 py-2 rounded-xl font-bold text-xs flex items-center space-x-2 transition-all shadow-md cursor-pointer disabled:opacity-50"
          >
            <Sparkles className={`w-3.5 h-3.5 ${isGenerating ? 'animate-spin' : ''}`} />
            <span>{isGenerating ? 'Tejiendo Trasfondo & Cronología IA...' : '✨ Generar Trasfondo Completo Coherente (IA & Motor)'}</span>
          </button>

          <button
            type="button"
            onClick={handleLocalSynthesis}
            disabled={isGenerating}
            className="bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050] text-[#C9A050] hover:bg-[#C9A050]/10 px-3.5 py-2 rounded-xl font-medium text-xs flex items-center space-x-1.5 transition-all cursor-pointer"
          >
            <Wand2 className="w-3.5 h-3.5" />
            <span>🎲 Síntesis Local Rápida (Offline)</span>
          </button>
        </div>

        {generateError && (
          <div className="text-xs text-amber-300 bg-amber-950/25 border border-amber-800/40 p-2.5 rounded-lg">
            {generateError}
          </div>
        )}
      </div>

      {/* Tabs Navigation for Internal Suite Views */}
      <div className="flex border-b border-[#222222] gap-1">
        <button
          type="button"
          onClick={() => setActiveTab('sintesis')}
          className={`px-4 py-2.5 text-xs font-mono font-bold transition-all border-b-2 cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'sintesis'
              ? 'border-[#C9A050] text-[#C9A050]'
              : 'border-transparent text-[#888888] hover:text-[#E0E0E0]'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5" />
          <span>Trasfondo, Origen & Motivación</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('cronologia')}
          className={`px-4 py-2.5 text-xs font-mono font-bold transition-all border-b-2 cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'cronologia'
              ? 'border-[#C9A050] text-[#C9A050]'
              : 'border-transparent text-[#888888] hover:text-[#E0E0E0]'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span>Línea Temporal ({timeline?.milestones?.length || 0} Hitos)</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('detalles')}
          className={`px-4 py-2.5 text-xs font-mono font-bold transition-all border-b-2 cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'detalles'
              ? 'border-[#C9A050] text-[#C9A050]'
              : 'border-transparent text-[#888888] hover:text-[#E0E0E0]'
          }`}
        >
          <Milestone className="w-3.5 h-3.5" />
          <span>Detalles Únicos & Singularidades ({state.background?.uniqueDetails?.length || 0})</span>
        </button>
      </div>

      {/* TAB 1: SÍNTESIS, GEOPOLÍTICA, HISTORIA & MOTIVACIÓN */}
      {activeTab === 'sintesis' && (
        <div className="space-y-6">
          {/* Módulo A: Geopolítica & Fe (Tierra Natal & Facción) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Tierra Natal / Dominio Territorial */}
            <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-4 space-y-2.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-mono font-bold text-[#C9A050] uppercase flex items-center gap-1.5">
                  <Globe className="w-3.5 h-3.5" />
                  <span>Tierra Natal / Dominio Territorial</span>
                </label>
                <InfoTooltip text="Reino, enclave silvano, ciudadela o dominio de origen. Condiciona su herencia cultural, estética y lazos con su tierra." />
              </div>
              <input
                type="text"
                value={state.background?.homelandOrDomain || ''}
                onChange={(e) => setState(p => ({
                  ...p,
                  background: { ...p.background, homelandOrDomain: e.target.value }
                }))}
                placeholder="Ej: Tierras Altas de Solaria, Enclave de Arvandor, Bajíos de Puerto Negro..."
                className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl px-3 py-2 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050] transition-colors"
              />
              <div className="space-y-1">
                <span className="text-[10px] font-mono text-[#666666]">Sugerencias de Dominios:</span>
                <div className="flex flex-wrap gap-1 max-h-24 overflow-y-auto">
                  {SUGGESTED_HOMELANDS.map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setState(p => ({
                        ...p,
                        background: { ...p.background, homelandOrDomain: preset }
                      }))}
                      className={`px-2 py-0.5 rounded text-[10px] font-mono transition-all cursor-pointer ${
                        state.background?.homelandOrDomain === preset
                          ? 'bg-[#C9A050] text-[#0A0B0E] font-semibold'
                          : 'bg-[#0F1115] border border-[#2A2D35] text-[#AAAAAA] hover:text-[#C9A050] hover:border-[#C9A050]/50'
                      }`}
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Facción, Gremio o Fe Devocional */}
            <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-4 space-y-2.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-mono font-bold text-[#C9A050] uppercase flex items-center gap-1.5">
                  <Flag className="w-3.5 h-3.5" />
                  <span>Facción, Gremio o Fe Devocional</span>
                </label>
                <InfoTooltip text="Organización, orden caballeresca, culto o sindicato al que debe lealtad, obediencia o rebeldía." />
              </div>
              <input
                type="text"
                value={state.background?.factionOrFaith || ''}
                onChange={(e) => setState(p => ({
                  ...p,
                  background: { ...p.background, factionOrFaith: e.target.value }
                }))}
                placeholder="Ej: Orden del Fénix Plateado, Círculo Chamánico, Pacto de las Sombras..."
                className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl px-3 py-2 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050] transition-colors"
              />
              <div className="space-y-1">
                <span className="text-[10px] font-mono text-[#666666]">Sugerencias de Facciones:</span>
                <div className="flex flex-wrap gap-1 max-h-24 overflow-y-auto">
                  {SUGGESTED_FACTIONS.map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setState(p => ({
                        ...p,
                        background: { ...p.background, factionOrFaith: preset }
                      }))}
                      className={`px-2 py-0.5 rounded text-[10px] font-mono transition-all cursor-pointer ${
                        state.background?.factionOrFaith === preset
                          ? 'bg-[#C9A050] text-[#0A0B0E] font-semibold'
                          : 'bg-[#0F1115] border border-[#2A2D35] text-[#AAAAAA] hover:text-[#C9A050] hover:border-[#C9A050]/50'
                      }`}
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Módulo B: Historia de Origen (5.2) */}
          <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-[#222222] pb-2.5 flex-wrap gap-2">
              <div className="flex items-center space-x-2">
                <Shield className="w-4 h-4 text-[#C9A050]" />
                <h4 className="text-sm font-mono font-bold uppercase text-[#C9A050]">
                  Historia de Origen & Trayectoria Formativa
                </h4>
              </div>
              <span className="text-[11px] font-mono text-[#888888]">
                {(state.background?.backstory || '').length} caracteres
              </span>
            </div>
            <p className="text-[#888888] text-xs">
              De dónde proviene tu personaje, su linaje, su juventud y los eventos trascendentales que lo llevaron a adoptar su rol, armadura e indumentaria actual.
            </p>
            <textarea
              rows={5}
              value={state.background?.backstory || ''}
              onChange={(e) => setState(p => ({ ...p, background: { ...p.background, backstory: e.target.value } }))}
              placeholder="Describe la historia de origen de tu personaje..."
              className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-4 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050] transition-colors resize-y leading-relaxed"
            />
          </div>

          {/* Módulo C: Motivación Principal (5.3) & Secreto */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Motivación Principal */}
            <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-5 space-y-3">
              <div className="flex items-center justify-between border-b border-[#222222] pb-2.5 flex-wrap gap-2">
                <div className="flex items-center space-x-2">
                  <Heart className="w-4 h-4 text-[#C9A050]" />
                  <h4 className="text-sm font-mono font-bold uppercase text-[#C9A050]">
                    Motivación Principal
                  </h4>
                </div>
                <span className="text-[11px] font-mono text-[#888888]">
                  {(state.background?.motivation || '').length} car.
                </span>
              </div>
              <p className="text-[#888888] text-xs">
                El motor inquebrantable que lo impulsa hacia adelante (redención, gloria, justicia, venganza, descubrimiento).
              </p>
              <textarea
                rows={3}
                value={state.background?.motivation || ''}
                onChange={(e) => setState(p => ({ ...p, background: { ...p.background, motivation: e.target.value } }))}
                placeholder="¿Qué impulsa a tu personaje? Proteger a los inocentes, redimir el honor de su casa..."
                className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-3 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050] transition-colors resize-y leading-relaxed"
              />
            </div>

            {/* Secreto u Carga Oculta */}
            <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-5 space-y-3">
              <div className="flex items-center justify-between border-b border-[#222222] pb-2.5 flex-wrap gap-2">
                <div className="flex items-center space-x-2">
                  <Eye className="w-4 h-4 text-[#C9A050]" />
                  <h4 className="text-sm font-mono font-bold uppercase text-[#C9A050]">
                    Secreto, Pacto u Carga Oculta
                  </h4>
                </div>
                <span className="text-[11px] font-mono text-[#888888]">
                  {(state.background?.secret || '').length} car.
                </span>
              </div>
              <p className="text-[#888888] text-xs">
                Un conflicto no resuelto, una deuda de sangre o un pacto sellado en las sombras que añade misterio narrativo.
              </p>
              <textarea
                rows={3}
                value={state.background?.secret || ''}
                onChange={(e) => setState(p => ({ ...p, background: { ...p.background, secret: e.target.value } }))}
                placeholder="Oculta un pasado misterioso, un artefacto prohibido o un juramento ineludible..."
                className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-3 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050] transition-colors resize-y leading-relaxed"
              />
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: CRONOLOGÍA & LÍNEA TEMPORAL NARRATIVA */}
      {activeTab === 'cronologia' && (
        <div className="space-y-5">
          <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-[#C9A050] uppercase flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5" />
                <span>Arco Temático & Visión General</span>
              </span>
              <span className="text-[10px] font-mono text-[#888888]">
                {timeline?.milestones?.length || 0} Hitos Registrados
              </span>
            </div>
            <p className="text-xs text-[#E0E0E0] font-serif italic">
              "{timeline?.thematicArc || 'Arco temático en desarrollo según los actos del personaje.'}"
            </p>
            <p className="text-[11px] text-[#888888] leading-relaxed">
              {timeline?.overview || 'La línea temporal organiza los hitos clave desde sus orígenes tempranos hasta su desafío presente y horizonte futuro.'}
            </p>
          </div>

          {/* Milestones List */}
          {(!timeline?.milestones || timeline.milestones.length === 0) ? (
            <div className="p-8 text-center bg-[#15171C] border border-[#2A2D35] rounded-xl space-y-3">
              <Clock className="w-8 h-8 text-[#C9A050]/50 mx-auto" />
              <p className="text-xs text-[#888888]">
                No hay hitos cronológicos generados todavía.
              </p>
              <button
                type="button"
                onClick={handleUnifiedGenerate}
                className="px-4 py-2 rounded-xl bg-[#C9A050] text-[#0A0B0E] text-xs font-bold transition-all cursor-pointer inline-flex items-center gap-1.5 shadow-xs"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Generar Cronología con el Motor</span>
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {timeline.milestones.map((milestone, idx) => (
                <div
                  key={milestone.id || idx}
                  className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-4 space-y-2 hover:border-[#C9A050]/40 transition-all"
                >
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                        milestone.era === 'Pasado'
                          ? 'bg-blue-950/40 text-blue-300 border border-blue-800/40'
                          : milestone.era === 'Presente'
                          ? 'bg-purple-950/40 text-purple-300 border border-purple-800/40'
                          : milestone.era === 'Futuro'
                          ? 'bg-rose-950/40 text-rose-300 border border-rose-800/40'
                          : 'bg-emerald-950/40 text-emerald-300 border border-emerald-800/40'
                      }`}>
                        {milestone.era}
                      </span>
                      <span className="text-[11px] font-mono text-[#888888]">
                        ({milestone.periodOrAge})
                      </span>
                      <h5 className="text-xs font-bold text-zinc-100">
                        {milestone.title}
                      </h5>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        const updated = (timeline.milestones || []).filter((_, i) => i !== idx);
                        setState(prev => ({
                          ...prev,
                          background: {
                            ...prev.background,
                            narrativeTimeline: prev.background?.narrativeTimeline ? {
                              ...prev.background.narrativeTimeline,
                              milestones: updated
                            } : undefined
                          },
                          narrativeTimeline: prev.narrativeTimeline ? {
                            ...prev.narrativeTimeline,
                            milestones: updated
                          } : undefined
                        }));
                      }}
                      className="text-[#888888] hover:text-red-400 p-1 rounded transition-colors cursor-pointer"
                      title="Eliminar este hito"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <p className="text-xs text-[#CCCCCC] leading-relaxed">
                    {milestone.summary}
                  </p>

                  {milestone.psychologicalEvolution && (
                    <div className="text-[11px] font-mono text-[#C9A050]/90 bg-[#0F1115] px-3 py-1.5 rounded-lg border border-[#222222]">
                      <span className="font-semibold">Impacto Psicológico:</span> {milestone.psychologicalEvolution}
                    </div>
                  )}

                  {milestone.keyEvents && milestone.keyEvents.length > 0 && (
                    <div className="flex flex-wrap gap-1 pt-1">
                      {milestone.keyEvents.map((evt, eIdx) => (
                        <span key={eIdx} className="text-[10px] font-mono bg-[#0F1115] text-[#888888] px-2 py-0.5 rounded border border-[#2A2D35]">
                          • {evt}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              ))}

              {/* Append Milestone directly to backstory */}
              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={() => {
                    if (!timeline) return;
                    const compiled = `\n\n[CRONOLOGÍA & HITOS VITALES]\n` +
                      timeline.milestones.map(m => `• ${m.era} (${m.periodOrAge}): ${m.title} - ${m.summary}`).join('\n');
                    setState(p => ({
                      ...p,
                      background: {
                        ...p.background,
                        backstory: (p.background?.backstory || '') + compiled
                      }
                    }));
                  }}
                  className="text-xs font-mono text-[#C9A050] hover:text-[#b58e45] flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Anexar Resumen Cronológico a la Historia de Origen</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: DETALLES ÚNICOS & SINGULARIDADES */}
      {activeTab === 'detalles' && (
        <div className="space-y-4">
          <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-[#C9A050] uppercase flex items-center gap-1.5">
                <Milestone className="w-3.5 h-3.5" />
                <span>Detalles Únicos, Singularidades y Marcas Distintivas</span>
              </span>
              <span className="text-[10px] font-mono text-[#888888]">
                {state.background?.uniqueDetails?.length || 0} Singularidades Activas
              </span>
            </div>
            <p className="text-xs text-[#888888] leading-relaxed">
              Peculiaridades que hacen único a este personaje: votos sagrados, marcas corporales indelebles, reliquias heredadas, manías de combate o juramentos enigmáticos.
            </p>
          </div>

          {/* List of Unique Details */}
          <div className="space-y-2.5">
            {(!state.background?.uniqueDetails || state.background.uniqueDetails.length === 0) ? (
              <div className="p-6 text-center bg-[#15171C] border border-[#2A2D35] rounded-xl text-xs text-[#888888]">
                No hay detalles únicos añadidos. Pulsa en generar trasfondo o escribe una singularidad abajo.
              </div>
            ) : (
              state.background.uniqueDetails.map((detail, idx) => (
                <div
                  key={idx}
                  className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-3.5 flex items-start justify-between gap-3 group hover:border-[#C9A050]/50 transition-all"
                >
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-[#C9A050]/20 text-[#C9A050] font-mono text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <p className="text-xs text-zinc-200 leading-relaxed">
                      {detail}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleRemoveUniqueDetail(idx)}
                    className="text-[#888888] hover:text-red-400 p-1 rounded transition-colors cursor-pointer shrink-0"
                    title="Eliminar este detalle único"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))
            )}
          </div>

          {/* Add custom unique detail */}
          <div className="flex gap-2 pt-2">
            <input
              type="text"
              value={newUniqueDetailInput}
              onChange={(e) => setNewUniqueDetailInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleAddUniqueDetail();
                }
              }}
              placeholder="Escribe una peculiaridad o detalle único (ej: Porta la empuñadura de la espada que quebró en su primera batalla)..."
              className="flex-1 bg-[#0F1115] border border-[#2A2D35] rounded-xl px-3 py-2 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050] transition-colors"
            />
            <button
              type="button"
              onClick={handleAddUniqueDetail}
              className="bg-[#1A1C22] border border-[#2A2D35] text-[#C9A050] hover:bg-[#C9A050] hover:text-[#0A0B0E] px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Añadir Detalle</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
