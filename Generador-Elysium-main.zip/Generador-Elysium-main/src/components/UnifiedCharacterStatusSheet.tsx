import React, { useState } from 'react';
import {
  Shield,
  Award,
  Sparkles,
  Package,
  Trash2,
  Plus,
  ChevronDown,
  ChevronUp,
  Shirt,
  X,
  Check,
  RotateCcw,
  Zap,
  Info
} from 'lucide-react';
import { GarmentConfig } from '../types';

export interface UnifiedCharacterStatusSheetProps {
  characterName: string;
  onUpdateCharacterName?: (name: string) => void;
  title?: string;
  raceName?: string;
  roleName?: string;

  // XP & Progression
  xp: number;
  onUpdateXp?: (newXp: number) => void;

  // Attributes
  attributes: {
    FUE: number;
    DES: number;
    CON: number;
    INT: number;
    SAB: number;
    CAR: number;
  };
  onUpdateAttributes?: (attrs: {
    FUE: number;
    DES: number;
    CON: number;
    INT: number;
    SAB: number;
    CAR: number;
  }) => void;

  // Derived Stats
  derived: {
    PV: number;
    maxPV: number;
    PEP: number;
    maxPEP: number;
    CA: number;
    iniciativa: number;
    velocidad: number;
    CEP: number;
    EFC: number;
    RR: number;
  };
  onUpdateDerived?: (derived: {
    PV: number;
    maxPV: number;
    PEP: number;
    maxPEP: number;
    CA: number;
    iniciativa: number;
    velocidad: number;
    CEP: number;
    EFC: number;
    RR: number;
  }) => void;

  // Active Skills & Equipment
  activeSkills: string[];
  onUpdateActiveSkills?: (skills: string[]) => void;
  equipmentItems: string[];
  onUpdateEquipmentItems?: (items: string[]) => void;

  // Conduct & Motivations
  moralAlignment: string;
  onUpdateMoralAlignment?: (alignment: string) => void;
  allegianceFaction: string;
  factionOptions?: Array<{ id: string; name: string }>;
  onUpdateAllegianceFaction?: (faction: string) => void;
  greatestFear: string;
  fearOptions?: string[];
  onUpdateGreatestFear?: (fear: string) => void;
  motivations: string[];
  onUpdateMotivations?: (motivations: string[]) => void;

  // Wardrobe / Vestimenta
  wardrobes: GarmentConfig[];
  onUpdateWardrobes?: (wardrobes: GarmentConfig[]) => void;

  // Header & Footer slot
  headerControls?: React.ReactNode;
  footerControls?: React.ReactNode;
  readOnly?: boolean;
}

export const UnifiedCharacterStatusSheet: React.FC<UnifiedCharacterStatusSheetProps> = ({
  characterName,
  onUpdateCharacterName,
  title = 'Ficha del Usuario',
  raceName = 'Humano',
  roleName = 'Estratega de Élite',

  xp = 300,
  onUpdateXp,

  attributes = { FUE: 18, DES: 14, CON: 16, INT: 12, SAB: 12, CAR: 14 },
  onUpdateAttributes,

  derived = {
    PV: 216,
    maxPV: 216,
    PEP: 5,
    maxPEP: 5,
    CA: 16,
    iniciativa: 14,
    velocidad: 30,
    CEP: 15,
    EFC: 35,
    RR: 60
  },
  onUpdateDerived,

  activeSkills = ['Tajo Espejado', 'Evaluación Táctica', 'Foco Inquebrantable'],
  onUpdateActiveSkills,

  equipmentItems = ['Hoja Damasquina', 'Poción de Vigor', 'Mapa Cartográfico del Oasis'],
  onUpdateEquipmentItems,

  moralAlignment = 'Devoto Protector',
  onUpdateMoralAlignment,

  allegianceFaction = '',
  factionOptions = [],
  onUpdateAllegianceFaction,

  greatestFear = '',
  fearOptions = [],
  onUpdateGreatestFear,

  motivations = ['Proteger el honor de su linaje', 'Explorar los misterios del cosmos'],
  onUpdateMotivations,

  wardrobes = [],
  onUpdateWardrobes,

  headerControls,
  footerControls,
  readOnly = false
}) => {
  // Local state for UI interactions
  const [feedback, setFeedback] = useState<string | null>(null);
  const [expandedWardrobeId, setExpandedWardrobeId] = useState<string | null>(null);
  const [newSkillInput, setNewSkillInput] = useState('');
  const [isAddingSkill, setIsAddingSkill] = useState(false);
  const [newItemInput, setNewItemInput] = useState('');
  const [isAddingItem, setIsAddingItem] = useState(false);
  const [newMotivationInput, setNewMotivationInput] = useState('');

  // Toast notification
  const notify = (msg: string) => {
    setFeedback(msg);
    setTimeout(() => setFeedback(null), 3000);
  };

  // Helper modifier D&D
  const getMod = (val: number) => Math.floor((val - 10) / 2);

  // Recalculate derived helper
  const recalculateDerived = (
    currentAttrs: typeof attributes,
    currentDerived: typeof derived
  ) => {
    const con = currentAttrs.CON;
    const fue = currentAttrs.FUE;
    const des = currentAttrs.DES;

    // Standard baseline formula:
    // PV = (CON * 10) + (FUE * 2) + racial/role bonus (~20 + 4 = 24 for standard)
    const newMaxPv = con * 10 + fue * 2 + 20;
    const newCa = 10 + Math.floor(des / 2) + 1; // +1 role/base
    const newIni = des;
    const newPep = Math.max(1, Math.round(currentDerived.CEP * (currentDerived.EFC / 100)));

    return {
      ...currentDerived,
      PV: Math.min(newMaxPv, currentDerived.PV > 0 ? currentDerived.PV : newMaxPv),
      maxPV: newMaxPv,
      CA: newCa,
      iniciativa: newIni,
      PEP: newPep,
      maxPEP: newPep
    };
  };

  // Spend XP on attributes
  const handleSpendAttributeXp = (attrKey: keyof typeof attributes) => {
    if (readOnly) return;
    const cost = 200;
    if (xp < cost) {
      notify(`XP insuficiente: Requiere ${cost} XP, tienes ${xp} XP.`);
      return;
    }

    if (attributes[attrKey] >= 20) {
      notify(`El atributo ${attrKey} ya está al nivel máximo (20).`);
      return;
    }

    const nextXp = xp - cost;
    const nextAttrs = {
      ...attributes,
      [attrKey]: attributes[attrKey] + 1
    };

    if (onUpdateXp) onUpdateXp(nextXp);
    if (onUpdateAttributes) onUpdateAttributes(nextAttrs);

    if (onUpdateDerived) {
      const nextDerived = recalculateDerived(nextAttrs, derived);
      onUpdateDerived(nextDerived);
    }

    notify(`+1 a ${attrKey} mejorado con éxito.`);
  };

  // Spend XP on CEP (+5 [100 XP])
  const handleSpendCepXp = () => {
    if (readOnly) return;
    const cost = 100;
    if (xp < cost) {
      notify(`XP insuficiente: Requiere ${cost} XP, tienes ${xp} XP.`);
      return;
    }

    const nextXp = xp - cost;
    const nextCep = derived.CEP + 5;
    const nextPep = Math.max(1, Math.round(nextCep * (derived.EFC / 100)));

    if (onUpdateXp) onUpdateXp(nextXp);
    if (onUpdateDerived) {
      onUpdateDerived({
        ...derived,
        CEP: nextCep,
        PEP: nextPep,
        maxPEP: nextPep
      });
    }
    notify(`+5 a CEP (Capacidad) mejorado.`);
  };

  // Spend XP on EFC (+1% [150 XP])
  const handleSpendEfcXp = () => {
    if (readOnly) return;
    const cost = 150;
    if (xp < cost) {
      notify(`XP insuficiente: Requiere ${cost} XP, tienes ${xp} XP.`);
      return;
    }

    if (derived.EFC >= 95) {
      notify('Eficiencia (EFC) al límite máximo del 95%.');
      return;
    }

    const nextXp = xp - cost;
    const nextEfc = derived.EFC + 1;
    const nextPep = Math.max(1, Math.round(derived.CEP * (nextEfc / 100)));

    if (onUpdateXp) onUpdateXp(nextXp);
    if (onUpdateDerived) {
      onUpdateDerived({
        ...derived,
        EFC: nextEfc,
        PEP: nextPep,
        maxPEP: nextPep
      });
    }
    notify(`+1% a EFC (Eficiencia) mejorado.`);
  };

  // Spend XP on RR (+1 [100 XP])
  const handleSpendRrXp = () => {
    if (readOnly) return;
    const cost = 100;
    if (xp < cost) {
      notify(`XP insuficiente: Requiere ${cost} XP, tienes ${xp} XP.`);
      return;
    }

    const nextXp = xp - cost;
    const nextRr = derived.RR + 1;

    if (onUpdateXp) onUpdateXp(nextXp);
    if (onUpdateDerived) {
      onUpdateDerived({
        ...derived,
        RR: nextRr
      });
    }
    notify(`+1 a RR (Resistencia) mejorado.`);
  };

  // Quick grant XP for testing
  const handleGrantXp = (amount: number) => {
    if (onUpdateXp) {
      onUpdateXp(xp + amount);
      notify(`+${amount} XP añadido.`);
    }
  };

  // Active skills handlers
  const handleAddSkill = () => {
    if (!newSkillInput.trim()) return;
    const nextSkills = [...activeSkills, newSkillInput.trim()];
    if (onUpdateActiveSkills) onUpdateActiveSkills(nextSkills);
    setNewSkillInput('');
    setIsAddingSkill(false);
  };

  const handleRemoveSkill = (index: number) => {
    const nextSkills = activeSkills.filter((_, i) => i !== index);
    if (onUpdateActiveSkills) onUpdateActiveSkills(nextSkills);
  };

  // Equipment handlers
  const handleAddItem = () => {
    if (!newItemInput.trim()) return;
    const nextItems = [...equipmentItems, newItemInput.trim()];
    if (onUpdateEquipmentItems) onUpdateEquipmentItems(nextItems);
    setNewItemInput('');
    setIsAddingItem(false);
  };

  const handleRemoveItem = (index: number) => {
    const nextItems = equipmentItems.filter((_, i) => i !== index);
    if (onUpdateEquipmentItems) onUpdateEquipmentItems(nextItems);
  };

  // Motivations handlers
  const handleAddMotivation = () => {
    if (!newMotivationInput.trim()) return;
    const nextMotivations = [...motivations, newMotivationInput.trim()];
    if (onUpdateMotivations) onUpdateMotivations(nextMotivations);
    setNewMotivationInput('');
  };

  const handleRemoveMotivation = (index: number) => {
    const nextMotivations = motivations.filter((_, i) => i !== index);
    if (onUpdateMotivations) onUpdateMotivations(nextMotivations);
  };

  // Wardrobe update helper
  const handleUpdateSingleWardrobe = (id: string, field: keyof GarmentConfig, val: any) => {
    if (!onUpdateWardrobes) return;
    const updated = wardrobes.map(w => (w.id === id ? { ...w, [field]: val } : w));
    onUpdateWardrobes(updated);
  };

  const handleRemoveWardrobe = (id: string) => {
    if (!onUpdateWardrobes) return;
    onUpdateWardrobes(wardrobes.filter(w => w.id !== id));
  };

  const handleAddWardrobe = () => {
    if (!onUpdateWardrobes) return;
    const newG: GarmentConfig = {
      id: `w-custom-${Date.now()}`,
      categoryId: 'B0',
      name: 'Prenda Personalizada',
      cut: 'Corte Ajustado',
      length: 'Estándar',
      sleeve: 'Manga Larga',
      material: 'Seda y lino refinado',
      color: 'Negro y Dorado',
      finish: 'Satinado',
      details: ['Bordado artesanal', 'Ribetes dorados'],
      variation: 'Estándar',
      layer: 'Media',
      location: ['TORSO / PECHO'],
      detailLocations: {},
      pattern: 'Liso',
      patternDetail: '',
      neckline: 'Redondo',
      emblem: '',
      vfx: ''
    };
    onUpdateWardrobes([...wardrobes, newG]);
    setExpandedWardrobeId(newG.id);
  };

  // Fallback seed wardrobes if empty
  const displayWardrobes =
    wardrobes && wardrobes.length > 0
      ? wardrobes
      : [
          {
            id: 'w-seed-01',
            categoryId: 'B0',
            name: 'Corsé de Terciopelo y Seda Nocturna',
            cut: 'Ajustado',
            length: 'Cintura',
            sleeve: 'Sin mangas',
            material: 'Terciopelo negro con bordados de hilo de plata',
            color: 'Negro Azabache y Borgoña',
            finish: 'Satinado',
            details: ['Bordado de rosas doradas', 'Cintas de seda cruzadas en espalda'],
            variation: 'Corte Victoriano',
            layer: 'Base',
            location: ['TORSO / PECHO'],
            detailLocations: {},
            pattern: 'Filigrana',
            patternDetail: 'Espinas entrelazadas',
            neckline: 'Corazón pronunciado',
            emblem: 'Rosa Negra',
            vfx: 'Sutil destello de partículas sombrías'
          },
          {
            id: 'w-seed-02',
            categoryId: 'B2',
            name: 'Falda Larga de Capas de Encaje con Abertura',
            cut: 'Campana con vuelo',
            length: 'Hasta los tobillos',
            sleeve: 'N/A',
            material: 'Seda y encaje de araña',
            color: 'Negro y Púrpura Nocturno',
            finish: 'Mate elegante',
            details: ['Abertura lateral alta', 'Ribete de encaje floral'],
            variation: 'Elegancia gótica',
            layer: 'Media',
            location: ['CADERAS / PIERNAS'],
            detailLocations: {},
            pattern: 'Encaje fino',
            patternDetail: 'Telaraña floral',
            neckline: '',
            emblem: '',
            vfx: ''
          }
        ];

  const attributeList: Array<{
    key: keyof typeof attributes;
    label: string;
    val: number;
    mod: number;
  }> = [
    { key: 'FUE', label: 'FUE', val: attributes.FUE, mod: getMod(attributes.FUE) },
    { key: 'DES', label: 'DES', val: attributes.DES, mod: getMod(attributes.DES) },
    { key: 'CON', label: 'CON', val: attributes.CON, mod: getMod(attributes.CON) },
    { key: 'INT', label: 'INT', val: attributes.INT, mod: getMod(attributes.INT) },
    { key: 'SAB', label: 'SAB', val: attributes.SAB, mod: getMod(attributes.SAB) },
    { key: 'CAR', label: 'CAR', val: attributes.CAR, mod: getMod(attributes.CAR) }
  ];

  return (
    <div className="w-full bg-[#0B0D13] text-[#E0E2EC] font-sans antialiased selection:bg-indigo-500 selection:text-white">
      {/* Toast feedback */}
      {feedback && (
        <div className="fixed top-6 right-6 z-50 px-4 py-2.5 rounded-xl bg-indigo-950 border border-indigo-500/60 text-indigo-100 text-xs font-bold shadow-2xl backdrop-blur-md flex items-center gap-2 animate-fadeIn">
          <Info className="w-4 h-4 text-indigo-400" />
          <span>{feedback}</span>
        </div>
      )}

      {/* Main card container */}
      <div className="bg-[#0F121C] border border-[#1E2336] rounded-2xl p-4 sm:p-6 md:p-8 shadow-2xl relative">
        {/* TOP HEADER CONTROLS (if provided by parent) */}
        {headerControls && <div className="mb-4">{headerControls}</div>}

        {/* TOP BAR: SHIELD ICON, CHARACTER NAME & TITLE, XP BADGE */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#1A1F30]">
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-[#141829] border border-[#2B3454] flex items-center justify-center shrink-0 shadow-inner">
              <Shield className="w-5 h-5 text-indigo-400" />
            </div>

            <div>
              <h2 className="text-base sm:text-lg font-bold text-white tracking-wide flex items-center gap-2">
                <span>{characterName || 'Xander Vaelith'}</span>
                <span className="text-[#8A8F9E] font-medium">•</span>
                <span className="text-[#9CA3AF] font-semibold">{title}</span>
              </h2>
              <p className="text-xs text-[#8A8F9E] mt-0.5">
                Raza:{' '}
                <span className="text-[#D4AF37] font-semibold">
                  {raceName || 'Humano'}
                </span>
                {' · '}
                Rol:{' '}
                <span className="text-[#D4AF37] font-semibold">
                  {roleName || 'Estratega de Élite'}
                </span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-center">
            <div className="px-3.5 py-1.5 rounded-xl bg-[#141624] border border-[#2E354C] flex items-center gap-2 text-xs font-mono font-bold text-[#E5C158] shadow-sm">
              <Award className="w-4 h-4 text-[#D4AF37]" />
              <span>
                XP Disponible: <strong className="text-white">{xp}</strong>
              </span>
            </div>

            {!readOnly && (
              <button
                type="button"
                onClick={() => handleGrantXp(100)}
                className="px-2 py-1.5 rounded-lg bg-[#181B28] hover:bg-[#23273A] text-[#9CA3AF] hover:text-white border border-[#292F45] text-[11px] font-mono font-semibold transition-colors cursor-pointer"
                title="Añadir +100 XP para pruebas de progresión"
              >
                +100 XP
              </button>
            )}
          </div>
        </div>

        {/* SECTION: ATRIBUTOS PRINCIPALES (S4) */}
        <div className="mt-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[11px] font-mono font-bold tracking-wider text-[#8A8F9E] uppercase">
              ATRIBUTOS PRINCIPALES (S4)
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
            {attributeList.map(({ key, label, val, mod }) => (
              <div
                key={key}
                className="bg-[#12141F] border border-[#222638] hover:border-indigo-500/40 rounded-xl p-3 text-center flex flex-col justify-between transition-colors shadow-xs"
              >
                <span className="text-xs font-bold text-[#8A8F9E] tracking-wider uppercase">
                  {label}
                </span>

                <div className="my-2">
                  <span className="text-xl sm:text-2xl font-black text-white">
                    {val}
                  </span>
                  <span className="text-sm font-mono font-bold text-[#D4AF37] ml-1.5">
                    ({mod >= 0 ? `+${mod}` : mod})
                  </span>
                </div>

                <button
                  type="button"
                  disabled={readOnly}
                  onClick={() => handleSpendAttributeXp(key)}
                  className="mt-1 py-1.5 px-2 bg-[#1A1D2B] hover:bg-indigo-600 hover:text-white border border-[#292E42] rounded-lg text-xs font-semibold text-[#9CA3AF] transition-all cursor-pointer active:scale-95 disabled:opacity-50"
                  title={`Aumentar ${label} +1 por 200 XP`}
                >
                  +1 [200 XP]
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* SECTION: ESTADÍSTICAS DERIVADAS & ENERGÍA PNEUMA */}
        <div className="mt-6">
          <span className="text-[11px] font-mono font-bold tracking-wider text-[#8A8F9E] uppercase block mb-3">
            ESTADÍSTICAS DERIVADAS & ENERGÍA PNEUMA
          </span>

          {/* Row 1: PV, PEP, CA, Iniciativa/Velocidad */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-[#12141F] border border-[#222638] rounded-xl p-3 flex flex-col justify-between">
              <span className="text-[11px] font-semibold text-[#8A8F9E]">
                Puntos de Vida (PV)
              </span>
              <span className="text-lg sm:text-xl font-bold text-[#10B981] mt-1.5">
                {derived.PV} / {derived.maxPV}
              </span>
            </div>

            <div className="bg-[#12141F] border border-[#222638] rounded-xl p-3 flex flex-col justify-between">
              <span className="text-[11px] font-semibold text-[#8A8F9E]">
                Puntos de E-Pn (PEP)
              </span>
              <span className="text-lg sm:text-xl font-bold text-[#818CF8] mt-1.5">
                {derived.PEP} / {derived.maxPEP}
              </span>
            </div>

            <div className="bg-[#12141F] border border-[#222638] rounded-xl p-3 flex flex-col justify-between">
              <span className="text-[11px] font-semibold text-[#8A8F9E]">
                Clase de Armadura (CA)
              </span>
              <span className="text-lg sm:text-xl font-bold text-[#F59E0B] mt-1.5">
                {derived.CA}
              </span>
            </div>

            <div className="bg-[#12141F] border border-[#222638] rounded-xl p-3 flex flex-col justify-between">
              <span className="text-[11px] font-semibold text-[#8A8F9E]">
                Iniciativa / Velocidad
              </span>
              <span className="text-base sm:text-lg font-bold text-white mt-1.5">
                {derived.iniciativa} / {derived.velocidad} pies
              </span>
            </div>
          </div>

          {/* Row 2: CEP, EFC, RR with upgrade buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-3">
            <div className="bg-[#12141F] border border-[#222638] rounded-xl p-3 flex items-center justify-between">
              <div>
                <span className="text-[11px] font-semibold text-[#8A8F9E] block">
                  CEP (Capacidad)
                </span>
                <span className="text-lg font-bold text-white mt-0.5 block">
                  {derived.CEP}
                </span>
              </div>
              <button
                type="button"
                disabled={readOnly}
                onClick={handleSpendCepXp}
                className="py-1 px-2.5 bg-[#1A1D2B] hover:bg-indigo-600 hover:text-white border border-[#292E42] rounded-lg text-xs font-semibold text-[#9CA3AF] transition-colors cursor-pointer active:scale-95 disabled:opacity-50"
              >
                +5 [100 XP]
              </button>
            </div>

            <div className="bg-[#12141F] border border-[#222638] rounded-xl p-3 flex items-center justify-between">
              <div>
                <span className="text-[11px] font-semibold text-[#8A8F9E] block">
                  EFC (Eficiencia)
                </span>
                <span className="text-lg font-bold text-white mt-0.5 block">
                  {derived.EFC}%
                </span>
              </div>
              <button
                type="button"
                disabled={readOnly}
                onClick={handleSpendEfcXp}
                className="py-1 px-2.5 bg-[#1A1D2B] hover:bg-indigo-600 hover:text-white border border-[#292E42] rounded-lg text-xs font-semibold text-[#9CA3AF] transition-colors cursor-pointer active:scale-95 disabled:opacity-50"
              >
                +1% [150 XP]
              </button>
            </div>

            <div className="bg-[#12141F] border border-[#222638] rounded-xl p-3 flex items-center justify-between">
              <div>
                <span className="text-[11px] font-semibold text-[#8A8F9E] block">
                  RR (Resistencia)
                </span>
                <span className="text-lg font-bold text-white mt-0.5 block">
                  {derived.RR}
                </span>
              </div>
              <button
                type="button"
                disabled={readOnly}
                onClick={handleSpendRrXp}
                className="py-1 px-2.5 bg-[#1A1D2B] hover:bg-indigo-600 hover:text-white border border-[#292E42] rounded-lg text-xs font-semibold text-[#9CA3AF] transition-colors cursor-pointer active:scale-95 disabled:opacity-50"
              >
                +1 [100 XP]
              </button>
            </div>
          </div>
        </div>

        {/* SECTION: HABILIDADES ACTIVAS & INVENTARIO Y EQUIPAMIENTO */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
          {/* Left: Active Skills */}
          <div className="bg-[#12141F] border border-[#222638] rounded-xl p-4">
            <div className="flex items-center justify-between mb-3">
              <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-[#8A8F9E] flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-indigo-400" />
                <span>HABILIDADES ACTIVAS</span>
              </span>

              {!readOnly && (
                <button
                  type="button"
                  onClick={() => setIsAddingSkill(!isAddingSkill)}
                  className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Añadir</span>
                </button>
              )}
            </div>

            {isAddingSkill && (
              <div className="flex items-center gap-2 mb-3">
                <input
                  type="text"
                  value={newSkillInput}
                  onChange={e => setNewSkillInput(e.target.value)}
                  placeholder="Nombre de la técnica..."
                  className="flex-1 bg-[#181B26] border border-[#2B2F3F] rounded-lg px-2.5 py-1.5 text-xs text-white outline-hidden focus:border-indigo-500"
                  onKeyDown={e => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddSkill();
                    }
                  }}
                />
                <button
                  type="button"
                  onClick={handleAddSkill}
                  className="px-2.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold cursor-pointer"
                >
                  Añadir
                </button>
              </div>
            )}

            <div className="flex flex-wrap gap-2">
              {activeSkills.map((skill, idx) => (
                <span
                  key={idx}
                  className="bg-[#161925] border border-[#2A3048] hover:border-indigo-500/50 px-3 py-1.5 rounded-xl text-xs font-medium text-white flex items-center gap-1.5 group transition-colors"
                >
                  <span>{skill}</span>
                  {!readOnly && (
                    <button
                      type="button"
                      onClick={() => handleRemoveSkill(idx)}
                      className="text-[#6B7280] hover:text-rose-400 opacity-60 group-hover:opacity-100 cursor-pointer transition-opacity"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  )}
                </span>
              ))}
            </div>
          </div>

          {/* Right: Inventory and Equipment Chips */}
          <div className="bg-[#12141F] border border-[#222638] rounded-xl p-4">
            <div className="flex items-center justify-between mb-3">
              <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-[#8A8F9E] flex items-center gap-2">
                <Package className="w-4 h-4 text-amber-400" />
                <span>INVENTARIO Y EQUIPAMIENTO</span>
              </span>

              {!readOnly && (
                <button
                  type="button"
                  onClick={() => setIsAddingItem(!isAddingItem)}
                  className="text-xs text-[#D4AF37] hover:text-amber-300 font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Añadir</span>
                </button>
              )}
            </div>

            {isAddingItem && (
              <div className="flex items-center gap-2 mb-3">
                <input
                  type="text"
                  value={newItemInput}
                  onChange={e => setNewItemInput(e.target.value)}
                  placeholder="Nombre del objeto o arma..."
                  className="flex-1 bg-[#181B26] border border-[#2B2F3F] rounded-lg px-2.5 py-1.5 text-xs text-white outline-hidden focus:border-[#D4AF37]"
                  onKeyDown={e => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddItem();
                    }
                  }}
                />
                <button
                  type="button"
                  onClick={handleAddItem}
                  className="px-2.5 py-1.5 bg-[#252A3B] hover:bg-[#30374C] text-[#D4AF37] rounded-lg text-xs font-bold cursor-pointer"
                >
                  Añadir
                </button>
              </div>
            )}

            <div className="flex flex-wrap gap-2">
              {equipmentItems.map((item, idx) => (
                <span
                  key={idx}
                  className="bg-[#161925] border border-[#2A3048] hover:border-amber-500/50 px-3 py-1.5 rounded-xl text-xs font-medium text-white flex items-center gap-1.5 group transition-colors"
                >
                  <span>{item}</span>
                  {!readOnly && (
                    <button
                      type="button"
                      onClick={() => handleRemoveItem(idx)}
                      className="text-[#6B7280] hover:text-rose-400 opacity-60 group-hover:opacity-100 cursor-pointer transition-opacity"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  )}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* SECTION: ALINEACIÓN MORAL & FACCIÓN */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
          <div>
            <label className="text-xs text-[#8A8F9E] block mb-1.5 font-bold">
              Alineación Moral:
            </label>
            <select
              disabled={readOnly}
              value={moralAlignment || 'Devoto Protector'}
              onChange={e =>
                onUpdateMoralAlignment && onUpdateMoralAlignment(e.target.value)
              }
              className="w-full bg-[#12141F] border border-[#222638] rounded-xl px-3.5 py-2.5 text-xs text-white outline-hidden focus:border-[#D4AF37] transition-colors"
            >
              <option value="Devoto Protector">Devoto Protector</option>
              <option value="Leal Bondadoso">Leal Bondadoso</option>
              <option value="Neutral Bondadoso">Neutral Bondadoso</option>
              <option value="Neutral">Neutral</option>
              <option value="Neutral Ambicioso">Neutral Ambicioso</option>
              <option value="Curioso">Curioso</option>
              <option value="Hedonismo">Hedonismo</option>
              <option value="Rebelde">Rebelde</option>
              <option value="Caótico">Caótico</option>
            </select>
          </div>

          <div>
            <label className="text-xs text-[#8A8F9E] block mb-1.5 font-bold">
              Facción de Lealtad:
            </label>
            <select
              disabled={readOnly}
              value={allegianceFaction || ''}
              onChange={e =>
                onUpdateAllegianceFaction &&
                onUpdateAllegianceFaction(e.target.value)
              }
              className="w-full bg-[#12141F] border border-[#222638] rounded-xl px-3.5 py-2.5 text-xs text-white outline-hidden focus:border-[#D4AF37] transition-colors"
            >
              <option value="">(Sin facción seleccionada en Estado 5)</option>
              {factionOptions && factionOptions.length > 0 ? (
                factionOptions.map(f => (
                  <option key={f.id} value={f.name}>
                    {f.name}
                  </option>
                ))
              ) : allegianceFaction ? (
                <option value={allegianceFaction}>{allegianceFaction}</option>
              ) : null}
            </select>
          </div>
        </div>

        {/* SECTION: MAYOR MIEDO */}
        <div className="mt-4">
          <label className="text-xs text-[#8A8F9E] block mb-1.5 font-bold">
            Mayor Miedo (Vulnerabilidad Fatal / Talón de Aquiles):
          </label>
          <select
            disabled={readOnly}
            value={greatestFear || ''}
            onChange={e =>
              onUpdateGreatestFear && onUpdateGreatestFear(e.target.value)
            }
            className="w-full bg-[#12141F] border border-[#222638] rounded-xl px-3.5 py-2.5 text-xs text-white outline-hidden focus:border-[#D4AF37] transition-colors"
          >
            <option value="">
              (Sin vulnerabilidad fatal seleccionada en Estado 5)
            </option>
            {fearOptions && fearOptions.length > 0 ? (
              fearOptions.map((fo, idx) => (
                <option key={idx} value={fo}>
                  {fo}
                </option>
              ))
            ) : greatestFear ? (
              <option value={greatestFear}>{greatestFear}</option>
            ) : null}
          </select>

          {greatestFear && greatestFear.includes(' | ') && (
            <div className="mt-2 flex flex-wrap gap-1.5">
              {greatestFear.split(' | ').filter(Boolean).map((fearPart, idx) => (
                <span
                  key={idx}
                  className="bg-amber-500/15 border border-amber-500/40 text-amber-200 px-2 py-0.5 rounded-md text-[11px] font-medium flex items-center gap-1"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
                  {fearPart}
                </span>
              ))}
            </div>
          )}
        </div>

        {/* SECTION: MOTIVACIONES & IMPULSOS CLAVE */}
        <div className="mt-5">
          <label className="text-xs text-[#8A8F9E] block mb-2 font-bold">
            Motivaciones & Impulsos Clave:
          </label>

          <div className="space-y-2">
            {motivations.map((mot, idx) => (
              <div
                key={idx}
                className="bg-[#12141F] border border-[#222638] rounded-xl px-4 py-2.5 flex items-center justify-between text-xs text-[#D4AF37] font-medium"
              >
                <span>▪ {mot}</span>
                {!readOnly && (
                  <button
                    type="button"
                    onClick={() => handleRemoveMotivation(idx)}
                    className="text-[#6B7280] hover:text-rose-400 p-1 cursor-pointer transition-colors"
                    title="Eliminar motivación"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            ))}
          </div>

          {!readOnly && (
            <div className="flex gap-2 mt-2">
              <input
                type="text"
                value={newMotivationInput}
                onChange={e => setNewMotivationInput(e.target.value)}
                placeholder="Añadir nueva motivación..."
                className="flex-1 bg-[#12141F] border border-[#222638] rounded-xl px-3 py-2 text-xs text-white outline-hidden focus:border-[#D4AF37]"
                onKeyDown={e => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddMotivation();
                  }
                }}
              />
              <button
                type="button"
                onClick={handleAddMotivation}
                className="px-3.5 py-2 bg-[#1A1D2B] hover:bg-[#252A3E] text-[#D4AF37] rounded-xl text-xs font-bold border border-[#2A2F45] cursor-pointer"
              >
                Añadir
              </button>
            </div>
          )}
        </div>

        {/* SECTION: INVENTARIO, VESTIMENTA Y EQUIPO */}
        <div className="mt-8 pt-6 border-t border-[#1E2336]">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold text-white tracking-tight">
              Inventario, Vestimenta y Equipo
            </h3>

            {!readOnly && onUpdateWardrobes && (
              <button
                type="button"
                onClick={handleAddWardrobe}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#1A1D2B] hover:bg-indigo-600 hover:text-white border border-[#2A2F45] text-xs font-semibold text-[#D4AF37] transition-all cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Añadir Prenda</span>
              </button>
            )}
          </div>

          <div className="space-y-4">
            {displayWardrobes.map((garment, idx) => {
              const isExpanded = expandedWardrobeId === garment.id;

              return (
                <div
                  key={garment.id || idx}
                  className="bg-[#12141F] border border-[#222638] hover:border-[#2F354D] rounded-2xl p-4 sm:p-5 transition-colors"
                >
                  <div className="flex items-start gap-4">
                    {/* Left Square Thumbnail Box */}
                    <div className="w-12 h-12 rounded-xl bg-[#151722] border border-[#262A3B] flex items-center justify-center shrink-0 shadow-inner">
                      <Shirt className="w-6 h-6 text-[#8A8F9E]" />
                    </div>

                    {/* Right Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm sm:text-base font-bold text-white">
                          {garment.name}
                        </span>
                        <span className="px-2 py-0.5 rounded-full bg-[#1C2030] text-[#9CA3AF] border border-[#2B3045] text-[10px] font-mono font-bold">
                          #{idx + 1}
                        </span>
                      </div>

                      {/* Line 1: Mat & Finish */}
                      <p className="text-xs text-[#8A8F9E] mt-1">
                        Mat:{' '}
                        <span className="text-[#E5E7EB] font-medium">
                          {garment.material || 'Tela refinada'}
                        </span>
                        {' ▪ '}
                        Acabado:{' '}
                        <span className="text-[#E5E7EB] font-medium">
                          {garment.finish || 'Estándar'}
                        </span>
                      </p>

                      {/* Line 2: Details */}
                      <p className="text-xs text-[#D4AF37] font-medium mt-0.5">
                        ▪ Detalles:{' '}
                        {garment.details && garment.details.length > 0
                          ? garment.details.join(', ')
                          : 'Bordado artesanal y costuras finas'}
                      </p>

                      {/* Collapsible Toggle: Ajustar Prenda v */}
                      <button
                        type="button"
                        onClick={() =>
                          setExpandedWardrobeId(isExpanded ? null : garment.id)
                        }
                        className="text-xs font-semibold text-[#D4AF37] hover:text-amber-300 flex items-center gap-1 mt-2.5 cursor-pointer transition-colors"
                      >
                        <span>Ajustar Prenda</span>
                        {isExpanded ? (
                          <ChevronUp className="w-3.5 h-3.5" />
                        ) : (
                          <ChevronDown className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Expanded Accordion: Ajuste Detallado de la Prenda */}
                  {isExpanded && !readOnly && (
                    <div className="mt-4 pt-4 border-t border-[#1F2333] grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs animate-fadeIn">
                      <div>
                        <label className="text-[#8A8F9E] block mb-1 font-semibold">
                          Nombre de la Prenda:
                        </label>
                        <input
                          type="text"
                          value={garment.name}
                          onChange={e =>
                            handleUpdateSingleWardrobe(
                              garment.id,
                              'name',
                              e.target.value
                            )
                          }
                          className="w-full bg-[#181B26] border border-[#2B2F3F] rounded-lg px-2.5 py-1.5 text-white outline-hidden focus:border-[#D4AF37]"
                        />
                      </div>

                      <div>
                        <label className="text-[#8A8F9E] block mb-1 font-semibold">
                          Material:
                        </label>
                        <input
                          type="text"
                          value={garment.material}
                          onChange={e =>
                            handleUpdateSingleWardrobe(
                              garment.id,
                              'material',
                              e.target.value
                            )
                          }
                          className="w-full bg-[#181B26] border border-[#2B2F3F] rounded-lg px-2.5 py-1.5 text-white outline-hidden focus:border-[#D4AF37]"
                        />
                      </div>

                      <div>
                        <label className="text-[#8A8F9E] block mb-1 font-semibold">
                          Acabado:
                        </label>
                        <input
                          type="text"
                          value={garment.finish}
                          onChange={e =>
                            handleUpdateSingleWardrobe(
                              garment.id,
                              'finish',
                              e.target.value
                            )
                          }
                          className="w-full bg-[#181B26] border border-[#2B2F3F] rounded-lg px-2.5 py-1.5 text-white outline-hidden focus:border-[#D4AF37]"
                        />
                      </div>

                      <div>
                        <label className="text-[#8A8F9E] block mb-1 font-semibold">
                          Corte / Silueta:
                        </label>
                        <input
                          type="text"
                          value={garment.cut || ''}
                          onChange={e =>
                            handleUpdateSingleWardrobe(
                              garment.id,
                              'cut',
                              e.target.value
                            )
                          }
                          className="w-full bg-[#181B26] border border-[#2B2F3F] rounded-lg px-2.5 py-1.5 text-white outline-hidden focus:border-[#D4AF37]"
                        />
                      </div>

                      <div>
                        <label className="text-[#8A8F9E] block mb-1 font-semibold">
                          Capa de Vestimenta:
                        </label>
                        <select
                          value={garment.layer || 'Base'}
                          onChange={e =>
                            handleUpdateSingleWardrobe(
                              garment.id,
                              'layer',
                              e.target.value
                            )
                          }
                          className="w-full bg-[#181B26] border border-[#2B2F3F] rounded-lg px-2.5 py-1.5 text-white outline-hidden focus:border-[#D4AF37]"
                        >
                          <option value="Ropa Interior / Íntima">
                            Ropa Interior / Íntima
                          </option>
                          <option value="Base">Capa Base</option>
                          <option value="Media">Capa Media</option>
                          <option value="Exterior">Capa Exterior</option>
                          <option value="Capa / Manto">Capa / Manto</option>
                          <option value="Accesorio">Accesorio</option>
                        </select>
                      </div>

                      <div className="flex items-end">
                        <button
                          type="button"
                          onClick={() => handleRemoveWardrobe(garment.id)}
                          className="w-full py-1.5 px-3 rounded-lg bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 border border-rose-800/60 font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Eliminar Prenda</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* FOOTER CONTROLS (if provided by parent) */}
        {footerControls && <div className="mt-8 pt-4">{footerControls}</div>}
      </div>
    </div>
  );
};
