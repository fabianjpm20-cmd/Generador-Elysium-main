import React, { useState, useEffect, useMemo } from 'react';
import { CharacterState, SavedCharacterEntry } from '../types';
import {
  getSavedCharacters,
  deleteCharacterFromLibrary,
  duplicateCharacterInLibrary,
  exportLibraryToJson,
  importLibraryFromJson,
  saveCharacterToLibrary,
  PRELOADED_SEED_CHARACTERS,
  LIBRARY_STORAGE_KEY,
  getCharacterVariantGroups,
  createAlternateVersion,
  unlinkCharacterFromVariantGroup,
  CharacterVariantGroup
} from '../utils/libraryStorage';
import {
  BookMarked,
  Plus,
  Trash2,
  Copy,
  Edit3,
  Shirt,
  Sparkles,
  Download,
  Upload,
  Search,
  Users,
  Shield,
  FileText,
  Clock,
  X,
  CheckCircle,
  ArrowRight,
  RotateCcw,
  Zap,
  Layers,
  LayoutGrid,
  GitBranch,
  Split,
  ChevronRight,
  HelpCircle,
  Scale,
  Check,
  FileUp
} from 'lucide-react';
import { generateCharacterSheetText } from '../utils/characterPromptUtils';
import { parseCharacterData } from '../utils/characterSheetLoader';
import { LoadCharacterSheetModal } from './LoadCharacterSheetModal';

interface State0LibraryProps {
  onLoadCharacter: (charState: CharacterState, targetState?: number) => void;
  onNewCharacter: () => void;
  onOpenQuickCreation?: () => void;
}

export const State0Library: React.FC<State0LibraryProps> = ({
  onLoadCharacter,
  onNewCharacter,
  onOpenQuickCreation
}) => {
  const [characters, setCharacters] = useState<SavedCharacterEntry[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRaceFilter, setSelectedRaceFilter] = useState('ALL');
  const [viewMode, setViewMode] = useState<'grouped' | 'flat'>('grouped');
  
  // Modals & Panels
  const [previewCharacter, setPreviewCharacter] = useState<SavedCharacterEntry | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  
  // Selected active variant in each group
  const [activeGroupVariants, setActiveGroupVariants] = useState<Record<string, string>>({});
  
  // Create alternate version modal
  const [createVariantSource, setCreateVariantSource] = useState<SavedCharacterEntry | null>(null);
  const [variantTypeChoice, setVariantTypeChoice] = useState<'Rol/Vestuario' | 'Futuro' | 'Pasado' | 'Personalizada'>('Rol/Vestuario');
  const [customVariantLabel, setCustomVariantLabel] = useState('');
  const [autoLinkRelationships, setAutoLinkRelationships] = useState(true);

  // Compare versions modal
  const [comparingGroup, setComparingGroup] = useState<CharacterVariantGroup | null>(null);

  // Load / Map Character Sheet Modal
  const [showLoadSheetModal, setShowLoadSheetModal] = useState(false);
  const [loadSheetInitialTab, setLoadSheetInitialTab] = useState<'paste' | 'file' | 'library' | 'seeds'>('paste');

  const refreshList = () => {
    setCharacters(getSavedCharacters());
  };

  useEffect(() => {
    refreshList();
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleDownloadCharacterSheet = (charState: CharacterState) => {
    const sheetText = generateCharacterSheetText(charState);
    const filename = `${(charState.name || 'personaje').toLowerCase().replace(/\s+/g, '_')}_ficha_tecnica.md`;
    const blob = new Blob([sheetText], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showToast(`Ficha técnica "${filename}" descargada.`);
  };

  const handleDownloadCharacterJson = (charState: CharacterState) => {
    const filename = `${(charState.name || 'personaje').toLowerCase().replace(/\s+/g, '_')}_ficha_canonica.json`;
    const blob = new Blob([JSON.stringify(charState, null, 2)], { type: 'application/json;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showToast(`JSON canónico "${filename}" descargado.`);
  };

  const handleCopyCharacterSheet = (charState: CharacterState) => {
    const sheetText = generateCharacterSheetText(charState);
    navigator.clipboard.writeText(sheetText);
    showToast('¡Ficha técnica copiada al portapapeles!');
  };

  const handleDelete = (id: string) => {
    const success = deleteCharacterFromLibrary(id);
    if (success) {
      refreshList();
      showToast('Personaje eliminado de la biblioteca.');
    }
    setDeleteConfirmId(null);
  };

  const handleDuplicate = (id: string) => {
    const dup = duplicateCharacterInLibrary(id);
    if (dup) {
      refreshList();
      showToast(`Personaje duplicado como "${dup.state.name}".`);
    }
  };

  const handleExport = () => {
    const jsonStr = exportLibraryToJson();
    const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `biblioteca_personajes_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showToast('Biblioteca exportada en archivo JSON.');
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        // Try library JSON format first
        const result = importLibraryFromJson(content);
        if (result.success && result.count > 0) {
          refreshList();
          showToast(`¡Se importaron ${result.count} personajes con éxito!`);
        } else {
          // Fallback to single character parser (MD or JSON)
          const singleParsed = parseCharacterData(content);
          if (singleParsed.success && singleParsed.state) {
            saveCharacterToLibrary(singleParsed.state, singleParsed.state.variantLabel || 'Base');
            refreshList();
            showToast(`¡Ficha técnica de "${singleParsed.state.name}" importada y guardada en biblioteca!`);
          } else {
            showToast(`Error al importar: ${result.error || singleParsed.error || 'Formato no reconocido'}`);
          }
        }
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleRestoreSeeds = () => {
    try {
      localStorage.removeItem('CANONICAL_CHARACTER_LIBRARY_V7');
      localStorage.removeItem('CANONICAL_CHARACTER_LIBRARY_V6');
    } catch {}
    localStorage.setItem(LIBRARY_STORAGE_KEY, JSON.stringify(PRELOADED_SEED_CHARACTERS));
    refreshList();
    showToast('Se han restaurado los personajes nativos (Go pip, Xander Vaelith y variantes de Valentín Montclair).');
  };

  const handleExecuteCreateVariant = () => {
    if (!createVariantSource) return;

    const newVariant = createAlternateVersion(
      createVariantSource.id,
      variantTypeChoice,
      customVariantLabel,
      autoLinkRelationships
    );

    if (newVariant) {
      refreshList();
      setCreateVariantSource(null);
      setCustomVariantLabel('');
      showToast(`¡Versión alterna "${newVariant.state.name}" creada y agrupada con éxito!`);
    }
  };

  const handleUnlinkVariant = (charId: string) => {
    const success = unlinkCharacterFromVariantGroup(charId);
    if (success) {
      refreshList();
      showToast('Personaje desvinculado del grupo; ahora es independiente.');
    }
  };

  // Filter characters
  const uniqueRaces = Array.from(new Set(characters.map(c => c.state.raceName || 'Humano'))).filter(Boolean);

  const filteredCharacters = useMemo(() => {
    return characters.filter(entry => {
      const name = (entry.state.name || '').toLowerCase();
      const role = (entry.state.role || '').toLowerCase();
      const race = (entry.state.raceName || '').toLowerCase();
      const subtype = (entry.state.subtype || '').toLowerCase();
      const personality = (entry.state.personality || '').toLowerCase();
      const variant = (entry.variantLabel || entry.state?.variantLabel || '').toLowerCase();
      const query = searchQuery.toLowerCase().trim();

      const matchesQuery = !query || 
        name.includes(query) || 
        role.includes(query) || 
        race.includes(query) || 
        subtype.includes(query) ||
        personality.includes(query) ||
        variant.includes(query);

      const matchesRace = selectedRaceFilter === 'ALL' || (entry.state.raceName || '') === selectedRaceFilter;

      return matchesQuery && matchesRace;
    });
  }, [characters, searchQuery, selectedRaceFilter]);

  // Compute variant groups based on current filtered characters
  const variantGroups: CharacterVariantGroup[] = useMemo(() => {
    return getCharacterVariantGroups(filteredCharacters);
  }, [filteredCharacters]);

  const totalAlternateVariantsCount = characters.filter(c => 
    (c.variantLabel && c.variantLabel.toLowerCase() !== 'base') || 
    (c.state?.variantLabel && c.state.variantLabel.toLowerCase() !== 'base') ||
    c.baseCharacterId ||
    c.state?.baseCharacterId
  ).length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#1A1C22] border border-[#C9A050] text-[#E0E0E0] px-5 py-3 rounded-2xl shadow-2xl flex items-center space-x-3 animate-fade-in">
          <CheckCircle className="w-5 h-5 text-[#C9A050]" />
          <span className="text-sm font-medium">{toastMessage}</span>
        </div>
      )}

      {/* Hero Header */}
      <div className="bg-[#0F1115] border border-[#222222] rounded-3xl p-8 md:p-10 text-[#E0E0E0] shadow-xl mb-8 relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-96 h-96 bg-[#C9A050]/5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <div className="max-w-2xl">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-[#1A1C22] border border-[#2A2D35] text-[#C9A050] text-xs font-medium mb-4">
              <BookMarked className="w-3.5 h-3.5 text-[#C9A050]" />
              <span>ESTADO 0: BIBLIOTECA CENTRAL DE PERSONAJES & VERSIONES</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-serif italic text-[#C9A050] tracking-tight mb-3">
              Biblioteca de Personajes & Versiones Alternas
            </h2>
            <p className="text-[#888888] text-sm md:text-base leading-relaxed">
              Organiza, crea y compara versiones alternas de un mismo personaje (Pasado, Futuro, Rol/Vestuario). Modifica atuendos, sincroniza vínculos temporales recíprocos y carga cualquier variante en el compilador.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {onOpenQuickCreation && (
              <button
                onClick={onOpenQuickCreation}
                className="bg-gradient-to-r from-[#C9A050] to-[#E5C17D] hover:from-[#D4AF37] hover:to-[#F3D59B] text-[#0A0B0E] px-5 py-3 rounded-xl font-bold text-sm flex items-center space-x-2 transition-all shadow-lg cursor-pointer active:scale-95"
              >
                <Zap className="w-4 h-4 fill-current" />
                <span>⚡ Creación Rápida</span>
              </button>
            )}
            <button
              onClick={onNewCharacter}
              className="bg-[#1A1C22] hover:bg-[#252830] border border-[#2A2D35] hover:border-[#C9A050] text-[#E0E0E0] px-5 py-3 rounded-xl font-semibold text-sm flex items-center space-x-2 transition-all shadow-md cursor-pointer"
            >
              <Plus className="w-4 h-4 text-[#C9A050]" />
              <span>Nuevo Personaje (Paso a Paso)</span>
            </button>
            <button
              onClick={() => {
                setLoadSheetInitialTab('paste');
                setShowLoadSheetModal(true);
              }}
              className="bg-[#15171C] hover:bg-[#1A1C22] border border-[#C9A050]/80 hover:border-[#C9A050] text-[#C9A050] px-4 py-3 rounded-xl font-bold text-xs flex items-center space-x-2 transition-all shadow-md cursor-pointer"
              title="Pegar ficha técnica o JSON y mapear automáticamente a los Estados 1 al 6"
            >
              <FileText className="w-4 h-4 text-[#C9A050]" />
              <span>📋 Pegar Ficha o JSON</span>
            </button>
            <button
              onClick={() => {
                setLoadSheetInitialTab('file');
                setShowLoadSheetModal(true);
              }}
              className="bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050] text-[#E0E0E0] px-4 py-3 rounded-xl font-semibold text-xs flex items-center space-x-2 transition-all shadow-md cursor-pointer"
              title="Cargar archivo .md, .json o .txt con asistente de mapeo a los Estados"
            >
              <FileUp className="w-4 h-4 text-[#C9A050]" />
              <span>📁 Cargar Archivo (.md / .json)</span>
            </button>
            <div className="flex gap-2">
              <button
                onClick={handleExport}
                className="bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] hover:border-[#888888] text-[#E0E0E0] px-4 py-3 rounded-xl text-xs font-medium flex items-center space-x-2 transition-all cursor-pointer"
                title="Exportar toda la biblioteca a un archivo JSON de respaldo"
              >
                <Download className="w-4 h-4 text-[#C9A050]" />
                <span>Exportar Todo (.json)</span>
              </button>
              <label className="bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] hover:border-[#888888] text-[#E0E0E0] px-3.5 py-3 rounded-xl text-xs font-medium flex items-center space-x-1.5 transition-all cursor-pointer" title="Importación rápida directa de archivo">
                <Upload className="w-4 h-4 text-[#C9A050]" />
                <span className="hidden sm:inline">Rápido</span>
                <input
                  type="file"
                  accept=".json,.md,.txt"
                  onChange={handleImportFile}
                  className="hidden"
                />
              </label>
            </div>
          </div>
        </div>
      </div>

      {/* Filter and View Mode Toolbar */}
      <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-4 mb-8 flex flex-col md:flex-row gap-4 justify-between items-center">
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 text-[#888888] absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar por nombre, rol, raza, variante (ej: Pasado, Futuro)..."
            className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl pl-10 pr-4 py-2 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050] transition-colors"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-[#888888] hover:text-[#E0E0E0]"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto justify-between md:justify-end">
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#888888]">Raza:</span>
            <select
              value={selectedRaceFilter}
              onChange={(e) => setSelectedRaceFilter(e.target.value)}
              className="bg-[#15171C] border border-[#2A2D35] text-xs text-[#E0E0E0] rounded-xl px-3 py-2 outline-none focus:border-[#C9A050]"
            >
              <option value="ALL">Todas las Razas ({characters.length})</option>
              {uniqueRaces.map(r => (
                <option key={r} value={r}>{r}</option>
              ))}
            </select>
          </div>

          {/* View Mode Toggle */}
          <div className="flex items-center p-1 bg-[#15171C] border border-[#2A2D35] rounded-xl">
            <button
              onClick={() => setViewMode('grouped')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all cursor-pointer ${
                viewMode === 'grouped'
                  ? 'bg-[#C9A050] text-[#0A0B0E] shadow-sm'
                  : 'text-[#888888] hover:text-[#E0E0E0]'
              }`}
              title="Vista agrupada por personaje y sus versiones alternas"
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Agrupado por Personaje</span>
            </button>
            <button
              onClick={() => setViewMode('flat')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all cursor-pointer ${
                viewMode === 'flat'
                  ? 'bg-[#C9A050] text-[#0A0B0E] shadow-sm'
                  : 'text-[#888888] hover:text-[#E0E0E0]'
              }`}
              title="Vista plana de cuadrícula individual"
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>Cuadrícula Plana</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Characters List / Groups */}
      {filteredCharacters.length === 0 ? (
        <div className="bg-[#0F1115] border border-[#222222] rounded-3xl p-12 text-center">
          <BookMarked className="w-12 h-12 text-[#444444] mx-auto mb-4" />
          <h3 className="text-lg font-serif italic text-[#C9A050] mb-2">No se encontraron personajes</h3>
          <p className="text-xs text-[#888888] max-w-md mx-auto mb-6">
            {searchQuery || selectedRaceFilter !== 'ALL'
              ? 'No hay personajes que coincidan con los filtros de búsqueda aplicados.'
              : 'Aún no has guardado ningún personaje en tu biblioteca local. ¡Crea el primero o restaura los ejemplos canónicos!'}
          </p>
          <div className="flex justify-center gap-3">
            <button
              onClick={onNewCharacter}
              className="bg-[#C9A050] text-[#0A0B0E] px-5 py-2.5 rounded-xl text-xs font-semibold flex items-center space-x-2"
            >
              <Plus className="w-4 h-4" />
              <span>Crear Primer Personaje</span>
            </button>
            <button
              onClick={handleRestoreSeeds}
              className="bg-[#15171C] border border-[#2A2D35] text-[#C9A050] px-4 py-2.5 rounded-xl text-xs font-medium flex items-center space-x-2 hover:bg-[#1A1C22]"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Restaurar Muestra con Versiones</span>
            </button>
          </div>
        </div>
      ) : viewMode === 'grouped' ? (
        /* =========================================================================
           GROUPED VIEW: Show characters organized by Base Character + Alternate Versions Tabs
           ========================================================================= */
        <div className="space-y-8">
          {variantGroups.map((group) => {
            const activeId = activeGroupVariants[group.groupId] || group.baseCharacter.id;
            const activeEntry = group.allEntries.find(e => e.id === activeId) || group.baseCharacter;
            const activeChar = activeEntry.state;
            const isMultiVariant = group.allEntries.length > 1;

            const wardrobeCount = (activeChar.wardrobes || []).filter(w => w && w.name).length;
            const weaponsCount = (activeChar.equipment?.weapons || []).length;
            const relsCount = (activeChar.background?.relationships || []).length;
            const isDeleting = deleteConfirmId === activeEntry.id;

            return (
              <div
                key={group.groupId}
                className="bg-[#0F1115] border border-[#222222] hover:border-[#C9A050]/40 rounded-3xl p-6 md:p-8 transition-all shadow-lg relative overflow-hidden"
              >
                {/* Background glow */}
                <div className="absolute right-0 top-0 w-80 h-80 bg-[#C9A050]/5 rounded-full blur-3xl pointer-events-none"></div>

                {/* Group Header & Actions */}
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 pb-6 border-b border-[#222222]">
                  <div className="flex items-center space-x-3.5">
                    <div className="w-10 h-10 rounded-2xl bg-[#1A1C22] border border-[#C9A050]/40 flex items-center justify-center text-[#C9A050] font-serif font-bold text-lg shadow-xs">
                      {group.groupName[0] || 'P'}
                    </div>
                    <div>
                      <div className="flex items-center gap-2.5 flex-wrap">
                        <h3 className="text-xl font-serif italic font-bold text-[#E0E0E0]">
                          {group.groupName}
                        </h3>
                        {isMultiVariant ? (
                          <span className="px-2.5 py-0.5 rounded-full bg-[#1A1C22] border border-[#C9A050]/50 text-[#C9A050] text-[11px] font-mono font-semibold flex items-center gap-1">
                            <GitBranch className="w-3 h-3 text-[#C9A050]" />
                            <span>{group.allEntries.length} Versiones Alternas</span>
                          </span>
                        ) : (
                          <span className="px-2.5 py-0.5 rounded-full bg-[#15171C] border border-[#2A2D35] text-[#888888] text-[10px] font-mono">
                            Personaje Individual
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-[#888888] mt-0.5">
                        Raza: <span className="text-[#AAAAAA]">{group.baseCharacter.state.raceName || 'Humano'}</span> • Arquetipo: <span className="text-[#C9A050]">{group.baseCharacter.state.archetype || 'Genérico'}</span>
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 flex-wrap">
                    {isMultiVariant && (
                      <button
                        onClick={() => setComparingGroup(group)}
                        className="bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050] text-[#E0E0E0] hover:text-[#C9A050] px-3.5 py-2 rounded-xl text-xs font-medium flex items-center space-x-1.5 transition-all cursor-pointer shadow-xs"
                        title="Comparar atributos, trasfondo y vestuarios de todas las versiones"
                      >
                        <Scale className="w-3.5 h-3.5 text-[#C9A050]" />
                        <span>Comparar Versiones</span>
                      </button>
                    )}
                    <button
                      onClick={() => {
                        setCreateVariantSource(activeEntry);
                        setVariantTypeChoice('Rol/Vestuario');
                      }}
                      className="bg-[#1A1C22] hover:bg-[#252830] border border-[#C9A050]/60 text-[#C9A050] hover:text-[#E0E0E0] px-3.5 py-2 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all cursor-pointer shadow-xs"
                      title="Crear una versión alterna (Pasado, Futuro, Rol/Vestuario) basada en este personaje"
                    >
                      <Plus className="w-3.5 h-3.5 text-[#C9A050]" />
                      <span>+ Crear Versión Alterna</span>
                    </button>
                  </div>
                </div>

                {/* Version Selector Tabs */}
                <div className="py-4 flex items-center gap-2 overflow-x-auto border-b border-[#1A1C22] scrollbar-none">
                  <span className="text-[11px] font-mono text-[#888888] uppercase pr-2 flex items-center gap-1 shrink-0">
                    <Split className="w-3.5 h-3.5 text-[#C9A050]" />
                    <span>Versiones:</span>
                  </span>

                  {group.allEntries.map((entry) => {
                    const isSelected = entry.id === activeEntry.id;
                    const label = entry.variantLabel || entry.state?.variantLabel || 'Base';
                    const isBase = label.toLowerCase() === 'base' || (!entry.baseCharacterId && !entry.state?.baseCharacterId);
                    
                    let badgeColor = 'border-[#2A2D35] text-[#AAAAAA]';
                    let icon = '🎭';
                    if (isBase) {
                      icon = '👑';
                      badgeColor = isSelected ? 'border-[#C9A050] bg-[#C9A050] text-[#0A0B0E]' : 'border-[#C9A050]/40 text-[#C9A050] bg-[#15171C]';
                    } else if (label.toLowerCase().includes('futuro')) {
                      icon = '🔮';
                      badgeColor = isSelected ? 'border-purple-500 bg-purple-900/60 text-purple-200' : 'border-purple-500/40 text-purple-300 bg-[#15171C]';
                    } else if (label.toLowerCase().includes('pasado')) {
                      icon = '⏳';
                      badgeColor = isSelected ? 'border-blue-500 bg-blue-900/60 text-blue-200' : 'border-blue-500/40 text-blue-300 bg-[#15171C]';
                    } else if (label.toLowerCase().includes('rol') || label.toLowerCase().includes('vestuario')) {
                      icon = '👗';
                      badgeColor = isSelected ? 'border-emerald-500 bg-emerald-900/60 text-emerald-200' : 'border-emerald-500/40 text-emerald-300 bg-[#15171C]';
                    } else {
                      icon = '✨';
                      badgeColor = isSelected ? 'border-[#C9A050] bg-[#C9A050] text-[#0A0B0E]' : 'border-[#2A2D35] text-[#AAAAAA] bg-[#15171C]';
                    }

                    return (
                      <button
                        key={entry.id}
                        type="button"
                        onClick={() => setActiveGroupVariants(p => ({ ...p, [group.groupId]: entry.id }))}
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold border flex items-center space-x-1.5 transition-all cursor-pointer shrink-0 ${badgeColor} ${
                          isSelected ? 'shadow-md scale-102' : 'hover:border-[#C9A050]/60'
                        }`}
                      >
                        <span>{icon}</span>
                        <span>{label}</span>
                        <span className="text-[10px] opacity-75 font-mono">({entry.state.role ? entry.state.role.split(' ')[0] : 'Rol'})</span>
                      </button>
                    );
                  })}
                </div>

                {/* Active Version Main Details View */}
                <div className="pt-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
                  {/* Left Column: Avatar and Key Badges */}
                  <div className="lg:col-span-4 flex flex-col items-center sm:flex-row lg:flex-col gap-4 text-center sm:text-left lg:text-center">
                    {activeEntry.thumbnailUrl ? (
                      <img
                        src={activeEntry.thumbnailUrl}
                        alt={activeChar.name}
                        className="w-36 h-36 md:w-44 md:h-44 rounded-2xl object-cover border-2 border-[#C9A050]/40 shadow-xl"
                      />
                    ) : (
                      <div className="w-36 h-36 md:w-44 md:h-44 rounded-2xl bg-gradient-to-br from-[#1A1C22] to-[#252830] border border-[#2A2D35] flex items-center justify-center text-[#C9A050] font-serif font-bold text-4xl shadow-xl">
                        {(activeChar.name || 'P')[0]}
                      </div>
                    )}

                    <div className="space-y-1.5 w-full">
                      <div className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full bg-[#15171C] border border-[#C9A050]/40 text-[#C9A050] text-[11px] font-mono font-bold">
                        <span>🏷️ Versión: {activeEntry.variantLabel || activeChar.variantLabel || 'Base'}</span>
                      </div>
                      <h4 className="text-lg font-serif italic text-[#E0E0E0] font-bold">
                        {activeChar.name}
                      </h4>
                      <p className="text-xs text-[#C9A050] font-mono">
                        {activeChar.role || 'Rol Sin Definir'}
                      </p>
                      <p className="text-[11px] text-[#888888]">
                        {activeChar.anatomy?.sexBase?.replace(/^\d+\s*/, '')} • {activeChar.anatomy?.age || 'Edad estándar'}
                      </p>
                    </div>
                  </div>

                  {/* Middle Column: Metadata, Summary & Relationships */}
                  <div className="lg:col-span-5 space-y-4">
                    {/* Backstory / Synopsis snippet */}
                    <div className="bg-[#15171C] p-3.5 rounded-xl border border-[#2A2D35] space-y-1.5">
                      <span className="text-[10px] uppercase font-mono text-[#888888] block">
                        Trasfondo / Sinopsis de Esta Versión:
                      </span>
                      <p className="text-xs text-[#CCCCCC] italic leading-relaxed line-clamp-3">
                        «{activeChar.background?.backstory || activeChar.background?.motivation || 'Sin trasfondo redactado aún.'}»
                      </p>
                    </div>

                    {/* Personality & Values */}
                    <div>
                      <span className="text-[10px] uppercase font-mono text-[#888888] block mb-1.5">
                        Rasgos de Personalidad & Valores Morales:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {(activeChar.personalityTraits || ['Alegre']).slice(0, 4).map(t => (
                          <span key={t} className="px-2 py-0.5 rounded-lg bg-[#1A1C22] border border-[#2A2D35] text-[10px] text-[#E0E0E0]">
                            {t}
                          </span>
                        ))}
                        {activeChar.background?.coreValues && (
                          <span className="px-2 py-0.5 rounded-lg bg-[#C9A050]/15 border border-[#C9A050]/40 text-[10px] text-[#C9A050] font-medium">
                            ⚖️ {activeChar.background.coreValues.split(',')[0]}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Stats Counters */}
                    <div className="grid grid-cols-3 gap-2 py-2 px-3 rounded-xl bg-[#15171C] border border-[#2A2D35] text-center">
                      <div>
                        <span className="block text-[9px] uppercase font-mono text-[#888888]">Vestuarios</span>
                        <span className="text-xs font-bold text-[#E0E0E0] flex items-center justify-center gap-1">
                          <Shirt className="w-3 h-3 text-[#C9A050]" />
                          {wardrobeCount}
                        </span>
                      </div>
                      <div>
                        <span className="block text-[9px] uppercase font-mono text-[#888888]">Armas / Equipo</span>
                        <span className="text-xs font-bold text-[#E0E0E0] flex items-center justify-center gap-1">
                          <Shield className="w-3 h-3 text-[#C9A050]" />
                          {weaponsCount}
                        </span>
                      </div>
                      <div>
                        <span className="block text-[9px] uppercase font-mono text-[#888888]">Vínculos</span>
                        <span className="text-xs font-bold text-[#E0E0E0] flex items-center justify-center gap-1">
                          <Users className="w-3 h-3 text-[#C9A050]" />
                          {relsCount}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Right Column: Direct Launch & Actions */}
                  <div className="lg:col-span-3 flex flex-col justify-center space-y-2.5 bg-[#15171C] p-4 rounded-2xl border border-[#2A2D35]">
                    <button
                      onClick={() => onLoadCharacter(activeChar, 1)}
                      className="w-full bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] py-2.5 rounded-xl text-xs font-bold flex items-center justify-center space-x-2 transition-all shadow-md cursor-pointer"
                    >
                      <Edit3 className="w-4 h-4" />
                      <span>Cargar & Modificar</span>
                    </button>

                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => onLoadCharacter(activeChar, 3)}
                        className="bg-[#0F1115] hover:bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050] text-[#C9A050] py-2 rounded-xl text-xs font-medium flex items-center justify-center space-x-1 transition-all cursor-pointer"
                        title="Modificar Vestuario de esta versión"
                      >
                        <Shirt className="w-3.5 h-3.5" />
                        <span>Vestuario</span>
                      </button>

                      <button
                        onClick={() => onLoadCharacter(activeChar, 6)}
                        className="bg-[#0F1115] hover:bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050] text-[#E0E0E0] py-2 rounded-xl text-xs font-medium flex items-center justify-center space-x-1 transition-all cursor-pointer"
                        title="Ver y compilar ficha técnica"
                      >
                        <ArrowRight className="w-3.5 h-3.5 text-[#C9A050]" />
                        <span>Compilar</span>
                      </button>
                    </div>

                    <div className="pt-2 border-t border-[#222222] flex flex-wrap items-center justify-between gap-1">
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleDownloadCharacterSheet(activeChar)}
                          className="text-[10px] bg-[#0F1115] hover:bg-[#1A1C22] text-[#AAAAAA] hover:text-[#C9A050] border border-[#2A2D35] px-2 py-1 rounded-md flex items-center gap-1 cursor-pointer"
                          title="Descargar Ficha Técnica (.md)"
                        >
                          <Download className="w-2.5 h-2.5 text-[#C9A050]" />
                          <span>.md</span>
                        </button>
                        <button
                          onClick={() => handleDownloadCharacterJson(activeChar)}
                          className="text-[10px] bg-[#0F1115] hover:bg-[#1A1C22] text-[#AAAAAA] hover:text-[#C9A050] border border-[#2A2D35] px-2 py-1 rounded-md flex items-center gap-1 cursor-pointer"
                          title="Exportar JSON Canónico"
                        >
                          <Download className="w-2.5 h-2.5 text-[#C9A050]" />
                          <span>.json</span>
                        </button>
                        <button
                          onClick={() => handleCopyCharacterSheet(activeChar)}
                          className="text-[10px] bg-[#0F1115] hover:bg-[#1A1C22] text-[#AAAAAA] hover:text-[#C9A050] border border-[#2A2D35] px-2 py-1 rounded-md flex items-center gap-1 cursor-pointer"
                          title="Copiar Ficha al Portapapeles"
                        >
                          <Copy className="w-2.5 h-2.5" />
                          <span>Copiar</span>
                        </button>
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => setPreviewCharacter(activeEntry)}
                          className="text-[11px] text-[#AAAAAA] hover:text-[#C9A050] flex items-center gap-1 p-1.5 rounded-lg hover:bg-[#0F1115] cursor-pointer"
                          title="Ver Ficha Técnica Completa"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          <span>Ficha</span>
                        </button>

                        <button
                          onClick={() => handleDuplicate(activeEntry.id)}
                          className="text-[11px] text-[#AAAAAA] hover:text-[#C9A050] flex items-center gap-1 p-1.5 rounded-lg hover:bg-[#0F1115] cursor-pointer"
                          title="Duplicar esta versión"
                        >
                          <Copy className="w-3.5 h-3.5" />
                          <span>Clonar</span>
                        </button>
                      </div>

                      {isMultiVariant && !activeEntry.variantLabel?.toLowerCase().includes('base') && (
                        <button
                          onClick={() => handleUnlinkVariant(activeEntry.id)}
                          className="text-[11px] text-[#888888] hover:text-amber-400 flex items-center gap-1 p-1.5 rounded-lg hover:bg-[#0F1115] cursor-pointer"
                          title="Separar esta variante para convertirla en un personaje independiente"
                        >
                          <Split className="w-3.5 h-3.5" />
                        </button>
                      )}

                      {isDeleting ? (
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => handleDelete(activeEntry.id)}
                            className="text-[10px] bg-red-600 hover:bg-red-700 text-white px-2 py-1 rounded font-bold cursor-pointer"
                          >
                            Borrar
                          </button>
                          <button
                            onClick={() => setDeleteConfirmId(null)}
                            className="text-[10px] text-[#888888] px-1 py-1 cursor-pointer"
                          >
                            ✕
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => setDeleteConfirmId(activeEntry.id)}
                          className="text-[11px] text-[#888888] hover:text-red-400 p-1.5 rounded-lg hover:bg-[#0F1115] cursor-pointer"
                          title="Eliminar esta versión"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* =========================================================================
           FLAT GRID VIEW: Individual card for each saved entry
           ========================================================================= */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCharacters.map((entry) => {
            const char = entry.state;
            const wardrobeCount = (char.wardrobes || []).filter(w => w && w.name).length;
            const weaponsCount = (char.equipment?.weapons || []).length;
            const relsCount = (char.background?.relationships || []).length;
            const isDeleting = deleteConfirmId === entry.id;
            const variantLabel = entry.variantLabel || char.variantLabel || 'Base';

            return (
              <div
                key={entry.id}
                className="bg-[#0F1115] border border-[#222222] hover:border-[#C9A050]/50 rounded-2xl p-6 flex flex-col justify-between transition-all group shadow-md hover:shadow-xl relative overflow-hidden"
              >
                {/* Accent glow on hover */}
                <div className="absolute -right-8 -top-8 w-28 h-28 bg-[#C9A050]/5 rounded-full blur-2xl group-hover:bg-[#C9A050]/15 transition-all"></div>

                <div>
                  {/* Top Header Card */}
                  <div className="flex items-start justify-between gap-3 mb-4">
                    <div className="flex items-center space-x-3">
                      {entry.thumbnailUrl ? (
                        <img
                          src={entry.thumbnailUrl}
                          alt={char.name}
                          className="w-12 h-12 rounded-xl object-cover border border-[#C9A050]/40 shadow-sm"
                        />
                      ) : (
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#1A1C22] to-[#252830] border border-[#2A2D35] flex items-center justify-center text-[#C9A050] font-bold text-lg">
                          {(char.name || 'P')[0]}
                        </div>
                      )}
                      <div>
                        <h3 className="text-base font-serif italic text-[#E0E0E0] group-hover:text-[#C9A050] transition-colors leading-tight font-bold">
                          {char.name || 'Personaje Sin Nombre'}
                        </h3>
                        <p className="text-[11px] text-[#C9A050] truncate max-w-[180px]">
                          {char.role || 'Rol Sin Definir'}
                        </p>
                      </div>
                    </div>

                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#15171C] border border-[#2A2D35] text-[#C9A050]">
                      {variantLabel}
                    </span>
                  </div>

                  {/* Badges & Meta */}
                  <div className="flex flex-wrap gap-1.5 mb-3">
                    <span className="px-2 py-0.5 rounded-md bg-[#15171C] border border-[#2A2D35] text-[10px] text-[#AAAAAA]">
                      🏛️ {char.raceName || 'Humano'}
                    </span>
                    {char.archetype && char.archetype !== 'Genérico' && (
                      <span className="px-2 py-0.5 rounded-md bg-[#15171C] border border-[#2A2D35] text-[10px] text-[#C9A050]">
                        🎭 {char.archetype}
                      </span>
                    )}
                    {char.styleVisual && (
                      <span className="px-2 py-0.5 rounded-md bg-[#15171C] border border-[#2A2D35] text-[10px] text-[#888888]">
                        🎨 {char.styleVisual}
                      </span>
                    )}
                  </div>

                  {/* Content Counters Bar */}
                  <div className="grid grid-cols-3 gap-2 py-2.5 px-3 rounded-xl bg-[#15171C] border border-[#2A2D35] mb-4 text-center">
                    <div>
                      <span className="block text-[9px] uppercase font-mono text-[#888888]">Prendas</span>
                      <span className="text-xs font-bold text-[#E0E0E0] flex items-center justify-center gap-1">
                        <Shirt className="w-3 h-3 text-[#C9A050]" />
                        {wardrobeCount}
                      </span>
                    </div>
                    <div>
                      <span className="block text-[9px] uppercase font-mono text-[#888888]">Armamento</span>
                      <span className="text-xs font-bold text-[#E0E0E0] flex items-center justify-center gap-1">
                        <Shield className="w-3 h-3 text-[#C9A050]" />
                        {weaponsCount}
                      </span>
                    </div>
                    <div>
                      <span className="block text-[9px] uppercase font-mono text-[#888888]">Vínculos</span>
                      <span className="text-xs font-bold text-[#E0E0E0] flex items-center justify-center gap-1">
                        <Users className="w-3 h-3 text-[#C9A050]" />
                        {relsCount}
                      </span>
                    </div>
                  </div>

                  {/* Last updated timestamp */}
                  <div className="flex items-center text-[10px] text-[#666666] mb-4">
                    <Clock className="w-3 h-3 mr-1" />
                    <span>Guardado: {new Date(entry.updatedAt).toLocaleDateString()}</span>
                  </div>
                </div>

                {/* Card Actions */}
                <div className="pt-3 border-t border-[#222222] space-y-2">
                  <div className="flex gap-2">
                    <button
                      onClick={() => onLoadCharacter(char, 1)}
                      className="flex-1 bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] py-2 rounded-xl text-xs font-bold flex items-center justify-center space-x-1.5 transition-all shadow-xs cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>Cargar</span>
                    </button>
                    <button
                      onClick={() => {
                        setCreateVariantSource(entry);
                        setVariantTypeChoice('Rol/Vestuario');
                      }}
                      className="bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050] text-[#C9A050] px-3 py-2 rounded-xl text-xs font-medium flex items-center justify-center space-x-1 transition-all cursor-pointer"
                      title="Crear versión alterna"
                    >
                      <Split className="w-3.5 h-3.5" />
                      <span>+ Variante</span>
                    </button>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-1 pt-1.5 border-t border-[#222222]">
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleDownloadCharacterSheet(char)}
                        className="text-[10px] bg-[#15171C] hover:bg-[#1A1C22] text-[#AAAAAA] hover:text-[#C9A050] border border-[#2A2D35] px-2 py-1 rounded-md flex items-center gap-1 cursor-pointer"
                        title="Descargar Ficha Técnica (.md)"
                      >
                        <Download className="w-2.5 h-2.5 text-[#C9A050]" />
                        <span>.md</span>
                      </button>
                      <button
                        onClick={() => handleDownloadCharacterJson(char)}
                        className="text-[10px] bg-[#15171C] hover:bg-[#1A1C22] text-[#AAAAAA] hover:text-[#C9A050] border border-[#2A2D35] px-2 py-1 rounded-md flex items-center gap-1 cursor-pointer"
                        title="Exportar JSON Canónico"
                      >
                        <Download className="w-2.5 h-2.5 text-[#C9A050]" />
                        <span>.json</span>
                      </button>
                      <button
                        onClick={() => handleCopyCharacterSheet(char)}
                        className="text-[10px] bg-[#15171C] hover:bg-[#1A1C22] text-[#AAAAAA] hover:text-[#C9A050] border border-[#2A2D35] px-2 py-1 rounded-md flex items-center gap-1 cursor-pointer"
                        title="Copiar Ficha al Portapapeles"
                      >
                        <Copy className="w-2.5 h-2.5" />
                        <span>Copiar</span>
                      </button>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => setPreviewCharacter(entry)}
                        className="text-[11px] text-[#AAAAAA] hover:text-[#C9A050] flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-[#15171C] cursor-pointer"
                        title="Ver Ficha Técnica"
                      >
                        <FileText className="w-3 h-3" />
                        <span>Ficha</span>
                      </button>

                      <button
                        onClick={() => handleDuplicate(entry.id)}
                        className="text-[11px] text-[#AAAAAA] hover:text-[#C9A050] flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-[#15171C] cursor-pointer"
                        title="Clonar"
                      >
                        <Copy className="w-3 h-3" />
                        <span>Clonar</span>
                      </button>
                    </div>

                    {isDeleting ? (
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleDelete(entry.id)}
                          className="text-[10px] bg-red-600 hover:bg-red-700 text-white px-2 py-1 rounded font-bold cursor-pointer"
                        >
                          Confirmar
                        </button>
                        <button
                          onClick={() => setDeleteConfirmId(null)}
                          className="text-[10px] text-[#888888] px-1 py-1 cursor-pointer"
                        >
                          ✕
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setDeleteConfirmId(entry.id)}
                        className="text-[11px] text-[#888888] hover:text-red-400 flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-[#15171C] cursor-pointer"
                        title="Eliminar de la biblioteca"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* =========================================================================
          MODAL: CREATE ALTERNATE VERSION (Rol/Vestuario, Futuro, Pasado, Personalizada)
          ========================================================================= */}
      {createVariantSource && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#0F1115] border border-[#222222] rounded-3xl max-w-xl w-full shadow-2xl overflow-hidden animate-scale-up">
            <div className="p-6 border-b border-[#222222] flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <GitBranch className="w-5 h-5 text-[#C9A050]" />
                <div>
                  <h3 className="text-lg font-serif italic text-[#C9A050] font-bold">
                    Crear Versión Alterna de {createVariantSource.state.name}
                  </h3>
                  <p className="text-xs text-[#888888]">
                    Crea una variante manteniendo coherencia biológica y vinculándola al grupo del personaje.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setCreateVariantSource(null)}
                className="text-[#888888] hover:text-[#E0E0E0] p-1.5 rounded-lg hover:bg-[#1A1C22] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-5 bg-[#15171C]">
              {/* Variant Type Selection Grid */}
              <div>
                <label className="block text-xs font-mono text-[#C9A050] uppercase font-bold mb-2.5">
                  Selecciona el Tipo de Versión Alterna:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* Option 1: Rol / Vestuario */}
                  <button
                    type="button"
                    onClick={() => setVariantTypeChoice('Rol/Vestuario')}
                    className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
                      variantTypeChoice === 'Rol/Vestuario'
                        ? 'bg-[#C9A050]/15 border-[#C9A050] text-[#E0E0E0]'
                        : 'bg-[#0F1115] border-[#2A2D35] text-[#AAAAAA] hover:border-[#C9A050]/50'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-xs text-[#C9A050] flex items-center gap-1.5">
                        👗 Rol / Vestuario
                      </span>
                      {variantTypeChoice === 'Rol/Vestuario' && <Check className="w-3.5 h-3.5 text-[#C9A050]" />}
                    </div>
                    <p className="text-[11px] text-[#888888] leading-tight">
                      Mantiene misma edad y fisionomía, para explorar otra profesión, uniforme o conjunto de batalla.
                    </p>
                  </button>

                  {/* Option 2: Futuro */}
                  <button
                    type="button"
                    onClick={() => setVariantTypeChoice('Futuro')}
                    className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
                      variantTypeChoice === 'Futuro'
                        ? 'bg-purple-900/20 border-purple-500 text-[#E0E0E0]'
                        : 'bg-[#0F1115] border-[#2A2D35] text-[#AAAAAA] hover:border-purple-500/50'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-xs text-purple-300 flex items-center gap-1.5">
                        🔮 Futuro / Veterano(a)
                      </span>
                      {variantTypeChoice === 'Futuro' && <Check className="w-3.5 h-3.5 text-purple-300]" />}
                    </div>
                    <p className="text-[11px] text-[#888888] leading-tight">
                      Ajusta edad a Adulto Maduro (36-50 años), mayor temple, cicatrices y madurez marcial o mágica.
                    </p>
                  </button>

                  {/* Option 3: Pasado */}
                  <button
                    type="button"
                    onClick={() => setVariantTypeChoice('Pasado')}
                    className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
                      variantTypeChoice === 'Pasado'
                        ? 'bg-blue-900/20 border-blue-500 text-[#E0E0E0]'
                        : 'bg-[#0F1115] border-[#2A2D35] text-[#AAAAAA] hover:border-blue-500/50'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-xs text-blue-300 flex items-center gap-1.5">
                        ⏳ Pasado / Aprendiz
                      </span>
                      {variantTypeChoice === 'Pasado' && <Check className="w-3.5 h-3.5 text-blue-300" />}
                    </div>
                    <p className="text-[11px] text-[#888888] leading-tight">
                      Ajusta edad a Juvenil (15-18 años), primeros años de formación, ideales puros y vestimenta de novicio.
                    </p>
                  </button>

                  {/* Option 4: Personalizada */}
                  <button
                    type="button"
                    onClick={() => setVariantTypeChoice('Personalizada')}
                    className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
                      variantTypeChoice === 'Personalizada'
                        ? 'bg-[#C9A050]/15 border-[#C9A050] text-[#E0E0E0]'
                        : 'bg-[#0F1115] border-[#2A2D35] text-[#AAAAAA] hover:border-[#C9A050]/50'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-xs text-[#C9A050] flex items-center gap-1.5">
                        ✨ Personalizada
                      </span>
                      {variantTypeChoice === 'Personalizada' && <Check className="w-3.5 h-3.5 text-[#C9A050]" />}
                    </div>
                    <p className="text-[11px] text-[#888888] leading-tight">
                      Define tu propia etiqueta descriptiva (ej: Emperatriz Carmesí, Demonio Renegado).
                    </p>
                  </button>
                </div>
              </div>

              {/* Custom Label Input if Personalizada */}
              {variantTypeChoice === 'Personalizada' && (
                <div>
                  <label className="block text-xs font-mono text-[#888888] mb-1.5">
                    Etiqueta de la Variante Personalizada:
                  </label>
                  <input
                    type="text"
                    value={customVariantLabel}
                    onChange={(e) => setCustomVariantLabel(e.target.value)}
                    placeholder="Ej: Matriarca Suprema, Versión Sombría, Paladín Dorado..."
                    className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl px-3.5 py-2.5 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050]"
                  />
                </div>
              )}

              {/* Automatic reciprocal relationship linkage toggle */}
              <div className="p-3.5 rounded-xl bg-[#0F1115] border border-[#2A2D35] flex items-start space-x-3">
                <input
                  type="checkbox"
                  id="autolink-toggle"
                  checked={autoLinkRelationships}
                  onChange={(e) => setAutoLinkRelationships(e.target.checked)}
                  className="mt-0.5 h-4 w-4 rounded accent-[#C9A050] bg-[#1A1C22] border-[#2A2D35] cursor-pointer"
                />
                <label htmlFor="autolink-toggle" className="text-xs text-[#CCCCCC] cursor-pointer leading-tight">
                  <strong className="text-[#C9A050] block mb-0.5">Enlazar Vínculos Recíprocos Automáticos (Estado 5.1):</strong>
                  Crea automáticamente la relación correspondiente (ej: «Versión Alterna: Futuro» y «Versión Alterna: Pasado») con sentimientos y opiniones adaptados a su psicología.
                </label>
              </div>
            </div>

            <div className="p-4 border-t border-[#222222] flex justify-end gap-3 bg-[#0F1115]">
              <button
                onClick={() => setCreateVariantSource(null)}
                className="px-4 py-2 rounded-xl text-xs font-medium text-[#888888] hover:text-[#E0E0E0] cursor-pointer"
              >
                Cancelar
              </button>
              <button
                onClick={handleExecuteCreateVariant}
                className="bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] px-5 py-2 rounded-xl text-xs font-bold flex items-center space-x-2 cursor-pointer shadow-md"
              >
                <Plus className="w-4 h-4" />
                <span>Crear y Registrar Variante</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL: COMPARE CHARACTER VERSIONS MATRIX
          ========================================================================= */}
      {comparingGroup && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#0F1115] border border-[#222222] rounded-3xl max-w-5xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-scale-up">
            <div className="p-6 border-b border-[#222222] flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Scale className="w-5 h-5 text-[#C9A050]" />
                <div>
                  <h3 className="text-lg font-serif italic text-[#C9A050] font-bold">
                    Matriz Comparativa: {comparingGroup.groupName}
                  </h3>
                  <p className="text-xs text-[#888888]">
                    Comparación directa de todas las versiones alternas registradas en este grupo.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setComparingGroup(null)}
                className="text-[#888888] hover:text-[#E0E0E0] p-1.5 rounded-lg hover:bg-[#1A1C22] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-x-auto overflow-y-auto flex-1 bg-[#15171C]">
              <div className="grid grid-flow-col auto-cols-[minmax(260px,1fr)] gap-4">
                {comparingGroup.allEntries.map((entry) => {
                  const s = entry.state;
                  const label = entry.variantLabel || s.variantLabel || 'Base';
                  const isBase = label.toLowerCase() === 'base';

                  return (
                    <div
                      key={entry.id}
                      className="bg-[#0F1115] border border-[#2A2D35] rounded-2xl p-5 flex flex-col justify-between space-y-4"
                    >
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                            isBase ? 'bg-[#C9A050]/20 text-[#C9A050] border border-[#C9A050]/40' : 'bg-[#15171C] text-purple-300 border border-purple-500/40'
                          }`}>
                            {label}
                          </span>
                          <span className="text-[10px] text-[#888888] font-mono">
                            {s.raceName}
                          </span>
                        </div>

                        <div className="text-center">
                          {entry.thumbnailUrl ? (
                            <img
                              src={entry.thumbnailUrl}
                              alt={s.name}
                              className="w-20 h-20 rounded-xl object-cover mx-auto border border-[#C9A050]/40 mb-2"
                            />
                          ) : (
                            <div className="w-20 h-20 rounded-xl bg-[#1A1C22] border border-[#2A2D35] flex items-center justify-center text-[#C9A050] font-serif font-bold text-2xl mx-auto mb-2">
                              {(s.name || 'P')[0]}
                            </div>
                          )}
                          <h4 className="font-serif italic font-bold text-sm text-[#E0E0E0]">{s.name}</h4>
                          <p className="text-[11px] text-[#C9A050]">{s.role}</p>
                        </div>

                        <div className="space-y-2 text-xs border-t border-[#222222] pt-3">
                          <div>
                            <span className="text-[10px] text-[#888888] block uppercase font-mono">Edad:</span>
                            <span className="text-[#CCCCCC]">{s.anatomy?.age || 'Estándar'}</span>
                          </div>
                          <div>
                            <span className="text-[10px] text-[#888888] block uppercase font-mono">Rasgos Psicológicos:</span>
                            <span className="text-[#CCCCCC]">{(s.personalityTraits || []).join(', ') || 'Equilibrado'}</span>
                          </div>
                          <div>
                            <span className="text-[10px] text-[#888888] block uppercase font-mono">Valores Morales:</span>
                            <span className="text-[#C9A050]">{s.background?.coreValues || 'No especificados'}</span>
                          </div>
                          <div>
                            <span className="text-[10px] text-[#888888] block uppercase font-mono">Vestuarios ({s.wardrobes?.length || 0}):</span>
                            <span className="text-[#CCCCCC]">{(s.wardrobes || []).map(w => w.name).join(', ') || '1 Conjunto'}</span>
                          </div>
                          <div>
                            <span className="text-[10px] text-[#888888] block uppercase font-mono">Vínculos ({s.background?.relationships?.length || 0}):</span>
                            <span className="text-[#CCCCCC]">
                              {(s.background?.relationships || []).map(r => `${r.targetCharacterName} (${r.relationshipType})`).join('; ') || 'Ninguno'}
                            </span>
                          </div>
                        </div>
                      </div>

                      <button
                        onClick={() => {
                          setComparingGroup(null);
                          onLoadCharacter(s, 1);
                        }}
                        className="w-full bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] py-2 rounded-xl text-xs font-bold flex items-center justify-center space-x-1.5 cursor-pointer shadow-xs"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>Cargar esta versión</span>
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="p-4 border-t border-[#222222] flex justify-end bg-[#0F1115]">
              <button
                onClick={() => setComparingGroup(null)}
                className="px-5 py-2 rounded-xl text-xs font-bold text-[#E0E0E0] bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] cursor-pointer"
              >
                Cerrar Comparación
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL: QUICK VIEW CHARACTER SHEET
          ========================================================================= */}
      {previewCharacter && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#0F1115] border border-[#222222] rounded-3xl max-w-3xl w-full max-h-[85vh] flex flex-col shadow-2xl overflow-hidden animate-scale-up">
            <div className="p-6 border-b border-[#222222] flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <FileText className="w-5 h-5 text-[#C9A050]" />
                <div>
                  <h3 className="text-lg font-serif italic text-[#C9A050] font-bold">
                    Ficha Técnica: {previewCharacter.state.name || 'Personaje'}
                  </h3>
                  <p className="text-xs text-[#888888]">
                    {previewCharacter.state.raceName} — {previewCharacter.state.role} (Versión: {previewCharacter.variantLabel || previewCharacter.state.variantLabel || 'Base'})
                  </p>
                </div>
              </div>
              <button
                onClick={() => setPreviewCharacter(null)}
                className="text-[#888888] hover:text-[#E0E0E0] p-1.5 rounded-lg hover:bg-[#1A1C22] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto font-mono text-xs text-[#CCCCCC] whitespace-pre-wrap leading-relaxed bg-[#15171C] flex-1">
              {generateCharacterSheetText(previewCharacter.state)}
            </div>

            <div className="p-4 border-t border-[#222222] flex flex-wrap items-center justify-between gap-3 bg-[#0F1115]">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleDownloadCharacterSheet(previewCharacter.state)}
                  className="px-3 py-2 bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050] text-[#E0E0E0] rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-all"
                  title="Descargar archivo Markdown"
                >
                  <Download className="w-3.5 h-3.5 text-[#C9A050]" />
                  <span>Descargar .md</span>
                </button>
                <button
                  onClick={() => handleDownloadCharacterJson(previewCharacter.state)}
                  className="px-3 py-2 bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050] text-[#E0E0E0] rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-all"
                  title="Exportar archivo JSON canónico"
                >
                  <Download className="w-3.5 h-3.5 text-[#C9A050]" />
                  <span>Exportar .json</span>
                </button>
                <button
                  onClick={() => handleCopyCharacterSheet(previewCharacter.state)}
                  className="px-3 py-2 bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050] text-[#E0E0E0] rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-all"
                  title="Copiar texto de la ficha al portapapeles"
                >
                  <Copy className="w-3.5 h-3.5 text-[#C9A050]" />
                  <span>Copiar Ficha</span>
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setPreviewCharacter(null)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-[#888888] hover:text-[#E0E0E0] cursor-pointer"
                >
                  Cerrar
                </button>
                <button
                  onClick={() => {
                    const s = previewCharacter.state;
                    setPreviewCharacter(null);
                    onLoadCharacter(s, 1);
                  }}
                  className="bg-[#15171C] hover:bg-[#1A1C22] border border-[#C9A050] text-[#C9A050] px-4 py-2 rounded-xl text-xs font-bold flex items-center space-x-1.5 cursor-pointer shadow-sm transition-all"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Cargar en Estado 1</span>
                </button>
                <button
                  onClick={() => {
                    const s = previewCharacter.state;
                    setPreviewCharacter(null);
                    onLoadCharacter(s, 6);
                  }}
                  className="bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] px-5 py-2 rounded-xl text-xs font-bold flex items-center space-x-2 cursor-pointer shadow-md transition-all"
                >
                  <span>Cargar en Compilador (Estado 6)</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      {/* Load / Map Character Sheet Modal */}
      <LoadCharacterSheetModal
        isOpen={showLoadSheetModal}
        initialTab={loadSheetInitialTab}
        onClose={() => setShowLoadSheetModal(false)}
        onLoadCharacter={(loadedState) => {
          saveCharacterToLibrary(loadedState, loadedState.variantLabel || 'Base');
          refreshList();
          onLoadCharacter(loadedState, 6);
          showToast(`¡Ficha de "${loadedState.name}" mapeada y cargada con éxito!`);
        }}
        onSaveToLibrary={() => {
          refreshList();
        }}
        onNavigateToState={(targetState) => {
          // Handled via onLoadCharacter state routing
        }}
      />
    </div>
  );
};
