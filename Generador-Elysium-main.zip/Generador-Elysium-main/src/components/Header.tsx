import React from 'react';
import { MainScreen } from '../types';
import {
  Sparkles,
  BookMarked,
  Wand2,
  Heart,
  Compass,
  Zap,
  Flame,
  Download
} from 'lucide-react';

interface HeaderProps {
  currentScreen: MainScreen;
  onNavigate: (screen: MainScreen) => void;
  onOpenQuickCreation?: () => void;
  isNsfwEnabled?: boolean;
  onToggleNsfw?: () => void;
  onOpenInstallModal?: () => void;
}

const MAIN_SCREENS: { id: MainScreen; label: string; icon: React.ReactNode; color: string }[] = [
  { id: 'home', label: '1. Inicio', icon: <Compass className="w-4 h-4" />, color: 'text-[#D4AF37]' },
  { id: 'library', label: '2. Biblioteca', icon: <BookMarked className="w-4 h-4" />, color: 'text-amber-400' },
  { id: 'creation', label: '3. Creación', icon: <Wand2 className="w-4 h-4" />, color: 'text-indigo-400' },
  { id: 'interaction', label: '4. Interacción', icon: <Heart className="w-4 h-4 fill-current" />, color: 'text-rose-400' },
];

export const Header: React.FC<HeaderProps> = ({
  currentScreen,
  onNavigate,
  onOpenQuickCreation,
  isNsfwEnabled,
  onToggleNsfw,
  onOpenInstallModal
}) => {
  return (
    <header className="bg-[#0D0F14] border-b border-[#20232B] sticky top-0 z-40 shadow-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Brand / Logo */}
          <div
            className="flex items-center space-x-3 cursor-pointer group"
            onClick={() => onNavigate('home')}
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#C9A050] to-[#E5C17D] flex items-center justify-center text-[#0A0B0E] font-bold text-sm shadow-md group-hover:scale-105 transition-transform">
              <Sparkles className="w-5 h-5 text-black" />
            </div>
            <div>
              <h1 className="text-xl font-serif italic text-[#F3F4F6] tracking-tight flex items-center gap-2">
                <span className="text-[#D4AF37]">Elysium</span>
                <span className="text-[10px] uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-[#181A22] border border-[#2B2F3C] text-[#A0A5B5] font-sans not-italic hidden sm:inline-block">
                  Simulador de Vínculo & Rol
                </span>
              </h1>
            </div>
          </div>

          {/* Center 4 Main Screens Tabs */}
          <nav className="hidden md:flex items-center space-x-1.5 bg-[#14161E] p-1.5 rounded-2xl border border-[#262934]">
            {MAIN_SCREENS.map(screen => {
              const isActive = currentScreen === screen.id;
              return (
                <button
                  key={screen.id}
                  type="button"
                  onClick={() => onNavigate(screen.id)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                    isActive
                      ? 'bg-[#1F2330] text-[#F3F4F6] border border-[#3E4354] shadow-md'
                      : 'text-[#8A8F9E] hover:text-[#E0E0E0] hover:bg-[#1A1C24]'
                  }`}
                >
                  <span className={screen.color}>{screen.icon}</span>
                  <span>{screen.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Quick CTAs (Install App, R+18 Toggle & Quick Creation) */}
          <div className="flex items-center space-x-2">
            {onOpenInstallModal && (
              <button
                type="button"
                onClick={onOpenInstallModal}
                className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-[#151722] hover:bg-[#1E2230] border border-[#2A2E40] hover:border-[#C9A050]/60 text-white font-bold text-xs shadow-md transition-all cursor-pointer active:scale-95 shrink-0"
                title="Descargar e instalar la aplicación para PC y Móvil (Funciona 100% Offline)"
              >
                <Download className="w-4 h-4 text-[#C9A050]" />
                <span className="hidden sm:inline">Instalar App</span>
                <span className="sm:hidden">App</span>
              </button>
            )}

            {onToggleNsfw && (
              <button
                type="button"
                onClick={onToggleNsfw}
                className={`flex items-center space-x-1.5 px-3 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer shadow-xs ${
                  isNsfwEnabled
                    ? 'bg-rose-950/70 border-rose-600 text-rose-300 hover:bg-rose-900/80 shadow-rose-950/50'
                    : 'bg-[#15171C] border-[#2D3039] text-[#8A8F9E] hover:text-[#E0E0E0] hover:border-rose-700/50'
                }`}
                title="Activar o desactivar opciones R+18"
              >
                <Flame className={`w-4 h-4 ${isNsfwEnabled ? 'text-rose-400 fill-current animate-pulse' : 'text-[#8A8F9E]'}`} />
                <span className="hidden sm:inline">{isNsfwEnabled ? 'R+18 Activo' : 'Modo R+18'}</span>
              </button>
            )}

            {onOpenQuickCreation && (
              <button
                type="button"
                onClick={onOpenQuickCreation}
                className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#C9A050] to-[#E5C17D] hover:from-[#D4AF37] hover:to-[#F3D59B] text-[#0A0B0E] font-bold text-xs shadow-md transition-all cursor-pointer active:scale-95 shrink-0"
                title="Abrir menú de creación rápida"
              >
                <Zap className="w-4 h-4 fill-current" />
                <span className="hidden sm:inline">⚡ Rápido</span>
              </button>
            )}
          </div>
        </div>

        {/* Mobile Tab Bar */}
        <div className="flex md:hidden items-center py-2.5 border-t border-[#20232B] overflow-x-auto space-x-2 scrollbar-none">
          {MAIN_SCREENS.map(screen => {
            const isActive = currentScreen === screen.id;
            return (
              <button
                key={screen.id}
                type="button"
                onClick={() => onNavigate(screen.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-1.5 cursor-pointer shrink-0 transition-all ${
                  isActive
                    ? 'bg-[#1F2330] text-[#F3F4F6] border border-[#3E4354]'
                    : 'text-[#8A8F9E] hover:text-[#E0E0E0]'
                }`}
              >
                <span className={screen.color}>{screen.icon}</span>
                <span>{screen.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
