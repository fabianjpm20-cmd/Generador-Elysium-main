import React, { useState, useEffect } from 'react';
import { CharacterState, CharacterRelationship, AdvancedCustomization } from '../types';
import {
  CHARACTER_ARCHETYPES,
  RELATIONSHIP_TYPES,
  FEELINGS_TOWARDS_SUGGESTIONS,
  OPINION_ON_SUGGESTIONS,
  INTERACTION_DYNAMICS_SUGGESTIONS,
  VOICE_TONES,
  SPEECH_STYLES,
  CATCHPHRASES_SUGGESTIONS,
  SKILLS_CATEGORIES,
  HABITS_AND_MANNERISMS_POOL,
  SUGGESTED_FATAL_FLAWS,
  FATAL_FLAW_CATEGORIES,
  getRoleBackgroundData,
  RoleRelationshipSuggestion
} from '../data';
import {
  TRAIT_CATEGORIES,
  CORE_VALUE_CATEGORIES,
  ARCHETYPE_PRESETS
} from '../data/backgroundPresetsEngine';
import {
  getDynamicFeelingsSuggestions,
  getDynamicOpinionSuggestions,
  generateArchetypeAdaptedBackground,
  analyzePersonalityAndValues
} from '../utils/dynamicBackgroundEngine';
import { getSavedCharacters } from '../utils/libraryStorage';
import { INTIMATE_PERSONALITIES } from '../data/nsfwData';
import {
  BookOpen,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  User,
  Dices,
  Shield,
  Heart,
  Users,
  Plus,
  Trash2,
  Edit3,
  Mic,
  MessageSquare,
  Zap,
  Check,
  Award,
  Flame,
  Swords,
  Crown,
  MessageCircle,
  Wand2,
  RefreshCw,
  Compass,
  Scale,
  Globe,
  Flag,
  AlertTriangle,
  X,
  Search,
  Eye,
  Copy
} from 'lucide-react';
import { InfoTooltip } from './ui/InfoTooltip';
import { NarrativeBackgroundSuite } from './narrative/NarrativeBackgroundSuite';
import {
  formatBackgroundCanonicalDescription,
  generateCharacterSheetText
} from '../utils/characterPromptUtils';

interface State5Props {
  state: CharacterState;
  setState: React.Dispatch<React.SetStateAction<CharacterState>>;
  onNext: () => void;
  onBack: () => void;
}

const NAME_POOLS = {
  firstNames: [
    'Aeloria', 'Kaelen', 'Lyra', 'Valerius', 'Seraphina', 'Dante', 'Elysia', 'Ragnar',
    'Morrigan', 'Zephyr', 'Rowan', 'Sylas', 'Isolde', 'Caspian', 'Vesper', 'Thalor',
    'Kaelitha', 'Zarek', 'Aurelius', 'Lyanna', 'Draeven', 'Althea', 'Noctis', 'Elowen',
    'Fenris', 'Sariel', 'Gideon', 'Mira', 'Balthazar', 'Lilith', 'Ronan', 'Celeste'
  ],
  epithets: [
    'de la Rosa Negra', 'Cazador de Sombras', 'el Indómito', 'del Valle Plateado',
    'Corazón de Hierro', 'del Crepúsculo', 'la Espada Carmesí', 'de Luminaria',
    'el Errante', 'de las Cenizas', 'Vane', 'Frostwhisper', 'Stormbringer', 'Nightshade'
  ]
};

const TRAITS_POOL = [
  'Alegre', 'Tímido', 'Carismático', 'Agresivo', 'Rebelde', 'Serio',
  'Melancólico', 'Enérgico', 'Estoico', 'Apático', 'Ambicioso', 'Compasivo',
  'Cínico', 'Astuto', 'Valiente', 'Pragmático', 'Idealista', 'Impulsivo',
  'Calmado', 'Sarcástico', 'Leal', 'Solitario', 'Perfeccionista', 'Hedonista',
  'Misterioso', 'Protector', 'Arrogante', 'Humilde', 'Curioso', 'Audaz',
  'Calculador', 'Seductor', 'Teatral', 'Neurótico', 'Soñador', 'Meticuloso',
  'Intrépido', 'Flemático', 'Vengativo', 'Excéntrico', 'Maligno', 'Noble'
];

const CORE_VALUES_POOL = [
  'Honor', 'Lealtad', 'Libertad', 'Justicia', 'Verdad', 'Poder',
  'Venganza', 'Supervivencia', 'Conocimiento', 'Amistad', 'Orden',
  'Caos', 'Redención', 'Familia', 'Gloria', 'Paz', 'Independencia', 'Deber',
  'Equilibrio Cósmico', 'Disciplina Férrea', 'Instinto Salvaje',
  'Armonía Espiritual', 'Ambición Desmedida', 'Soberanía Individual', 'Destino Ineludible',
  'Protección del Débil', 'Innovación Tecnológica', 'Legado Inmortal'
];

export const RHYTHMIC_MOCKING_HABITS = [
  'Baila y tararea melodías al andar, sacudiendo su cola para presumir sus colores pastel',
  'Se ajusta la máscara de cráneo animal sobre la coronilla cuando adopta una pose desafiante',
  'Señala con picardía y saca la lengua en son de broma cuando alguien se sonroja al mirarle',
  'Danza al ritmo de pisadas descalzas sobre la arena mientras hace tintinear sus tobilleras y cascabeles',
  'Sonríe con picardía ladeando las orejas y guiñando un ojo mientras provoca al rival («¡Atrápame si puedes!»)',
  'Sacude y esponja sus colas de colores pastel al recibir cumplidos con fingida arrogancia'
];

export const FELINE_URBAN_HABITS = [
  'Alza una mano flexionando los dedos para mostrar sus almohadillas dérmicas haciendo un saludo felino juguetón («Nya~»)',
  'Se sienta sobre pupitres o mesas balanceando las piernas mientras ladea la cabeza con curiosidad traviesa',
  'Cruza los brazos dejando caer su chaqueta sobre los hombros mientras hace un puchero desafiante'
];

export const State5Background: React.FC<State5Props> = ({ state, setState, onNext, onBack }) => {
  const [customTraitInput, setCustomTraitInput] = useState('');
  const [customValueInput, setCustomValueInput] = useState('');
  const [customSkillInput, setCustomSkillInput] = useState('');
  const [customHabitInput, setCustomHabitInput] = useState('');
  const [customFatalFlawInput, setCustomFatalFlawInput] = useState('');
  const [selectedFatalFlawCategory, setSelectedFatalFlawCategory] = useState<string>('Todos');
  const [fatalFlawSearchQuery, setFatalFlawSearchQuery] = useState<string>('');
  const [isAILoading, setIsAILoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);

  // New relationship form state
  const [newRelCharId, setNewRelCharId] = useState('');
  const [newRelCharName, setNewRelCharName] = useState('');
  const [newRelType, setNewRelType] = useState(RELATIONSHIP_TYPES[0]);
  const [newRelDynamic, setNewRelDynamic] = useState(INTERACTION_DYNAMICS_SUGGESTIONS[0]);
  const [newRelFeelings, setNewRelFeelings] = useState('');
  const [newRelOpinion, setNewRelOpinion] = useState('');
  const [showAddRelForm, setShowAddRelForm] = useState(false);
  const [showArchetypeAdaptivePanel, setShowArchetypeAdaptivePanel] = useState(true);

  // Editing relationship state
  const [editingRelId, setEditingRelId] = useState<string | null>(null);
  const [editRelCharId, setEditRelCharId] = useState('');
  const [editRelCharName, setEditRelCharName] = useState('');
  const [editRelType, setEditRelType] = useState(RELATIONSHIP_TYPES[0]);
  const [editRelDynamic, setEditRelDynamic] = useState(INTERACTION_DYNAMICS_SUGGESTIONS[0]);
  const [editRelFeelings, setEditRelFeelings] = useState('');
  const [editRelOpinion, setEditRelOpinion] = useState('');

  // Category filters for Presets, Habits and Advanced options
  const [selectedPresetCategory, setSelectedPresetCategory] = useState<string>('Todos');
  const [selectedHabitsCategory, setSelectedHabitsCategory] = useState<string>('Todos');
  const [selectedVoiceCategory, setSelectedVoiceCategory] = useState<string>('Todos');

  // Saved characters from library
  const [libraryCharacters, setLibraryCharacters] = useState<{ id: string; name: string; role: string; raceName: string; variantLabel?: string; variantGroupId?: string }[]>([]);

  // Canonical description preview state
  const [canonicalPreviewMode, setCanonicalPreviewMode] = useState<'background' | 'fullSheet'>('background');
  const [copiedCanonical, setCopiedCanonical] = useState(false);

  const handleCopyCanonical = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCanonical(true);
    setTimeout(() => setCopiedCanonical(false), 2000);
  };

  // Canonical Role Background Data lookup
  const roleProfile = getRoleBackgroundData(state.role);
  const currentRoleName = state.role || 'Rol Canónico';

  // Dynamic Archetype and Personality Engine Modulation
  const dynamicModulation = generateArchetypeAdaptedBackground(
    state.role || 'Civil Genérico',
    state.archetype || 'Genérico',
    state.personalityTraits || [],
    state.background?.coreValues
  );

  const personalitySummary = dynamicModulation.personalitySummary || analyzePersonalityAndValues(
    state.personalityTraits || [],
    state.background?.coreValues || ''
  );

  useEffect(() => {
    const list = getSavedCharacters();
    setLibraryCharacters(list.map(e => ({
      id: e.id,
      name: e.state.name || 'Sin Nombre',
      role: e.state.role || 'Rol',
      raceName: e.state.raceName || 'Humano',
      variantLabel: e.variantLabel || e.state.variantLabel || 'Base',
      variantGroupId: e.variantGroupId || e.state.variantGroupId
    })).filter(c => c.id !== state.id));
  }, [state.id]);

  // Ensure advancedCustomization object is initialized
  const adv: AdvancedCustomization = state.background?.advancedCustomization || {
    voiceTone: dynamicModulation.adaptedVoiceTone || VOICE_TONES[0],
    speechStyle: dynamicModulation.adaptedSpeechStyle || SPEECH_STYLES[0],
    catchphrasesOrIdioms: dynamicModulation.adaptedCatchphrase || CATCHPHRASES_SUGGESTIONS[0],
    skills: dynamicModulation.synergisticSkills.slice(0, 3).map(s => s.skill),
    habitsAndMannerisms: dynamicModulation.adaptedHabits.slice(0, 2),
    specificInteractions: {
      withAuthority: dynamicModulation.adaptedBehaviors.withAuthority,
      withPeers: dynamicModulation.adaptedBehaviors.withPeers,
      withFriends: dynamicModulation.adaptedBehaviors.withFriends,
      withSubordinates: dynamicModulation.adaptedBehaviors.withSubordinates,
      withStrangers: dynamicModulation.adaptedBehaviors.withStrangers,
      withEnemies: dynamicModulation.adaptedBehaviors.withEnemies
    }
  };

  const updateAdv = (updater: (prev: AdvancedCustomization) => AdvancedCustomization) => {
    setState(p => {
      const currentAdv = p.background?.advancedCustomization || adv;
      return {
        ...p,
        background: {
          ...p.background,
          advancedCustomization: updater(currentAdv)
        }
      };
    });
  };

  const handleAddSuggestedRelationship = (sug: RoleRelationshipSuggestion & { synergyTags?: string[] }) => {
    const newRel: CharacterRelationship = {
      id: `rel-sug-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      targetCharacterName: sug.targetCharacterName,
      relationshipType: sug.relationshipType,
      interactionDynamic: sug.interactionDynamic,
      feelingsTowards: sug.feelingsTowards,
      opinionOn: sug.opinionOn
    };

    setState(prev => {
      const currentRels = prev.background?.relationships || [];
      if (currentRels.some(r => r.targetCharacterName === sug.targetCharacterName && r.relationshipType === sug.relationshipType)) {
        return prev;
      }
      return {
        ...prev,
        background: {
          ...prev.background,
          relationships: [...currentRels, newRel]
        }
      };
    });
  };

  // Adapts existing relationships' feelings and opinions according to active personality & core values
  const handleAdaptExistingRelationshipsToTraits = () => {
    setState(prev => {
      const currentRels = prev.background?.relationships || [];
      if (currentRels.length === 0) return prev;

      const updatedRels = currentRels.map(rel => {
        const feelingsPool = getDynamicFeelingsSuggestions(
          rel.relationshipType,
          prev.archetype,
          prev.personalityTraits,
          prev.background?.coreValues
        );
        const opinionPool = getDynamicOpinionSuggestions(
          rel.relationshipType,
          prev.archetype,
          prev.personalityTraits,
          prev.background?.coreValues,
          rel.targetCharacterName
        );

        return {
          ...rel,
          feelingsTowards: feelingsPool[0] || rel.feelingsTowards,
          opinionOn: opinionPool[0] || rel.opinionOn
        };
      });

      return {
        ...prev,
        background: {
          ...prev.background,
          relationships: updatedRels
        }
      };
    });
  };

  const getSelectedFatalFlaws = (): string[] => {
    if (Array.isArray(state.background?.fatalFlaws) && state.background.fatalFlaws.length > 0) {
      return state.background.fatalFlaws;
    }
    if (state.background?.fatalFlawOrVulnerability) {
      const parts = state.background.fatalFlawOrVulnerability
        .split(/\s*\|\s*|\s*;\s*/)
        .map(s => s.trim())
        .filter(Boolean);
      return parts.length > 0 ? parts : [state.background.fatalFlawOrVulnerability.trim()];
    }
    return [];
  };

  const toggleFatalFlaw = (flaw: string) => {
    setState(prev => {
      const bg = prev.background || ({} as any);
      const current = (Array.isArray(bg.fatalFlaws) && bg.fatalFlaws.length > 0)
        ? bg.fatalFlaws
        : (bg.fatalFlawOrVulnerability
            ? bg.fatalFlawOrVulnerability.split(/\s*\|\s*|\s*;\s*/).map(s => s.trim()).filter(Boolean)
            : []);
      const exists = current.includes(flaw);
      const updated = exists ? current.filter(f => f !== flaw) : [...current, flaw];
      return {
        ...prev,
        background: {
          ...bg,
          fatalFlaws: updated,
          fatalFlawOrVulnerability: updated.join(' | ')
        }
      };
    });
  };

  const handleAddCustomFatalFlaw = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const flaw = customFatalFlawInput.trim();
    if (!flaw) return;
    setState(prev => {
      const bg = prev.background || ({} as any);
      const current = (Array.isArray(bg.fatalFlaws) && bg.fatalFlaws.length > 0)
        ? bg.fatalFlaws
        : (bg.fatalFlawOrVulnerability
            ? bg.fatalFlawOrVulnerability.split(/\s*\|\s*|\s*;\s*/).map(s => s.trim()).filter(Boolean)
            : []);
      if (current.includes(flaw)) return prev;
      const updated = [...current, flaw];
      return {
        ...prev,
        background: {
          ...bg,
          fatalFlaws: updated,
          fatalFlawOrVulnerability: updated.join(' | ')
        }
      };
    });
    setCustomFatalFlawInput('');
  };

  const handleRemoveFatalFlaw = (flaw: string) => {
    setState(prev => {
      const bg = prev.background || ({} as any);
      const current = (Array.isArray(bg.fatalFlaws) && bg.fatalFlaws.length > 0)
        ? bg.fatalFlaws
        : (bg.fatalFlawOrVulnerability
            ? bg.fatalFlawOrVulnerability.split(/\s*\|\s*|\s*;\s*/).map(s => s.trim()).filter(Boolean)
            : []);
      const updated = current.filter(f => f !== flaw);
      return {
        ...prev,
        background: {
          ...bg,
          fatalFlaws: updated,
          fatalFlawOrVulnerability: updated.join(' | ')
        }
      };
    });
  };

  const handleClearAllFatalFlaws = () => {
    setState(prev => ({
      ...prev,
      background: {
        ...prev.background,
        fatalFlaws: [],
        fatalFlawOrVulnerability: ''
      }
    }));
  };

  const handleApplyAllRoleSkills = () => {
    updateAdv(prev => {
      const current = prev.skills || [];
      const combined = Array.from(new Set([...current, ...roleProfile.specializedSkills]));
      return { ...prev, skills: combined };
    });
  };

  const handleApplySynergisticSkills = () => {
    updateAdv(prev => {
      const current = prev.skills || [];
      const newSkills = dynamicModulation.synergisticSkills.map(s => s.skill);
      const combined = Array.from(new Set([...current, ...newSkills]));
      return { ...prev, skills: combined };
    });
  };

  const handleApplySynergisticHabits = () => {
    updateAdv(prev => {
      const current = prev.habitsAndMannerisms || [];
      const newHabits = dynamicModulation.suggestedHabits.map(h => h.habit);
      const combined = Array.from(new Set([...current, ...newHabits]));
      return { ...prev, habitsAndMannerisms: combined };
    });
  };

  const handleApplyAllRhythmicHabits = () => {
    updateAdv(prev => {
      const current = prev.habitsAndMannerisms || [];
      const combined = Array.from(new Set([...current, ...RHYTHMIC_MOCKING_HABITS]));
      return { ...prev, habitsAndMannerisms: combined };
    });
  };

  const handleApplyAllFelineUrbanHabits = () => {
    updateAdv(prev => {
      const current = prev.habitsAndMannerisms || [];
      const combined = Array.from(new Set([...current, ...FELINE_URBAN_HABITS]));
      return { ...prev, habitsAndMannerisms: combined };
    });
  };

  const handleApplyRoleBehaviors = () => {
    updateAdv(prev => ({
      ...prev,
      specificInteractions: {
        withAuthority: roleProfile.behaviorByRank.withAuthority,
        withPeers: roleProfile.behaviorByRank.withPeers || 'Camaradería cordial, respeto mutuo y cooperación táctica de igual a igual.',
        withFriends: roleProfile.behaviorByRank.withFriends || 'Confianza absoluta, sinceridad sin armadura y lealtad incondicional.',
        withSubordinates: roleProfile.behaviorByRank.withSubordinates,
        withStrangers: roleProfile.behaviorByRank.withStrangers,
        withEnemies: roleProfile.behaviorByRank.withEnemies
      }
    }));
  };

  const handleApplyArchetypeBehaviors = () => {
    updateAdv(prev => ({
      ...prev,
      specificInteractions: {
        withAuthority: dynamicModulation.adaptedBehaviors.withAuthority,
        withPeers: dynamicModulation.adaptedBehaviors.withPeers,
        withFriends: dynamicModulation.adaptedBehaviors.withFriends,
        withSubordinates: dynamicModulation.adaptedBehaviors.withSubordinates,
        withStrangers: dynamicModulation.adaptedBehaviors.withStrangers,
        withEnemies: dynamicModulation.adaptedBehaviors.withEnemies
      }
    }));
  };

  const handleApplyAllArchetypePersonalization = () => {
    updateAdv(prev => ({
      ...prev,
      voiceTone: dynamicModulation.adaptedVoiceTone || prev.voiceTone,
      speechStyle: dynamicModulation.adaptedSpeechStyle || prev.speechStyle,
      catchphrasesOrIdioms: dynamicModulation.adaptedCatchphrase || prev.catchphrasesOrIdioms,
      skills: Array.from(new Set([...(prev.skills || []), ...dynamicModulation.synergisticSkills.map(s => s.skill)])),
      habitsAndMannerisms: Array.from(new Set([...(prev.habitsAndMannerisms || []), ...dynamicModulation.adaptedHabits])),
      specificInteractions: {
        withAuthority: dynamicModulation.adaptedBehaviors.withAuthority,
        withPeers: dynamicModulation.adaptedBehaviors.withPeers,
        withFriends: dynamicModulation.adaptedBehaviors.withFriends,
        withSubordinates: dynamicModulation.adaptedBehaviors.withSubordinates,
        withStrangers: dynamicModulation.adaptedBehaviors.withStrangers,
        withEnemies: dynamicModulation.adaptedBehaviors.withEnemies
      }
    }));
  };

  const handleApplyRoleVoiceAndSpeech = () => {
    updateAdv(prev => ({
      ...prev,
      voiceTone: roleProfile.recommendedVoiceTone || prev.voiceTone,
      speechStyle: roleProfile.recommendedSpeechStyle || prev.speechStyle,
      catchphrasesOrIdioms: roleProfile.catchphrase || prev.catchphrasesOrIdioms
    }));
  };

  const handleApplyAllRoleHabits = () => {
    updateAdv(prev => {
      const current = prev.habitsAndMannerisms || [];
      const combined = Array.from(new Set([...current, ...roleProfile.habits]));
      return { ...prev, habitsAndMannerisms: combined };
    });
  };

  const generateRandomName = (): string => {
    const fn = NAME_POOLS.firstNames[Math.floor(Math.random() * NAME_POOLS.firstNames.length)];
    const useEpithet = Math.random() > 0.4;
    if (useEpithet) {
      const ep = NAME_POOLS.epithets[Math.floor(Math.random() * NAME_POOLS.epithets.length)];
      return `${fn} ${ep}`;
    }
    return fn;
  };

  const handleSuggestName = () => {
    const newName = generateRandomName();
    setState(p => ({ ...p, name: newName }));
  };

  const toggleTrait = (trait: string) => {
    setState(prev => {
      const current = prev.personalityTraits || [];
      const exists = current.includes(trait);
      const updated = exists ? current.filter(t => t !== trait) : [...current, trait];
      return {
        ...prev,
        personalityTraits: updated,
        personality: updated.join(', ')
      };
    });
  };

  const handleClearAllTraits = () => {
    setState(prev => ({
      ...prev,
      personalityTraits: [],
      personality: ''
    }));
  };

  const handleAddCustomTrait = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customTraitInput.trim()) return;
    const trait = customTraitInput.trim();
    setState(prev => {
      const current = prev.personalityTraits || [];
      if (current.includes(trait)) return prev;
      const updated = [...current, trait];
      return {
        ...prev,
        personalityTraits: updated,
        personality: updated.join(', ')
      };
    });
    setCustomTraitInput('');
  };

  const handleCoreValueSelect = (val: string) => {
    setState(prev => {
      const current = prev.background?.coreValues || '';
      const list = current ? current.split(',').map(s => s.trim()).filter(Boolean) : [];
      const trimmedVal = val.trim();
      const existingIdx = list.findIndex(v => v.toLowerCase() === trimmedVal.toLowerCase());
      if (existingIdx >= 0) {
        const updated = list.filter((_, idx) => idx !== existingIdx);
        return {
          ...prev,
          background: {
            ...prev.background,
            coreValues: updated.join(', ')
          }
        };
      } else {
        list.push(trimmedVal);
        return {
          ...prev,
          background: {
            ...prev.background,
            coreValues: list.join(', ')
          }
        };
      }
    });
  };

  const handleClearAllCoreValues = () => {
    setState(prev => ({
      ...prev,
      background: {
        ...prev.background,
        coreValues: ''
      }
    }));
  };

  const handleAddCustomValue = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customValueInput.trim()) return;
    const val = customValueInput.trim();
    setState(prev => {
      const current = prev.background?.coreValues || '';
      const list = current ? current.split(',').map(s => s.trim()).filter(Boolean) : [];
      if (list.some(v => v.toLowerCase() === val.toLowerCase())) return prev;
      const updatedList = [...list, val];
      return {
        ...prev,
        background: {
          ...prev.background,
          coreValues: updatedList.join(', ')
        }
      };
    });
    setCustomValueInput('');
  };

  // Relationship Management (5.1)
  const handleAddRelationship = () => {
    const finalName = newRelCharName.trim() || (libraryCharacters.find(c => c.id === newRelCharId)?.name) || 'Aliado Anónimo';
    if (!finalName) return;

    const newRel: CharacterRelationship = {
      id: `rel-${Date.now()}`,
      targetCharacterId: newRelCharId || undefined,
      targetCharacterName: finalName,
      relationshipType: newRelType,
      interactionDynamic: newRelDynamic,
      feelingsTowards: newRelFeelings.trim() || undefined,
      opinionOn: newRelOpinion.trim() || undefined
    };

    setState(prev => {
      const currentRels = prev.background?.relationships || [];
      return {
        ...prev,
        background: {
          ...prev.background,
          relationships: [...currentRels, newRel]
        }
      };
    });

    setNewRelCharId('');
    setNewRelCharName('');
    setNewRelFeelings('');
    setNewRelOpinion('');
    setShowAddRelForm(false);
  };

  const handleRemoveRelationship = (relId: string) => {
    if (editingRelId === relId) {
      setEditingRelId(null);
    }
    setState(prev => {
      const currentRels = prev.background?.relationships || [];
      return {
        ...prev,
        background: {
          ...prev.background,
          relationships: currentRels.filter(r => r.id !== relId)
        }
      };
    });
  };

  const handleStartEditRelationship = (rel: CharacterRelationship) => {
    setEditingRelId(rel.id);
    setEditRelCharId(rel.targetCharacterId || '');
    setEditRelCharName(rel.targetCharacterName || '');
    setEditRelType(rel.relationshipType || RELATIONSHIP_TYPES[0]);
    setEditRelDynamic(rel.interactionDynamic || INTERACTION_DYNAMICS_SUGGESTIONS[0]);
    setEditRelFeelings(rel.feelingsTowards || '');
    setEditRelOpinion(rel.opinionOn || '');
  };

  const handleCancelEditRelationship = () => {
    setEditingRelId(null);
    setEditRelCharId('');
    setEditRelCharName('');
    setEditRelType(RELATIONSHIP_TYPES[0]);
    setEditRelDynamic(INTERACTION_DYNAMICS_SUGGESTIONS[0]);
    setEditRelFeelings('');
    setEditRelOpinion('');
  };

  const handleSaveEditRelationship = (relId: string) => {
    const finalName = editRelCharName.trim() || (libraryCharacters.find(c => c.id === editRelCharId)?.name) || 'Aliado Anónimo';
    if (!finalName) return;

    setState(prev => {
      const currentRels = prev.background?.relationships || [];
      return {
        ...prev,
        background: {
          ...prev.background,
          relationships: currentRels.map(r => {
            if (r.id === relId) {
              return {
                ...r,
                targetCharacterId: editRelCharId || undefined,
                targetCharacterName: finalName,
                relationshipType: editRelType || RELATIONSHIP_TYPES[0],
                interactionDynamic: editRelDynamic,
                feelingsTowards: editRelFeelings.trim() || undefined,
                opinionOn: editRelOpinion.trim() || undefined
              };
            }
            return r;
          })
        }
      };
    });

    setEditingRelId(null);
  };

  // Skills & Habits toggles (5.4)
  const toggleSkill = (skill: string) => {
    updateAdv(prev => {
      const current = prev.skills || [];
      const exists = current.includes(skill);
      return {
        ...prev,
        skills: exists ? current.filter(s => s !== skill) : [...current, skill]
      };
    });
  };

  const handleAddCustomSkill = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customSkillInput.trim()) return;
    const skill = customSkillInput.trim();
    updateAdv(prev => {
      const current = prev.skills || [];
      if (current.includes(skill)) return prev;
      return { ...prev, skills: [...current, skill] };
    });
    setCustomSkillInput('');
  };

  const toggleHabit = (habit: string) => {
    updateAdv(prev => {
      const current = prev.habitsAndMannerisms || [];
      const exists = current.includes(habit);
      return {
        ...prev,
        habitsAndMannerisms: exists ? current.filter(h => h !== habit) : [...current, habit]
      };
    });
  };

  const handleAddCustomHabit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customHabitInput.trim()) return;
    const habit = customHabitInput.trim();
    updateAdv(prev => {
      const current = prev.habitsAndMannerisms || [];
      if (current.includes(habit)) return prev;
      return { ...prev, habitsAndMannerisms: [...current, habit] };
    });
    setCustomHabitInput('');
  };

  // Dynamic Generator (Backstory / Motivation / Timeline / Unique Details)
  const handleGenerateDynamicHistory = async () => {
    setIsAILoading(true);
    setAiError(null);
    try {
      const wardrobeSummary = (state.wardrobes && state.wardrobes.length > 0)
        ? state.wardrobes.map(w => `${w.garmentName || 'Prenda'} (${w.primaryFabric || 'tela'} ${w.primaryColor || ''})`).join(', ')
        : 'Atuendo adaptado a su cometido';

      const weaponsSummary = (state.equipment && state.equipment.weapons && state.equipment.weapons.length > 0)
        ? state.equipment.weapons.join(', ')
        : 'Armamento personal';

      const physicalTraits = [
        state.hornsType && state.hornsType !== 'none' ? `Cornamenta: ${state.hornsType}` : null,
        state.wingsType && state.wingsType !== 'none' ? `Alas: ${state.wingsType}` : null,
        state.tailsType && state.tailsType !== 'none' ? `Colas: ${state.tailsType}` : null,
        state.skinAndMarks ? `Piel/Marcas: ${state.skinAndMarks}` : null,
        state.clawsType && state.clawsType !== 'none' ? `Garras: ${state.clawsType}` : null
      ].filter(Boolean).join(', ') || 'Anatomía estándar';

      const response = await fetch('/api/generate-backstory', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: state.name,
          gender: state.gender,
          age: state.age,
          raceName: state.raceName,
          subRace: state.subRace,
          role: state.role,
          subRole: state.subRole,
          hybridRoleTitle: state.hybridRoleTitle,
          nobleTitle: state.nobleTitle,
          archetype: state.archetype,
          personalityTraits: state.personalityTraits,
          coreValues: state.background?.coreValues,
          styleVisual: state.styleVisual,
          homelandOrDomain: state.background?.homelandOrDomain,
          factionOrFaith: state.background?.factionOrFaith,
          fatalFlaws: state.background?.fatalFlaws || (state.background?.fatalFlawOrVulnerability ? [state.background.fatalFlawOrVulnerability] : []),
          physicalDetails: physicalTraits,
          wardrobeSummary,
          equipmentSummary: weaponsSummary,
          userNotes: state.background?.userNarrativeNotes || '',
          narrativeTone: 'Épico & Heroico'
        })
      });

      if (!response.ok) {
        throw new Error('Error al conectar con la API de generación');
      }

      const data = await response.json();
      setState(prev => ({
        ...prev,
        name: prev.name.trim() ? prev.name : (data.name || prev.name),
        background: {
          ...prev.background,
          homelandOrDomain: data.homelandOrDomain || prev.background?.homelandOrDomain,
          factionOrFaith: data.factionOrFaith || prev.background?.factionOrFaith,
          backstory: data.backstory || prev.background?.backstory,
          motivation: data.motivation || prev.background?.motivation,
          secret: data.secret || prev.background?.secret,
          uniqueDetails: (data.uniqueDetails && Array.isArray(data.uniqueDetails) && data.uniqueDetails.length > 0)
            ? data.uniqueDetails
            : prev.background?.uniqueDetails,
          narrativeTimeline: data.timeline ? {
            overview: data.timeline.overview || 'Línea temporal consolidada.',
            thematicArc: data.timeline.thematicArc || 'Arco dramático del personaje.',
            pivotalTurningPoints: data.timeline.pivotalTurningPoints || [],
            milestones: (data.timeline.milestones || []).map((m: any, idx: number) => ({
              id: m.id || `m-${Date.now()}-${idx}`,
              era: m.era || 'Pasado',
              title: m.title || `Hito ${idx + 1}`,
              periodOrAge: m.periodOrAge || 'Período no determinado',
              summary: m.summary || '',
              keyEvents: m.keyEvents || [],
              psychologicalEvolution: m.psychologicalEvolution || ''
            })),
            generatedAt: new Date().toISOString()
          } : prev.background?.narrativeTimeline
        },
        narrativeTimeline: data.timeline ? {
          overview: data.timeline.overview || 'Línea temporal consolidada.',
          thematicArc: data.timeline.thematicArc || 'Arco dramático.',
          pivotalTurningPoints: data.timeline.pivotalTurningPoints || [],
          milestones: (data.timeline.milestones || []).map((m: any, idx: number) => ({
            id: m.id || `m-${Date.now()}-${idx}`,
            era: m.era || 'Pasado',
            title: m.title || `Hito ${idx + 1}`,
            periodOrAge: m.periodOrAge || 'Período no determinado',
            summary: m.summary || '',
            keyEvents: m.keyEvents || [],
            psychologicalEvolution: m.psychologicalEvolution || ''
          })),
          generatedAt: new Date().toISOString()
        } : prev.narrativeTimeline
      }));
    } catch (err: any) {
      console.warn("Fallo API IA:", err);
      setAiError(err.message || 'Error al generar historial dinámico con IA. Se ejecutó la síntesis local.');
      handleGenerateBackstory();
    } finally {
      setIsAILoading(false);
    }
  };

  const handleGenerateBackstory = () => {
    const currentName = state.name.trim() || generateRandomName();
    const cleanRace = state.raceName ? state.raceName.replace(/^[A-Z0-9_]+\s*/i, '').trim() : 'Humano';
    const cleanRole = state.role ? state.role.replace(/^[A-Z0-9_]+\s*/i, '').trim() : 'Aventurero';
    const traits = state.personalityTraits && state.personalityTraits.length > 0 
      ? state.personalityTraits.join(', ') 
      : (state.personality || 'Alegre');
    const coreVals = state.background?.coreValues 
      ? ` Guiado/a por sus valores de ${state.background.coreValues},` 
      : '';
    const archetype = (state.archetype && state.archetype !== 'Genérico') ? state.archetype : '';
    const style = state.styleVisual || 'Fantasía';
    const domain = state.background?.homelandOrDomain || 'Tierras Altas de Solaria';
    const faction = state.background?.factionOrFaith || 'Orden del Fénix Plateado';

    const backstoryOptions = [
      `En los confines de ${domain}, la historia de ${currentName} comenzó bajo la influencia de ${style}. Siendo de linaje ${cleanRace} y manifestando aptitudes de ${cleanRole}, creció bajo la tutela de rigurosos maestros.${coreVals} Con una personalidad forjada en [${traits}]${archetype ? ` y arquetipo ${archetype}` : ''}, consagró su lealtad a ${faction}. Hoy en día recorre el mundo forjando su propio legado.`,
      `Desde las turbulentas fronteras de ${domain}, ${currentName} aprendió a valerse por sí mismo/a desde temprana edad.${coreVals} Siendo un/a ${cleanRace} de espíritu [${traits}], su alianza con ${faction} y su maestría como ${cleanRole} le han ganado el respeto de aliados y el recelo de sus adversarios.`,
      `En las cortes y las sombras de ${domain}, el nombre de ${currentName} resuena con fuerza. Siendo un/a ${cleanRace} consagrado/a a ${faction}, adoptó el rol de ${cleanRole} para desafiar las normas impuestas sobre su destino y proteger a su gente.`
    ];

    const motivationOptions = [
      `Proteger a sus camaradas en ${domain} y demostrar que un/a ${cleanRace} puede transformar el equilibrio del mundo.`,
      `Alcanzar la cúspide de su maestría como ${cleanRole}, cumpliendo los votos sagrados pactados con ${faction}.`,
      `Consolidar su propia soberanía y libertad, viviendo fiel a sus convicciones éticas sin someterse a ningún dogma tiránico.`
    ];

    const pick = (arr: string[]) => arr[Math.floor(Math.random() * arr.length)];

    setState(prev => ({
      ...prev,
      name: prev.name.trim() ? prev.name : currentName,
      background: {
        ...prev.background,
        homelandOrDomain: prev.background?.homelandOrDomain || domain,
        factionOrFaith: prev.background?.factionOrFaith || faction,
        backstory: pick(backstoryOptions),
        motivation: pick(motivationOptions),
        uniqueDetails: prev.background?.uniqueDetails && prev.background.uniqueDetails.length > 0
          ? prev.background.uniqueDetails
          : [
              `Porta una insignia ceremonial forjada en ${domain}.`,
              `Sus juramentos de combate ante ${faction} le impiden retroceder si un aliado está en peligro.`
            ]
      }
    }));
  };

  const applyDarkBehaviorPreset = () => {
    updateAdv(p => ({
      ...p,
      specificInteractions: {
        withAuthority: 'Mirada fría y evaluativa; obedece órdenes con desdén implícito mientras memoriza sus debilidades y puntos de quiebre.',
        withPeers: 'Trato distante y calculador; solo coopera si hay ganancia mutua y jamás da la espalda en combate.',
        withFriends: 'Posesión obsesiva y protección feroz tras una máscara de frialdad; jamás perdonaría una traición.',
        withSubordinates: 'Exigente y despiadado; no tolera la mediocridad y castiga el fracaso con humillaciones cortantes.',
        withStrangers: 'Desconfianza gélida e indiferencia pragmática; evalúa en silencio si representan una amenaza o una herramienta.',
        withEnemies: 'Fascinación sádica y letalidad implacable; disfruta desgastar su voluntad antes de asestar el golpe definitivo.'
      }
    }));
  };

  const applySensualBehaviorPreset = () => {
    updateAdv(p => ({
      ...p,
      specificInteractions: {
        withAuthority: 'Seductora y complaciente en la superficie, usando encanto y falsa docilidad para manipular sus decisiones.',
        withPeers: 'Coqueteo constante con dobles sentidos, roces intencionales y una camaradería magnética e intrigante.',
        withFriends: 'Confianza íntima y cariñosa; alterna confesiones cómplices con mimos indulgentes y lealtad incondicional.',
        withSubordinates: 'Amo/a cariñosa pero caprichosa; premia la lealtad con caricias y palabras dulces pero espera entrega total.',
        withStrangers: 'Mirada envolvente, sonrisa enigmática y una cortesía magnética que desarma cualquier hostilidad inicial.',
        withEnemies: 'Tensión erótica y provocación verbal punzante; convierte el combate en una danza de dominación sensual y letal.'
      }
    }));
  };

  const applyCyberBehaviorPreset = () => {
    updateAdv(p => ({
      ...p,
      specificInteractions: {
        withAuthority: 'Protocolo estricto y comunicación encriptada; acata directivas con eficiencia binaria sin cuestionar la moral.',
        withPeers: 'Confianza basada en el rendimiento en combate; comunicación telemetría rápida y lealtad de trinchera.',
        withFriends: 'Dificultad para procesar emociones orgánicas; expresa afecto compartiendo ancho de banda o protegiendo su señal vital.',
        withSubordinates: 'Instrucciones quirúrgicas y optimización de recursos; evalúa vidas en función del éxito de la misión.',
        withStrangers: 'Escaneo biométrico continuo; mantiene distancia táctica de 3 metros y filtra respuestas con tono neutral.',
        withEnemies: 'Análisis de patrones en tiempo real; explota sus puntos ciegos cibernéticos y vulnerabilidades con frialdad implacable.'
      }
    }));
  };

  const applyAnimeBehaviorPreset = () => {
    updateAdv(p => ({
      ...p,
      specificInteractions: {
        withAuthority: 'Rebeldía petulante y quejas continuas, inflando los mofletes o desobedeciendo de forma traviesa (Mesugaki).',
        withPeers: 'Competitividad ruidosa y camaradería apasionada; pica y desafía a todos pero celebra sus triunfos a lo grande.',
        withFriends: 'Tsundere en grado máximo: «¡No es como si me importaras, idiota!», sonrojándose intensamente si hay afecto físico.',
        withSubordinates: 'Se autoproclama "Gran Líder" o "Senpai Mayor", exigiendo elogios y repartiendo palmadas en la cabeza.',
        withStrangers: 'Desconfianza altiva y ceño fruncido, ocultándose tras su abrigo o susurrando comentarios sarcásticos.',
        withEnemies: '¡«Za~ko, za~ko!»; burlas descaradas sacando la lengua (akanbe) mientras demuestra superioridad cómica y aplastante.'
      }
    }));
  };

  const relationshipsList = state.background?.relationships || [];

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      {/* Hero Header */}
      <div className="bg-[#0F1115] border border-[#222222] rounded-3xl p-8 md:p-12 text-[#E0E0E0] shadow-xl mb-10 relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-96 h-96 bg-[#C9A050]/5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-[#1A1C22] border border-[#2A2D35] text-[#C9A050] text-xs font-medium mb-4">
            <BookOpen className="w-3.5 h-3.5 text-[#C9A050]" />
            <span>ESTADO 5: ANTECEDENTES, RELACIONES & PERSONALIZACIÓN AVANZADA</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-serif italic text-[#C9A050] tracking-tight mb-4">
            Antecedentes, Relaciones & Personalización
          </h2>
          <p className="text-[#888888] text-base md:text-lg mb-6 leading-relaxed">
            Configura las relaciones con personajes de la biblioteca (5.1), unifica su historia, motivación, dominio, facción, cronología y singularidades con la Herramienta de Trasfondo Narrativo (5.2), y modula en detalle su voz, habilidades, manías y dinámicas de interacción (5.4) en base a sus rasgos y valores.
          </p>
          <div className="flex flex-wrap gap-3 mb-3">
            <button
              onClick={handleGenerateDynamicHistory}
              disabled={isAILoading}
              className="bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] px-5 py-2.5 rounded-xl font-semibold text-sm flex items-center space-x-2 transition-all shadow-md cursor-pointer disabled:opacity-50"
            >
              <Sparkles className={`w-4 h-4 ${isAILoading ? 'animate-spin' : ''}`} />
              <span>{isAILoading ? 'Redactando Biografía IA...' : 'Generar Historial Dinámico (IA)'}</span>
            </button>
            <button
              onClick={handleGenerateBackstory}
              className="bg-[#1A1C22] border border-[#C9A050] text-[#C9A050] hover:bg-[#C9A050] hover:text-[#0A0B0E] px-5 py-2.5 rounded-xl font-semibold text-sm flex items-center space-x-2 transition-all shadow-md cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>Generar Trasfondo Sugerido</span>
            </button>
            <button
              onClick={handleSuggestName}
              className="bg-[#15171C] border border-[#2A2D35] text-[#E0E0E0] hover:border-[#C9A050] hover:text-[#C9A050] px-4 py-2.5 rounded-xl font-medium text-sm flex items-center space-x-2 transition-all cursor-pointer"
            >
              <Dices className="w-4 h-4" />
              <span>Sugerir Nombre</span>
            </button>
          </div>
          {aiError && (
            <div className="text-xs text-red-400 bg-red-950/30 border border-red-900/50 p-2.5 rounded-lg mt-2">
              {aiError} (Se usó el generador local alternativo).
            </div>
          )}
        </div>
      </div>

      <div className="space-y-8">
        {/* 5.0 Identidad & Perfil */}
        <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs">
          <div className="flex items-center space-x-2 mb-4 border-b border-[#222222] pb-3">
            <User className="w-4 h-4 text-[#C9A050]" />
            <h3 className="text-lg font-serif italic text-[#C9A050]">
              5.0 Identidad y Perfil Psicológico
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            {/* Nombre del Personaje */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="block text-xs font-mono text-[#888888]">
                  Nombre del Personaje <InfoTooltip text="Nombre propio, apodo o título distintivo" />
                </label>
                <button
                  type="button"
                  onClick={handleSuggestName}
                  className="text-[11px] font-mono text-[#C9A050] hover:underline flex items-center gap-1 cursor-pointer"
                  title="Generar nombre aleatorio"
                >
                  <Dices className="w-3 h-3" />
                  <span>Aleatorio</span>
                </button>
              </div>
              <input
                type="text"
                value={state.name || ''}
                onChange={(e) => setState(p => ({ ...p, name: e.target.value }))}
                placeholder="Ej: Aeloria de la Rosa Negra, Dante..."
                className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-3 text-sm text-[#E0E0E0] outline-none focus:border-[#C9A050] transition-colors"
              />
            </div>

            {/* Tipo de Personaje / Arquetipo */}
            <div>
              <label className="block text-xs font-mono text-[#888888] mb-2">
                Tipo de Personaje / Arquetipo <InfoTooltip text="Arquetipo narrativo o tropo dramático" />
              </label>
              <select
                value={state.archetype || 'Genérico'}
                onChange={e => setState(p => ({ ...p, archetype: e.target.value }))}
                className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-3 text-sm text-[#E0E0E0] outline-none focus:border-[#C9A050] transition-colors"
              >
                {CHARACTER_ARCHETYPES.map(a => (
                  <option key={a} value={a}>{a}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Plantillas de Arquetipos Psicológicos Rápidos (1-Click) */}
          <div className="pt-4 border-t border-[#222222]">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-mono text-[#C9A050] flex items-center gap-1.5 font-semibold">
                <Wand2 className="w-3.5 h-3.5" />
                <span>Plantillas de Arquetipos Psicológicos (1-Clic):</span>
              </span>
              <span className="text-[10px] text-[#777777] font-mono">
                Aplica rasgos, valores y tono coordinados
              </span>
            </div>

            {/* Category Filter Tabs */}
            <div className="flex items-center gap-1.5 flex-wrap">
              {['Todos', 'Oscuro & Edgy', 'Provocativo & Sexy', 'Moderno & Cyber', 'Anime & Gacha', 'Épico & Noble', 'Estratégico & Oculto', 'Místico & Trascendente'].map(cat => {
                const isSelected = selectedPresetCategory === cat;
                const count = cat === 'Todos' ? ARCHETYPE_PRESETS.length : ARCHETYPE_PRESETS.filter(p => p.category === cat).length;
                if (cat !== 'Todos' && count === 0) return null;
                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setSelectedPresetCategory(cat)}
                    className={`px-2.5 py-1 rounded-lg text-[10px] font-mono transition-all cursor-pointer flex items-center space-x-1 ${
                      isSelected
                        ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                        : 'bg-[#15171C] border border-[#2A2D35] text-[#AAAAAA] hover:text-[#E0E0E0] hover:border-[#C9A050]/50'
                    }`}
                  >
                    <span>{cat}</span>
                    <span className={`text-[9px] px-1 rounded ${isSelected ? 'bg-[#0A0B0E]/20 text-[#0A0B0E]' : 'bg-[#0F1115] text-[#777777]'}`}>
                      {count}
                    </span>
                  </button>
                );
              })}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
              {ARCHETYPE_PRESETS.filter(p => selectedPresetCategory === 'Todos' || p.category === selectedPresetCategory).map(preset => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => {
                    setState(prev => ({
                      ...prev,
                      archetype: preset.archetype,
                      personalityTraits: preset.traits,
                      personality: preset.traits.join(', '),
                      background: {
                        ...prev.background,
                        coreValues: preset.coreValues.join(', '),
                        ...(preset.homelandOrDomain ? { homelandOrDomain: preset.homelandOrDomain } : {}),
                        ...(preset.factionOrFaith ? { factionOrFaith: preset.factionOrFaith } : {})
                      },
                      advancedCustomization: {
                        ...prev.advancedCustomization,
                        voiceTone: preset.voiceTone || prev.advancedCustomization?.voiceTone || '',
                        speechStyle: preset.speechStyle || prev.advancedCustomization?.speechStyle || '',
                        catchphrasesOrIdioms: preset.catchphrase || prev.advancedCustomization?.catchphrasesOrIdioms || '',
                        habitsAndMannerisms: Array.from(new Set([...(prev.advancedCustomization?.habitsAndMannerisms || []), ...(preset.habits || [])])),
                        skills: Array.from(new Set([...(prev.advancedCustomization?.skills || []), ...(preset.skills || [])]))
                      }
                    }));
                  }}
                  className="bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050] p-3 rounded-xl text-left transition-all cursor-pointer group"
                >
                  <div className="text-xs font-bold text-[#E0E0E0] group-hover:text-[#C9A050] flex items-center justify-between">
                    <span>{preset.name}</span>
                    <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-[#0F1115] text-[#C9A050] border border-[#2A2D35]">
                      {preset.archetype}
                    </span>
                  </div>
                  <p className="text-[10px] text-[#888888] mt-1 line-clamp-2 leading-relaxed">
                    {preset.description}
                  </p>
                  <div className="mt-2 flex flex-wrap gap-1">
                    {preset.traits.slice(0, 3).map(t => (
                      <span key={t} className="text-[9px] px-1.5 py-0.2 rounded bg-[#0F1115] text-[#AAAAAA]">
                        {t}
                      </span>
                    ))}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* 5.0.1 Rasgos de Personalidad & Core de Valores */}
        <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs">
          <div className="flex items-center justify-between mb-3 border-b border-[#222222] pb-3">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-[#C9A050]" />
              <h3 className="text-lg font-serif italic text-[#C9A050]">
                Rasgos de Personalidad & Valores Fundamentales
              </h3>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-mono text-[#C9A050]">
                {(state.personalityTraits || []).length} rasgos seleccionados
              </span>
              {(state.personalityTraits || []).length > 0 && (
                <button
                  type="button"
                  onClick={handleClearAllTraits}
                  className="text-[10px] font-mono text-[#E57373] hover:text-[#FF8A80] border border-[#E57373]/30 hover:border-[#E57373] px-2 py-0.5 rounded transition-all cursor-pointer"
                  title="Quitar la selección de todos los rasgos"
                >
                  Deseleccionar todos
                </button>
              )}
            </div>
          </div>

          {/* Categorized Personality Traits */}
          <div className="space-y-3 mb-4">
            {TRAIT_CATEGORIES.map(cat => (
              <div key={cat.id} className="bg-[#15171C]/60 p-3 rounded-xl border border-[#2A2D35]/50">
                <div className="text-[11px] font-mono text-[#C9A050] mb-2 flex items-center justify-between">
                  <span>{cat.categoryName}</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {cat.traits.map(trait => {
                    const isSelected = (state.personalityTraits || []).includes(trait);
                    return (
                      <button
                        key={trait}
                        type="button"
                        onClick={() => toggleTrait(trait)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all flex items-center space-x-1 cursor-pointer ${
                          isSelected
                            ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                            : 'bg-[#15171C] border border-[#2A2D35] text-[#AAAAAA] hover:border-[#C9A050] hover:text-[#E0E0E0]'
                        }`}
                      >
                        {isSelected && <Check className="w-3 h-3" />}
                        <span>{trait}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

          <form onSubmit={handleAddCustomTrait} className="flex gap-2 mb-6">
            <input
              type="text"
              value={customTraitInput}
              onChange={(e) => setCustomTraitInput(e.target.value)}
              placeholder="Añadir rasgo psicológico personalizado..."
              className="flex-1 bg-[#15171C] border border-[#2A2D35] rounded-xl px-3 py-2 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050]"
            />
            <button
              type="submit"
              className="bg-[#1A1C22] border border-[#2A2D35] text-[#C9A050] hover:bg-[#C9A050] hover:text-[#0A0B0E] px-4 py-2 rounded-xl text-xs font-medium transition-all cursor-pointer"
            >
              Añadir Rasgo
            </button>
          </form>

          {/* Core Values Categorized */}
          <div className="pt-4 border-t border-[#222222]">
            <div className="flex items-center justify-between mb-2 flex-wrap gap-2">
              <label className="block text-xs font-mono text-[#888888]">
                Core de Valores & Principios Morales por Ámbito:
              </label>
              <div className="flex items-center space-x-2">
                <span className="text-[11px] font-mono text-[#C9A050]">
                  {(state.background?.coreValues ? state.background.coreValues.split(',').map(s => s.trim()).filter(Boolean).length : 0)} valores activos
                </span>
                {(state.background?.coreValues ? state.background.coreValues.split(',').map(s => s.trim()).filter(Boolean).length : 0) > 0 && (
                  <button
                    type="button"
                    onClick={handleClearAllCoreValues}
                    className="text-[10px] font-mono text-[#E57373] hover:text-[#FF8A80] border border-[#E57373]/30 hover:border-[#E57373] px-2 py-0.5 rounded transition-all cursor-pointer"
                    title="Quitar la selección de todos los valores morales"
                  >
                    Deseleccionar todos
                  </button>
                )}
              </div>
            </div>

            <div className="space-y-3 mb-3">
              {CORE_VALUE_CATEGORIES.map(cat => (
                <div key={cat.id} className="bg-[#15171C]/60 p-2.5 rounded-xl border border-[#2A2D35]/50">
                  <div className="text-[10px] font-mono text-[#888888] mb-1.5">
                    {cat.categoryName}
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {cat.values.map(val => {
                      const currentValsList = (state.background?.coreValues || '')
                        .split(',')
                        .map(s => s.trim().toLowerCase())
                        .filter(Boolean);
                      const isSelected = currentValsList.includes(val.trim().toLowerCase());
                      return (
                        <button
                          key={val}
                          type="button"
                          onClick={() => handleCoreValueSelect(val)}
                          className={`px-2.5 py-0.5 rounded text-[11px] font-medium transition-all flex items-center space-x-1 cursor-pointer ${
                            isSelected
                              ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                              : 'bg-[#15171C] border border-[#2A2D35] text-[#888888] hover:border-[#C9A050] hover:text-[#DDD]'
                          }`}
                        >
                          {isSelected && <Check className="w-2.5 h-2.5" />}
                          <span>{val}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}

              {(() => {
                const allEngineVals = CORE_VALUE_CATEGORIES.flatMap(c => c.values).map(v => v.trim().toLowerCase());
                const currentVals = state.background?.coreValues ? state.background.coreValues.split(',').map(s => s.trim()).filter(Boolean) : [];
                const customAdded = currentVals.filter(v => !allEngineVals.includes(v.toLowerCase()));
                if (customAdded.length === 0) return null;
                return (
                  <div className="flex flex-wrap gap-1.5 p-2 bg-[#1A1C22] rounded-lg border border-[#C9A050]/30">
                    <span className="text-[10px] font-mono text-[#C9A050] w-full mb-1">Valores Personalizados:</span>
                    {customAdded.map(val => (
                      <button
                        key={val}
                        type="button"
                        onClick={() => handleCoreValueSelect(val)}
                        className="bg-[#C9A050] text-[#0A0B0E] font-semibold px-2 py-0.5 rounded text-[11px] transition-all flex items-center space-x-1 cursor-pointer"
                        title="Clic para remover este valor"
                      >
                        <Check className="w-2.5 h-2.5" />
                        <span>{val}</span>
                      </button>
                    ))}
                  </div>
                );
              })()}
            </div>
            <form onSubmit={handleAddCustomValue} className="flex gap-2">
              <input
                type="text"
                value={customValueInput}
                onChange={(e) => setCustomValueInput(e.target.value)}
                placeholder="Añadir principio o valor moral personalizado (ej: Honor, Lealtad inquebrantable, Libertad sobre dogma)..."
                className="flex-1 bg-[#15171C] border border-[#2A2D35] rounded-xl px-3 py-2 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050]"
              />
              <button
                type="submit"
                className="bg-[#1A1C22] border border-[#2A2D35] text-[#C9A050] hover:bg-[#C9A050] hover:text-[#0A0B0E] px-4 py-2 rounded-xl text-xs font-medium transition-all cursor-pointer whitespace-nowrap"
              >
                Añadir Valor
              </button>
            </form>
          </div>

          {/* Psychological & Moral Synthesis Dynamic Live Banner */}
          <div className="mt-5 p-4 rounded-xl bg-[#15171C] border border-[#C9A050]/40 space-y-2">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center space-x-2">
                <Compass className="w-4 h-4 text-[#C9A050]" />
                <span className="text-xs font-mono font-bold text-[#C9A050] uppercase">
                  Síntesis Psicológica: {personalitySummary.archetypeTitle}
                </span>
              </div>
              <div className="flex items-center space-x-2 text-[11px] font-mono text-[#AAAAAA]">
                <Scale className="w-3.5 h-3.5 text-[#C9A050]" />
                <span>{personalitySummary.moralAlignment}</span>
              </div>
            </div>
            <p className="text-xs text-[#CCCCCC] leading-relaxed italic">
              «{personalitySummary.interactionSummary}»
            </p>
            <div className="flex items-center justify-between pt-2 border-t border-[#222222] flex-wrap gap-2">
              <div className="flex items-center gap-1.5 flex-wrap">
                {personalitySummary.keyThemes.map((theme, i) => (
                  <span key={i} className="px-2 py-0.5 rounded bg-[#0F1115] border border-[#2A2D35] text-[10px] font-mono text-[#C9A050]">
                    {theme}
                  </span>
                ))}
              </div>
              <button
                type="button"
                onClick={handleApplyAllArchetypePersonalization}
                className="bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] px-3.5 py-1.5 rounded-lg text-xs font-bold flex items-center space-x-1.5 cursor-pointer shadow-xs transition-all"
                title="Aplica automáticamente dinámicas de trato, voz, habilidades y manías según tus rasgos y valores seleccionados"
              >
                <Wand2 className="w-3.5 h-3.5" />
                <span>✨ Sincronizar Todo con Mis Rasgos & Valores</span>
              </button>
            </div>
          </div>
        </div>

        {/* 5.0.2 VULNERABILIDAD FATAL & DEFECTO TRÁGICO */}
        <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs space-y-6">
          <div className="flex items-center justify-between border-b border-[#222222] pb-3 flex-wrap gap-2">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <h3 className="text-lg font-serif italic text-[#C9A050]">
                5.0.2 Defecto Trágico & Vulnerabilidad Fatal (Punto Ciego / Talón de Aquiles)
              </h3>
            </div>
            <span className="text-[11px] font-mono text-[#888888]">
              Punto Débil & Humanidad Trágica
            </span>
          </div>

          <p className="text-[#888888] text-xs">
            Selecciona o redacta la vulnerabilidad primordial o defecto trágico que define la fragilidad, peligro y humanidad de tu personaje ante sus adversarios. El dominio territorial y facción se gestionan y unifican dentro de la Herramienta de Trasfondo Narrativo (5.2).
          </p>

          {/* Defecto Trágico o Vulnerabilidad Fatal (Selección Múltiple) */}
          {(() => {
            const selectedFatalFlaws = getSelectedFatalFlaws();
            const categoryPool = FATAL_FLAW_CATEGORIES[selectedFatalFlawCategory] || SUGGESTED_FATAL_FLAWS;
            const filteredSuggestions = categoryPool.filter(f =>
              fatalFlawSearchQuery.trim() === '' || f.toLowerCase().includes(fatalFlawSearchQuery.toLowerCase().trim())
            );

            return (
              <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-4 space-y-3.5">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <label className="text-xs font-mono font-bold text-[#C9A050] uppercase flex items-center gap-1.5">
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                      <span>Defecto Trágico o Vulnerabilidad Fatal (Talón de Aquiles)</span>
                    </label>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold">
                      {selectedFatalFlaws.length} {selectedFatalFlaws.length === 1 ? 'seleccionado' : 'seleccionados'}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    {selectedFatalFlaws.length > 0 && (
                      <button
                        type="button"
                        onClick={handleClearAllFatalFlaws}
                        className="text-[10px] font-mono text-[#888888] hover:text-red-400 transition-colors cursor-pointer"
                        title="Deseleccionar todos los defectos"
                      >
                        Limpiar selección
                      </button>
                    )}
                    <InfoTooltip text="Selección múltiple de debilidades primordiales del personaje: traumas psicológicos, deudas de honor ineludibles, fobias paralizantes, ciberpsicosis, adicciones o vulnerabilidades físicas concretas. Haz clic en las sugerencias para activarlas o desactivarlas, o escribe defectos personalizados." />
                  </div>
                </div>

                {/* Chips de Defectos Seleccionados / Activos */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-mono text-amber-400/90 font-semibold">
                      Vulnerabilidades Activas Asignadas ({selectedFatalFlaws.length}):
                    </span>
                  </div>

                  {selectedFatalFlaws.length > 0 ? (
                    <div className="flex flex-wrap gap-1.5 p-2.5 bg-[#0F1115] border border-amber-500/30 rounded-xl min-h-[44px] items-center">
                      {selectedFatalFlaws.map((flaw) => (
                        <span
                          key={flaw}
                          className="bg-amber-500/20 border border-amber-500/60 text-amber-200 px-2.5 py-1 rounded-lg text-xs font-medium flex items-center gap-1.5 shadow-xs"
                        >
                          <AlertTriangle className="w-3 h-3 text-amber-400 shrink-0" />
                          <span className="leading-snug">{flaw}</span>
                          <button
                            type="button"
                            onClick={() => handleRemoveFatalFlaw(flaw)}
                            className="ml-1 text-amber-300 hover:text-red-400 hover:bg-red-500/20 rounded p-0.5 transition-colors cursor-pointer"
                            title="Quitar este defecto"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </span>
                      ))}
                    </div>
                  ) : (
                    <div className="text-[11px] text-[#888888] italic bg-[#0F1115] border border-dashed border-[#2A2D35] rounded-xl p-3 text-center">
                      Sin defectos trágicos seleccionados todavía. Haz clic en una o varias sugerencias a continuación o escribe defectos personalizados.
                    </div>
                  )}
                </div>

                {/* Sugerencias de Selección Múltiple con Filtros y Buscador */}
                <div className="space-y-2 pt-1 border-t border-[#222222]">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <span className="text-[10px] font-mono text-[#888888]">
                      Sugerencias de Defectos Trágicos (Haz clic para alternar selección múltiple):
                    </span>
                    {/* Buscador de defectos */}
                    <div className="relative w-full sm:w-64">
                      <Search className="w-3 h-3 text-[#666666] absolute left-2.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={fatalFlawSearchQuery}
                        onChange={(e) => setFatalFlawSearchQuery(e.target.value)}
                        placeholder="Buscar defecto (ej: sangre, orgullo, ciber...)"
                        className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-lg pl-8 pr-2.5 py-1 text-[11px] text-[#E0E0E0] outline-none focus:border-[#C9A050] transition-colors placeholder:text-[#555555]"
                      />
                      {fatalFlawSearchQuery && (
                        <button
                          type="button"
                          onClick={() => setFatalFlawSearchQuery('')}
                          className="absolute right-2 top-1/2 -translate-y-1/2 text-[#888888] hover:text-white text-xs cursor-pointer"
                        >
                          ×
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Pestañas de categorías */}
                  <div className="flex flex-wrap gap-1">
                    {Object.keys(FATAL_FLAW_CATEGORIES).map((catName) => {
                      const isCatActive = selectedFatalFlawCategory === catName;
                      const catCount = FATAL_FLAW_CATEGORIES[catName].length;
                      return (
                        <button
                          key={catName}
                          type="button"
                          onClick={() => setSelectedFatalFlawCategory(catName)}
                          className={`px-2 py-0.5 rounded text-[10px] font-mono transition-all cursor-pointer whitespace-nowrap ${
                            isCatActive
                              ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                              : 'bg-[#12141A] border border-[#2A2D35] text-[#888888] hover:text-[#C9A050] hover:border-[#C9A050]/40'
                          }`}
                        >
                          {catName} ({catCount})
                        </button>
                      );
                    })}
                  </div>

                  {/* Parrilla de sugerencias interactivas */}
                  <div className="flex flex-wrap gap-1.5 max-h-56 overflow-y-auto pr-1 p-1.5 bg-[#0F1115]/60 border border-[#222222] rounded-xl">
                    {filteredSuggestions.length > 0 ? (
                      filteredSuggestions.map((flaw) => {
                        const isSelected = selectedFatalFlaws.includes(flaw);
                        return (
                          <button
                            key={flaw}
                            type="button"
                            onClick={() => toggleFatalFlaw(flaw)}
                            className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all cursor-pointer text-left flex items-center gap-1.5 max-w-full ${
                              isSelected
                                ? 'bg-amber-500/25 border border-amber-500 text-amber-200 font-semibold shadow-xs'
                                : 'bg-[#0F1115] border border-[#2A2D35] text-[#AAAAAA] hover:text-[#C9A050] hover:border-[#C9A050]/60'
                            }`}
                            title={flaw}
                          >
                            {isSelected ? (
                              <Check className="w-3 h-3 text-amber-400 shrink-0" />
                            ) : (
                              <Plus className="w-3 h-3 text-[#666666] shrink-0" />
                            )}
                            <span className="truncate">{flaw}</span>
                          </button>
                        );
                      })
                    ) : (
                      <div className="w-full text-center py-3 text-xs text-[#666666] italic">
                        No se encontraron sugerencias que coincidan con «{fatalFlawSearchQuery}».
                      </div>
                    )}
                  </div>
                </div>

                {/* Formulario para añadir Defecto Personalizado */}
                <form onSubmit={handleAddCustomFatalFlaw} className="flex gap-2 pt-1 border-t border-[#222222]">
                  <input
                    type="text"
                    value={customFatalFlawInput}
                    onChange={(e) => setCustomFatalFlawInput(e.target.value)}
                    placeholder="Añadir defecto trágico o vulnerabilidad personalizada (ej: Miedo paralizante a los espejos antiguos, Sobrecarga de maná al cantar)..."
                    className="flex-1 bg-[#0F1115] border border-[#2A2D35] rounded-xl px-3 py-2 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050] transition-colors placeholder:text-[#555555]"
                  />
                  <button
                    type="submit"
                    className="bg-[#1A1C22] border border-[#2A2D35] text-[#C9A050] hover:bg-[#C9A050] hover:text-[#0A0B0E] px-4 py-2 rounded-xl text-xs font-medium transition-all cursor-pointer whitespace-nowrap flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Añadir Defecto</span>
                  </button>
                </form>

                {/* Vista previa / Ajuste textual libre sincronizado */}
                <div className="space-y-1 pt-1">
                  <span className="text-[10px] font-mono text-[#666666]">
                    Texto compilado / Ajuste descriptivo libre (sincronizado automáticamente):
                  </span>
                  <textarea
                    rows={2}
                    value={state.background?.fatalFlawOrVulnerability || ''}
                    onChange={(e) => {
                      const val = e.target.value;
                      const parts = val.split(/\s*\|\s*|\s*;\s*/).map(s => s.trim()).filter(Boolean);
                      setState(p => ({
                        ...p,
                        background: {
                          ...p.background,
                          fatalFlawOrVulnerability: val,
                          fatalFlaws: parts
                        }
                      }));
                    }}
                    placeholder="Describe su talón de Aquiles o vulnerabilidades separadas por | ..."
                    className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050] transition-colors resize-y leading-relaxed font-mono"
                  />
                </div>
              </div>
            );
          })()}
        </div>

        {/* 5.1 RELACIONES & FORMA DE INTERACCIÓN (Vínculos con la Biblioteca & Canónicos) */}
        <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs">
          <div className="flex items-center justify-between mb-4 border-b border-[#222222] pb-3 flex-wrap gap-2">
            <div className="flex items-center space-x-2">
              <Users className="w-4 h-4 text-[#C9A050]" />
              <h3 className="text-lg font-serif italic text-[#C9A050]">
                5.1 Relaciones & Vínculos con Personajes
              </h3>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                onClick={handleAdaptExistingRelationshipsToTraits}
                className="bg-[#15171C] border border-[#2A2D35] hover:border-[#C9A050] text-[#E0E0E0] hover:text-[#C9A050] px-3 py-1.5 rounded-xl text-xs font-medium flex items-center space-x-1.5 transition-all cursor-pointer"
                title="Actualiza los sentimientos y opiniones de los vínculos existentes según tus rasgos actuales"
              >
                <RefreshCw className="w-3 h-3 text-[#C9A050]" />
                <span>Re-adaptar Vínculos Existentes</span>
              </button>
              <button
                type="button"
                onClick={() => setShowArchetypeAdaptivePanel(!showArchetypeAdaptivePanel)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition-all cursor-pointer ${
                  showArchetypeAdaptivePanel
                    ? 'bg-[#C9A050] text-[#0A0B0E]'
                    : 'bg-[#15171C] border border-[#C9A050]/50 text-[#C9A050] hover:bg-[#C9A050]/10'
                }`}
              >
                <Wand2 className="w-3.5 h-3.5" />
                <span>✨ Sugerencias Dinámicas ({dynamicModulation.adaptedRelationships.length})</span>
              </button>
              <button
                onClick={() => setShowAddRelForm(!showAddRelForm)}
                className="bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] px-3 py-1.5 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{showAddRelForm ? 'Cancelar' : 'Añadir Vínculo'}</span>
              </button>
            </div>
          </div>
          <p className="text-[#888888] text-xs mb-4">
            Establece conexiones narrativas con personajes de tu biblioteca guardada o añade vínculos sugeridos que combinan el rol de <strong className="text-[#C9A050]">{currentRoleName}</strong> con sus rasgos psicológicos ({state.personalityTraits?.join(', ') || 'Equilibrado'}) y sus valores morales ({state.background?.coreValues || 'Honor y Lealtad'}).
          </p>

          {/* Archetype & Personality Adaptive Panel */}
          {showArchetypeAdaptivePanel && (
            <div className="bg-[#15171C] border border-[#C9A050]/50 rounded-xl p-4 mb-5 space-y-3 animate-scale-up">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <Wand2 className="w-4 h-4 text-[#C9A050]" />
                  <h4 className="text-xs font-mono text-[#C9A050] uppercase font-bold">
                    Vínculos Modulados por: [{personalitySummary.archetypeTitle}]
                  </h4>
                </div>
                <span className="text-[11px] font-mono text-[#AAAAAA]">
                  Influenciados por {(state.personalityTraits || []).length} rasgos y valores morales
                </span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                {dynamicModulation.adaptedRelationships.map((sug, idx) => {
                  const isAdded = relationshipsList.some(r => r.targetCharacterName === sug.targetCharacterName && r.relationshipType === sug.relationshipType);
                  return (
                    <div
                      key={`dyn-rel-${idx}`}
                      className="p-3 rounded-lg border bg-[#0F1115] border-[#2A2D35] hover:border-[#C9A050]/40 flex flex-col justify-between gap-2 text-xs"
                    >
                      <div>
                        <div className="flex items-center justify-between gap-1 mb-1">
                          <span className="font-serif italic font-bold text-[#E0E0E0]">{sug.targetCharacterName}</span>
                          <span className="px-1.5 py-0.5 rounded bg-[#1A1C22] text-[10px] font-mono text-[#C9A050]">
                            {sug.relationshipType}
                          </span>
                        </div>
                        <p className="text-[11px] text-[#CCCCCC] italic mb-1.5 bg-[#15171C] p-1.5 rounded border border-[#222222]">
                          «{sug.interactionDynamic}»
                        </p>
                        {sug.feelingsTowards && (
                          <div className="text-[10px] text-[#C9A050]/90 mb-1">
                            <strong>Sentimientos hacia él/ella:</strong> {sug.feelingsTowards}
                          </div>
                        )}
                        {sug.opinionOn && (
                          <div className="text-[10px] text-blue-300/90 mb-1">
                            <strong>Opinión sobre él/ella:</strong> {sug.opinionOn}
                          </div>
                        )}
                        {sug.synergyTags && sug.synergyTags.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-1">
                            {sug.synergyTags.map((tag, tIdx) => (
                              <span key={tIdx} className="px-1.5 py-0.5 rounded bg-[#1A1C22] text-[9px] font-mono text-[#888888]">
                                {tag}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                      <div className="flex justify-end pt-1">
                        <button
                          type="button"
                          onClick={() => handleAddSuggestedRelationship(sug)}
                          disabled={isAdded}
                          className={`px-2.5 py-1 rounded-md text-[10px] font-bold flex items-center gap-1 cursor-pointer transition-all ${
                            isAdded
                              ? 'bg-[#C9A050]/20 text-[#C9A050] cursor-default'
                              : 'bg-[#1A1C22] border border-[#C9A050]/60 text-[#C9A050] hover:bg-[#C9A050] hover:text-[#0A0B0E]'
                          }`}
                        >
                          {isAdded ? <Check className="w-3 h-3" /> : <Plus className="w-3 h-3" />}
                          <span>{isAdded ? 'Vinculado' : 'Añadir Vínculo'}</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Add Relationship Form */}
          {showAddRelForm && (
            <div className="bg-[#15171C] border border-[#C9A050]/40 rounded-xl p-5 mb-6 animate-scale-up space-y-4">
              <h4 className="text-xs font-mono text-[#C9A050] uppercase font-bold flex items-center gap-1.5">
                <Plus className="w-3.5 h-3.5" />
                <span>Configurar Nueva Relación & Vínculo</span>
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Select from Library */}
                <div>
                  <label className="block text-[11px] font-mono text-[#888888] mb-1.5">
                    Seleccionar de la Biblioteca:
                  </label>
                  <select
                    value={newRelCharId}
                    onChange={(e) => {
                      setNewRelCharId(e.target.value);
                      const target = libraryCharacters.find(c => c.id === e.target.value);
                      if (target) {
                        setNewRelCharName(target.name);
                        // Auto-detect variant relationship
                        const isSameGroup = target.variantGroupId && target.variantGroupId === state.variantGroupId;
                        const vLabel = (target.variantLabel || '').toLowerCase();
                        if (isSameGroup || vLabel.includes('futuro') || vLabel.includes('pasado') || vLabel.includes('rol') || vLabel.includes('vestuario')) {
                          if (vLabel.includes('futuro')) {
                            setNewRelType('Versión Alterna: Futuro');
                            setNewRelDynamic(`Vínculo temporal y reflejo existencial con su yo futuro/veterano.`);
                          } else if (vLabel.includes('pasado')) {
                            setNewRelType('Versión Alterna: Pasado');
                            setNewRelDynamic(`Vínculo temporal y reflejo existencial con su yo pasado/aprendiz.`);
                          } else if (vLabel.includes('rol') || vLabel.includes('vestuario')) {
                            setNewRelType('Versión Alterna: Rol/Vestuario');
                            setNewRelDynamic(`Reflejo alternativo de su propia alma portando otro rol y vestimenta.`);
                          }
                        }
                      }
                    }}
                    className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050]"
                  >
                    <option value="">-- O escribir nombre personalizado abajo --</option>
                    {libraryCharacters.map(char => (
                      <option key={char.id} value={char.id}>
                        {char.name} ({char.raceName} - {char.role}) [{char.variantLabel || 'Base'}]
                      </option>
                    ))}
                  </select>
                </div>

                {/* Target Name (if custom or autofilled) */}
                <div>
                  <label className="block text-[11px] font-mono text-[#888888] mb-1.5">
                    Nombre del Personaje Objetivo:
                  </label>
                  <input
                    type="text"
                    value={newRelCharName}
                    onChange={(e) => setNewRelCharName(e.target.value)}
                    placeholder="Ej: Valerius de Luminaria, Maestro Kael, Aeloria (Futuro)..."
                    className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050]"
                  />
                </div>
              </div>

              {/* Relationship Type */}
              <div>
                <div className="flex items-center justify-between mb-1.5 flex-wrap gap-1">
                  <label className="block text-[11px] font-mono text-[#888888]">
                    Tipo de Relación / Jerarquía / Versión Alterna:
                  </label>
                  <span className="text-[10px] font-mono text-[#C9A050]">
                    Incluye Jerarquías y Versiones Alternas (Rol, Futuro, Pasado)
                  </span>
                </div>

                {/* Quick select pills grouped by category */}
                <div className="space-y-1.5 mb-2">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[9px] font-mono text-[#888888] uppercase">🌀 Versiones Alternas:</span>
                    {['Versión Alterna: Rol/Vestuario', 'Versión Alterna: Futuro', 'Versión Alterna: Pasado'].map(type => (
                      <button
                        key={type}
                        type="button"
                        onClick={() => setNewRelType(type)}
                        className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold transition-all cursor-pointer ${
                          newRelType === type
                            ? type.includes('Futuro')
                              ? 'bg-purple-900/60 border border-purple-400 text-purple-200 shadow-xs'
                              : type.includes('Pasado')
                              ? 'bg-blue-900/60 border border-blue-400 text-blue-200 shadow-xs'
                              : 'bg-emerald-900/60 border border-emerald-400 text-emerald-200 shadow-xs'
                            : 'bg-[#0F1115] border border-[#2A2D35] text-[#AAAAAA] hover:border-[#C9A050]'
                        }`}
                      >
                        {type}
                      </button>
                    ))}
                  </div>

                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[9px] font-mono text-[#888888] uppercase">👑 Jerarquías & Vínculos:</span>
                    {['Sirviente → Maestro (El objetivo es mi Amo / Maestro / Señor)', 'Maestro → Sirviente (El objetivo es mi Sirviente / Mayordomo / Lacayo)', 'Subordinado/a / Bajo Mi Mando', 'Superior / Comandante Oficial', 'Mentor/a → Aprendiz (El objetivo es mi Alumno / Pupilo)', 'Compañero/a de Armas / Igual Rango', 'Rival Jurado / Competidor Directo', 'Interés Romántico / Vínculo Afectivo', 'Hermano/a / Pariente de Sangre'].map(type => (
                      <button
                        key={type}
                        type="button"
                        onClick={() => setNewRelType(type)}
                        className={`px-2 py-0.5 rounded-lg text-[10px] font-medium transition-all cursor-pointer ${
                          newRelType === type
                            ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                            : 'bg-[#0F1115] border border-[#2A2D35] text-[#AAAAAA] hover:border-[#C9A050]'
                        }`}
                      >
                        {type.split('(')[0].trim()}
                      </button>
                    ))}
                  </div>

                  {/* 💀 Oscuras & Prohibidas */}
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[9px] font-mono text-rose-400 uppercase">💀 Oscuras & Prohibidas:</span>
                    {['Amo/a Dominante ↔ Mascota / Juguete Consentido/a', 'Obsesión Yandere (Posesión Absoluta: jamás permitiré que nadie te toque)', 'Pacto de Sangre / Vínculo Demoníaco Indisoluble', 'Relación Tóxica & Codependencia Destructiva', 'Verdugo / Torturador ↔ Prisionero/a de Guerra Fascinante'].map(type => (
                      <button
                        key={type}
                        type="button"
                        onClick={() => setNewRelType(type)}
                        className={`px-2 py-0.5 rounded-lg text-[10px] font-medium transition-all cursor-pointer ${
                          newRelType === type
                            ? 'bg-rose-950/70 border border-rose-500 text-rose-200 font-bold shadow-xs'
                            : 'bg-[#0F1115] border border-rose-900/40 text-rose-300/80 hover:border-rose-500'
                        }`}
                      >
                        {type.split('(')[0].trim()}
                      </button>
                    ))}
                  </div>

                  {/* 💋 Provocativas & Sensuales */}
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[9px] font-mono text-pink-400 uppercase">💋 Provocativas & Sensuales:</span>
                    {['Vínculo de Placer y Seducción / Súcubo o Íncubo Tentador/a', 'Rival Frenemies con Alta Tensión Sexual y Deseo Prohibido', 'Cortesana / Concubina de Confianza ↔ Protector Aristócrata'].map(type => (
                      <button
                        key={type}
                        type="button"
                        onClick={() => setNewRelType(type)}
                        className={`px-2 py-0.5 rounded-lg text-[10px] font-medium transition-all cursor-pointer ${
                          newRelType === type
                            ? 'bg-pink-950/70 border border-pink-500 text-pink-200 font-bold shadow-xs'
                            : 'bg-[#0F1115] border border-pink-900/40 text-pink-300/80 hover:border-pink-500'
                        }`}
                      >
                        {type}
                      </button>
                    ))}
                  </div>

                  {/* ⚡ Modernas & Cyber */}
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[9px] font-mono text-cyan-400 uppercase">⚡ Modernas & Cyber:</span>
                    {['Netrunner Hacker ↔ Operador Táctico de Enlace en Vivo', 'Socio/a de Contrabando Urbano / Cómplice de Fixer Callejero', 'Creador/a Cibernético ↔ Androide de Combate / Guardaespaldas Biónico'].map(type => (
                      <button
                        key={type}
                        type="button"
                        onClick={() => setNewRelType(type)}
                        className={`px-2 py-0.5 rounded-lg text-[10px] font-medium transition-all cursor-pointer ${
                          newRelType === type
                            ? 'bg-cyan-950/70 border border-cyan-500 text-cyan-200 font-bold shadow-xs'
                            : 'bg-[#0F1115] border border-cyan-900/40 text-cyan-300/80 hover:border-cyan-500'
                        }`}
                      >
                        {type}
                      </button>
                    ))}
                  </div>

                  {/* 🌸 Anime & Gachas */}
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[9px] font-mono text-amber-400 uppercase">🌸 Anime & Gachas:</span>
                    {['Invocador/a Master ↔ Unidad SSR Devota de Gacha', 'Mesugaki Burlona ↔ Senpai / Blanco Favorito de Provocaciones', 'Kouhai Consentida/o ↔ Senpai Protector/a', 'Tsundere en Negación (Te insulta pero daría la vida por ti)'].map(type => (
                      <button
                        key={type}
                        type="button"
                        onClick={() => setNewRelType(type)}
                        className={`px-2 py-0.5 rounded-lg text-[10px] font-medium transition-all cursor-pointer ${
                          newRelType === type
                            ? 'bg-amber-950/70 border border-amber-500 text-amber-200 font-bold shadow-xs'
                            : 'bg-[#0F1115] border border-amber-900/40 text-amber-300/80 hover:border-amber-500'
                        }`}
                      >
                        {type.split('(')[0].trim()}
                      </button>
                    ))}
                  </div>
                </div>

                <select
                  value={newRelType}
                  onChange={(e) => setNewRelType(e.target.value)}
                  className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050]"
                >
                  {RELATIONSHIP_TYPES.map(type => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
              </div>

              {/* Interaction Dynamic */}
              <div>
                <label className="block text-[11px] font-mono text-[#888888] mb-1.5">
                  Forma de Interacción & Dinámica de Trato:
                </label>
                <div className="flex flex-wrap gap-1.5 mb-2">
                  {dynamicModulation.customSuggestedRelationships?.slice(0, 3).map((sug, idx) => (
                    <button
                      key={`form-sug-${idx}`}
                      type="button"
                      onClick={() => setNewRelDynamic(sug.interactionDynamic)}
                      className="px-2 py-1 rounded-lg bg-[#0F1115] border border-[#C9A050]/40 text-[10px] text-[#C9A050] hover:bg-[#C9A050] hover:text-[#0A0B0E] truncate max-w-xs text-left cursor-pointer font-mono"
                      title={sug.interactionDynamic}
                    >
                      ⚡ {sug.targetCharacterName}
                    </button>
                  ))}
                  {INTERACTION_DYNAMICS_SUGGESTIONS.slice(0, 4).map((dyn, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setNewRelDynamic(dyn)}
                      className="px-2 py-1 rounded-lg bg-[#0F1115] border border-[#2A2D35] text-[10px] text-[#AAAAAA] hover:text-[#C9A050] hover:border-[#C9A050] truncate max-w-xs text-left cursor-pointer"
                      title={dyn}
                    >
                      {dyn}
                    </button>
                  ))}
                </div>
                <textarea
                  rows={2}
                  value={newRelDynamic}
                  onChange={(e) => setNewRelDynamic(e.target.value)}
                  placeholder="Describe cómo le habla, cómo se comporta frente a él/ella, tensión o afecto..."
                  className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050] resize-y"
                />
              </div>

              {/* Sentimientos hacia el personaje objetivo & Opinión sobre el personaje objetivo */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-[#222222]">
                {/* Sentimientos hacia */}
                <div className="space-y-1.5">
                  <label className="block text-[11px] font-mono text-[#C9A050] font-semibold flex items-center gap-1">
                    <Heart className="w-3.5 h-3.5" />
                    <span>Sentimientos hacia {newRelCharName.trim() || 'el Personaje Objetivo'}:</span>
                  </label>
                  <div className="flex flex-wrap gap-1 mb-1.5">
                    {getDynamicFeelingsSuggestions(newRelType, state.archetype, state.personalityTraits, state.background?.coreValues).map((feel, idx) => (
                      <button
                        key={`feel-${idx}`}
                        type="button"
                        onClick={() => setNewRelFeelings(feel)}
                        className="px-2 py-0.5 rounded bg-[#0F1115] border border-[#2A2D35] text-[10px] text-[#AAAAAA] hover:text-[#C9A050] hover:border-[#C9A050] cursor-pointer truncate max-w-full text-left"
                        title={feel}
                      >
                        {feel.slice(0, 36)}...
                      </button>
                    ))}
                  </div>
                  <input
                    type="text"
                    value={newRelFeelings}
                    onChange={(e) => setNewRelFeelings(e.target.value)}
                    placeholder="Ej: Devoción absoluta pero miedo a decepcionarlo, resentimiento silencioso..."
                    className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050]"
                  />
                </div>

                {/* Opinión sobre */}
                <div className="space-y-1.5">
                  <label className="block text-[11px] font-mono text-blue-300 font-semibold flex items-center gap-1">
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>Opinión sobre {newRelCharName.trim() || 'el Personaje Objetivo'}:</span>
                  </label>
                  <div className="flex flex-wrap gap-1 mb-1.5">
                    {getDynamicOpinionSuggestions(newRelType, state.archetype, state.personalityTraits, state.background?.coreValues, newRelCharName).map((op, idx) => (
                      <button
                        key={`op-${idx}`}
                        type="button"
                        onClick={() => setNewRelOpinion(op)}
                        className="px-2 py-0.5 rounded bg-[#0F1115] border border-[#2A2D35] text-[10px] text-[#AAAAAA] hover:text-blue-300 hover:border-blue-400 cursor-pointer truncate max-w-full text-left"
                        title={op}
                      >
                        {op.slice(0, 36)}...
                      </button>
                    ))}
                  </div>
                  <input
                    type="text"
                    value={newRelOpinion}
                    onChange={(e) => setNewRelOpinion(e.target.value)}
                    placeholder="Ej: Lo considera un estratega brillante pero carente de empatía..."
                    className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050]"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddRelForm(false)}
                  className="px-3 py-1.5 rounded-xl text-xs text-[#888888] hover:text-[#E0E0E0] cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleAddRelationship}
                  className="bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] px-4 py-1.5 rounded-xl text-xs font-bold flex items-center space-x-1 cursor-pointer shadow-sm"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Guardar Vínculo</span>
                </button>
              </div>
            </div>
          )}

          {/* Active Relationships List */}
          {relationshipsList.length === 0 ? (
            <div className="bg-[#15171C] border border-dashed border-[#2A2D35] rounded-xl p-6 text-center text-xs text-[#888888]">
              <Users className="w-6 h-6 mx-auto mb-2 text-[#444444]" />
              <p>No se han registrado relaciones aún. Añade sugerencias dinámicas adaptadas arriba o haz clic en "Añadir Vínculo" para conectar personajes de la biblioteca.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {relationshipsList.map((rel) => {
                const isServantMaster = rel.relationshipType.includes('Sirviente → Maestro') || rel.relationshipType.includes('Maestro → Sirviente');
                const isAltFuture = rel.relationshipType.includes('Futuro');
                const isAltPast = rel.relationshipType.includes('Pasado');
                const isAltWardrobe = rel.relationshipType.includes('Rol/Vestuario') || rel.relationshipType.includes('Vestuario');
                
                let badgeStyle = 'bg-[#0F1115] border border-[#2A2D35] text-[#C9A050]';
                if (isAltFuture) {
                  badgeStyle = 'bg-purple-950/70 border border-purple-500/50 text-purple-200';
                } else if (isAltPast) {
                  badgeStyle = 'bg-blue-950/70 border border-blue-500/50 text-blue-200';
                } else if (isAltWardrobe) {
                  badgeStyle = 'bg-emerald-950/70 border border-emerald-500/50 text-emerald-200';
                } else if (isServantMaster) {
                  badgeStyle = 'bg-amber-950/70 border border-amber-500/40 text-amber-300';
                }

                const isEditing = editingRelId === rel.id;

                if (isEditing) {
                  return (
                    <div
                      key={rel.id}
                      className="col-span-1 md:col-span-2 bg-[#15171C] border border-[#C9A050] shadow-lg ring-1 ring-[#C9A050]/30 rounded-xl p-5 space-y-4 animate-scale-up"
                    >
                      {/* Header */}
                      <div className="flex items-center justify-between gap-2 border-b border-[#2A2D35] pb-2">
                        <div className="flex items-center gap-2">
                          <Edit3 className="w-4 h-4 text-[#C9A050]" />
                          <h4 className="text-xs font-mono text-[#C9A050] uppercase font-bold">
                            Modificar Vínculo: <span className="text-[#E0E0E0] normal-case font-serif italic text-sm">{rel.targetCharacterName}</span>
                          </h4>
                        </div>
                        <button
                          type="button"
                          onClick={handleCancelEditRelationship}
                          className="text-xs text-[#888888] hover:text-[#E0E0E0] flex items-center gap-1 cursor-pointer transition-colors"
                        >
                          <X className="w-3.5 h-3.5" />
                          <span>Cancelar</span>
                        </button>
                      </div>

                      {/* Select from Library or Target Name */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-[11px] font-mono text-[#888888] mb-1.5">
                            Vincular a Personaje de la Biblioteca:
                          </label>
                          <select
                            value={editRelCharId}
                            onChange={(e) => {
                              setEditRelCharId(e.target.value);
                              const target = libraryCharacters.find(c => c.id === e.target.value);
                              if (target) {
                                setEditRelCharName(target.name);
                                const isSameGroup = target.variantGroupId && target.variantGroupId === state.variantGroupId;
                                const vLabel = (target.variantLabel || '').toLowerCase();
                                if (isSameGroup || vLabel.includes('futuro') || vLabel.includes('pasado') || vLabel.includes('rol') || vLabel.includes('vestuario')) {
                                  if (vLabel.includes('futuro')) {
                                    setEditRelType('Versión Alterna: Futuro');
                                  } else if (vLabel.includes('pasado')) {
                                    setEditRelType('Versión Alterna: Pasado');
                                  } else if (vLabel.includes('rol') || vLabel.includes('vestuario')) {
                                    setEditRelType('Versión Alterna: Rol/Vestuario');
                                  }
                                }
                              }
                            }}
                            className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050]"
                          >
                            <option value="">-- Mantener o escribir nombre personalizado --</option>
                            {libraryCharacters.map(char => (
                              <option key={char.id} value={char.id}>
                                {char.name} ({char.raceName} - {char.role}) [{char.variantLabel || 'Base'}]
                              </option>
                            ))}
                          </select>
                        </div>

                        <div>
                          <label className="block text-[11px] font-mono text-[#888888] mb-1.5">
                            Nombre del Personaje Objetivo:
                          </label>
                          <input
                            type="text"
                            value={editRelCharName}
                            onChange={(e) => setEditRelCharName(e.target.value)}
                            placeholder="Nombre del personaje..."
                            className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050]"
                          />
                        </div>
                      </div>

                      {/* Relationship Type Selector */}
                      <div>
                        <div className="flex items-center justify-between mb-1.5 flex-wrap gap-1">
                          <label className="block text-[11px] font-mono text-[#888888]">
                            Tipo de Relación / Jerarquía / Versión Alterna:
                          </label>
                        </div>

                        <div className="space-y-1.5 mb-2">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="text-[9px] font-mono text-[#888888] uppercase">🌀 Alternas:</span>
                            {['Versión Alterna: Rol/Vestuario', 'Versión Alterna: Futuro', 'Versión Alterna: Pasado'].map(type => (
                              <button
                                key={type}
                                type="button"
                                onClick={() => setEditRelType(type)}
                                className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold transition-all cursor-pointer ${
                                  editRelType === type
                                    ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                                    : 'bg-[#0F1115] border border-[#2A2D35] text-[#AAAAAA] hover:border-[#C9A050]'
                                }`}
                              >
                                {type}
                              </button>
                            ))}
                          </div>

                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="text-[9px] font-mono text-[#888888] uppercase">👑 Vínculos:</span>
                            {['Sirviente → Maestro (El objetivo es mi Amo / Maestro / Señor)', 'Maestro → Sirviente (El objetivo es mi Sirviente / Mayordomo / Lacayo)', 'Subordinado/a / Bajo Mi Mando', 'Superior / Comandante Oficial', 'Mentor/a → Aprendiz (El objetivo es mi Alumno / Pupilo)', 'Compañero/a de Armas / Igual Rango', 'Rival Jurado / Competidor Directo', 'Interés Romántico / Vínculo Afectivo', 'Hermano/a / Pariente de Sangre'].map(type => (
                              <button
                                key={type}
                                type="button"
                                onClick={() => setEditRelType(type)}
                                className={`px-2 py-0.5 rounded-lg text-[10px] font-medium transition-all cursor-pointer ${
                                  editRelType === type
                                    ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                                    : 'bg-[#0F1115] border border-[#2A2D35] text-[#AAAAAA] hover:border-[#C9A050]'
                                }`}
                              >
                                {type.split('(')[0].trim()}
                              </button>
                            ))}
                          </div>

                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="text-[9px] font-mono text-rose-400 uppercase">💀 Oscuras & Prohibidas:</span>
                            {['Amo/a Dominante ↔ Mascota / Juguete Consentido/a', 'Obsesión Yandere (Posesión Absoluta: jamás permitiré que nadie te toque)', 'Pacto de Sangre / Vínculo Demoníaco Indisoluble', 'Relación Tóxica & Codependencia Destructiva'].map(type => (
                              <button
                                key={type}
                                type="button"
                                onClick={() => setEditRelType(type)}
                                className={`px-2 py-0.5 rounded-lg text-[10px] font-medium transition-all cursor-pointer ${
                                  editRelType === type
                                    ? 'bg-rose-950/70 border border-rose-500 text-rose-200 font-bold shadow-xs'
                                    : 'bg-[#0F1115] border border-rose-900/40 text-rose-300/80 hover:border-rose-500'
                                }`}
                              >
                                {type.split('(')[0].trim()}
                              </button>
                            ))}
                          </div>

                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="text-[9px] font-mono text-pink-400 uppercase">💋 Provocativas:</span>
                            {['Vínculo de Placer y Seducción / Súcubo o Íncubo Tentador/a', 'Rival Frenemies con Alta Tensión Sexual y Deseo Prohibido', 'Cortesana / Concubina de Confianza ↔ Protector Aristócrata'].map(type => (
                              <button
                                key={type}
                                type="button"
                                onClick={() => setEditRelType(type)}
                                className={`px-2 py-0.5 rounded-lg text-[10px] font-medium transition-all cursor-pointer ${
                                  editRelType === type
                                    ? 'bg-pink-950/70 border border-pink-500 text-pink-200 font-bold shadow-xs'
                                    : 'bg-[#0F1115] border border-pink-900/40 text-pink-300/80 hover:border-pink-500'
                                }`}
                              >
                                {type}
                              </button>
                            ))}
                          </div>
                        </div>

                        <select
                          value={editRelType}
                          onChange={(e) => setEditRelType(e.target.value)}
                          className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050]"
                        >
                          {RELATIONSHIP_TYPES.map(type => (
                            <option key={type} value={type}>{type}</option>
                          ))}
                        </select>
                      </div>

                      {/* Interaction Dynamic */}
                      <div>
                        <label className="block text-[11px] font-mono text-[#888888] mb-1.5">
                          Forma de Interacción & Dinámica de Trato:
                        </label>
                        <div className="flex flex-wrap gap-1.5 mb-2">
                          {INTERACTION_DYNAMICS_SUGGESTIONS.slice(0, 4).map((dyn, idx) => (
                            <button
                              key={idx}
                              type="button"
                              onClick={() => setEditRelDynamic(dyn)}
                              className="px-2 py-1 rounded-lg bg-[#0F1115] border border-[#2A2D35] text-[10px] text-[#AAAAAA] hover:text-[#C9A050] hover:border-[#C9A050] truncate max-w-xs text-left cursor-pointer transition-colors"
                              title={dyn}
                            >
                              {dyn}
                            </button>
                          ))}
                        </div>
                        <textarea
                          rows={2}
                          value={editRelDynamic}
                          onChange={(e) => setEditRelDynamic(e.target.value)}
                          placeholder="Describe cómo le habla, cómo se comporta frente a él/ella, tensión o afecto..."
                          className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050] resize-y"
                        />
                      </div>

                      {/* Feelings & Opinion */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-[#222222]">
                        <div className="space-y-1.5">
                          <label className="block text-[11px] font-mono text-[#C9A050] font-semibold flex items-center gap-1">
                            <Heart className="w-3.5 h-3.5" />
                            <span>Sentimientos hacia {editRelCharName.trim() || 'el Personaje Objetivo'}:</span>
                          </label>
                          <div className="flex flex-wrap gap-1 mb-1.5">
                            {getDynamicFeelingsSuggestions(editRelType, state.archetype, state.personalityTraits, state.background?.coreValues).slice(0, 4).map((feel, idx) => (
                              <button
                                key={`edit-feel-${idx}`}
                                type="button"
                                onClick={() => setEditRelFeelings(feel)}
                                className="px-2 py-0.5 rounded bg-[#0F1115] border border-[#2A2D35] text-[10px] text-[#AAAAAA] hover:text-[#C9A050] hover:border-[#C9A050] cursor-pointer truncate max-w-full text-left transition-colors"
                                title={feel}
                              >
                                {feel.slice(0, 36)}...
                              </button>
                            ))}
                          </div>
                          <input
                            type="text"
                            value={editRelFeelings}
                            onChange={(e) => setEditRelFeelings(e.target.value)}
                            placeholder="Ej: Devoción absoluta pero miedo a decepcionarlo..."
                            className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050]"
                          />
                        </div>

                        <div className="space-y-1.5">
                          <label className="block text-[11px] font-mono text-blue-300 font-semibold flex items-center gap-1">
                            <MessageCircle className="w-3.5 h-3.5" />
                            <span>Opinión sobre {editRelCharName.trim() || 'el Personaje Objetivo'}:</span>
                          </label>
                          <div className="flex flex-wrap gap-1 mb-1.5">
                            {getDynamicOpinionSuggestions(editRelType, state.archetype, state.personalityTraits, state.background?.coreValues, editRelCharName).slice(0, 4).map((op, idx) => (
                              <button
                                key={`edit-op-${idx}`}
                                type="button"
                                onClick={() => setEditRelOpinion(op)}
                                className="px-2 py-0.5 rounded bg-[#0F1115] border border-[#2A2D35] text-[10px] text-[#AAAAAA] hover:text-blue-300 hover:border-blue-400 cursor-pointer truncate max-w-full text-left transition-colors"
                                title={op}
                              >
                                {op.slice(0, 36)}...
                              </button>
                            ))}
                          </div>
                          <input
                            type="text"
                            value={editRelOpinion}
                            onChange={(e) => setEditRelOpinion(e.target.value)}
                            placeholder="Ej: Lo considera un estratega brillante..."
                            className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050]"
                          />
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex justify-end gap-2 pt-2 border-t border-[#222222]">
                        <button
                          type="button"
                          onClick={handleCancelEditRelationship}
                          className="px-3.5 py-1.5 rounded-xl text-xs text-[#AAAAAA] hover:text-[#E0E0E0] bg-[#0F1115] border border-[#2A2D35] hover:border-[#444444] cursor-pointer transition-colors"
                        >
                          Cancelar
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSaveEditRelationship(rel.id)}
                          className="bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] px-4 py-1.5 rounded-xl text-xs font-bold flex items-center space-x-1.5 cursor-pointer shadow-sm transition-colors"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Guardar Cambios</span>
                        </button>
                      </div>
                    </div>
                  );
                }

                return (
                  <div
                    key={rel.id}
                    className="bg-[#15171C] border border-[#2A2D35] hover:border-[#C9A050]/40 rounded-xl p-4 flex flex-col justify-between transition-colors space-y-2"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div>
                          <h4 className="text-sm font-serif italic text-[#E0E0E0] font-bold">
                            {rel.targetCharacterName}
                          </h4>
                          <span className={`inline-block px-2 py-0.5 rounded-md text-[10px] font-mono mt-1 font-bold ${badgeStyle}`}>
                            {isAltFuture ? '🔮 ' : isAltPast ? '⏳ ' : isAltWardrobe ? '👗 ' : ''}{rel.relationshipType}
                          </span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <button
                            type="button"
                            onClick={() => handleStartEditRelationship(rel)}
                            className="text-[#888888] hover:text-[#C9A050] p-1.5 rounded-lg hover:bg-[#0F1115] cursor-pointer transition-colors"
                            title="Editar relación / vínculo"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleRemoveRelationship(rel.id)}
                            className="text-[#888888] hover:text-red-400 p-1.5 rounded-lg hover:bg-[#0F1115] cursor-pointer transition-colors"
                            title="Eliminar relación"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                      <p className="text-xs text-[#AAAAAA] leading-relaxed italic bg-[#0F1115]/50 p-2.5 rounded-lg border border-[#222222]">
                        «{rel.interactionDynamic || 'Trato estándar recíproco.'}»
                      </p>
                      {rel.feelingsTowards && (
                        <div className="text-[11px] text-[#C9A050] mt-1.5">
                          <strong className="text-[#888888]">Sentimientos hacia {rel.targetCharacterName}:</strong> {rel.feelingsTowards}
                        </div>
                      )}
                      {rel.opinionOn && (
                        <div className="text-[11px] text-blue-300 mt-1">
                          <strong className="text-[#888888]">Opinión sobre {rel.targetCharacterName}:</strong> {rel.opinionOn}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* 5.1.1 PERSONALIDAD & DINÁMICA ÍNTIMA EN RELACIONES */}
          <div className="mt-8 pt-6 border-t border-[#222222] space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center space-x-2">
                <Heart className="w-4 h-4 text-rose-400" />
                <h4 className="text-sm font-serif italic text-rose-300 font-bold">
                  Personalidad & Dinámica Íntima en Relaciones
                </h4>
              </div>
              <div className="flex items-center space-x-2">
                {state.nsfw?.intimatePersonality ? (
                  <button
                    type="button"
                    onClick={() => {
                      setState(prev => ({
                        ...prev,
                        nsfw: {
                          isNsfwEnabled: prev.nsfw?.isNsfwEnabled ?? false,
                          ageConfirmed: prev.nsfw?.ageConfirmed ?? false,
                          ...prev.nsfw,
                          intimatePersonality: ''
                        }
                      }));
                    }}
                    className="text-[10px] font-mono text-rose-400 hover:text-rose-300 border border-rose-500/40 hover:border-rose-400 px-2 py-0.5 rounded transition-all cursor-pointer"
                    title="Quitar la selección de personalidad íntima"
                  >
                    Quitar selección (Sin definir)
                  </button>
                ) : (
                  <span className="text-[10px] font-mono text-zinc-500 border border-zinc-700/50 px-2 py-0.5 rounded">
                    Sin selección activa
                  </span>
                )}
                <span className="text-[11px] font-mono text-[#AAAAAA] bg-[#15171C] border border-[#2A2D35] px-2.5 py-0.5 rounded-full">
                  Vínculos afectivos & interacción a solas
                </span>
              </div>
            </div>
            <p className="text-[#888888] text-xs leading-relaxed">
              Define el temperamento relacional y la dinámica psicológica del personaje en la intimidad, modulando cómo expresa el apego, la confianza, la timidez o el control en los vínculos de pareja y cercanía profunda. Puedes pulsar en una tarjeta activa para deseleccionarla o usar el botón de quitar selección.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {INTIMATE_PERSONALITIES.map(ip => {
                const isSelected = Boolean(state.nsfw?.intimatePersonality && state.nsfw.intimatePersonality === ip.name);
                return (
                  <button
                    key={ip.id}
                    type="button"
                    onClick={() => {
                      setState(prev => ({
                        ...prev,
                        nsfw: {
                          isNsfwEnabled: prev.nsfw?.isNsfwEnabled ?? false,
                          ageConfirmed: prev.nsfw?.ageConfirmed ?? false,
                          ...prev.nsfw,
                          intimatePersonality: isSelected ? '' : ip.name
                        }
                      }));
                    }}
                    className={`text-left p-3.5 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                      isSelected
                        ? 'bg-[#1C141C] border-rose-500 shadow-sm'
                        : 'bg-[#15171C] border-[#2A2D35] hover:border-[#444]'
                    }`}
                  >
                    <div>
                      <div className="text-xs font-bold text-zinc-200 flex items-center justify-between mb-1.5">
                        <span className={isSelected ? 'text-rose-200 font-bold' : 'text-zinc-200'}>{ip.name}</span>
                        {isSelected && <Check className="w-3.5 h-3.5 text-rose-400 shrink-0" />}
                      </div>
                      <p className="text-[10px] text-zinc-400 leading-relaxed">
                        {ip.description}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* 5.2 HERRAMIENTA UNIFICADA DE TRASFONDO NARRATIVO */}
        <NarrativeBackgroundSuite state={state} setState={setState} />

        {/* 5.4 PERSONALIZACIÓN AVANZADA */}
        <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs space-y-6">
          <div className="flex items-center justify-between border-b border-[#222222] pb-3 flex-wrap gap-2">
            <div className="flex items-center space-x-2">
              <Zap className="w-4 h-4 text-[#C9A050]" />
              <h3 className="text-lg font-serif italic text-[#C9A050]">
                5.4 Personalización Avanzada Modulada por Rasgos & Valores
              </h3>
            </div>
            <button
              type="button"
              onClick={handleApplyAllArchetypePersonalization}
              className="bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center space-x-1.5 cursor-pointer shadow-xs transition-all"
            >
              <Wand2 className="w-3.5 h-3.5" />
              <span>✨ Aplicar Toda la Personalización a Mis Rasgos ({state.personalityTraits?.length || 0})</span>
            </button>
          </div>
          <p className="text-[#888888] text-xs">
            Detalla la voz, registro lingüístico, habilidades especializadas, hábitos y manías cotidianas, y patrones específicos de conducta en los 6 rangos sociales.
          </p>

          {/* 5.4.1 Voz & Forma de Hablar */}
          <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center space-x-2 text-xs font-mono text-[#C9A050] uppercase font-bold">
                <Mic className="w-4 h-4" />
                <span>5.4.1 Voz, Timbre & Forma de Hablar</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => updateAdv(p => ({
                    ...p,
                    voiceTone: dynamicModulation.adaptedVoiceTone || p.voiceTone,
                    speechStyle: dynamicModulation.adaptedSpeechStyle || p.speechStyle,
                    catchphrasesOrIdioms: dynamicModulation.adaptedCatchphrase || p.catchphrasesOrIdioms
                  }))}
                  className="px-2.5 py-1 rounded-lg bg-[#C9A050] text-[#0A0B0E] text-[11px] font-bold cursor-pointer transition-colors flex items-center gap-1 shadow-xs"
                >
                  <Wand2 className="w-3 h-3" />
                  <span>✨ Adaptar a Rasgos</span>
                </button>
                <button
                  type="button"
                  onClick={handleApplyRoleVoiceAndSpeech}
                  className="px-2.5 py-1 rounded-lg bg-[#1A1C22] border border-[#C9A050]/60 text-[#C9A050] hover:bg-[#C9A050] hover:text-[#0A0B0E] text-[11px] font-bold cursor-pointer transition-colors flex items-center gap-1"
                >
                  <Sparkles className="w-3 h-3" />
                  <span>Voz del Rol ({currentRoleName})</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-mono text-[#888888] mb-1.5">
                  Tono y Timbre de Voz:
                </label>
                <div className="flex flex-wrap gap-1 mb-2">
                  {dynamicModulation.suggestedVoiceTones?.map((item, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => updateAdv(p => ({ ...p, voiceTone: item.tone }))}
                      className="px-2 py-0.5 rounded bg-[#0F1115] border border-[#C9A050]/40 text-[10px] text-[#C9A050] hover:bg-[#C9A050] hover:text-[#0A0B0E] cursor-pointer"
                      title={item.reason}
                    >
                      {item.tone}
                    </button>
                  ))}
                </div>
                <select
                  value={adv.voiceTone || VOICE_TONES[0]}
                  onChange={(e) => updateAdv(p => ({ ...p, voiceTone: e.target.value }))}
                  className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050]"
                >
                  {VOICE_TONES.map(t => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-mono text-[#888888] mb-1.5">
                  Forma de Hablar & Registro Lingüístico:
                </label>
                <div className="flex flex-wrap gap-1 mb-2">
                  {dynamicModulation.suggestedSpeechStyles?.map((item, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => updateAdv(p => ({ ...p, speechStyle: item.style }))}
                      className="px-2 py-0.5 rounded bg-[#0F1115] border border-[#C9A050]/40 text-[10px] text-[#C9A050] hover:bg-[#C9A050] hover:text-[#0A0B0E] cursor-pointer"
                      title={item.reason}
                    >
                      {item.style.slice(0, 32)}...
                    </button>
                  ))}
                </div>
                <select
                  value={adv.speechStyle || SPEECH_STYLES[0]}
                  onChange={(e) => updateAdv(p => ({ ...p, speechStyle: e.target.value }))}
                  className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050]"
                >
                  {SPEECH_STYLES.map(s => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5 flex-wrap gap-1">
                <label className="block text-[11px] font-mono text-[#888888]">
                  Muletilla, Modismo o Expresión Recurrente (Inspirada en Valores):
                </label>
                <div className="flex items-center gap-1 flex-wrap">
                  {['Todos', 'Oscuras 💀', 'Provocativas 💋', 'Modernas ⚡', 'Anime/Gacha 🌸', 'Épicas ⚔️'].map(cat => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setSelectedVoiceCategory(cat)}
                      className={`px-2 py-0.5 rounded text-[9px] font-mono transition-all cursor-pointer ${
                        selectedVoiceCategory === cat
                          ? 'bg-[#C9A050] text-[#0A0B0E] font-bold'
                          : 'bg-[#0F1115] border border-[#2A2D35] text-[#888888] hover:text-[#C9A050]'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex flex-wrap gap-1.5 mb-2">
                {dynamicModulation.suggestedCatchphrases?.map((cp, idx) => (
                  <button
                    key={`dyn-cp-${idx}`}
                    type="button"
                    onClick={() => updateAdv(p => ({ ...p, catchphrasesOrIdioms: cp }))}
                    className="px-2.5 py-1 rounded-lg bg-[#0F1115] border border-[#C9A050]/60 text-[10px] text-[#C9A050] hover:bg-[#C9A050] hover:text-[#0A0B0E] cursor-pointer font-medium text-left truncate max-w-xs"
                    title={cp}
                  >
                    ✨ {cp}
                  </button>
                ))}
                {CATCHPHRASES_SUGGESTIONS.filter(cp => {
                  if (selectedVoiceCategory === 'Todos') return true;
                  const lower = cp.toLowerCase();
                  if (selectedVoiceCategory === 'Oscuras 💀') {
                    return lower.includes('rodillas') || lower.includes('dragón negro') || lower.includes('dolor') || lower.includes('muerte') || lower.includes('sombras') || lower.includes('cenizas');
                  }
                  if (selectedVoiceCategory === 'Provocativas 💋') {
                    return lower.includes('cariño') || lower.includes('morderé') || lower.includes('apuestas') || lower.includes('amabilidad');
                  }
                  if (selectedVoiceCategory === 'Modernas ⚡') {
                    return lower.includes('firewall') || lower.includes('precio') || lower.includes('misión') || lower.includes('parámetros') || lower.includes('diagrama');
                  }
                  if (selectedVoiceCategory === 'Anime/Gacha 🌸') {
                    return lower.includes('za~ko') || lower.includes('mío/a') || lower.includes('baka') || lower.includes('ssr') || lower.includes('tch');
                  }
                  if (selectedVoiceCategory === 'Épicas ⚔️') {
                    return lower.includes('alba') || lower.includes('honor') || lower.includes('destino') || lower.includes('predecible');
                  }
                  return true;
                }).slice(0, 6).map((cp, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => updateAdv(p => ({ ...p, catchphrasesOrIdioms: cp }))}
                    className="px-2 py-1 rounded-lg bg-[#0F1115] border border-[#2A2D35] text-[10px] text-[#AAAAAA] hover:text-[#C9A050] hover:border-[#C9A050] cursor-pointer"
                  >
                    {cp}
                  </button>
                ))}
              </div>
              <input
                type="text"
                value={adv.catchphrasesOrIdioms || ''}
                onChange={(e) => updateAdv(p => ({ ...p, catchphrasesOrIdioms: e.target.value }))}
                placeholder="Ej: «Por el filo del alba...», «Interesante...», «No bajes la guardia»"
                className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050]"
              />
            </div>
          </div>

          {/* 5.4.2 Habilidades & Talentos */}
          <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center space-x-2 text-xs font-mono text-[#C9A050] uppercase font-bold">
                <Award className="w-4 h-4" />
                <span>5.4.2 Habilidades & Talentos Especializados</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleApplySynergisticSkills}
                  className="px-3 py-1 rounded-lg bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] text-[11px] font-bold cursor-pointer transition-all flex items-center gap-1 shadow-xs"
                >
                  <Wand2 className="w-3 h-3" />
                  <span>+ Añadir Sinergias con Rasgos</span>
                </button>
                <span className="text-xs font-mono text-[#C9A050]">
                  {(adv.skills || []).length} habilidades activas
                </span>
              </div>
            </div>

            {/* Synergistic Recommended Skills */}
            {dynamicModulation.synergisticSkills && dynamicModulation.synergisticSkills.length > 0 && (
              <div className="bg-[#0F1115] border border-[#C9A050]/40 rounded-xl p-4 space-y-2.5">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <Wand2 className="w-4 h-4 text-[#C9A050]" />
                    <h5 className="text-xs font-mono text-[#C9A050] uppercase font-bold">
                      Habilidades Sinergéticas Recomendadas por Tus Rasgos & Valores
                    </h5>
                  </div>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {dynamicModulation.synergisticSkills.map((item, idx) => {
                    const isSelected = (adv.skills || []).includes(item.skill);
                    return (
                      <button
                        key={`syn-sk-${idx}`}
                        type="button"
                        onClick={() => toggleSkill(item.skill)}
                        className={`px-3 py-1.5 rounded-lg text-[11px] font-medium transition-all flex items-center space-x-1.5 cursor-pointer ${
                          isSelected
                            ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-md'
                            : 'bg-[#15171C] border border-[#C9A050]/50 text-[#E0E0E0] hover:border-[#C9A050] hover:bg-[#1A1C22]'
                        }`}
                        title={item.reason}
                      >
                        {isSelected ? <Check className="w-3 h-3" /> : <Plus className="w-3 h-3 text-[#C9A050]" />}
                        <span>{item.skill}</span>
                        <span className="text-[9px] opacity-75 font-mono">({item.category})</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Canonical Role Skills Card */}
            {roleProfile.specializedSkills && roleProfile.specializedSkills.length > 0 && (
              <div className="bg-[#0F1115] border border-[#2A2D35] rounded-xl p-3.5 space-y-2">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <Swords className="w-3.5 h-3.5 text-[#888888]" />
                    <h5 className="text-[11px] font-mono text-[#AAAAAA] uppercase font-bold">
                      Habilidades Canónicas del Rol: {currentRoleName}
                    </h5>
                  </div>
                  <button
                    type="button"
                    onClick={handleApplyAllRoleSkills}
                    className="px-2.5 py-0.5 rounded bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050] text-[#AAAAAA] hover:text-[#C9A050] text-[10px] font-bold cursor-pointer transition-all"
                  >
                    + Añadir Canónicas
                  </button>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {roleProfile.specializedSkills.map(sk => {
                    const isSelected = (adv.skills || []).includes(sk);
                    return (
                      <button
                        key={`role-sk-${sk}`}
                        type="button"
                        onClick={() => toggleSkill(sk)}
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-medium transition-all flex items-center space-x-1 cursor-pointer ${
                          isSelected
                            ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                            : 'bg-[#15171C] border border-[#2A2D35] text-[#AAAAAA] hover:border-[#C9A050]'
                        }`}
                      >
                        {isSelected && <Check className="w-2.5 h-2.5" />}
                        <span>{sk}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            <div className="space-y-4">
              {SKILLS_CATEGORIES.map(cat => (
                <div key={cat.category} className="bg-[#0F1115] p-3.5 rounded-xl border border-[#222222]">
                  <h5 className="text-[11px] font-mono text-[#C9A050] mb-2 font-bold">{cat.category}</h5>
                  <div className="flex flex-wrap gap-1.5">
                    {cat.skills.map(sk => {
                      const isSelected = (adv.skills || []).includes(sk);
                      return (
                        <button
                          key={sk}
                          type="button"
                          onClick={() => toggleSkill(sk)}
                          className={`px-2.5 py-1 rounded-lg text-[10px] font-medium transition-all flex items-center space-x-1 cursor-pointer ${
                            isSelected
                              ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                              : 'bg-[#15171C] border border-[#2A2D35] text-[#AAAAAA] hover:border-[#C9A050] hover:text-[#E0E0E0]'
                          }`}
                        >
                          {isSelected && <Check className="w-2.5 h-2.5" />}
                          <span>{sk}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>

            <form onSubmit={handleAddCustomSkill} className="flex gap-2 pt-1">
              <input
                type="text"
                value={customSkillInput}
                onChange={(e) => setCustomSkillInput(e.target.value)}
                placeholder="Añadir habilidad personalizada (ej. Forja rúnica, Canto oracular...)"
                className="flex-1 bg-[#0F1115] border border-[#2A2D35] rounded-xl px-3 py-2 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050]"
              />
              <button
                type="submit"
                className="bg-[#1A1C22] border border-[#2A2D35] text-[#C9A050] hover:bg-[#C9A050] hover:text-[#0A0B0E] px-4 py-2 rounded-xl text-xs font-medium cursor-pointer"
              >
                Añadir Habilidad
              </button>
            </form>
          </div>

          {/* 5.4.3 Hábitos & Manías */}
          <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center space-x-2 text-xs font-mono text-[#C9A050] uppercase font-bold">
                <Flame className="w-4 h-4" />
                <span>5.4.3 Hábitos, Manías & Gestualidad</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleApplySynergisticHabits}
                  className="px-3 py-1 rounded-lg bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] text-[11px] font-bold cursor-pointer transition-all flex items-center gap-1 shadow-xs"
                >
                  <Wand2 className="w-3 h-3" />
                  <span>+ Añadir Manías de mis Rasgos</span>
                </button>
                <span className="text-xs font-mono text-[#C9A050]">
                  {(adv.habitsAndMannerisms || []).length} manías seleccionadas
                </span>
              </div>
            </div>

            {/* Dynamic Habits Generated from Active Traits */}
            {dynamicModulation.suggestedHabits && dynamicModulation.suggestedHabits.length > 0 && (
              <div className="bg-[#0F1115] border border-[#C9A050]/40 rounded-xl p-3.5 space-y-2">
                <div className="flex items-center justify-between">
                  <h5 className="text-[11px] font-mono text-[#C9A050] uppercase font-bold flex items-center gap-1.5">
                    <Wand2 className="w-3.5 h-3.5" />
                    <span>Hábitos & Gestos Inspirados en tus Rasgos Activos</span>
                  </h5>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {dynamicModulation.suggestedHabits.map((item, idx) => {
                    const isSelected = (adv.habitsAndMannerisms || []).includes(item.habit);
                    return (
                      <button
                        key={`dyn-h-${idx}`}
                        type="button"
                        onClick={() => toggleHabit(item.habit)}
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-medium transition-all flex items-center space-x-1.5 cursor-pointer ${
                          isSelected
                            ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                            : 'bg-[#15171C] border border-[#C9A050]/40 text-[#CCCCCC] hover:border-[#C9A050]'
                        }`}
                      >
                        {isSelected ? <Check className="w-2.5 h-2.5" /> : <Plus className="w-2.5 h-2.5 text-[#C9A050]" />}
                        <span>{item.habit}</span>
                        <span className="text-[9px] opacity-75 font-mono text-[#C9A050]">[{item.trait}]</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Canonical Role Habits */}
            {roleProfile.habits && roleProfile.habits.length > 0 && (
              <div className="bg-[#0F1115] border border-[#2A2D35] rounded-xl p-3 space-y-1.5">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <h5 className="text-[10px] font-mono text-[#888888] uppercase font-bold flex items-center gap-1">
                    <Flame className="w-3 h-3" />
                    <span>Canónicos del Rol ({currentRoleName})</span>
                  </h5>
                  <button
                    type="button"
                    onClick={handleApplyAllRoleHabits}
                    className="px-2 py-0.5 rounded bg-[#1A1C22] border border-[#2A2D35] text-[#AAAAAA] hover:text-[#C9A050] text-[9px] font-bold cursor-pointer"
                  >
                    + Añadir Todos del Rol
                  </button>
                </div>
                <div className="flex flex-wrap gap-1">
                  {roleProfile.habits.map(habit => {
                    const isSelected = (adv.habitsAndMannerisms || []).includes(habit);
                    return (
                      <button
                        key={`role-h-${habit}`}
                        type="button"
                        onClick={() => toggleHabit(habit)}
                        className={`px-2 py-0.5 rounded text-[10px] font-medium transition-all flex items-center space-x-1 cursor-pointer ${
                          isSelected
                            ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                            : 'bg-[#15171C] border border-[#2A2D35] text-[#888888] hover:border-[#C9A050]'
                        }`}
                      >
                        {isSelected && <Check className="w-2.5 h-2.5" />}
                        <span>{habit}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Comportamientos Rítmicos, Danzantes & Burlones (Chamánico / Fénec 🦊) */}
            <div className="bg-[#0F1115] border border-[#C9A050]/40 rounded-xl p-3.5 space-y-2">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <h5 className="text-[11px] font-mono text-[#C9A050] uppercase font-bold flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#C9A050]" />
                  <span>Comportamientos Rítmicos, Chamánicos & Burlones (Fénec 🦊)</span>
                </h5>
                <button
                  type="button"
                  onClick={handleApplyAllRhythmicHabits}
                  className="px-2.5 py-1 rounded bg-[#1A1C22] border border-[#C9A050]/60 text-[#C9A050] hover:bg-[#C9A050] hover:text-[#0A0B0E] text-[10px] font-bold cursor-pointer transition-colors shadow-xs"
                >
                  + Añadir Todos los Rítmicos & Burlones
                </button>
              </div>
              <p className="text-[10px] text-[#888888] leading-relaxed">
                Gestualidad rítmica de danza tribal en arena, balanceo de colas pastel, poses desafiantes con máscara de cráneo animal y burlas afectuosas.
              </p>
              <div className="flex flex-wrap gap-1.5">
                {RHYTHMIC_MOCKING_HABITS.map((habit, idx) => {
                  const isSelected = (adv.habitsAndMannerisms || []).includes(habit);
                  return (
                    <div key={`rhythmic-h-${idx}`} className="inline-flex items-center">
                      <button
                        type="button"
                        onClick={() => toggleHabit(habit)}
                        className={`px-2.5 py-1 rounded-l-lg text-[10px] font-medium transition-all flex items-center space-x-1.5 cursor-pointer ${
                          isSelected
                            ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                            : 'bg-[#15171C] border border-[#C9A050]/30 text-[#CCCCCC] hover:border-[#C9A050] hover:text-[#FFFFFF]'
                        }`}
                        title="Haz clic para seleccionar o deseleccionar"
                      >
                        {isSelected ? <Check className="w-2.5 h-2.5" /> : <Plus className="w-2.5 h-2.5 text-[#C9A050]" />}
                        <span>{habit}</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setCustomHabitInput(habit)}
                        className={`px-1.5 py-1 rounded-r-lg text-[9px] border-l-0 transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-[#B08A40] text-[#0A0B0E] hover:bg-[#977432]'
                            : 'bg-[#15171C] border border-l-0 border-[#C9A050]/30 text-[#888888] hover:text-[#C9A050]'
                        }`}
                        title="Copiar al campo de entrada personalizada para editar"
                      >
                        ✎
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Comportamientos Felinos Urbanos & Streetwear (🐾) */}
            <div className="bg-[#0F1115] border border-[#C9A050]/40 rounded-xl p-3.5 space-y-2">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <h5 className="text-[11px] font-mono text-[#C9A050] uppercase font-bold flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#C9A050]" />
                  <span>Comportamientos Felinos Urbanos & Streetwear (🐾)</span>
                </h5>
                <button
                  type="button"
                  onClick={handleApplyAllFelineUrbanHabits}
                  className="px-2.5 py-1 rounded bg-[#1A1C22] border border-[#C9A050]/60 text-[#C9A050] hover:bg-[#C9A050] hover:text-[#0A0B0E] text-[10px] font-bold cursor-pointer transition-colors shadow-xs"
                >
                  + Añadir Todos los Felinos Urbanos
                </button>
              </div>
              <p className="text-[10px] text-[#888888] leading-relaxed">
                Gestos relajados y juguetones de estética urbana: saludo felino mostrando almohadillas (Nikukyu), porte descarado de chaqueta caída y descanso sobre pupitres.
              </p>
              <div className="flex flex-wrap gap-1.5">
                {FELINE_URBAN_HABITS.map((habit, idx) => {
                  const isSelected = (adv.habitsAndMannerisms || []).includes(habit);
                  return (
                    <div key={`feline-h-${idx}`} className="inline-flex items-center">
                      <button
                        type="button"
                        onClick={() => toggleHabit(habit)}
                        className={`px-2.5 py-1 rounded-l-lg text-[10px] font-medium transition-all flex items-center space-x-1.5 cursor-pointer ${
                          isSelected
                            ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                            : 'bg-[#15171C] border border-[#C9A050]/30 text-[#CCCCCC] hover:border-[#C9A050] hover:text-[#FFFFFF]'
                        }`}
                        title="Haz clic para seleccionar o deseleccionar"
                      >
                        {isSelected ? <Check className="w-2.5 h-2.5" /> : <Plus className="w-2.5 h-2.5 text-[#C9A050]" />}
                        <span>{habit}</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setCustomHabitInput(habit)}
                        className={`px-1.5 py-1 rounded-r-lg text-[9px] border-l-0 transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-[#B08A40] text-[#0A0B0E] hover:bg-[#977432]'
                            : 'bg-[#15171C] border border-l-0 border-[#C9A050]/30 text-[#888888] hover:text-[#C9A050]'
                        }`}
                        title="Copiar al campo de entrada personalizada para editar"
                      >
                        ✎
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Habits Filter Tabs */}
            <div className="flex items-center justify-between flex-wrap gap-2 pt-1 border-t border-[#222222]">
              <span className="text-[11px] font-mono text-[#888888]">
                Explorar Manías & Hábitos por Temática:
              </span>
              <div className="flex items-center gap-1.5 flex-wrap">
                {['Todos', 'Felinos & Streetwear 🐾', 'Rítmicos & Burlones 🦊', 'Anime & Gacha 🌸', 'Provocativos 💋', 'Oscuros 💀', 'Modernos ⚡', 'Marciales 🗡️'].map(cat => {
                  const isSelected = selectedHabitsCategory === cat;
                  return (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setSelectedHabitsCategory(cat)}
                      className={`px-2 py-0.5 rounded text-[10px] font-mono transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                          : 'bg-[#0F1115] border border-[#2A2D35] text-[#AAAAAA] hover:text-[#E0E0E0] hover:border-[#C9A050]'
                      }`}
                    >
                      {cat}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="flex flex-wrap gap-1.5 max-h-72 overflow-y-auto pr-1">
              {HABITS_AND_MANNERISMS_POOL.filter(habit => {
                if (selectedHabitsCategory === 'Todos') return true;
                const lower = habit.toLowerCase();
                if (selectedHabitsCategory === 'Felinos & Streetwear 🐾') {
                  return lower.includes('almohadillas') || lower.includes('nya') || lower.includes('pupitre') || lower.includes('chaqueta') || lower.includes('felino') || lower.includes('puchero') || lower.includes('gato');
                }
                if (selectedHabitsCategory === 'Rítmicos & Burlones 🦊') {
                  return lower.includes('baila') || lower.includes('tararea') || lower.includes('cráneo') || lower.includes('máscara') || lower.includes('picardía') || lower.includes('saca la lengua') || lower.includes('broma') || lower.includes('burlon') || lower.includes('burlón') || lower.includes('pastel') || lower.includes('cola') || lower.includes('descalzas') || lower.includes('tintinear') || lower.includes('provoca') || lower.includes('esponja');
                }
                if (selectedHabitsCategory === 'Oscuros 💀') {
                  return lower.includes('yandere') || lower.includes('sangre') || lower.includes('daga') || lower.includes('yugular') || lower.includes('dolor') || lower.includes('inquietante') || lower.includes('sombríos') || lower.includes('arma al reflexionar') || lower.includes('sin inmutarse') || lower.includes('amenazas');
                }
                if (selectedHabitsCategory === 'Provocativos 💋') {
                  return lower.includes('labio') || lower.includes('clavícula') || lower.includes('piernas') || lower.includes('coqueta') || lower.includes('susurrándole') || lower.includes('pícara') || lower.includes('escote') || lower.includes('mentón') || lower.includes('espacio personal') || lower.includes('dedo');
                }
                if (selectedHabitsCategory === 'Modernos ⚡') {
                  return lower.includes('holográfica') || lower.includes('chicle') || lower.includes('implantes') || lower.includes('auriculares') || lower.includes('cigarrillo') || lower.includes('synthwave') || lower.includes('teclea') || lower.includes('anteojos');
                }
                if (selectedHabitsCategory === 'Anime & Gacha 🌸') {
                  return lower.includes('akanbe') || lower.includes('mesugaki') || lower.includes('chuunibyou') || lower.includes('tsundere') || lower.includes('kemono') || lower.includes('cola') || lower.includes('idol') || lower.includes('ssr') || lower.includes('sonroja') || lower.includes('burlona') || lower.includes('baila') || lower.includes('tararea') || lower.includes('cráneo') || lower.includes('máscara') || lower.includes('picardía');
                }
                if (selectedHabitsCategory === 'Marciales 🗡️') {
                  return lower.includes('guantes') || lower.includes('contacto visual') || lower.includes('fórmulas') || lower.includes('pared') || lower.includes('moneda') || lower.includes('comida') || lower.includes('marcial') || lower.includes('oreja') || lower.includes('suspiro') || lower.includes('ave rapaz') || lower.includes('pasos') || lower.includes('cuaderno') || lower.includes('arma');
                }
                return true;
              }).map(habit => {
                const isSelected = (adv.habitsAndMannerisms || []).includes(habit);
                return (
                  <button
                    key={habit}
                    type="button"
                    onClick={() => toggleHabit(habit)}
                    className={`px-2 py-1 rounded-lg text-[10px] font-medium transition-all flex items-center space-x-1 cursor-pointer ${
                      isSelected
                        ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                        : 'bg-[#0F1115] border border-[#2A2D35] text-[#AAAAAA] hover:border-[#C9A050] hover:text-[#E0E0E0]'
                    }`}
                  >
                    {isSelected && <Check className="w-2.5 h-2.5" />}
                    <span>{habit}</span>
                  </button>
                );
              })}
            </div>

            <form onSubmit={handleAddCustomHabit} className="flex gap-2 pt-1">
              <input
                type="text"
                value={customHabitInput}
                onChange={(e) => setCustomHabitInput(e.target.value)}
                placeholder="Añadir o editar hábito o manía personalizada (ej: Baila descalza sobre la arena, saca la lengua, tararea...)..."
                className="flex-1 bg-[#0F1115] border border-[#2A2D35] rounded-xl px-3 py-2 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050]"
              />
              <button
                type="submit"
                className="bg-[#1A1C22] border border-[#2A2D35] text-[#C9A050] hover:bg-[#C9A050] hover:text-[#0A0B0E] px-4 py-2 rounded-xl text-xs font-medium cursor-pointer"
              >
                Añadir Manía
              </button>
            </form>
          </div>

          {/* 5.4.4 Forma de Comportarse con Personajes Específicos */}
          <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-5 space-y-5">
            <div className="flex items-center justify-between flex-wrap gap-2 border-b border-[#222222] pb-3">
              <div className="flex items-center space-x-2 text-xs font-mono text-[#C9A050] uppercase font-bold">
                <MessageSquare className="w-4 h-4" />
                <span>5.4.4 Comportamiento y Trato por Rangos / Tipos de Personaje</span>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={handleApplyArchetypeBehaviors}
                  className="bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all shadow-xs cursor-pointer"
                >
                  <Wand2 className="w-3.5 h-3.5" />
                  <span>✨ Adaptar a Mis Rasgos ({state.personalityTraits?.length || 0})</span>
                </button>
                <button
                  type="button"
                  onClick={handleApplyRoleBehaviors}
                  className="bg-[#1A1C22] border border-[#C9A050]/60 text-[#C9A050] hover:bg-[#C9A050] hover:text-[#0A0B0E] px-3 py-1.5 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all shadow-xs cursor-pointer"
                >
                  <Crown className="w-3.5 h-3.5" />
                  <span>⚡ Trato Canónico de Rol</span>
                </button>
              </div>
            </div>

            {/* Quick Thematic Style Presets for 6 Ranks */}
            <div className="flex items-center justify-between flex-wrap gap-2 bg-[#0F1115] border border-[#2A2D35] p-2.5 rounded-xl">
              <span className="text-[10px] font-mono text-[#888888] uppercase font-semibold">
                Estilos Temáticos Globales para los 6 Rangos:
              </span>
              <div className="flex items-center gap-1.5 flex-wrap">
                <button
                  type="button"
                  onClick={applyDarkBehaviorPreset}
                  className="px-2.5 py-1 rounded-lg bg-rose-950/50 border border-rose-900/60 text-rose-300 hover:bg-rose-900 hover:text-white text-[10px] font-mono font-bold transition-all cursor-pointer shadow-xs"
                >
                  💀 Oscuro / Dominante
                </button>
                <button
                  type="button"
                  onClick={applySensualBehaviorPreset}
                  className="px-2.5 py-1 rounded-lg bg-pink-950/50 border border-pink-900/60 text-pink-300 hover:bg-pink-900 hover:text-white text-[10px] font-mono font-bold transition-all cursor-pointer shadow-xs"
                >
                  💋 Sensual / Femme Fatale
                </button>
                <button
                  type="button"
                  onClick={applyCyberBehaviorPreset}
                  className="px-2.5 py-1 rounded-lg bg-cyan-950/50 border border-cyan-900/60 text-cyan-300 hover:bg-cyan-900 hover:text-white text-[10px] font-mono font-bold transition-all cursor-pointer shadow-xs"
                >
                  ⚡ Cyber / Spec-Ops
                </button>
                <button
                  type="button"
                  onClick={applyAnimeBehaviorPreset}
                  className="px-2.5 py-1 rounded-lg bg-amber-950/50 border border-amber-900/60 text-amber-300 hover:bg-amber-900 hover:text-white text-[10px] font-mono font-bold transition-all cursor-pointer shadow-xs"
                >
                  🌸 Anime / Mesugaki-Tsundere
                </button>
              </div>
            </div>

            <p className="text-[11px] text-[#888888]">
              Establece cómo modula su conducta, tono y lenguaje corporal según la jerarquía y naturaleza del interlocutor. Cada categoría ofrece opciones adaptadas directamente a sus rasgos psicológicos y valores morales.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* 1. Con Superiores y Figuras de Autoridad */}
              <div className="space-y-2">
                <label className="block text-[11px] font-mono text-[#888888] font-semibold">
                  1. Con Superiores y Figuras de Autoridad:
                </label>
                <div className="flex flex-wrap gap-1">
                  {dynamicModulation.behaviorSuggestionsByRank?.withAuthority?.map((sug, idx) => (
                    <button
                      key={`auth-dyn-${idx}`}
                      type="button"
                      onClick={() => updateAdv(p => ({
                        ...p,
                        specificInteractions: { ...p.specificInteractions, withAuthority: sug.text }
                      }))}
                      className="px-2 py-0.5 rounded bg-[#0F1115] border border-[#C9A050]/50 text-[10px] text-[#C9A050] hover:bg-[#C9A050] hover:text-[#0A0B0E] cursor-pointer font-mono truncate max-w-full text-left"
                      title={sug.text}
                    >
                      ✨ [{sug.tag}]: {sug.text.slice(0, 30)}...
                    </button>
                  ))}
                </div>
                <textarea
                  rows={2}
                  value={adv.specificInteractions?.withAuthority || ''}
                  onChange={(e) => updateAdv(p => ({
                    ...p,
                    specificInteractions: { ...p.specificInteractions, withAuthority: e.target.value }
                  }))}
                  placeholder="Ej: Respeto protocolario pero con mirada firme y analítica..."
                  className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050] resize-y leading-relaxed"
                />
              </div>

              {/* 2. Con Compañeros y Personas de Igual Rango (Pares) */}
              <div className="space-y-2">
                <label className="block text-[11px] font-mono text-[#888888] font-semibold">
                  2. Con Compañeros y Personas de Igual Rango (Pares):
                </label>
                <div className="flex flex-wrap gap-1">
                  {dynamicModulation.behaviorSuggestionsByRank?.withPeers?.map((sug, idx) => (
                    <button
                      key={`peer-dyn-${idx}`}
                      type="button"
                      onClick={() => updateAdv(p => ({
                        ...p,
                        specificInteractions: { ...p.specificInteractions, withPeers: sug.text }
                      }))}
                      className="px-2 py-0.5 rounded bg-[#0F1115] border border-[#C9A050]/50 text-[10px] text-[#C9A050] hover:bg-[#C9A050] hover:text-[#0A0B0E] cursor-pointer font-mono truncate max-w-full text-left"
                      title={sug.text}
                    >
                      ✨ [{sug.tag}]: {sug.text.slice(0, 30)}...
                    </button>
                  ))}
                </div>
                <textarea
                  rows={2}
                  value={adv.specificInteractions?.withPeers || ''}
                  onChange={(e) => updateAdv(p => ({
                    ...p,
                    specificInteractions: { ...p.specificInteractions, withPeers: e.target.value }
                  }))}
                  placeholder="Ej: Camaradería táctica, trato directo de igual a igual, sin pretensiones..."
                  className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050] resize-y leading-relaxed"
                />
              </div>

              {/* 3. Con Amigos y Aliados de Confianza */}
              <div className="space-y-2">
                <label className="block text-[11px] font-mono text-[#888888] font-semibold">
                  3. Con Amigos y Aliados de Confianza:
                </label>
                <div className="flex flex-wrap gap-1">
                  {dynamicModulation.behaviorSuggestionsByRank?.withFriends?.map((sug, idx) => (
                    <button
                      key={`frn-dyn-${idx}`}
                      type="button"
                      onClick={() => updateAdv(p => ({
                        ...p,
                        specificInteractions: { ...p.specificInteractions, withFriends: sug.text }
                      }))}
                      className="px-2 py-0.5 rounded bg-[#0F1115] border border-[#C9A050]/50 text-[10px] text-[#C9A050] hover:bg-[#C9A050] hover:text-[#0A0B0E] cursor-pointer font-mono truncate max-w-full text-left"
                      title={sug.text}
                    >
                      ✨ [{sug.tag}]: {sug.text.slice(0, 30)}...
                    </button>
                  ))}
                </div>
                <textarea
                  rows={2}
                  value={adv.specificInteractions?.withFriends || ''}
                  onChange={(e) => updateAdv(p => ({
                    ...p,
                    specificInteractions: { ...p.specificInteractions, withFriends: e.target.value }
                  }))}
                  placeholder="Ej: Calidez genuina, baja sus defensas, bromas cómplices y lealtad incondicional..."
                  className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050] resize-y leading-relaxed"
                />
              </div>

              {/* 4. Con Aprendices y Subordinados */}
              <div className="space-y-2">
                <label className="block text-[11px] font-mono text-[#888888] font-semibold">
                  4. Con Aprendices y Subordinados:
                </label>
                <div className="flex flex-wrap gap-1">
                  {dynamicModulation.behaviorSuggestionsByRank?.withSubordinates?.map((sug, idx) => (
                    <button
                      key={`sub-dyn-${idx}`}
                      type="button"
                      onClick={() => updateAdv(p => ({
                        ...p,
                        specificInteractions: { ...p.specificInteractions, withSubordinates: sug.text }
                      }))}
                      className="px-2 py-0.5 rounded bg-[#0F1115] border border-[#C9A050]/50 text-[10px] text-[#C9A050] hover:bg-[#C9A050] hover:text-[#0A0B0E] cursor-pointer font-mono truncate max-w-full text-left"
                      title={sug.text}
                    >
                      ✨ [{sug.tag}]: {sug.text.slice(0, 30)}...
                    </button>
                  ))}
                </div>
                <textarea
                  rows={2}
                  value={adv.specificInteractions?.withSubordinates || ''}
                  onChange={(e) => updateAdv(p => ({
                    ...p,
                    specificInteractions: { ...p.specificInteractions, withSubordinates: e.target.value }
                  }))}
                  placeholder="Ej: Exigente con la disciplina pero ferozmente protector/a..."
                  className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050] resize-y leading-relaxed"
                />
              </div>

              {/* 5. Con Desconocidos y Sospechosos */}
              <div className="space-y-2">
                <label className="block text-[11px] font-mono text-[#888888] font-semibold">
                  5. Con Desconocidos y Sospechosos:
                </label>
                <div className="flex flex-wrap gap-1">
                  {dynamicModulation.behaviorSuggestionsByRank?.withStrangers?.map((sug, idx) => (
                    <button
                      key={`str-dyn-${idx}`}
                      type="button"
                      onClick={() => updateAdv(p => ({
                        ...p,
                        specificInteractions: { ...p.specificInteractions, withStrangers: sug.text }
                      }))}
                      className="px-2 py-0.5 rounded bg-[#0F1115] border border-[#C9A050]/50 text-[10px] text-[#C9A050] hover:bg-[#C9A050] hover:text-[#0A0B0E] cursor-pointer font-mono truncate max-w-full text-left"
                      title={sug.text}
                    >
                      ✨ [{sug.tag}]: {sug.text.slice(0, 30)}...
                    </button>
                  ))}
                </div>
                <textarea
                  rows={2}
                  value={adv.specificInteractions?.withStrangers || ''}
                  onChange={(e) => updateAdv(p => ({
                    ...p,
                    specificInteractions: { ...p.specificInteractions, withStrangers: e.target.value }
                  }))}
                  placeholder="Ej: Distancia protocolaria, cortesía fría y cautelosa..."
                  className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050] resize-y leading-relaxed"
                />
              </div>

              {/* 6. Con Rivales y Enemigos Mortales */}
              <div className="space-y-2">
                <label className="block text-[11px] font-mono text-[#888888] font-semibold">
                  6. Con Rivales y Enemigos Mortales:
                </label>
                <div className="flex flex-wrap gap-1">
                  {dynamicModulation.behaviorSuggestionsByRank?.withEnemies?.map((sug, idx) => (
                    <button
                      key={`enm-dyn-${idx}`}
                      type="button"
                      onClick={() => updateAdv(p => ({
                        ...p,
                        specificInteractions: { ...p.specificInteractions, withEnemies: sug.text }
                      }))}
                      className="px-2 py-0.5 rounded bg-[#0F1115] border border-[#C9A050]/50 text-[10px] text-[#C9A050] hover:bg-[#C9A050] hover:text-[#0A0B0E] cursor-pointer font-mono truncate max-w-full text-left"
                      title={sug.text}
                    >
                      ✨ [{sug.tag}]: {sug.text.slice(0, 30)}...
                    </button>
                  ))}
                </div>
                <textarea
                  rows={2}
                  value={adv.specificInteractions?.withEnemies || ''}
                  onChange={(e) => updateAdv(p => ({
                    ...p,
                    specificInteractions: { ...p.specificInteractions, withEnemies: e.target.value }
                  }))}
                  placeholder="Ej: Frialdad elegante, ironía mordaz sin perder la calma..."
                  className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] outline-none focus:border-[#C9A050] resize-y leading-relaxed"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Live Real-Time Canonical Description Preview */}
        <div className="bg-[#15171C] border border-[#2A2D35] rounded-2xl p-6 shadow-xs space-y-3 mt-6">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center space-x-2 text-xs font-mono text-[#C9A050]">
              <Sparkles className="w-4 h-4 text-[#C9A050]" />
              <span className="font-bold uppercase tracking-wider">Descripción Canónica en Tiempo Real</span>
            </div>

            <div className="flex items-center space-x-2">
              <div className="flex items-center bg-[#0F1115] border border-[#2A2D35] rounded-lg p-0.5 text-[11px] font-mono">
                <button
                  type="button"
                  onClick={() => setCanonicalPreviewMode('background')}
                  className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                    canonicalPreviewMode === 'background'
                      ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                      : 'text-[#888888] hover:text-[#E0E0E0]'
                  }`}
                >
                  Trasfondo (Estado 5)
                </button>
                <button
                  type="button"
                  onClick={() => setCanonicalPreviewMode('fullSheet')}
                  className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                    canonicalPreviewMode === 'fullSheet'
                      ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                      : 'text-[#888888] hover:text-[#E0E0E0]'
                  }`}
                >
                  Ficha Canónica Completa
                </button>
              </div>

              <button
                type="button"
                onClick={() => handleCopyCanonical(
                  canonicalPreviewMode === 'background'
                    ? formatBackgroundCanonicalDescription(state)
                    : generateCharacterSheetText(state)
                )}
                className="px-3 py-1 rounded-lg bg-[#0F1115] border border-[#2A2D35] hover:border-[#C9A050] text-xs font-mono text-[#E0E0E0] hover:text-[#C9A050] transition-all cursor-pointer flex items-center space-x-1.5"
                title="Copiar descripción canónica"
              >
                {copiedCanonical ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedCanonical ? '¡Copiado!' : 'Copiar'}</span>
              </button>
            </div>
          </div>

          <div className="bg-[#0F1115] border border-[#222222] rounded-xl p-4 text-xs text-[#E0E0E0] font-mono leading-relaxed whitespace-pre-wrap max-h-80 overflow-y-auto">
            {canonicalPreviewMode === 'background'
              ? formatBackgroundCanonicalDescription(state)
              : generateCharacterSheetText(state)}
          </div>

          <div className="text-[11px] text-[#888888] flex items-center space-x-1.5">
            <Eye className="w-3.5 h-3.5 text-[#C9A050]" />
            <span>Las selecciones de Zona de Ajuste/Cobertura se reflejan inmediatamente en esta vista, en la Ficha Técnica (Estado 7) y en los prompts IA.</span>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="mt-10 flex justify-between items-center">
        <button
          onClick={onBack}
          className="text-[#888888] hover:text-[#E0E0E0] px-4 py-3 rounded-xl font-medium text-sm flex items-center space-x-2 transition-all cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Volver: Rol y Equipo</span>
        </button>
        <button
          onClick={onNext}
          className="bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] px-6 py-3 rounded-xl font-semibold text-sm flex items-center space-x-2 transition-all shadow-md cursor-pointer"
        >
          <span>Siguiente: Compilación / Ficha Técnica</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
