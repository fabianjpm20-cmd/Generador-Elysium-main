import React, { useState, useMemo } from 'react';
import { CharacterState, NsfwConfig } from '../types';
import {
  AREOLA_COLORS,
  AREOLA_SIZES,
  NIPPLE_TYPES,
  PUBIC_HAIR_STYLES,
  BODY_SENSITIVITIES,
  GENITAL_TYPES,
  GENITAL_SIZES,
  GENITAL_DETAILS,
  INTIMATE_PERSONALITIES,
  EXPLICIT_LINGERIE_OPTIONS
} from '../data/nsfwData';
import { ShieldAlert, Check, X, Flame, Heart, Sparkles } from 'lucide-react';

interface NsfwModalProps {
  isOpen: boolean;
  onClose: () => void;
  state?: CharacterState;
  characterState?: CharacterState;
  setState?: React.Dispatch<React.SetStateAction<CharacterState>>;
  onUpdateNsfwConfig?: (updatedNsfw: NsfwConfig) => void;
}

export const NsfwModal: React.FC<NsfwModalProps> = ({
  isOpen,
  onClose,
  state,
  characterState,
  setState,
  onUpdateNsfwConfig
}) => {
  if (!isOpen) return null;

  const targetCharacter = characterState || state;
  const currentNsfw: NsfwConfig = targetCharacter?.nsfw || {
    isNsfwEnabled: false,
    ageConfirmed: false,
    areolaColor: AREOLA_COLORS[0].name,
    areolaSize: AREOLA_SIZES[1].name,
    nippleType: NIPPLE_TYPES[0].name,
    pubicHairStyle: PUBIC_HAIR_STYLES[0].name,
    genitalType: GENITAL_TYPES[0].name,
    genitalSize: GENITAL_SIZES[1].name,
    genitalDetails: GENITAL_DETAILS[0].name,
    intimatePersonality: INTIMATE_PERSONALITIES[1].name,
    bodySensitivities: ['BS2', 'BS3', 'BS5'],
    fetishesAndPreferences: []
  };

  const [hasConfirmedAge, setHasConfirmedAge] = useState<boolean>(currentNsfw.ageConfirmed);
  const [isEnabled, setIsEnabled] = useState<boolean>(currentNsfw.isNsfwEnabled);
  const [areolaColor, setAreolaColor] = useState(currentNsfw.areolaColor || AREOLA_COLORS[0].name);
  const [areolaSize, setAreolaSize] = useState(currentNsfw.areolaSize || AREOLA_SIZES[1].name);
  const [nippleType, setNippleType] = useState(currentNsfw.nippleType || NIPPLE_TYPES[0].name);
  const [pubicHair, setPubicHair] = useState(currentNsfw.pubicHairStyle || PUBIC_HAIR_STYLES[0].name);
  const [genitalType, setGenitalType] = useState(currentNsfw.genitalType || GENITAL_TYPES[0].name);
  const [genitalSize, setGenitalSize] = useState(currentNsfw.genitalSize || GENITAL_SIZES[1].name);
  
  const initialDetails: string[] = useMemo(() => {
    const raw = currentNsfw.genitalDetails;
    if (Array.isArray(raw)) return raw;
    if (typeof raw === 'string' && raw.trim()) return [raw];
    return [GENITAL_DETAILS[0].name];
  }, [currentNsfw.genitalDetails]);

  const [genitalDetails, setGenitalDetails] = useState<string[]>(initialDetails);
  const [intimatePersonality, setPersonality] = useState(currentNsfw.intimatePersonality || '');
  const [sensitivities, setSensitivities] = useState<string[]>(currentNsfw.bodySensitivities || ['BS2', 'BS3', 'BS5']);

  const handleToggleSensitivity = (id: string) => {
    setSensitivities(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const handleToggleGenitalDetail = (name: string) => {
    setGenitalDetails(prev =>
      prev.includes(name) ? prev.filter(item => item !== name) : [...prev, name]
    );
  };

  const handleSave = () => {
    const updatedConfig: NsfwConfig = {
      isNsfwEnabled: isEnabled && hasConfirmedAge,
      ageConfirmed: hasConfirmedAge,
      areolaColor,
      areolaSize,
      nippleType,
      pubicHairStyle: pubicHair,
      genitalType,
      genitalSize,
      genitalDetails,
      intimatePersonality,
      bodySensitivities: sensitivities,
      fetishesAndPreferences: currentNsfw.fetishesAndPreferences
    };

    if (onUpdateNsfwConfig) {
      onUpdateNsfwConfig(updatedConfig);
    } else if (setState) {
      setState(prev => ({
        ...prev,
        nsfw: updatedConfig
      }));
    }
    onClose();
  };

  const handleDisable = () => {
    const updatedConfig: NsfwConfig = {
      ...currentNsfw,
      isNsfwEnabled: false
    };

    if (onUpdateNsfwConfig) {
      onUpdateNsfwConfig(updatedConfig);
    } else if (setState) {
      setState(prev => ({
        ...prev,
        nsfw: updatedConfig
      }));
    }
    setIsEnabled(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-[#12141A] border border-[#3A2228] rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#262832] pb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-rose-600 to-amber-600 flex items-center justify-center text-white font-bold shadow-md">
              <Flame className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-rose-300 flex items-center gap-2">
                Configuración de Modo Adulto (R+18)
                <span className="text-[10px] uppercase tracking-widest px-2 py-0.5 rounded-full bg-rose-950/80 border border-rose-700 text-rose-300 font-sans">
                  Contenido Íntimo
                </span>
              </h3>
              <p className="text-xs text-[#8A8F9E]">
                Desbloquea anatomía explícita, lencería desértica avanzada y conducta íntima.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-[#8A8F9E] hover:text-[#E0E0E0] cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Age Verification Box */}
        {!hasConfirmedAge ? (
          <div className="bg-rose-950/30 border border-rose-800/60 rounded-xl p-5 space-y-4">
            <div className="flex items-start gap-3">
              <ShieldAlert className="w-6 h-6 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-bold text-rose-200">Verificación de Edad Requerida</h4>
                <p className="text-xs text-rose-300/80 mt-1 leading-relaxed">
                  Este módulo contiene representaciones anatómicas explícitas, lencería para adultos y dinámicas de interacción íntima. Debes tener 18 años o más para habilitar este contenido en tu dispositivo local.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setHasConfirmedAge(true);
                setIsEnabled(true);
              }}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-rose-600 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white font-bold text-xs tracking-wider uppercase transition-all shadow-md cursor-pointer"
            >
              Confirmo que tengo 18 años o más — Habilitar R+18
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Status toggle */}
            <div className="flex items-center justify-between bg-[#181A22] border border-[#282B36] p-3.5 rounded-xl">
              <div className="flex items-center gap-2.5">
                <div className="w-3 h-3 rounded-full bg-rose-500 animate-pulse" />
                <span className="text-xs font-bold text-[#E0E0E0]">Estado del Modo Adulto R+18</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsEnabled(!isEnabled)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                    isEnabled
                      ? 'bg-rose-600 text-white'
                      : 'bg-[#252834] text-[#8A8F9E]'
                  }`}
                >
                  {isEnabled ? 'Activado' : 'Desactivado'}
                </button>
              </div>
            </div>

            {/* Intimate Personality */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold uppercase tracking-wider text-[#C9A050] flex items-center gap-1.5">
                  <Heart className="w-3.5 h-3.5" />
                  <span>Personalidad Íntima & Dinámica</span>
                </label>
                {intimatePersonality ? (
                  <button
                    type="button"
                    onClick={() => setPersonality('')}
                    className="text-[10px] font-mono text-rose-400 hover:text-rose-300 border border-rose-500/30 px-2 py-0.5 rounded cursor-pointer transition-colors"
                    title="Quitar selección"
                  >
                    Quitar selección
                  </button>
                ) : (
                  <span className="text-[10px] font-mono text-zinc-500">Sin selección</span>
                )}
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {INTIMATE_PERSONALITIES.map(item => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setPersonality(prev => prev === item.name ? '' : item.name)}
                    className={`p-2.5 rounded-xl text-left text-xs border cursor-pointer transition-all ${
                      intimatePersonality === item.name
                        ? 'bg-rose-950/60 border-rose-600 text-rose-200'
                        : 'bg-[#181A22] border-[#282B36] text-[#A0A5B5] hover:text-[#E0E0E0]'
                    }`}
                  >
                    <span className="font-bold block text-[#E0E0E0]">{item.name}</span>
                    <span className="text-[11px] text-[#7A7F90] mt-0.5 block leading-tight">{item.description}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Intimate Anatomy: Areola & Nipples */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Areola Color */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-[#A0A5B5]">Color de Areola</label>
                <select
                  value={areolaColor}
                  onChange={(e) => setAreolaColor(e.target.value)}
                  className="w-full bg-[#181A22] border border-[#282B36] rounded-xl px-3 py-2 text-xs text-[#E0E0E0] outline-hidden"
                >
                  {AREOLA_COLORS.map(c => (
                    <option key={c.id} value={c.name}>{c.name}</option>
                  ))}
                </select>
              </div>

              {/* Nipple Type */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-[#A0A5B5]">Morfología de Pezón</label>
                <select
                  value={nippleType}
                  onChange={(e) => setNippleType(e.target.value)}
                  className="w-full bg-[#181A22] border border-[#282B36] rounded-xl px-3 py-2 text-xs text-[#E0E0E0] outline-hidden"
                >
                  {NIPPLE_TYPES.map(n => (
                    <option key={n.id} value={n.name}>{n.name}</option>
                  ))}
                </select>
              </div>

              {/* Areola Size */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-[#A0A5B5]">Tamaño de Areola</label>
                <select
                  value={areolaSize}
                  onChange={(e) => setAreolaSize(e.target.value)}
                  className="w-full bg-[#181A22] border border-[#282B36] rounded-xl px-3 py-2 text-xs text-[#E0E0E0] outline-hidden"
                >
                  {AREOLA_SIZES.map(s => (
                    <option key={s.id} value={s.name}>{s.name}</option>
                  ))}
                </select>
              </div>

              {/* Pubic Hair Style */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-[#A0A5B5]">Estilo de Vello Íntimo</label>
                <select
                  value={pubicHair}
                  onChange={(e) => setPubicHair(e.target.value)}
                  className="w-full bg-[#181A22] border border-[#282B36] rounded-xl px-3 py-2 text-xs text-[#E0E0E0] outline-hidden"
                >
                  {PUBIC_HAIR_STYLES.map(p => (
                    <option key={p.id} value={p.name}>{p.name}</option>
                  ))}
                </select>
              </div>

              {/* Genital Morphology */}
              <div className="space-y-1.5 sm:col-span-2">
                <label className="text-xs font-bold text-[#A0A5B5]">Morfología & Tipo de Genitales</label>
                <select
                  value={genitalType}
                  onChange={(e) => setGenitalType(e.target.value)}
                  className="w-full bg-[#181A22] border border-[#282B36] rounded-xl px-3 py-2 text-xs text-[#E0E0E0] outline-hidden"
                >
                  {GENITAL_TYPES.map(g => (
                    <option key={g.id} value={g.name}>[{g.category}] {g.name}</option>
                  ))}
                </select>
              </div>

              {/* Genital Size */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-[#A0A5B5]">Proporción / Tamaño Genital</label>
                <select
                  value={genitalSize}
                  onChange={(e) => setGenitalSize(e.target.value)}
                  className="w-full bg-[#181A22] border border-[#282B36] rounded-xl px-3 py-2 text-xs text-[#E0E0E0] outline-hidden"
                >
                  {GENITAL_SIZES.map(s => (
                    <option key={s.id} value={s.name}>{s.name}</option>
                  ))}
                </select>
              </div>

              {/* Rasgos & Acabados Íntimos (Selección Múltiple) */}
              <div className="space-y-2 sm:col-span-2">
                <div className="flex items-center justify-between flex-wrap gap-1">
                  <label className="text-xs font-bold uppercase tracking-wider text-[#C9A050]">
                    Rasgos & Acabados Íntimos (Selección Múltiple)
                  </label>
                  <span className="text-[10px] text-zinc-400 font-mono bg-[#181A22] border border-[#282B36] px-2 py-0.5 rounded-full">
                    {genitalDetails.length} seleccionados
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-60 overflow-y-auto pr-1">
                  {GENITAL_DETAILS.map(gd => {
                    const isChecked = genitalDetails.includes(gd.name);
                    return (
                      <button
                        key={gd.id}
                        type="button"
                        onClick={() => handleToggleGenitalDetail(gd.name)}
                        className={`p-2.5 rounded-xl text-left text-xs border flex items-start justify-between cursor-pointer transition-all ${
                          isChecked
                            ? 'bg-rose-950/40 border-rose-600 text-rose-200 shadow-xs'
                            : 'bg-[#181A22] border-[#282B36] text-[#8A8F9E] hover:border-zinc-600'
                        }`}
                      >
                        <div className="pr-2 space-y-0.5">
                          <span className={`font-semibold block text-xs ${isChecked ? 'text-rose-200' : 'text-zinc-200'}`}>{gd.name}</span>
                          <span className="text-[10px] text-zinc-400 block leading-tight">{gd.description}</span>
                        </div>
                        {isChecked ? (
                          <Check className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                        ) : (
                          <div className="w-4 h-4 rounded border border-zinc-600 shrink-0 mt-0.5" />
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Erogenous Sensitivities */}
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-[#C9A050]">
                Zonas de Alta Sensibilidad Erógena
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {BODY_SENSITIVITIES.map(bs => {
                  const isChecked = sensitivities.includes(bs.id);
                  return (
                    <button
                      key={bs.id}
                      type="button"
                      onClick={() => handleToggleSensitivity(bs.id)}
                      className={`p-2.5 rounded-xl text-left text-xs border flex items-center justify-between cursor-pointer transition-all ${
                        isChecked
                          ? 'bg-rose-950/40 border-rose-600 text-rose-200'
                          : 'bg-[#181A22] border-[#282B36] text-[#8A8F9E]'
                      }`}
                    >
                      <span className="font-semibold">{bs.name}</span>
                      {isChecked && <Check className="w-4 h-4 text-rose-400 shrink-0" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-between pt-4 border-t border-[#262832]">
              <button
                type="button"
                onClick={handleDisable}
                className="px-4 py-2 rounded-xl bg-[#181A22] hover:bg-rose-950/50 text-rose-400 text-xs font-medium border border-rose-900/40 cursor-pointer transition-all"
              >
                Desactivar Modo R+18
              </button>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl bg-[#181A22] text-[#8A8F9E] text-xs font-medium cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleSave}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-rose-600 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white font-bold text-xs shadow-md cursor-pointer transition-all"
                >
                  Guardar Preferencias
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
