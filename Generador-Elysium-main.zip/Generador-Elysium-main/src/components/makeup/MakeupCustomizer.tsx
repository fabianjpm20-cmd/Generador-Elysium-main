import React from 'react';
import { CharacterState, MakeupConfig } from '../../types';
import { 
  LIPSTICK_STYLES, LIPSTICK_COLORS, LIPSTICK_FINISHES,
  BLUSH_STYLES, BLUSH_COLORS,
  NAIL_STYLES, NAIL_COLORS, NAIL_FINISHES,
  EYESHADOW_STYLES, EYESHADOW_COLORS, EYELINER_MAKEUP_STYLES,
  FACE_ACCENTS, MAKEUP_PRESETS, DEFAULT_MAKEUP_CONFIG
} from '../../data';
import { Sparkles, Heart, Check, RotateCcw, Palette, Flame } from 'lucide-react';
import { InfoTooltip } from '../ui/InfoTooltip';

interface MakeupCustomizerProps {
  state: CharacterState;
  setState: React.Dispatch<React.SetStateAction<CharacterState>>;
}

// Color visual swatch mapping helper
const getColorHex = (colorName: string): string => {
  const c = (colorName || '').toLowerCase();
  if (c.includes('negro') || c.includes('azabache') || c.includes('carbón')) return '#18181B';
  if (c.includes('carmesí') || c.includes('pasión') || c.includes('rojo')) return '#DC2626';
  if (c.includes('borgoña') || c.includes('vino') || c.includes('toro')) return '#7F1D1D';
  if (c.includes('pastel') || c.includes('sakura')) return '#F472B6';
  if (c.includes('fucsia') || c.includes('neón')) return '#EC4899';
  if (c.includes('nude') || c.includes('cuarzo') || c.includes('rosado')) return '#E8B4B8';
  if (c.includes('coral') || c.includes('melocotón')) return '#FB923C';
  if (c.includes('ciruela') || c.includes('mora') || c.includes('berenjena')) return '#581C87';
  if (c.includes('chocolate') || c.includes('marrón') || c.includes('terracota')) return '#78350F';
  if (c.includes('blanco') || c.includes('porcelana') || c.includes('francés')) return '#F8FAFC';
  if (c.includes('dorado') || c.includes('oro') || c.includes('solar') || c.includes('ámbar')) return '#F59E0B';
  if (c.includes('plata') || c.includes('espejo') || c.includes('hielo')) return '#CBD5E1';
  if (c.includes('zafiro') || c.includes('azul') || c.includes('noche') || c.includes('galaxia')) return '#1D4ED8';
  if (c.includes('verde') || c.includes('esmeralda') || c.includes('jade')) return '#059669';
  if (c.includes('púrpura') || c.includes('amatista') || c.includes('violeta') || c.includes('malva') || c.includes('lavanda')) return '#9333EA';
  if (c.includes('frambuesa')) return '#BE185D';
  if (c.includes('albaricoque')) return '#EA580C';
  if (c.includes('lima')) return '#84CC16';
  if (c.includes('tierra')) return '#A16207';
  if (c.includes('iridiscente') || c.includes('prisma') || c.includes('holográfico')) return '#A855F7';
  return '#C9A050';
};

export const MakeupCustomizer: React.FC<MakeupCustomizerProps> = ({ state, setState }) => {
  const currentMakeup: MakeupConfig = state.makeup || { ...DEFAULT_MAKEUP_CONFIG };

  const updateMakeup = (key: keyof MakeupConfig, value: string) => {
    setState(prev => ({
      ...prev,
      makeup: {
        ...(prev.makeup || DEFAULT_MAKEUP_CONFIG),
        [key]: value
      }
    }));
  };

  const applyPreset = (preset: typeof MAKEUP_PRESETS[0]) => {
    setState(prev => ({
      ...prev,
      makeup: { ...preset.config }
    }));
  };

  const resetToNatural = () => {
    setState(prev => ({
      ...prev,
      makeup: { ...DEFAULT_MAKEUP_CONFIG }
    }));
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner & Quick Presets */}
      <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#1E222B]">
          <div className="flex items-center space-x-2">
            <Palette className="w-5 h-5 text-[#C9A050]" />
            <div>
              <h3 className="text-base font-serif italic text-[#C9A050] font-bold">
                Paletas Rápidas & Estilos de Maquillaje
              </h3>
              <p className="text-xs text-[#888888]">
                Aplica combinaciones armónicas de cosméticos con un clic o personaliza cada elemento.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={resetToNatural}
            className="self-start sm:self-auto flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-[#15171C] border border-[#2A2D35] text-xs text-[#AAAAAA] hover:text-[#E0E0E0] hover:border-[#C9A050] transition-all"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Restablecer Natural</span>
          </button>
        </div>

        {/* Preset Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-2.5">
          {MAKEUP_PRESETS.map(preset => {
            const isSelected = 
              currentMakeup.lipstickStyle === preset.config.lipstickStyle &&
              currentMakeup.blushStyle === preset.config.blushStyle &&
              currentMakeup.nailStyle === preset.config.nailStyle;

            return (
              <button
                key={preset.id}
                type="button"
                onClick={() => applyPreset(preset)}
                className={`p-3 rounded-xl border text-left transition-all relative flex flex-col justify-between ${
                  isSelected
                    ? 'bg-[#1C1F26] border-[#C9A050] text-[#E0E0E0] shadow-md ring-1 ring-[#C9A050]/50'
                    : 'bg-[#15171C] border-[#2A2D35] text-[#888888] hover:border-[#4A4E58] hover:text-[#CCCCCC]'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-lg">{preset.emoji}</span>
                    {isSelected && <Check className="w-3.5 h-3.5 text-[#C9A050]" />}
                  </div>
                  <div className={`text-xs font-bold leading-tight ${isSelected ? 'text-[#C9A050]' : 'text-[#E0E0E0]'}`}>
                    {preset.name}
                  </div>
                </div>
                <div className="text-[10px] text-[#777777] mt-2 line-clamp-2 leading-tight">
                  {preset.description}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Makeup Modules Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

        {/* 1. Lápiz Labial & Acabado de Labios */}
        <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs space-y-4 border-t-2 border-t-[#C9A050]">
          <div className="flex items-center justify-between pb-2 border-b border-[#1E222B]">
            <div className="flex items-center space-x-2">
              <span className="text-base">💋</span>
              <h4 className="text-sm font-serif italic text-[#C9A050] font-bold">
                A.2.5.1 Lápiz Labial & Acabado de Labios
              </h4>
            </div>
            <InfoTooltip text="Configura el estilo de aplicación (mate, gloss, degradado ombré), color y acabado de labios." />
          </div>

          <div className="space-y-3">
            <div>
              <label className="block text-xs text-[#AAAAAA] mb-1 font-medium">Estilo / Aplicación:</label>
              <select
                value={currentMakeup.lipstickStyle}
                onChange={(e) => updateMakeup('lipstickStyle', e.target.value)}
                className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none"
              >
                {LIPSTICK_STYLES.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-[#AAAAAA] mb-1 font-medium flex items-center justify-between">
                  <span>Tono / Color:</span>
                  <span
                    className="w-3 h-3 rounded-full inline-block border border-white/20 shadow-xs"
                    style={{ backgroundColor: getColorHex(currentMakeup.lipstickColor) }}
                  />
                </label>
                <select
                  value={currentMakeup.lipstickColor}
                  onChange={(e) => updateMakeup('lipstickColor', e.target.value)}
                  className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none"
                >
                  {LIPSTICK_COLORS.map(o => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>

              <div>
                <label className="block text-xs text-[#AAAAAA] mb-1 font-medium">Acabado / Textura:</label>
                <select
                  value={currentMakeup.lipstickFinish}
                  onChange={(e) => updateMakeup('lipstickFinish', e.target.value)}
                  className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none"
                >
                  {LIPSTICK_FINISHES.map(o => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
            </div>

            {/* Quick lipstick color pills */}
            <div>
              <label className="block text-[10px] text-[#777777] font-mono mb-1.5 uppercase">Acceso Rápido de Color:</label>
              <div className="flex flex-wrap gap-1.5">
                {LIPSTICK_COLORS.slice(0, 6).map(color => {
                  const isSel = currentMakeup.lipstickColor === color;
                  return (
                    <button
                      key={color}
                      type="button"
                      onClick={() => updateMakeup('lipstickColor', color)}
                      className={`flex items-center space-x-1.5 px-2 py-1 rounded-lg text-[11px] border transition-all ${
                        isSel
                          ? 'bg-[#222733] border-[#C9A050] text-[#C9A050] font-medium'
                          : 'bg-[#15171C] border-[#2A2D35] text-[#888888] hover:text-[#CCCCCC]'
                      }`}
                    >
                      <span
                        className="w-2.5 h-2.5 rounded-full inline-block"
                        style={{ backgroundColor: getColorHex(color) }}
                      />
                      <span className="truncate max-w-[120px]">{color.split('/')[0].trim()}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* 2. Rubor & Colorete Facial */}
        <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs space-y-4 border-t-2 border-t-[#C9A050]">
          <div className="flex items-center justify-between pb-2 border-b border-[#1E222B]">
            <div className="flex items-center space-x-2">
              <span className="text-base">🌸</span>
              <h4 className="text-sm font-serif italic text-[#C9A050] font-bold">
                A.2.5.2 Rubor & Colorete Facial
              </h4>
            </div>
            <InfoTooltip text="Ubicación y tono del rubor: bajo los ojos (Igari), puente de la nariz (Sun-kissed), contorno alto o anime blush." />
          </div>

          <div className="space-y-3">
            <div>
              <label className="block text-xs text-[#AAAAAA] mb-1 font-medium">Estilo / Técnica de Rubor:</label>
              <select
                value={currentMakeup.blushStyle}
                onChange={(e) => updateMakeup('blushStyle', e.target.value)}
                className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none"
              >
                {BLUSH_STYLES.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>

            <div>
              <label className="block text-xs text-[#AAAAAA] mb-1 font-medium flex items-center justify-between">
                <span>Color / Tonalidad de Mejillas:</span>
                <span
                  className="w-3 h-3 rounded-full inline-block border border-white/20 shadow-xs"
                  style={{ backgroundColor: getColorHex(currentMakeup.blushColor) }}
                />
              </label>
              <select
                value={currentMakeup.blushColor}
                onChange={(e) => updateMakeup('blushColor', e.target.value)}
                className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none"
              >
                {BLUSH_COLORS.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>

            {/* Quick blush style chips */}
            <div>
              <label className="block text-[10px] text-[#777777] font-mono mb-1.5 uppercase">Técnicas Populares:</label>
              <div className="flex flex-wrap gap-1.5">
                {[
                  'B2 Estilo Igari / Resaca Tierna (Bajo los Ojos)',
                  'B3 Sun-Kissed (Puente de la Nariz y Mejillas)',
                  'B6 Rayitas Anime / Chibi Blush',
                  'B4 Pómulos Esculpidos / Contorno Alto (Editorial)'
                ].map(style => {
                  const isSel = currentMakeup.blushStyle === style;
                  return (
                    <button
                      key={style}
                      type="button"
                      onClick={() => updateMakeup('blushStyle', style)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] border transition-all ${
                        isSel
                          ? 'bg-[#222733] border-[#C9A050] text-[#C9A050] font-medium'
                          : 'bg-[#15171C] border-[#2A2D35] text-[#888888] hover:text-[#CCCCCC]'
                      }`}
                    >
                      {style.split('/')[0].replace(/^[A-Z0-9]+\s+/i, '').trim()}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* 3. Esmalte de Uñas & Manicura */}
        <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs space-y-4 border-t-2 border-t-[#C9A050]">
          <div className="flex items-center justify-between pb-2 border-b border-[#1E222B]">
            <div className="flex items-center space-x-2">
              <span className="text-base">💅</span>
              <h4 className="text-sm font-serif italic text-[#C9A050] font-bold">
                A.2.5.3 Esmalte de Uñas & Manicura
              </h4>
            </div>
            <InfoTooltip text="Forma de uñas (stiletto, almendradas, garras), esmalte, color, manicura francesa y acabados." />
          </div>

          <div className="space-y-3">
            <div>
              <label className="block text-xs text-[#AAAAAA] mb-1 font-medium">Forma & Longitud de Uñas:</label>
              <select
                value={currentMakeup.nailStyle}
                onChange={(e) => updateMakeup('nailStyle', e.target.value)}
                className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none"
              >
                {NAIL_STYLES.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-[#AAAAAA] mb-1 font-medium flex items-center justify-between">
                  <span>Color de Esmalte:</span>
                  <span
                    className="w-3 h-3 rounded-full inline-block border border-white/20 shadow-xs"
                    style={{ backgroundColor: getColorHex(currentMakeup.nailColor) }}
                  />
                </label>
                <select
                  value={currentMakeup.nailColor}
                  onChange={(e) => updateMakeup('nailColor', e.target.value)}
                  className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none"
                >
                  {NAIL_COLORS.map(o => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>

              <div>
                <label className="block text-xs text-[#AAAAAA] mb-1 font-medium">Acabado del Esmalte:</label>
                <select
                  value={currentMakeup.nailFinish}
                  onChange={(e) => updateMakeup('nailFinish', e.target.value)}
                  className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none"
                >
                  {NAIL_FINISHES.map(o => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
            </div>

            {/* Quick nail shape chips */}
            <div>
              <label className="block text-[10px] text-[#777777] font-mono mb-1.5 uppercase">Formas Destacadas:</label>
              <div className="flex flex-wrap gap-1.5">
                {[
                  'N2 Almendradas / Clásicas Elegantes',
                  'N3 Stiletto / Largas y Afiladas',
                  'N5 Garras Afiladas de Fantasía',
                  'N6 Manicura Francesa (Punta Contrastante)'
                ].map(style => {
                  const isSel = currentMakeup.nailStyle === style;
                  return (
                    <button
                      key={style}
                      type="button"
                      onClick={() => updateMakeup('nailStyle', style)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] border transition-all ${
                        isSel
                          ? 'bg-[#222733] border-[#C9A050] text-[#C9A050] font-medium'
                          : 'bg-[#15171C] border-[#2A2D35] text-[#888888] hover:text-[#CCCCCC]'
                      }`}
                    >
                      {style.split('/')[0].replace(/^[A-Z0-9]+\s+/i, '').trim()}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* 4. Sombras & Delineado Especial */}
        <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs space-y-4 border-t-2 border-t-[#C9A050]">
          <div className="flex items-center justify-between pb-2 border-b border-[#1E222B]">
            <div className="flex items-center space-x-2">
              <span className="text-base">👁️</span>
              <h4 className="text-sm font-serif italic text-[#C9A050] font-bold">
                A.2.5.4 Sombras & Delineado Cosmético
              </h4>
            </div>
            <InfoTooltip text="Sombreado de párpados artístico (smokey eye, cut crease, glitter) y delineado con alas o pestañas anime." />
          </div>

          <div className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-[#AAAAAA] mb-1 font-medium">Estilo de Sombras & Ojeras:</label>
                <select
                  value={currentMakeup.eyeshadowStyle}
                  onChange={(e) => updateMakeup('eyeshadowStyle', e.target.value)}
                  className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none"
                >
                  {EYESHADOW_STYLES.map(o => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>

              <div>
                <label className="block text-xs text-[#AAAAAA] mb-1 font-medium flex items-center justify-between">
                  <span>Color de Sombras / Tono Ojera:</span>
                  <span
                    className="w-3 h-3 rounded-full inline-block border border-white/20 shadow-xs"
                    style={{ backgroundColor: getColorHex(currentMakeup.eyeshadowColor) }}
                  />
                </label>
                <select
                  value={currentMakeup.eyeshadowColor}
                  onChange={(e) => updateMakeup('eyeshadowColor', e.target.value)}
                  className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none"
                >
                  {EYESHADOW_COLORS.map(o => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs text-[#AAAAAA] mb-1 font-medium">Delineado & Pestañas Cosméticas:</label>
              <select
                value={currentMakeup.eyelinerStyle}
                onChange={(e) => updateMakeup('eyelinerStyle', e.target.value)}
                className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none"
              >
                {EYELINER_MAKEUP_STYLES.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>

            {/* Quick shadow / ojeras style chips */}
            <div>
              <label className="block text-[10px] text-[#777777] font-mono mb-1.5 uppercase">Estilos Rápidos de Sombras & Ojeras:</label>
              <div className="flex flex-wrap gap-1.5">
                {[
                  'E9 Ojeras Marcadas / Dark Circles (Estilo Cansado / Ojeras Góticas)',
                  'E10 Ojeras Suaves / Sombra de Fatiga Seductora',
                  'E2 Smokey Eye Negro / Ahumado Dramático',
                  'E6 Fox Eye / Alargado Felino',
                  'D8 Delineado con Ojeras Difuminadas / Estilo Grunge'
                ].map(style => {
                  const isEyeshadow = style.startsWith('E');
                  const isSel = isEyeshadow ? currentMakeup.eyeshadowStyle === style : currentMakeup.eyelinerStyle === style;
                  return (
                    <button
                      key={style}
                      type="button"
                      onClick={() => {
                        if (isEyeshadow) {
                          updateMakeup('eyeshadowStyle', style);
                        } else {
                          updateMakeup('eyelinerStyle', style);
                        }
                      }}
                      className={`px-2.5 py-1 rounded-lg text-[11px] border transition-all ${
                        isSel
                          ? 'bg-[#222733] border-[#C9A050] text-[#C9A050] font-medium'
                          : 'bg-[#15171C] border-[#2A2D35] text-[#888888] hover:text-[#CCCCCC]'
                      }`}
                    >
                      {style.split('/')[0].replace(/^[A-Z0-9]+\s+/i, '').trim()}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* 5. Acentos Faciales & Iluminador */}
        <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs space-y-4 border-t-2 border-t-[#C9A050] md:col-span-2">
          <div className="flex items-center justify-between pb-2 border-b border-[#1E222B]">
            <div className="flex items-center space-x-2">
              <span className="text-base">✨</span>
              <h4 className="text-sm font-serif italic text-[#C9A050] font-bold">
                A.2.5.5 Iluminador & Acentos Cosméticos Faciales
              </h4>
            </div>
            <InfoTooltip text="Puntos de luz en pómulos/nariz (Glass skin), pecas dibujadas doradas, lágrimas de purpurina o gemas." />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
            {FACE_ACCENTS.map(accent => {
              const isSelected = currentMakeup.faceAccent === accent;
              return (
                <button
                  key={accent}
                  type="button"
                  onClick={() => updateMakeup('faceAccent', accent)}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    isSelected
                      ? 'bg-[#1C1F26] border-[#C9A050] text-[#E0E0E0] font-medium shadow-sm ring-1 ring-[#C9A050]/50'
                      : 'bg-[#15171C] border-[#2A2D35] text-[#888888] hover:border-[#4A4E58] hover:text-[#CCCCCC]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs">{accent}</span>
                    {isSelected && <Check className="w-3.5 h-3.5 text-[#C9A050]" />}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Live Makeup Summary Card */}
      <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-5 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center space-x-2 text-[#C9A050] text-xs font-mono font-bold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>CONFIGURACIÓN COSMÉTICA VIGENTE</span>
          </div>
          <div className="flex flex-wrap gap-2 text-xs">
            <span className="px-2.5 py-1 rounded-lg bg-[#15171C] border border-[#2A2D35] text-[#E0E0E0]">
              💄 <strong className="text-[#C9A050]">{currentMakeup.lipstickColor.split('/')[0].trim()}</strong> ({currentMakeup.lipstickStyle.split('/')[0].trim()})
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-[#15171C] border border-[#2A2D35] text-[#E0E0E0]">
              🌸 <strong className="text-[#C9A050]">{currentMakeup.blushStyle.split('/')[0].trim()}</strong>
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-[#15171C] border border-[#2A2D35] text-[#E0E0E0]">
              💅 <strong className="text-[#C9A050]">{currentMakeup.nailColor.split('/')[0].trim()}</strong> ({currentMakeup.nailStyle.split('/')[0].trim()})
            </span>
            {currentMakeup.faceAccent !== 'Ninguno' && (
              <span className="px-2.5 py-1 rounded-lg bg-[#15171C] border border-[#2A2D35] text-[#C9A050]">
                ✨ {currentMakeup.faceAccent.split('/')[0].trim()}
              </span>
            )}
          </div>
        </div>

        <button
          type="button"
          onClick={resetToNatural}
          className="text-xs text-[#888888] hover:text-[#C9A050] hover:underline"
        >
          Limpiar Maquillaje
        </button>
      </div>
    </div>
  );
};
