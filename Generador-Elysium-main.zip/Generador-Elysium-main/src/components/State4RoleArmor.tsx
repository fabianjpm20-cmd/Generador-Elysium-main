import React, { useState } from 'react';
import {
  CharacterState,
  GarmentConfig,
  RolePieceDetail,
  EquipmentPieceDetail,
  OrientalFantasyConfig
} from '../types';
import {
  ROLES_CATALOG,
  VISUAL_STYLES,
  ROLE_THEME_CONFIG,
  STYLE_THEME_CONFIG,
  WEAPONS_LIST,
  WEAPONS_GRIPS,
  BAGS_LIST,
  BAGS_SIZES,
  BAGS_CLOSURES,
  ITEMS_LIST,
  getRoleAttireConfig,
  RoleAttireConfig,
  getPieceLengthOptions,
  getDefaultPieceLength,
  DETAIL_LOCATIONS,
  GENERAL_ROLE_MATERIALS,
  GENERAL_ROLE_FINISHES,
  ALL_STYLE_THEMATIC_DATA,
  getStyleThematicPackage,
  StyleThematicDataPackage,
  StyleThematicTradition,
  StyleThematicPieceOption,
  StyleAccentMineral,
  StyleWeaponOption
} from '../data';
import {
  ARMOR_SLOT_GROUPS,
  WEAPON_CUSTOMIZATION_GROUPS,
  CONTAINER_CUSTOMIZATION_GROUPS,
  getArmorSlotOptionConfig
} from '../data/roleArmorOptionEngine';
import {
  getCompatibleSubStyles,
  computeStyleFusion,
  getCompatibleSubRoles,
  computeRoleHybrid,
  SubStyleOption,
  SubRoleOption
} from '../data/styleRoleFusionEngine';
import {
  Shield,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  Wand2,
  Palette,
  Check,
  Layers,
  Shirt,
  Sliders,
  ChevronDown,
  ChevronUp,
  RefreshCw,
  Plus,
  Gem,
  Package,
  Sword,
  Sparkle,
  Paintbrush,
  Ruler,
  X,
  RotateCcw,
  Tag,
  MapPin,
  Compass,
  Crown,
  Zap,
  Flame,
  Wind,
  Eye,
  Crosshair
} from 'lucide-react';
import { InfoTooltip } from './ui/InfoTooltip';
import { NobleTitlesSection } from './NobleTitlesSection';

interface State4Props {
  state: CharacterState;
  setState: React.Dispatch<React.SetStateAction<CharacterState>>;
  onNext: () => void;
  onBack: () => void;
}

type UnifiedPieceCategoryTab =
  | 'ROLE_SLOTS'
  | 'SUB_ROLE_SLOTS'
  | 'STYLE_ARMOR'
  | 'STYLE_ACCESSORIES'
  | 'ALL';

export function mapPieceToAnatomicalSlot(pieceName: string, category?: string): 'P1' | 'P2' | 'P3' | 'P4' | 'P5' | 'P6' | 'P7' {
  const pLower = pieceName.toLowerCase();
  const cLower = (category || '').toLowerCase();

  // P1 Cabeza / Cuello / Rostro
  if (
    cLower.includes('cabeza') || cLower.includes('máscara') || cLower.includes('joyería & cabello') || cLower.includes('cabello') ||
    pLower.includes('máscara') || pLower.includes('sombrero') || pLower.includes('casco') || pLower.includes('tiara') ||
    pLower.includes('horquilla') || pLower.includes('corona') || pLower.includes('diadema') || pLower.includes('velo') ||
    pLower.includes('collar') || pLower.includes('gargantilla') || pLower.includes('eboshi') || pLower.includes('kabuto') ||
    pLower.includes('douli') || pLower.includes('kasa') || pLower.includes('gafas') || pLower.includes('visor') ||
    pLower.includes('ojo') || pLower.includes('anteojos') || pLower.includes('capucha') || pLower.includes('pendientes') ||
    pLower.includes('tocado') || pLower.includes('monóculo') || pLower.includes('antifaz')
  ) {
    return 'P1';
  }

  // P3 Hombros & Brazos / Manos
  if (
    cLower.includes('hombro') || cLower.includes('brazo') ||
    pLower.includes('hombrera') || pLower.includes('brazal') || pLower.includes('guante') || pLower.includes('sode') ||
    pLower.includes('kote') || pLower.includes('manguito') || pLower.includes('mitón') || pLower.includes('muñequera') ||
    pLower.includes('biguan') || pLower.includes('brazalete') || pLower.includes('anillo') || pLower.includes('ban zhi') ||
    pLower.includes('coderas') || pLower.includes('guantelete') || pLower.includes('protectores brazo')
  ) {
    return 'P3';
  }

  // P4 Cintura / Fajín / Cinto
  if (
    cLower.includes('cintura') || cLower.includes('fajín') || cLower.includes('cinto') ||
    pLower.includes('faja') || pLower.includes('fajín') || pLower.includes('cinturón') || pLower.includes('kuadai') ||
    pLower.includes('obi') || pLower.includes('tahalí') || pLower.includes('bandolera') || pLower.includes('hebilla') ||
    pLower.includes('calabaza') || pLower.includes('hulu') || pLower.includes('cordón') || pLower.includes('nudo') ||
    pLower.includes('colgante') || pLower.includes('espejo') || pLower.includes('pipa') || pLower.includes('yandai') ||
    pLower.includes('kiseru') || pLower.includes('arnés') || pLower.includes('cartuchera')
  ) {
    return 'P4';
  }

  // P6 Pies & Calzado
  if (
    pLower.includes('bota') || pLower.includes('sandalia') || pLower.includes('zapato') || pLower.includes('geta') ||
    pLower.includes('waraji') || pLower.includes('tabi') || pLower.includes('calzado') || pLower.includes('escarpín') ||
    pLower.includes('suneate') || pLower.includes('espinillera') || pLower.includes('borceguí') || pLower.includes('alpargata') ||
    pLower.includes('exo-pies')
  ) {
    return 'P6';
  }

  // P5 Piernas & Faldón / Pantalones
  if (
    cLower.includes('piernas') ||
    pLower.includes('falda') || pLower.includes('faldón') || pLower.includes('pantalón') || pLower.includes('greba') ||
    pLower.includes('hakama') || pLower.includes('quijote') || pLower.includes('muslera') || pLower.includes('mallas') ||
    pLower.includes('calzas') || pLower.includes('kusazuri') || pLower.includes('haidate') || pLower.includes('pantacorte')
  ) {
    return 'P5';
  }

  // P7 Capas / Prenda Flotante / Manto / Talismanes / Accesorios Sagrados
  if (
    cLower.includes('flotante') || cLower.includes('sagrado') || cLower.includes('accesorio') ||
    pLower.includes('capa') || pLower.includes('manto') || pLower.includes('pibo') || pLower.includes('hagoromo') ||
    pLower.includes('chal') || pLower.includes('talismanes') || pLower.includes('ofuda') || pLower.includes('abanico') ||
    pLower.includes('tessen') || pLower.includes('sensu') || pLower.includes('campanilla') || pLower.includes('suzu') ||
    pLower.includes('fengling') || pLower.includes('estandarte') || pLower.includes('alas') || pLower.includes('aura') ||
    pLower.includes('emisor') || pLower.includes('holotag') || pLower.includes('cables') || pLower.includes('relicario')
  ) {
    return 'P7';
  }

  // P2 Torso / Armadura Torso / Pechera / Default
  return 'P2';
}

export function buildTraditionFullEnsemble(
  tradition: StyleThematicTradition,
  roleConfig: RoleAttireConfig
) {
  const traditionPieces = [...tradition.suggestedArmor, ...tradition.suggestedAccessories];
  const coveredSlots = new Set<string>();

  traditionPieces.forEach(p => {
    coveredSlots.add(mapPieceToAnatomicalSlot(p));
  });

  const roleComplementPieces: { piece: string; slotId: string }[] = [];
  const allSlots = ['P1', 'P2', 'P3', 'P4', 'P5', 'P6', 'P7'];

  allSlots.forEach(slotId => {
    if (!coveredSlots.has(slotId)) {
      const roleSlot = roleConfig.slots.find(s => s.slotId === slotId);
      if (roleSlot && roleSlot.pieces.length > 0) {
        roleComplementPieces.push({ piece: roleSlot.pieces[0], slotId });
        coveredSlots.add(slotId);
      }
    }
  });

  return {
    traditionPieces,
    roleComplementPieces,
    allPieces: [...traditionPieces, ...roleComplementPieces.map(r => r.piece)],
    coveredSlots: Array.from(coveredSlots).sort()
  };
}

export const State4RoleArmor: React.FC<State4Props> = ({ state, setState, onNext, onBack }) => {
  const [expandedGarmentId, setExpandedGarmentId] = useState<string | null>(null);
  const [syncFeedback, setSyncFeedback] = useState<string | null>(null);
  const [customPieceInput, setCustomPieceInput] = useState<string>('');
  const [customPieceSlot, setCustomPieceSlot] = useState<string>('P1');
  const [isCustomPieceOpen, setIsCustomPieceOpen] = useState<boolean>(false);
  const [pieceSearchQuery, setPieceSearchQuery] = useState<string>('');
  const [activeCategoryTab, setActiveCategoryTab] = useState<UnifiedPieceCategoryTab>('ROLE_SLOTS');
  const [activeRoleSlotFilter, setActiveRoleSlotFilter] = useState<string>('ALL');
  const [armorCategoryFilter, setArmorCategoryFilter] = useState<string>('ALL');
  const [accessoryCategoryFilter, setAccessoryCategoryFilter] = useState<string>('ALL');
  const [focusedPieceId, setFocusedPieceId] = useState<string | null>(null);
  const [activeEditorPieceFilter, setActiveEditorPieceFilter] = useState<string>('ALL');
  const [isSubStyleOpen, setIsSubStyleOpen] = useState<boolean>(Boolean(state.subStyleVisual));
  const [isSubRoleOpen, setIsSubRoleOpen] = useState<boolean>(Boolean(state.subRole));

  const currentRoleName = state.role || 'Civil Genérico';
  const roleConfig: RoleAttireConfig = getRoleAttireConfig(currentRoleName);
  const roleCategory = ROLES_CATALOG.find(rc => rc.roles.includes(currentRoleName))?.cat || roleConfig.category || 'Civiles';
  const roleTheme = ROLE_THEME_CONFIG[roleCategory] || ROLE_THEME_CONFIG['Civiles'];
  const currentStyleName = state.styleVisual || 'Fantasía Oriental';
  const stylePackage: StyleThematicDataPackage = getStyleThematicPackage(currentStyleName);
  const styleTheme = STYLE_THEME_CONFIG[currentStyleName] || STYLE_THEME_CONFIG['Fantasía Tradicional'];

  // Current unified thematic data
  const thematicData: OrientalFantasyConfig = state.orientalFantasy || {
    tradition: '',
    armorPieces: [],
    culturalAccessories: [],
    spiritualMotif: '',
    silkPattern: '',
    jadeAccentColor: '',
    energyAura: '',
    weaponStyle: ''
  };

  const triggerFeedback = (msg: string) => {
    setSyncFeedback(msg);
    setTimeout(() => setSyncFeedback(null), 3200);
  };

  // Update thematic config
  const updateThematic = (updates: Partial<OrientalFantasyConfig>) => {
    setState(prev => ({
      ...prev,
      orientalFantasy: {
        ...(prev.orientalFantasy || {}),
        ...updates
      }
    }));
  };

  // --------------------------------------------------------------------------
  // UNIFIED PIECE TOGGLE (Both Role Pieces and Style Armor/Accessories)
  // --------------------------------------------------------------------------
  const handleArmorPieceToggle = (
    pieceName: string,
    slotId?: string,
    categoryType?: string,
    visualDesc?: string
  ) => {
    setState(prev => {
      const arr = prev.armor.pieces || [];
      const isSelected = arr.includes(pieceName);
      const newPieces = isSelected ? arr.filter(i => i !== pieceName) : [...arr, pieceName];

      const newDetails = { ...(prev.armor.pieceDetails || {}) };
      if (!isSelected && !newDetails[pieceName]) {
        const defaultLength = getDefaultPieceLength(pieceName, slotId);
        const defaultColor =
          roleConfig.suggestedColors[0]?.hex ||
          stylePackage.jadeColors[0]?.hex ||
          '#C9A050';
        const defaultMaterial =
          prev.armor.material ||
          roleConfig.materials[0] ||
          GENERAL_ROLE_MATERIALS[3];
        const defaultFinish =
          prev.armor.finish ||
          roleConfig.finishes[0] ||
          GENERAL_ROLE_FINISHES[1];

        newDetails[pieceName] = {
          id: pieceName,
          name: pieceName,
          category: categoryType || 'role',
          slot: slotId || '',
          color: defaultColor,
          length: defaultLength,
          material: defaultMaterial,
          finish: defaultFinish,
          detailLocation: 'Bordes y dobladillos',
          detail: '',
          description: visualDesc || ''
        };
      }

      // If it's a style-thematic piece, synchronize orientalFantasy list as well
      const currentThematicArmor = prev.orientalFantasy?.armorPieces || [];
      const currentThematicAccs = prev.orientalFantasy?.culturalAccessories || [];
      let nextThematicArmor = currentThematicArmor;
      let nextThematicAccs = currentThematicAccs;

      if (categoryType === 'style_armor') {
        nextThematicArmor = isSelected
          ? currentThematicArmor.filter(p => p !== pieceName)
          : [...currentThematicArmor, pieceName];
      } else if (categoryType === 'style_accessory') {
        nextThematicAccs = isSelected
          ? currentThematicAccs.filter(a => a !== pieceName)
          : [...currentThematicAccs, pieceName];
      }

      return {
        ...prev,
        armor: {
          ...prev.armor,
          pieces: newPieces,
          pieceDetails: newDetails
        },
        orientalFantasy: {
          ...(prev.orientalFantasy || {}),
          armorPieces: nextThematicArmor,
          culturalAccessories: nextThematicAccs
        }
      };
    });
  };

  const handleUpdatePieceDetail = (pieceId: string, updates: Partial<RolePieceDetail>) => {
    setState(prev => {
      const current = prev.armor.pieceDetails?.[pieceId] || {
        id: pieceId,
        name: pieceId,
        color: roleConfig.suggestedColors[0]?.hex || '#C9A050',
        length: getDefaultPieceLength(pieceId),
        material: prev.armor.material || roleConfig.materials[0] || GENERAL_ROLE_MATERIALS[3],
        finish: prev.armor.finish || roleConfig.finishes[0] || GENERAL_ROLE_FINISHES[1],
        detailLocation: 'Bordes y dobladillos',
        detail: '',
        description: ''
      };

      return {
        ...prev,
        armor: {
          ...prev.armor,
          pieceDetails: {
            ...(prev.armor.pieceDetails || {}),
            [pieceId]: {
              ...current,
              ...updates
            }
          }
        }
      };
    });
  };

  const handleResetPieceDetail = (pieceId: string, slotId?: string) => {
    handleUpdatePieceDetail(pieceId, {
      color: roleConfig.suggestedColors[0]?.hex || '#C9A050',
      length: getDefaultPieceLength(pieceId, slotId),
      material: state.armor.material || roleConfig.materials[0] || GENERAL_ROLE_MATERIALS[3],
      finish: state.armor.finish || roleConfig.finishes[0] || GENERAL_ROLE_FINISHES[1],
      detailLocation: 'Bordes y dobladillos',
      detail: ''
    });
    triggerFeedback('Pieza restablecida a los valores estándar de su aspecto.');
  };

  const handleHarmonizeAllPiecesColor = (colorHex: string) => {
    if (!state.armor.pieces || state.armor.pieces.length === 0) {
      triggerFeedback('No hay piezas seleccionadas para cambiar de color.');
      return;
    }

    setState(prev => {
      const updatedDetails: Record<string, RolePieceDetail> = { ...(prev.armor.pieceDetails || {}) };
      prev.armor.pieces.forEach(p => {
        const current = updatedDetails[p] || {
          id: p,
          name: p,
          color: colorHex,
          length: getDefaultPieceLength(p),
          material: prev.armor.material,
          finish: prev.armor.finish,
          detailLocation: 'Bordes y dobladillos',
          detail: ''
        };
        updatedDetails[p] = { ...current, color: colorHex };
      });

      return {
        ...prev,
        armor: {
          ...prev.armor,
          pieceDetails: updatedDetails
        }
      };
    });
    triggerFeedback(`Color ${colorHex} aplicado a todas las piezas activas.`);
  };

  const handleAddCustomPiece = () => {
    const trimmed = customPieceInput.trim();
    if (!trimmed) return;
    const formatted = `P-Custom: ${trimmed}`;
    if (!state.armor.pieces.includes(formatted)) {
      const defaultLength = getDefaultPieceLength(trimmed);
      const defaultColor = roleConfig.suggestedColors[0]?.hex || '#C9A050';

      setState(prev => ({
        ...prev,
        armor: {
          ...prev.armor,
          pieces: [...prev.armor.pieces, formatted],
          pieceDetails: {
            ...(prev.armor.pieceDetails || {}),
            [formatted]: {
              id: formatted,
              name: trimmed,
              category: 'custom',
              slot: customPieceSlot,
              color: defaultColor,
              length: defaultLength,
              material: prev.armor.material || roleConfig.materials[0] || GENERAL_ROLE_MATERIALS[3],
              finish: prev.armor.finish || roleConfig.finishes[0] || GENERAL_ROLE_FINISHES[1],
              detailLocation: 'Bordes y dobladillos',
              detail: '',
              description: 'Pieza personalizada de indumentaria/armadura con diseño singular.'
            }
          }
        }
      }));
      setCustomPieceInput('');
      setFocusedPieceId(formatted);
      triggerFeedback(`Pieza personalizada añadida: "${trimmed}"`);
    }
  };

  // --------------------------------------------------------------------------
  // ROLE & STYLE SELECTION HANDLERS (PRIMARY & COMPATIBLE SUB-SELECTIONS)
  // --------------------------------------------------------------------------
  const handleSelectMainStyle = (styleName: string) => {
    setState(prev => {
      const nextSubStyle = prev.subStyleVisual === styleName ? undefined : prev.subStyleVisual;
      const fusion = nextSubStyle ? computeStyleFusion(styleName, nextSubStyle) : undefined;
      return {
        ...prev,
        styleVisual: styleName,
        subStyleVisual: nextSubStyle,
        styleFusionTitle: fusion?.fusedTitle
      };
    });
    triggerFeedback(`Estilo principal actualizado a "${styleName}".`);
  };

  const handleSelectSubStyle = (subStyleName: string | undefined) => {
    setState(prev => {
      if (!subStyleName || subStyleName === 'none' || subStyleName === prev.styleVisual) {
        return {
          ...prev,
          subStyleVisual: undefined,
          styleFusionTitle: undefined
        };
      }
      const fusion = computeStyleFusion(prev.styleVisual, subStyleName);
      return {
        ...prev,
        subStyleVisual: subStyleName,
        styleFusionTitle: fusion.fusedTitle
      };
    });
    if (subStyleName && subStyleName !== 'none') {
      const fusion = computeStyleFusion(state.styleVisual, subStyleName);
      triggerFeedback(`Sub-estilo "${subStyleName}" activado. Fusión: ${fusion.fusedTitle}`);
    } else {
      triggerFeedback(`Sub-estilo desactivado (Estilo Puro).`);
    }
  };

  const handleRoleSelect = (roleName: string) => {
    const newConfig = getRoleAttireConfig(roleName);
    const newOutfitType = newConfig.recommendedOutfitType || newConfig.outfitTypes[0]?.name || 'Ninguna';
    const newMaterial = newConfig.materials[0] || GENERAL_ROLE_MATERIALS[0];
    const newFinish = newConfig.finishes[0] || GENERAL_ROLE_FINISHES[0];
    const newDefense = newConfig.armorDefenses[0]?.name || 'Ninguna';

    // Auto-select 2-3 signature pieces
    const defaultPieces: string[] = [];
    if (newConfig.slots[0]?.pieces[0]) defaultPieces.push(newConfig.slots[0].pieces[0]);
    if (newConfig.slots[1]?.pieces[0]) defaultPieces.push(newConfig.slots[1].pieces[0]);
    if (newConfig.slots[4]?.pieces[0]) defaultPieces.push(newConfig.slots[4].pieces[0]);

    const initialDetails: Record<string, RolePieceDetail> = {};
    defaultPieces.forEach(p => {
      initialDetails[p] = {
        id: p,
        name: p,
        category: 'role',
        color: newConfig.suggestedColors[0]?.hex || '#C9A050',
        length: getDefaultPieceLength(p),
        material: newMaterial,
        finish: newFinish,
        detailLocation: 'Bordes y dobladillos',
        detail: '',
        description: ''
      };
    });

    setState(prev => {
      const nextSubRole = prev.subRole === roleName ? undefined : prev.subRole;
      const hybrid = nextSubRole ? computeRoleHybrid(roleName, nextSubRole) : undefined;
      const isFemale =
        prev.anatomy?.sexBase?.toLowerCase().includes('mujer') ||
        prev.anatomy?.sexBase?.toLowerCase().includes('femenino') ||
        prev.anatomy?.sexBase?.startsWith('2');
      const defaultNobleTitle =
        roleName === 'Noble'
          ? prev.nobleTitle || (isFemale ? 'Duquesa' : 'Duque')
          : prev.nobleTitle;
      const defaultNobleHouse =
        roleName === 'Noble'
          ? prev.nobleHouseOrDomain || 'de Valgrave'
          : prev.nobleHouseOrDomain;

      return {
        ...prev,
        role: roleName,
        subRole: nextSubRole,
        hybridRoleTitle: hybrid?.hybridTitle,
        nobleTitle: defaultNobleTitle,
        nobleHouseOrDomain: defaultNobleHouse,
        armor: {
          ...prev.armor,
          type: newOutfitType,
          material: newMaterial,
          finish: newFinish,
          specialType: newDefense,
          pieces: defaultPieces,
          pieceDetails: initialDetails
        }
      };
    });

    triggerFeedback(`Rol cambiado a "${roleName}". Indumentaria canónica adaptada.`);
  };

  const handleSelectSubRole = (subRoleName: string | undefined) => {
    setState(prev => {
      if (!subRoleName || subRoleName === 'none' || subRoleName === prev.role) {
        return {
          ...prev,
          subRole: undefined,
          hybridRoleTitle: undefined
        };
      }
      const hybrid = computeRoleHybrid(prev.role, subRoleName);
      return {
        ...prev,
        subRole: subRoleName,
        hybridRoleTitle: hybrid.hybridTitle
      };
    });
    if (subRoleName && subRoleName !== 'none') {
      const hybrid = computeRoleHybrid(state.role, subRoleName);
      triggerFeedback(`Sub-rol "${subRoleName}" activado. Modificador de Rol: ${hybrid.hybridTitle}`);
    } else {
      triggerFeedback(`Sub-rol desactivado (Rol Canónico Puro).`);
    }
  };

  const handleEquipHybridAttire = () => {
    if (!state.subRole) return;
    const hybrid = computeRoleHybrid(state.role, state.subRole, state.hybridRoleTitle);
    const subConfig = getRoleAttireConfig(state.subRole);

    const combinedPieces = Array.from(new Set([...state.armor.pieces, ...hybrid.combinedPieces]));
    const newPieceDetails = { ...(state.armor.pieceDetails || {}) };

    hybrid.combinedPieces.forEach(p => {
      if (!newPieceDetails[p]) {
        const slotId = mapPieceToAnatomicalSlot(p);
        newPieceDetails[p] = {
          id: p,
          name: p,
          category: 'role',
          slot: slotId,
          color: subConfig.suggestedColors[0]?.hex || '#C9A050',
          length: getDefaultPieceLength(p, slotId),
          material: subConfig.materials[0] || state.armor.material || GENERAL_ROLE_MATERIALS[0],
          finish: subConfig.finishes[0] || state.armor.finish || GENERAL_ROLE_FINISHES[0],
          detailLocation: 'Bordes y dobladillos',
          detail: `Pieza híbrida de ${state.subRole}`,
          description: ''
        };
      }
    });

    const currentWeapons = state.equipment.weapons || [];
    const newWeapons = Array.from(new Set([...currentWeapons, ...hybrid.combinedWeapons]));

    setState(prev => ({
      ...prev,
      armor: {
        ...prev.armor,
        pieces: combinedPieces,
        pieceDetails: newPieceDetails
      },
      equipment: {
        ...prev.equipment,
        weapons: newWeapons
      }
    }));

    triggerFeedback(`¡Piezas y armamento del rol híbrido "${hybrid.hybridTitle}" equipados!`);
  };

  const handleApplyTradition = (tradition: StyleThematicTradition) => {
    const ensemble = buildTraditionFullEnsemble(tradition, roleConfig);
    const initialDetails: Record<string, RolePieceDetail> = {};

    ensemble.allPieces.forEach(p => {
      const isTradArmor = tradition.suggestedArmor.includes(p);
      const isTradAcc = tradition.suggestedAccessories.includes(p);
      const isRolePiece = !isTradArmor && !isTradAcc;
      const slotId = mapPieceToAnatomicalSlot(p);

      initialDetails[p] = {
        id: p,
        name: p,
        category: isTradArmor ? 'style_armor' : isTradAcc ? 'style_accessory' : 'role',
        slot: slotId,
        color: tradition.suggestedJade ? tradition.suggestedJade : roleConfig.suggestedColors[0]?.hex || '#C9A050',
        length: getDefaultPieceLength(p, slotId),
        material: state.armor.material || roleConfig.materials[0] || GENERAL_ROLE_MATERIALS[3],
        finish: state.armor.finish || roleConfig.finishes[0] || GENERAL_ROLE_FINISHES[1],
        detailLocation: 'Bordes y dobladillos',
        detail: '',
        description: ''
      };
    });

    setState(prev => {
      const currentWeapons = prev.equipment.weapons || [];
      const hasWeapon = currentWeapons.includes(tradition.suggestedWeapon);
      const newWeapons = hasWeapon ? currentWeapons : [...currentWeapons, tradition.suggestedWeapon];

      return {
        ...prev,
        orientalFantasy: {
          tradition: tradition.name,
          armorPieces: tradition.suggestedArmor,
          culturalAccessories: tradition.suggestedAccessories,
          spiritualMotif: tradition.suggestedMotif,
          silkPattern: tradition.suggestedSilk,
          jadeAccentColor: tradition.suggestedJade,
          energyAura: tradition.suggestedAura,
          weaponStyle: tradition.suggestedWeapon
        },
        armor: {
          ...prev.armor,
          pieces: ensemble.allPieces,
          pieceDetails: {
            ...(prev.armor.pieceDetails || {}),
            ...initialDetails
          }
        },
        equipment: {
          ...prev.equipment,
          weapons: newWeapons
        }
      };
    });

    triggerFeedback(`Conjunto integral '${tradition.name}' aplicado: ${tradition.suggestedArmor.length + tradition.suggestedAccessories.length} piezas de tradición + ${ensemble.roleComplementPieces.length} piezas anatómicas de ${currentRoleName} armonizadas.`);
  };

  const handleSmartSyncRoleArmor = () => {
    const newOutfitType = roleConfig.recommendedOutfitType || roleConfig.outfitTypes[0]?.name || 'Ninguna';
    const newMaterial = roleConfig.materials[0] || GENERAL_ROLE_MATERIALS[0];
    const newFinish = roleConfig.finishes[0] || GENERAL_ROLE_FINISHES[0];
    const newDefense = roleConfig.armorDefenses[0]?.name || 'Ninguna';

    const signaturePieces: string[] = [];
    roleConfig.slots.forEach(s => {
      if (s.pieces[0]) signaturePieces.push(s.pieces[0]);
    });

    const chosen = signaturePieces.slice(0, 4);
    const initialDetails: Record<string, RolePieceDetail> = {};
    chosen.forEach(p => {
      initialDetails[p] = {
        id: p,
        name: p,
        category: 'role',
        color: roleConfig.suggestedColors[0]?.hex || '#C9A050',
        length: getDefaultPieceLength(p),
        material: newMaterial,
        finish: newFinish,
        detailLocation: 'Bordes y dobladillos',
        detail: '',
        description: ''
      };
    });

    setState(prev => ({
      ...prev,
      armor: {
        ...prev.armor,
        type: newOutfitType,
        material: newMaterial,
        finish: newFinish,
        specialType: newDefense,
        pieces: chosen,
        pieceDetails: initialDetails
      }
    }));
    triggerFeedback(`Piezas icónicas de "${currentRoleName}" configuradas con éxito.`);
  };

  // --------------------------------------------------------------------------
  // EQUIPMENT HANDLERS
  // --------------------------------------------------------------------------
  const handleArrayToggle = (category: keyof CharacterState['equipment'], item: string) => {
    setState(prev => {
      const arr = prev.equipment[category] as string[];
      const isSelected = arr.includes(item);
      const newArr = isSelected ? arr.filter(i => i !== item) : [...arr, item];

      let eqDetails = { ...(prev.equipment.equipmentDetails || {}) };
      if (!isSelected && (category === 'weapons' || category === 'bags' || category === 'items')) {
        const catType = category === 'weapons' ? 'weapon' : category === 'bags' ? 'bag' : 'item';
        if (!eqDetails[item]) {
          eqDetails[item] = {
            id: item,
            name: item,
            category: catType,
            color: roleConfig.suggestedColors[0]?.hex || '#C9A050',
            material: roleConfig.materials[0] || GENERAL_ROLE_MATERIALS[0],
            finish: roleConfig.finishes[0] || GENERAL_ROLE_FINISHES[0],
            sizeOrLength: 'Estándar',
            detail: ''
          };
        }
      }

      return {
        ...prev,
        equipment: {
          ...prev.equipment,
          [category]: newArr,
          equipmentDetails: eqDetails
        }
      };
    });
  };

  const handleUpdateEquipmentDetail = (itemId: string, updates: Partial<EquipmentPieceDetail>) => {
    setState(prev => {
      const current = prev.equipment.equipmentDetails?.[itemId] || {
        id: itemId,
        name: itemId,
        category: 'item',
        color: roleConfig.suggestedColors[0]?.hex || '#C9A050',
        material: roleConfig.materials[0] || GENERAL_ROLE_MATERIALS[0],
        finish: roleConfig.finishes[0] || GENERAL_ROLE_FINISHES[0],
        sizeOrLength: 'Estándar',
        detail: ''
      };

      return {
        ...prev,
        equipment: {
          ...prev.equipment,
          equipmentDetails: {
            ...(prev.equipment.equipmentDetails || {}),
            [itemId]: {
              ...current,
              ...updates
            }
          }
        }
      };
    });
  };

  // --------------------------------------------------------------------------
  // STATE 3 WARDROBE HARMONIZERS
  // --------------------------------------------------------------------------
  const handleSyncWardrobeToRole = () => {
    if (!state.wardrobes || state.wardrobes.length === 0) {
      triggerFeedback('No hay prendas en el Estado 3 para sintonizar.');
      return;
    }

    const targetMaterial = roleConfig.materials[0] || roleTheme.primaryMaterial || 'MAT04 - Seda';
    const targetFinish = roleConfig.finishes[0] || roleTheme.primaryFinish || 'FIN02 - Satinado';
    const suggestedDetail = roleConfig.suggestedWardrobeDetails[0] || 'DET01 - Bordados';

    setState(prev => ({
      ...prev,
      wardrobes: prev.wardrobes.map(garment => {
        const updatedDetails = Array.from(new Set([...garment.details, suggestedDetail]));
        return {
          ...garment,
          material: targetMaterial,
          finish: targetFinish,
          details: updatedDetails
        };
      })
    }));
    triggerFeedback(`Prendas de Estado 3 adaptadas al Rol "${currentRoleName}".`);
  };

  const handleSyncWardrobeToStyle = () => {
    if (!state.wardrobes || state.wardrobes.length === 0) {
      triggerFeedback('No hay prendas en el Estado 3 para sintonizar.');
      return;
    }

    setState(prev => ({
      ...prev,
      wardrobes: prev.wardrobes.map(garment => {
        const updatedDetails = Array.from(new Set([...garment.details, ...(styleTheme.detailOverrides?.slice(0, 1) || [])]));
        return {
          ...garment,
          material: styleTheme.primaryMaterial || garment.material,
          finish: styleTheme.primaryFinish || garment.finish,
          details: updatedDetails
        };
      })
    }));
    triggerFeedback(`Prendas de Estado 3 adaptadas al Estilo "${state.styleVisual}".`);
  };

  const handleHarmonizeWardrobeColors = () => {
    if (!state.wardrobes || state.wardrobes.length === 0) {
      triggerFeedback('No hay prendas en el Estado 3 para armonizar.');
      return;
    }

    const availablePalette = (roleConfig.suggestedColors && roleConfig.suggestedColors.length > 0)
      ? roleConfig.suggestedColors
      : (styleTheme.colorPalette && styleTheme.colorPalette.length > 0)
        ? styleTheme.colorPalette
        : roleTheme.suggestedColors;

    setState(prev => ({
      ...prev,
      wardrobes: prev.wardrobes.map((garment, idx) => {
        const selectedColor = availablePalette[idx % availablePalette.length];
        return {
          ...garment,
          color: selectedColor.hex
        };
      })
    }));
    triggerFeedback(`Paleta cromática armonizada según Rol "${currentRoleName}" y Estilo.`);
  };

  const handleUpdateSingleGarment = (garmentId: string, updates: Partial<GarmentConfig>) => {
    setState(prev => ({
      ...prev,
      wardrobes: prev.wardrobes.map(g => (g.id === garmentId ? { ...g, ...updates } : g))
    }));
  };

  const handleToggleGarmentDetail = (garmentId: string, detailName: string) => {
    setState(prev => ({
      ...prev,
      wardrobes: prev.wardrobes.map(g => {
        if (g.id !== garmentId) return g;
        const exists = g.details.includes(detailName);
        const newDetails = exists ? g.details.filter(d => d !== detailName) : [...g.details, detailName];
        return { ...g, details: newDetails };
      })
    }));
  };

  // Materials & Finishes combined pools
  const combinedMaterials = Array.from(
    new Set([
      ...roleConfig.materials,
      ...(roleTheme.materials || []),
      ...(styleTheme.materials || []),
      ...GENERAL_ROLE_MATERIALS
    ])
  );

  const combinedFinishes = Array.from(
    new Set([
      ...roleConfig.finishes,
      ...(roleTheme.finishes || []),
      ...(styleTheme.finishes || []),
      ...GENERAL_ROLE_FINISHES
    ])
  );

  // Filtered style armor/accessories
  const styleArmorCategories = Array.from(
    new Set(stylePackage.armorPieces.map(a => a.category))
  );
  const styleAccessoryCategories = Array.from(
    new Set(stylePackage.culturalAccessories.map(a => a.category))
  );

  const filteredStyleArmorPieces = stylePackage.armorPieces.filter(
    p => armorCategoryFilter === 'ALL' || p.category === armorCategoryFilter
  );
  const filteredStyleAccessories = stylePackage.culturalAccessories.filter(
    a => accessoryCategoryFilter === 'ALL' || a.category === accessoryCategoryFilter
  );

  // Helper to get all style/tradition pieces belonging to an anatomical slot
  const getStylePiecesForSlot = (slotId: string) => {
    const pieces: Array<{
      id: string;
      name: string;
      sourceType: 'tradition' | 'style_armor' | 'style_accessory';
      originBadge: string;
      description: string;
      iconTag?: string;
    }> = [];

    const seen = new Set<string>();

    // 1. From traditions
    (stylePackage.traditions || []).forEach(trad => {
      [...trad.suggestedArmor, ...trad.suggestedAccessories].forEach(pName => {
        if (mapPieceToAnatomicalSlot(pName) === slotId && !seen.has(pName)) {
          seen.add(pName);
          pieces.push({
            id: `trad_${trad.id}_${pName}`,
            name: pName,
            sourceType: 'tradition',
            originBadge: trad.name.split('/')[0].trim(),
            iconTag: trad.iconTag,
            description: `Pieza sugerida del arquetipo ${trad.name}.`
          });
        }
      });
    });

    // 2. From style armor
    (stylePackage.armorPieces || []).forEach(p => {
      if (mapPieceToAnatomicalSlot(p.name, p.category) === slotId && !seen.has(p.name)) {
        seen.add(p.name);
        pieces.push({
          id: p.id,
          name: p.name,
          sourceType: 'style_armor',
          originBadge: p.culturalOrigin || 'Armadura de Estilo',
          iconTag: '🛡️',
          description: p.description
        });
      }
    });

    // 3. From style accessories
    (stylePackage.culturalAccessories || []).forEach(a => {
      if (mapPieceToAnatomicalSlot(a.name, a.category) === slotId && !seen.has(a.name)) {
        seen.add(a.name);
        pieces.push({
          id: a.id,
          name: a.name,
          sourceType: 'style_accessory',
          originBadge: a.culturalOrigin || 'Accesorio Sagrado',
          iconTag: '✨',
          description: a.description
        });
      }
    });

    return pieces;
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      {/* Hero Header */}
      <div className="bg-[#0F1115] border border-[#222222] rounded-3xl p-8 text-[#E0E0E0] shadow-xl mb-8 relative">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-[#1A1C22] border border-[#2A2D35] text-[#C9A050] text-xs font-medium">
            <Shield className="w-3.5 h-3.5 text-[#C9A050]" />
            <span>ESTADO 4: INDUMENTARIA DE ROL, ARMADURA, ACCESORIOS & EQUIPAMIENTO</span>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handleSmartSyncRoleArmor}
              className="bg-[#1A1C22] border border-[#C9A050] text-[#C9A050] hover:bg-[#C9A050] hover:text-[#0A0B0E] px-3.5 py-1.5 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition-all shadow-md cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Autoconfigurar Piezas de "{currentRoleName}"</span>
            </button>
          </div>
        </div>

        <h2 className="text-3xl font-serif italic text-[#C9A050] tracking-tight mb-2">
          Indumentaria de Rol, Armaduras, Accesorios & Modificadores Físicos
        </h2>
        <p className="text-[#888888] text-sm leading-relaxed mb-4">
          Sistema unificado de diseño visual donde puedes seleccionar y modificar con precisión matemática cada prenda de rol, pieza de armadura y accesorio temático (color exacto, largo/caída, material, acabado superficial, ubicación de detalles y silueta física).
        </p>

        {syncFeedback && (
          <div className="mb-4 bg-[#1A1C22] border border-emerald-500/50 text-emerald-400 text-xs px-4 py-2.5 rounded-xl flex items-center space-x-2 animate-fade-in shadow-md">
            <Check className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="font-medium">{syncFeedback}</span>
          </div>
        )}

        <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="text-xs text-[#A0A0A0] flex items-center gap-2">
              <span className="text-[#C9A050] font-bold uppercase tracking-wider">{roleConfig.category}</span>
              <span>•</span>
              <strong className="text-[#E0E0E0] text-sm">{currentRoleName}</strong>
              <span>•</span>
              <span className="text-cyan-400 font-mono text-xs">Estilo {state.styleVisual}</span>
            </div>
            <p className="text-xs text-[#888888] italic">
              "{roleConfig.tagline}"
            </p>
          </div>
          <div className="text-[11px] font-mono text-[#C9A050] bg-[#1A1C22] px-3 py-1.5 rounded-lg border border-[#2A2D35] shrink-0">
            {state.armor.pieces.length} pieza(s) de indumentaria activas • {state.wardrobes.length} prenda(s) de Estado 3
          </div>
        </div>
      </div>

      <div className="space-y-8">
        {/* ==================================================================== */}
        {/* SECTION 4.0: CANONICAL ROLE & VISUAL AESTHETIC STYLE (WITH SUB-SELECTIONS) */}
        {/* ==================================================================== */}
        <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs space-y-6">
          <h3 className="text-lg font-serif italic text-[#C9A050] flex items-center gap-2">
            <Compass className="w-5 h-5 text-[#C9A050]" />
            <span>4.0 Rol Canónico y Estilo Visual (Jerarquía & Fusión)</span>
          </h3>

          {/* ------------------------------------------------------------------ */}
          {/* 4.0.A: PRIMARY VISUAL STYLE & COMPATIBLE SUB-STYLE */}
          {/* ------------------------------------------------------------------ */}
          <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-5 space-y-4">
            <div>
              <label className="block text-xs font-mono text-[#C9A050] font-bold uppercase tracking-wider mb-2 flex items-center justify-between">
                <span>1. Estilo Estético Visual Principal</span>
                <InfoTooltip text="Estilo base que gobierna la estética arquitectónica, patrones, texturas y lenguaje visual." />
              </label>
              <div className="flex flex-wrap gap-2">
                {VISUAL_STYLES.map(s => {
                  const isSelected = state.styleVisual === s;
                  return (
                    <button
                      key={s}
                      onClick={() => handleSelectMainStyle(s)}
                      className={`px-4 py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-[#1A1C22] border-[#C9A050] text-[#C9A050] shadow-md ring-1 ring-[#C9A050]/50'
                          : 'bg-[#0F1115] border-[#222222] text-[#888888] hover:text-[#E0E0E0] hover:border-[#444]'
                      }`}
                    >
                      {s} {isSelected && '✓'}
                    </button>
                  );
                })}
              </div>
              {stylePackage && (
                <p className="text-[11px] text-[#A0A0A0] mt-2.5 italic flex items-center gap-1.5 bg-[#0F1115] p-2 rounded-lg border border-[#222222]">
                  <Sparkles className="w-3.5 h-3.5 text-[#C9A050] shrink-0" />
                  <span><strong>{stylePackage.title}:</strong> {stylePackage.description}</span>
                </p>
              )}
            </div>

            {/* Sub-Style Selection & Synergistic Fusion (Optimized Collapsible / Demand-driven) */}
            {!isSubStyleOpen && !state.subStyleVisual ? (
              <div className="pt-3 border-t border-[#222222] flex flex-wrap items-center justify-between gap-2 bg-[#0F1115] px-3.5 py-2.5 rounded-xl border border-[#222222]">
                <div className="flex items-center gap-2">
                  <Palette className="w-3.5 h-3.5 text-purple-400" />
                  <span className="text-xs font-mono text-[#CCCCCC]">Sub-Estilo & Fusión:</span>
                  <span className="text-xs font-semibold text-[#888888]">Estilo Puro ({state.styleVisual})</span>
                </div>
                <button
                  type="button"
                  onClick={() => setIsSubStyleOpen(true)}
                  className="px-3 py-1 bg-purple-950/40 hover:bg-purple-900/50 border border-purple-500/40 text-purple-300 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Sparkles className="w-3 h-3" />
                  <span>+ Mezclar / Doble Estilo</span>
                </button>
              </div>
            ) : (
              <div className="pt-4 border-t border-[#222222] space-y-3 animate-fade-in">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-mono text-[#C9A050] font-semibold flex items-center gap-1.5">
                    <Palette className="w-3.5 h-3.5 text-purple-400" />
                    <span>2. Sub-Estilo Compatible & Fusión Estética</span>
                    <InfoTooltip text="Añade un segundo estilo compatible para fusionar acabados, paletas y lenguajes decorativos (ej. Gótico + Elegante = Gótico Aristocrático)." />
                  </label>
                  <div className="flex items-center gap-2">
                    {state.subStyleVisual ? (
                      <button
                        type="button"
                        onClick={() => {
                          handleSelectSubStyle(undefined);
                          setIsSubStyleOpen(false);
                        }}
                        className="text-[10px] text-[#888888] hover:text-red-400 font-mono transition-colors cursor-pointer px-2 py-0.5 rounded border border-[#2A2D35] hover:border-red-500/40"
                      >
                        × Quitar Sub-Estilo (Estilo Puro)
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setIsSubStyleOpen(false)}
                        className="text-[10px] text-[#888888] hover:text-[#CCCCCC] font-mono transition-colors cursor-pointer px-2 py-0.5 rounded border border-[#2A2D35]"
                      >
                        Ocultar Selector
                      </button>
                    )}
                  </div>
                </div>

                {/* Compatible Sub-Style Recommendations */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                  {/* Option: Pure Style (No Sub-Style) */}
                  <button
                    type="button"
                    onClick={() => {
                      handleSelectSubStyle(undefined);
                      setIsSubStyleOpen(false);
                    }}
                    className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                      !state.subStyleVisual
                        ? 'bg-purple-950/20 border-purple-400/80 text-purple-200 shadow-xs ring-1 ring-purple-400/40'
                        : 'bg-[#0F1115] border-[#222222] text-[#888888] hover:border-[#444] hover:text-[#CCCCCC]'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold font-mono">Estilo Puro (Sin Sub-Estilo)</span>
                      {!state.subStyleVisual && <Check className="w-3.5 h-3.5 text-purple-400" />}
                    </div>
                    <p className="text-[10px] text-[#777777] mt-0.5">Conserva directrices puras de {state.styleVisual}.</p>
                  </button>

                  {/* Dynamically Curated Sub-Styles */}
                  {getCompatibleSubStyles(state.styleVisual).map(subOpt => {
                    const isChosen = state.subStyleVisual === subOpt.name;
                    return (
                      <button
                        key={subOpt.id || subOpt.name}
                        type="button"
                        onClick={() => {
                          handleSelectSubStyle(subOpt.name);
                          setIsSubStyleOpen(true);
                        }}
                        className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                          isChosen
                            ? 'bg-purple-950/30 border-purple-400 text-purple-100 shadow-md ring-1 ring-purple-400'
                            : 'bg-[#0F1115] border-[#222222] hover:border-purple-500/40 hover:bg-[#12141A] text-[#CCCCCC]'
                        }`}
                      >
                        <div>
                          <div className="flex items-center justify-between gap-1 mb-0.5">
                            <span className="text-xs font-bold text-[#E0E0E0]">{subOpt.name}</span>
                            <span className="text-[9px] font-mono px-1 py-0.2 rounded border bg-purple-950/40 border-purple-500/40 text-purple-300">
                              {subOpt.styleTags.slice(0, 2).join(', ')}
                            </span>
                          </div>
                          <p className="text-[10px] text-purple-300 font-semibold mb-0.5">
                            → {subOpt.fusedTitle}
                          </p>
                          <p className="text-[10px] text-[#777777] line-clamp-1">
                            {subOpt.synergyDescription}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* All Styles Sub-Dropdown Fallback */}
                <div className="flex items-center gap-2 pt-0.5 text-xs text-[#888888]">
                  <span className="text-[11px] font-mono shrink-0">O seleccionar otro sub-estilo:</span>
                  <select
                    value={state.subStyleVisual || ''}
                    onChange={e => {
                      const val = e.target.value || undefined;
                      handleSelectSubStyle(val);
                      if (val) setIsSubStyleOpen(true);
                    }}
                    className="bg-[#0F1115] border border-[#2A2D35] rounded-lg px-2.5 py-1 text-xs text-[#E0E0E0] focus:border-purple-400 outline-hidden"
                  >
                    <option value="">-- Ninguno (Estilo Puro) --</option>
                    {VISUAL_STYLES.filter(s => s !== state.styleVisual).map(s => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>

                {/* ACTIVE FUSION SHOWCASE CARD */}
                {state.subStyleVisual && (() => {
                  const fusion = computeStyleFusion(state.styleVisual, state.subStyleVisual);
                  return (
                    <div className="bg-gradient-to-r from-purple-950/25 via-[#15171C] to-indigo-950/25 border border-purple-500/40 rounded-xl p-3 space-y-2 animate-fade-in">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Sparkle className="w-4 h-4 text-purple-400 animate-pulse" />
                          <span className="text-xs font-bold uppercase tracking-wide text-purple-300">
                            Fusión Estética Activa: {state.styleFusionTitle || fusion.fusedTitle}
                          </span>
                        </div>
                        <span className="text-[10px] font-mono bg-[#0A0B0E] text-purple-300 px-2 py-0.5 rounded border border-purple-500/30">
                          {state.styleVisual} + {state.subStyleVisual}
                        </span>
                      </div>
                      <p className="text-xs text-[#CCCCCC] leading-relaxed">
                        {fusion.description}
                      </p>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1 text-[11px] text-[#A0A0A0]">
                        <div className="bg-[#0A0B0E]/60 p-1.5 rounded border border-[#222222]">
                          <span className="text-purple-400 font-bold block text-[10px]">Materiales:</span>
                          <span className="text-[11px] truncate block">{fusion.materials.slice(0, 3).join(', ')}</span>
                        </div>
                        <div className="bg-[#0A0B0E]/60 p-1.5 rounded border border-[#222222]">
                          <span className="text-purple-400 font-bold block text-[10px]">Paleta de Color:</span>
                          <span className="text-[11px] truncate block">{fusion.colorPalette.map(c => c.name).slice(0, 3).join(', ')}</span>
                        </div>
                        <div className="bg-[#0A0B0E]/60 p-1.5 rounded border border-[#222222]">
                          <span className="text-purple-400 font-bold block text-[10px]">Acabados:</span>
                          <span className="text-[11px] truncate block">{fusion.finishes.slice(0, 2).join(', ')}</span>
                        </div>
                      </div>
                    </div>
                  );
                })()}
              </div>
            )}
          </div>

          {/* ------------------------------------------------------------------ */}
          {/* 4.0.B: CANONICAL ROLE & COMPATIBLE SUB-ROLE (HYBRID MODIFIERS)   */}
          {/* ------------------------------------------------------------------ */}
          <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-5 space-y-4">
            <div>
              <label className="block text-xs font-mono text-[#C9A050] font-bold uppercase tracking-wider mb-2 flex items-center justify-between">
                <span>1. Selección de Rol Canónico Principal</span>
                <InfoTooltip text="Identidad arquetípica central del personaje que determina su base de indumentaria, armas y armaduras." />
              </label>
              <div className="space-y-3">
                {ROLES_CATALOG.map(rc => (
                  <div key={rc.cat} className="bg-[#0F1115] border border-[#222222] rounded-xl p-3.5">
                    <h4 className="text-xs font-bold text-[#C9A050] mb-2 uppercase tracking-wide flex items-center justify-between">
                      <span>{rc.cat}</span>
                      {rc.roles.includes(currentRoleName) && (
                        <span className="text-[10px] text-emerald-400 font-mono">Rol Activo en esta Categoría</span>
                      )}
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {rc.roles.map(r => {
                        const isChosen = currentRoleName === r;
                        return (
                          <button
                            key={r}
                            onClick={() => handleRoleSelect(r)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all cursor-pointer ${
                              isChosen
                                ? 'bg-[#C9A050] border-[#C9A050] text-[#0A0B0E] font-bold shadow-md'
                                : 'bg-[#15171C] border-[#2A2D35] text-[#888888] hover:text-[#E0E0E0] hover:border-[#555]'
                            }`}
                          >
                            {r} {isChosen && '✓'}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Sub-Role Selection & Hybrid Role Synthesis (Optimized Collapsible / Demand-driven) */}
            {!isSubRoleOpen && !state.subRole ? (
              <div className="pt-3 border-t border-[#222222] flex flex-wrap items-center justify-between gap-2 bg-[#0F1115] px-3.5 py-2.5 rounded-xl border border-[#222222]">
                <div className="flex items-center gap-2">
                  <Crown className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="text-xs font-mono text-[#CCCCCC]">Sub-Rol Modificador & Híbrido:</span>
                  <span className="text-xs font-semibold text-[#888888]">Rol Puro ({currentRoleName})</span>
                </div>
                <button
                  type="button"
                  onClick={() => setIsSubRoleOpen(true)}
                  className="px-3 py-1 bg-cyan-950/40 hover:bg-cyan-900/50 border border-cyan-500/40 text-cyan-300 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Zap className="w-3 h-3" />
                  <span>+ Activar Sub-Rol / Híbrido</span>
                </button>
              </div>
            ) : (
              <div className="pt-4 border-t border-[#222222] space-y-3 animate-fade-in">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-mono text-[#C9A050] font-semibold flex items-center gap-1.5">
                    <Crown className="w-3.5 h-3.5 text-cyan-400" />
                    <span>2. Sub-Rol Compatible / Modificador de Rol Híbrido</span>
                    <InfoTooltip text="Selecciona un segundo rol para transformar al personaje en un arquetipo híbrido (ej. Princesa + Berserker = Princesa Bárbara, o Princesa + Caballero = Princesa Caballero)." />
                  </label>
                  <div className="flex items-center gap-2">
                    {state.subRole ? (
                      <button
                        type="button"
                        onClick={() => {
                          handleSelectSubRole(undefined);
                          setIsSubRoleOpen(false);
                        }}
                        className="text-[10px] text-[#888888] hover:text-red-400 font-mono transition-colors cursor-pointer px-2 py-0.5 rounded border border-[#2A2D35] hover:border-red-500/40"
                      >
                        × Quitar Sub-Rol (Rol Puro)
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setIsSubRoleOpen(false)}
                        className="text-[10px] text-[#888888] hover:text-[#CCCCCC] font-mono transition-colors cursor-pointer px-2 py-0.5 rounded border border-[#2A2D35]"
                      >
                        Ocultar Selector
                      </button>
                    )}
                  </div>
                </div>

                {/* Compatible Sub-Role Recommendations */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                  {/* Option: Pure Canonical Role */}
                  <button
                    type="button"
                    onClick={() => {
                      handleSelectSubRole(undefined);
                      setIsSubRoleOpen(false);
                    }}
                    className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                      !state.subRole
                        ? 'bg-cyan-950/20 border-cyan-400/80 text-cyan-200 shadow-xs ring-1 ring-cyan-400/40'
                        : 'bg-[#0F1115] border-[#222222] text-[#888888] hover:border-[#444] hover:text-[#CCCCCC]'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold font-mono">Rol Canónico Puro</span>
                      {!state.subRole && <Check className="w-3.5 h-3.5 text-cyan-400" />}
                    </div>
                    <p className="text-[10px] text-[#777777] mt-0.5">Conserva la identidad única de {currentRoleName} sin rol secundario.</p>
                  </button>

                  {/* Dynamically Curated Sub-Roles for currentRoleName */}
                  {getCompatibleSubRoles(currentRoleName).map(subOpt => {
                    const isChosen = state.subRole === subOpt.name;
                    return (
                      <button
                        key={subOpt.id || subOpt.name}
                        type="button"
                        onClick={() => {
                          handleSelectSubRole(subOpt.name);
                          setIsSubRoleOpen(true);
                        }}
                        className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                          isChosen
                            ? 'bg-cyan-950/30 border-cyan-400 text-cyan-100 shadow-md ring-1 ring-cyan-400'
                            : 'bg-[#0F1115] border-[#222222] hover:border-cyan-500/40 hover:bg-[#12141A] text-[#CCCCCC]'
                        }`}
                      >
                        <div>
                          <div className="flex items-center justify-between gap-1 mb-0.5">
                            <span className="text-xs font-bold text-[#E0E0E0]">{subOpt.name}</span>
                            <span className="text-[9px] font-mono px-1 py-0.2 rounded border bg-cyan-950/40 border-cyan-500/40 text-cyan-300">
                              {subOpt.synergyTags.slice(0, 2).join(', ')}
                            </span>
                          </div>
                          <p className="text-xs text-amber-300 font-serif font-bold mb-0.5">
                            → {subOpt.hybridTitle}
                          </p>
                          <p className="text-[10px] text-[#777777] line-clamp-1">
                            {subOpt.synergyDescription}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* All Roles Sub-Dropdown Fallback */}
                <div className="flex items-center gap-2 pt-0.5 text-xs text-[#888888]">
                  <span className="text-[11px] font-mono shrink-0">O seleccionar otro sub-rol de cualquier categoría:</span>
                  <select
                    value={state.subRole || ''}
                    onChange={e => {
                      const val = e.target.value || undefined;
                      handleSelectSubRole(val);
                      if (val) setIsSubRoleOpen(true);
                    }}
                    className="bg-[#0F1115] border border-[#2A2D35] rounded-lg px-2.5 py-1 text-xs text-[#E0E0E0] focus:border-cyan-400 outline-hidden"
                  >
                    <option value="">-- Ninguno (Rol Puro) --</option>
                    {ROLES_CATALOG.flatMap(rc => rc.roles).filter(r => r !== currentRoleName).map(r => (
                      <option key={r} value={r}>{r}</option>
                    ))}
                  </select>
                </div>

                {/* ACTIVE HYBRID ROLE DOSSIER CARD */}
                {state.subRole && (() => {
                  const hybrid = computeRoleHybrid(currentRoleName, state.subRole, state.hybridRoleTitle);
                  return (
                    <div className="bg-gradient-to-r from-cyan-950/25 via-[#15171C] to-amber-950/25 border border-cyan-500/40 rounded-xl p-3.5 space-y-2.5 animate-fade-in">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-[#222222]">
                        <div className="flex items-center gap-2">
                          <Crown className="w-4 h-4 text-cyan-400" />
                          <div>
                            <span className="text-[10px] uppercase font-mono text-[#888888] block">Título del Rol Híbrido:</span>
                            <input
                              type="text"
                              value={state.hybridRoleTitle || hybrid.hybridTitle}
                              onChange={e => setState(p => ({ ...p, hybridRoleTitle: e.target.value }))}
                              className="bg-[#0A0B0E] border border-[#2A2D35] focus:border-cyan-400 text-amber-300 font-serif font-bold text-sm px-2.5 py-1 rounded-md outline-hidden w-full sm:w-auto min-w-[240px]"
                            />
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={handleEquipHybridAttire}
                          className="px-3 py-1.5 bg-gradient-to-r from-cyan-500 to-amber-500 hover:from-cyan-400 hover:to-amber-400 text-[#0A0B0E] font-bold text-xs rounded-lg flex items-center gap-1.5 transition-all shadow-md cursor-pointer shrink-0"
                        >
                          <Zap className="w-3.5 h-3.5 fill-current" />
                          <span>Equipar Piezas & Armas de Híbrido</span>
                        </button>
                      </div>

                      <p className="text-xs text-[#CCCCCC] leading-relaxed">
                        {hybrid.description}
                      </p>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-[#A0A0A0]">
                        <div className="bg-[#0A0B0E]/60 p-2 rounded-lg border border-[#222222] space-y-1">
                          <span className="text-cyan-400 font-bold block flex items-center gap-1 text-[10px]">
                            <Shield className="w-3 h-3" />
                            Piezas Clave ({currentRoleName} + {state.subRole}):
                          </span>
                          <div className="flex flex-wrap gap-1 mt-0.5">
                            {hybrid.combinedPieces.map(p => (
                              <span key={p} className="bg-[#15171C] border border-[#2A2D35] text-[#E0E0E0] px-1.5 py-0.5 rounded text-[9px]">
                                {p}
                              </span>
                            ))}
                          </div>
                        </div>

                        <div className="bg-[#0A0B0E]/60 p-2 rounded-lg border border-[#222222] space-y-1">
                          <span className="text-amber-400 font-bold block flex items-center gap-1 text-[10px]">
                            <Sword className="w-3 h-3" />
                            Armamento Recomendado:
                          </span>
                          <div className="flex flex-wrap gap-1 mt-0.5">
                            {hybrid.combinedWeapons.map(w => (
                              <span key={w} className="bg-[#15171C] border border-[#2A2D35] text-[#E0E0E0] px-1.5 py-0.5 rounded text-[9px]">
                                {w}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })()}
              </div>
            )}
          </div>

          {/* ------------------------------------------------------------------ */}
          {/* 4.0.C: EXCLUSIVE NOBLE TITLES SELECTOR (ONLY FOR ROLE 'NOBLE')    */}
          {/* ------------------------------------------------------------------ */}
          {(currentRoleName === 'Noble' || state.role === 'Noble') && (
            <NobleTitlesSection
              state={state}
              setState={setState}
              triggerFeedback={triggerFeedback}
              onEquipPiece={handleArmorPieceToggle}
            />
          )}
        </div>

        {/* ==================================================================== */}
        {/* SECTION 4.1: UNIFIED ROLE & STYLE ATTIRE, ARMOR & ACCESSORIES */}
        {/* ==================================================================== */}
        <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs">
          {/* Header & Quick Action */}
          <div className="flex flex-wrap items-center justify-between gap-4 mb-5">
            <div>
              <h3 className="text-lg font-serif italic text-[#C9A050] flex items-center gap-2">
                <Gem className="w-5 h-5 text-[#C9A050]" />
                <span>4.1 Indumentaria, Armadura & Accesorios Integrados (Por Rol y Estilo)</span>
              </h3>
              <p className="text-xs text-[#888888] mt-1">
                Catálogo unificado y editor de modificadores físicos para <strong>{currentRoleName}</strong> bajo la estética <strong>{state.styleVisual}</strong>.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              {state.armor.pieces.length > 0 && (
                <div className="text-xs font-mono bg-[#1A1C22] border border-[#C9A050] text-[#C9A050] px-3 py-1.5 rounded-lg flex items-center gap-1.5 shadow-xs">
                  <Shirt className="w-3.5 h-3.5" />
                  <span>{state.armor.pieces.length} pieza(s) seleccionadas</span>
                </div>
              )}
              <button
                type="button"
                onClick={handleSmartSyncRoleArmor}
                className="bg-[#15171C] hover:bg-[#1A1C22] border border-[#C9A050]/70 hover:border-[#C9A050] text-[#C9A050] hover:text-[#E0E0E0] px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all cursor-pointer shadow-xs"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Autoconfigurar Piezas de "{currentRoleName}"</span>
              </button>
            </div>
          </div>

          {/* Quick Style Archetypes / Traditions (If Available for this Style) */}
          {stylePackage.traditions && stylePackage.traditions.length > 0 && (
            <div className="mb-6 bg-[#15171C] border border-[#2A2D35] rounded-xl p-4">
              <div className="text-xs font-bold text-[#E0E0E0] mb-2.5 flex items-center justify-between">
                <span className="flex items-center gap-2 text-[#C9A050]">
                  <Crown className="w-4 h-4 text-[#C9A050]" />
                  <span>Arquetipos y Tradiciones Sugeridas de {state.styleVisual}:</span>
                </span>
                <span className="text-[10px] text-[#888888] font-mono">
                  Haz clic para aplicar conjunto armónico integral (P1-P7) con piezas de tradición + rol
                </span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {stylePackage.traditions.map(trad => {
                  const isActive = thematicData.tradition === trad.name;
                  const ensemble = buildTraditionFullEnsemble(trad, roleConfig);

                  return (
                    <div
                      key={trad.id}
                      onClick={() => handleApplyTradition(trad)}
                      className={`p-3.5 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                        isActive
                          ? 'bg-[#1A1C22] border-[#C9A050] shadow-md ring-1 ring-[#C9A050]/30'
                          : 'bg-[#0F1115] border-[#2A2D35] hover:border-[#444]'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between text-xs font-bold mb-1">
                          <span className={isActive ? 'text-[#C9A050]' : 'text-[#E0E0E0]'}>{trad.name}</span>
                          <span className="text-[10px] text-[#888888] font-mono">{trad.iconTag}</span>
                        </div>
                        <p className="text-[11px] text-[#888888] leading-tight line-clamp-2 mb-2">
                          {trad.description}
                        </p>
                      </div>

                      <div className="pt-2 border-t border-[#2A2D35]/50 space-y-1.5">
                        {/* Slots Covered Badges */}
                        <div className="flex items-center justify-between text-[10px]">
                          <span className="text-[#888888] font-mono">Ranuras:</span>
                          <div className="flex flex-wrap gap-1">
                            {['P1', 'P2', 'P3', 'P4', 'P5', 'P6', 'P7'].map(slotKey => {
                              const isSlotCovered = ensemble.coveredSlots.includes(slotKey);
                              return (
                                <span
                                  key={slotKey}
                                  className={`px-1 py-0.2 rounded text-[9px] font-mono ${
                                    isSlotCovered
                                      ? 'bg-[#C9A050]/20 text-[#C9A050] font-bold border border-[#C9A050]/30'
                                      : 'bg-[#15171C] text-[#555]'
                                  }`}
                                >
                                  {slotKey}
                                </span>
                              );
                            })}
                          </div>
                        </div>

                        <div className="text-[10px] text-[#A0A0A0] flex items-center justify-between">
                          <span className="text-[#C9A050] font-medium">
                            {ensemble.allPieces.length} piezas ({trad.suggestedArmor.length + trad.suggestedAccessories.length} trad. + {ensemble.roleComplementPieces.length} rol)
                          </span>
                          {isActive ? (
                            <span className="text-emerald-400 font-mono font-bold text-[10px]">Activo ✓</span>
                          ) : (
                            <span className="text-[10px] text-[#777] font-mono">Aplicar →</span>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Unified Global Attire & Style Deck */}
          <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-4.5 mb-6">
            <div className="text-xs font-bold text-[#C9A050] uppercase tracking-wider mb-3 flex items-center justify-between border-b border-[#2A2D35]/50 pb-2">
              <span className="flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-[#C9A050]" />
                <span>Configuración Global del Atuendo & Acabados de Estilo</span>
              </span>
              <span className="text-[10px] text-[#888888] font-mono normal-case">
                Afecta a la indumentaria base y sirve de referencia para nuevas piezas
              </span>
            </div>

            {(!state.armor.type || /^ninguna?$/i.test(state.armor.type)) && (
              <div className="mb-3.5 p-2.5 rounded-lg bg-[#1A1C22] border border-[#C9A050]/40 text-[11px] text-[#E0E0E0] flex items-center gap-2">
                <span className="text-[#C9A050] font-bold">ℹ️ Estructura en "Ninguna":</span>
                <span className="text-[#AAAAAA]">No se incluirá indumentaria base ni acabados globales de estilo en la ficha técnica, compilación ni prompts finales.</span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
              {/* 1. Outfit Structure Type */}
              <div>
                <label className="block text-[11px] font-mono text-[#888888] mb-1">
                  Estructura / Corte Base <InfoTooltip text="Tipo de indumentaria base sugerida según el rol." />
                </label>
                <select
                  value={state.armor.type || 'Ninguna'}
                  onChange={e => setState(p => ({ ...p, armor: { ...p.armor, type: e.target.value } }))}
                  className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-lg p-2 text-xs text-[#E0E0E0] focus:border-[#C9A050]"
                >
                  <option value="Ninguna">Ninguna</option>
                  {roleConfig.outfitTypes.filter(o => o.name !== 'Ninguna' && !o.name.startsWith('Ningun')).map(o => (
                    <option key={o.id} value={o.name}>{o.name}</option>
                  ))}
                </select>
              </div>

              {/* 2. Primary Base Material */}
              <div>
                <label className="block text-[11px] font-mono text-[#888888] mb-1">
                  Material Principal Base
                </label>
                <select
                  value={state.armor.material}
                  onChange={e => setState(p => ({ ...p, armor: { ...p.armor, material: e.target.value } }))}
                  className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-lg p-2 text-xs text-[#E0E0E0] focus:border-[#C9A050]"
                >
                  {combinedMaterials.map(m => (
                    <option key={m} value={m}>{m}</option>
                  ))}
                </select>
              </div>

              {/* 3. Surface Finish */}
              <div>
                <label className="block text-[11px] font-mono text-[#888888] mb-1">
                  Acabado Superficial Base
                </label>
                <select
                  value={state.armor.finish}
                  onChange={e => setState(p => ({ ...p, armor: { ...p.armor, finish: e.target.value } }))}
                  className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-lg p-2 text-xs text-[#E0E0E0] focus:border-[#C9A050]"
                >
                  {combinedFinishes.map(f => (
                    <option key={f} value={f}>{f}</option>
                  ))}
                </select>
              </div>

              {/* 4. Accent Mineral / Gem */}
              <div>
                <label className="block text-[11px] font-mono text-[#888888] mb-1">
                  Gema / Mineral de Acento
                </label>
                <select
                  value={thematicData.jadeAccentColor || ''}
                  onChange={e => updateThematic({ jadeAccentColor: e.target.value })}
                  className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-lg p-2 text-xs text-[#E0E0E0] focus:border-[#C9A050]"
                >
                  <option value="">Sin acento mineral específico</option>
                  {(stylePackage.jadeColors || []).map(jc => (
                    <option key={jc.id} value={jc.name}>{jc.name}</option>
                  ))}
                </select>
              </div>

              {/* 5. Textile / Damask Pattern */}
              <div>
                <label className="block text-[11px] font-mono text-[#888888] mb-1">
                  Patrón Textil / Damascado
                </label>
                <select
                  value={thematicData.silkPattern || ''}
                  onChange={e => updateThematic({ silkPattern: e.target.value })}
                  className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-lg p-2 text-xs text-[#E0E0E0] focus:border-[#C9A050]"
                >
                  <option value="">Liso / Sin patrón especial</option>
                  {(stylePackage.silkPatterns || []).map(sp => (
                    <option key={sp} value={sp}>{sp}</option>
                  ))}
                </select>
              </div>

              {/* 6. Spiritual / Aesthetic Motif */}
              <div>
                <label className="block text-[11px] font-mono text-[#888888] mb-1">
                  Motivo / Sello Temático
                </label>
                <select
                  value={thematicData.spiritualMotif || ''}
                  onChange={e => updateThematic({ spiritualMotif: e.target.value })}
                  className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-lg p-2 text-xs text-[#E0E0E0] focus:border-[#C9A050]"
                >
                  <option value="">Ninguno / Sin motivo especial</option>
                  {(stylePackage.spiritualMotifs || []).map(m => (
                    <option key={m} value={m}>{m}</option>
                  ))}
                </select>
              </div>

              {/* 7. Aura / Glow (Visual Only) */}
              <div className="sm:col-span-2">
                <label className="block text-[11px] font-mono text-[#888888] mb-1">
                  Aura / Resplandor Visual (Opcional)
                </label>
                <select
                  value={thematicData.energyAura || 'Sin Aura (Aspecto Natural Puramente Físico)'}
                  onChange={e => updateThematic({ energyAura: e.target.value })}
                  className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-lg p-2 text-xs text-[#E0E0E0] focus:border-[#C9A050]"
                >
                  {(stylePackage.auras || ['Sin Aura (Aspecto Natural Puramente Físico)']).map(a => (
                    <option key={a} value={a}>{a}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* ================================================================= */}
          {/* UNIFIED PIECES EXPLORER (ROLE SLOTS, STYLE ARMOR & ACCESSORIES)   */}
          {/* ================================================================= */}
          <div className="space-y-4 mb-6">
            {/* Navigation Tabs & Quick Add Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#2A2D35] pb-3">
              <div className="flex flex-wrap gap-1.5">
                <button
                  type="button"
                  onClick={() => setActiveCategoryTab('ROLE_SLOTS')}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center space-x-1.5 ${
                    activeCategoryTab === 'ROLE_SLOTS'
                      ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                      : 'bg-[#15171C] text-[#888888] hover:text-[#E0E0E0]'
                  }`}
                >
                  <Tag className="w-3.5 h-3.5" />
                  <span>Prendas de Rol ({currentRoleName})</span>
                  <span className="text-[10px] font-mono opacity-80">
                    ({roleConfig.slots.reduce((acc, s) => acc + s.pieces.length, 0)})
                  </span>
                </button>

                {state.subRole && (
                  <button
                    type="button"
                    onClick={() => setActiveCategoryTab('SUB_ROLE_SLOTS')}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center space-x-1.5 ${
                      activeCategoryTab === 'SUB_ROLE_SLOTS'
                        ? 'bg-cyan-500 text-[#0A0B0E] font-bold shadow-xs'
                        : 'bg-[#15171C] text-cyan-400/80 hover:text-cyan-300'
                    }`}
                  >
                    <Crown className="w-3.5 h-3.5" />
                    <span>Prendas Sub-Rol ({state.subRole})</span>
                    <span className="text-[10px] font-mono opacity-80">
                      ({getRoleAttireConfig(state.subRole).slots.reduce((acc, s) => acc + s.pieces.length, 0)})
                    </span>
                  </button>
                )}

                {stylePackage.armorPieces.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setActiveCategoryTab('STYLE_ARMOR')}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center space-x-1.5 ${
                      activeCategoryTab === 'STYLE_ARMOR'
                        ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                        : 'bg-[#15171C] text-[#888888] hover:text-[#E0E0E0]'
                    }`}
                  >
                    <Shield className="w-3.5 h-3.5" />
                    <span>Armaduras de Estilo</span>
                    <span className="text-[10px] font-mono opacity-80">
                      ({stylePackage.armorPieces.length})
                    </span>
                  </button>
                )}

                {stylePackage.culturalAccessories.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setActiveCategoryTab('STYLE_ACCESSORIES')}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center space-x-1.5 ${
                      activeCategoryTab === 'STYLE_ACCESSORIES'
                        ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                        : 'bg-[#15171C] text-[#888888] hover:text-[#E0E0E0]'
                    }`}
                  >
                    <Gem className="w-3.5 h-3.5" />
                    <span>Accesorios & Joyería</span>
                    <span className="text-[10px] font-mono opacity-80">
                      ({stylePackage.culturalAccessories.length})
                    </span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => setActiveCategoryTab('ALL')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                    activeCategoryTab === 'ALL'
                      ? 'bg-[#1A1C22] border border-[#C9A050] text-[#C9A050] font-bold'
                      : 'bg-[#15171C] text-[#888888] hover:text-[#E0E0E0]'
                  }`}
                >
                  Todas las Piezas
                </button>
              </div>

              {/* Quick Add Custom Piece Toggle Button */}
              <button
                type="button"
                onClick={() => setIsCustomPieceOpen(prev => !prev)}
                className="bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050] text-[#C9A050] px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{isCustomPieceOpen ? 'Cerrar Creador' : '+ Añadir Pieza Personalizada'}</span>
              </button>
            </div>

            {/* Collapsible Quick-Add Custom Piece Bar */}
            {isCustomPieceOpen && (
              <div className="bg-[#15171C] border border-[#C9A050]/50 rounded-xl p-3.5 flex flex-wrap items-center gap-2.5 animate-fade-in shadow-sm">
                <div className="text-xs font-bold text-[#E0E0E0] shrink-0 flex items-center gap-1.5">
                  <Sparkle className="w-3.5 h-3.5 text-[#C9A050]" />
                  <span>Nueva Pieza Personalizada:</span>
                </div>
                <select
                  value={customPieceSlot}
                  onChange={e => setCustomPieceSlot(e.target.value)}
                  className="bg-[#0F1115] border border-[#2A2D35] rounded-lg px-2.5 py-1.5 text-xs text-[#E0E0E0]"
                >
                  <option value="P1">P1 Cabeza / Cuello</option>
                  <option value="P2">P2 Torso / Pechera</option>
                  <option value="P3">P3 Hombros / Brazos</option>
                  <option value="P4">P4 Cintura / Fajín</option>
                  <option value="P5">P5 Piernas / Faldón</option>
                  <option value="P6">P6 Pies / Calzado</option>
                  <option value="P7">P7 Capas / Flotantes</option>
                </select>
                <input
                  type="text"
                  value={customPieceInput}
                  onChange={e => setCustomPieceInput(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter') handleAddCustomPiece(); }}
                  placeholder="Ej. Velo de seda con filigrana dorada, Hombrera de dragón esculpida, Grebas con espuelas..."
                  className="flex-1 min-w-[220px] bg-[#0F1115] border border-[#2A2D35] rounded-lg px-3 py-1.5 text-xs text-[#E0E0E0] placeholder-[#555]"
                />
                <button
                  type="button"
                  onClick={handleAddCustomPiece}
                  className="bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] font-bold px-3.5 py-1.5 rounded-lg text-xs flex items-center gap-1 transition-all cursor-pointer shadow-xs"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Guardar Pieza</span>
                </button>
              </div>
            )}

            {/* TAB 1: ROLE SLOTS (P1 TO P7) */}
            {(activeCategoryTab === 'ROLE_SLOTS' || activeCategoryTab === 'ALL') && (
              <div className="space-y-4">
                {/* Anatomical Slot Filters */}
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-xs font-bold text-[#C9A050] uppercase tracking-wider">
                    Ranuras Anatómicas de {currentRoleName}:
                  </span>
                  <div className="flex flex-wrap gap-1">
                    <button
                      type="button"
                      onClick={() => setActiveRoleSlotFilter('ALL')}
                      className={`px-2.5 py-0.5 rounded text-[10px] font-medium cursor-pointer transition-all ${
                        activeRoleSlotFilter === 'ALL'
                          ? 'bg-[#C9A050] text-[#0A0B0E] font-bold'
                          : 'bg-[#15171C] text-[#888888] hover:text-[#E0E0E0]'
                      }`}
                    >
                      Todos (P1-P7)
                    </button>
                    {roleConfig.slots.map(s => (
                      <button
                        key={s.slotId}
                        type="button"
                        onClick={() => setActiveRoleSlotFilter(s.slotId)}
                        className={`px-2 py-0.5 rounded text-[10px] font-mono cursor-pointer transition-all ${
                          activeRoleSlotFilter === s.slotId
                            ? 'bg-[#C9A050] text-[#0A0B0E] font-bold'
                            : 'bg-[#15171C] text-[#888888] hover:text-[#E0E0E0]'
                        }`}
                      >
                        {s.slotId}
                      </button>
                    ))}
                  </div>
                </div>

                {roleConfig.slots.map(slot => {
                  if (activeRoleSlotFilter !== 'ALL' && activeRoleSlotFilter !== slot.slotId) return null;

                  const stylePiecesForSlot = getStylePiecesForSlot(slot.slotId);
                  const totalOptions = slot.pieces.length + stylePiecesForSlot.length;
                  const activeRoleCount = slot.pieces.filter(p => state.armor.pieces.includes(p)).length;
                  const activeStyleCount = stylePiecesForSlot.filter(p => state.armor.pieces.includes(p.name)).length;
                  const totalActiveInSlot = activeRoleCount + activeStyleCount;

                  return (
                    <div key={slot.slotId} className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-4 space-y-3.5">
                      {/* Slot Header */}
                      <div className="text-xs font-bold text-[#C9A050] pb-2 border-b border-[#2A2D35]/50 flex items-center justify-between">
                        <span className="flex items-center gap-1.5">
                          <Tag className="w-3.5 h-3.5 text-[#C9A050]" />
                          <span>{slot.slotName}</span>
                        </span>
                        <div className="flex items-center gap-2">
                          {totalActiveInSlot > 0 && (
                            <span className="text-[10px] bg-[#C9A050]/20 text-[#C9A050] font-bold px-2 py-0.5 rounded border border-[#C9A050]/40">
                              {totalActiveInSlot} seleccionada{totalActiveInSlot > 1 ? 's' : ''}
                            </span>
                          )}
                          <span className="text-[10px] text-[#888888] font-mono">
                            {totalOptions} opciones ({slot.pieces.length} rol + {stylePiecesForSlot.length} estilo/tradición)
                          </span>
                        </div>
                      </div>

                      {/* Role Canonical Pieces */}
                      <div>
                        <div className="text-[11px] font-semibold text-[#A0A0A0] mb-2 flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#C9A050]"></span>
                          <span>Piezas Canónicas del Rol ({currentRoleName}):</span>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {slot.pieces.map(piece => {
                            const isSelected = state.armor.pieces.includes(piece);
                            const detail = state.armor.pieceDetails?.[piece];

                            return (
                              <div
                                key={piece}
                                className={`flex items-center gap-1.5 rounded-xl p-1 border transition-all ${
                                  isSelected
                                    ? 'bg-[#1A1C22] border-[#C9A050] text-[#E0E0E0] shadow-xs'
                                    : 'bg-[#0F1115] border-[#2A2D35] text-[#888888] hover:border-[#555]'
                                }`}
                              >
                                <button
                                  type="button"
                                  onClick={() => handleArmorPieceToggle(piece, slot.slotId, 'role')}
                                  className="flex items-center space-x-2 px-2.5 py-1.5 text-xs text-left cursor-pointer transition-all"
                                >
                                  <div
                                    className={`w-3.5 h-3.5 rounded flex items-center justify-center border text-[9px] ${
                                      isSelected
                                        ? 'bg-[#C9A050] border-[#C9A050] text-[#0A0B0E] font-bold'
                                        : 'border-[#444] bg-[#0F1115]'
                                    }`}
                                  >
                                    {isSelected && <Check className="w-2.5 h-2.5" />}
                                  </div>
                                  <span className={isSelected ? 'text-[#FFFFFF] font-semibold' : 'text-[#B0B0B0]'}>
                                    {piece}
                                  </span>
                                </button>

                                {isSelected && detail && (
                                  <div className="flex items-center gap-1 pr-1.5 border-l border-[#2A2D35] pl-1.5">
                                    <div
                                      title={`Color: ${detail.color || '#C9A050'}`}
                                      className="w-3.5 h-3.5 rounded-full border border-[#444] shrink-0"
                                      style={{ backgroundColor: detail.color || '#C9A050' }}
                                    />
                                    {detail.length && (
                                      <span className="text-[10px] font-mono text-[#C9A050] bg-[#0F1115] px-1.5 py-0.5 rounded border border-[#C9A050]/40 max-w-[100px] truncate">
                                        {detail.length.split(' / ')[0]}
                                      </span>
                                    )}
                                    <button
                                      type="button"
                                      title="Ajustar modificadores"
                                      onClick={() => {
                                        setFocusedPieceId(piece);
                                        setActiveEditorPieceFilter(piece);
                                        const el = document.getElementById(`piece-customizer-${piece.replace(/[^a-zA-Z0-9]/g, '_')}`);
                                        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                                      }}
                                      className="text-[#888888] hover:text-[#C9A050] p-1 cursor-pointer"
                                    >
                                      <Sliders className="w-3 h-3" />
                                    </button>
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Style Archetypes & Traditions Pieces Mapped to this Slot */}
                      {stylePiecesForSlot.length > 0 && (
                        <div className="pt-2 border-t border-[#2A2D35]/40">
                          <div className="text-[11px] font-semibold text-cyan-400 mb-2 flex items-center justify-between">
                            <span className="flex items-center gap-1.5">
                              <Sparkles className="w-3 h-3 text-cyan-400" />
                              <span>Piezas de Arquetipos y Tradiciones de Estilo ({state.styleVisual}):</span>
                            </span>
                            <span className="text-[10px] text-[#777] font-mono">
                              {stylePiecesForSlot.length} piezas sugeridas
                            </span>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {stylePiecesForSlot.map(sp => {
                              const isSelected = state.armor.pieces.includes(sp.name);
                              const detail = state.armor.pieceDetails?.[sp.name];

                              return (
                                <div
                                  key={sp.id}
                                  className={`flex items-center gap-1.5 rounded-xl p-1 border transition-all ${
                                    isSelected
                                      ? 'bg-[#142028] border-cyan-500/80 text-[#E0E0E0] shadow-xs'
                                      : 'bg-[#0A0E13] border-[#202E38] text-[#888888] hover:border-cyan-800'
                                  }`}
                                >
                                  <button
                                    type="button"
                                    onClick={() => handleArmorPieceToggle(sp.name, slot.slotId, sp.sourceType, sp.description)}
                                    className="flex items-center space-x-2 px-2.5 py-1.5 text-xs text-left cursor-pointer transition-all"
                                  >
                                    <div
                                      className={`w-3.5 h-3.5 rounded flex items-center justify-center border text-[9px] ${
                                        isSelected
                                          ? 'bg-cyan-500 border-cyan-500 text-[#0A0B0E] font-bold'
                                          : 'border-[#334455] bg-[#0F1115]'
                                      }`}
                                    >
                                      {isSelected && <Check className="w-2.5 h-2.5" />}
                                    </div>
                                    <span className="text-[10px] font-mono text-cyan-400/80 bg-cyan-950/40 px-1 py-0.2 rounded border border-cyan-800/40">
                                      {sp.iconTag || '✨'} {sp.originBadge}
                                    </span>
                                    <span className={isSelected ? 'text-[#FFFFFF] font-semibold' : 'text-[#B0B0B0]'}>
                                      {sp.name}
                                    </span>
                                  </button>

                                  {isSelected && detail && (
                                    <div className="flex items-center gap-1 pr-1.5 border-l border-[#202E38] pl-1.5">
                                      <div
                                        title={`Color: ${detail.color || '#C9A050'}`}
                                        className="w-3.5 h-3.5 rounded-full border border-[#444] shrink-0"
                                        style={{ backgroundColor: detail.color || '#C9A050' }}
                                      />
                                      {detail.length && (
                                        <span className="text-[10px] font-mono text-cyan-300 bg-[#0F1115] px-1.5 py-0.5 rounded border border-cyan-500/40 max-w-[100px] truncate">
                                          {detail.length.split(' / ')[0]}
                                        </span>
                                      )}
                                      <button
                                        type="button"
                                        title="Ajustar modificadores"
                                        onClick={() => {
                                          setFocusedPieceId(sp.name);
                                          setActiveEditorPieceFilter(sp.name);
                                          const el = document.getElementById(`piece-customizer-${sp.name.replace(/[^a-zA-Z0-9]/g, '_')}`);
                                          if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                                        }}
                                        className="text-[#888888] hover:text-cyan-400 p-1 cursor-pointer"
                                      >
                                        <Sliders className="w-3 h-3" />
                                      </button>
                                    </div>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            {/* TAB: SUB-ROLE SLOTS (P1 TO P7 for state.subRole) */}
            {state.subRole && (activeCategoryTab === 'SUB_ROLE_SLOTS' || activeCategoryTab === 'ALL') && (() => {
              const subConfig = getRoleAttireConfig(state.subRole);
              return (
                <div className="space-y-4 pt-2 border-t border-cyan-500/30">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
                      <Crown className="w-3.5 h-3.5" />
                      <span>Ranuras Anatómicas del Sub-Rol ({state.subRole}):</span>
                    </span>
                    <span className="text-[10px] text-[#888888] font-mono">
                      {subConfig.slots.reduce((acc, s) => acc + s.pieces.length, 0)} piezas disponibles
                    </span>
                  </div>

                  {subConfig.slots.map(slot => {
                    const activeCount = slot.pieces.filter(p => state.armor.pieces.includes(p)).length;

                    return (
                      <div key={`sub-${slot.slotId}`} className="bg-[#15171C] border border-cyan-500/30 rounded-xl p-4 space-y-3.5">
                        <div className="text-xs font-bold text-cyan-300 pb-2 border-b border-[#2A2D35]/50 flex items-center justify-between">
                          <span className="flex items-center gap-1.5">
                            <Tag className="w-3.5 h-3.5 text-cyan-400" />
                            <span>{slot.slotName} ({slot.slotId})</span>
                          </span>
                          {activeCount > 0 && (
                            <span className="text-[10px] bg-cyan-950/40 text-cyan-300 font-bold px-2 py-0.5 rounded border border-cyan-500/40">
                              {activeCount} seleccionada{activeCount > 1 ? 's' : ''}
                            </span>
                          )}
                        </div>

                        <div className="flex flex-wrap gap-2">
                          {slot.pieces.map(piece => {
                            const isSelected = state.armor.pieces.includes(piece);
                            const detail = state.armor.pieceDetails?.[piece];

                            return (
                              <div
                                key={piece}
                                className={`flex items-center gap-1.5 rounded-xl p-1 border transition-all ${
                                  isSelected
                                    ? 'bg-cyan-950/30 border-cyan-400 text-[#E0E0E0] shadow-xs ring-1 ring-cyan-400/40'
                                    : 'bg-[#0F1115] border-[#2A2D35] text-[#888888] hover:border-cyan-500/40'
                                }`}
                              >
                                <button
                                  type="button"
                                  onClick={() => handleArmorPieceToggle(piece, slot.slotId, 'role', `Pieza de sub-rol ${state.subRole}`)}
                                  className="px-2.5 py-1 text-xs font-medium flex items-center gap-1.5 cursor-pointer text-left"
                                >
                                  <div
                                    className={`w-3.5 h-3.5 rounded flex items-center justify-center border text-[9px] shrink-0 ${
                                      isSelected
                                        ? 'bg-cyan-400 border-cyan-400 text-[#0A0B0E] font-bold'
                                        : 'border-[#444] bg-[#0A0B0E]'
                                    }`}
                                  >
                                    {isSelected && <Check className="w-2.5 h-2.5" />}
                                  </div>
                                  <span>{piece}</span>
                                </button>

                                {isSelected && detail && (
                                  <div className="flex items-center gap-1 pr-1.5 pl-1 border-l border-[#2A2D35]">
                                    <div
                                      title={`Color: ${detail.color || '#C9A050'}`}
                                      className="w-3.5 h-3.5 rounded-full border border-[#444]"
                                      style={{ backgroundColor: detail.color || '#C9A050' }}
                                    />
                                    <button
                                      type="button"
                                      title="Ajustar modificadores físicos"
                                      onClick={() => {
                                        setFocusedPieceId(piece);
                                        setActiveEditorPieceFilter(piece);
                                        const el = document.getElementById(`piece-customizer-${piece.replace(/[^a-zA-Z0-9]/g, '_')}`);
                                        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                                      }}
                                      className="text-[#888888] hover:text-cyan-300 p-0.5 cursor-pointer"
                                    >
                                      <Sliders className="w-3 h-3" />
                                    </button>
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              );
            })()}

            {/* TAB 2: STYLE ARMOR */}
            {(activeCategoryTab === 'STYLE_ARMOR' || activeCategoryTab === 'ALL') && stylePackage.armorPieces.length > 0 && (
              <div className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-xs font-bold text-[#C9A050] uppercase tracking-wider">
                    Piezas de Armadura & Protección del Estilo {state.styleVisual}:
                  </span>
                  <div className="flex flex-wrap gap-1">
                    <button
                      type="button"
                      onClick={() => setArmorCategoryFilter('ALL')}
                      className={`px-2.5 py-0.5 rounded text-[10px] font-medium cursor-pointer transition-all ${
                        armorCategoryFilter === 'ALL' ? 'bg-[#C9A050] text-[#0A0B0E] font-bold' : 'bg-[#15171C] text-[#888888]'
                      }`}
                    >
                      Todas
                    </button>
                    {styleArmorCategories.map(cat => (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setArmorCategoryFilter(cat)}
                        className={`px-2.5 py-0.5 rounded text-[10px] font-medium cursor-pointer transition-all ${
                          armorCategoryFilter === cat ? 'bg-[#C9A050] text-[#0A0B0E] font-bold' : 'bg-[#15171C] text-[#888888]'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {filteredStyleArmorPieces.map(piece => {
                    const isSelected = state.armor.pieces.includes(piece.name);
                    const detail = state.armor.pieceDetails?.[piece.name];

                    return (
                      <div
                        key={piece.id}
                        className={`p-3.5 rounded-xl border transition-all ${
                          isSelected
                            ? 'bg-[#1A1C22] border-[#C9A050] shadow-sm ring-1 ring-[#C9A050]/20'
                            : 'bg-[#15171C] border-[#2A2D35] hover:border-[#444]'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <button
                            type="button"
                            onClick={() => handleArmorPieceToggle(piece.name, undefined, 'style_armor', piece.description)}
                            className="flex items-start space-x-2.5 text-left cursor-pointer flex-1"
                          >
                            <div
                              className={`w-4 h-4 mt-0.5 rounded flex items-center justify-center border text-[10px] shrink-0 ${
                                isSelected
                                  ? 'bg-[#C9A050] border-[#C9A050] text-[#0A0B0E] font-bold'
                                  : 'border-[#444] bg-[#0F1115]'
                              }`}
                            >
                              {isSelected && <Check className="w-3 h-3" />}
                            </div>
                            <div>
                              <div className="text-xs font-bold text-[#E0E0E0]">{piece.name}</div>
                              <div className="text-[10px] text-[#C9A050] font-mono mt-0.5">{piece.category} • {piece.culturalOrigin}</div>
                              <p className="text-[11px] text-[#888888] mt-1 leading-snug">
                                {piece.description}
                              </p>
                            </div>
                          </button>

                          {isSelected && detail && (
                            <div className="flex flex-col items-end gap-1.5 shrink-0 pl-2 border-l border-[#2A2D35]">
                              <div
                                title={`Color: ${detail.color || '#C9A050'}`}
                                className="w-4 h-4 rounded-full border border-[#444]"
                                style={{ backgroundColor: detail.color || '#C9A050' }}
                              />
                              <button
                                type="button"
                                title="Ajustar modificadores"
                                onClick={() => {
                                  setFocusedPieceId(piece.name);
                                  setActiveEditorPieceFilter(piece.name);
                                  const el = document.getElementById(`piece-customizer-${piece.name.replace(/[^a-zA-Z0-9]/g, '_')}`);
                                  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                                }}
                                className="text-[#888888] hover:text-[#C9A050] p-1 cursor-pointer"
                              >
                                <Sliders className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* TAB 3: STYLE ACCESSORIES & JEWELRY */}
            {(activeCategoryTab === 'STYLE_ACCESSORIES' || activeCategoryTab === 'ALL') && stylePackage.culturalAccessories.length > 0 && (
              <div className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-xs font-bold text-[#C9A050] uppercase tracking-wider">
                    Accesorios, Tocados & Joyería del Estilo {state.styleVisual}:
                  </span>
                  <div className="flex flex-wrap gap-1">
                    <button
                      type="button"
                      onClick={() => setAccessoryCategoryFilter('ALL')}
                      className={`px-2.5 py-0.5 rounded text-[10px] font-medium cursor-pointer transition-all ${
                        accessoryCategoryFilter === 'ALL' ? 'bg-[#C9A050] text-[#0A0B0E] font-bold' : 'bg-[#15171C] text-[#888888]'
                      }`}
                    >
                      Todos
                    </button>
                    {styleAccessoryCategories.map(cat => (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setAccessoryCategoryFilter(cat)}
                        className={`px-2.5 py-0.5 rounded text-[10px] font-medium cursor-pointer transition-all ${
                          accessoryCategoryFilter === cat ? 'bg-[#C9A050] text-[#0A0B0E] font-bold' : 'bg-[#15171C] text-[#888888]'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {filteredStyleAccessories.map(acc => {
                    const isSelected = state.armor.pieces.includes(acc.name);
                    const detail = state.armor.pieceDetails?.[acc.name];

                    return (
                      <div
                        key={acc.id}
                        className={`p-3.5 rounded-xl border transition-all ${
                          isSelected
                            ? 'bg-[#1A1C22] border-[#C9A050] shadow-sm ring-1 ring-[#C9A050]/20'
                            : 'bg-[#15171C] border-[#2A2D35] hover:border-[#444]'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <button
                            type="button"
                            onClick={() => handleArmorPieceToggle(acc.name, undefined, 'style_accessory', acc.description)}
                            className="flex items-start space-x-2.5 text-left cursor-pointer flex-1"
                          >
                            <div
                              className={`w-4 h-4 mt-0.5 rounded flex items-center justify-center border text-[10px] shrink-0 ${
                                isSelected
                                  ? 'bg-[#C9A050] border-[#C9A050] text-[#0A0B0E] font-bold'
                                  : 'border-[#444] bg-[#0F1115]'
                              }`}
                            >
                              {isSelected && <Check className="w-3 h-3" />}
                            </div>
                            <div>
                              <div className="text-xs font-bold text-[#E0E0E0]">{acc.name}</div>
                              <div className="text-[10px] text-[#C9A050] font-mono mt-0.5">{acc.category} • {acc.culturalOrigin}</div>
                              <p className="text-[11px] text-[#888888] mt-1 leading-snug">
                                {acc.description}
                              </p>
                            </div>
                          </button>

                          {isSelected && detail && (
                            <div className="flex flex-col items-end gap-1.5 shrink-0 pl-2 border-l border-[#2A2D35]">
                              <div
                                title={`Color: ${detail.color || '#C9A050'}`}
                                className="w-4 h-4 rounded-full border border-[#444]"
                                style={{ backgroundColor: detail.color || '#C9A050' }}
                              />
                              <button
                                type="button"
                                title="Ajustar modificadores"
                                onClick={() => {
                                  setFocusedPieceId(acc.name);
                                  setActiveEditorPieceFilter(acc.name);
                                  const el = document.getElementById(`piece-customizer-${acc.name.replace(/[^a-zA-Z0-9]/g, '_')}`);
                                  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                                }}
                                className="text-[#888888] hover:text-[#C9A050] p-1 cursor-pointer"
                              >
                                <Sliders className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* ==================================================================== */}
          {/* SECTION 4.1.1: COMPREHENSIVE MODIFIERS EDITOR (COLOR, LENGTH, MATERIAL, */}
          {/* FINISH, DETAIL LOCATION & PHYSICAL DESCRIPTION)                       */}
          {/* ==================================================================== */}
          <div className="pt-6 border-t border-[#2A2D35]">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
              <div>
                <h4 className="text-sm font-semibold text-[#E0E0E0] flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-[#C9A050]" />
                  <span>4.1.1 Editor de Modificadores Individuales de Piezas</span>
                </h4>
                <p className="text-[11px] text-[#888888] mt-0.5">
                  Parámetros visuales y físicos exactos (color #HEX, caída/largo contextual, material textil/metálico, textura, ubicación de adornos y silueta física).
                </p>
              </div>

              {state.armor.pieces.length > 0 && (
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-[11px] text-[#888888] font-mono">Armonizar con:</span>
                  {(roleConfig.suggestedColors || []).slice(0, 3).map(sc => (
                    <button
                      key={sc.id}
                      type="button"
                      title={`Aplicar ${sc.name} (${sc.hex}) a todas las piezas`}
                      onClick={() => handleHarmonizeAllPiecesColor(sc.hex)}
                      className="flex items-center gap-1 bg-[#15171C] hover:bg-[#1F222A] border border-[#2A2D35] px-2 py-1 rounded-lg text-[10px] text-[#E0E0E0] cursor-pointer transition-all shadow-2xs"
                    >
                      <span className="w-2.5 h-2.5 rounded-full border border-[#444]" style={{ backgroundColor: sc.hex }} />
                      <span>{sc.name.split(' / ')[0]}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {state.armor.pieces.length === 0 ? (
              <div className="bg-[#15171C]/60 border border-dashed border-[#2A2D35] rounded-xl p-6 text-center">
                <Tag className="w-8 h-8 text-[#555] mx-auto mb-2 opacity-50" />
                <div className="text-xs text-[#888888]">
                  No has seleccionado ninguna pieza de indumentaria o armadura todavía.
                </div>
                <div className="text-[11px] text-[#666] mt-1">
                  Selecciona piezas de las pestañas superiores o haz clic en "Autoconfigurar Piezas" para activarlas y editar sus modificadores.
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Active Pieces Selector Ribbon */}
                <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-2.5 flex flex-wrap items-center gap-2">
                  <span className="text-[11px] font-mono text-[#888888] pl-1">Filtrar editor:</span>
                  <button
                    type="button"
                    onClick={() => setActiveEditorPieceFilter('ALL')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                      activeEditorPieceFilter === 'ALL'
                        ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                        : 'bg-[#0F1115] text-[#888888] hover:text-[#E0E0E0]'
                    }`}
                  >
                    Ver Todas ({state.armor.pieces.length})
                  </button>
                  {state.armor.pieces.map(pKey => {
                    const pDet = state.armor.pieceDetails?.[pKey];
                    const isSelectedFilter = activeEditorPieceFilter === pKey;
                    const cleanName = pKey.replace(/^P\d+\.?\d*\s*/, '').replace(/^P-Custom:\s*/, '');

                    return (
                      <button
                        key={pKey}
                        type="button"
                        onClick={() => {
                          setActiveEditorPieceFilter(pKey);
                          setFocusedPieceId(pKey);
                        }}
                        className={`px-2 py-1 rounded-lg text-[11px] font-medium border flex items-center gap-1.5 cursor-pointer transition-all ${
                          isSelectedFilter
                            ? 'bg-[#1A1C22] border-[#C9A050] text-[#C9A050] font-bold shadow-xs'
                            : 'bg-[#0F1115] border-[#2A2D35] text-[#888888] hover:text-[#E0E0E0]'
                        }`}
                      >
                        <span
                          className="w-2.5 h-2.5 rounded-full border border-[#444] shrink-0"
                          style={{ backgroundColor: pDet?.color || '#C9A050' }}
                        />
                        <span className="truncate max-w-[120px]">{cleanName}</span>
                      </button>
                    );
                  })}
                </div>

                {/* Individual Piece Modifiers Cards */}
                {state.armor.pieces.map((pieceKey) => {
                  if (activeEditorPieceFilter !== 'ALL' && activeEditorPieceFilter !== pieceKey) {
                    return null;
                  }

                  const detail: RolePieceDetail = state.armor.pieceDetails?.[pieceKey] || {
                    id: pieceKey,
                    name: pieceKey,
                    color: roleConfig.suggestedColors[0]?.hex || '#C9A050',
                    length: getDefaultPieceLength(pieceKey),
                    material: state.armor.material || roleConfig.materials[0] || GENERAL_ROLE_MATERIALS[3],
                    finish: state.armor.finish || roleConfig.finishes[0] || GENERAL_ROLE_FINISHES[1],
                    detailLocation: 'Bordes y dobladillos',
                    detail: '',
                    description: ''
                  };

                  const cleanPieceTitle = pieceKey
                    .replace(/^P\d+\.?\d*\s*/, '')
                    .replace(/^P-Custom:\s*/, '');
                  const lengthOptions = getPieceLengthOptions(pieceKey, detail.slot);
                  const isFocused = focusedPieceId === pieceKey;
                  const domId = `piece-customizer-${pieceKey.replace(/[^a-zA-Z0-9]/g, '_')}`;

                  const detectedSlot = (detail.slot || mapPieceToAnatomicalSlot(pieceKey)) as ('P1' | 'P2' | 'P3' | 'P4' | 'P5' | 'P6' | 'P7');
                  const slotConfig = detectedSlot ? getArmorSlotOptionConfig(detectedSlot) : undefined;
                  const pieceMaterials = slotConfig ? slotConfig.materials : combinedMaterials;
                  const pieceFinishes = slotConfig ? slotConfig.finishes : combinedFinishes;
                  const pieceDetailLocations = slotConfig ? slotConfig.detailLocations : DETAIL_LOCATIONS;

                  return (
                    <div
                      key={pieceKey}
                      id={domId}
                      className={`bg-[#15171C] rounded-xl p-4 border transition-all ${
                        isFocused
                          ? 'border-[#C9A050] shadow-md ring-1 ring-[#C9A050]/20'
                          : 'border-[#2A2D35] hover:border-[#3A3E48]'
                      }`}
                    >
                      {/* Piece Title & Actions Header */}
                      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 mb-3 border-b border-[#2A2D35]/50">
                        <div className="flex items-center space-x-2">
                          <span
                            className="w-3.5 h-3.5 rounded-full border border-[#444] shrink-0 shadow-xs"
                            style={{ backgroundColor: detail.color || '#C9A050' }}
                          />
                          <span className="text-xs font-bold text-[#E0E0E0]">
                            {cleanPieceTitle}
                          </span>
                          <span className="text-[10px] font-mono bg-[#0F1115] text-[#C9A050] border border-[#C9A050]/30 px-2 py-0.5 rounded">
                            {pieceKey.startsWith('P-Custom:')
                              ? 'Personalizada'
                              : detail.category === 'style_armor'
                                ? 'Armadura de Estilo'
                                : detail.category === 'style_accessory'
                                  ? 'Accesorio de Estilo'
                                  : pieceKey.split(' ')[0]}
                          </span>
                        </div>

                        <div className="flex items-center space-x-2">
                          <button
                            type="button"
                            onClick={() => handleResetPieceDetail(pieceKey, detail.slot)}
                            title="Restablecer valores estándar"
                            className="text-[10px] font-mono text-[#888888] hover:text-[#C9A050] flex items-center space-x-1 px-2 py-1 rounded bg-[#0F1115] border border-[#2A2D35] cursor-pointer"
                          >
                            <RotateCcw className="w-2.5 h-2.5" />
                            <span>Reset</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleArmorPieceToggle(pieceKey, detail.slot, detail.category)}
                            title="Quitar pieza"
                            className="text-[11px] text-red-400 hover:text-red-300 px-2.5 py-0.5 rounded bg-[#0F1115] border border-red-900/40 cursor-pointer"
                          >
                            Quitar
                          </button>
                        </div>
                      </div>

                      {/* Modifiers Grid */}
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {/* 1. COLOR MODIFIER */}
                        <div className="space-y-2">
                          <label className="block text-[11px] font-mono text-[#888888] flex items-center gap-1.5">
                            <Palette className="w-3.5 h-3.5 text-[#C9A050]" />
                            <span>Color Exacto</span>
                          </label>

                          <div className="flex items-center gap-2">
                            <input
                              type="color"
                              value={detail.color && detail.color.startsWith('#') ? detail.color : '#C9A050'}
                              onChange={e => handleUpdatePieceDetail(pieceKey, { color: e.target.value })}
                              className="w-8 h-8 rounded-lg border border-[#2A2D35] cursor-pointer bg-transparent"
                            />
                            <input
                              type="text"
                              value={detail.color || ''}
                              onChange={e => handleUpdatePieceDetail(pieceKey, { color: e.target.value })}
                              placeholder="#C9A050 o Dorado brillante"
                              className="flex-1 bg-[#0F1115] border border-[#2A2D35] rounded-xl px-3 py-1.5 text-xs text-[#E0E0E0] font-mono"
                            />
                          </div>

                          {/* Quick Swatches */}
                          <div className="flex flex-wrap items-center gap-1.5 pt-1">
                            <span className="text-[10px] text-[#666] font-mono">Sugeridos:</span>
                            {(roleConfig.suggestedColors || []).slice(0, 4).map(sc => (
                              <button
                                key={sc.id}
                                type="button"
                                title={`${sc.name} (${sc.hex})`}
                                onClick={() => handleUpdatePieceDetail(pieceKey, { color: sc.hex })}
                                className={`w-5 h-5 rounded-full border transition-all cursor-pointer ${
                                  detail.color === sc.hex ? 'border-[#FFFFFF] scale-110 shadow-sm' : 'border-[#444] hover:scale-105'
                                }`}
                                style={{ backgroundColor: sc.hex }}
                              />
                            ))}
                            {(stylePackage.jadeColors || []).slice(0, 3).map(jc => (
                              <button
                                key={jc.id}
                                type="button"
                                title={`${jc.name} (${jc.hex})`}
                                onClick={() => handleUpdatePieceDetail(pieceKey, { color: jc.hex })}
                                className={`w-5 h-5 rounded-full border transition-all cursor-pointer ${
                                  detail.color === jc.hex ? 'border-[#FFFFFF] scale-110 shadow-sm' : 'border-[#444] hover:scale-105'
                                }`}
                                style={{ backgroundColor: jc.hex }}
                              />
                            ))}
                          </div>
                        </div>

                        {/* 2. CONTEXTUAL LENGTH & COVERAGE MODIFIER */}
                        <div className="space-y-2">
                          <label className="block text-[11px] font-mono text-[#888888] flex items-center justify-between">
                            <span className="flex items-center gap-1.5">
                              <Ruler className="w-3.5 h-3.5 text-[#C9A050]" />
                              <span>Largo / Extensión de Caída</span>
                            </span>
                            <span className="text-[10px] text-[#C9A050] font-mono truncate max-w-[120px]">
                              {detail.length || 'Estándar'}
                            </span>
                          </label>

                          <div className="flex flex-wrap gap-1">
                            {lengthOptions.map(opt => {
                              const isSelected = detail.length === opt;
                              return (
                                <button
                                  key={opt}
                                  type="button"
                                  onClick={() => handleUpdatePieceDetail(pieceKey, { length: opt })}
                                  className={`px-2 py-0.5 rounded text-[10px] font-medium border transition-all cursor-pointer ${
                                    isSelected
                                      ? 'bg-[#C9A050] border-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                                      : 'bg-[#0F1115] border-[#2A2D35] text-[#888888] hover:text-[#E0E0E0]'
                                  }`}
                                >
                                  {opt.split(' (')[0]}
                                </button>
                              );
                            })}
                          </div>

                          <input
                            type="text"
                            value={detail.length || ''}
                            onChange={e => handleUpdatePieceDetail(pieceKey, { length: e.target.value })}
                            placeholder="O largo personalizado (ej. Al suelo, 60cm, Hasta el muslo...)"
                            className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl px-3 py-1 text-[11px] text-[#E0E0E0] placeholder-[#555]"
                          />
                        </div>

                        {/* 3. MATERIAL MODIFIER */}
                        <div className="space-y-1.5">
                          <label className="block text-[11px] font-mono text-[#888888]">
                            Material / Tejido / Aleación
                          </label>
                          <select
                            value={detail.material || (pieceMaterials[0] || state.armor.material)}
                            onChange={e => handleUpdatePieceDetail(pieceKey, { material: e.target.value })}
                            className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                          >
                            {pieceMaterials.map(m => (
                              <option key={m} value={m}>{m}</option>
                            ))}
                          </select>
                        </div>

                        {/* 4. FINISH MODIFIER */}
                        <div className="space-y-1.5">
                          <label className="block text-[11px] font-mono text-[#888888]">
                            Acabado / Textura Superficial
                          </label>
                          <select
                            value={detail.finish || (pieceFinishes[0] || state.armor.finish)}
                            onChange={e => handleUpdatePieceDetail(pieceKey, { finish: e.target.value })}
                            className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                          >
                            {pieceFinishes.map(f => (
                              <option key={f} value={f}>{f}</option>
                            ))}
                          </select>
                        </div>

                        {/* 5. DETAIL LOCATION MODIFIER */}
                        <div className="space-y-1.5">
                          <label className="block text-[11px] font-mono text-[#888888] flex items-center gap-1.5">
                            <MapPin className="w-3.5 h-3.5 text-[#C9A050]" />
                            <span>Ubicación de Detalles & Acentos</span>
                          </label>
                          <select
                            value={detail.detailLocation || 'Bordes y dobladillos'}
                            onChange={e => handleUpdatePieceDetail(pieceKey, { detailLocation: e.target.value })}
                            className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                          >
                            {pieceDetailLocations.map(loc => (
                              <option key={loc} value={loc}>{loc}</option>
                            ))}
                          </select>
                        </div>

                        {/* 6. PHYSICAL DETAIL / ORNAMENT */}
                        <div className="space-y-1.5">
                          <label className="block text-[11px] font-mono text-[#888888]">
                            Adorno o Detalle Físico Concreto
                          </label>
                          <input
                            type="text"
                            value={detail.detail || ''}
                            onChange={e => handleUpdatePieceDetail(pieceKey, { detail: e.target.value })}
                            placeholder="Ej. Ribetes dorados cosidos, Tachuelas de bronce, Filigrana en relieve..."
                            className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl px-3 py-1.5 text-xs text-[#E0E0E0] placeholder-[#555]"
                          />
                          {slotConfig?.suggestedDetails && slotConfig.suggestedDetails.length > 0 && (
                            <div className="flex flex-wrap gap-1 pt-1">
                              {slotConfig.suggestedDetails.map(sug => {
                                const isAdded = (detail.detail || '').includes(sug);
                                return (
                                  <button
                                    key={sug}
                                    type="button"
                                    onClick={() => {
                                      const current = detail.detail || '';
                                      let updated;
                                      if (current.includes(sug)) {
                                        updated = current.replace(sug, '').replace(/,\s*,/g, ',').replace(/^,\s*|,\s*$/g, '').trim();
                                      } else {
                                        updated = current ? `${current}, ${sug}` : sug;
                                      }
                                      handleUpdatePieceDetail(pieceKey, { detail: updated });
                                    }}
                                    className={`px-1.5 py-0.5 rounded text-[9px] border transition-all cursor-pointer ${
                                      isAdded
                                        ? 'bg-[#C9A050] border-[#C9A050] text-[#0A0B0E] font-bold'
                                        : 'bg-[#0F1115] border-[#2A2D35] text-[#888888] hover:text-[#E0E0E0]'
                                    }`}
                                  >
                                    {sug} {isAdded && '✓'}
                                  </button>
                                );
                              })}
                            </div>
                          )}
                        </div>

                        {/* 7. PHYSICAL VISUAL DESCRIPTION (Concise, Visual-Only) */}
                        <div className="md:col-span-2 lg:col-span-3 space-y-1.5">
                          <label className="block text-[11px] font-mono text-[#888888] flex items-center justify-between">
                            <span className="flex items-center gap-1.5">
                              <Eye className="w-3.5 h-3.5 text-[#C9A050]" />
                              <span>Aspecto Físico y Silueta de la Pieza (Puramente Visual)</span>
                            </span>
                            <span className="text-[10px] text-[#666]">
                              Sin elementos narrativos ajenos a cómo se ve
                            </span>
                          </label>
                          <input
                            type="text"
                            value={detail.description || ''}
                            onChange={e => handleUpdatePieceDetail(pieceKey, { description: e.target.value })}
                            placeholder="Descripción concisa de qué es y cómo luce (forma geométrica, drapeado, placas solapadas, aberturas...)"
                            className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl px-3 py-1.5 text-xs text-[#E0E0E0] placeholder-[#555]"
                          />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* ==================================================================== */}
        {/* SECTION 4.2: STATE 3 WARDROBE SYNCHRONIZATION & HARMONIZATION        */}
        {/* ==================================================================== */}
        <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs">
          <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
            <div>
              <h3 className="text-lg font-serif italic text-[#C9A050] flex items-center gap-2">
                <Shirt className="w-5 h-5 text-[#C9A050]" />
                <span>4.2 Sintonización y Armonización de Guardarropa de Estado 3</span>
              </h3>
              <p className="text-xs text-[#888888] mt-1">
                Ajusta las prendas creadas en el Estado 3 con materiales, acabados y paletas cromáticas influenciadas por <strong>{currentRoleName}</strong> y el estilo <strong>{state.styleVisual}</strong>.
              </p>
            </div>
            {state.wardrobes && state.wardrobes.length > 0 && (
              <div className="text-xs font-mono bg-[#1A1C22] border border-[#C9A050] text-[#C9A050] px-3 py-1.5 rounded-lg flex items-center gap-1.5">
                <Shirt className="w-3.5 h-3.5" />
                <span>{state.wardrobes.length} prenda(s) en guardarropa</span>
              </div>
            )}
          </div>

          {/* Quick-Action Synchronizers */}
          <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-4 mb-6">
            <div className="text-xs font-bold text-[#E0E0E0] mb-3 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#C9A050]" />
              <span>Acciones Rápidas de Armonización:</span>
            </div>
            <div className="flex flex-wrap gap-3">
              <button
                onClick={handleSyncWardrobeToRole}
                className="bg-[#1A1C22] hover:bg-[#252830] border border-[#C9A050]/60 hover:border-[#C9A050] text-[#E0E0E0] px-3.5 py-2 rounded-xl text-xs font-medium flex items-center space-x-2 transition-all cursor-pointer shadow-sm"
              >
                <RefreshCw className="w-3.5 h-3.5 text-[#C9A050]" />
                <span>Sintonizar Materiales al Rol ({currentRoleName})</span>
              </button>

              <button
                onClick={handleSyncWardrobeToStyle}
                className="bg-[#1A1C22] hover:bg-[#252830] border border-[#C9A050]/60 hover:border-[#C9A050] text-[#E0E0E0] px-3.5 py-2 rounded-xl text-xs font-medium flex items-center space-x-2 transition-all cursor-pointer shadow-sm"
              >
                <Palette className="w-3.5 h-3.5 text-[#C9A050]" />
                <span>Sintonizar Acabados al Estilo ({state.styleVisual})</span>
              </button>

              <button
                onClick={handleHarmonizeWardrobeColors}
                className="bg-[#1A1C22] hover:bg-[#252830] border border-[#2A2D35] hover:border-[#C9A050] text-[#A0A0A0] hover:text-[#E0E0E0] px-3.5 py-2 rounded-xl text-xs font-medium flex items-center space-x-2 transition-all cursor-pointer"
              >
                <Layers className="w-3.5 h-3.5 text-[#C9A050]" />
                <span>Armonizar Paleta de Colores de Rol</span>
              </button>
            </div>
          </div>

          {/* Garments List with Fine-Tuning */}
          {state.wardrobes && state.wardrobes.length > 0 ? (
            <div className="space-y-4">
              <div className="text-xs font-mono text-[#888888]">
                Haz clic en cualquier prenda para desplegar y ajustar sus modificadores:
              </div>

              {state.wardrobes.map((garment, index) => {
                const isExpanded = expandedGarmentId === garment.id;

                return (
                  <div
                    key={garment.id}
                    className={`border rounded-xl transition-all ${
                      isExpanded
                        ? 'bg-[#15171C] border-[#C9A050]/70 shadow-lg'
                        : 'bg-[#121418] border-[#2A2D35] hover:border-[#444]'
                    }`}
                  >
                    <div
                      onClick={() => setExpandedGarmentId(isExpanded ? null : garment.id)}
                      className="p-3.5 flex flex-wrap items-center justify-between gap-3 cursor-pointer select-none"
                    >
                      <div className="flex items-center space-x-3">
                        <div
                          className="w-7 h-7 rounded-lg border border-[#2A2D35] shrink-0 shadow-xs"
                          style={{ backgroundColor: garment.color || '#1A1C22' }}
                        />
                        <div>
                          <div className="text-xs font-bold text-[#E0E0E0] flex items-center gap-2">
                            <span>{garment.name}</span>
                            <span className="text-[10px] px-2 py-0.5 rounded bg-[#1A1C22] border border-[#2A2D35] text-[#C9A050]">
                              #{index + 1}
                            </span>
                          </div>
                          <div className="text-[11px] text-[#888888] flex flex-wrap gap-x-2 gap-y-0.5 mt-0.5">
                            <span>Mat: <strong className="text-[#B0B0B0]">{garment.material}</strong></span>
                            <span>• Acabado: <strong className="text-[#B0B0B0]">{garment.finish || 'Estándar'}</strong></span>
                            {garment.details && garment.details.length > 0 && (
                              <span>• Detalles: <strong className="text-[#C9A050]">{garment.details.join(', ')}</strong></span>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2 text-xs font-semibold text-[#C9A050]">
                        <span>{isExpanded ? 'Cerrar Ajustes' : 'Ajustar Prenda'}</span>
                        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </div>
                    </div>

                    {isExpanded && (
                      <div className="p-4 border-t border-[#2A2D35] bg-[#0F1115] rounded-b-xl space-y-4 animate-fade-in">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                          <div>
                            <label className="block text-[11px] font-mono text-[#888888] mb-1">
                              Material de la Prenda
                            </label>
                            <select
                              value={garment.material}
                              onChange={e => handleUpdateSingleGarment(garment.id, { material: e.target.value })}
                              className="w-full bg-[#15171C] border border-[#2A2D35] rounded-lg p-2 text-xs text-[#E0E0E0] mb-2"
                            >
                              {combinedMaterials.map(m => (
                                <option key={m} value={m}>{m}</option>
                              ))}
                            </select>
                          </div>

                          <div>
                            <label className="block text-[11px] font-mono text-[#888888] mb-1">
                              Acabado Visual
                            </label>
                            <select
                              value={garment.finish}
                              onChange={e => handleUpdateSingleGarment(garment.id, { finish: e.target.value })}
                              className="w-full bg-[#15171C] border border-[#2A2D35] rounded-lg p-2 text-xs text-[#E0E0E0] mb-2"
                            >
                              {combinedFinishes.map(f => (
                                <option key={f} value={f}>{f}</option>
                              ))}
                            </select>
                          </div>

                          <div>
                            <label className="block text-[11px] font-mono text-[#888888] mb-1">
                              Color Base de la Prenda
                            </label>
                            <div className="flex items-center space-x-2 mb-2">
                              <input
                                type="color"
                                value={garment.color || '#1A1C22'}
                                onChange={e => handleUpdateSingleGarment(garment.id, { color: e.target.value })}
                                className="w-8 h-8 rounded border border-[#2A2D35] bg-transparent cursor-pointer"
                              />
                              <input
                                type="text"
                                value={garment.color || '#1A1C22'}
                                onChange={e => handleUpdateSingleGarment(garment.id, { color: e.target.value })}
                                className="flex-1 bg-[#15171C] border border-[#2A2D35] rounded-lg p-1.5 text-xs text-[#E0E0E0] font-mono"
                              />
                            </div>
                          </div>
                        </div>

                        <div>
                          <label className="block text-[11px] font-mono text-[#888888] mb-1.5">
                            Detalles y Adornos de Confección:
                          </label>
                          <div className="flex flex-wrap gap-1.5">
                            {[
                              'Bordados',
                              'Hebillas',
                              'Costuras',
                              'Encajes',
                              'Parches',
                              'Cinturones',
                              'Pliegues',
                              'Cremalleras',
                              'Cintas',
                              'Minimalista'
                            ].map(det => {
                              const active = garment.details.includes(det);
                              return (
                                <button
                                  key={det}
                                  onClick={() => handleToggleGarmentDetail(garment.id, det)}
                                  className={`px-2.5 py-1 rounded-lg text-xs border transition-all cursor-pointer ${
                                    active
                                      ? 'bg-[#C9A050] border-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                                      : 'bg-[#15171C] border-[#2A2D35] text-[#888888] hover:text-[#E0E0E0]'
                                  }`}
                                >
                                  {det} {active && '✓'}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-5 text-center text-xs text-[#888888]">
              No tienes prendas personalizadas en el Estado 3 (Vestuario). Puedes regresar a crearlas o continuar usando las piezas de indumentaria y armadura de rol.
            </div>
          )}
        </div>

        {/* ==================================================================== */}
        {/* SECTION 4.3: WEAPONS, RELICS, ITEMS & CONTAINERS                     */}
        {/* ==================================================================== */}
        <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs">
          <h3 className="text-lg font-serif italic text-[#C9A050] mb-4 flex items-center gap-2">
            <Sword className="w-5 h-5 text-[#C9A050]" />
            <span>4.3 Armamento, Objetos Personales & Contenedores</span>
          </h3>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Weapons / Utensils */}
            <div>
              <h4 className="text-sm font-bold text-[#C9A050] mb-2 flex items-center gap-1.5">
                <span>4.3.1 Armamento & Utensilios</span>
              </h4>

              {/* Role specific weapon suggestions */}
              {roleConfig.weapons.length > 0 && (
                <div className="mb-3 bg-[#15171C] p-3 rounded-xl border border-[#2A2D35]">
                  <div className="text-[10px] text-[#C9A050] font-mono mb-2">
                    ★ Sugeridas para {currentRoleName}:
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {roleConfig.weapons.map(rw => {
                      const active = state.equipment.weapons.includes(rw);
                      return (
                        <button
                          key={rw}
                          onClick={() => handleArrayToggle('weapons', rw)}
                          className={`px-3 py-1.5 rounded-lg text-xs border transition-all cursor-pointer ${
                            active
                              ? 'bg-[#C9A050] border-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                              : 'bg-[#1A1C22] border-[#C9A050]/40 text-[#E0E0E0] hover:border-[#C9A050]'
                          }`}
                        >
                          {rw} {active && '✓'}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* General weapons catalog */}
              <div className="flex flex-wrap gap-1.5 mb-4">
                {WEAPONS_LIST.map(w => {
                  const active = state.equipment.weapons.includes(w);
                  return (
                    <button
                      key={w}
                      onClick={() => handleArrayToggle('weapons', w)}
                      className={`px-2 py-1 rounded text-[11px] border transition-all cursor-pointer ${
                        active
                          ? 'bg-[#1A1C22] border-[#C9A050] text-[#C9A050] font-bold shadow-xs'
                          : 'bg-[#15171C] border-[#2A2D35] text-[#888888] hover:text-[#E0E0E0]'
                      }`}
                    >
                      {w} {active && '✓'}
                    </button>
                  );
                })}
              </div>

              <h4 className="text-xs font-mono text-[#888888] mb-2">Empuñaduras Especiales</h4>
              <div className="flex flex-wrap gap-2">
                {WEAPONS_GRIPS.map(h => {
                  const active = state.equipment.weaponGrips.includes(h);
                  return (
                    <button
                      key={h}
                      onClick={() => handleArrayToggle('weaponGrips', h)}
                      className={`px-2 py-1 rounded text-[11px] border transition-all cursor-pointer ${
                        active
                          ? 'bg-[#1A1C22] border-[#C9A050] text-[#C9A050] font-bold'
                          : 'bg-[#15171C] border-[#2A2D35] text-[#888888]'
                      }`}
                    >
                      {h}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Relics, Items and Bags */}
            <div>
              <h4 className="text-sm font-bold text-[#C9A050] mb-2">4.3.2 Reliquias & Objetos de Rol</h4>
              {roleConfig.relicsAndItems.length > 0 && (
                <div className="mb-3 bg-[#15171C] p-3 rounded-xl border border-[#2A2D35]">
                  <div className="text-[10px] text-[#C9A050] font-mono mb-2">
                    ★ Objetos y Reliquias de {currentRoleName}:
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {roleConfig.relicsAndItems.map(ri => {
                      const active = state.equipment.items.includes(ri);
                      return (
                        <button
                          key={ri}
                          onClick={() => handleArrayToggle('items', ri)}
                          className={`px-3 py-1.5 rounded-lg text-xs border transition-all cursor-pointer ${
                            active
                              ? 'bg-[#C9A050] border-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                              : 'bg-[#1A1C22] border-[#C9A050]/40 text-[#E0E0E0] hover:border-[#C9A050]'
                          }`}
                        >
                          {ri} {active && '✓'}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              <div className="flex flex-wrap gap-1.5 mb-4">
                {ITEMS_LIST.map(i => {
                  const active = state.equipment.items.includes(i);
                  return (
                    <button
                      key={i}
                      onClick={() => handleArrayToggle('items', i)}
                      className={`px-2 py-1 rounded text-[11px] border transition-all cursor-pointer ${
                        active
                          ? 'bg-[#1A1C22] border-[#C9A050] text-[#C9A050] font-bold'
                          : 'bg-[#15171C] border-[#2A2D35] text-[#888888]'
                      }`}
                    >
                      {i} {active && '✓'}
                    </button>
                  );
                })}
              </div>

              {/* Bags and Containers */}
              <h4 className="text-sm font-bold text-[#C9A050] mb-2">4.3.3 Bolsas & Contenedores</h4>
              {roleConfig.bags.length > 0 && (
                <div className="mb-3 bg-[#15171C] p-3 rounded-xl border border-[#2A2D35]">
                  <div className="text-[10px] text-[#C9A050] font-mono mb-2">
                    ★ Contenedores Típicos de {currentRoleName}:
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {roleConfig.bags.map(rb => {
                      const active = state.equipment.bags.includes(rb);
                      return (
                        <button
                          key={rb}
                          onClick={() => handleArrayToggle('bags', rb)}
                          className={`px-3 py-1.5 rounded-lg text-xs border transition-all cursor-pointer ${
                            active
                              ? 'bg-[#C9A050] border-[#C9A050] text-[#0A0B0E] font-bold'
                              : 'bg-[#1A1C22] border-[#C9A050]/40 text-[#E0E0E0]'
                          }`}
                        >
                          {rb} {active && '✓'}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              <div className="flex flex-wrap gap-1.5 mb-4">
                {BAGS_LIST.map(b => {
                  const active = state.equipment.bags.includes(b);
                  return (
                    <button
                      key={b}
                      onClick={() => handleArrayToggle('bags', b)}
                      className={`px-2 py-1 rounded text-[11px] border transition-all cursor-pointer ${
                        active
                          ? 'bg-[#1A1C22] border-[#C9A050] text-[#C9A050] font-bold'
                          : 'bg-[#15171C] border-[#2A2D35] text-[#888888]'
                      }`}
                    >
                      {b} {active && '✓'}
                    </button>
                  );
                })}
              </div>

              <div className="flex gap-4">
                <div className="flex-1">
                  <h4 className="text-xs font-mono text-[#888888] mb-1.5">Tamaño</h4>
                  <div className="flex flex-wrap gap-1">
                    {BAGS_SIZES.map(z => {
                      const active = state.equipment.bagSizes.includes(z);
                      return (
                        <button
                          key={z}
                          onClick={() => handleArrayToggle('bagSizes', z)}
                          className={`px-2 py-1 rounded text-[10px] border cursor-pointer ${
                            active
                              ? 'bg-[#1A1C22] border-[#C9A050] text-[#C9A050]'
                              : 'bg-[#15171C] border-[#2A2D35] text-[#888888]'
                          }`}
                        >
                          {z}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="flex-1">
                  <h4 className="text-xs font-mono text-[#888888] mb-1.5">Cierre</h4>
                  <div className="flex flex-wrap gap-1">
                    {BAGS_CLOSURES.map(c => {
                      const active = state.equipment.bagClosures.includes(c);
                      return (
                        <button
                          key={c}
                          onClick={() => handleArrayToggle('bagClosures', c)}
                          className={`px-2 py-1 rounded text-[10px] border cursor-pointer ${
                            active
                              ? 'bg-[#1A1C22] border-[#C9A050] text-[#C9A050]'
                              : 'bg-[#15171C] border-[#2A2D35] text-[#888888]'
                          }`}
                        >
                          {c}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* 4.3.4 Detailed Equipment Piece Modifiers */}
          <div className="mt-8 pt-6 border-t border-[#2A2D35]">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
              <div>
                <h4 className="text-sm font-semibold text-[#E0E0E0] flex items-center gap-2">
                  <Palette className="w-4 h-4 text-[#C9A050]" />
                  <span>4.3.4 Ajustes Individuales de Armas, Reliquias y Contenedores</span>
                </h4>
                <p className="text-[11px] text-[#888888] mt-0.5">
                  Personaliza el color, material, acabado superficial, tamaño y detalles físicos específicos de cada arma o accesorio.
                </p>
              </div>
            </div>

            {(() => {
              const allSelectedEquipment = [
                ...(state.equipment.weapons || []).map(w => ({ id: w, name: w, cat: 'Arma' })),
                ...(state.equipment.items || []).map(i => ({ id: i, name: i, cat: 'Reliquia / Objeto' })),
                ...(state.equipment.bags || []).map(b => ({ id: b, name: b, cat: 'Bolsa / Contenedor' }))
              ];

              if (allSelectedEquipment.length === 0) {
                return (
                  <div className="bg-[#15171C]/60 border border-dashed border-[#2A2D35] rounded-xl p-6 text-center">
                    <Package className="w-8 h-8 text-[#555] mx-auto mb-2 opacity-50" />
                    <div className="text-xs text-[#888888]">
                      No has seleccionado ninguna arma, reliquia o bolsa todavía.
                    </div>
                  </div>
                );
              }

              return (
                <div className="space-y-4">
                  {allSelectedEquipment.map(eq => {
                    const detail = state.equipment.equipmentDetails?.[eq.id] || {
                      id: eq.id,
                      name: eq.name,
                      category: 'item',
                      color: roleConfig.suggestedColors[0]?.hex || '#C9A050',
                      material: roleConfig.materials[0] || GENERAL_ROLE_MATERIALS[0],
                      finish: roleConfig.finishes[0] || GENERAL_ROLE_FINISHES[0],
                      sizeOrLength: 'Estándar',
                      detail: ''
                    };

                    return (
                      <div
                        key={eq.id}
                        className="bg-[#15171C] rounded-xl p-4 border border-[#2A2D35] hover:border-[#3A3E48] transition-all"
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2 pb-3 mb-3 border-b border-[#2A2D35]/50">
                          <div className="flex items-center space-x-2">
                            <span
                              className="w-3.5 h-3.5 rounded-full border border-[#444] shrink-0"
                              style={{ backgroundColor: detail.color || '#C9A050' }}
                            />
                            <span className="text-xs font-bold text-[#E0E0E0]">
                              {eq.name}
                            </span>
                            <span className="text-[10px] font-mono bg-[#0F1115] text-[#C9A050] border border-[#C9A050]/30 px-2 py-0.5 rounded">
                              {eq.cat}
                            </span>
                          </div>

                          <button
                            type="button"
                            onClick={() => {
                              if (state.equipment.weapons.includes(eq.id)) handleArrayToggle('weapons', eq.id);
                              else if (state.equipment.items.includes(eq.id)) handleArrayToggle('items', eq.id);
                              else if (state.equipment.bags.includes(eq.id)) handleArrayToggle('bags', eq.id);
                            }}
                            className="text-[11px] text-red-400 hover:text-red-300 px-2 py-0.5 rounded bg-[#0F1115] border border-red-900/40 cursor-pointer"
                          >
                            Quitar
                          </button>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                          {/* 1. Color */}
                          <div className="space-y-1.5">
                            <label className="block text-[11px] font-mono text-[#888888]">
                              Color del Objeto
                            </label>
                            <div className="flex items-center gap-2">
                              <input
                                type="color"
                                value={detail.color && detail.color.startsWith('#') ? detail.color : '#C9A050'}
                                onChange={e => handleUpdateEquipmentDetail(eq.id, { color: e.target.value })}
                                className="w-7 h-7 rounded border border-[#2A2D35] cursor-pointer bg-transparent"
                              />
                              <input
                                type="text"
                                value={detail.color || ''}
                                onChange={e => handleUpdateEquipmentDetail(eq.id, { color: e.target.value })}
                                placeholder="#C9A050"
                                className="flex-1 bg-[#0F1115] border border-[#2A2D35] rounded-xl px-2.5 py-1 text-xs text-[#E0E0E0] font-mono"
                              />
                            </div>
                          </div>

                          {/* 2. Material */}
                          <div className="space-y-1.5">
                            <label className="block text-[11px] font-mono text-[#888888]">
                              Material
                            </label>
                            <select
                              value={detail.material || roleConfig.materials[0]}
                              onChange={e => handleUpdateEquipmentDetail(eq.id, { material: e.target.value })}
                              className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-1.5 text-xs text-[#E0E0E0]"
                            >
                              {combinedMaterials.map(m => (
                                <option key={m} value={m}>{m}</option>
                              ))}
                            </select>
                          </div>

                          {/* 3. Finish */}
                          <div className="space-y-1.5">
                            <label className="block text-[11px] font-mono text-[#888888]">
                              Acabado / Textura
                            </label>
                            <select
                              value={detail.finish || roleConfig.finishes[0]}
                              onChange={e => handleUpdateEquipmentDetail(eq.id, { finish: e.target.value })}
                              className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl p-1.5 text-xs text-[#E0E0E0]"
                            >
                              {combinedFinishes.map(f => (
                                <option key={f} value={f}>{f}</option>
                              ))}
                            </select>
                          </div>

                          {/* 4. Size or Length */}
                          <div className="space-y-1.5">
                            <label className="block text-[11px] font-mono text-[#888888]">
                              Tamaño / Extensión
                            </label>
                            <input
                              type="text"
                              value={detail.sizeOrLength || ''}
                              onChange={e => handleUpdateEquipmentDetail(eq.id, { sizeOrLength: e.target.value })}
                              placeholder="Ej. Compacto, Largo (120cm)..."
                              className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl px-2.5 py-1 text-xs text-[#E0E0E0]"
                            />
                          </div>

                          {/* 5. Specific Physical Detail */}
                          <div className="md:col-span-2 lg:col-span-4 space-y-2">
                            <label className="block text-[11px] font-mono text-[#888888]">
                              Detalle / Adorno Físico Concreto ({eq.cat})
                            </label>
                            <input
                              type="text"
                              value={detail.detail || ''}
                              onChange={e => handleUpdateEquipmentDetail(eq.id, { detail: e.target.value })}
                              placeholder={
                                eq.cat === 'Arma'
                                  ? 'Ej. Filo dentado con runas élficas de escarcha y empuñadura de cordón de seda...'
                                  : eq.cat === 'Bolsa / Contenedor'
                                  ? 'Ej. Hebillas de latón bruñido con refuerzo de remaches y triple compartimento...'
                                  : 'Ej. Engaste de zafiro estelar con filigrana de plata y runas de protección...'
                              }
                              className="w-full bg-[#0F1115] border border-[#2A2D35] rounded-xl px-3 py-1.5 text-xs text-[#E0E0E0] placeholder-[#555]"
                            />

                            {/* Contextual Suggestions Chips */}
                            <div className="pt-1">
                              <span className="text-[10px] text-[#777777] font-mono block mb-1">
                                Opciones Rápidas Sugeridas para {eq.cat}:
                              </span>
                              <div className="flex flex-wrap gap-1.5">
                                {(eq.cat === 'Arma'
                                  ? [
                                      'Filo Ancho con Muescas de Batalla',
                                      'Guarda Cruzada de Acero Macizo Esculpido',
                                      'Empuñadura Larga Envuelta en Cuero',
                                      'Portado al Hombro o Espalda con Tahalí',
                                      'Filo Biselado Espejo',
                                      'Runas Grabadas en la Hoja',
                                      'Guarda en Cruz Ornamentada',
                                      'Pomo con Piedra de Poder',
                                      'Empuñadura de Cuero Encordado',
                                      'Aura Elemental Ardiente',
                                      'Vaina de Madera Lacada',
                                      'Funda con Broches de Cuero'
                                    ]
                                  : eq.cat === 'Bolsa / Contenedor'
                                  ? [
                                      'Hebillas de Bronce Antiguo',
                                      'Costuras Reforzadas de Hilo Encerado',
                                      'Bolsillo Oculto Interior',
                                      'Correa Cruzada Ajustable',
                                      'Cierre de Cordón con Borla',
                                      'Remaches de Acero Templado',
                                      'Emblema de Gremio Grabado'
                                    ]
                                  : [
                                      'Gema Engarzada en Filigrana',
                                      'Cadena de Eslabones Finos',
                                      'Inscripciones Arcanas Brillantes',
                                      'Patina Envejecida y Reliquia',
                                      'Sello Mágico de Contención',
                                      'Piedra Lunar Reflectante'
                                    ]
                                ).map(sug => {
                                  const isActive = (detail.detail || '').includes(sug);
                                  return (
                                    <button
                                      key={sug}
                                      type="button"
                                      onClick={() => {
                                        const current = detail.detail || '';
                                        let updated;
                                        if (current.includes(sug)) {
                                          updated = current.replace(sug, '').replace(/,\s*,/g, ',').replace(/^,\s*|,\s*$/g, '').trim();
                                        } else {
                                          updated = current ? `${current}, ${sug}` : sug;
                                        }
                                        handleUpdateEquipmentDetail(eq.id, { detail: updated });
                                      }}
                                      className={`px-2 py-0.5 rounded text-[10px] border transition-all cursor-pointer ${
                                        isActive
                                          ? 'bg-[#C9A050] text-[#0A0B0E] font-bold border-[#C9A050]'
                                          : 'bg-[#0F1115] text-[#888888] border-[#2A2D35] hover:text-[#CCC]'
                                      }`}
                                    >
                                      {sug} {isActive && '✓'}
                                    </button>
                                  );
                                })}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              );
            })()}
          </div>
        </div>
      </div>

      {/* Navigation Buttons */}
      <div className="mt-10 flex justify-between">
        <button
          onClick={onBack}
          className="bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] text-[#E0E0E0] px-6 py-3 rounded-xl font-semibold text-sm flex items-center space-x-2 transition-all cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Anterior (Estado 3: Vestuario)</span>
        </button>

        <button
          onClick={onNext}
          className="bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] px-6 py-3 rounded-xl font-semibold text-sm flex items-center space-x-2 transition-all shadow-md cursor-pointer"
        >
          <span>Siguiente: Trasfondo e Historia</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
