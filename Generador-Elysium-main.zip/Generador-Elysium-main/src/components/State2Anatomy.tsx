import React, { useState, useMemo } from 'react';
import { CharacterState } from '../types';
import {
  SEX_BASES, AGES, COMPLEXIONS, HEIGHTS, BREAST_DEV, SKIN_COLORS, WAISTS, GLUTES, THIGHS,
  HEAD_SHAPES, HEAD_WIDTHS, BONE_STRUCTURES, EYE_COLORS,
  EYES_CATEGORIES, EYES_SUBTYPES, EYELINERS, SHADOWS, EXPRESSIONS, IRIS_TYPES,
  NOSES, LIPS, MOUTH_EXPS, MOUTH_SPECIALS, TEETHS, MOUTH_CORNERS, MOUTH_TEXTURES,
  EARS_BASES, EARS_LENGTHS, KEMONO_EARS,
  FACIAL_HAIR_OPTIONS, FACIAL_HAIR_COLORS,
  HAIR_TEXTURES, HAIR_LENGTHS, HAIR_CUTS, HAIR_PARTS, HAIR_BANGS, HAIR_STYLES, HAIR_COLORS,
  HORNS_FORMS, HORNS_LENGTHS, HORNS_THICKNESSES, HORNS_POSITIONS,
  WINGS_SIZES, WINGS_POSITIONS, WINGS_TYPES,
  TAILS_TYPES, TAILS_LENGTHS, TAILS_FINISHES, TAILS_COLORS,
  SKIN_AND_MARKS, MARK_TYPES, MARK_SHAPES, MARK_LOCATIONS, MARK_COLORS, getMarkTypeConfig, ANATOMY_DESCRIPTIONS,
  SCLERA_COLORS, FACIAL_MORPHOLOGIES, LOWER_BODY_STRUCTURES, CHEST_CORES, NECK_FEATURES, HAIR_ELEMENTALS,
  ANTENNAE_TYPES, ANTENNAE_LENGTHS, ANTENNAE_POSITIONS, EXTRA_EYES_OPTIONS, EXTRA_ARMS_OPTIONS, SPECIAL_LIMBS_OPTIONS,
  PUPIL_SHAPES, TONGUE_TYPES, MARK_FINISHES, CLAWS_TYPES, PAW_PADS_OPTIONS
} from '../data';
import { BODY_PRESETS, FACIAL_PRESETS, HAIR_PRESETS, APPENDICES_PRESETS } from '../data/anatomyPresetsEngine';
import { Sparkles, ArrowRight, ArrowLeft, User, Eye, Scissors, ShieldAlert, Palette, Check, Flame, Heart, Lock, Unlock, Trash2, Plus, X, RotateCcw, MapPin, Tag } from 'lucide-react';
import { InfoTooltip } from './ui/InfoTooltip';
import { EyeColorCustomizer } from './color/EyeColorCustomizer';
import { HairColorCustomizer } from './color/HairColorCustomizer';
import { MakeupCustomizer } from './makeup/MakeupCustomizer';
import { CalligraphyTextInput } from './common/CalligraphyTextInput';
import { LogoSealEmblemBuilder } from './common/LogoSealEmblemBuilder';
import { isCalligraphyOrTextOption, isLogoShieldOrSealOption } from '../utils/emblemTextDetectors';
import {
  AREOLA_COLORS,
  AREOLA_SIZES,
  NIPPLE_TYPES,
  PUBIC_HAIR_STYLES,
  BODY_SENSITIVITIES,
  GENITAL_TYPES,
  GENITAL_SIZES,
  GENITAL_DETAILS
} from '../data/nsfwData';

interface State2Props {
  state: CharacterState;
  setState: React.Dispatch<React.SetStateAction<CharacterState>>;
  onNext: () => void;
  onBack: () => void;
}

const matchBreastDevOption = (val?: string): string => {
  if (!val) return BREAST_DEV[0];
  if (BREAST_DEV.includes(val)) return val;
  const v = val.toLowerCase().trim();
  if (v.startsWith('a') || v.includes('incipiente') || v.includes('plano') || v.includes('copa aa')) return BREAST_DEV[0];
  if (v.startsWith('b') || v.includes('pequeño') || v.includes('pequeno') || v.includes('copa a')) return BREAST_DEV[1];
  if (v.startsWith('c') || v.includes('medio') || v.includes('mediano') || v.includes('copa b')) return BREAST_DEV[2];
  if (v.startsWith('d') || v.includes('prominente') || v.includes('voluminoso') || v.includes('copa d')) return BREAST_DEV[3];
  if (v.startsWith('e') || v.includes('abundante') || v.includes('copa dd') || v.includes('copa e')) return BREAST_DEV[4];
  if (v.startsWith('f') || v.includes('enorme') || v.includes('hipertrófico') || v.includes('hipertrofico') || v.includes('colosal') || v.includes('copa f')) return BREAST_DEV[5];
  return val;
};

const matchSexBaseOption = (val?: string): string => {
  if (!val) return SEX_BASES[0];
  if (SEX_BASES.includes(val)) return val;
  const v = val.toLowerCase().trim();
  if (v.includes('trans')) return '4 Hombre (mujer trans-sexual)';
  if (v.startsWith('1') || v.includes('hombre') || v.includes('masculino')) return '1 Hombre';
  if (v.startsWith('2') || v.includes('mujer') || v.includes('femenino')) return '2 Mujer';
  if (v.startsWith('3') || v.includes('andrógino') || v.includes('androgino')) return '3 Andrógino';
  return val;
};

export const State2Anatomy: React.FC<State2Props> = ({ state, setState, onNext, onBack }) => {
  const [subTab, setSubTab] = useState<'anatomy' | 'facial' | 'hair' | 'appendices' | 'makeup' | 'intimate'>('anatomy');
  const [genitalFilter, setGenitalFilter] = useState<'Auto' | 'Femenino' | 'Masculino' | 'Fantasía / Andrógino' | 'Todos'>('Auto');

  const defaultGenitalType = useMemo(() => {
    const sex = (state.anatomy?.sexBase || '').toLowerCase();
    if (sex.includes('trans')) {
      return GENITAL_TYPES[0].name;
    }
    if (sex.includes('hombre')) {
      return GENITAL_TYPES.find(g => g.category === 'Masculino')?.name || GENITAL_TYPES[4].name;
    }
    if (sex.includes('andrógino') || sex.includes('androgino')) {
      return GENITAL_TYPES.find(g => g.category === 'Fantasía / Andrógino')?.name || GENITAL_TYPES[8].name;
    }
    return GENITAL_TYPES[0].name;
  }, [state.anatomy?.sexBase]);

  const filteredGenitalTypes = useMemo(() => {
    if (genitalFilter === 'Todos') return GENITAL_TYPES;
    if (genitalFilter === 'Auto') {
      const sex = (state.anatomy?.sexBase || '').toLowerCase();
      if (sex.includes('trans')) {
        return GENITAL_TYPES;
      }
      if (sex.includes('hombre')) {
        return GENITAL_TYPES.filter(g => g.category === 'Masculino' || g.category === 'Fantasía / Andrógino');
      }
      if (sex.includes('andrógino') || sex.includes('androgino')) {
        return GENITAL_TYPES;
      }
      return GENITAL_TYPES.filter(g => g.category === 'Femenino' || g.category === 'Fantasía / Andrógino');
    }
    return GENITAL_TYPES.filter(g => g.category === genitalFilter);
  }, [genitalFilter, state.anatomy?.sexBase]);

  const selectedGenitalDetails: string[] = useMemo(() => {
    const raw = state.nsfw?.genitalDetails;
    if (Array.isArray(raw)) return raw;
    if (typeof raw === 'string' && raw.trim()) return [raw];
    return [GENITAL_DETAILS[0].name];
  }, [state.nsfw?.genitalDetails]);

  const toggleGenitalDetail = (detailName: string) => {
    const current = selectedGenitalDetails;
    let next: string[];
    if (current.includes(detailName)) {
      next = current.filter(d => d !== detailName);
    } else {
      next = [...current, detailName];
    }
    updateNsfw('genitalDetails', next);
  };

  const updateNsfw = (k: string, val: any) => {
    setState(prev => ({
      ...prev,
      nsfw: {
        isNsfwEnabled: true,
        areolaColor: prev.nsfw?.areolaColor || AREOLA_COLORS[0].name,
        areolaSize: prev.nsfw?.areolaSize || AREOLA_SIZES[0].name,
        nippleType: prev.nsfw?.nippleType || NIPPLE_TYPES[0].name,
        pubicHairStyle: prev.nsfw?.pubicHairStyle || PUBIC_HAIR_STYLES[0].name,
        bodySensitivities: prev.nsfw?.bodySensitivities || [BODY_SENSITIVITIES[0].id],
        genitalType: prev.nsfw?.genitalType || defaultGenitalType,
        genitalSize: prev.nsfw?.genitalSize || GENITAL_SIZES[1].name,
        genitalDetails: prev.nsfw?.genitalDetails
          ? (Array.isArray(prev.nsfw.genitalDetails) ? prev.nsfw.genitalDetails : [prev.nsfw.genitalDetails])
          : [GENITAL_DETAILS[0].name],
        intimatePersonality: prev.nsfw?.intimatePersonality !== undefined ? prev.nsfw.intimatePersonality : '',
        explicitLingerie: prev.nsfw?.explicitLingerie || [],
        ...prev.nsfw,
        [k]: val
      }
    }));
  };

  const toggleNsfw = (enable?: boolean) => {
    const nextVal = enable !== undefined ? enable : !state.nsfw?.isNsfwEnabled;
    setState(prev => ({
      ...prev,
      nsfw: {
        areolaColor: prev.nsfw?.areolaColor || AREOLA_COLORS[0].name,
        areolaSize: prev.nsfw?.areolaSize || AREOLA_SIZES[0].name,
        nippleType: prev.nsfw?.nippleType || NIPPLE_TYPES[0].name,
        pubicHairStyle: prev.nsfw?.pubicHairStyle || PUBIC_HAIR_STYLES[0].name,
        bodySensitivities: prev.nsfw?.bodySensitivities || [BODY_SENSITIVITIES[0].id],
        genitalType: prev.nsfw?.genitalType || defaultGenitalType,
        genitalSize: prev.nsfw?.genitalSize || GENITAL_SIZES[1].name,
        genitalDetails: prev.nsfw?.genitalDetails
          ? (Array.isArray(prev.nsfw.genitalDetails) ? prev.nsfw.genitalDetails : [prev.nsfw.genitalDetails])
          : [GENITAL_DETAILS[0].name],
        intimatePersonality: prev.nsfw?.intimatePersonality !== undefined ? prev.nsfw.intimatePersonality : '',
        explicitLingerie: prev.nsfw?.explicitLingerie || [],
        ...prev.nsfw,
        isNsfwEnabled: nextVal
      }
    }));
  };

  const updateAnat = (k: keyof CharacterState['anatomy'], val: string) => {
    setState(prev => ({ ...prev, anatomy: { ...prev.anatomy, [k]: val } }));
  };

  const updateFacial = (k: keyof CharacterState['facial'], val: any) => {
    setState(prev => {
      const newFacial = { ...prev.facial, [k]: val };
      if (k === 'eyesCategory') {
        const prefix = val.charAt(0);
        const validSubtypes = EYES_SUBTYPES.filter(s => s.startsWith(prefix));
        newFacial.eyesSubtype = validSubtypes[0] || '';
      }
      return { ...prev, facial: newFacial };
    });
  };

  const updateHair = (k: keyof CharacterState['hair'], val: string) => {
    setState(prev => ({ ...prev, hair: { ...prev.hair, [k]: val } }));
  };

  const updateApp = (k: keyof CharacterState['appendices'], val: any) => {
    setState(prev => ({ ...prev, appendices: { ...prev.appendices, [k]: val } }));
  };

  const updateAppendices = (updates: Partial<CharacterState['appendices']>) => {
    setState(prev => ({ ...prev, appendices: { ...prev.appendices, ...updates } }));
  };

  const [markLocationZones, setMarkLocationZones] = useState<Record<string, string>>({});
  const [openTextForMarks, setOpenTextForMarks] = useState<Record<string, boolean>>({});
  const [openEmblemForMarks, setOpenEmblemForMarks] = useState<Record<string, boolean>>({});

  const getDefaultLocationsForMark = (markName: string): string[] => {
    const m = markName.toLowerCase();
    if (m.includes('lunar') || m.includes('nacimiento')) {
      return ['Rostro: Mejilla Derecha'];
    }
    if (m.includes('cicatriz')) {
      return ['Rostro: Mejilla Izquierda'];
    }
    if (m.includes('yakuza') || m.includes('irezumi')) {
      return ['Espalda: Espalda Completa'];
    }
    if (m.includes('maquillaje') || m.includes('pintura')) {
      return ['Rostro: Frente (Centro)'];
    }
    if (m.includes('circuito') || m.includes('cibernétic')) {
      return ['Brazos: Antebrazo Derecho'];
    }
    if (m.includes('sello') || m.includes('runa')) {
      return ['Torso: Pecho (Sobre el Corazón)'];
    }
    if (m.includes('cristal') || m.includes('escama')) {
      return ['Brazos: Brazo Derecho Completo'];
    }
    if (m.includes('vena') || m.includes('infección')) {
      return ['Cuello: Lado Derecho'];
    }
    if (m.includes('vitíligo') || m.includes('manchas')) {
      return ['Torso: Clavícula Derecha'];
    }
    return ['Torso: Pecho (Centro)'];
  };

  const MARK_LOCATION_ZONES: { label: string; filter: (loc: string) => boolean }[] = [
    { label: 'Todas', filter: () => true },
    { label: 'Rostro', filter: l => l.startsWith('Rostro:') },
    { label: 'Cuello', filter: l => l.startsWith('Cuello:') },
    { label: 'Torso', filter: l => l.startsWith('Torso:') },
    { label: 'Espalda', filter: l => l.startsWith('Espalda:') },
    { label: 'Brazos', filter: l => l.startsWith('Brazos:') },
    { label: 'Piernas', filter: l => l.startsWith('Piernas:') },
    { label: 'Pelvis / Glúteos', filter: l => l.startsWith('Pelvis') || l.startsWith('Glúteos') },
    { label: 'General / Accesorios', filter: l => l.startsWith('General:') || l.startsWith('Accesorio:') }
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      {/* Header banner */}
      <div className="bg-[#0F1115] border border-[#222222] rounded-3xl p-8 text-[#E0E0E0] shadow-xl mb-8 relative">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-[#1A1C22] border border-[#2A2D35] text-[#C9A050] text-xs font-medium mb-4">
          <Sparkles className="w-3.5 h-3.5 text-[#C9A050]" />
          <span>ESTADO 2: ANATOMÍA, FACIAL Y APÉNDICES</span>
        </div>
        <h2 className="text-3xl font-serif italic text-[#C9A050] tracking-tight mb-2">
          Modelado Corporal, Facial y Apéndices
        </h2>
        <p className="text-[#888888] text-sm leading-relaxed">
          Configura los ejes anatómicos, proporciones, rasgos faciales, cabello y apéndices raciales con precisión determinista V7.4.
        </p>

        {/* Subtab buttons */}
        <div className="flex items-center justify-between flex-wrap gap-3 mt-6 pt-6 border-t border-[#222222]">
          <div className="flex flex-wrap gap-2">
            <button onClick={() => setSubTab('anatomy')} className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${subTab === 'anatomy' ? 'bg-[#1A1C22] text-[#C9A050] border border-[#2A2D35]' : 'bg-[#15171C] text-[#888888]'}`}>
              <User className="w-3.5 h-3.5" />
              <span>2.1 Anatomía</span>
            </button>
            <button onClick={() => setSubTab('facial')} className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${subTab === 'facial' ? 'bg-[#1A1C22] text-[#C9A050] border border-[#2A2D35]' : 'bg-[#15171C] text-[#888888]'}`}>
              <Eye className="w-3.5 h-3.5" />
              <span>2.2 Facial & Ojos</span>
            </button>
            <button onClick={() => setSubTab('hair')} className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${subTab === 'hair' ? 'bg-[#1A1C22] text-[#C9A050] border border-[#2A2D35]' : 'bg-[#15171C] text-[#888888]'}`}>
              <Scissors className="w-3.5 h-3.5" />
              <span>2.3 Cabello</span>
            </button>
            <button onClick={() => setSubTab('appendices')} className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${subTab === 'appendices' ? 'bg-[#1A1C22] text-[#C9A050] border border-[#2A2D35]' : 'bg-[#15171C] text-[#888888]'}`}>
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>2.4 Apéndices & Piel</span>
            </button>
            <button onClick={() => setSubTab('makeup')} className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center space-x-1.5 ${subTab === 'makeup' ? 'bg-[#1A1C22] text-[#C9A050] border border-[#2A2D35]' : 'bg-[#15171C] text-[#888888]'}`}>
              <Palette className="w-3.5 h-3.5" />
              <span>2.5 Maquillaje & Uñas</span>
            </button>
            <button 
              onClick={() => {
                setSubTab('intimate');
                if (!state.nsfw?.isNsfwEnabled) toggleNsfw(true);
              }} 
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center space-x-1.5 ${
                subTab === 'intimate' 
                  ? 'bg-rose-950/70 text-rose-300 border border-rose-600/70 shadow-sm' 
                  : state.nsfw?.isNsfwEnabled 
                    ? 'bg-[#1c1418] text-rose-300/80 border border-rose-900/40 hover:text-rose-200' 
                    : 'bg-[#15171C] text-[#888888] hover:text-rose-400'
              }`}
            >
              <Flame className={`w-3.5 h-3.5 ${state.nsfw?.isNsfwEnabled ? 'text-rose-400 fill-current' : 'text-zinc-500'}`} />
              <span>2.6 Anatomía Íntima (R+18)</span>
              {state.nsfw?.isNsfwEnabled && (
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
              )}
            </button>
          </div>

          {/* Quick R+18 Toggle Switch */}
          <button
            type="button"
            onClick={() => toggleNsfw()}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold border transition-all flex items-center gap-2 cursor-pointer ${
              state.nsfw?.isNsfwEnabled
                ? 'bg-rose-950/70 border-rose-600 text-rose-300 hover:bg-rose-900/80 shadow-md shadow-rose-950/40'
                : 'bg-[#15171C] border-[#2A2D35] text-[#888888] hover:text-[#C9A050] hover:border-[#C9A050]/50'
            }`}
          >
            <Flame className={`w-4 h-4 ${state.nsfw?.isNsfwEnabled ? 'text-rose-400 fill-current' : 'text-zinc-500'}`} />
            <span>Modo R+18: {state.nsfw?.isNsfwEnabled ? 'HABILITADO' : 'DESACTIVADO'}</span>
          </button>
        </div>
      </div>

      {subTab === 'anatomy' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Quick Body Presets */}
          <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-mono font-bold text-[#C9A050] uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#C9A050]" />
                Arquetipos Corporales Rápidos (1-Click)
              </h3>
              <span className="text-[11px] text-[#777777]">Aplica proporciones y siluetas clave al instante</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
              {BODY_PRESETS.map(preset => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => {
                    setState(prev => ({
                      ...prev,
                      anatomy: {
                        ...prev.anatomy,
                        ...preset.anatomy
                      }
                    }));
                  }}
                  className="text-left bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050]/50 rounded-xl p-3 transition-all cursor-pointer group"
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-[#E0E0E0] group-hover:text-[#C9A050] transition-colors">
                      {preset.name}
                    </span>
                    <span className="text-[9px] font-mono text-[#888888] bg-[#0F1115] px-1.5 py-0.5 rounded border border-[#222222]">
                      {preset.category}
                    </span>
                  </div>
                  <p className="text-[11px] text-[#888888] line-clamp-2 leading-tight">
                    {preset.description}
                  </p>
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs">
              <h3 className="text-sm font-bold text-[#C9A050] mb-3">
                A.2.1.1 Sexo Base
                {(ANATOMY_DESCRIPTIONS[matchSexBaseOption(state.anatomy.sexBase)] || ANATOMY_DESCRIPTIONS[state.anatomy.sexBase]) && (
                  <InfoTooltip text={ANATOMY_DESCRIPTIONS[matchSexBaseOption(state.anatomy.sexBase)] || ANATOMY_DESCRIPTIONS[state.anatomy.sexBase]} />
                )}
              </h3>
              <select
                value={matchSexBaseOption(state.anatomy.sexBase)}
                onChange={(e) => updateAnat('sexBase', e.target.value)}
                className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-3 text-sm text-[#E0E0E0]"
              >
                {SEX_BASES.map(o => <option key={o} value={o}>{o}</option>)}
                {state.anatomy.sexBase && !SEX_BASES.includes(matchSexBaseOption(state.anatomy.sexBase)) && (
                  <option value={state.anatomy.sexBase}>{state.anatomy.sexBase}</option>
                )}
              </select>
            </div>
            <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs">
              <h3 className="text-sm font-bold text-[#C9A050] mb-3">
                A.2.1.2 Edad
                {ANATOMY_DESCRIPTIONS[state.anatomy.age] && (
                  <InfoTooltip text={ANATOMY_DESCRIPTIONS[state.anatomy.age]} />
                )}
              </h3>
              <select value={state.anatomy.age} onChange={(e) => updateAnat('age', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-3 text-sm text-[#E0E0E0]">
                {AGES.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>

            <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs">
              <h3 className="text-sm font-bold text-[#C9A050] mb-3">
                A.2.1.3 Complexión
                {ANATOMY_DESCRIPTIONS[state.anatomy.complexion] && (
                  <InfoTooltip text={ANATOMY_DESCRIPTIONS[state.anatomy.complexion]} />
                )}
              </h3>
              <select value={state.anatomy.complexion} onChange={(e) => updateAnat('complexion', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-3 text-sm text-[#E0E0E0]">
                {COMPLEXIONS.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
            <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs">
              <h3 className="text-sm font-bold text-[#C9A050] mb-3">
                A.2.1.4 Altura
                {ANATOMY_DESCRIPTIONS[state.anatomy.height] && (
                  <InfoTooltip text={ANATOMY_DESCRIPTIONS[state.anatomy.height]} />
                )}
              </h3>
              <select value={state.anatomy.height} onChange={(e) => updateAnat('height', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-3 text-sm text-[#E0E0E0]">
                {HEIGHTS.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
            <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs">
              <h3 className="text-sm font-bold text-[#C9A050] mb-3">
                A.2.1.5 Desarrollo Mamario
                {(ANATOMY_DESCRIPTIONS[matchBreastDevOption(state.anatomy.breastDevelopment)] || ANATOMY_DESCRIPTIONS[state.anatomy.breastDevelopment]) && (
                  <InfoTooltip text={ANATOMY_DESCRIPTIONS[matchBreastDevOption(state.anatomy.breastDevelopment)] || ANATOMY_DESCRIPTIONS[state.anatomy.breastDevelopment]} />
                )}
              </h3>
              <select
                value={matchBreastDevOption(state.anatomy.breastDevelopment)}
                onChange={(e) => updateAnat('breastDevelopment', e.target.value)}
                className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-3 text-sm text-[#E0E0E0]"
              >
                {BREAST_DEV.map(o => <option key={o} value={o}>{o}</option>)}
                {state.anatomy.breastDevelopment && !BREAST_DEV.includes(matchBreastDevOption(state.anatomy.breastDevelopment)) && (
                  <option value={state.anatomy.breastDevelopment}>{state.anatomy.breastDevelopment}</option>
                )}
              </select>
            </div>
            <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs">
              <h3 className="text-sm font-bold text-[#C9A050] mb-3">
                A.2.1.6 Cintura
                {ANATOMY_DESCRIPTIONS[state.anatomy.waist] && (
                  <InfoTooltip text={ANATOMY_DESCRIPTIONS[state.anatomy.waist]} />
                )}
              </h3>
              <select value={state.anatomy.waist} onChange={(e) => updateAnat('waist', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-3 text-sm text-[#E0E0E0]">
                {WAISTS.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
            <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs">
              <h3 className="text-sm font-bold text-[#C9A050] mb-3">
                A.2.1.7 Glúteos
                {ANATOMY_DESCRIPTIONS[state.anatomy.glutes] && (
                  <InfoTooltip text={ANATOMY_DESCRIPTIONS[state.anatomy.glutes]} />
                )}
              </h3>
              <select value={state.anatomy.glutes} onChange={(e) => updateAnat('glutes', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-3 text-sm text-[#E0E0E0]">
                {GLUTES.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
            <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs">
              <h3 className="text-sm font-bold text-[#C9A050] mb-3">
                A.2.1.8 Muslos
                {ANATOMY_DESCRIPTIONS[state.anatomy.thighs] && (
                  <InfoTooltip text={ANATOMY_DESCRIPTIONS[state.anatomy.thighs]} />
                )}
              </h3>
              <select value={state.anatomy.thighs} onChange={(e) => updateAnat('thighs', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-3 text-sm text-[#E0E0E0]">
                {THIGHS.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
            <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs">
              <h3 className="text-sm font-bold text-[#C9A050] mb-3">A.2.1.9 Color de Piel</h3>
              <select value={state.anatomy.skinColor} onChange={(e) => updateAnat('skinColor', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-3 text-sm text-[#E0E0E0]">
                {SKIN_COLORS.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>

            <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs">
              <h3 className="text-sm font-bold text-[#C9A050] mb-3">
                A.2.1.10 Estructura Inferior del Cuerpo
                {ANATOMY_DESCRIPTIONS[state.anatomy.lowerBodyStructure || LOWER_BODY_STRUCTURES[0]] ? (
                  <InfoTooltip text={ANATOMY_DESCRIPTIONS[state.anatomy.lowerBodyStructure || LOWER_BODY_STRUCTURES[0]]} />
                ) : (
                  <InfoTooltip text="Morfología anatómica de extremidades inferiores (humanoide, centauro, lamia serpentina, sirena pisciforme, arpía, slime que babea/escurre gel, etc.)." />
                )}
              </h3>
              <select value={state.anatomy.lowerBodyStructure || LOWER_BODY_STRUCTURES[0]} onChange={(e) => updateAnat('lowerBodyStructure', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-3 text-sm text-[#E0E0E0]">
                {LOWER_BODY_STRUCTURES.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>

            <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs">
              <h3 className="text-sm font-bold text-[#C9A050] mb-3">
                A.2.1.11 Núcleo en el Pecho / Matriz Vital
                <InfoTooltip text="Núcleo de energía vital en el pecho, característico de plasmoides (slime), autómatas o seres arcanos." />
              </h3>
              <select value={state.anatomy.chestCore || CHEST_CORES[0]} onChange={(e) => updateAnat('chestCore', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-3 text-sm text-[#E0E0E0]">
                {CHEST_CORES.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>

            <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs">
              <h3 className="text-sm font-bold text-[#C9A050] mb-3">
                A.2.1.12 Rasgo de Cuello / Pelaje
                <InfoTooltip text="Pelaje de lana denso alrededor del cuello (Caprinae / Bestfolk), melenas, gorgueras de plumas o collares de escamas." />
              </h3>
              <select value={state.anatomy.neckFeature || NECK_FEATURES[0]} onChange={(e) => updateAnat('neckFeature', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-3 text-sm text-[#E0E0E0]">
                {NECK_FEATURES.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
          </div>
        </div>
      )}

      {subTab === 'facial' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Quick Facial Presets */}
          <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-mono font-bold text-[#C9A050] uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#C9A050]" />
                Arquetipos Faciales y Mirada (1-Click)
              </h3>
              <span className="text-[11px] text-[#777777]">Configura ojos, estructura ósea y estética facial instantánea</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
              {FACIAL_PRESETS.map(preset => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => {
                    setState(prev => ({
                      ...prev,
                      facial: {
                        ...prev.facial,
                        ...preset.facial
                      }
                    }));
                  }}
                  className="text-left bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050]/50 rounded-xl p-3 transition-all cursor-pointer group"
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-[#E0E0E0] group-hover:text-[#C9A050] transition-colors">
                      {preset.name}
                    </span>
                  </div>
                  <span className="inline-block text-[9px] font-mono text-[#C9A050] bg-[#0F1115] px-1.5 py-0.5 rounded border border-[#222222] mb-1.5">
                    {preset.category}
                  </span>
                  <p className="text-[11px] text-[#888888] line-clamp-2 leading-tight">
                    {preset.description}
                  </p>
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs col-span-1 md:col-span-2">
              <h3 className="text-lg font-serif italic text-[#C9A050] mb-4">A.2.2.1 Cabeza & Morfología Facial</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Forma</label>
                  <select value={state.facial.headShape} onChange={(e) => updateFacial('headShape', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {HEAD_SHAPES.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Ancho</label>
                  <select value={state.facial.headWidth} onChange={(e) => updateFacial('headWidth', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {HEAD_WIDTHS.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Estructura Ósea <InfoTooltip text="Define la prominencia de pómulos, mandíbula y cejas." /></label>
                  <select value={state.facial.boneStructure} onChange={(e) => updateFacial('boneStructure', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {BONE_STRUCTURES.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Morfología / Hocico <InfoTooltip text="Estructura de hocico felino (Pantheris), canino, rasgos saurios o humanoide estándar." /></label>
                  <select value={state.facial.facialMorphology || FACIAL_MORPHOLOGIES[0]} onChange={(e) => updateFacial('facialMorphology', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {FACIAL_MORPHOLOGIES.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
              </div>
            </div>

            <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs col-span-1 md:col-span-2 space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-[#1E222B]">
                <h3 className="text-lg font-serif italic text-[#C9A050]">A.2.2.2 Ojos, Esclerótica y Mirada</h3>
                {/* Fast Eye Category Selector */}
                <div className="flex flex-wrap gap-1">
                  {EYES_CATEGORIES.map(cat => {
                    const isSelected = state.facial.eyesCategory === cat;
                    const letter = cat.charAt(0);
                    const label = cat.replace(/^[A-Z]\s+/, '').split('/')[0].trim();
                    return (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => updateFacial('eyesCategory', cat)}
                        className={`px-2 py-0.5 rounded text-[10px] font-mono border transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-[#C9A050] text-[#0A0B0E] font-bold border-[#C9A050]'
                            : 'bg-[#15171C] border-[#2A2D35] text-[#888888] hover:text-[#CCC]'
                        }`}
                        title={cat}
                      >
                        [{letter}] {label}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Categoría</label>
                  <select value={state.facial.eyesCategory} onChange={(e) => updateFacial('eyesCategory', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {EYES_CATEGORIES.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Subtipo <InfoTooltip text="Variación específica de la forma base del ojo." /></label>
                  <select value={state.facial.eyesSubtype} onChange={(e) => updateFacial('eyesSubtype', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {EYES_SUBTYPES.filter(s => s.startsWith(state.facial.eyesCategory?.charAt(0) || 'A')).map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Delineado <InfoTooltip text="Grosor y estilo de la línea exterior de las pestañas." /></label>
                  <select value={state.facial.eyeliner} onChange={(e) => updateFacial('eyeliner', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {EYELINERS.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Sombra <InfoTooltip text="Maquillaje o sombreado natural en los párpados." /></label>
                  <select value={state.facial.shadow} onChange={(e) => updateFacial('shadow', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {SHADOWS.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Expresión</label>
                  <select value={state.facial.expression} onChange={(e) => updateFacial('expression', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {EXPRESSIONS.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">A.2.2.3 Iris</label>
                  <select value={state.facial.iris} onChange={(e) => updateFacial('iris', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {IRIS_TYPES.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Morfología de Pupila <InfoTooltip text="Forma física de la pupila (redonda humana, hendidura vertical felina/sauria, horizontal caprina, etc.)." /></label>
                  <select value={state.facial.pupilShape || PUPIL_SHAPES[0]} onChange={(e) => updateFacial('pupilShape', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {PUPIL_SHAPES.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div className="col-span-1 sm:col-span-2">
                  <label className="block text-xs text-[#888888] mb-1">Color de Esclerótica (Globo Ocular) <InfoTooltip text="Color del fondo ocular (blanco natural, esclerótica negra abisal de demonios/elementales, dorada, roja carmesí, etc.)." /></label>
                  <select 
                    value={
                      SCLERA_COLORS.find(c => c === state.facial.scleraColor) ||
                      SCLERA_COLORS.find(c => c.toLowerCase().startsWith(state.facial.scleraColor?.toLowerCase() || '')) ||
                      SCLERA_COLORS.find(c => state.facial.scleraColor && (c.toLowerCase().includes(state.facial.scleraColor.toLowerCase()) || state.facial.scleraColor.toLowerCase().includes(c.toLowerCase()))) ||
                      SCLERA_COLORS[0]
                    } 
                    onChange={(e) => updateFacial('scleraColor', e.target.value)} 
                    className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                  >
                    {SCLERA_COLORS.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div className="col-span-1 sm:col-span-2 flex items-center justify-between bg-[#15171C] border border-[#2A2D35] rounded-xl px-3 py-2">
                  <label className="flex items-center gap-2 text-xs text-[#C9A050] cursor-pointer">
                    <input 
                      type="checkbox"
                      checked={Boolean(state.facial.irisGlow)}
                      onChange={(e) => updateFacial('irisGlow', e.target.checked)}
                      className="rounded border-[#2A2D35] bg-[#0F1115] text-[#C9A050] focus:ring-0"
                    />
                    <span className="font-medium">Iris Bioluminiscente / Resplandor Arcano</span>
                  </label>
                  <span className="text-[10px] text-[#777777] font-mono">Efecto VFX</span>
                </div>
              </div>

              {/* Heterochromia toggle switch */}
              <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-3 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <label className="text-xs font-bold text-[#E0E0E0] flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={Boolean(state.facial.isHeterochromia)}
                      onChange={(e) => updateFacial('isHeterochromia', e.target.checked)}
                      className="rounded border-[#2A2D35] bg-[#0F1115] text-[#C9A050] focus:ring-0"
                    />
                    <span>Heterocromía Completa (Ojos con diferente color)</span>
                  </label>
                  <p className="text-[11px] text-[#777777] ml-5">Permite configurar tonalidades independientes para el ojo izquierdo y el derecho.</p>
                </div>
                {state.facial.isHeterochromia && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#C9A050]/20 text-[#C9A050] border border-[#C9A050]/30 font-bold">
                    Modo Dual Activo
                  </span>
                )}
              </div>

              {/* Eye Color Customizer(s) */}
              <div className="pt-2">
                {state.facial.isHeterochromia ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-[#15171C]/60 border border-[#2A2D35] rounded-xl p-3">
                      <div className="text-xs font-mono font-bold text-[#C9A050] uppercase mb-2 flex items-center gap-1.5">
                        <span>👁️ Ojo Izquierdo</span>
                      </div>
                      <EyeColorCustomizer
                        value={state.facial.eyeColor}
                        onChange={(newVal) => updateFacial('eyeColor', newVal)}
                      />
                    </div>
                    <div className="bg-[#15171C]/60 border border-[#2A2D35] rounded-xl p-3">
                      <div className="text-xs font-mono font-bold text-[#C9A050] uppercase mb-2 flex items-center gap-1.5">
                        <span>👁️ Ojo Derecho</span>
                      </div>
                      <EyeColorCustomizer
                        value={state.facial.eyeColorRight || state.facial.eyeColor}
                        onChange={(newVal) => updateFacial('eyeColorRight', newVal)}
                      />
                    </div>
                  </div>
                ) : (
                  <EyeColorCustomizer
                    value={state.facial.eyeColor}
                    onChange={(newVal) => updateFacial('eyeColor', newVal)}
                  />
                )}
              </div>
            </div>

            <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs col-span-1">
              <h3 className="text-lg font-serif italic text-[#C9A050] mb-4">A.2.2.4 Nariz y Boca</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Nariz</label>
                  <select value={state.facial.nose} onChange={(e) => updateFacial('nose', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {NOSES.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs text-[#888888] mb-1">Labios</label>
                    <select value={state.facial.lips} onChange={(e) => updateFacial('lips', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                      {LIPS.map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs text-[#888888] mb-1">Expresión Boca</label>
                    <select value={state.facial.mouthExp} onChange={(e) => updateFacial('mouthExp', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                      {MOUTH_EXPS.map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs text-[#888888] mb-1">Forma Especial</label>
                    <select value={state.facial.mouthSpecial} onChange={(e) => updateFacial('mouthSpecial', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                      {MOUTH_SPECIALS.map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs text-[#888888] mb-1">Dientes</label>
                    <select value={state.facial.teeth} onChange={(e) => updateFacial('teeth', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                      {TEETHS.map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs text-[#888888] mb-1">Comisuras</label>
                    <select value={state.facial.mouthCorners} onChange={(e) => updateFacial('mouthCorners', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                      {MOUTH_CORNERS.map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs text-[#888888] mb-1">Textura <InfoTooltip text="Aspecto visual de los labios (mate, brillante, jugoso)." /></label>
                    <select value={state.facial.mouthTexture} onChange={(e) => updateFacial('mouthTexture', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                      {MOUTH_TEXTURES.map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </div>
                  <div className="col-span-2">
                    <label className="block text-xs text-[#888888] mb-1">Lengua / Rasgo Lingual <InfoTooltip text="Morfología lingual (humana estándar, bífida reptil/demoníaca, bioluminiscente, etc.)." /></label>
                    <select value={state.facial.tongueType || TONGUE_TYPES[0]} onChange={(e) => updateFacial('tongueType', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                      {TONGUE_TYPES.map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs col-span-1">
              <h3 className="text-lg font-serif italic text-[#C9A050] mb-4">A.2.2.5 Orejas</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Forma Base</label>
                  <select value={state.facial.earsBase} onChange={(e) => updateFacial('earsBase', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {EARS_BASES.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Longitud</label>
                  <select value={state.facial.earsLength} onChange={(e) => updateFacial('earsLength', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {EARS_LENGTHS.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Especial Kemono <InfoTooltip text="Orejas animales. Reemplazan o se añaden a las orejas base." /></label>
                  <select value={state.facial.kemonoEars} onChange={(e) => updateFacial('kemonoEars', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {KEMONO_EARS.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
              </div>
            </div>

            <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs col-span-1 md:col-span-2 space-y-4 border-t-2 border-t-[#C9A050]">
              <div className="flex items-center justify-between pb-2 border-b border-[#1E222B]">
                <div className="flex items-center space-x-2">
                  <span className="text-base">🧔</span>
                  <h3 className="text-lg font-serif italic text-[#C9A050] font-bold">
                    A.2.2.6 Vello Facial (Barba, Bigote, Patillas)
                  </h3>
                </div>
                <InfoTooltip text="Personaliza el estilo de barba, bigote, perilla, patillas y su tonalidad cromática." />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-[#AAAAAA] mb-1 font-medium">Estilo / Tipo de Vello Facial:</label>
                  <select
                    value={state.facial.facialHair || FACIAL_HAIR_OPTIONS[0]}
                    onChange={(e) => updateFacial('facialHair', e.target.value)}
                    className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none"
                  >
                    {FACIAL_HAIR_OPTIONS.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>

                <div>
                  <label className="block text-xs text-[#AAAAAA] mb-1 font-medium">Color del Vello Facial:</label>
                  <select
                    value={state.facial.facialHairColor || FACIAL_HAIR_COLORS[0]}
                    onChange={(e) => updateFacial('facialHairColor', e.target.value)}
                    className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none"
                  >
                    {FACIAL_HAIR_COLORS.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
              </div>

              {/* Quick chips for facial hair */}
              <div>
                <label className="block text-[10px] text-[#777777] font-mono mb-1.5 uppercase">Estilos Populares Rápidos:</label>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    'Ninguno (Afeitado / Rostro Limpio)',
                    'Barba Incipiente / Sombra de 3 Días (Stubble)',
                    'Barba Corta Perfilada y Recortada',
                    'Barba Completa Espesa / Leñador',
                    'Barba de Chivo / Perilla Clásica (Goatee)',
                    'Bigote Clásico / Chevron',
                    'Barba Trenzada de Guerrero Nórdico / Enano con Anillos'
                  ].map(style => {
                    const isSel = (state.facial.facialHair || FACIAL_HAIR_OPTIONS[0]) === style;
                    return (
                      <button
                        key={style}
                        type="button"
                        onClick={() => updateFacial('facialHair', style)}
                        className={`px-2.5 py-1 rounded-lg text-[11px] border transition-all cursor-pointer ${
                          isSel
                            ? 'bg-[#222733] border-[#C9A050] text-[#C9A050] font-medium'
                            : 'bg-[#15171C] border-[#2A2D35] text-[#888888] hover:text-[#CCCCCC]'
                        }`}
                      >
                        {style.split('/')[0].trim()}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {subTab === 'hair' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Quick Hair Presets */}
          <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-mono font-bold text-[#C9A050] uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#C9A050]" />
                Estilos Capilares Icónicos (1-Click)
              </h3>
              <span className="text-[11px] text-[#777777]">Aplica textura, longitud, flequillo y corte al instante</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
              {HAIR_PRESETS.map(preset => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => {
                    setState(prev => ({
                      ...prev,
                      hair: {
                        ...prev.hair,
                        ...preset.hair
                      }
                    }));
                  }}
                  className="text-left bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050]/50 rounded-xl p-3 transition-all cursor-pointer group"
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-[#E0E0E0] group-hover:text-[#C9A050] transition-colors">
                      {preset.name}
                    </span>
                    <span className="text-[9px] font-mono text-[#888888] bg-[#0F1115] px-1.5 py-0.5 rounded border border-[#222222]">
                      {preset.category}
                    </span>
                  </div>
                  <p className="text-[11px] text-[#888888] line-clamp-2 leading-tight">
                    {preset.description}
                  </p>
                </button>
              ))}
            </div>
          </div>

          <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs space-y-6">
            <h3 className="text-lg font-serif italic text-[#C9A050] mb-2">A.2.3.1 Estructura y Peinado</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs text-[#888888] mb-1">Textura <InfoTooltip text="Tipo de cabello: lacio, ondulado, rizado, etc." /></label>
                <select value={state.hair.texture} onChange={(e) => updateHair('texture', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-3 text-sm text-[#E0E0E0]">
                  {HAIR_TEXTURES.map(o => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs text-[#888888] mb-1">Longitud</label>
                <select value={state.hair.length} onChange={(e) => updateHair('length', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-3 text-sm text-[#E0E0E0]">
                  {HAIR_LENGTHS.map(o => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs text-[#888888] mb-1">Corte</label>
                <select value={state.hair.cut} onChange={(e) => updateHair('cut', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-3 text-sm text-[#E0E0E0]">
                  {HAIR_CUTS.map(o => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs text-[#888888] mb-1">Partido</label>
                <select value={state.hair.part} onChange={(e) => updateHair('part', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-3 text-sm text-[#E0E0E0]">
                  {HAIR_PARTS.map(o => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs text-[#888888] mb-1">Flequillo</label>
                <select value={state.hair.bangs} onChange={(e) => updateHair('bangs', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-3 text-sm text-[#E0E0E0]">
                  {HAIR_BANGS.map(o => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs text-[#888888] mb-1">Peinado</label>
                <select value={state.hair.style} onChange={(e) => updateHair('style', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-3 text-sm text-[#E0E0E0]">
                  {HAIR_STYLES.map(o => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
              <div className="col-span-1 md:col-span-2 lg:col-span-3">
                <label className="block text-xs text-[#888888] mb-1">
                  Cabello Elemental / Mágico (Elementales / Seres Especiales)
                  <InfoTooltip text="Permite seleccionar cabellos compuestos de fuego viviente, agua líquida etérea, rayo voltaico, hielo cristalino, sombras arcanas o luz divina." />
                </label>
                <select value={state.hair.hairElemental || HAIR_ELEMENTALS[0]} onChange={(e) => updateHair('hairElemental', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-3 text-sm text-[#E0E0E0]">
                  {HAIR_ELEMENTALS.map(o => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
            </div>

            {/* Enhanced Hair Color Customizer */}
            <div className="pt-2">
              <HairColorCustomizer
                value={state.hair.hairColor}
                onChange={(newVal) => updateHair('hairColor', newVal)}
              />
            </div>
          </div>
        </div>
      )}

      {subTab === 'appendices' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Quick Appendices Presets */}
          <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-mono font-bold text-[#C9A050] uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#C9A050]" />
                Arquetipos Raciales y Apéndices (1-Click)
              </h3>
              <span className="text-[11px] text-[#777777]">Aplica cuernos, alas, colas y marcas de especies de fantasía</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
              {APPENDICES_PRESETS.map(preset => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => {
                    setState(prev => ({
                      ...prev,
                      appendices: {
                        ...prev.appendices,
                        ...preset.appendices
                      }
                    }));
                  }}
                  className="text-left bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] hover:border-[#C9A050]/50 rounded-xl p-3 transition-all cursor-pointer group"
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-[#E0E0E0] group-hover:text-[#C9A050] transition-colors">
                      {preset.name}
                    </span>
                    <span className="text-[9px] font-mono text-[#888888] bg-[#0F1115] px-1.5 py-0.5 rounded border border-[#222222]">
                      {preset.category}
                    </span>
                  </div>
                  <p className="text-[11px] text-[#888888] line-clamp-2 leading-tight">
                    {preset.description}
                  </p>
                </button>
              ))}
            </div>
          </div>
          <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              
              <div className="space-y-4">
                <h3 className="text-lg font-serif italic text-[#C9A050] mb-2 border-b border-[#222222] pb-2">A.2.4.1 Cuernos</h3>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Forma</label>
                  <select value={state.appendices.hornsForm} onChange={(e) => updateApp('hornsForm', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {HORNS_FORMS.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Longitud</label>
                  <select value={state.appendices.hornsLength} onChange={(e) => updateApp('hornsLength', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {HORNS_LENGTHS.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Grosor</label>
                  <select value={state.appendices.hornsThickness} onChange={(e) => updateApp('hornsThickness', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {HORNS_THICKNESSES.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Posición</label>
                  <select value={state.appendices.hornsPosition} onChange={(e) => updateApp('hornsPosition', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {HORNS_POSITIONS.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-serif italic text-[#C9A050] mb-2 border-b border-[#222222] pb-2">A.2.4.2 Alas</h3>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Tipo</label>
                  <select value={state.appendices.wingsType} onChange={(e) => updateApp('wingsType', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {WINGS_TYPES.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Tamaño</label>
                  <select value={state.appendices.wingsSize} onChange={(e) => updateApp('wingsSize', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {WINGS_SIZES.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Posición</label>
                  <select value={state.appendices.wingsPosition} onChange={(e) => updateApp('wingsPosition', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {WINGS_POSITIONS.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-serif italic text-[#C9A050] mb-2 border-b border-[#222222] pb-2">A.2.4.3 Colas</h3>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Tipo de Cola</label>
                  <select value={state.appendices.tailsType} onChange={(e) => updateApp('tailsType', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {TAILS_TYPES.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Longitud de Cola</label>
                  <select value={state.appendices.tailsLength} onChange={(e) => updateApp('tailsLength', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {TAILS_LENGTHS.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>

                {state.appendices.tailsType !== 'Ninguno' && (
                  <div className="bg-[#111317] border border-[#2A2D35] p-3.5 rounded-xl space-y-3 mt-2">
                    <span className="text-[11px] font-mono text-[#C9A050] uppercase tracking-wider font-semibold block">Coloración y Textura de Cola</span>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block text-xs text-[#AAAAAA] mb-1">Color Principal Pelaje / Base</label>
                        <select
                          value={state.appendices.tailsColorPrimary || 'Blanco puro'}
                          onChange={(e) => updateApp('tailsColorPrimary', e.target.value)}
                          className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                        >
                          {TAILS_COLORS.map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs text-[#AAAAAA] mb-1">Color Secundario / Puntas</label>
                        <select
                          value={state.appendices.tailsColorSecondary || 'Ninguno (Unicolor)'}
                          onChange={(e) => updateApp('tailsColorSecondary', e.target.value)}
                          className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                        >
                          <option value="Ninguno (Unicolor)">Ninguno (Unicolor)</option>
                          {TAILS_COLORS.map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs text-[#AAAAAA] mb-1">Acabado / Textura</label>
                        <select
                          value={state.appendices.tailsFinish || 'Pelaje suave aterciopelado'}
                          onChange={(e) => updateApp('tailsFinish', e.target.value)}
                          className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                        >
                          {TAILS_FINISHES.map(f => <option key={f} value={f}>{f}</option>)}
                        </select>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-serif italic text-[#C9A050] mb-2 border-b border-[#222222] pb-2">A.2.4.4 Piel y Patrones</h3>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Textura / Patrón</label>
                  <select value={state.appendices.skinAndMarks} onChange={(e) => updateApp('skinAndMarks', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {SKIN_AND_MARKS.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>

                <div>
                  <label className="block text-xs text-[#888888] mb-1">Uñas y Garras Biológicas <InfoTooltip text="Morfología de garras en manos/patas (uñas naturales, retráctiles felinas, garras de dragón, quitinosas, etc.)." /></label>
                  <select value={state.appendices.clawsType || CLAWS_TYPES[0]} onChange={(e) => updateApp('clawsType', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {CLAWS_TYPES.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>

                <div>
                  <label className="block text-xs text-[#888888] mb-1">Almohadillas Dérmicas Felinas (Paw Pads / Nikukyu) <InfoTooltip text="Presencia de almohadillas carnosas suaves pigmentadas en manos y plantas de pies (rasgo felino / kemono)." /></label>
                  <select value={state.appendices.pawPads || PAW_PADS_OPTIONS[0]} onChange={(e) => updateApp('pawPads', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {PAW_PADS_OPTIONS.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>

                {(state.appendices.skinAndMarks.includes('Escamosa') || state.appendices.skinAndMarks.includes('T2') || state.appendices.skinAndMarks.includes('Placas')) && (
                  <div className="bg-[#15171C] border border-[#2A2D35] p-3.5 rounded-xl mt-3">
                    <label className="block text-xs font-mono text-[#C9A050] mb-2 font-bold">Ubicación de Escamas (Múltiple)</label>
                    <p className="text-[11px] text-[#888888] mb-3">Selecciona las zonas corporales donde se extienden las escamas o placas queratínicas.</p>
                    <div className="flex flex-wrap gap-2">
                      {MARK_LOCATIONS.map(o => {
                        const currentLocs = state.appendices.scaleLocations || [];
                        const isSelected = currentLocs.includes(o);
                        return (
                          <button
                            key={o}
                            type="button"
                            onClick={() => {
                              const newLocs = isSelected ? currentLocs.filter(l => l !== o) : [...currentLocs, o];
                              updateApp('scaleLocations', newLocs);
                            }}
                            className={`px-2.5 py-1 text-[11px] rounded-lg transition-all border ${
                              isSelected
                                ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-md border-[#C9A050]'
                                : 'bg-[#1A1C22] text-[#888888] border-[#2A2D35] hover:border-[#888888] hover:text-[#E0E0E0]'
                            }`}
                          >
                            {o}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>

              <div className="space-y-4 pt-6">
                <h3 className="text-lg font-serif italic text-[#C9A050] mb-2 border-b border-[#222222] pb-2">A.2.4.5 Marcas y Rasgos Singulares</h3>
                
                <div className="bg-[#15171C] border border-[#2A2D35] p-4 rounded-xl mt-2">
                  <div className="flex items-center justify-between mb-3">
                    <label className="block text-sm font-bold text-[#C9A050]">
                      Marcas y Rasgos (Múltiple) <InfoTooltip text="Tatuajes, cicatrices, sellos, runas o características singulares del personaje." />
                    </label>
                    <span className="text-xs font-mono text-[#888888]">
                      {(state.appendices.markTypes || []).length === 0 ? 'Sin marcas seleccionadas' : `${(state.appendices.markTypes || []).length} marca(s) activa(s)`}
                    </span>
                  </div>
                  
                  <div className="mb-4">
                    <label className="block text-xs font-mono text-[#888888] mb-2">Selecciona Tipo de Marca:</label>
                    <div className="flex flex-wrap gap-2">
                      {/* Ninguna option */}
                      <button
                        type="button"
                        onClick={() => {
                          updateAppendices({
                            markTypes: [],
                            markLocations: {},
                            markShapes: {},
                            markColors: {},
                            markSecondaryColors: {},
                            markFinishes: {},
                            markTexts: {},
                            markEmblemConfigs: {}
                          });
                        }}
                        className={`px-3 py-1.5 text-xs rounded-lg transition-all border font-medium ${
                          (state.appendices.markTypes || []).length === 0
                            ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-md border-[#C9A050]'
                            : 'bg-[#1A1C22] text-[#888888] border-[#2A2D35] hover:border-[#888888] hover:text-[#E0E0E0]'
                        }`}
                      >
                        Ninguna (Sin marcas)
                      </button>

                      {MARK_TYPES.filter(o => o !== 'Ninguna').map(o => {
                        const isSelected = (state.appendices.markTypes || []).includes(o);
                        return (
                          <button
                            key={o}
                            type="button"
                            onClick={() => {
                              const currentTypes = state.appendices.markTypes || [];
                              const exists = currentTypes.includes(o);
                              const newTypes = exists ? currentTypes.filter(t => t !== o) : [...currentTypes, o];
                              
                              const newLocs = { ...(state.appendices.markLocations || {}) };
                              const newShapes = { ...(state.appendices.markShapes || {}) };
                              const newColors = { ...(state.appendices.markColors || {}) };
                              const newSecondaryColors = { ...(state.appendices.markSecondaryColors || {}) };
                              const newFinishes = { ...(state.appendices.markFinishes || {}) };
                              const newTexts = { ...(state.appendices.markTexts || {}) };
                              const newEmblems = { ...(state.appendices.markEmblemConfigs || {}) };
                              
                              if (exists) {
                                delete newLocs[o];
                                delete newShapes[o];
                                delete newColors[o];
                                delete newSecondaryColors[o];
                                delete newFinishes[o];
                                delete newTexts[o];
                                delete newEmblems[o];
                              } else {
                                const markConfig = getMarkTypeConfig(o);
                                newShapes[o] = markConfig.defaultShape;
                                newColors[o] = markConfig.defaultColor;
                                newSecondaryColors[o] = 'Ninguno';
                                newFinishes[o] = MARK_FINISHES[0];
                                newLocs[o] = getDefaultLocationsForMark(o);
                              }
                              
                              updateAppendices({
                                markTypes: newTypes,
                                markLocations: newLocs,
                                markShapes: newShapes,
                                markColors: newColors,
                                markSecondaryColors: newSecondaryColors,
                                markFinishes: newFinishes,
                                markTexts: newTexts,
                                markEmblemConfigs: newEmblems
                              });
                            }}
                            className={`px-3 py-1.5 text-xs rounded-lg transition-all border ${
                              isSelected
                                ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-md border-[#C9A050]'
                                : 'bg-[#1A1C22] text-[#A0A0A0] border-[#2A2D35] hover:border-[#888888] hover:text-[#E0E0E0]'
                            }`}
                          >
                            {o}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {(state.appendices.markTypes || []).length > 0 && (
                    <div className="space-y-4 pt-3 border-t border-[#222222]">
                      <div className="flex items-center justify-between mb-1">
                        <label className="block text-xs font-mono text-[#888888]">Configuración Adaptativa por Marca:</label>
                        <span className="text-[11px] text-[#C9A050]/80 font-mono">
                          Personaliza cada marca independientemente
                        </span>
                      </div>
                      {(state.appendices.markTypes || []).map(mark => {
                        const markConfig = getMarkTypeConfig(mark);
                        const currentShape = (state.appendices.markShapes || {})[mark] || markConfig.defaultShape;
                        const currentColor = (state.appendices.markColors || {})[mark] || markConfig.defaultColor;
                        const currentSecondaryColor = (state.appendices.markSecondaryColors || {})[mark] || 'Ninguno';
                        const currentFinish = (state.appendices.markFinishes || {})[mark] || MARK_FINISHES[0];
                        const currentMarkLocs = (state.appendices.markLocations || {})[mark] || [];
                        const activeZone = markLocationZones[mark] || 'Todas';

                        const hasCustomText = Boolean((state.appendices.markTexts || {})[mark]);
                        const isCalligraphy = isCalligraphyOrTextOption(mark, currentShape) || hasCustomText || openTextForMarks[mark];

                        const hasCustomEmblem = Boolean((state.appendices.markEmblemConfigs || {})[mark]);
                        const isEmblem = isLogoShieldOrSealOption(mark, currentShape) || hasCustomEmblem || openEmblemForMarks[mark];

                        const zoneDef = MARK_LOCATION_ZONES.find(z => z.label === activeZone) || MARK_LOCATION_ZONES[0];
                        const filteredLocations = MARK_LOCATIONS.filter(zoneDef.filter);

                        const handleRemoveMark = () => {
                          const currentTypes = state.appendices.markTypes || [];
                          const newTypes = currentTypes.filter(t => t !== mark);
                          const newLocs = { ...(state.appendices.markLocations || {}) };
                          const newShapes = { ...(state.appendices.markShapes || {}) };
                          const newColors = { ...(state.appendices.markColors || {}) };
                          const newSecondaryColors = { ...(state.appendices.markSecondaryColors || {}) };
                          const newFinishes = { ...(state.appendices.markFinishes || {}) };
                          const newTexts = { ...(state.appendices.markTexts || {}) };
                          const newEmblems = { ...(state.appendices.markEmblemConfigs || {}) };

                          delete newLocs[mark];
                          delete newShapes[mark];
                          delete newColors[mark];
                          delete newSecondaryColors[mark];
                          delete newFinishes[mark];
                          delete newTexts[mark];
                          delete newEmblems[mark];

                          updateAppendices({
                            markTypes: newTypes,
                            markLocations: newLocs,
                            markShapes: newShapes,
                            markColors: newColors,
                            markSecondaryColors: newSecondaryColors,
                            markFinishes: newFinishes,
                            markTexts: newTexts,
                            markEmblemConfigs: newEmblems
                          });
                        };

                        return (
                          <div key={mark} className="bg-[#0F1115] rounded-xl p-4 border border-[#222222] border-l-4 border-l-[#C9A050] space-y-4 shadow-sm">
                            <div className="flex items-center justify-between pb-2 border-b border-[#1E222B]">
                              <div className="flex items-center space-x-2">
                                <Sparkles className="w-3.5 h-3.5 text-[#C9A050]" />
                                <span className="text-xs font-bold text-[#C9A050] uppercase tracking-wide">{mark}</span>
                                <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono border ${
                                  currentMarkLocs.length > 0 
                                    ? 'bg-[#18201A] border-[#38A169]/40 text-[#48BB78]' 
                                    : 'bg-[#2A1818] border-[#E53E3E]/40 text-[#FC8181]'
                                }`}>
                                  {currentMarkLocs.length > 0 ? `${currentMarkLocs.length} ubicación(es)` : 'Sin ubicación'}
                                </span>
                              </div>
                              <button
                                type="button"
                                onClick={handleRemoveMark}
                                className="flex items-center space-x-1 text-[11px] text-[#888888] hover:text-[#FF6B6B] hover:bg-[#201414] px-2 py-1 rounded transition-colors"
                                title="Eliminar esta marca"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                                <span>Quitar Marca</span>
                              </button>
                            </div>
                            
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                              <div>
                                <label className="block text-xs text-[#AAAAAA] mb-1.5 font-medium">
                                  Forma / Motivo:
                                </label>
                                <select 
                                  value={currentShape} 
                                  onChange={(e) => updateAppendices({
                                    markShapes: { ...(state.appendices.markShapes || {}), [mark]: e.target.value }
                                  })} 
                                  className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none transition-colors"
                                >
                                  {markConfig.shapes.map(o => <option key={o} value={o}>{o}</option>)}
                                  {!markConfig.shapes.includes(currentShape) && (
                                    <option value={currentShape}>{currentShape}</option>
                                  )}
                                </select>
                              </div>
                              <div>
                                <label className="block text-xs text-[#AAAAAA] mb-1.5 font-medium">
                                  Color Primario:
                                </label>
                                <select 
                                  value={currentColor} 
                                  onChange={(e) => updateAppendices({
                                    markColors: { ...(state.appendices.markColors || {}), [mark]: e.target.value }
                                  })} 
                                  className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none transition-colors"
                                >
                                  {markConfig.colors.map(o => <option key={o} value={o}>{o}</option>)}
                                  {!markConfig.colors.includes(currentColor) && (
                                    <option value={currentColor}>{currentColor}</option>
                                  )}
                                </select>
                              </div>
                              <div>
                                <label className="block text-xs text-[#AAAAAA] mb-1.5 font-medium">
                                  Color Secundario / Degradado:
                                </label>
                                <select 
                                  value={currentSecondaryColor} 
                                  onChange={(e) => updateAppendices({
                                    markSecondaryColors: { ...(state.appendices.markSecondaryColors || {}), [mark]: e.target.value }
                                  })} 
                                  className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none transition-colors"
                                >
                                  <option value="Ninguno">Ninguno (Color Sólido)</option>
                                  {markConfig.colors.map(o => <option key={o} value={o}>{o}</option>)}
                                </select>
                              </div>
                              <div>
                                <label className="block text-xs text-[#AAAAAA] mb-1.5 font-medium">
                                  Acabado / Efecto:
                                </label>
                                <select 
                                  value={currentFinish} 
                                  onChange={(e) => updateAppendices({
                                    markFinishes: { ...(state.appendices.markFinishes || {}), [mark]: e.target.value }
                                  })} 
                                  className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2.5 text-xs text-[#E0E0E0] focus:border-[#C9A050] outline-none transition-colors"
                                >
                                  {MARK_FINISHES.map(o => <option key={o} value={o}>{o}</option>)}
                                </select>
                              </div>
                            </div>

                            {/* Body Locations with Zone Filters */}
                            <div className="bg-[#12141A] p-3 rounded-xl border border-[#1E222B]">
                              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2 pb-2 border-b border-[#1E222B]">
                                <div className="flex items-center space-x-2">
                                  <MapPin className="w-3.5 h-3.5 text-[#C9A050]" />
                                  <label className="text-xs font-mono text-[#E0E0E0] font-semibold">
                                    Posición en el Cuerpo ({currentMarkLocs.length} seleccionadas):
                                  </label>
                                </div>
                                <div className="flex items-center space-x-2">
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const def = getDefaultLocationsForMark(mark);
                                      updateAppendices({
                                        markLocations: { ...(state.appendices.markLocations || {}), [mark]: def }
                                      });
                                    }}
                                    className="text-[10px] text-[#A0A0A0] hover:text-[#C9A050] bg-[#1A1C22] px-2 py-0.5 rounded border border-[#2A2D35] transition-colors"
                                  >
                                    Posición Sugerida
                                  </button>
                                  {currentMarkLocs.length > 0 && (
                                    <button
                                      type="button"
                                      onClick={() => updateAppendices({
                                        markLocations: { ...(state.appendices.markLocations || {}), [mark]: [] }
                                      })}
                                      className="text-[10px] text-[#FF8888] hover:underline px-1"
                                    >
                                      Limpiar
                                    </button>
                                  )}
                                </div>
                              </div>

                              {/* Zone filter tabs */}
                              <div className="flex flex-wrap gap-1 mb-2.5">
                                {MARK_LOCATION_ZONES.map(zone => {
                                  const isZoneActive = activeZone === zone.label;
                                  return (
                                    <button
                                      key={zone.label}
                                      type="button"
                                      onClick={() => setMarkLocationZones(prev => ({ ...prev, [mark]: zone.label }))}
                                      className={`px-2 py-0.5 text-[10px] rounded-md transition-all border ${
                                        isZoneActive
                                          ? 'bg-[#C9A050]/20 text-[#C9A050] border-[#C9A050]/50 font-semibold'
                                          : 'bg-[#15171C] text-[#777777] border-[#22252C] hover:text-[#AAAAAA]'
                                      }`}
                                    >
                                      {zone.label}
                                    </button>
                                  );
                                })}
                              </div>

                              {/* Location pill buttons */}
                              <div className="flex flex-wrap gap-1.5 max-h-48 overflow-y-auto pr-1">
                                {filteredLocations.map(o => {
                                  const isSelected = currentMarkLocs.includes(o);
                                  return (
                                    <button
                                      key={o}
                                      type="button"
                                      onClick={() => {
                                        const prevLocs = (state.appendices.markLocations || {})[mark] || [];
                                        const newLocs = prevLocs.includes(o) ? prevLocs.filter(l => l !== o) : [...prevLocs, o];
                                        updateAppendices({
                                          markLocations: { ...(state.appendices.markLocations || {}), [mark]: newLocs }
                                        });
                                      }}
                                      className={`px-2.5 py-1 text-[11px] rounded-lg transition-all border ${
                                        isSelected
                                          ? 'bg-[#C9A050] text-[#0A0B0E] font-bold border-[#C9A050] shadow-sm'
                                          : 'bg-[#15171C] text-[#888888] border-[#2A2D35] hover:border-[#888888] hover:text-[#CCCCCC]'
                                      }`}
                                    >
                                      {o}
                                    </button>
                                  );
                                })}
                              </div>
                            </div>

                            {/* Additional Tools: Text Inscription / Emblem Builder */}
                            <div className="space-y-3 pt-1">
                              {/* Calligraphy / Text Input */}
                              {isCalligraphy ? (
                                <div className="pt-2 border-t border-[#1E222B]">
                                  <div className="flex items-center justify-between mb-1">
                                    <span className="text-[11px] font-mono text-[#C9A050]">Inscripción de Texto / Caligrafía / Runas</span>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setOpenTextForMarks(prev => ({ ...prev, [mark]: false }));
                                        const newTexts = { ...(state.appendices.markTexts || {}) };
                                        delete newTexts[mark];
                                        updateAppendices({ markTexts: newTexts });
                                      }}
                                      className="text-[10px] text-[#888888] hover:text-[#FF6B6B]"
                                    >
                                      Ocultar / Borrar texto
                                    </button>
                                  </div>
                                  <CalligraphyTextInput
                                    value={(state.appendices.markTexts || {})[mark] || ''}
                                    onChange={text => {
                                      updateAppendices({
                                        markTexts: {
                                          ...(state.appendices.markTexts || {}),
                                          [mark]: text
                                        }
                                      });
                                    }}
                                    optionContext={mark}
                                  />
                                </div>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => setOpenTextForMarks(prev => ({ ...prev, [mark]: true }))}
                                  className="text-[11px] text-[#888888] hover:text-[#C9A050] flex items-center space-x-1.5 py-1 px-2 rounded-lg bg-[#14161C] border border-[#22252C] hover:border-[#C9A050]/40 transition-colors"
                                >
                                  <Plus className="w-3 h-3 text-[#C9A050]" />
                                  <span>Añadir Inscripción de Texto personalizada (Kanjis, Frase, Código, Runas)</span>
                                </button>
                              )}

                              {/* Logo / Shield / Seal Emblem Builder */}
                              {isEmblem ? (
                                <div className="pt-2 border-t border-[#1E222B]">
                                  <div className="flex items-center justify-between mb-1">
                                    <span className="text-[11px] font-mono text-[#C9A050]">Diseñador de Emblema / Sello / Blasón</span>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setOpenEmblemForMarks(prev => ({ ...prev, [mark]: false }));
                                        const newEmblems = { ...(state.appendices.markEmblemConfigs || {}) };
                                        delete newEmblems[mark];
                                        updateAppendices({ markEmblemConfigs: newEmblems });
                                      }}
                                      className="text-[10px] text-[#888888] hover:text-[#FF6B6B]"
                                    >
                                      Ocultar / Borrar emblema
                                    </button>
                                  </div>
                                  <LogoSealEmblemBuilder
                                    config={(state.appendices.markEmblemConfigs || {})[mark]}
                                    onChange={cfg => {
                                      updateAppendices({
                                        markEmblemConfigs: {
                                          ...(state.appendices.markEmblemConfigs || {}),
                                          [mark]: cfg
                                        }
                                      });
                                    }}
                                    contextTitle={`Constructor de Emblema / Sello: ${mark}`}
                                  />
                                </div>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => setOpenEmblemForMarks(prev => ({ ...prev, [mark]: true }))}
                                  className="text-[11px] text-[#888888] hover:text-[#C9A050] flex items-center space-x-1.5 py-1 px-2 rounded-lg bg-[#14161C] border border-[#22252C] hover:border-[#C9A050]/40 transition-colors"
                                >
                                  <Plus className="w-3 h-3 text-[#C9A050]" />
                                  <span>Diseñar Emblema, Sello o Blasón Heráldico para esta marca</span>
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>

              {/* A.2.4.6 Antenas y Palpos Sensoriales */}
              <div className="space-y-4 pt-6">
                <h3 className="text-lg font-serif italic text-[#C9A050] mb-2 border-b border-[#222222] pb-2">A.2.4.6 Antenas y Palpos Sensoriales</h3>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Tipo de Antenas</label>
                  <select 
                    value={state.appendices.antennaeType || ANTENNAE_TYPES[0]} 
                    onChange={(e) => updateApp('antennaeType', e.target.value)} 
                    className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                  >
                    {ANTENNAE_TYPES.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                {(state.appendices.antennaeType && state.appendices.antennaeType !== 'Ninguna') && (
                  <>
                    <div>
                      <label className="block text-xs text-[#888888] mb-1">Longitud</label>
                      <select 
                        value={state.appendices.antennaeLength || ANTENNAE_LENGTHS[1]} 
                        onChange={(e) => updateApp('antennaeLength', e.target.value)} 
                        className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                      >
                        {ANTENNAE_LENGTHS.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs text-[#888888] mb-1">Posición Cefálica</label>
                      <select 
                        value={state.appendices.antennaePosition || ANTENNAE_POSITIONS[0]} 
                        onChange={(e) => updateApp('antennaePosition', e.target.value)} 
                        className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                      >
                        {ANTENNAE_POSITIONS.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                    </div>
                  </>
                )}
              </div>

              {/* A.2.4.7 Ojos Extras & Cluster Ocular */}
              <div className="space-y-4 pt-6">
                <h3 className="text-lg font-serif italic text-[#C9A050] mb-2 border-b border-[#222222] pb-2">A.2.4.7 Ojos Extras & Cluster Ocular</h3>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Disposición Ocular Sobrenatural</label>
                  <select 
                    value={state.appendices.extraEyes || EXTRA_EYES_OPTIONS[0]} 
                    onChange={(e) => updateApp('extraEyes', e.target.value)} 
                    className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                  >
                    {EXTRA_EYES_OPTIONS.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <p className="text-[11px] text-[#777777] italic">Configura ojos múltiples, tercer ojo místico, cluster aracnoide o aberraciones abisales.</p>
              </div>

              {/* A.2.4.8 Brazos Extras & Extremidades Múltiples */}
              <div className="space-y-4 pt-6">
                <h3 className="text-lg font-serif italic text-[#C9A050] mb-2 border-b border-[#222222] pb-2">A.2.4.8 Brazos Extras & Extremidades Múltiples</h3>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Brazos y Extremidades Superiores</label>
                  <select 
                    value={state.appendices.extraArms || EXTRA_ARMS_OPTIONS[0]} 
                    onChange={(e) => updateApp('extraArms', e.target.value)} 
                    className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                  >
                    {EXTRA_ARMS_OPTIONS.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <p className="text-[11px] text-[#777777] italic">Permite seleccionar 4 a 6 brazos divinos/marciales Asura, exo-brazos robóticos o tentáculos dorsales.</p>
              </div>

              {/* A.2.4.9 Extremidades Especiales (Ciborg / Muñeca BJD / Bestiales) */}
              <div className="space-y-4 pt-6">
                <h3 className="text-lg font-serif italic text-[#C9A050] mb-2 border-b border-[#222222] pb-2">A.2.4.9 Extremidades Especiales (Ciborg / Muñeca / Bestiales)</h3>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Brazos y/o Piernas Especiales</label>
                  <select 
                    value={state.appendices.specialLimbs || SPECIAL_LIMBS_OPTIONS[0]} 
                    onChange={(e) => updateApp('specialLimbs', e.target.value)} 
                    className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                  >
                    {SPECIAL_LIMBS_OPTIONS.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <p className="text-[11px] text-[#777777] italic">Prótesis biónicas ciborg con circuitos, articulaciones esféricas de muñeca BJD de porcelana o patas de bestia.</p>
              </div>

              {/* A.2.4.10 Estructura Inferior del Cuerpo (Aracne, Cecaelia, Lamia, etc.) */}
              <div className="space-y-4 pt-6 md:col-span-2 lg:col-span-2">
                <h3 className="text-lg font-serif italic text-[#C9A050] mb-2 border-b border-[#222222] pb-2">A.2.4.10 Estructura y Parte Inferior del Cuerpo</h3>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Mitad Inferior Sobrenatural / Animal / Taura</label>
                  <select 
                    value={state.anatomy.lowerBodyStructure || LOWER_BODY_STRUCTURES[0]} 
                    onChange={(e) => {
                      updateAnat('lowerBodyStructure', e.target.value);
                      updateApp('lowerBodyStructure', e.target.value);
                    }} 
                    className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                  >
                    {LOWER_BODY_STRUCTURES.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div className="bg-[#15171C] border border-[#2A2D35] p-3 rounded-xl mt-2">
                  <p className="text-xs text-[#AAAAAA] leading-relaxed">
                    {ANATOMY_DESCRIPTIONS[state.anatomy.lowerBodyStructure] || ANATOMY_DESCRIPTIONS[state.appendices.lowerBodyStructure || ''] || 'Estructura bípeda estándar u ontología morfológica seleccionada.'}
                  </p>
                </div>
              </div>
          </div>
        </div>
      </div>
      )}

      {subTab === 'makeup' && (
        <MakeupCustomizer state={state} setState={setState} />
      )}

      {subTab === 'intimate' && (
        <div className="space-y-6 animate-fadeIn">
          {!state.nsfw?.isNsfwEnabled ? (
            <div className="bg-[#120D14] border border-rose-900/60 rounded-3xl p-8 text-center space-y-4 shadow-2xl">
              <div className="w-16 h-16 rounded-2xl bg-rose-950/80 border border-rose-600/50 flex items-center justify-center mx-auto text-rose-400">
                <Flame className="w-8 h-8 fill-current" />
              </div>
              <h3 className="text-xl font-serif italic text-rose-200">
                Modo Adulto R+18 Desactivado
              </h3>
              <p className="text-xs text-zinc-400 max-w-lg mx-auto leading-relaxed">
                Al activar el Modo R+18 desbloquearás las opciones de configuración exclusivamente anatómica y corporal íntima (areolas, pezones, genitales, vello púbico, hipersensibilidad) y se deshabilitarán las limitaciones de resistencia y pudor en la sala de interacción.
              </p>
              <button
                type="button"
                onClick={() => toggleNsfw(true)}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-rose-700 to-rose-600 hover:from-rose-600 hover:to-rose-500 text-white font-bold text-xs tracking-wider uppercase transition-all shadow-lg shadow-rose-950/60 cursor-pointer inline-flex items-center gap-2"
              >
                <Flame className="w-4 h-4 fill-current" />
                <span>Habilitar Modo R+18 (+18 Años)</span>
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Header card */}
              <div className="bg-[#140E16] border border-rose-900/50 rounded-2xl p-5 shadow-xl flex items-center justify-between flex-wrap gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Flame className="w-4 h-4 text-rose-400 fill-current" />
                    <h3 className="text-sm font-bold text-rose-200 uppercase tracking-wider">
                      2.6 Anatomía Íntima & Parámetros Explícitos
                    </h3>
                  </div>
                  <p className="text-xs text-zinc-400">
                    Sincronizados en tiempo real con el lienzo visual de la muñeca y la sala de interacción libre.
                  </p>
                </div>
                <span className="px-3 py-1 rounded-full bg-rose-950 border border-rose-700 text-rose-300 text-[11px] font-mono font-bold">
                  Limitaciones de Interacción: DESACTIVADAS
                </span>
              </div>

              {/* 2.6.1 Areola Color & 2.6.2 Areola Size */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Areola Color */}
                <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-5 space-y-4">
                  <h4 className="text-xs font-mono font-bold text-[#C9A050] uppercase tracking-wider flex items-center gap-2">
                    <Sparkles className="w-3.5 h-3.5 text-[#C9A050]" />
                    Color y Pigmentación de Areola
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {AREOLA_COLORS.map(c => {
                      const isSelected = (state.nsfw?.areolaColor || AREOLA_COLORS[0].name) === c.name;
                      return (
                        <button
                          key={c.id}
                          type="button"
                          onClick={() => updateNsfw('areolaColor', c.name)}
                          className={`text-left p-3 rounded-xl border transition-all cursor-pointer flex items-start gap-3 ${
                            isSelected
                              ? 'bg-[#1C141C] border-rose-500 shadow-sm'
                              : 'bg-[#15171C] border-[#2A2D35] hover:border-[#444]'
                          }`}
                        >
                          <div
                            className="w-5 h-5 rounded-full border border-white/20 shrink-0 mt-0.5"
                            style={{ backgroundColor: c.colorHex }}
                          />
                          <div className="space-y-0.5">
                            <div className="text-xs font-bold text-zinc-200 flex items-center gap-1.5">
                              <span>{c.name}</span>
                              {isSelected && <Check className="w-3 h-3 text-rose-400" />}
                            </div>
                            <p className="text-[10px] text-zinc-400 leading-tight">
                              {c.description}
                            </p>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Areola Size */}
                <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-5 space-y-4">
                  <h4 className="text-xs font-mono font-bold text-[#C9A050] uppercase tracking-wider flex items-center gap-2">
                    <Sparkles className="w-3.5 h-3.5 text-[#C9A050]" />
                    Tamaño y Proporción de Areola
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {AREOLA_SIZES.map(s => {
                      const isSelected = (state.nsfw?.areolaSize || AREOLA_SIZES[0].name) === s.name;
                      return (
                        <button
                          key={s.id}
                          type="button"
                          onClick={() => updateNsfw('areolaSize', s.name)}
                          className={`text-left p-3 rounded-xl border transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-[#1C141C] border-rose-500 shadow-sm'
                              : 'bg-[#15171C] border-[#2A2D35] hover:border-[#444]'
                          }`}
                        >
                          <div className="text-xs font-bold text-zinc-200 flex items-center justify-between mb-1">
                            <span>{s.name}</span>
                            {isSelected && <Check className="w-3 h-3 text-rose-400" />}
                          </div>
                          <p className="text-[10px] text-zinc-400 leading-tight">
                            {s.description}
                          </p>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* 2.6.3 Nipple Morphology & 2.6.4 Pubic Hair Style */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Nipple Types */}
                <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-5 space-y-4">
                  <h4 className="text-xs font-mono font-bold text-[#C9A050] uppercase tracking-wider flex items-center gap-2">
                    <Flame className="w-3.5 h-3.5 text-rose-400" />
                    Morfología y Firmeza de Pezón
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {NIPPLE_TYPES.map(n => {
                      const isSelected = (state.nsfw?.nippleType || NIPPLE_TYPES[0].name) === n.name;
                      return (
                        <button
                          key={n.id}
                          type="button"
                          onClick={() => updateNsfw('nippleType', n.name)}
                          className={`text-left p-3 rounded-xl border transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-[#1C141C] border-rose-500 shadow-sm'
                              : 'bg-[#15171C] border-[#2A2D35] hover:border-[#444]'
                          }`}
                        >
                          <div className="text-xs font-bold text-zinc-200 flex items-center justify-between mb-1">
                            <span>{n.name}</span>
                            {isSelected && <Check className="w-3 h-3 text-rose-400" />}
                          </div>
                          <p className="text-[10px] text-zinc-400 leading-tight">
                            {n.description}
                          </p>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Pubic Hair Style */}
                <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-5 space-y-4">
                  <h4 className="text-xs font-mono font-bold text-[#C9A050] uppercase tracking-wider flex items-center gap-2">
                    <Scissors className="w-3.5 h-3.5 text-[#C9A050]" />
                    Estilo y Corte de Vello Púbico
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {PUBIC_HAIR_STYLES.map(p => {
                      const isSelected = (state.nsfw?.pubicHairStyle || PUBIC_HAIR_STYLES[0].name) === p.name;
                      return (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => updateNsfw('pubicHairStyle', p.name)}
                          className={`text-left p-3 rounded-xl border transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-[#1C141C] border-rose-500 shadow-sm'
                              : 'bg-[#15171C] border-[#2A2D35] hover:border-[#444]'
                          }`}
                        >
                          <div className="text-xs font-bold text-zinc-200 flex items-center justify-between mb-1">
                            <span>{p.name}</span>
                            {isSelected && <Check className="w-3 h-3 text-rose-400" />}
                          </div>
                          <p className="text-[10px] text-zinc-400 leading-tight">
                            {p.description}
                          </p>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* 2.6.5 Morfología y Tipo de Genitales */}
              <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-5 space-y-5">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="space-y-1">
                    <h4 className="text-xs font-mono font-bold text-[#C9A050] uppercase tracking-wider flex items-center gap-2">
                      <Sparkles className="w-3.5 h-3.5 text-[#C9A050]" />
                      2.6.5 Morfología & Tipo de Genitales
                    </h4>
                    <p className="text-[11px] text-zinc-400">
                      Configuración anatómica pélvica e íntima adaptada al sexo base (<strong className="text-[#C9A050]">{state.anatomy?.sexBase || 'No definido'}</strong>) o con opciones híbridas y de fantasía.
                    </p>
                  </div>
                  {/* Category filters */}
                  <div className="flex items-center gap-1.5 bg-[#15171C] p-1 rounded-xl border border-[#2A2D35] flex-wrap">
                    {(['Auto', 'Femenino', 'Masculino', 'Fantasía / Andrógino', 'Todos'] as const).map(cat => (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setGenitalFilter(cat)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                          genitalFilter === cat
                            ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-xs'
                            : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#1C1F26]'
                        }`}
                      >
                        {cat === 'Auto' ? '✨ Auto (Recomendado)' : cat}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Genital Types grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-3">
                  {filteredGenitalTypes.map(gt => {
                    const isSelected = (state.nsfw?.genitalType || defaultGenitalType) === gt.name;
                    return (
                      <button
                        key={gt.id}
                        type="button"
                        onClick={() => updateNsfw('genitalType', gt.name)}
                        className={`text-left p-3.5 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                          isSelected
                            ? 'bg-[#1C141C] border-rose-500 shadow-sm'
                            : 'bg-[#15171C] border-[#2A2D35] hover:border-[#444]'
                        }`}
                      >
                        <div>
                          <div className="flex items-start justify-between gap-2 mb-1.5">
                            <span className="text-xs font-bold text-zinc-200">{gt.name}</span>
                            <div className="flex items-center gap-1 shrink-0">
                              <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-black/40 text-zinc-400 border border-white/5">
                                {gt.category}
                              </span>
                              {isSelected && <Check className="w-3.5 h-3.5 text-rose-400 shrink-0" />}
                            </div>
                          </div>
                          <p className="text-[10px] text-zinc-400 leading-relaxed">
                            {gt.description}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Genital Size and Genital Details sub-row */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-3 border-t border-[#1C1F26]">
                  {/* Proporción / Tamaño Genital */}
                  <div className="space-y-2.5">
                    <label className="text-[11px] font-mono font-bold text-[#C9A050] uppercase tracking-wider block">
                      Proporción / Tamaño Genital
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {GENITAL_SIZES.map(gs => {
                        const isSelected = (state.nsfw?.genitalSize || GENITAL_SIZES[1].name) === gs.name;
                        return (
                          <button
                            key={gs.id}
                            type="button"
                            onClick={() => updateNsfw('genitalSize', gs.name)}
                            className={`text-left p-2.5 rounded-xl border transition-all cursor-pointer ${
                              isSelected
                                ? 'bg-[#1C141C] border-rose-500 text-rose-200 shadow-sm'
                                : 'bg-[#15171C] border-[#2A2D35] text-zinc-300 hover:border-[#444]'
                            }`}
                          >
                            <div className="text-xs font-bold flex items-center justify-between mb-0.5">
                              <span>{gs.name}</span>
                              {isSelected && <Check className="w-3 h-3 text-rose-400" />}
                            </div>
                            <p className="text-[9px] text-zinc-400 leading-tight">
                              {gs.description}
                            </p>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Rasgos & Acabados Íntimos */}
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between flex-wrap gap-1">
                      <label className="text-[11px] font-mono font-bold text-[#C9A050] uppercase tracking-wider block">
                        Rasgos & Acabados Íntimos (Tono, Joyería, Tersura)
                      </label>
                      <span className="text-[10px] text-zinc-400 font-mono bg-[#15171C] border border-[#2A2D35] px-2 py-0.5 rounded-full">
                        {selectedGenitalDetails.length} seleccionados (Múltiple)
                      </span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {GENITAL_DETAILS.map(gd => {
                        const isSelected = selectedGenitalDetails.includes(gd.name);
                        return (
                          <button
                            key={gd.id}
                            type="button"
                            onClick={() => toggleGenitalDetail(gd.name)}
                            className={`text-left p-2.5 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                              isSelected
                                ? 'bg-[#1C141C] border-rose-500 text-rose-200 shadow-sm'
                                : 'bg-[#15171C] border-[#2A2D35] text-zinc-300 hover:border-[#444]'
                            }`}
                          >
                            <div>
                              <div className="text-xs font-bold flex items-center justify-between mb-1">
                                <span className={isSelected ? 'text-rose-200' : 'text-zinc-200'}>{gd.name}</span>
                                <div className="flex items-center gap-1 shrink-0 ml-1">
                                  <span className="text-[9px] font-mono px-1 py-0.2 rounded bg-black/40 text-zinc-400 border border-white/5">
                                    {gd.id}
                                  </span>
                                  {isSelected ? (
                                    <Check className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                                  ) : (
                                    <div className="w-3.5 h-3.5 rounded border border-zinc-600 shrink-0" />
                                  )}
                                </div>
                              </div>
                              <p className="text-[9px] text-zinc-400 leading-tight">
                                {gd.description}
                              </p>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>

              {/* 2.6.6 Body Sensitivities (Multi-select) */}
              <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-mono font-bold text-[#C9A050] uppercase tracking-wider flex items-center gap-2">
                    <Heart className="w-3.5 h-3.5 text-rose-400 fill-current" />
                    2.6.6 Zonas Corporales Hipersensibles (Selección Múltiple)
                  </h4>
                  <span className="text-[11px] text-zinc-400">
                    Aumentan drásticamente la excitación y alteran los diálogos al ser tocadas
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                  {BODY_SENSITIVITIES.map(bs => {
                    const currentSens = state.nsfw?.bodySensitivities || [];
                    const isSelected = currentSens.includes(bs.id);
                    return (
                      <button
                        key={bs.id}
                        type="button"
                        onClick={() => {
                          const updated = isSelected
                            ? currentSens.filter(id => id !== bs.id)
                            : [...currentSens, bs.id];
                          updateNsfw('bodySensitivities', updated);
                        }}
                        className={`text-left p-3 rounded-xl border transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-[#20141E] border-rose-500 text-rose-200 shadow-sm'
                            : 'bg-[#15171C] border-[#2A2D35] text-zinc-300 hover:border-[#444]'
                        }`}
                      >
                        <div className="text-xs font-bold flex items-center justify-between mb-1">
                          <span>{bs.name}</span>
                          {isSelected && <Check className="w-3 h-3 text-rose-400" />}
                        </div>
                        <p className="text-[10px] text-zinc-400 leading-tight">
                          {bs.description}
                        </p>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Navigation buttons */}
      <div className="mt-10 flex justify-between">
        <button onClick={onBack} className="bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] text-[#E0E0E0] px-6 py-3 rounded-xl font-semibold text-sm flex items-center space-x-2 transition-all cursor-pointer">
          <ArrowLeft className="w-4 h-4" /><span>Anterior</span>
        </button>
        <button onClick={onNext} className="bg-[#C9A050] hover:bg-[#b58e45] text-[#0A0B0E] px-6 py-3 rounded-xl font-semibold text-sm flex items-center space-x-2 transition-all shadow-md cursor-pointer">
          <span>Siguiente: Constructor de Vestuario</span><ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
