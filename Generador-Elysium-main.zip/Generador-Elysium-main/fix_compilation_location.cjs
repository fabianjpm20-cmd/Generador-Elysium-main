const fs = require('fs');
let data = fs.readFileSync('src/components/State6Compilation.tsx', 'utf8');

data = data.replace(
  /w\.details \? \`Details: \$\{cleanVal\(w\.details\)\}\` : '',\n        w\.variation \? \`Variation: \$\{cleanVal\(w\.variation\)\}\` : '',\n        w\.layer \? \`Layer: \$\{cleanVal\(w\.layer\)\}\` : '',\n        w\.location \? \`Location: \$\{cleanVal\(w\.location\)\}\` : '',/,
  "w.details ? `Details: ${cleanVal(w.details)}${w.location ? ' (' + cleanVal(w.location) + ')' : ''}` : '',\n        w.variation ? `Variation: ${cleanVal(w.variation)}` : '',\n        w.layer ? `Layer: ${cleanVal(w.layer)}` : '',"
);

fs.writeFileSync('src/components/State6Compilation.tsx', data);
