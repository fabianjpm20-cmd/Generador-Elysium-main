const fs = require('fs');
let data = fs.readFileSync('src/components/State2Anatomy.tsx', 'utf8');

const startIndex = data.indexOf('<div className="space-y-4 pt-6">');
const endIndex = data.indexOf('</div>\n            </div>\n          </div>\n        </div>\n      )}\n\n      {/* Navigation buttons */}');

if (startIndex !== -1 && endIndex !== -1) {
  const newBlock = `<div className="space-y-4 pt-6">
                <h3 className="text-lg font-serif italic text-[#C9A050] mb-2 border-b border-[#222222] pb-2">A.2.4.5 Marcas y Rasgos Singulares</h3>
                
                <div className="bg-[#15171C] border border-[#2A2D35] p-4 rounded-xl mt-2">
                  <label className="block text-sm font-bold text-[#C9A050] mb-3">Marcas y Rasgos (Múltiple) <InfoTooltip text="Tatuajes, cicatrices, sellos, runas o características singulares del personaje." /></label>
                  
                  <div className="mb-4">
                    <label className="block text-xs font-mono text-[#888888] mb-2">Selecciona Tipo de Marca:</label>
                    <div className="flex flex-wrap gap-2">
                      {MARK_TYPES.filter(o => o !== 'Ninguna').map(o => {
                        const isSelected = (state.appendices.markTypes || []).includes(o);
                        return (
                          <button
                            key={o}
                            type="button"
                            onClick={() => {
                              const types = state.appendices.markTypes || [];
                              let newTypes;
                              if (types.includes(o)) {
                                newTypes = types.filter(t => t !== o);
                              } else {
                                newTypes = [...types, o];
                              }
                              
                              const newLocs = { ...(state.appendices.markLocations || {}) };
                              const newShapes = { ...(state.appendices.markShapes || {}) };
                              const newColors = { ...(state.appendices.markColors || {}) };
                              
                              if (!newTypes.includes(o)) {
                                delete newLocs[o];
                                delete newShapes[o];
                                delete newColors[o];
                              } else {
                                newShapes[o] = MARK_SHAPES[0];
                                newColors[o] = MARK_COLORS[0];
                              }
                              
                              updateApp('markTypes', newTypes);
                              updateApp('markLocations', newLocs);
                              updateApp('markShapes', newShapes);
                              updateApp('markColors', newColors);
                            }}
                            className={\`px-3 py-1.5 text-xs rounded-lg transition-all border \${
                              isSelected
                                ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-md border-[#C9A050]'
                                : 'bg-[#1A1C22] text-[#A0A0A0] border-[#2A2D35] hover:border-[#888888] hover:text-[#E0E0E0]'
                            }\`}
                          >
                            {o}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {(state.appendices.markTypes || []).length > 0 && (
                    <div className="space-y-4 pt-3 border-t border-[#222222]">
                      <label className="block text-xs font-mono text-[#888888] mb-1">Configuración Específica por Marca:</label>
                      {(state.appendices.markTypes || []).map(mark => (
                        <div key={mark} className="bg-[#0F1115] rounded-lg p-4 border border-[#222222] pl-4 border-l-2 border-l-[#C9A050]">
                          <label className="block text-[11px] font-mono text-[#A0A0A0] mb-3 uppercase tracking-wide">Configuración para: <span className="text-[#C9A050] font-bold">{mark}</span></label>
                          
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                            <div>
                              <label className="block text-xs text-[#888888] mb-1">Forma / Motivo</label>
                              <select 
                                value={(state.appendices.markShapes || {})[mark] || MARK_SHAPES[0]} 
                                onChange={(e) => updateApp('markShapes', { ...state.appendices.markShapes, [mark]: e.target.value })} 
                                className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                              >
                                {MARK_SHAPES.map(o => <option key={o} value={o}>{o}</option>)}
                              </select>
                            </div>
                            <div>
                              <label className="block text-xs text-[#888888] mb-1">Color / Apariencia Visual</label>
                              <select 
                                value={(state.appendices.markColors || {})[mark] || MARK_COLORS[0]} 
                                onChange={(e) => updateApp('markColors', { ...state.appendices.markColors, [mark]: e.target.value })} 
                                className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                              >
                                {MARK_COLORS.map(o => <option key={o} value={o}>{o}</option>)}
                              </select>
                            </div>
                          </div>

                          <div>
                            <label className="block text-xs font-mono text-[#888888] mb-2">Posición de la Marca (Múltiple)</label>
                            <div className="flex flex-wrap gap-2">
                              {MARK_LOCATIONS.map(o => {
                                const currentMarkLocs = (state.appendices.markLocations || {})[mark] || [];
                                const isSelected = currentMarkLocs.includes(o);
                                return (
                                  <button
                                    key={o}
                                    type="button"
                                    onClick={() => {
                                      const prevLocs = (state.appendices.markLocations || {})[mark] || [];
                                      const newLocs = prevLocs.includes(o) ? prevLocs.filter(l => l !== o) : [...prevLocs, o];
                                      updateApp('markLocations', { ...state.appendices.markLocations, [mark]: newLocs });
                                    }}
                                    className={\`px-2 py-1 text-[11px] rounded transition-all \${
                                      isSelected
                                        ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-md'
                                        : 'bg-[#15171C] text-[#888888] border border-[#2A2D35] hover:border-[#888888]'
                                    }\`}
                                  >
                                    {o}
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>\n            `;

  data = data.substring(0, startIndex) + newBlock + data.substring(endIndex);
  fs.writeFileSync('src/components/State2Anatomy.tsx', data);
  console.log("Replaced State2Anatomy.tsx successfully.");
} else {
  console.log("Failed to find bounds.");
}
