const fs = require('fs');

let content = fs.readFileSync('src/data.ts', 'utf8');

content = content.replace("'4 Twink/Soft Boy'", "'4 Hombre Twink/Soft Boy'");
content = content.replace("'5 Casi Feminizado'", "'5 Hombre Casi Feminizado'");

content = content.replace(/"4 Twink\/Soft Boy":/g, '"4 Hombre Twink/Soft Boy":');
content = content.replace(/"5 Casi Feminizado":/g, '"5 Hombre Casi Feminizado":');

fs.writeFileSync('src/data.ts', content);
