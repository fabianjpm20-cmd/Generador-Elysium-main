#!/bin/bash

# Script de inicio optimizado para Generador Elysium
# Uso: ./run.sh [puerto]

PORT=${1:-3000}
NODE_ENV=production

echo "Iniciando Generador Elysium en el puerto $PORT..."
echo "Presione Ctrl+C para detener el servidor"

node dist/server.cjs
