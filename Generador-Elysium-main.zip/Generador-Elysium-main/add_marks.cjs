const fs = require('fs');
let data = fs.readFileSync('src/data.ts', 'utf8');

const marksOptions = `
export const MARK_TYPES = [
  'Ninguna',
  'M1 Tatuaje Tradicional / Tribal',
  'M2 Tatuaje Yakuza / Irezumi',
  'M3 Tatuaje Minimalista / Geométrico',
  'M4 Marca de Nacimiento / Lunares',
  'M5 Cicatriz de Batalla / Quemadura',
  'M6 Cicatriz Quirúrgica / Implante',
  'M7 Sello Mágico / Runa Maldita',
  'M8 Pintura Corporal / Maquillaje de Guerra',
  'M9 Circuitos / Líneas Cibernéticas',
  'M10 Patrón Natural (Vitíligo / Manchas)',
  'M11 Cristales / Escamas Incrustadas',
  'M12 Venas Corruptas / Infección Mágica'
];

export const MARK_SHAPES = [
  'S1 Líneas y Geometría',
  'S2 Animal / Bestia Espiritual',
  'S3 Texto / Runas Antiguas',
  'S4 Estrellas / Constelaciones / Astros',
  'S5 Caótico / Asimétrico / Rasguños',
  'S6 Llamas / Humo / Fluidos',
  'S7 Botánico (Flores / Enredaderas / Espinas)',
  'S8 Cráneos / Motivos Oscuros',
  'S9 Abstracto / Fractal',
  'S10 Código / Datos Digitales'
];

export const MARK_LOCATIONS = [
  'L1 Rostro (Ojo o Mejilla)',
  'L2 Rostro (Frente o Tercer Ojo)',
  'L3 Cuello / Garganta / Nuca',
  'L4 Pecho / Sobre el Corazón',
  'L5 Espalda Completa',
  'L6 Brazo Derecho (Manga)',
  'L7 Brazo Izquierdo (Manga)',
  'L8 Ambos Brazos',
  'L9 Manos / Palmas / Dedos',
  'L10 Abdomen / Torso Inferior',
  'L11 Muslos / Piernas',
  'L12 Cuerpo Completo (Patrón Extenso)'
];

export const MARK_COLORS = [
  'C1 Negro Tinta / Carbón',
  'C2 Rojo Sangre / Carmesí',
  'C3 Dorado Luminoso / Oro',
  'C4 Azul Neón / Cian',
  'C5 Blanco Fantasma / Cicatriz Pálida',
  'C6 Plata / Metálico',
  'C7 Magenta / Púrpura Emisivo',
  'C8 Verde Tóxico / Ácido',
  'C9 Tono de Piel Más Oscuro / Vitíligo',
  'C10 Rosa Cicatriz / Tejido Sano',
  'C11 Naranja Fuego / Ascuas',
  'C12 Vantablack / Vacío Oscuro'
];
`;

data = data.replace(
  /export const SKIN_AND_MARKS = \[[\s\S]*?\];/,
  "export const SKIN_AND_MARKS = [\n  'T1 Piel Lisa', 'T2 Piel Escamosa', 'T3 Pelo Corto', 'T4 Pelo Largo', 'T5 Plumas', 'T6 Queratina Cuernos/Placas', 'T7 Cartílago Óseo', 'T8 Membrana', 'T9 Cristalina', 'T10 Metálica'\n];\n" + marksOptions
);

fs.writeFileSync('src/data.ts', data);
