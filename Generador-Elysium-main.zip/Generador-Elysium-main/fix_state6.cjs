const fs = require('fs');

let content = fs.readFileSync('src/components/State6Compilation.tsx', 'utf8');

content = content.replace(
  /return \`\$\{w.name\} \$\{desc \? \`\(\$\{desc\}\)\` : ''\} \[Material: \$\{cleanVal\(w.material\)\}, Color: \$\{w.color\}, Layer: \$\{cleanVal\(w.layer\)\}, Details: \$\{cleanVal\(w.details\)\}\]\`;/,
  "return `${w.name} ${desc ? `(${desc})` : ''} [Cut: ${cleanVal(w.cut)}, Length: ${cleanVal(w.length)}, Sleeve: ${cleanVal(w.sleeve)}, Material: ${cleanVal(w.material)}, Color: ${w.color}, Finish: ${cleanVal(w.finish)}, Details: ${cleanVal(w.details)}, Variation: ${cleanVal(w.variation)}, Layer: ${cleanVal(w.layer)}]`.replace(/Sleeve: , /g, '');"
);

fs.writeFileSync('src/components/State6Compilation.tsx', content);
