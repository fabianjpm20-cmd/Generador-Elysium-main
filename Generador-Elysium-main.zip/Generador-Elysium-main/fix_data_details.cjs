const fs = require('fs');
let data = fs.readFileSync('src/data.ts', 'utf8');

// details replacement
const detailsStr = `  let details = ['Bordados', 'Costuras', 'Cinturones', 'Pliegues', 'Transparencias', 'Encajes', 'Lazos', 'Cintas', 'Hebillas', 'Parches', 'Cremalleras Expuestas', 'Bolsillos Tácticos', 'Aberturas / Cortes (Cut-outs)', 'Cordones / Corsetería', 'Lentejuelas / Pedrería', 'Flecos', 'Cadenas Colgantes', 'Remaches', 'Plumas', 'Minimalista'];
  if (isShoes || isAcc) details = ['Tachuelas', 'Hebillas', 'Cadenas', 'Grabados', 'Lazos', 'Cintas', 'Remaches', 'Cremalleras', 'Bordados', 'Flecos', 'Minimalista'];
  if (isBra || categoryId === 'B3-B') details = ['Lazos', 'Transparencias', 'Encajes', 'Volantes', 'Bordados', 'Cintas', 'Aberturas / Cortes (Cut-outs)', 'Cordones / Corsetería', 'Minimalista'];`;

data = data.replace(
  /  let details \= \['Bordados'[\s\S]*?if \(isBra \|\| categoryId === 'B3-B'\) details = \['Lazos', 'Transparencias', 'Volantes', 'Bordados', 'Cintas', 'Minimalista'\];/,
  detailsStr
);

// location logic replacement
const locationLogic = `  // LOCATION / COVERAGE (Now heavily dependent on the chosen detail)
  let location: string[] = [];
  
  const effDetail = currentDetail || details[0] || '';
  if (effDetail === 'Lazos' || effDetail === 'Cintas' || effDetail === 'Cordones / Corsetería') {
    location = [
      'Cuello / Gargantilla', 'Hombros (Ambos)', 'Hombro Izquierdo', 'Hombro Derecho', 
      'Escote / Busto Frontal', 'Cintura Frontal', 'Cintura Lateral', 'Espalda Alta', 
      'Espalda Baja / Corsé', 'Puños / Muñecas', 'Dobladillo Inferior', 'Muslos (Ligas)', 'Tobillos'
    ];
  } else if (effDetail === 'Transparencias' || effDetail === 'Encajes' || effDetail === 'Aberturas / Cortes (Cut-outs)') {
    location = [
      'Cobertura Total', 'Paneles Laterales (Costados)', 'Escote / Pecho', 'Busto (Underboob/Sideboob)',
      'Vientre / Abdomen', 'Espalda Completa', 'Espalda Baja', 'Sólo Mangas', 
      'Hombros Descubiertos', 'Muslo Lateral', 'Rodillas', 'Caderas (High-cut)'
    ];
  } else if (effDetail === 'Bordados' || effDetail === 'Parches' || effDetail === 'Lentejuelas / Pedrería' || effDetail === 'Plumas') {
    location = [
      'Pecho Central', 'Espalda Central', 'Solapas / Cuello', 'Hombros / Hombreras',
      'Mangas (Lado Exterior)', 'Puños', 'Borde Inferior / Dobladillo', 'Bolsillos Frontales',
      'Disperso por toda la prenda', 'Rodillas', 'Costuras Laterales'
    ];
  } else if (effDetail === 'Hebillas' || effDetail === 'Cinturones' || effDetail === 'Tachuelas' || effDetail === 'Cadenas' || effDetail === 'Cadenas Colgantes' || effDetail === 'Remaches') {
    location = [
      'Cuello (Gargantilla)', 'Hombros / Charreteras', 'Pecho (Arnés cruzado)', 'Pecho (Horizontal)',
      'Bajo Busto (Underbust)', 'Cintura Frontal', 'Cintura (Cinturón caído)', 'Caderas', 
      'Brazos (Bíceps)', 'Muñecas', 'Muslo Derecho', 'Muslo Izquierdo', 'Rodillas', 'Botas / Tobillos'
    ];
  } else if (effDetail === 'Pliegues' || effDetail === 'Volantes' || effDetail === 'Flecos') {
    location = [
      'Cuello / Gorguera', 'Mangas / Puños', 'Pecho / Cascada Frontal', 'Cintura / Peplum',
      'Borde Inferior / Dobladillo', 'A lo largo de las mangas', 'Espalda Baja', 'Asimétrico (Diagonal)'
    ];
  } else if (effDetail === 'Grabados' || effDetail === 'Costuras' || effDetail === 'Cremalleras Expuestas' || effDetail === 'Bolsillos Tácticos') {
    location = [
      'Frontal Central', 'Costuras Laterales', 'Diagonal en el Pecho', 'Brazos / Mangas',
      'Muslos / Cargo', 'Pantorrillas', 'Cintura', 'Glúteos / Espalda Baja'
    ];
  } else if (isAcc) {
    location = ['Cabeza / Pelo', 'Rostro / Frente', 'Oreja Derecha', 'Oreja Izquierda', 'Ojo Izquierdo', 'Ojo Derecho', 'Cuello', 'Pecho', 'Brazo Derecho', 'Brazo Izquierdo', 'Muñecas (Ambas)', 'Mano Derecha', 'Mano Izquierda', 'Dedos', 'Cintura', 'Muslo Derecho', 'Muslo Izquierdo', 'Tobillos'];
  } else if (isShoes) {
    location = ['Punta del Pie', 'Talón', 'Tobillo Lateral', 'Lengüeta', 'Caña / Media Pierna', 'Pierna Completa (Musleras)'];
  } else if (isBra || isTop) {
    location = ['Torso Completo', 'Pecho Superior', 'Bajo Busto', 'Hombros', 'Centro del Escote', 'Espalda'];
  } else if (isBottom) {
    location = ['Cintura Alta', 'Caderas / Pelvis', 'Muslos Frontal', 'Muslos Lateral', 'Rodillas', 'Pantorrillas', 'Piernas Completas'];
  }`;

data = data.replace(
  /\/\/ LOCATION \/ COVERAGE[\s\S]*?if \(isBottom\) \{\n    location = \['Cintura', 'Cadera', 'Piernas', 'Rodillas'\];\n  \}/,
  locationLogic
);

fs.writeFileSync('src/data.ts', data);
