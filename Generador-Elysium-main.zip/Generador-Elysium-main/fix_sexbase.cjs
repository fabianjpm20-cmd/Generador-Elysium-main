const fs = require('fs');
let content = fs.readFileSync('src/data.ts', 'utf8');

const match = content.match(/export const ANATOMY_DESCRIPTIONS: Record<string, string> = (\{[\s\S]*?\});/);
if (match) {
  const map = eval('(' + match[1] + ')');
  
  map["1 Hombre Normal"] = "Lienzo corporal masculino estándar. Proporciona una distribución de masa y proporciones base de hombre, sobre la cual se aplicarán los demás modificadores anatómicos sin forzar medidas ni volúmenes específicos.";
  map["2 Hombre Lindo"] = "Lienzo masculino con estética juvenil y atractiva. La presentación base es más suave que la estándar, proporcionando un aura grácil sin contradecir la complexión, facciones o altura seleccionadas.";
  map["3 Femboy/Andrógino"] = "Lienzo de presentación andrógina o ambigua. Establece una base estructural fluida que no impone ni un dimorfismo masculino severo ni uno femenino clásico, permitiendo que los otros parámetros definan la silueta final.";
  map["4 Hombre Twink/Soft Boy"] = "Lienzo masculino con estética 'soft'. Proporciona una base receptiva a curvas suaves y siluetas fluidas, ideal para combinar con diferentes complexiones sin imponer una estructura ósea rígida.";
  map["5 Hombre Casi Feminizado"] = "Lienzo masculino con fuerte inclinación a la lectura visual femenina. La base estructural mantiene una masculinidad residual pre-configurada para alojar curvas y suavidad sin contradecir los parámetros volumétricos posteriores.";
  map["6 Mujer Normal"] = "Lienzo corporal femenino estándar. Proporciona la estructura ósea base y los patrones de distribución de masa típicos de una mujer, listos para ser modelados libremente por el resto de los parámetros.";
  map["7 Mujer Hiperfeminizada"] = "Lienzo femenino con una presentación estética exagerada. Actúa como una base que acentúa de forma natural la lectura visual de la feminidad sin anular las selecciones de proporciones corporales o faciales.";

  const newStr = 'export const ANATOMY_DESCRIPTIONS: Record<string, string> = ' + JSON.stringify(map, null, 2) + ';';
  content = content.replace(/export const ANATOMY_DESCRIPTIONS: Record<string, string> = \{[\s\S]*?\};/, newStr);
  fs.writeFileSync('src/data.ts', content);
}
