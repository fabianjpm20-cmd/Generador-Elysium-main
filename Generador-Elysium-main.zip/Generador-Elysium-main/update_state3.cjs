const fs = require('fs');

let content = fs.readFileSync('src/components/State3Wardrobe.tsx', 'utf8');

// Replace imports
content = content.replace(
  /import \{ WARDROBE_CATEGORIES,[^\}]+ \} from '\.\.\/data';/,
  "import { WARDROBE_CATEGORIES, getWardrobeOptions } from '../data';"
);

// Add useEffect
const useEffectImportMatch = content.match(/import React, \{ useState([^\}]*)\} from 'react';/);
if (useEffectImportMatch && !useEffectImportMatch[0].includes('useEffect')) {
  content = content.replace(/import React, \{ useState /, 'import React, { useState, useEffect ');
}

// Add the useEffect hook inside the component
const componentStartMatch = content.match(/export const State3Wardrobe[^{]+\{/);
if (componentStartMatch) {
  const insertIndex = content.indexOf('  const [currentGarment', componentStartMatch.index);
  
  // Actually let's just insert it after the activeCategory definition
  const activeCategoryMatch = content.indexOf('  const activeCategory = WARDROBE_CATEGORIES.find(c => c.id === selectedCat) || WARDROBE_CATEGORIES[0];');
  
  const useEffectCode = `

  const activeOptions = getWardrobeOptions(selectedCat);

  useEffect(() => {
    const activeCategory = WARDROBE_CATEGORIES.find(c => c.id === selectedCat) || WARDROBE_CATEGORIES[0];
    const firstItem = activeCategory.items[0];
    const opts = getWardrobeOptions(selectedCat);
    
    setCurrentGarment({
      itemId: firstItem.id,
      name: firstItem.name,
      cut: opts.cut[0] || '',
      length: opts.length[0] || '',
      sleeve: opts.sleeve[0] || '',
      material: opts.material[0] || '',
      color: '#1A1C22',
      finish: opts.finish[0] || '',
      details: opts.details[0] || '',
      variation: opts.variation[0] || '',
      layer: opts.layer[0] || '',
    });
  }, [selectedCat]);
`;

  content = content.replace('  const activeCategory = WARDROBE_CATEGORIES.find(c => c.id === selectedCat) || WARDROBE_CATEGORIES[0];', 
    '  const activeCategory = WARDROBE_CATEGORIES.find(c => c.id === selectedCat) || WARDROBE_CATEGORIES[0];' + useEffectCode);
}

// Now replace all the CUT_OPTIONS etc. with activeOptions.cut inside the dropdowns.
content = content.replace(/\{CUT_OPTIONS.map/g, '{activeOptions.cut.map');
content = content.replace(/\{LENGTH_OPTIONS.map/g, '{activeOptions.length.map');
content = content.replace(/\{SLEEVE_OPTIONS.map/g, '{activeOptions.sleeve.map');
content = content.replace(/\{MATERIAL_OPTIONS.map/g, '{activeOptions.material.map');
content = content.replace(/\{FINISH_OPTIONS.map/g, '{activeOptions.finish.map');
content = content.replace(/\{DETAIL_OPTIONS.map/g, '{activeOptions.details.map');
content = content.replace(/\{VARIATION_OPTIONS.map/g, '{activeOptions.variation.map');
content = content.replace(/\{LAYER_OPTIONS.map/g, '{activeOptions.layer.map');

// For the divs, conditionally render them based on activeOptions properties length (or if it exists)
// e.g. for sleeve, if activeOptions.sleeve is empty, don't render it.
content = content.replace(
  /(<div>\s*<label[^>]+>1\. Corte \/ Ajuste[\s\S]*?<\/select>\s*<\/div>)/,
  '{activeOptions.cut.length > 0 && ($1)}'
);
content = content.replace(
  /(<div>\s*<label[^>]+>2\. Largo[\s\S]*?<\/select>\s*<\/div>)/,
  '{activeOptions.length.length > 0 && ($1)}'
);
content = content.replace(
  /(<div>\s*<label[^>]+>3\. Manga[\s\S]*?<\/select>\s*<\/div>)/,
  '{activeOptions.sleeve.length > 0 && ($1)}'
);

// We need to fix the initial state
content = content.replace(
  /cut: CUT_OPTIONS\[0\],\s*length: LENGTH_OPTIONS\[2\],\s*sleeve: SLEEVE_OPTIONS\[0\],\s*material: MATERIAL_OPTIONS\[0\],\s*color: '#1A1C22',\s*finish: FINISH_OPTIONS\[0\],\s*details: DETAIL_OPTIONS\[0\],\s*variation: VARIATION_OPTIONS\[0\],\s*layer: LAYER_OPTIONS\[1\]/,
  `cut: '',
    length: '',
    sleeve: '',
    material: '',
    color: '#1A1C22',
    finish: '',
    details: '',
    variation: '',
    layer: ''`
);


fs.writeFileSync('src/components/State3Wardrobe.tsx', content);

