const fs = require('fs');

const content = `import React, { useState } from 'react';
import { CharacterState } from '../types';
import { FileText, Copy, Check, Sparkles, ArrowLeft } from 'lucide-react';

interface State7Props {
  state: CharacterState;
  onBack: () => void;
}

export const State7Compilation: React.FC<State7Props> = ({ state, onBack }) => {
  const [copiedSheet, setCopiedSheet] = useState(false);

  const generateCharacterSheet = () => {
    // Función central para limpiar códigos (ej. A1, P1.1) y descartar vacíos/"Ninguno"
    const cleanVal = (val: string | undefined | null, lower = true) => {
      if (!val || /ningun/i.test(val) || /^sin\s/i.test(val) || val === '{}' || val === '[]' || val === '0') return '';
      let cleaned = val.replace(/^([A-Z0-9.\\-]+)(\\s+-\\s+|\\s+)/i, '').trim();
      return lower ? cleaned.toLowerCase() : cleaned;
    };

    const getWardrobeList = (categories: string[]) => {
      const items = state.wardrobes.filter(w => categories.includes(w.categoryId));
      return items.map(w => {
        const n = cleanVal(w.name, false);
        const m = cleanVal(w.material, true);
        return n ? \`\${n} (\${m})\` : '';
      }).filter(Boolean).join(', ');
    };

    const getArmorPieces = (prefix: string) => {
      return state.armor.pieces.filter(p => p.startsWith(prefix)).map(p => cleanVal(p.substring(5), false)).filter(Boolean).join(', ');
    };

    // Generador del prompt compacto en minúsculas y lenguaje natural
    const getDatosCompilados = () => {
      const parts: string[] = [];
      const add = (val: string | undefined | null, prefix = '') => {
        const c = cleanVal(val, true);
        if (c) parts.push(prefix ? \`\${prefix} \${c}\` : c);
      };
      
      add(state.raceName);
      add(state.role);
      add(state.styleVisual);
      if (state.archetype !== 'Genérico') add(state.archetype);
      
      add(state.anatomy.sexBase);
      add(state.anatomy.age);
      add(state.anatomy.complexion);
      add(state.anatomy.skinColor, 'piel');
      add(state.anatomy.height);
      add(state.anatomy.breastDevelopment);
      add(state.anatomy.waist);
      add(state.anatomy.glutes);
      add(state.anatomy.thighs);

      add(state.facial.headShape);
      add(state.facial.headWidth);
      add(state.facial.boneStructure);
      add(state.facial.eyeColor, 'ojos');
      add(state.facial.eyesCategory);
      add(state.facial.eyesSubtype);
      add(state.facial.iris, 'iris');
      add(state.facial.nose, 'nariz');
      add(state.facial.lips);
      add(state.facial.mouthExp);
      add(state.facial.teeth, 'dientes');
      add(state.facial.earsBase, 'orejas');
      add(state.facial.kemonoEars);

      add(state.hair.hairColor, 'cabello');
      add(state.hair.length);
      add(state.hair.texture, 'textura');
      add(state.hair.style);

      add(state.appendices.skinAndMarks);
      state.appendices.markTypes.forEach(m => add(m));

      const horns = cleanVal(state.appendices.hornsForm, true);
      if (horns) {
        parts.push(\`cuernos \${horns} \${cleanVal(state.appendices.hornsLength, true)}\`.trim());
      }
      
      const wings = cleanVal(state.appendices.wingsType, true);
      if (wings) {
        parts.push(\`alas \${wings} \${cleanVal(state.appendices.wingsSize, true)}\`.trim());
      }
      
      const tail = cleanVal(state.appendices.tailsType, true);
      if (tail) {
        parts.push(\`cola \${tail} \${cleanVal(state.appendices.tailsLength, true)}\`.trim());
      }

      state.wardrobes.forEach(w => {
        const n = cleanVal(w.name, true);
        const m = cleanVal(w.material, true);
        if (n) parts.push(\`\${n} de \${m}\`);
      });

      if (cleanVal(state.armor.type)) {
        parts.push(\`vestimenta \${cleanVal(state.armor.type, true)}\`);
        state.armor.pieces.forEach(p => add(p.substring(5)));
      }

      state.equipment.weapons.forEach(w => add(w));
      state.equipment.bags.forEach(w => add(w));
      state.equipment.items.forEach(w => add(w));

      return parts.join(', ');
    };

    const lines: string[] = [
      "# Plantilla de compilación",
      "",
      "## Personaje",
      "Nombre: "
    ];

    const age = cleanVal(state.anatomy.age, false);
    if (age) lines.push(\`Edad: \${age}\`);
    
    if (state.personality) lines.push(\`Personalidad: \${state.personality}\`);
    
    const role = cleanVal(state.role, false);
    if (role) lines.push(\`Rol: \${role}\`);
    
    if (state.archetype && state.archetype !== 'Genérico') lines.push(\`Tipo de Personaje: \${state.archetype}\`);

    lines.push("", "## Anatomía (las que tenga)", "");

    const sex = cleanVal(state.anatomy.sexBase, false);
    if (sex) lines.push(\`Sexo base: \${sex}\`);
    const comp = cleanVal(state.anatomy.complexion, false);
    if (comp) lines.push(\`Complexión: \${comp}\`);
    const height = cleanVal(state.anatomy.height, false);
    if (height) lines.push(\`Altura: \${height}\`);
    const breasts = cleanVal(state.anatomy.breastDevelopment, false);
    if (breasts) lines.push(\`Desarrollo mamario: \${breasts}\`);
    const waist = cleanVal(state.anatomy.waist, false);
    if (waist) lines.push(\`Cintura: \${waist}\`);
    const glutes = cleanVal(state.anatomy.glutes, false);
    if (glutes) lines.push(\`Gluteos: \${glutes}\`);
    const thighs = cleanVal(state.anatomy.thighs, false);
    if (thighs) lines.push(\`Muslos: \${thighs}\`);

    const headParts = [cleanVal(state.facial.headShape, false), cleanVal(state.facial.headWidth, false), cleanVal(state.facial.boneStructure, false)].filter(Boolean);
    if (headParts.length) lines.push(\`\\nCabeza: \${headParts.join(', ')}\`);
    
    const eyeParts = [cleanVal(state.facial.eyeColor, false), cleanVal(state.facial.eyesCategory, false), cleanVal(state.facial.eyesSubtype, false)].filter(Boolean);
    if (eyeParts.length) lines.push(\`Ojos: \${eyeParts.join(', ')}\`);
    
    const iris = cleanVal(state.facial.iris, false);
    if (iris) lines.push(\`Iris: \${iris}\`);
    const nose = cleanVal(state.facial.nose, false);
    if (nose) lines.push(\`Nariz: \${nose}\`);
    
    const mouthParts = [cleanVal(state.facial.lips, false), cleanVal(state.facial.mouthExp, false), cleanVal(state.facial.teeth, false)].filter(Boolean);
    if (mouthParts.length) lines.push(\`Boca: \${mouthParts.join(', ')}\`);
    
    const earParts = [cleanVal(state.facial.earsBase, false), cleanVal(state.facial.kemonoEars, false)].filter(Boolean);
    if (earParts.length) lines.push(\`Orejas: \${earParts.join(', ')}\`);

    const hairParts = [cleanVal(state.hair.hairColor, false), cleanVal(state.hair.style, false), cleanVal(state.hair.length, false), cleanVal(state.hair.texture, false)].filter(Boolean);
    if (hairParts.length) lines.push(\`\\nCabello: \${hairParts.join(', ')}\`);

    const skin = cleanVal(state.anatomy.skinColor, false);
    if (skin) lines.push(\`\\nPiel: \${skin}\`);
    
    const marks = [cleanVal(state.appendices.skinAndMarks, false), ...state.appendices.markTypes.map(m => cleanVal(m, false))].filter(Boolean);
    if (marks.length) lines.push(\`Marcas: \${marks.join(', ')}\`);

    const horns = cleanVal(state.appendices.hornsForm, false);
    const wings = cleanVal(state.appendices.wingsType, false);
    const tail = cleanVal(state.appendices.tailsType, false);
    
    if (horns || wings || tail) {
      lines.push("", "Apendices extras:");
      if (horns) {
        const hL = cleanVal(state.appendices.hornsLength, false);
        lines.push(\`- cuernos: \${horns}\${hL ? \` (\${hL})\` : ''}\`);
      }
      if (wings) {
         const wS = cleanVal(state.appendices.wingsSize, false);
         lines.push(\`- Alas: \${wings}\${wS ? \` (\${wS})\` : ''}\`);
      }
      if (tail) {
         const tL = cleanVal(state.appendices.tailsLength, false);
         lines.push(\`- Cola: \${tail}\${tL ? \` (\${tL})\` : ''}\`);
      }
    }

    const wOne = getWardrobeList(['B0']);
    const wTop = getWardrobeList(['B1', 'B12']);
    const wSec = getWardrobeList(['B2']);
    const wBot = getWardrobeList(['B3']);
    const wInt = getWardrobeList(['B4']);
    const wShoe = getWardrobeList(['B5']);
    
    if (wOne || wTop || wSec || wBot || wInt || wShoe) {
      lines.push("", "## Vestuario (las que use)");
      if (wOne) lines.push(\`Una pieza: \${wOne}\`);
      if (wTop) lines.push(\`Superior: \${wTop}\`);
      if (wSec) lines.push(\`Secundaria: \${wSec}\`);
      if (wBot) lines.push(\`Inferior: \${wBot}\`);
      if (wInt) lines.push(\`Interior: \${wInt}\`);
      if (wShoe) lines.push(\`Calzado: \${wShoe}\`);
    }

    const armorType = cleanVal(state.armor.type, false);
    const p1 = getArmorPieces('P1');
    const p2 = getArmorPieces('P2');
    const p3 = getArmorPieces('P3');
    const p4 = getArmorPieces('P4');
    const p5 = getArmorPieces('P5');
    const p6 = getArmorPieces('P6');
    const p7 = getArmorPieces('P7');
    const weapons = state.equipment.weapons.map(w => cleanVal(w, false)).filter(Boolean);
    const bags = state.equipment.bags.map(b => cleanVal(b, false)).filter(Boolean);
    const items = state.equipment.items.map(i => cleanVal(i, false)).filter(Boolean);

    if (armorType || p1 || p2 || p3 || p4 || p5 || p6 || p7 || weapons.length || bags.length || items.length) {
      lines.push("", "### Armaduras/ropas especiales: (si es que los usa)");
      if (armorType) lines.push(\`- Base: \${armorType}\`);
      if (p1) lines.push(\`- Yelmo/Casco: \${p1}\`);
      if (p2) lines.push(\`- Peto/Coraza: \${p2}\`);
      if (p3) lines.push(\`- Espaldares/Proteccion de espalda: \${p3}\`);
      if (p4) lines.push(\`- Brazales/Guanteletes: \${p4}\`);
      if (p5) lines.push(\`- Faldon/Cinturon de armas: \${p5}\`);
      if (p6) lines.push(\`- Grebas/Proteccion de piernas: \${p6}\`);
      if (p7) lines.push(\`- Botas/Calzados de armaduras: \${p7}\`);
      if (weapons.length) lines.push(\`- Armas: \${weapons.join(', ')}\`);
      if (bags.length) lines.push(\`- Bolsos: \${bags.join(', ')}\`);
      if (items.length) lines.push(\`- item´s y objetos personales: \${items.join(', ')}\`);
    }

    const bg = state.background.backstory?.trim();
    if (bg) {
      lines.push("", "### Antecedentes", \`Historia: \${bg}\`);
    }

    lines.push(
      "",
      "## Prompt de estilo:[contemporary anime digital illustration, manhwa visual novel aesthetic, otome gacha character art, fine variable linework, thicker outer silhouette contour, soft inner lines, low to moderate color saturation, muted palette, clean silhouette, 4k resolution, sharp focus.]",
      "+",
      \`[\${getDatosCompilados()}]\`,
      "+",
      "## Negative Prompt:[photorealistic, western comic style, hyperrealistic anatomy, heavy black clothing outlines, 3D render, oversaturated colors, noisy texture, blurry, low resolution, western cartoon, low quality, blurry, deformed hands, deformed feet, bad anatomy, extra limbs, watermark, logo, ugly, disfigured, poor lighting, oversaturated, grainy]"
    );

    return lines.join('\\n');
  };

  const characterSheet = generateCharacterSheet();

  const handleCopy = () => {
    navigator.clipboard.writeText(characterSheet);
    setCopiedSheet(true);
    setTimeout(() => setCopiedSheet(false), 2000);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="bg-[#0F1115] border border-[#222222] rounded-3xl p-8 text-[#E0E0E0] shadow-xl mb-8 relative">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-[#1A1C22] border border-[#2A2D35] text-[#C9A050] text-xs font-medium mb-4">
          <FileText className="w-3.5 h-3.5 text-[#C9A050]" />
          <span>ESTADO 7: FICHA DE PERSONAJE</span>
        </div>
        <h2 className="text-3xl font-serif italic text-[#C9A050] tracking-tight mb-2">
          Ficha Técnica del Personaje
        </h2>
        <p className="text-[#888888] text-sm leading-relaxed">
          Personaje compilado con éxito. Copia la plantilla final con todos los datos seleccionados.
        </p>
      </div>

      <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs space-y-6">
        <div className="flex justify-between items-center border-b border-[#222222] pb-3">
          <h3 className="text-lg font-serif italic text-[#C9A050] flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#C9A050]" />
            <span>Ficha de Personaje Generada</span>
          </h3>
          <button
            onClick={handleCopy}
            className="flex items-center space-x-2 text-sm font-semibold text-[#0A0B0E] bg-[#C9A050] hover:bg-[#b58e45] px-4 py-2 rounded-lg transition-all shadow-md"
          >
            {copiedSheet ? <Check className="w-4 h-4 text-[#0A0B0E]" /> : <Copy className="w-4 h-4" />}
            <span>{copiedSheet ? 'Copiada!' : 'Copiar Ficha'}</span>
          </button>
        </div>
        
        <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-6 text-sm font-mono text-[#E0E0E0] select-all leading-relaxed whitespace-pre-wrap overflow-x-auto">
          {characterSheet}
        </div>
      </div>

      <div className="mt-10 flex justify-start">
        <button
          onClick={onBack}
          className="bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] text-[#E0E0E0] px-6 py-3 rounded-xl font-semibold text-sm flex items-center space-x-2 transition-all cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Volver a Edición</span>
        </button>
      </div>
    </div>
  );
};
`;

fs.writeFileSync('src/components/State7Compilation.tsx', content);
