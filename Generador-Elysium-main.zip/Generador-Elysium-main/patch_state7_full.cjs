const fs = require('fs');

const content = `import React, { useState } from 'react';
import { CharacterState } from '../types';
import { FileText, Copy, Check, Sparkles, ArrowLeft } from 'lucide-react';

interface State7Props {
  state: CharacterState;
  onBack: () => void;
}

export const State7Compilation: React.FC<State7Props> = ({ state, onBack }) => {
  const [copiedSheet, setCopiedSheet] = useState(false);

  const generateCharacterSheet = () => {
    // Función central para limpiar códigos (ej. A1, P1.1) y descartar vacíos/"Ninguno"
    const cleanVal = (val: string | undefined | null, lower = true) => {
      if (!val || /ningun/i.test(val) || /^sin\\s/i.test(val) || val === '{}' || val === '[]' || val === '0') return '';
      let cleaned = val.replace(/^([A-Z0-9.\\-]+)(\\s+-\\s+|\\s+)/i, '').trim();
      return lower ? cleaned.toLowerCase() : cleaned;
    };

    const buildPart = (label: string, val: string | undefined | null, lower = true) => {
       const c = cleanVal(val, lower);
       return c ? \`\${label} \${c}\` : '';
    };

    // --- Definición de bloques de características para unificar Ficha y Prompt ---

    const bodyParts = [
      buildPart('sexo', state.anatomy.sexBase, false),
      buildPart('complexión', state.anatomy.complexion, false),
      buildPart('altura', state.anatomy.height, false),
      buildPart('desarrollo mamario', state.anatomy.breastDevelopment, false),
      buildPart('cintura', state.anatomy.waist, false),
      buildPart('glúteos', state.anatomy.glutes, false),
      buildPart('muslos', state.anatomy.thighs, false)
    ].filter(Boolean);

    const headParts = [
      buildPart('forma', state.facial.headShape, false),
      buildPart('anchura', state.facial.headWidth, false),
      buildPart('estructura', state.facial.boneStructure, false)
    ].filter(Boolean);
    
    const eyeParts = [
      buildPart('color', state.facial.eyeColor, false),
      buildPart('forma', state.facial.eyesCategory, false),
      buildPart('tipo', state.facial.eyesSubtype, false)
    ].filter(Boolean);
    
    const mouthParts = [
      buildPart('labios', state.facial.lips, false),
      buildPart('expresión', state.facial.mouthExp, false),
      buildPart('dientes', state.facial.teeth, false)
    ].filter(Boolean);
    
    const earParts = [
      buildPart('tipo', state.facial.earsBase, false),
      buildPart('especial', state.facial.kemonoEars, false)
    ].filter(Boolean);

    const hairParts = [
      buildPart('color', state.hair.hairColor, false),
      buildPart('largo', state.hair.length, false),
      buildPart('textura', state.hair.texture, false),
      buildPart('estilo', state.hair.style, false)
    ].filter(Boolean);

    const skin = buildPart('color', state.anatomy.skinColor, false);
    const marks = [cleanVal(state.appendices.skinAndMarks, false), ...state.appendices.markTypes.map(m => cleanVal(m, false))].filter(Boolean);

    const horns = cleanVal(state.appendices.hornsForm, false);
    const wings = cleanVal(state.appendices.wingsType, false);
    const tail = cleanVal(state.appendices.tailsType, false);

    const getWardrobeList = (categories: string[]) => {
      const items = state.wardrobes.filter(w => categories.includes(w.categoryId));
      return items.map(w => {
        const n = cleanVal(w.name, false);
        const m = cleanVal(w.material, false);
        return n ? \`prenda \${n}\${m ? \`, material \${m}\` : ''}\` : '';
      }).filter(Boolean).join('; ');
    };

    const wOne = getWardrobeList(['B0']);
    const wTop = getWardrobeList(['B1', 'B12']);
    const wSec = getWardrobeList(['B2']);
    const wBot = getWardrobeList(['B3']);
    const wInt = getWardrobeList(['B4']);
    const wShoe = getWardrobeList(['B5']);

    const getArmorPieces = (prefix: string) => {
      return state.armor.pieces.filter(p => p.startsWith(prefix)).map(p => cleanVal(p.substring(5), false)).filter(Boolean).join(', ');
    };
    const armorType = cleanVal(state.armor.type, false);
    const p1 = getArmorPieces('P1');
    const p2 = getArmorPieces('P2');
    const p3 = getArmorPieces('P3');
    const p4 = getArmorPieces('P4');
    const p5 = getArmorPieces('P5');
    const p6 = getArmorPieces('P6');
    const p7 = getArmorPieces('P7');

    const weapons = state.equipment.weapons.map(w => cleanVal(w, false)).filter(Boolean);
    const bags = state.equipment.bags.map(b => cleanVal(b, false)).filter(Boolean);
    const items = state.equipment.items.map(i => cleanVal(i, false)).filter(Boolean);

    // --- CONSTRUCCIÓN DE LA FICHA VISUAL ---
    const lines: string[] = [
      "# Plantilla de compilación",
      "",
      "## Personaje",
      "Nombre: "
    ];

    const race = cleanVal(state.raceName, false);
    if (race) lines.push(\`Raza: \${race}\`);
    const age = cleanVal(state.anatomy.age, false);
    if (age) lines.push(\`Edad: \${age}\`);
    if (state.personality) lines.push(\`Personalidad: \${state.personality}\`);
    const role = cleanVal(state.role, false);
    if (role) lines.push(\`Rol: \${role}\`);
    if (state.archetype && state.archetype !== 'Genérico') lines.push(\`Tipo de Personaje: \${state.archetype}\`);
    const style = cleanVal(state.styleVisual, false);
    if (style) lines.push(\`Estilo visual: \${style}\`);

    lines.push("", "## Anatomía");
    if (bodyParts.length) lines.push(\`Cuerpo: \${bodyParts.join(', ')}\`);
    
    if (headParts.length) lines.push(\`Cabeza: \${headParts.join(', ')}\`);
    if (eyeParts.length) lines.push(\`Ojos: \${eyeParts.join(', ')}\`);
    const iris = cleanVal(state.facial.iris, false);
    if (iris) lines.push(\`Iris: forma \${iris}\`);
    const nose = cleanVal(state.facial.nose, false);
    if (nose) lines.push(\`Nariz: forma \${nose}\`);
    if (mouthParts.length) lines.push(\`Boca: \${mouthParts.join(', ')}\`);
    if (earParts.length) lines.push(\`Orejas: \${earParts.join(', ')}\`);
    
    if (hairParts.length) lines.push(\`Cabello: \${hairParts.join(', ')}\`);
    
    if (skin) lines.push(\`Piel: \${skin}\`);
    if (marks.length) lines.push(\`Marcas: \${marks.join(', ')}\`);

    if (horns || wings || tail) {
      lines.push("", "## Apéndices extras");
      if (horns) {
        const hL = cleanVal(state.appendices.hornsLength, false);
        lines.push(\`- Cuernos: forma \${horns}\${hL ? \`, longitud \${hL}\` : ''}\`);
      }
      if (wings) {
         const wS = cleanVal(state.appendices.wingsSize, false);
         lines.push(\`- Alas: tipo \${wings}\${wS ? \`, tamaño \${wS}\` : ''}\`);
      }
      if (tail) {
         const tL = cleanVal(state.appendices.tailsLength, false);
         lines.push(\`- Cola: tipo \${tail}\${tL ? \`, longitud \${tL}\` : ''}\`);
      }
    }

    if (wOne || wTop || wSec || wBot || wInt || wShoe) {
      lines.push("", "## Vestuario");
      if (wOne) lines.push(\`- Una pieza: \${wOne}\`);
      if (wTop) lines.push(\`- Superior: \${wTop}\`);
      if (wSec) lines.push(\`- Secundaria: \${wSec}\`);
      if (wBot) lines.push(\`- Inferior: \${wBot}\`);
      if (wInt) lines.push(\`- Interior: \${wInt}\`);
      if (wShoe) lines.push(\`- Calzado: \${wShoe}\`);
    }

    if (armorType || p1 || p2 || p3 || p4 || p5 || p6 || p7 || weapons.length || bags.length || items.length) {
      lines.push("", "### Armaduras y ropas especiales:");
      if (armorType) lines.push(\`- Armadura base: tipo \${armorType}\`);
      if (p1) lines.push(\`- Yelmo/Casco: pieza \${p1}\`);
      if (p2) lines.push(\`- Peto/Coraza: pieza \${p2}\`);
      if (p3) lines.push(\`- Espaldares: pieza \${p3}\`);
      if (p4) lines.push(\`- Brazales/Guanteletes: pieza \${p4}\`);
      if (p5) lines.push(\`- Faldon/Cinturon: pieza \${p5}\`);
      if (p6) lines.push(\`- Grebas: pieza \${p6}\`);
      if (p7) lines.push(\`- Botas: pieza \${p7}\`);
      if (weapons.length) lines.push(\`- Armas: \${weapons.map(w => \`arma \${w}\`).join(', ')}\`);
      if (bags.length) lines.push(\`- Bolsos: \${bags.map(b => \`bolso \${b}\`).join(', ')}\`);
      if (items.length) lines.push(\`- Objetos: \${items.map(i => \`objeto \${i}\`).join(', ')}\`);
    }

    const bg = state.background.backstory?.trim();
    if (bg) {
      lines.push("", "### Antecedentes", \`Historia: \${bg}\`);
    }

    // --- CONSTRUCCIÓN DEL PROMPT COMPACTO EN MINÚSCULAS ---
    const getDatosCompilados = () => {
      const parts: string[] = [];
      const add = (str: string) => { if (str) parts.push(str.toLowerCase()); };
      
      add(buildPart('raza', state.raceName || 'humano', false));
      add(buildPart('rol', state.role, false));
      add(buildPart('estilo visual', state.styleVisual, false));
      if (state.archetype && state.archetype !== 'Genérico') add(buildPart('arquetipo', state.archetype, false));

      if (bodyParts.length) parts.push(\`cuerpo: \${bodyParts.join(', ').toLowerCase()}\`);
      if (headParts.length) parts.push(\`cabeza: \${headParts.join(', ').toLowerCase()}\`);
      if (eyeParts.length) parts.push(\`ojos: \${eyeParts.join(', ').toLowerCase()}\`);
      if (iris) parts.push(\`iris: forma \${iris.toLowerCase()}\`);
      if (nose) parts.push(\`nariz: forma \${nose.toLowerCase()}\`);
      if (mouthParts.length) parts.push(\`boca: \${mouthParts.join(', ').toLowerCase()}\`);
      if (earParts.length) parts.push(\`orejas: \${earParts.join(', ').toLowerCase()}\`);
      if (hairParts.length) parts.push(\`cabello: \${hairParts.join(', ').toLowerCase()}\`);
      if (skin) parts.push(\`piel: \${skin.toLowerCase()}\`);
      if (marks.length) parts.push(\`marcas: \${marks.join(', ').toLowerCase()}\`);
      
      if (horns) {
        const hL = cleanVal(state.appendices.hornsLength, true);
        parts.push(\`cuernos: forma \${horns.toLowerCase()}\${hL ? \`, longitud \${hL}\` : ''}\`);
      }
      if (wings) {
        const wS = cleanVal(state.appendices.wingsSize, true);
        parts.push(\`alas: tipo \${wings.toLowerCase()}\${wS ? \`, tamaño \${wS}\` : ''}\`);
      }
      if (tail) {
        const tL = cleanVal(state.appendices.tailsLength, true);
        parts.push(\`cola: tipo \${tail.toLowerCase()}\${tL ? \`, longitud \${tL}\` : ''}\`);
      }

      const allWardrobes = [wOne, wTop, wSec, wBot, wInt, wShoe].filter(Boolean);
      if (allWardrobes.length) {
        parts.push(\`vestimenta: \${allWardrobes.join('; ').toLowerCase()}\`);
      }

      if (armorType) parts.push(\`armadura base: tipo \${armorType.toLowerCase()}\`);
      [p1, p2, p3, p4, p5, p6, p7].filter(Boolean).forEach(p => {
         parts.push(\`pieza de armadura: \${p.toLowerCase()}\`);
      });
      
      weapons.forEach(w => parts.push(\`arma: \${cleanVal(w, true)}\`));
      bags.forEach(b => parts.push(\`bolso: \${cleanVal(b, true)}\`));
      items.forEach(i => parts.push(\`objeto: \${cleanVal(i, true)}\`));

      return parts.join(', ');
    };

    lines.push(
      "",
      "## Prompt de estilo:[contemporary anime digital illustration, manhwa visual novel aesthetic, otome gacha character art, fine variable linework, thicker outer silhouette contour, soft inner lines, low to moderate color saturation, muted palette, clean silhouette, 4k resolution, sharp focus.]",
      "+",
      \`[\${getDatosCompilados()}]\`,
      "+",
      "## Negative Prompt:[photorealistic, western comic style, hyperrealistic anatomy, heavy black clothing outlines, 3D render, oversaturated colors, noisy texture, blurry, low resolution, western cartoon, low quality, blurry, deformed hands, deformed feet, bad anatomy, extra limbs, watermark, logo, ugly, disfigured, poor lighting, oversaturated, grainy]"
    );

    return lines.join('\\n');
  };

  const characterSheet = generateCharacterSheet();

  const handleCopy = () => {
    navigator.clipboard.writeText(characterSheet);
    setCopiedSheet(true);
    setTimeout(() => setCopiedSheet(false), 2000);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="bg-[#0F1115] border border-[#222222] rounded-3xl p-8 text-[#E0E0E0] shadow-xl mb-8 relative">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-[#1A1C22] border border-[#2A2D35] text-[#C9A050] text-xs font-medium mb-4">
          <FileText className="w-3.5 h-3.5 text-[#C9A050]" />
          <span>ESTADO 7: FICHA DE PERSONAJE</span>
        </div>
        <h2 className="text-3xl font-serif italic text-[#C9A050] tracking-tight mb-2">
          Ficha Técnica del Personaje
        </h2>
        <p className="text-[#888888] text-sm leading-relaxed">
          Personaje compilado con éxito. Copia la plantilla final con todos los datos seleccionados.
        </p>
      </div>

      <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs space-y-6">
        <div className="flex justify-between items-center border-b border-[#222222] pb-3">
          <h3 className="text-lg font-serif italic text-[#C9A050] flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#C9A050]" />
            <span>Ficha de Personaje Generada</span>
          </h3>
          <button
            onClick={handleCopy}
            className="flex items-center space-x-2 text-sm font-semibold text-[#0A0B0E] bg-[#C9A050] hover:bg-[#b58e45] px-4 py-2 rounded-lg transition-all shadow-md"
          >
            {copiedSheet ? <Check className="w-4 h-4 text-[#0A0B0E]" /> : <Copy className="w-4 h-4" />}
            <span>{copiedSheet ? 'Copiada!' : 'Copiar Ficha'}</span>
          </button>
        </div>
        
        <div className="bg-[#15171C] border border-[#2A2D35] rounded-xl p-6 text-sm font-mono text-[#E0E0E0] select-all leading-relaxed whitespace-pre-wrap overflow-x-auto">
          {characterSheet}
        </div>
      </div>

      <div className="mt-10 flex justify-start">
        <button
          onClick={onBack}
          className="bg-[#15171C] hover:bg-[#1A1C22] border border-[#2A2D35] text-[#E0E0E0] px-6 py-3 rounded-xl font-semibold text-sm flex items-center space-x-2 transition-all cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Volver a Edición</span>
        </button>
      </div>
    </div>
  );
};
`;

fs.writeFileSync('src/components/State7Compilation.tsx', content);
