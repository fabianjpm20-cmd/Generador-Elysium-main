const fs = require('fs');
let data = fs.readFileSync('src/components/State7Compilation.tsx', 'utf8');

data = data.replace('## Anatomía (las que tenga)', '## Anatomía');
data = data.replace('## Vestuario (las que use)', '## Vestuario');
data = data.replace('### Armaduras/ropas especiales: (si es que los usa)', '### Armaduras y ropas especiales:');

fs.writeFileSync('src/components/State7Compilation.tsx', data);
