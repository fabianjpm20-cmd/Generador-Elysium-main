const fs = require('fs');
let data = fs.readFileSync('src/App.tsx', 'utf8');

data = data.replace(/skinMarksLocation: '',\n\s*skinMarksColor: '',\n\s*markType: 'Ninguna',\n\s*markShape: 'Geometría: Líneas Rectas Paralelas'/, 
`markTypes: [],
      markLocations: {},
      markShapes: {},
      markColors: {}`);

fs.writeFileSync('src/App.tsx', data);
