const fs = require('fs');
let data = fs.readFileSync('src/data.ts', 'utf8');

const locationLogic = `  // LOCATION MAP (Per Detail)
  let locationMap: Record<string, string[]> = {};
  
  for (const effDetail of details) {
    let locs: string[] = [];
    if (effDetail === 'Lazos' || effDetail === 'Cintas' || effDetail === 'Cordones / Corsetería') {
      locs = ['Cuello / Gargantilla', 'Hombros (Ambos)', 'Hombro Izquierdo', 'Hombro Derecho', 
      'Escote / Busto Frontal', 'Cintura Frontal', 'Cintura Lateral', 'Espalda Alta', 
      'Espalda Baja / Corsé', 'Puños / Muñecas', 'Dobladillo Inferior', 'Muslos (Ligas)', 'Tobillos'];
    } else if (effDetail === 'Transparencias' || effDetail === 'Encajes' || effDetail === 'Aberturas / Cortes (Cut-outs)') {
      locs = ['Cobertura Total', 'Paneles Laterales (Costados)', 'Escote / Pecho', 'Busto (Underboob/Sideboob)',
      'Vientre / Abdomen', 'Espalda Completa', 'Espalda Baja', 'Sólo Mangas', 
      'Hombros Descubiertos', 'Muslo Lateral', 'Rodillas', 'Caderas (High-cut)'];
    } else if (effDetail === 'Bordados' || effDetail === 'Parches' || effDetail === 'Lentejuelas / Pedrería' || effDetail === 'Plumas') {
      locs = ['Pecho Central', 'Espalda Central', 'Solapas / Cuello', 'Hombros / Hombreras',
      'Mangas (Lado Exterior)', 'Puños', 'Borde Inferior / Dobladillo', 'Bolsillos Frontales',
      'Disperso por toda la prenda', 'Rodillas', 'Costuras Laterales'];
    } else if (effDetail === 'Hebillas' || effDetail === 'Cinturones' || effDetail === 'Tachuelas' || effDetail === 'Cadenas' || effDetail === 'Cadenas Colgantes' || effDetail === 'Remaches') {
      locs = ['Cuello (Gargantilla)', 'Hombros / Charreteras', 'Pecho (Arnés cruzado)', 'Pecho (Horizontal)',
      'Bajo Busto (Underbust)', 'Cintura Frontal', 'Cintura (Cinturón caído)', 'Caderas', 
      'Brazos (Bíceps)', 'Muñecas', 'Muslo Derecho', 'Muslo Izquierdo', 'Rodillas', 'Botas / Tobillos'];
    } else if (effDetail === 'Pliegues' || effDetail === 'Volantes' || effDetail === 'Flecos') {
      locs = ['Cuello / Gorguera', 'Mangas / Puños', 'Pecho / Cascada Frontal', 'Cintura / Peplum',
      'Borde Inferior / Dobladillo', 'A lo largo de las mangas', 'Espalda Baja', 'Asimétrico (Diagonal)'];
    } else if (effDetail === 'Grabados' || effDetail === 'Costuras' || effDetail === 'Cremalleras Expuestas' || effDetail === 'Bolsillos Tácticos') {
      locs = ['Frontal Central', 'Costuras Laterales', 'Diagonal en el Pecho', 'Brazos / Mangas',
      'Muslos / Cargo', 'Pantorrillas', 'Cintura', 'Glúteos / Espalda Baja'];
    }
    if (locs.length > 0) {
      locationMap[effDetail] = locs;
    }
  }

  let location: string[] = [];
  if (isAcc) {
    location = ['Cabeza / Pelo', 'Rostro / Frente', 'Oreja Derecha', 'Oreja Izquierda', 'Ojo Izquierdo', 'Ojo Derecho', 'Cuello', 'Pecho', 'Brazo Derecho', 'Brazo Izquierdo', 'Muñecas (Ambas)', 'Mano Derecha', 'Mano Izquierda', 'Dedos', 'Cintura', 'Muslo Derecho', 'Muslo Izquierdo', 'Tobillos'];
  } else if (isShoes) {
    location = ['Punta del Pie', 'Talón', 'Tobillo Lateral', 'Lengüeta', 'Caña / Media Pierna', 'Pierna Completa (Musleras)'];
  } else if (isBra || isTop) {
    location = ['Torso Completo', 'Pecho Superior', 'Bajo Busto', 'Hombros', 'Centro del Escote', 'Espalda'];
  } else if (isBottom) {
    location = ['Cintura Alta', 'Caderas / Pelvis', 'Muslos Frontal', 'Muslos Lateral', 'Rodillas', 'Pantorrillas', 'Piernas Completas'];
  }`;

data = data.replace(
  /\/\/ LOCATION \/ COVERAGE[\s\S]*?let location = Array\.from\(locationSet\);/,
  locationLogic
);

data = data.replace(
  /return \{ cut, length, sleeve, material, finish, details, variation, layer, location, pattern, emblem, vfx, neckline \};/,
  "return { cut, length, sleeve, material, finish, details, variation, layer, location, locationMap, pattern, emblem, vfx, neckline };"
);

fs.writeFileSync('src/data.ts', data);
