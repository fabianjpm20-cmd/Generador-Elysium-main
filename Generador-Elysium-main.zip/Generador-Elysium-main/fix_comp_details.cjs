const fs = require('fs');
let data = fs.readFileSync('src/components/State6Compilation.tsx', 'utf8');

data = data.replace(
  /w\.details \? \`Details: \$\{cleanVal\(w\.details\)\}\$\{\(w\.location && w\.location\.length \> 0\) \? ' \(' \+ \(Array\.isArray\(w\.location\) \? w\.location\.map\(cleanVal\)\.join\(', '\) : cleanVal\(w\.location\)\) \+ '\)' : ''\}\` : '',/,
  "(w.details && w.details.length > 0) ? `Details: ${(Array.isArray(w.details) ? w.details.map(cleanVal).join(', ') : cleanVal(w.details))}${(w.location && w.location.length > 0) ? ' (' + (Array.isArray(w.location) ? w.location.map(cleanVal).join(', ') : cleanVal(w.location)) + ')' : ''}` : '',"
);

fs.writeFileSync('src/components/State6Compilation.tsx', data);
