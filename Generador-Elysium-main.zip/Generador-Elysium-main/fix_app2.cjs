const fs = require('fs');
let data = fs.readFileSync('src/App.tsx', 'utf8');

data = data.replace(
  /skinMarksLocation: '',\n      skinMarksColor: ''/,
  "skinMarksLocation: '',\n      skinMarksColor: '',\n      markType: 'Ninguna',\n      markShape: 'S1 Líneas y Geometría'"
);

fs.writeFileSync('src/App.tsx', data);
