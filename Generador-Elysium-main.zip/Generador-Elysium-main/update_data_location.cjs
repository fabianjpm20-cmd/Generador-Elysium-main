const fs = require('fs');
let data = fs.readFileSync('src/data.ts', 'utf8');

data = data.replace(
  /export function getWardrobeOptions\(categoryId: string, itemId: string = '', itemName: string = ''\) \{/,
  "export function getWardrobeOptions(categoryId: string, itemId: string = '', itemName: string = '', currentDetail: string = '') {"
);

const locationLogic = `
  // LOCATION / COVERAGE (Now heavily dependent on the chosen detail)
  let location: string[] = [];
  
  if (currentDetail === 'Lazos' || currentDetail === 'Cintas') {
    location = ['En el pecho/escote', 'En los hombros', 'En la cintura/cadera', 'En la espalda', 'En los puños/tobillos', 'Asimétrico (Un lado)'];
  } else if (currentDetail === 'Transparencias' || currentDetail === 'Encajes') {
    location = ['Cobertura Completa (Total)', 'Sólo Mangas / Extremidades', 'Escote / Pecho', 'Costados / Ribetes', 'Espalda descubierta', 'Paneles asimétricos'];
  } else if (currentDetail === 'Bordados' || currentDetail === 'Parches') {
    location = ['Frontal central', 'En la espalda', 'En las extremidades', 'Bordes y Dobladillos', 'Esparcido / Patrón Completo'];
  } else if (currentDetail === 'Hebillas' || currentDetail === 'Cinturones' || currentDetail === 'Tachuelas' || currentDetail === 'Cadenas') {
    location = ['Frontal / Torso', 'Cintura / Cadera', 'Hombros / Charreteras', 'Brazos / Puños', 'Piernas / Muslos', 'Tobillos / Calzado'];
  } else if (currentDetail === 'Pliegues' || currentDetail === 'Volantes') {
    location = ['Cuello / Escote', 'Mangas / Puños', 'Borde / Dobladillo inferior', 'Frente completo', 'Cascada asimétrica'];
  } else if (currentDetail === 'Grabados' || currentDetail === 'Costuras') {
    location = ['Bordes y Contornos', 'Centro y Foco', 'Toda la superficie', 'Zonas de articulación'];
  } else if (isAcc) {
    location = ['Cabeza / Pelo', 'Rostro', 'Orejas', 'Cuello', 'Pecho', 'Brazos', 'Muñecas', 'Manos', 'Cintura', 'Piernas', 'Tobillos'];
  } else if (isShoes) {
    location = ['Pies', 'Tobillos', 'Media Pierna', 'Pierna Completa (Musleras)'];
  }
`;

data = data.replace(
  /\/\/ LOCATION[\s\S]*?if \(isAcc\) location = \['Cabeza', 'Cuello', 'Pecho', 'Brazos', 'Muñecas', 'Manos', 'Cintura', 'Piernas', 'Tobillos'\];/,
  locationLogic.trim()
);

fs.writeFileSync('src/data.ts', data);
