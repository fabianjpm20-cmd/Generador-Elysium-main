const fs = require('fs');
let data = fs.readFileSync('src/data.ts', 'utf8');

const newShapes = `
export const MARK_SHAPES = [
  // Geométricos
  'Geometría: Líneas Rectas Paralelas',
  'Geometría: Círculos Concéntricos',
  'Geometría: Triángulos Entrelazados',
  'Geometría: Hexágonos (Panal)',
  'Geometría: Espiral',
  'Geometría: Mandala',
  // Bestias Míticas
  'Mítico: Dragón Oriental',
  'Mítico: Dragón Occidental',
  'Mítico: Fénix',
  'Mítico: Zorro de Nueve Colas (Kitsune)',
  'Mítico: Demonio (Oni)',
  // Animales
  'Animal: Lobo',
  'Animal: Serpiente',
  'Animal: León',
  'Animal: Tigre',
  'Animal: Gato',
  'Animal: Cuervo',
  'Animal: Águila',
  'Animal: Búho',
  'Animal: Pez Koi',
  // Insectos / Arácnidos
  'Insecto: Mariposa',
  'Insecto: Polilla',
  'Arácnido: Araña',
  'Arácnido: Escorpión',
  // Naturaleza y Elementos
  'Botánico: Rosa (Flor)',
  'Botánico: Flor de Loto',
  'Botánico: Flor de Cerezo (Sakura)',
  'Botánico: Enredadera de Espinas',
  'Botánico: Árbol Seco',
  'Botánico: Hojas de Arce',
  'Elemento: Llamas de Fuego',
  'Elemento: Humo Ondulante',
  'Elemento: Gotas de Agua',
  'Elemento: Olas de Mar',
  'Elemento: Lágrima (Bajo el ojo)',
  // Celestial
  'Celestial: Sol Radiante',
  'Celestial: Luna Creciente',
  'Celestial: Fases Lunares',
  'Celestial: Estrella de 5 Puntas',
  'Celestial: Estrella de 4 Puntas',
  'Celestial: Constelación Específica',
  // Símbolos Oscuros
  'Símbolo: Cráneo Humano',
  'Símbolo: Ojo Abierto / Ojo que todo lo ve',
  'Símbolo: Telaraña',
  'Símbolo: Murciélago',
  'Símbolo: Pentagrama',
  'Símbolo: Cruz',
  // Armas y Objetos
  'Objeto: Espada Cruzada',
  'Objeto: Daga',
  'Objeto: Corona',
  'Objeto: Cadenas',
  'Objeto: Ancla',
  'Objeto: Reloj de Arena',
  // Alas (Como tatuaje o marca gráfica)
  'Alas: Alas de Ángel (Plumas)',
  'Alas: Alas de Demonio (Murciélago)',
  // Textos y Patrones
  'Texto: Runas Nórdicas',
  'Texto: Caracteres Kanji',
  'Texto: Escritura Élfica',
  'Texto: Números Romanos',
  'Texto: Código de Barras',
  'Tecnología: Placa de Circuitos / PCB',
  'Tecnología: Código Binario',
  // Daños Físicos (Para cicatrices, etc.)
  'Daño: Rasguños de Garras (3-4 líneas)',
  'Daño: Grietas (como porcelana rota)',
  'Daño: Salpicadura / Mancha Irregular',
  'Daño: Quemadura Extensa'
];
`;

data = data.replace(
  /export const MARK_SHAPES = \[[^\]]*?\];/,
  newShapes.trim()
);

fs.writeFileSync('src/data.ts', data);
