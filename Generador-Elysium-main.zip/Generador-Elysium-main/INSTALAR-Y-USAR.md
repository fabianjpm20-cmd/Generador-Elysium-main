# Elysium Neural - Guía de Instalación y Uso

## 📦 Versiones Disponibles

Elysium Neural está disponible en **3 formatos** para que elijas el que mejor se adapte a tus necesidades:

### 1. 🌐 **Versión Web (HTML Puro)** - **RECOMENDADO PARA PRINCIPIANTES**
- **No requiere instalación**
- **100% offline** - Funciona sin internet
- **No necesitas saber programar**
- **Funciona en cualquier navegador**

### 2. 💻 **Versión PWA (Aplicación Web Progresiva)**
- Se instala como una aplicación en tu dispositivo
- Acceso rápido desde el escritorio o menú de aplicaciones
- Funciona offline

### 3. 🖥️ **Versión Electron (Aplicación de Escritorio)**
- Aplicación nativa para Windows, macOS y Linux
- Ventana independiente (no en el navegador)
- Integración con el sistema operativo

---

## 🚀 Opción 1: Usar la Versión Web (HTML Puro) - **MÁS FÁCIL**

### Requisitos
- ❌ **No necesitas Node.js**
- ❌ **No necesitas npm**
- ❌ **No necesitas instalar nada**
- ✅ Solo necesitas un **navegador web** (Chrome, Firefox, Edge, Safari, etc.)

### Pasos para usar

#### En Windows:
1. **Descarga el archivo** `elysium-simple.html` de la carpeta `public/`
2. **Guarda el archivo** en tu escritorio o cualquier carpeta
3. **Haz doble clic** en el archivo `elysium-simple.html`
4. **¡Listo!** Se abrirá en tu navegador por defecto

#### En macOS:
1. **Descarga el archivo** `elysium-simple.html` de la carpeta `public/`
2. **Guarda el archivo** en tu escritorio o carpeta de Descargas
3. **Haz clic derecho** en el archivo → **Abrir con** → **Safari** o **Chrome**
4. **¡Listo!** La aplicación se abrirá

#### En Linux:
1. **Descarga el archivo** `elysium-simple.html` de la carpeta `public/`
2. **Guarda el archivo** en tu carpeta personal
3. **Abre un terminal** y navega a la carpeta donde está el archivo:
   ```bash
   cd ~/Descargas
   ```
4. **Abre el archivo con tu navegador:**
   ```bash
   xdg-open elysium-simple.html
   ```
5. **¡Listo!**

### Ventajas de la versión web:
- ✅ **No requiere instalación**
- ✅ **Funciona en cualquier dispositivo**
- ✅ **100% offline**
- ✅ **No necesitas permisos de administrador**
- ✅ **Puedes copiarlo a un USB y usarlo en cualquier PC**

---

## 📱 Opción 2: Instalar como PWA (Aplicación Web Progresiva)

### Requisitos
- Un navegador moderno (Chrome, Edge, Firefox, Safari)
- Conexión a internet **solo para la primera instalación**

### Pasos para instalar:

#### Método A: Usando el proyecto completo
1. **Ejecuta el servidor de desarrollo:**
   ```bash
   npm install
   npm run dev
   ```
2. **Abre tu navegador** y ve a `http://localhost:3000`
3. **Haz clic en el icono de instalación** (generalmente aparece en la barra de direcciones)
4. **Confirma la instalación**
5. **¡Listo!** Ahora puedes abrir Elysium Neural desde tu menú de aplicaciones

#### Método B: Usando solo el archivo HTML
1. **Abre el archivo** `public/elysium-simple.html` en Chrome o Edge
2. **Haz clic en el icono de instalación** (➕ o el icono de la app en la barra de direcciones)
3. **Selecciona "Instalar"**
4. **¡Listo!**

### Ventajas de la PWA:
- ✅ **Acceso rápido desde el escritorio**
- ✅ **Funciona offline**
- ✅ **Se actualiza automáticamente**
- ✅ **Ocupa poco espacio**

---

## 💻 Opción 3: Compilar la Versión Electron (Aplicación de Escritorio)

### Requisitos
- ✅ **Node.js 18 o superior** (Descargar de https://nodejs.org/)
- ✅ **npm** (viene con Node.js)
- ✅ **Git** (opcional, para clonar el repositorio)

### Pasos para compilar:

#### 1. Instalar Node.js
- Ve a https://nodejs.org/
- Descarga la versión **LTS** (Recomendada)
- Ejecuta el instalador y sigue los pasos

#### 2. Verificar la instalación
Abre una terminal (CMD en Windows, Terminal en macOS/Linux) y ejecuta:
```bash
node --version
npm --version
```
Deberías ver versiones como: `v20.x.x` y `10.x.x`

#### 3. Descargar el proyecto
Si no lo tienes ya:
```bash
cd /ruta/donde/quieres/guardarlo
git clone https://github.com/fabianjpm20-cmd/Generador-Elysium.git
cd Generador-Elysium
```

O descarga el ZIP desde GitHub y extrae el contenido.

#### 4. Instalar dependencias para Electron
```bash
npm install electron electron-builder --save-dev
```

#### 5. Instalar dependencias del proyecto
```bash
npm install
```

#### 6. Compilar para tu sistema operativo

##### Para Windows:
```bash
npm run build:win
```
El ejecutable se creará en la carpeta `dist-electron/`

##### Para macOS:
```bash
npm run build:mac
```
El archivo `.dmg` se creará en la carpeta `dist-electron/`

##### Para Linux:
```bash
npm run build:linux
```
Los archivos `.AppImage`, `.deb` y `.rpm` se crearán en la carpeta `dist-electron/`

#### 7. Ejecutar la aplicación
- **Windows:** Busca el archivo `Elysium Neural Setup X.X.X.exe` y ejecútalo
- **macOS:** Abre el archivo `.dmg` y arrastra la aplicación a la carpeta Aplicaciones
- **Linux:** Ejecuta el archivo `.AppImage` o instala el `.deb`/`.rpm`

### Solución de problemas comunes:

#### Error: "node no se reconoce"
- **Solución:** Asegúrate de que Node.js esté en tu PATH
- **En Windows:** Vuelve a ejecutar el instalador de Node.js y selecciona "Add to PATH"
- **En macOS/Linux:** Reinicia la terminal o tu computadora

#### Error: "npm no encontrado"
- **Solución:** Instala npm con Node.js o reinstala Node.js

#### Error: "Permission denied" en Linux/macOS
- **Solución:** Usa `sudo` o cambia los permisos:
  ```bash
  chmod -R 755 Generador-Elysium
  ```

---

## 🎮 Cómo Usar Elysium Neural

### Interfaz Principal

Cuando abras Elysium Neural, verás:

1. **Barra superior:** Logo, menú de navegación (Chat, Personajes, Lugares, Nuevo)
2. **Panel izquierdo:** Lista de personajes y lugares disponibles
3. **Área principal:** Chat con los mensajes
4. **Barra inferior:** Campo para escribir mensajes y botón de enviar

### Pasos para chatear:

#### 1. Seleccionar un Personaje
- **Haz clic en un personaje** de la lista en el panel izquierdo
- El personaje seleccionado se resaltará
- Verás su nombre y rol en la parte superior del chat

#### 2. (Opcional) Seleccionar un Lugar
- **Haz clic en un lugar** de la lista
- El lugar se resaltará
- Esto afecta cómo el personaje responde (contexto)

#### 3. Escribir un Mensaje
- **Haz clic en el campo de texto** en la parte inferior
- **Escribe tu mensaje** (ej: "Hola", "¿Cómo estás?", "Cuéntame tu historia")
- **Presiona Enter** o **haz clic en el botón →** para enviar

#### 4. Recibir Respuesta
- El personaje **respondirá automáticamente**
- La respuesta aparecerá en el chat
- El personaje **recordará el contexto** de la conversación

### Acciones Rápidas

En la parte inferior del chat, verás botones de **Acciones Rápidas**:
- **Saludar:** Envía "Hola"
- **Preguntar nombre:** Envía "¿Cómo te llamas?"
- **Preguntar rol:** Envía "¿Qué haces aquí?"
- **Contar historia:** Envía "Cuéntame tu historia"
- **Preguntar opinión:** Envía "¿Qué opinas de esto?"

### Crear un Nuevo Personaje

1. **Haz clic en "Nuevo"** en la barra superior
2. **Selecciona "Nuevo Personaje"**
3. **Completa el formulario:**
   - **Nombre:** Nombre del personaje (ej: "Aria", "Drakthar")
   - **Rol:** Su profesión o descripción (ej: "Maga Oscura", "Guerrero Noble")
   - **Personalidad:** Describe cómo es (ej: "Sabia, misteriosa, con sentido del humor")
   - **Apariencia:** Describe cómo se ve (ej: "Piel pálida, ojos rojos, cabello negro")
   - **Historial:** Su historia (opcional)
4. **Haz clic en "Crear"**
5. **¡Listo!** Tu personaje aparecerá en la lista

### Crear un Nuevo Lugar

1. **Haz clic en "Nuevo"** en la barra superior
2. **Selecciona "Nuevo Lugar"**
3. **Completa el formulario:**
   - **Nombre:** Nombre del lugar (ej: "Taberna del Dragón", "Bosque Encantado")
   - **Descripción:** Describe el lugar
   - **Atmósfera:** Ambiente (ej: "Oscuro", "Alegre", "Místico")
4. **Haz clic en "Crear"**
5. **¡Listo!** Tu lugar aparecerá en la lista

---

## 🎭 Personajes Predefinidos

Elysium Neural viene con **4 personajes predefinidos** para que puedas empezar a chatear inmediatamente:

### 1. **Elara Vaelith** 🔮
- **Rol:** Maga Arcana
- **Personalidad:** Sabia, misteriosa, con un toque de ironía. Habla con elegancia y precisión.
- **Historial:** Última descendiente de la Casa Vaelith, custodia conocimiento prohibido.

### 2. **Kael Duskbane** ⚔️
- **Rol:** Guerrero Oscuro
- **Personalidad:** Stoico, leal, con código de honor inquebrantable. Habla directo y sin rodeos.
- **Historial:** Antiguo capitán de la guardia real, ahora cazador de demonios.

### 3. **Lyria Moonshadow** 🎭
- **Rol:** Ladrona de Sombras
- **Personalidad:** Juguetona, astuta, sarcástica. Siempre tiene un plan de respaldo.
- **Historial:** Creció en los callejones, roba a los ricos para ayudar a los pobres.

### 4. **Thalion el Sabio** 📜
- **Rol:** Filósofo Errante
- **Personalidad:** Paciente, reflexivo, siempre buscando el significado más profundo.
- **Historial:** Maestro de muchas disciplinas, viaja buscando respuestas.

---

## 🌍 Lugares Predefinidos

- **La Taberna del Dragón:** Lugar de encuentro de aventureros y mercaderes (Cálido, ruidoso)
- **Bosque de Eldrin:** Antiguo bosque encantado con árboles milenarios (Místico, silencioso)
- **Castillo de Obsidiana:** Fortaleza de los señores oscuros (Oscuro, frío)
- **Elysium:** La gran ciudad capital del reino (Vibrante, luminoso)
- **Mazmorras de Khazad:** Laberintos subterráneos llenos de secretos (Húmedo, peligroso)

---

## 💾 Guardar y Cargar Datos

### Guardar automáticamente
- **Todos tus personajes y lugares creados** se guardan automáticamente en el **localStorage** del navegador
- **Las conversaciones** se mantienen mientras no cierres la pestaña

### Guardar manualmente (Versión Electron)
1. Tus datos se guardan en la carpeta de datos de la aplicación
2. Puedes exportar/importar manualmente si es necesario

### Limpiar datos
- **Para reiniciar:** Borra el localStorage o los archivos de datos
- **En Chrome:** Ve a Configuración → Privacidad → Borrar datos de navegación → Cookies y otros datos del sitio

---

## ⚙️ Configuración y Personalización

### Cambiar el tema
Actualmente Elysium Neural tiene un tema oscuro. En futuras versiones habrá más opciones.

### Añadir más personajes
Puedes crear tantos personajes como quieras. No hay límite.

### Añadir más lugares
Igual que con los personajes, puedes crear ilimitados lugares.

---

## 🛠️ Solución de Problemas

### La aplicación no se abre
- **Solución 1:** Asegúrate de tener un navegador instalado
- **Solución 2:** Prueba con otro navegador (Chrome, Firefox, Edge)
- **Solución 3:** Verifica que el archivo no esté corrupto (vuelve a descargarlo)

### Los personajes no responden
- **Solución 1:** Asegúrate de haber seleccionado un personaje
- **Solución 2:** Verifica que el campo de texto no esté vacío
- **Solución 3:** Espera unos segundos, la respuesta puede tardar

### No puedo crear personajes
- **Solución 1:** Asegúrate de completar al menos el nombre y el rol
- **Solución 2:** Verifica que no haya errores en la consola (F12 en Chrome)

### La aplicación es lenta
- **Solución 1:** Cierra otras pestañas del navegador
- **Solución 2:** Reinicia el navegador
- **Solución 3:** Prueba con otro navegador

### No se guardan mis personajes
- **Solución 1:** Asegúrate de que el navegador no esté en modo privado/incógnito
- **Solución 2:** Verifica que el localStorage no esté lleno (borra datos antiguos)
- **Solución 3:** En la versión Electron, los datos se guardan automáticamente

---

## 📚 Ejemplos de Conversación

### Ejemplo 1: Con Elara Vaelith (Maga Arcana)
```
Tú: Hola
Elara: ¡Hola! Soy Elara Vaelith, Maga Arcana. Como dicen los antiguos: "El conocimiento es poder, pero la sabiduría es libertad."

Tú: ¿Qué puedes hacer?
Elara: Como Maga Arcana, te diré que... La magia fluye a través de las venas de Elysium, accesible solo para aquellos con el don.

Tú: Cuéntame tu historia
Elara: Interesante... Última descendiente de la Casa Vaelith, una estirpe de magos que custodiaban el conocimiento prohibido.
```

### Ejemplo 2: Con Kael Duskbane (Guerrero Oscuro)
```
Tú: Hola
Kael: Saludos, viajero. ¿Qué te trae por aquí? Voy al grano: sí, puedo ayudarte con eso.

Tú: ¿Eres fuerte?
Kael: Interesante pregunta... Como Guerrero Oscuro, te diré que... Sin rodeos: esto es lo que hay.

Tú: Cuéntame de tu pasado
Kael: Interesante... Antiguo capitán de la guardia real, ahora cazador de demonios tras la masacre de su familia.
```

### Ejemplo 3: Con Lyria Moonshadow (Ladrona de Sombras)
```
Tú: Hola
Lyria: ¡Hola! Soy Lyria Moonshadow, Ladrona de Sombras. ¡Vaya, qué pregunta tan... interesante!

Tú: ¿Robas mucho?
Lyria: Por supuesto, como si fuera tan sencillo... Creció en los callejones, ahora roba a los ricos para ayudar a los pobres.

Tú: ¿Te atraparán?
Lyria: Oh, sí, porque eso es exactamente lo que necesitaba escuchar. Siempre tiene un plan de respaldo.
```

---

## 🎯 Consejos para Mejorar la Experiencia

1. **Sé específico:** Cuanto más detallado sea tu mensaje, mejor será la respuesta
2. **Usa el contexto:** Selecciona un lugar que se relacione con la conversación
3. **Crea personajes detallados:** Cuanta más información tengas en el perfil, más coherente será el personaje
4. **Experimenta:** Prueba diferentes combinaciones de personajes y lugares
5. **Usa las acciones rápidas:** Son una forma fácil de empezar conversaciones

---

## 📖 Glosario de Términos

| Término | Descripción |
|---------|-------------|
| **Rolplay** | Juego de interpretación de roles, donde cada persona asume el papel de un personaje |
| **Personaje** | Entidad con personalidad, historia y características únicas |
| **Lugar** | Escenario donde ocurren las interacciones |
| **Sesión** | Conversación activa entre el usuario y un personaje |
| **Memoria** | Sistema que recuerda el contexto de la conversación |
| **Conocimiento** | Base de datos con información sobre el mundo de Elysium |
| **PWA** | Aplicación Web Progresiva, que se puede instalar como una app nativa |
| **Electron** | Framework para crear aplicaciones de escritorio con tecnologías web |

---

## 🔒 Privacidad y Seguridad

- **100% Offline:** Elysium Neural **NO** envía ningún dato a internet
- **Tus datos son tuyos:** Todos los personajes, lugares y conversaciones se guardan **localmente** en tu dispositivo
- **Sin rastreo:** No hay cookies de seguimiento ni analytics
- **Código abierto:** Puedes revisar el código fuente para verificar que no hay código malicioso

---

## 🤝 Contribuir y Reportar Problemas

Si encuentras un error o tienes una sugerencia:

1. **Reportar un bug:**
   - Ve a https://github.com/fabianjpm20-cmd/Generador-Elysium
   - Abre un "Issue" y describe el problema
   - Incluye: Pasos para reproducir, navegador, sistema operativo

2. **Contribuir:**
   - Haz un fork del repositorio
   - Crea una rama con tu feature
   - Envía un Pull Request

---

## 📝 Historial de Versiones

| Versión | Fecha | Cambios |
|---------|-------|---------|
| 1.0.0 | 2024 | Versión inicial con personajes predefinidos |

---

## 🎉 ¡Gracias por usar Elysium Neural!

Esperamos que disfrutes creando historias y personajes con esta aplicación. 

**Recuerda:** Elysium Neural es 100% offline y no requiere conexión a internet ni conocimientos de programación.

---

*Documentación generada para usuarios sin conocimientos de programación*
*Última actualización: Septiembre 2024*
