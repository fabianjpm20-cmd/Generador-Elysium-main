const fs = require('fs');
let data = fs.readFileSync('src/types.ts', 'utf8');
data = data.replace(/location: string\[\];/, 'location: string[];\n  detailLocations: Record<string, string[]>;');
fs.writeFileSync('src/types.ts', data);
