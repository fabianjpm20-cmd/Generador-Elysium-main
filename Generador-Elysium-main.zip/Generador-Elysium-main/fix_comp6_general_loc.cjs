const fs = require('fs');
let data = fs.readFileSync('src/components/State6Compilation.tsx', 'utf8');

const regex = /w\.layer \? \`Layer: \$\{cleanVal\(w\.layer\)\}\` : '',/;
const newLogic = `w.layer ? \`Layer: \${cleanVal(w.layer)}\` : '',
        (w.location && w.location.length > 0) ? \`Location (General): \${w.location.map(cleanVal).join(', ')}\` : '',`;

data = data.replace(regex, newLogic);
fs.writeFileSync('src/components/State6Compilation.tsx', data);
