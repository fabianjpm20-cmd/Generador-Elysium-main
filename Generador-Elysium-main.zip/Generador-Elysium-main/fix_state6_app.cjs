const fs = require('fs');
let data = fs.readFileSync('src/components/State6Compilation.tsx', 'utf8');

const replacement = `
    if (cleanVal(state.appendices.skinAndMarks) && cleanVal(state.appendices.skinAndMarks) !== 'Piel Lisa') {
      apps.push(\`skin texture \${cleanVal(state.appendices.skinAndMarks)}\`);
    }
    
    if (cleanVal(state.appendices.markType) && cleanVal(state.appendices.markType) !== 'Ninguna') {
      const shape = state.appendices.markShape ? \` shaped as \${cleanVal(state.appendices.markShape)}\` : '';
      const location = state.appendices.skinMarksLocation ? \` located on \${cleanVal(state.appendices.skinMarksLocation)}\` : '';
      const color = state.appendices.skinMarksColor ? \` colored \${cleanVal(state.appendices.skinMarksColor)}\` : '';
      apps.push(\`marks: \${cleanVal(state.appendices.markType)}\${shape}\${location}\${color}\`);
    }
`;

data = data.replace(
  /    if \(cleanVal\(state\.appendices\.skinAndMarks\) && cleanVal\(state\.appendices\.skinAndMarks\) !== 'Piel Lisa'\) \{[\s\S]*?    \}/,
  replacement.trim()
);

fs.writeFileSync('src/components/State6Compilation.tsx', data);
