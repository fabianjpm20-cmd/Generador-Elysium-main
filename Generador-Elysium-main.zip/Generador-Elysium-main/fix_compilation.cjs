const fs = require('fs');
let data = fs.readFileSync('src/components/State6Compilation.tsx', 'utf8');

data = data.replace(
  /w\.sleeve \? \`Sleeve: \$\{cleanVal\(w\.sleeve\)\}\` : '',/,
  "w.sleeve ? `Sleeve: ${cleanVal(w.sleeve)}` : '',\n        w.neckline ? `Neckline: ${cleanVal(w.neckline)}` : '',"
);

fs.writeFileSync('src/components/State6Compilation.tsx', data);
