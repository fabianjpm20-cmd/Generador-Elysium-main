const fs = require('fs');
let data = fs.readFileSync('src/components/State6Compilation.tsx', 'utf8');

data = data.replace(
  /\$\{w\.location \? ' \(' \+ cleanVal\(w\.location\) \+ '\)' : ''\}/g,
  "${(w.location && w.location.length > 0) ? ' (' + (Array.isArray(w.location) ? w.location.map(cleanVal).join(', ') : cleanVal(w.location)) + ')' : ''}"
);

fs.writeFileSync('src/components/State6Compilation.tsx', data);
