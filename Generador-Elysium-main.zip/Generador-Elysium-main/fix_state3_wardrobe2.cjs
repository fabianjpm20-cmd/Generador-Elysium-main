const fs = require('fs');
let data = fs.readFileSync('src/components/State3Wardrobe.tsx', 'utf8');

data = data.replace(
  /variation: string;\n    layer: string;\n  }>/,
  "variation: string;\n    layer: string;\n    location: string;\n    pattern: string;\n  }>"
);

data = data.replace(
  /finish: '',\n    details: '',\n    variation: '',\n    layer: ''\n  }\)/,
  "finish: '',\n    details: '',\n    variation: '',\n    layer: '',\n    location: '',\n    pattern: ''\n  })"
);

fs.writeFileSync('src/components/State3Wardrobe.tsx', data);
