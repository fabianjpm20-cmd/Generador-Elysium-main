const fs = require('fs');
let data = fs.readFileSync('src/types.ts', 'utf8');
data = data.replace(/details: string;/, 'details: string[];');
fs.writeFileSync('src/types.ts', data);
