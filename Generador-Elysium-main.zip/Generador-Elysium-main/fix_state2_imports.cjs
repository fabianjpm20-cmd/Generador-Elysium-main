const fs = require('fs');
let data = fs.readFileSync('src/components/State2Anatomy.tsx', 'utf8');

data = data.replace(
  /TAILS_LENGTHS, SKIN_AND_MARKS/,
  "TAILS_LENGTHS, SKIN_AND_MARKS, MARK_TYPES, MARK_SHAPES, MARK_LOCATIONS, MARK_COLORS"
);

fs.writeFileSync('src/components/State2Anatomy.tsx', data);
