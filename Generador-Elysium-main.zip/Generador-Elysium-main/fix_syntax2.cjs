const fs = require('fs');
let data = fs.readFileSync('src/components/State3Wardrobe.tsx', 'utf8');

data = data.replace(
  /\}\}\)\)\}\s*className=\{/g,
  "}} className={"
);

fs.writeFileSync('src/components/State3Wardrobe.tsx', data);
