const fs = require('fs');
let data = fs.readFileSync('src/components/State2Anatomy.tsx', 'utf8');

data = data.replace(
  /            \<\/div\>\n          \<\/div\>\n          \<\/div\>\n        \<\/div\>\n      \)\}/,
  "            </div>\n          </div>\n        </div>\n      )}"
);

fs.writeFileSync('src/components/State2Anatomy.tsx', data);
