const fs = require('fs');
let data = fs.readFileSync('src/components/State2Anatomy.tsx', 'utf8');

const replacement = `
              <div className="space-y-4">
                <h3 className="text-lg font-serif italic text-[#C9A050] mb-2 border-b border-[#222222] pb-2">A.2.4.4 Piel</h3>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Textura / Patrón</label>
                  <select value={state.appendices.skinAndMarks} onChange={(e) => updateApp('skinAndMarks', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]">
                    {SKIN_AND_MARKS.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
              </div>

              <div className="space-y-4 pt-6">
                <h3 className="text-lg font-serif italic text-[#C9A050] mb-2 border-b border-[#222222] pb-2">A.2.4.5 Marcas</h3>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Ubicación (dónde están las marcas/escamas)</label>
                  <input type="text" value={state.appendices.skinMarksLocation} onChange={(e) => updateApp('skinMarksLocation', e.target.value)} placeholder="Ej. hombros, muslos, espalda" className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0] placeholder-[#555555]" />
                </div>
                <div>
                  <label className="block text-xs text-[#888888] mb-1">Color de marcas/escamas</label>
                  <input type="text" value={state.appendices.skinMarksColor} onChange={(e) => updateApp('skinMarksColor', e.target.value)} placeholder="Ej. dorado luminoso, negro oscuro" className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0] placeholder-[#555555]" />
                </div>
              </div>
`;

data = data.replace(
  /\<div className="space-y-4"\>\n\s*\<h3 className="text-lg font-serif italic text-\[\#C9A050\] mb-2 border-b border-\[\#222222\] pb-2"\>A\.2\.4\.4 Piel y Marcas\<\/h3\>[\s\S]*?\<\/div\>\n\n\s*\<\/div\>/,
  replacement.trim() + "\n            </div>"
);

fs.writeFileSync('src/components/State2Anatomy.tsx', data);
