const fs = require('fs');
let data = fs.readFileSync('src/components/State2Anatomy.tsx', 'utf8');

// 1. Update imports
data = data.replace(
  /SEX_BASES, COMPLEXIONS,/,
  'SEX_BASES, AGES, COMPLEXIONS,'
);

// 2. Add Age UI block
const ageBlock = `
            <div className="bg-[#0F1115] border border-[#222222] rounded-2xl p-6 shadow-xs">
              <h3 className="text-sm font-bold text-[#C9A050] mb-3">
                A.2.1.2 Edad
                {ANATOMY_DESCRIPTIONS[state.anatomy.age] && (
                  <InfoTooltip text={ANATOMY_DESCRIPTIONS[state.anatomy.age]} />
                )}
              </h3>
              <select value={state.anatomy.age} onChange={(e) => updateAnat('age', e.target.value)} className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-3 text-sm text-[#E0E0E0]">
                {AGES.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
`;

data = data.replace(
  /(<select value=\{state\.anatomy\.sexBase\}[\s\S]*?<\/select>\s*<\/div>)/,
  "$1" + ageBlock
);

// 3. Renumber remaining A.2.1.X items
data = data.replace('A.2.1.2 Complexión', 'A.2.1.3 Complexión');
data = data.replace('A.2.1.3 Altura', 'A.2.1.4 Altura');
data = data.replace('A.2.1.4 Desarrollo Mamario', 'A.2.1.5 Desarrollo Mamario');
data = data.replace('A.2.1.5 Cintura', 'A.2.1.6 Cintura');
data = data.replace('A.2.1.6 Glúteos', 'A.2.1.7 Glúteos');
data = data.replace('A.2.1.7 Muslos', 'A.2.1.8 Muslos');
data = data.replace('A.2.1.8 Color de Piel', 'A.2.1.9 Color de Piel');

fs.writeFileSync('src/components/State2Anatomy.tsx', data);
