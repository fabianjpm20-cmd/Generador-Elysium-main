const fs = require('fs');
let data = fs.readFileSync('src/components/State3Wardrobe.tsx', 'utf8');

const replacementOnClick = `onClick={() => {
                      const newOpts = getWardrobeOptions(selectedCat, item.id, item.name);
                      setCurrentGarment(prev => ({ 
                        ...prev, 
                        itemId: item.id, 
                        name: item.name,
                        cut: newOpts.cut.includes(prev.cut) ? prev.cut : (newOpts.cut[0] || ''),
                        length: newOpts.length.includes(prev.length) ? prev.length : (newOpts.length[0] || ''),
                        sleeve: newOpts.sleeve.includes(prev.sleeve) ? prev.sleeve : (newOpts.sleeve[0] || ''),
                        material: newOpts.material.includes(prev.material) ? prev.material : (newOpts.material[0] || ''),
                        finish: newOpts.finish.includes(prev.finish) ? prev.finish : (newOpts.finish[0] || ''),
                        details: newOpts.details.includes(prev.details) ? prev.details : (newOpts.details[0] || ''),
                        variation: newOpts.variation.includes(prev.variation) ? prev.variation : (newOpts.variation[0] || ''),
                        layer: newOpts.layer.includes(prev.layer) ? prev.layer : (newOpts.layer[0] || '')
                      }));
                    }}`;

data = data.replace(/onClick=\{[^}]*setCurrentGarment[^}]*\}/, replacementOnClick);

fs.writeFileSync('src/components/State3Wardrobe.tsx', data);
