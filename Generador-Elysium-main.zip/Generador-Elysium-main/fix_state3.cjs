const fs = require('fs');
let data = fs.readFileSync('src/components/State3Wardrobe.tsx', 'utf8');

data = data.replace(
  /const activeOptions = getWardrobeOptions\(selectedCat\);/,
  "const activeOptions = getWardrobeOptions(selectedCat, currentGarment.itemId, currentGarment.name);"
);

data = data.replace(
  /const opts = getWardrobeOptions\(selectedCat\);/,
  "const opts = getWardrobeOptions(selectedCat, firstItem.id, firstItem.name);"
);

fs.writeFileSync('src/components/State3Wardrobe.tsx', data);
