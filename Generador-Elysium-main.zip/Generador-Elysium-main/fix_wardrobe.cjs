const fs = require('fs');
let data = fs.readFileSync('src/components/State3Wardrobe.tsx', 'utf8');

// replace type
data = data.replace(
  /location: string;/,
  "location: string[];"
);

// replace initial states
data = data.replace(
  /location: '',/g,
  "location: [],"
);

// useEffect
data = data.replace(
  /location: opts\.location \? opts\.location\[0\] \|\| '' : '',/g,
  "location: opts.location && opts.location.length > 0 ? [opts.location[0]] : [],"
);

// onChange item
data = data.replace(
  /location: newOpts\.location\.includes\(prev\.location\) \? prev\.location : \(newOpts\.location\[0\] \|\| ''\),/g,
  "location: prev.location.filter(l => newOpts.location.includes(l)).length > 0 ? prev.location.filter(l => newOpts.location.includes(l)) : (newOpts.location[0] ? [newOpts.location[0]] : []),"
);

// JSX
const newJSX = `                    {activeOptions.location && activeOptions.location.length > 0 && currentGarment.details !== 'Minimalista' && (
                      <div className="mt-3 pl-3 border-l-2 border-[#C9A050]">
                        <label className="block text-xs font-mono text-[#888888] mb-2">Posición de Uso / Cobertura (Múltiple) <InfoTooltip text="Haz clic para seleccionar múltiples zonas." /></label>
                        <div className="flex flex-wrap gap-2">
                          {activeOptions.location.map(o => {
                            const isSelected = (currentGarment.location || []).includes(o);
                            return (
                              <button
                                key={o}
                                type="button"
                                onClick={() => {
                                  setCurrentGarment(prev => {
                                    const locs = prev.location || [];
                                    if (locs.includes(o)) return { ...prev, location: locs.filter(l => l !== o) };
                                    return { ...prev, location: [...locs, o] };
                                  });
                                }}
                                className={\`px-2 py-1 text-[11px] rounded transition-all \${
                                  isSelected
                                    ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-md'
                                    : 'bg-[#15171C] text-[#888888] border border-[#2A2D35] hover:border-[#888888]'
                                }\`}
                              >
                                {o}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}`;

data = data.replace(
  /                    \{activeOptions\.location && activeOptions\.location\.length > 0 && currentGarment\.details !== 'Minimalista' && \(\n                      \<div className="mt-2 pl-3 border-l-2 border-\[\#2A2D35\]"\>\n                        \<label className="block text-xs font-mono text-\[\#888888\] mb-1"\>Posición de Uso \/ Cobertura \<InfoTooltip text="Forma en la que se lleva o parte específica del cuerpo que cubre\." \/\>\<\/label\>\n                        \<select\n                          value=\{currentGarment\.location \|\| ''\}\n                          onChange=\{e => setCurrentGarment\(prev => \(\{ \.\.\.prev, location: e\.target\.value \}\)\)\}\n                          className="w-full bg-\[\#15171C\] border border-\[\#2A2D35\] rounded-xl p-2 text-xs text-\[\#E0E0E0\]"\n                        \>\n                          \{activeOptions\.location\.map\(o => \<option key=\{o\} value=\{o\}\>\{o\}\<\/option\>\)\}\n                        \<\/select\>\n                      \<\/div\>\n                    \)\}/,
  newJSX
);

fs.writeFileSync('src/components/State3Wardrobe.tsx', data);
