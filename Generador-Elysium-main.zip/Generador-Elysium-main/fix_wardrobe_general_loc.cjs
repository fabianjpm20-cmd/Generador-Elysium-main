const fs = require('fs');
let data = fs.readFileSync('src/components/State3Wardrobe.tsx', 'utf8');

const regex = /\{\/\* Detalles Selector \*\/\}/;

const newBlock = `
                    {/* General Location Selector */}
                    {activeOptions.location && activeOptions.location.length > 0 && (
                      <div className="mb-6">
                        <label className="block text-xs font-mono text-[#888888] mb-2">Posición de Uso / Cobertura (Prenda General):</label>
                        <div className="flex flex-wrap gap-2">
                          {activeOptions.location.map(o => {
                            const isSelected = (currentGarment.location || []).includes(o);
                            return (
                              <button
                                key={o}
                                type="button"
                                onClick={() => {
                                  setCurrentGarment(prev => {
                                    const locs = prev.location || [];
                                    const newLocs = locs.includes(o) ? locs.filter(l => l !== o) : [...locs, o];
                                    return { ...prev, location: newLocs };
                                  });
                                }}
                                className={\`px-2 py-1 text-[11px] rounded transition-all \${
                                  isSelected
                                    ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-md'
                                    : 'bg-[#15171C] text-[#888888] border border-[#2A2D35] hover:border-[#888888]'
                                }\`}
                              >
                                {o}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Detalles Selector */}`;

data = data.replace(regex, newBlock);
fs.writeFileSync('src/components/State3Wardrobe.tsx', data);
