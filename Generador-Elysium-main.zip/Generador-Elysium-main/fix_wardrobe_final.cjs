const fs = require('fs');
let data = fs.readFileSync('src/components/State3Wardrobe.tsx', 'utf8');

const regex = /\<div\>\n\s*\<label className="block text-xs font-mono text-\[\#888888\] mb-2"\>Detalles \(Múltiple\)\<\/label\>[\s\S]*?\<\/div\>\n\s*\<\/div\>\n\s*\<\/div\>/;
// Let's just find the start and end of this div.
// It starts with <div> then <label className="block text-xs font-mono text-[#888888] mb-2">Detalles (Múltiple)</label>
// and ends right before <div>\n<label className="block text-xs font-mono text-[#888888] mb-1">Variación

const startIndex = data.indexOf('<div>\n                    <label className="block text-xs font-mono text-[#888888] mb-2">Detalles (Múltiple)</label>');
const endIndex = data.indexOf('<div>\n                    <label className="block text-xs font-mono text-[#888888] mb-1">Variación');

if (startIndex !== -1 && endIndex !== -1) {
  const newBlock = `<div className="col-span-1 sm:col-span-3 bg-[#15171C] border border-[#2A2D35] p-4 rounded-xl mt-2">
                    <label className="block text-sm font-bold text-[#C9A050] mb-3">Detalles y Cobertura (Múltiple)</label>
                    
                    {/* Detalles Selector */}
                    <div className="mb-4">
                      <label className="block text-xs font-mono text-[#888888] mb-2">Selecciona Detalles:</label>
                      <div className="flex flex-wrap gap-2">
                        {activeOptions.details.map(o => {
                          const isSelected = (currentGarment.details || []).includes(o);
                          return (
                            <button
                              key={o}
                              type="button"
                              onClick={() => {
                                setCurrentGarment(prev => {
                                  const dets = prev.details || [];
                                  let newDets;
                                  if (dets.includes(o)) {
                                    newDets = dets.filter(d => d !== o);
                                  } else {
                                    newDets = [...dets, o];
                                  }
                                  
                                  // Limpiar location particular si lo quitamos
                                  const newDetailLocs = { ...prev.detailLocations };
                                  if (!newDets.includes(o)) {
                                    delete newDetailLocs[o];
                                  }
                                  
                                  return { ...prev, details: newDets, detailLocations: newDetailLocs };
                                });
                              }}
                              className={\`px-3 py-1.5 text-xs rounded-lg transition-all border \${
                                isSelected
                                  ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-md border-[#C9A050]'
                                  : 'bg-[#1A1C22] text-[#A0A0A0] border-[#2A2D35] hover:border-[#888888] hover:text-[#E0E0E0]'
                              }\`}
                            >
                              {o}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Posiciones Específicas por Detalle */}
                    {!(currentGarment.details || []).includes('Minimalista') && (currentGarment.details || []).length > 0 && (
                      <div className="space-y-3 pt-3 border-t border-[#222222]">
                        <label className="block text-xs font-mono text-[#888888] mb-1">Posición de Uso Específica por Detalle:</label>
                        {(currentGarment.details || []).map(det => {
                          const detLocs = activeOptions.locationMap && activeOptions.locationMap[det];
                          if (!detLocs || detLocs.length === 0) return null;
                          return (
                            <div key={det} className="bg-[#0F1115] rounded-lg p-3 border border-[#222222] pl-4 border-l-2 border-l-[#C9A050]">
                              <label className="block text-[11px] font-mono text-[#A0A0A0] mb-2 uppercase tracking-wide">Posición para: <span className="text-[#C9A050] font-bold">{det}</span></label>
                              <div className="flex flex-wrap gap-2">
                                {detLocs.map(o => {
                                  const currentDetLocs = (currentGarment.detailLocations && currentGarment.detailLocations[det]) || [];
                                  const isSelected = currentDetLocs.includes(o);
                                  return (
                                    <button
                                      key={o}
                                      type="button"
                                      onClick={() => {
                                        setCurrentGarment(prev => {
                                          const prevDetLocs = (prev.detailLocations && prev.detailLocations[det]) || [];
                                          const newLocs = prevDetLocs.includes(o) ? prevDetLocs.filter(l => l !== o) : [...prevDetLocs, o];
                                          return { ...prev, detailLocations: { ...prev.detailLocations, [det]: newLocs } };
                                        });
                                      }}
                                      className={\`px-2 py-1 text-[11px] rounded transition-all \${
                                        isSelected
                                          ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-md'
                                          : 'bg-[#15171C] text-[#888888] border border-[#2A2D35] hover:border-[#888888]'
                                      }\`}
                                    >
                                      {o}
                                    </button>
                                  );
                                })}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>\n\n                  `;

  data = data.substring(0, startIndex) + newBlock + data.substring(endIndex);
  fs.writeFileSync('src/components/State3Wardrobe.tsx', data);
  console.log("Success");
} else {
  console.log("Failed to find bounds.");
}
