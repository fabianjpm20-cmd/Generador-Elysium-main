const fs = require('fs');
let data = fs.readFileSync('src/data.ts', 'utf8');

data = data.replace(
  /  \} else if \(isShoes\) \{\n    location = \['Pies', 'Tobillos', 'Media Pierna', 'Pierna Completa \(Musleras\)'\];\n  \}\n  if \(isBra \|\| isTop\) location = \['Torso', 'Pecho', 'Hombros'\];\n  if \(isBottom\) location = \['Cintura', 'Cadera', 'Piernas', 'Rodillas'\];/g,
  "  } else if (isShoes) {\n    location = ['Pies', 'Tobillos', 'Media Pierna', 'Pierna Completa (Musleras)'];\n  } else if (isBra || isTop) {\n    location = ['Torso', 'Pecho', 'Hombros'];\n  } else if (isBottom) {\n    location = ['Cintura', 'Cadera', 'Piernas', 'Rodillas'];\n  }"
);

fs.writeFileSync('src/data.ts', data);
