const fs = require('fs');
let data = fs.readFileSync('src/components/State6Compilation.tsx', 'utf8');

data = data.replace(
  /w\.layer \? \`Layer: \$\{cleanVal\(w\.layer\)\}\` : ''/,
  "w.layer ? `Layer: ${cleanVal(w.layer)}` : '',\n        w.location ? `Location: ${cleanVal(w.location)}` : '',\n        w.pattern ? `Pattern: ${cleanVal(w.pattern)}` : ''"
);

fs.writeFileSync('src/components/State6Compilation.tsx', data);
