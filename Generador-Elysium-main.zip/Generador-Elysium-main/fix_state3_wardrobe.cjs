const fs = require('fs');
let data = fs.readFileSync('src/components/State3Wardrobe.tsx', 'utf8');

// Update initial state in addGarment or whenever setCurrentGarment is called
data = data.replace(
  /layer: opts\.layer\[0\] \|\| ''\n      \}/,
  "layer: opts.layer[0] || '',\n        location: opts.location ? opts.location[0] || '' : '',\n        pattern: opts.pattern ? opts.pattern[0] || '' : ''\n      }"
);

data = data.replace(
  /layer: newOpts\.layer\.includes\(prev\.layer\) \? prev\.layer : \(newOpts\.layer\[0\] \|\| ''\)\n                      \}\)\);/,
  "layer: newOpts.layer.includes(prev.layer) ? prev.layer : (newOpts.layer[0] || ''),\n                        location: newOpts.location.includes(prev.location) ? prev.location : (newOpts.location[0] || ''),\n                        pattern: newOpts.pattern.includes(prev.pattern) ? prev.pattern : (newOpts.pattern[0] || '')\n                      }));"
);

data = data.replace(
  /Configuración de 9 Parámetros para: /,
  "Configuración Detallada para: "
);

const newFields = `
                  {activeOptions.location && activeOptions.location.length > 0 && (<div>
                    <label className="block text-xs font-mono text-[#888888] mb-1">Ubicación</label>
                    <select
                      value={currentGarment.location || ''}
                      onChange={e => setCurrentGarment(prev => ({ ...prev, location: e.target.value }))}
                      className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                    >
                      {activeOptions.location.map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </div>)}

                  {activeOptions.pattern && activeOptions.pattern.length > 0 && (<div>
                    <label className="block text-xs font-mono text-[#888888] mb-1">Patrón / Estampado</label>
                    <select
                      value={currentGarment.pattern || ''}
                      onChange={e => setCurrentGarment(prev => ({ ...prev, pattern: e.target.value }))}
                      className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                    >
                      {activeOptions.pattern.map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </div>)}
`;

data = data.replace(
  /                  \{activeOptions\.variation\.length > 0 && \(\<div\>\n                    \<label className="block text-xs font-mono text-\[\#888888\] mb-1"\>Variación\<\/label\>[\s\S]*?\<\/div\>\)\}/,
  "                  {activeOptions.variation.length > 0 && (<div>\n                    <label className=\"block text-xs font-mono text-[#888888] mb-1\">Variación</label>\n                    <select\n                      value={currentGarment.variation}\n                      onChange={e => setCurrentGarment(prev => ({ ...prev, variation: e.target.value }))}\n                      className=\"w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]\"\n                    >\n                      {activeOptions.variation.map(o => <option key={o} value={o}>{o}</option>)}\n                    </select>\n                  </div>)}\n" + newFields
);

fs.writeFileSync('src/components/State3Wardrobe.tsx', data);
