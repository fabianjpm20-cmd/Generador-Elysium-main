const fs = require('fs');
let data = fs.readFileSync('src/components/State3Wardrobe.tsx', 'utf8');

// Update getWardrobeOptions calls
data = data.replace(
  /const activeOptions = getWardrobeOptions\(selectedCat, currentGarment\.itemId, currentGarment\.name\);/,
  "const activeOptions = getWardrobeOptions(selectedCat, currentGarment.itemId, currentGarment.name, currentGarment.details);"
);
data = data.replace(
  /const opts = getWardrobeOptions\(selectedCat, firstItem\.id, firstItem\.name\);/,
  "const opts = getWardrobeOptions(selectedCat, firstItem.id, firstItem.name); // fallback is empty"
);
data = data.replace(
  /const newOpts = getWardrobeOptions\(selectedCat, item\.id, item\.name\);/,
  "const newOpts = getWardrobeOptions(selectedCat, item.id, item.name); // fallback is empty on selection"
);


// Move JSX Location
// Remove the existing location block
const locationBlock = `                  {activeOptions.location && activeOptions.location.length > 0 && (<div>
                    <label className="block text-xs font-mono text-[#888888] mb-1">Posición de Uso / Cobertura <InfoTooltip text="Forma en la que se lleva o parte específica del cuerpo que cubre." /></label>
                    <select
                      value={currentGarment.location || ''}
                      onChange={e => setCurrentGarment(prev => ({ ...prev, location: e.target.value }))}
                      className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                    >
                      {activeOptions.location.map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </div>)}`;

data = data.replace(
  /                  \{activeOptions\.location && activeOptions\.location\.length > 0 && \(\<div\>[\s\S]*?\<\/select\>\n\s*\<\/div\>\)\}/,
  ""
);

// Add it under Details
const detailsBlockMatch = /                  \<div\>\n                    \<label className="block text-xs font-mono text-\[\#888888\] mb-1"\>Detalles\<\/label\>\n                    \<select[\s\S]*?\<\/select\>\n                  \<\/div\>/;
const newDetailsBlock = `                  <div>
                    <label className="block text-xs font-mono text-[#888888] mb-1">Detalles</label>
                    <select
                      value={currentGarment.details}
                      onChange={e => setCurrentGarment(prev => ({ ...prev, details: e.target.value }))}
                      className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                    >
                      {activeOptions.details.map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                    
                    {activeOptions.location && activeOptions.location.length > 0 && currentGarment.details !== 'Minimalista' && (
                      <div className="mt-2 pl-3 border-l-2 border-[#2A2D35]">
                        <label className="block text-xs font-mono text-[#888888] mb-1">Posición de Uso / Cobertura <InfoTooltip text="Forma en la que se lleva o parte específica del cuerpo que cubre." /></label>
                        <select
                          value={currentGarment.location || ''}
                          onChange={e => setCurrentGarment(prev => ({ ...prev, location: e.target.value }))}
                          className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                        >
                          {activeOptions.location.map(o => <option key={o} value={o}>{o}</option>)}
                        </select>
                      </div>
                    )}
                  </div>`;

data = data.replace(detailsBlockMatch, newDetailsBlock);

fs.writeFileSync('src/components/State3Wardrobe.tsx', data);
