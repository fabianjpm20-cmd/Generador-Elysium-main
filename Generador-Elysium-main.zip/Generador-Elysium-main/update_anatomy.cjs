const fs = require('fs');

let data = fs.readFileSync('src/data.ts', 'utf8');

// Add new arrays
const arraysStr = `
export const WAISTS = ['1 Muy Estrecha', '2 Estrecha', '3 Media / Equilibrada', '4 Ancha', '5 Muy Ancha', '6 Definida / Angular', '7 Suave / Redondeada'];
export const GLUTES = ['1 Planos', '2 Pequeños', '3 Moderados', '4 Redondeados', '5 Voluminosos', '6 Altos / Firmes', '7 Suaves / Blandos', '8 Muy Voluminosos'];
export const THIGHS = ['1 Muy Delgados', '2 Delgados', '3 Medios / Equilibrados', '4 Gruesos', '5 Musculosos', '6 Voluminosos / Suaves', '7 Muy Voluminosos', '8 Alargados / Estilizados'];
`;

data = data.replace(/(export const BREAST_DEV = \[[^\]]*\];)/, "$1\n\n" + arraysStr.trim() + "\n");

// Extract ANATOMY_DESCRIPTIONS string and update it
const descMatch = data.match(/export const ANATOMY_DESCRIPTIONS: Record<string, string> = (\{[\s\S]*?\});/);
if (descMatch) {
  const map = eval('(' + descMatch[1] + ')');
  
  const newDescs = {
    '1 Muy Estrecha': 'Cintura visualmente muy reducida respecto al tórax y las caderas; intensifica la silueta de reloj de arena y concentra las sombras en los laterales del abdomen.',
    '2 Estrecha': 'Reducción clara del perímetro de cintura; crea una transición marcada entre caja torácica, abdomen y cadera.',
    '3 Media / Equilibrada': 'Perímetro proporcional al resto del cuerpo; mantiene una silueta neutra y una distribución regular de sombras.',
    '4 Ancha': 'Cintura con mayor perímetro; suaviza la transición entre torso y cadera y reduce el contraste de curvas.',
    '5 Muy Ancha': 'Zona abdominal y lumbar de gran amplitud; genera una silueta robusta y transiciones laterales suaves.',
    '6 Definida / Angular': 'Cintura estrecha con bordes anatómicos claramente marcados; enfatiza la estructura ósea y las sombras de separación.',
    '7 Suave / Redondeada': 'Contorno continuo sin cambios bruscos; favorece una lectura corporal blanda y uniforme.',

    '1 Planos': 'Proyección posterior mínima; la línea de pelvis a muslo es relativamente recta.',
    '2 Pequeños': 'Proyección posterior leve; volumen contenido y transición corta hacia los muslos.',
    '3 Moderados': 'Proyección equilibrada; aporta volumen natural sin dominar la silueta.',
    '4 Redondeados': 'Proyección posterior continua y curva; genera una transición suave hacia la cintura y los muslos.',
    '5 Voluminosos': 'Mayor masa posterior; modifica el equilibrio visual de la pelvis y produce sombras más profundas bajo la curva.',
    '6 Altos / Firmes': 'Proyección moderada con inserción visual elevada; contorno compacto y definido.',
    '7 Suaves / Blandos': 'Volumen redondeado con caída visual ligera; transición difusa hacia muslos y pelvis.',
    '8 Muy Voluminosos': 'Proyección posterior dominante; aumenta considerablemente el ancho y profundidad visual de la pelvis.',

    '1 Muy Delgados': 'Poco volumen muscular o adiposo; extremidades visualmente estrechas.',
    '2 Delgados': 'Volumen reducido pero proporcional; líneas limpias y poca sombra interna.',
    '3 Medios / Equilibrados': 'Masa proporcional al resto de la pierna; transición anatómica neutra.',
    '4 Gruesos': 'Mayor volumen en aductores y cuádriceps; sombras internas más presentes.',
    '5 Musculosos': 'Masa muscular definida; separación visible de grupos musculares y contorno firme.',
    '6 Voluminosos / Suaves': 'Mayor masa blanda; contorno redondeado y sombras difusas.',
    '7 Muy Voluminosos': 'Gran masa de muslo que domina la lectura de la pierna y modifica el ancho de la silueta inferior.',
    '8 Alargados / Estilizados': 'Muslos largos con volumen moderado; enfatizan la verticalidad de la figura.'
  };

  Object.assign(map, newDescs);

  data = data.replace(/export const ANATOMY_DESCRIPTIONS: Record<string, string> = \{[\s\S]*?\};/, 'export const ANATOMY_DESCRIPTIONS: Record<string, string> = ' + JSON.stringify(map, null, 2) + ';');
}

fs.writeFileSync('src/data.ts', data);
