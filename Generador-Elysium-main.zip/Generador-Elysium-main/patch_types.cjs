const fs = require('fs');
let data = fs.readFileSync('src/types.ts', 'utf8');

data = data.replace(
  "export interface CharacterState {\n  // State 1",
  "export interface CharacterState {\n  // State 0\n  personality: string;\n  archetype: string;\n\n  // State 1"
);

fs.writeFileSync('src/types.ts', data);
