const fs = require('fs');
let data = fs.readFileSync('src/App.tsx', 'utf8');

data = data.replace(
  /sexBase: '1 Hombre Normal',/,
  "sexBase: '1 Hombre',\n      age: '3 Juventud (18-25 años)',"
);

fs.writeFileSync('src/App.tsx', data);
