const fs = require('fs');
let data = fs.readFileSync('src/types.ts', 'utf8');

data = data.replace(/skinMarksLocation: string;\n\s*skinMarksColor: string;\n\s*markType: string;\n\s*markShape: string;/, 
`markTypes: string[];
    markLocations: Record<string, string[]>;
    markShapes: Record<string, string>;
    markColors: Record<string, string>;`);

fs.writeFileSync('src/types.ts', data);
