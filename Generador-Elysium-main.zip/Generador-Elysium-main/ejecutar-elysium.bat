@echo off
REM =========================================================================
REM SCRIPT PARA EJECUTAR ELYSIUM NEURAL (VERSIÓN WEB)
REM =========================================================================
REM Este script abre el archivo elysium-simple.html en el navegador por defecto
REM No requiere Node.js, npm ni conocimientos de programación
REM 
REM Uso: Haz doble clic en este archivo o ejecútalo desde CMD
REM =========================================================================

@echo off
setlocal

REM Verificar si el archivo existe
if not exist "%~dp0public\elysium-simple.html" (
    echo No se encontró el archivo elysium-simple.html en la carpeta public/
    echo Asegúrate de que el archivo esté en la ubicación correcta.
    pause
    exit /b 1
)

REM Obtener la ruta completa del archivo
set "HTML_FILE=%~dp0public\elysium-simple.html"

REM Intentar abrir con el navegador por defecto
start "" "%HTML_FILE%"

REM Mensaje de confirmación
echo.
echo =========================================================================
echo  Elysium Neural - Aplicación de Chat de Rolplay
  =========================================================================
echo.
echo Se ha abierto Elysium Neural en tu navegador por defecto.
echo.
echo Si el navegador no se abre automáticamente, abre manualmente:
echo   %HTML_FILE%
echo.
echo =========================================================================
echo  Controles:
  =========================================================================
echo.
echo   - Selecciona un personaje de la lista para empezar a chatear
   - Escribe tu mensaje en el campo de texto y presiona Enter
   - Usa los botones de acciones rápidas para enviar mensajes predefinidos
   - Crea nuevos personajes y lugares con el botón "Nuevo"
   - Todos los datos se guardan automáticamente en tu navegador
echo.
echo =========================================================================
echo.

endlocal
