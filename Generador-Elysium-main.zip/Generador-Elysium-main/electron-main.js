// =========================================================================
// ELECTRON MAIN PROCESS - ELYSIUM NEURAL STANDALONE APPLICATION
// =========================================================================

const { app, BrowserWindow, ipcMain, globalShortcut } = require('electron');
const path = require('path');
const fs = require('fs');

let mainWindow = null;

// Configuración de la aplicación
const APP_CONFIG = {
  name: 'Elysium Neural',
  width: 1200,
  height: 800,
  minWidth: 800,
  minHeight: 600,
  backgroundColor: '#0B0D13',
  icon: path.join(__dirname, 'public', 'pwa-512x512.png'),
  title: 'Elysium Neural - Chat de Rolplay'
};

function createWindow() {
  // Crear la ventana principal
  mainWindow = new BrowserWindow({
    width: APP_CONFIG.width,
    height: APP_CONFIG.height,
    minWidth: APP_CONFIG.minWidth,
    minHeight: APP_CONFIG.minHeight,
    backgroundColor: APP_CONFIG.backgroundColor,
    icon: APP_CONFIG.icon,
    title: APP_CONFIG.title,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      enableRemoteModule: false,
      sandbox: true,
      webgl: true,
      plugins: false
    }
  });

  // Cargar el archivo HTML
  // Verificar si estamos en desarrollo o producción
  const isDev = process.env.NODE_ENV === 'development';
  
  if (isDev) {
    // En desarrollo, cargar desde el sistema de archivos
    mainWindow.loadFile(path.join(__dirname, 'public', 'elysium-simple.html'));
  } else {
    // En producción, cargar desde el path de recursos
    mainWindow.loadFile(path.join(process.resourcesPath, 'app.asar.unpacked', 'public', 'elysium-simple.html'));
      .catch(() => {
        // Fallback: intentar cargar directamente
        mainWindow.loadFile(path.join(__dirname, 'public', 'elysium-simple.html'));
      });
  }

  // Abrir DevTools en desarrollo
  if (isDev) {
    mainWindow.webContents.openDevTools();
  }

  // Manejar cierre de ventana
  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  // Registrar atajos de teclado globales
  registerGlobalShortcuts();
}

function registerGlobalShortcuts() {
  // Ctrl/Cmd + N: Nueva ventana
  globalShortcut.register('CommandOrControl+N', () => {
    if (mainWindow) {
      mainWindow.webContents.send('new-window');
    }
  });

  // Ctrl/Cmd + R: Recargar
  globalShortcut.register('CommandOrControl+R', () => {
    if (mainWindow) {
      mainWindow.reload();
    }
  });

  // Ctrl/Cmd + Q: Cerrar aplicación
  globalShortcut.register('CommandOrControl+Q', () => {
    app.quit();
  });

  // F11: Pantalla completa
  globalShortcut.register('F11', () => {
    if (mainWindow) {
      mainWindow.setFullScreen(!mainWindow.isFullScreen());
    }
  });
}

// Configurar IPC para comunicación entre procesos
function setupIPC() {
  // Guardar datos
  ipcMain.handle('save-data', (event, { type, data }) => {
    try {
      const filePath = path.join(app.getPath('userData'), `${type}.json`);
      fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
      return { success: true, path: filePath };
    } catch (error) {
      return { success: false, error: error.message };
    }
  });

  // Cargar datos
  ipcMain.handle('load-data', (event, type) => {
    try {
      const filePath = path.join(app.getPath('userData'), `${type}.json`);
      if (fs.existsSync(filePath)) {
        const data = fs.readFileSync(filePath, 'utf-8');
        return { success: true, data: JSON.parse(data) };
      }
      return { success: false, error: 'File not found' };
    } catch (error) {
      return { success: false, error: error.message };
    }
  });

  // Obtener información de la aplicación
  ipcMain.handle('get-app-info', () => ({
    name: app.name,
    version: app.getVersion(),
    platform: process.platform,
    electronVersion: process.versions.electron,
    nodeVersion: process.versions.node
  }));

  // Abrir diálogo de archivo
  const { dialog } = require('electron');
  
  ipcMain.handle('open-file-dialog', async (event, options) => {
    const result = await dialog.showOpenDialog(mainWindow, options);
    return result;
  });

  // Guardar diálogo de archivo
  ipcMain.handle('save-file-dialog', async (event, options) => {
    const result = await dialog.showSaveDialog(mainWindow, options);
    return result;
  });
}

// Manejar activación de la aplicación (macOS)
app.on('activate', () => {
  if (mainWindow === null) {
    createWindow();
  }
});

// Manejar listo de Electron
app.whenReady().then(() => {
  createWindow();
  setupIPC();
  
  // Manejar protocolo personalizado (opcional)
  app.on('will-finish-launching', () => {
    app.on('open-url', (event, url) => {
      event.preventDefault();
      if (mainWindow) {
        mainWindow.webContents.send('open-url', url);
      }
    });
  });

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

// Manejar cierre de todas las ventanas
app.on('window-all-closed', () => {
  // En macOS, es común que las aplicaciones sigan ejecutándose
  // incluso después de cerrar todas las ventanas
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

// Manejar errores no capturados
process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);
  if (mainWindow) {
    mainWindow.webContents.send('error', error.message);
  }
});

process.on('unhandledRejection', (reason) => {
  console.error('Unhandled Rejection:', reason);
  if (mainWindow) {
    mainWindow.webContents.send('error', reason instanceof Error ? reason.message : String(reason));
  }
});

// Exportar para testing
module.exports = { createWindow, registerGlobalShortcuts, setupIPC };
