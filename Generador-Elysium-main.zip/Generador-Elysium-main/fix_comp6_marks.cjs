const fs = require('fs');
let data = fs.readFileSync('src/components/State6Compilation.tsx', 'utf8');

const regex = /if \(cleanVal\(state\.appendices\.markType\)[\s\S]*?apps\.push\(\`marks: \$\{cleanVal\(state\.appendices\.markType\)\}\$\{shape\}\$\{location\}\$\{color\}\`\);\n\s*\}/;

const newBlock = `if (state.appendices.markTypes && state.appendices.markTypes.length > 0) {
      const marksStrings = state.appendices.markTypes.map(mark => {
        const shape = (state.appendices.markShapes && state.appendices.markShapes[mark]) ? \` shaped as \${cleanVal(state.appendices.markShapes[mark])}\` : '';
        const color = (state.appendices.markColors && state.appendices.markColors[mark]) ? \` colored \${cleanVal(state.appendices.markColors[mark])}\` : '';
        const locs = (state.appendices.markLocations && state.appendices.markLocations[mark]) || [];
        const locationStr = locs.length > 0 ? \` located on \${locs.map(cleanVal).join(', ')}\` : '';
        
        return \`\${cleanVal(mark)}\${shape}\${color}\${locationStr}\`;
      });
      if (marksStrings.length > 0) {
        apps.push(\`marks: \${marksStrings.join(' | ')}\`);
      }
    }`;

data = data.replace(regex, newBlock);
fs.writeFileSync('src/components/State6Compilation.tsx', data);
