const fs = require('fs');
let data = fs.readFileSync('src/components/State3Wardrobe.tsx', 'utf8');

data = data.replace(
  /pattern: string;\n  }>/,
  "pattern: string;\n    emblem: string;\n    vfx: string;\n  }>"
);

data = data.replace(
  /location: '',\n    pattern: ''\n  }\)/,
  "location: '',\n    pattern: '',\n    emblem: 'Ninguno',\n    vfx: 'Ninguno'\n  })"
);

data = data.replace(
  /pattern: opts\.pattern \? opts\.pattern\[0\] \|\| '' : ''\n      }/,
  "pattern: opts.pattern ? opts.pattern[0] || '' : '',\n      emblem: opts.emblem ? opts.emblem[0] || 'Ninguno' : 'Ninguno',\n      vfx: opts.vfx ? opts.vfx[0] || 'Ninguno' : 'Ninguno'\n      }"
);

data = data.replace(
  /pattern: newOpts\.pattern\.includes\(prev\.pattern\) \? prev\.pattern : \(newOpts\.pattern\[0\] \|\| ''\)/,
  "pattern: newOpts.pattern.includes(prev.pattern) ? prev.pattern : (newOpts.pattern[0] || ''),\n                        emblem: newOpts.emblem.includes(prev.emblem) ? prev.emblem : (newOpts.emblem[0] || 'Ninguno'),\n                        vfx: newOpts.vfx.includes(prev.vfx) ? prev.vfx : (newOpts.vfx[0] || 'Ninguno')"
);

const newFields = `
                  {activeOptions.emblem && activeOptions.emblem.length > 0 && (<div>
                    <label className="block text-xs font-mono text-[#888888] mb-1">Emblema / Símbolo <InfoTooltip text="Logos, crestas, runas o marcas singulares grabadas/bordadas en la prenda." /></label>
                    <select
                      value={currentGarment.emblem || 'Ninguno'}
                      onChange={e => setCurrentGarment(prev => ({ ...prev, emblem: e.target.value }))}
                      className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                    >
                      {activeOptions.emblem.map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </div>)}

                  {activeOptions.vfx && activeOptions.vfx.length > 0 && (<div>
                    <label className="block text-xs font-mono text-[#888888] mb-1">Efectos / Condición <InfoTooltip text="Estado físico especial o efectos visuales/mágicos que emite la prenda." /></label>
                    <select
                      value={currentGarment.vfx || 'Ninguno'}
                      onChange={e => setCurrentGarment(prev => ({ ...prev, vfx: e.target.value }))}
                      className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                    >
                      {activeOptions.vfx.map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </div>)}
`;

data = data.replace(
  /                  \{activeOptions\.pattern && activeOptions\.pattern\.length > 0 && \(\<div\>\n                    \<label className="block text-xs font-mono text-\[\#888888\] mb-1"\>Patrón \/ Estampado\<\/label\>[\s\S]*?\<\/div\>\)\}/,
  "                  {activeOptions.pattern && activeOptions.pattern.length > 0 && (<div>\n                    <label className=\"block text-xs font-mono text-[#888888] mb-1\">Patrón / Estampado</label>\n                    <select\n                      value={currentGarment.pattern || ''}\n                      onChange={e => setCurrentGarment(prev => ({ ...prev, pattern: e.target.value }))}\n                      className=\"w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]\"\n                    >\n                      {activeOptions.pattern.map(o => <option key={o} value={o}>{o}</option>)}\n                    </select>\n                  </div>)}\n" + newFields
);

fs.writeFileSync('src/components/State3Wardrobe.tsx', data);
