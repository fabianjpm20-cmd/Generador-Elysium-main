const fs = require('fs');
let data = fs.readFileSync('src/components/State3Wardrobe.tsx', 'utf8');

// replace type
data = data.replace(
  /details: string;/,
  "details: string[];"
);

// replace initial states
data = data.replace(
  /details: '',/,
  "details: [],"
);

// useEffect
data = data.replace(
  /details: opts\.details\[0\] \|\| '',/,
  "details: opts.details && opts.details.length > 0 ? [opts.details[0]] : [],"
);

// onChange item
data = data.replace(
  /details: newOpts\.details\.includes\(prev\.details\) \? prev\.details : \(newOpts\.details\[0\] \|\| ''\),/,
  "details: prev.details && prev.details.filter(d => newOpts.details.includes(d)).length > 0 ? prev.details.filter(d => newOpts.details.includes(d)) : (newOpts.details[0] ? [newOpts.details[0]] : []),"
);

// JSX
const newJSX = `                  <div>
                    <label className="block text-xs font-mono text-[#888888] mb-2">Detalles (Múltiple)</label>
                    <div className="flex flex-wrap gap-2">
                      {activeOptions.details.map(o => {
                        const isSelected = (currentGarment.details || []).includes(o);
                        return (
                          <button
                            key={o}
                            type="button"
                            onClick={() => {
                              setCurrentGarment(prev => {
                                const dets = prev.details || [];
                                if (dets.includes(o)) return { ...prev, details: dets.filter(d => d !== o) };
                                return { ...prev, details: [...dets, o] };
                              });
                            }}
                            className={\`px-2 py-1 text-[11px] rounded transition-all \${
                              isSelected
                                ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-md'
                                : 'bg-[#15171C] text-[#888888] border border-[#2A2D35] hover:border-[#888888]'
                            }\`}
                          >
                            {o}
                          </button>
                        );
                      })}
                    </div>
                    
                    {activeOptions.location && activeOptions.location.length > 0 && !(currentGarment.details || []).includes('Minimalista') && (`;

data = data.replace(
  /                  \<div\>\n                    \<label className="block text-xs font-mono text-\[\#888888\] mb-1"\>Detalles\<\/label\>\n                    \<select\n                      value=\{currentGarment\.details\}\n                      onChange=\{e => setCurrentGarment\(prev => \(\{ \.\.\.prev, details: e\.target\.value \}\)\)\}\n                      className="w-full bg-\[\#15171C\] border border-\[\#2A2D35\] rounded-xl p-2 text-xs text-\[\#E0E0E0\]"\n                    \>\n                      \{activeOptions\.details\.map\(o => \<option key=\{o\} value=\{o\}\>\{o\}\<\/option\>\)\}\n                    \<\/select\>\n                    \n                    \{activeOptions\.location && activeOptions\.location\.length > 0 && currentGarment\.details !== 'Minimalista' && \(/,
  newJSX
);

fs.writeFileSync('src/components/State3Wardrobe.tsx', data);
