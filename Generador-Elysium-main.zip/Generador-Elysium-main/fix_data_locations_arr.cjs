const fs = require('fs');
let data = fs.readFileSync('src/data.ts', 'utf8');

data = data.replace(
  /export function getWardrobeOptions\(categoryId: string, itemId: string = '', itemName: string = '', currentDetail: string = ''\) \{/,
  "export function getWardrobeOptions(categoryId: string, itemId: string = '', itemName: string = '', currentDetail: string[] = []) {"
);

const newLocationLogic = `  // LOCATION / COVERAGE (Now heavily dependent on the chosen detail)
  let locationSet = new Set<string>();
  
  const effDetails = (currentDetail && currentDetail.length > 0) ? currentDetail : [details[0] || ''];
  
  for (const effDetail of effDetails) {
    if (effDetail === 'Lazos' || effDetail === 'Cintas' || effDetail === 'Cordones / Corsetería') {
      ['Cuello / Gargantilla', 'Hombros (Ambos)', 'Hombro Izquierdo', 'Hombro Derecho', 
      'Escote / Busto Frontal', 'Cintura Frontal', 'Cintura Lateral', 'Espalda Alta', 
      'Espalda Baja / Corsé', 'Puños / Muñecas', 'Dobladillo Inferior', 'Muslos (Ligas)', 'Tobillos'].forEach(l => locationSet.add(l));
    } else if (effDetail === 'Transparencias' || effDetail === 'Encajes' || effDetail === 'Aberturas / Cortes (Cut-outs)') {
      ['Cobertura Total', 'Paneles Laterales (Costados)', 'Escote / Pecho', 'Busto (Underboob/Sideboob)',
      'Vientre / Abdomen', 'Espalda Completa', 'Espalda Baja', 'Sólo Mangas', 
      'Hombros Descubiertos', 'Muslo Lateral', 'Rodillas', 'Caderas (High-cut)'].forEach(l => locationSet.add(l));
    } else if (effDetail === 'Bordados' || effDetail === 'Parches' || effDetail === 'Lentejuelas / Pedrería' || effDetail === 'Plumas') {
      ['Pecho Central', 'Espalda Central', 'Solapas / Cuello', 'Hombros / Hombreras',
      'Mangas (Lado Exterior)', 'Puños', 'Borde Inferior / Dobladillo', 'Bolsillos Frontales',
      'Disperso por toda la prenda', 'Rodillas', 'Costuras Laterales'].forEach(l => locationSet.add(l));
    } else if (effDetail === 'Hebillas' || effDetail === 'Cinturones' || effDetail === 'Tachuelas' || effDetail === 'Cadenas' || effDetail === 'Cadenas Colgantes' || effDetail === 'Remaches') {
      ['Cuello (Gargantilla)', 'Hombros / Charreteras', 'Pecho (Arnés cruzado)', 'Pecho (Horizontal)',
      'Bajo Busto (Underbust)', 'Cintura Frontal', 'Cintura (Cinturón caído)', 'Caderas', 
      'Brazos (Bíceps)', 'Muñecas', 'Muslo Derecho', 'Muslo Izquierdo', 'Rodillas', 'Botas / Tobillos'].forEach(l => locationSet.add(l));
    } else if (effDetail === 'Pliegues' || effDetail === 'Volantes' || effDetail === 'Flecos') {
      ['Cuello / Gorguera', 'Mangas / Puños', 'Pecho / Cascada Frontal', 'Cintura / Peplum',
      'Borde Inferior / Dobladillo', 'A lo largo de las mangas', 'Espalda Baja', 'Asimétrico (Diagonal)'].forEach(l => locationSet.add(l));
    } else if (effDetail === 'Grabados' || effDetail === 'Costuras' || effDetail === 'Cremalleras Expuestas' || effDetail === 'Bolsillos Tácticos') {
      ['Frontal Central', 'Costuras Laterales', 'Diagonal en el Pecho', 'Brazos / Mangas',
      'Muslos / Cargo', 'Pantorrillas', 'Cintura', 'Glúteos / Espalda Baja'].forEach(l => locationSet.add(l));
    } else if (isAcc) {
      ['Cabeza / Pelo', 'Rostro / Frente', 'Oreja Derecha', 'Oreja Izquierda', 'Ojo Izquierdo', 'Ojo Derecho', 'Cuello', 'Pecho', 'Brazo Derecho', 'Brazo Izquierdo', 'Muñecas (Ambas)', 'Mano Derecha', 'Mano Izquierda', 'Dedos', 'Cintura', 'Muslo Derecho', 'Muslo Izquierdo', 'Tobillos'].forEach(l => locationSet.add(l));
    } else if (isShoes) {
      ['Punta del Pie', 'Talón', 'Tobillo Lateral', 'Lengüeta', 'Caña / Media Pierna', 'Pierna Completa (Musleras)'].forEach(l => locationSet.add(l));
    } else if (isBra || isTop) {
      ['Torso Completo', 'Pecho Superior', 'Bajo Busto', 'Hombros', 'Centro del Escote', 'Espalda'].forEach(l => locationSet.add(l));
    } else if (isBottom) {
      ['Cintura Alta', 'Caderas / Pelvis', 'Muslos Frontal', 'Muslos Lateral', 'Rodillas', 'Pantorrillas', 'Piernas Completas'].forEach(l => locationSet.add(l));
    }
  }
  let location = Array.from(locationSet);`;

data = data.replace(
  /\/\/ LOCATION \/ COVERAGE[\s\S]*?if \(isBottom\) \{\n    location = \['Cintura Alta', 'Caderas \/ Pelvis', 'Muslos Frontal', 'Muslos Lateral', 'Rodillas', 'Pantorrillas', 'Piernas Completas'\];\n  \}/,
  newLocationLogic
);

fs.writeFileSync('src/data.ts', data);
