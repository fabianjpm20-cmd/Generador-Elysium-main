const fs = require('fs');
let data = fs.readFileSync('src/data.ts', 'utf8');

data = data.replace(
  /  if \(currentDetail === 'Lazos' \|\| currentDetail === 'Cintas'\) \{/,
  "  const effDetail = currentDetail || details[0] || '';\n  if (effDetail === 'Lazos' || effDetail === 'Cintas') {"
);

data = data.replace(/currentDetail === /g, "effDetail === ");

fs.writeFileSync('src/data.ts', data);
