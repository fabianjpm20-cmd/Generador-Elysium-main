const fs = require('fs');
const rawText = `
1.1 Cadena simple. Clásico y versátil. Eslabones finos o medianos, cierre posterior discreto.
1.2 Colgante. Piedra central o símbolo que destaca. Cadena soporte con elemento focal suspendido.
1.3 Multicapa. Varias capas de cadena a diferentes alturas. Efecto escalonado en el pecho.
1.4 Gargantilla negra. Encaje o terciopelo. Estética gótica y elegante. Ajuste ceñido al cuello.
1.5 Choker con anillo. Aro central metálico. Estilo alternativo o punk. Sujeción con hebilla o cordón.
1.6 Perlas. Elegante y sofisticado. Clásico y refinado. Esferas uniformes en hilo continuo.
1.7 Corazón. Colgante romántico y dulce. Forma cardíaca, aire juvenil o sentimental.
1.8 Cadena gruesa. Llamativo y urbano. Eslabones grandes de peso visual, estilo rudo y moderno.
1.9 Cuero con dije. Natural y masculino. Cordón o banda de cuero con elemento colgante.
1.10 Amuleto. Protección o poder. Toque místico. Símbolo grabado o figura en relieve.

2.1 Delgado. Minimalista y sutil. Banda fina sin adornos o con detalle mínimo.
2.2 Signet. Sello o inicial. Clásico y elegante. Superficie plana grabada, heráldico.
2.3 Piedra preciosa. Piedra central. Elegante y llamativo. Engaste elevado, solitario.
2.4 Múltiple. Varias piezas apiladas. Estilo moderno. Combinación de finos en diferentes alturas.
2.5 Cadena. Diseño de cadena. Urbano y edgy. Eslabones flexibles que envuelven el dedo.
2.6 Gótico. Intrincado y oscuro. Estética dramática. Filigrana negra, motivos barrocos sombríos.
2.7 Nudillo. Cubre varios falanges. Impacto y actitud. Armadura segmentada para los dedos.
2.8 Abiertos. Ajustable y creativo. Diseño personalizado. Extremos que no se cierran, formas orgánicas.

3.1 Lazo. Femenino y dulce. Estilo romántico. Cinta anudada, colgante o ceñida.
3.2 Cuero con pinchos. Rebelde y punk. Apariencia agresiva. Tachuelas o púas metálicas sobre banda.
3.3 Cadena con cruz. Religioso o gótico. Simbólico y sobrio. Crucifijo colgante o integrado.
3.4 Encaje victoriano. Elegante y vintage. Detalles delicados. Patrón floral calado, cierre trasero.
3.5 Metálica. Futurista o armadura. Estilo imponente. Bandas rígidas de metal, posiblemente con tornillos.

4.1 Cortos. Formales o clásicos. Elegantes y discretos. Cobertura hasta la muñeca.
4.2 Largos. Hasta el codo o más. Elegancia y dramatismo. Cobertura extendida del antebrazo.
4.3 De cuero. Rudos y resistentes. Estilo masculino. Textura granulada, costuras expuestas.
4.4 Sin dedos. Prácticos y casuales. Estilo rebelde. Palma cubierta, falanges expuestas.
4.5 Encaje. Delicados y femeninos. Estética romántica. Transparencia en el dorso, ajuste fino.
4.6 Armadura. Protección y poder. Fantasía o medieval. Placas metálicas articuladas sobre mano.
4.7 Mitones. Cálidos y cómodos. Casuales o lindos. Sin separación de pulgar o dedos, borde cerrado.
4.8 Deportivos. Agarre y protección. Funcional. Refuerzos en palma, cierre de velcro en muñeca.

5.1 Clásico. Simple y funcional. Uso diario. Hebilla metálica estándar, banda uniforme.
5.2 Doble hebilla. Más ajuste y estilo. Detalles llamativos. Dos puntos de cierre frontales.
5.3 Cadena. Decorativo y urbano. Toque punk. Eslabones que funcionan como banda.
5.4 Arnés de pecho. Estilo alternativo. Resalta la silueta. Tiras cruzadas sobre torso.
5.5 Táctico. Funcional y militar. Utilitario. Bolsillos pequeños, hebilla de liberación rápida.
5.6 Faja / Cintura. Fluido y elegante. Inspiración oriental. Anudado, sin hebilla rígida.
5.7 Con argollas. Industrial y edgy. Estilo colgante. Aros metálicos para sujeción o decoración.
5.8 Cadena múltiple. Impactante y punk. Decorativo. Varias cadenas paralelas que caen desde la cintura.

6.1 Corbata clásica. Formal y refinada. Negocios y etiqueta. Nudo estándar, caída larga.
6.2 Corbata delgada. Moderna y estilizada. Elegante casual. Ancho reducido, aire contemporáneo.
6.3 Corbata mono. Vintage y elegante. Estilo victoriano. Nudo amplio en cinta ancha.
6.4 Corbata lazo. Suave y decorativo. Estética dulce. Cinta anudada en lazo, caída libre.
6.5 Moño grande. Impacto y dramatismo. Estilo lolita. Volumen amplio, proporción dominante.
6.6 Moño pequeño. Discreto y delicado. Tierno y sutil. Proporción reducida, detalle fino.
6.7 Moño escolar. Uniforme y juvenil. Estética académica. Línea recta, nudo simétrico.
6.8 Moño de cuello. Inspiración clásica. Formal. Preanudado con banda ajustable.

7.1 Gorra. Casual y urbano. Deportivo. Visera rígida, ajuste trasero.
7.2 Boina. Artístico y retro. Europeo clásico. Tejido plano, inclinación lateral.
7.3 Sombrero Fedora. Elegante y misterioso. Estilo detective. Ala media, copa abollada.
7.4 Sombrero de copa. Formal y antiguo. Época victoriana. Copa alta y cilíndrica, rigidez estructural.
7.5 Capucha. Práctico y misterioso. Aire misterioso. Tejido flexible, cobertura completa de cabeza.
7.6 Diadema. Femenino y delicado. Detalles refinados. Arco rígido o flexible, adorno frontal.
7.7 Tocado floral. Romántico y natural. Estilo bohemio. Flores artificiales o naturales integradas.
7.8 Casco / Headset. Tecnológico y moderno. Estilo futurista. Protector rígido o auriculares integrados.

8.1 Gafas redondas. Intelectual y vintage. Estilo clásico. Aros circulares, montura metálica o pasta.
8.2 Gafas. Serio y profesional. Moderno. Montura rectangular o cuadrada, líneas limpias.
8.3 Gafas de sol. Cool y reservado. Protección y estilo. Lentes oscuras, montura variable.
8.4 Monóculo. Noble y antiguo. Distinción. Lente única con sujeción facial o cadenilla.
8.5 Parche ocular. Discreto y rebelde. Toque moderno. Cubierta de cuero o tela sobre un ojo.

9.1 Arete largo. Elegante y llamativo. Aporta movimiento. Colgante que oscila con la cabeza.
9.2 Aro. Clásico y versátil. Masculino o femenino. Círculo continuo o con cierre.
9.3 Ear cuff. Sin perforación. Moderno y estético. Clip que se ajusta al borde auricular.
9.4 Cadena para oreja. Una o dos perforaciones. Estilo punk o gótico. Cadena que une lóbulo a cartílago superior.
9.5 Ceja. Discreto y rebelde. Toque moderno. Barra horizontal sobre el arco superciliar.
9.6 Labio. Sensual y decorativo. Estética urbana. Labret en el centro o Monroe lateral.
9.7 Nariz. Sutil y romántico. Aro o stud. Septum o ala nasal, pequeño y discreto.
9.8 Lengua. Audaz y enigmático. Estilo extremo. Barra con bolas en los extremos, oculta al hablar.

10.1 Cadena para pantalón. Urbano y punk. Funcional y estético. Sujeción de bolsillo a cinturón.
10.2 Cadena para bolsillo. Delicado y decorativo. Toque elegante. Cadena fina con adorno.
10.3 Broche / Alfiler. Decorativo y funcional. Detalles únicos. Prendedor con cierre de seguridad.
10.4 Charms / Dijes. Personalización. Simbólico y único. Colgantes para pulseras o cadenas.
10.5 Ligas para piernas. Estética alternativa o sexy. Banda elástica en el muslo, con o sin adorno.
10.6 Pulseras / Brazaletes. Variedad de estilos. Metal, cuero, tela. Muñequera rígida o flexible.

11.1 Bandolera. Práctico y casual. Uso diario. Correa larga cruzada, tamaño mediano.
11.2 Mochila. Funcional y cómoda. Escolar o urbana. Correas dobles, compartimentos múltiples.
11.3 Bolso de mano. Elegante y formal. Eventos y salidas. Asas cortas, estructura rígida.
11.4 Clutch. Pequeño y sofisticado. Minimalista. Sin asas, sujeción manual.
11.5 Bolso táctico. Resistente y útil. Estilo militar. Materiales sintéticos, múltiples bolsillos.
11.6 Bolso de cadena. Práctico y urbano. Elegante y moderno. Asa de cadena metálica.

12.1 Medias transparentes. Jóvenes y finas. Estilo escolar. Denier bajo, cobertura parcial.
12.2 Medias de encaje. Elegantes y femeninas. Básicas y sensuales. Patrón calado en pierna o borde.
12.3 Medias de red. Atrevidas y arriesgadas. Estilo alternativo. Malla de diamantes o cuadrícula.
12.4 Medias altas. Clásicas y elegantes. Estilo clásico. Caña larga, sujeción por elástico o liguero.
12.5 Calcetines cortos. Uso diario. Casuales. Tobilleros, cobertura mínima.
12.6 Calcetines largos. Deportivos y decorativos. Funcionales. Caña que llega a la pantorrilla.
12.7 Ligas. Sensuales y decorativas. Sujeción de medias. Banda elástica con broche metálico.
12.8 Portaligas. Vintage y seductor. Estilo clásico. Cinturón con tirantes que sujetan las medias.

13.1 Choker de cuero. Minimalista y punk. Aro o hebilla. Banda rígida o flexible con cierre.
13.2 Brazalete de brazo. Decorativo y tribal. Estilo guerrero. Armband rígido o flexible en el bíceps.
13.3 Cinta para el pelo. Tierno y femenino. Estilo casual. Lazo o diadema suave.
13.4 Pasador. Elegante y delicado. Inspiración oriental. Horquilla decorativa, sujeción parcial.
13.5 Abanico. Protección y estilo. Toque teatral. Varillas plegables, tela o papel.
13.6 Paraguas / Sombrilla. Elegante y vintage. Funcional y estético. Estructura radial, mango curvo.
13.7 Reloj de bolsillo. Antiguo y distinguido. Funcional y estético. Cadena de chaleco, tapa con bisagra.
13.8 Pañuelo / Bufanda. Aporta color y estilo. Versátil. Tejido ligero o pesado, anudado o suelto.
`;

let content = fs.readFileSync('src/data.ts', 'utf8');
const tempMatch = content.match(/export const WARDROBE_DESCRIPTIONS_MAP: Record<string, string> = (\{[\s\S]*?\});/);
if (tempMatch) {
  const mapStr = tempMatch[1];
  const map = eval('(' + mapStr + ')');

  const lines = rawText.split('\n');
  for (const line of lines) {
    let match = line.match(/^([0-9\.]+)\s+(.*?)\.\s+(.*)/);
    if (match) {
      let name = match[2].trim();
      let desc = match[3].trim();
      map[name] = desc;
    }
  }

  content = content.replace(/export const WARDROBE_DESCRIPTIONS_MAP: Record<string, string> = \{[\s\S]*?\};/, 'export const WARDROBE_DESCRIPTIONS_MAP: Record<string, string> = ' + JSON.stringify(map, null, 2) + ';');

  fs.writeFileSync('src/data.ts', content);
}
