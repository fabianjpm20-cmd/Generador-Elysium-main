const fs = require('fs');
let data = fs.readFileSync('src/components/State2Anatomy.tsx', 'utf8');

data = data.replace(
  /SKIN_AND_MARKS, ANATOMY_DESCRIPTIONS/,
  "SKIN_AND_MARKS, MARK_TYPES, MARK_SHAPES, MARK_LOCATIONS, MARK_COLORS, ANATOMY_DESCRIPTIONS"
);

fs.writeFileSync('src/components/State2Anatomy.tsx', data);
