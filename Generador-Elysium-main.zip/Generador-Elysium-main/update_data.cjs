const fs = require('fs');

let data = fs.readFileSync('src/data.ts', 'utf8');

// 1. Replace SEX_BASES and add AGES
data = data.replace(
  /export const SEX_BASES = \[[^\]]*\];/,
  "export const SEX_BASES = ['1 Hombre', '2 Mujer'];\nexport const AGES = ['1 Infancia (0-12 años)', '2 Adolescencia (13-17 años)', '3 Juventud (18-25 años)', '4 Adultez Joven (26-35 años)', '5 Adultez Media (36-50 años)', '6 Adultez Mayor (51-65 años)', '7 Ancianidad (66+ años)', '8 Desconocida / Inmortal'];"
);

// 2. Update ANATOMY_DESCRIPTIONS
const descMatch = data.match(/export const ANATOMY_DESCRIPTIONS: Record<string, string> = (\{[\s\S]*?\});/);
if (descMatch) {
  const map = eval('(' + descMatch[1] + ')');
  
  delete map['1 Hombre Normal'];
  delete map['2 Hombre Lindo'];
  delete map['3 Femboy/Andrógino'];
  delete map['4 Hombre Twink/Soft Boy'];
  delete map['5 Hombre Casi Feminizado'];
  delete map['6 Mujer Normal'];
  delete map['7 Mujer Hiperfeminizada'];

  map['1 Hombre'] = "Lienzo corporal masculino. Establece la base biológica, estructura ósea, patrón de vello y rasgos sexuales primarios/secundarios característicos del hombre.";
  map['2 Mujer'] = "Lienzo corporal femenino. Establece la base biológica, estructura ósea, contornos y rasgos sexuales primarios/secundarios característicos de la mujer.";
  
  map['1 Infancia (0-12 años)'] = "Rasgos faciales redondeados, proporciones corporales infantiles, ausencia de desarrollo sexual secundario maduro.";
  map['2 Adolescencia (13-17 años)'] = "Desarrollo en proceso, rasgos juveniles, piel tersa, transición entre proporciones infantiles y adultas.";
  map['3 Juventud (18-25 años)'] = "Madurez física plena, frescura juvenil, máximo vigor y definición muscular o de curvas naturales.";
  map['4 Adultez Joven (26-35 años)'] = "Rasgos completamente definidos, pérdida de grasa facial juvenil, madurez y presencia corporal estable.";
  map['5 Adultez Media (36-50 años)'] = "Líneas de expresión incipientes, textura de piel más curtida, densidad corporal consolidada.";
  map['6 Adultez Mayor (51-65 años)'] = "Signos claros de madurez, arrugas visibles, posibles canas, cambios marcados en la distribución de masa.";
  map['7 Ancianidad (66+ años)'] = "Envejecimiento avanzado, textura de piel fina, arrugas profundas, estructura ósea facial más prominente.";
  map['8 Desconocida / Inmortal'] = "Edad ambigua o congelada en el tiempo. Puede mezclar madurez en la mirada con apariencia física de otra etapa.";

  data = data.replace(/export const ANATOMY_DESCRIPTIONS: Record<string, string> = \{[\s\S]*?\};/, 'export const ANATOMY_DESCRIPTIONS: Record<string, string> = ' + JSON.stringify(map, null, 2) + ';');
}

fs.writeFileSync('src/data.ts', data);
