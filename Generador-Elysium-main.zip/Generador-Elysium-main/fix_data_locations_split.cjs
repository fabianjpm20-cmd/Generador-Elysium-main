const fs = require('fs');
let data = fs.readFileSync('src/data.ts', 'utf8');

data = data.replace(
  /'Hombros \/ Charreteras'/g,
  "'Hombros', 'Charreteras'"
);

data = data.replace(
  /'Botas \/ Tobillos'/g,
  "'Botas', 'Tobillos'"
);

fs.writeFileSync('src/data.ts', data);
