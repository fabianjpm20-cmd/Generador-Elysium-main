const fs = require('fs');
let data = fs.readFileSync('src/types.ts', 'utf8');

data = data.replace(
  /skinAndMarks: string;\n    skinMarksLocation: string;\n    skinMarksColor: string;\n  \};/,
  "skinAndMarks: string;\n    skinMarksLocation: string;\n    skinMarksColor: string;\n    markType: string;\n    markShape: string;\n  };"
);

fs.writeFileSync('src/types.ts', data);
