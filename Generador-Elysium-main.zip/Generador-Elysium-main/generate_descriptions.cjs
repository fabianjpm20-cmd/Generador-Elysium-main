const fs = require('fs');

const rawText = `
-	A.2.1.1 Sexo Base:
1 Hombre Normal: Silueta rectangular amplia, tirante en V. Los hombros son anchos y redondeados. El pecho es plano, espacioso y grueso. La cintura es estrecha y angular. Las caderas son notablemente mas estrechas que los hombros. Los gluteos son planos a moderados. Los muslos son gruesos y densos. Los brazos son gruesos y densos. El abdomen tiene plenitud suave concentrada en el centro.
2 Hombre Lindo: Delgado, juvenil, contorno corporal suave, Facciones masculinas suavizadas, silueta esbelta.
3 Femboy/Andrógino: Silueta neutra o grácil, estructura ósea delgada, rasgos faciales delicados.
4 Twink/Soft Boy: Silueta similar a la de Hombre Normal, pero con curvas suaves, contraste entre estructura masculina residual (hombros anchos) y acumulacion de grasa femenina (caderas, gluteos, senos blandos). Apariencia de "chico suave" o "soft boy". La mirada recorre la silueta sin encontrar un polo definido.
5 Casi Feminizado: Silueta similar a la de Hombre Normal, pero mas suave y redondeada, lee como mujer a medias, por la masculinidad residual que se manifiesta en hombros anchos y cintura gruesa. Los senos tienen caida pronunciada por falta de soporte ligamentario propio de la anatomía masculina. El conjunto genera una feminidad inestable, pesada.
6 Mujer Normal: Silueta de reloj de arena o pera. Los hombros son mas estrechos que las caderas. La cintura es estrecha. Las caderas son mas anchas que los hombros. Los brazos son delgados y suaves.
7 Mujer Hiperfeminizada: Curvatura acentuada en caderas y busto, facciones estilizadas.

-	A.2.1.2 Complexión:
1 Escuálido / Muy Delgado: Estructura osea visible. Minima grasa subcutanea. Musculos atrofiados o ausentes. Clavicula, costillas y caderas prominentes.
2 Esbelto / Estandar: Proporciones armonicas. Grasa y musculo en equilibrio. Sin excesos ni deficits.
3 Atlético / Fibroso: Músculos definidos sin hipertrofia, postura erguida.
4 Musculoso: Masa muscular desarrollada, hombros y espalda anchos.
5 Voluminoso / Robusto: Estructura corpulenta con mezcla de músculo y densidad física.
6 Hipertrofiado / Musculatura Extrema: Volumen muscular masivo, estiramiento extremo en vestuario.
7 Suave / Blando: Grasa subcutanea uniforme. Sin definicion muscular visible. Piel lisa, sin sombras de musculo.
8 Curvilíneo / Relleno: Formas redondeadas y suaves, contornos corporales continuos.
9 Gordo / Obeso / Extra Grande: Silueta muy redondeada, volumen corporal global muy elevado.

-	A.2.1.3 Altura (Escala de Cánones):
A Muy Pequeño (1.20 m – 1.40 m): Cánon de proporciones reducidas, apariencia compacta.
B Petite (1.40 m – 1.60 m): Cánon bajo, figura compacta y estilizada.
C Normal / Estándar (1.60 m – 1.80 m): Cánon proporcional estándar, equilibrio neutro.
D Alto (1.80 m – 2.00 m): Cánon alto y esbelto, extremidades alargadas.
E Enorme (2.00 m – 2.20 m): Cánon gigante, presencia dominante sobre la escena.
F Especial Racial: Definido directamente por la MRR de la raza (ej. Oni: 1.80–2.40m, Troll: 2.20–2.50m, Centauro: 3.15–3.30m).

-	A.2.1.4 Desarrollo Mamario:
A Incipiente / Plano: Torso plano sin relieve pectoral acentuado; caída recta de prendas.
B Pequeño / Copa A: Relieve suave y ligero; mínima alteración del drapeado superior.
C Medio / Copa B-C: Curvatura natural equilibrada; tensión estándar en corsés y tops.
D Prominente / Copa D: Volumen marcado; proyecta la tela frontalmente creando sombras inferiores.
E Abundante / Copa DD-E: Volumen grande; tensión acentuada en botones, escotes y prendas ajustadas.
F Enorme / Hipertrófico: Masa pectoral masiva; modifica fuertemente el centro de gravedad visual del torso.
`;

const dict = {};

const lines = rawText.split('\n');
for (const line of lines) {
  const match = line.match(/^([A-Z0-9]+ .*?|[^:]+): (.*)/);
  if (match) {
    let key = match[1].trim();
    // Special handling to match data.ts
    // 1 Hombre Normal => 1 Hombre Normal
    // A Incipiente / Plano => A Incipiente / Plano
    dict[key] = match[2].trim();
  }
}

let out = `\nexport const ANATOMY_DESCRIPTIONS: Record<string, string> = ` + JSON.stringify(dict, null, 2) + `;\n`;
fs.appendFileSync('src/data.ts', out);
