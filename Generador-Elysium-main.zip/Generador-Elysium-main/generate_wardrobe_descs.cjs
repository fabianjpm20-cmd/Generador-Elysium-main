const fs = require('fs');
const rawText = `
**A. VESTIDOS Y PRENDAS DE UNA PIEZA**
1. Bodycon — Ajustado al cuerpo, resalta la figura. Silueta ceñida de pecho a rodilla, sin volumen añadido. Tejido elástico y adherente.
2. Qi Pao — Cuello mandarín, apertura lateral desde el muslo. Silueta ajustada con corte tradicional, mangas cortas o tres cuartos.
3. Pegged — Volumen en caderas que se estrecha hacia abajo. Silueta de trapecio invertido, acentuado en la zona superior del muslo.
4. Puff Sleeve — Mangas voluminosas en los hombros, cintura definida. Contraste entre volumen superior y silueta ajustada inferior.
5. Peplum — Volante en la cintura que realza la cadera. Superposición de tela en la zona lumbar con caída estructurada.
6. Mermaid Trumpet — Ajustado hasta rodillas, se abre en campana desde la rodilla. Silueta de sirena con expansión inferior marcada.
7. Flapper — Silueta recta, flecos, estilo años veinte. Caída tubular con movimiento en los bordes, cintura baja.
8. Sheath — Recto y elegante, hasta la rodilla. Corte tubular que no marca cintura excesivamente, línea limpia.
9. Vestido Polo — Cuello polo con botones cortos. Estilo casual-vestir, manga corta, caída recta o ligeramente entallada.
10. Slip — Tirantes finos, estilo lencería. Tejido suave y fluido, escote en V o cuadrado, caída natural del cuerpo.
11. Strapless — Sin tirantes, sujeción interna. Expone hombros y clavículas, silueta definida por el corsé interno o elástico.
12. Shift — Recto y suelto, sin marcar cintura. Silueta de tubo recto desde hombros a muslos, comodidad y movimiento.
13. Tunic — Holgado y alargado, estilo túnica. Caída por encima de la rodilla o media pierna, corte amplio.
14. Tent — Se expande en A desde los hombros. Silueta triangular invertida, amplio en la base sin definición de cintura.
15. Drop Waisted — Cintura baja a la altura de la cadera. El punto de unión entre bodice y falda cae sobre la pelvis.
16. Wrap-Surplice — Envolvente con lazo, escote en V. Cruzado frontal que se cierra con nudo lateral o cinturón.
17. Kimono — Mangas anchas, cierre envolvente. Corte tradicional japonés, caída recta, cintura con obi o cinturón ancho.
18. Dolman — Mangas murciélago, caída fluida. Hombros caídos sin costura definida, silueta amplia en la parte superior.
19. Bubble-Balloon — Dobladillo recogido, efecto globo. Volumen artificial en la falda por medio de recogidos internos.
20. Shirtwaist — Estilo camisa arriba, falda completa. Cierre de botones frontal, cuello camisero, cintura definida.
21. Halter — Se sujeta en la nuca, espalda descubierta. Tirantes que se cruzan o anudan en el cuello, escote profundo.
22. Bustier — Cuerpo estructurado tipo corsé. Varillas internas, escote pronunciado, cintura muy definida.
23. Maxi — Largo hasta tobillos o el suelo. Silueta larga continua, puede ser recta o con vuelo.
24. Bouffant-Pouf — Falda muy voluminosa, forma de campana. Estructura interna o crinolina que sostiene el volumen.
25. One Shoulder — Un solo tirante, hombro descubierto. Asimetría en el escote, sujeción en un solo lado.
26. Mulet — Más corto adelante, largo atrás. Cola posterior visible desde la rodilla hacia abajo, frente corta.
27. Handkerchief — Dobladillo con picos irregulares. Caída asimétrica en puntas que imita el pañuelo.
28. Jacket Dress — Estilo blazer con longitud de vestido. Solapas, botones frontales, corte entallado de chaqueta extendida.
29. Babydoll — Corto bajo el busto, caída holgada. Corte empire con falda suelta y corta, aire juvenil.
30. Apron / Jumper — Estilo pichi o peto, tirantes anchos. Se usa sobre blusa, abertura frontal o lateral.
31. Sundress — Ligero y fresco, tirantes finos. Tejido veraniego, escote redondo o cuadrado, falda fluida.
32. Empire — Cintura bajo el busto, falda fluida. Unión alta que alarga la silueta inferior, caída libre.
33. Pleat — Tela plisada en todo el vestido. Pliegues estructurados verticales que aportan rigidez y movimiento.
34. Princess — Costuras verticales que estilizan. Ajuste mediante paneles sin cintura definida, silueta alargada.
35. Petal — Capas que imitan pétalos de flor. Volantes superpuestos en forma de pétalo, textura tridimensional.

**B. BODY'S Y PRENDAS AJUSTADAS**
1. Body Clásico — De tirantes finos, cobertura de torso y entrepierna. Base para combinar con otras prendas.
2. Body Manga Larga — Cobertura total de brazos. Manga larga ajustada, escote variable.
3. Body Escote Profundo — Escote pronunciado en V o cuadrado. Exposición marcada de pecho o espalda.
4. Body Off-Shoulder — Hombros descubiertos. Borde superior que cae por debajo de la línea del hombro.
5. Body Halter — Se sujeta en la nuca. Espalda descubierta, tirantes que se unen en el cuello.
6. Body Espalda Abierta — Espalda descubierta total o parcialmente. Apertura posterior que puede llegar a la cintura.
7. Leotardo — Estilo deportivo o danza. Cobertura de torso, piernas libres, tejido elástico opaco.
8. Unitardo — Cobertura completa de piernas. Prenda de una pieza que cubre desde el cuello hasta los tobillos.
9. Body Malla — Transparente o semitransparente. Tejido de red o tul, cobertura ilusoria.
10. Jumpsuit Casual — Cómodo y funcional. Pantalón y camisa o top unidos, corte relajado, cintura con cordón o elástico.
11. Jumpsuit Elegante — Corte alto, formal. Silueta entallada, escote definido, tela de calidad, aire de vestir.
12. Jumpsuit Halter — Escote halter, espalda descubierta. Tirantes en nuca, silueta de pierna ancha o recta.

**A. ABRIGOS LARGOS / EXTERIORES**
A1 Topcoat — Clásico y elegante. Corte recto hasta media pierna o más. Silueta formal con solapas definidas y estructura de sastrería.
A2 Raglan — Mangas raglan para mayor comodidad y movilidad. La costura de hombro se desplaza hacia el cuello, permitiendo amplitud en la parte superior del brazo.
A3 Princess Swing — Faldón amplio y fluido que da volumen y movimiento. Corte princesa con paneles que se ensanchan desde la cintura hacia el bajo.
A4 Recto Silueta Limpia — Corte recto y minimalista, línea impecable desde el hombro hasta el borde inferior. Sin adornos estructurales superfluos.
A5 Tailcoat — Falda trasera larga y abertura frontal. Formal y sofisticado. Silueta de frac con cola posterior visible.
A6 Loden Coat — Clásico europeo, largo y resistente al clima frío. Tejido pesado de origen alpino, corte amplio para capas internas.
A7 Balmacaán — Cuello amplio y cierre cubierto. Estilo sobrio y refinado. Origen en la confección escocesa, corte recto con hombros caídos sutiles.

**B. CHAQUETAS CLÁSICAS**
B1 Chanel — Corte recto y corto, acabados estructurados y detallados. Bordes en cadena o vivo, solapas simétricas, aire de alta costura.
B2 Cropped Chanel — Versión corta y elegante. Ideal para looks pulidos. Terminación por encima de la línea de cintura.
B3 Bolero — Muy corta, cubre solo hombros y parte alta de la espalda. Manga corta o tres cuartos, corte circular.
B4 Cardigan — Abierta al frente con botones o cierre. Tejido suave y versátil. Silueta relajada, posible uso como capa intermedia.
B5 Bomber — Corte con puños y cintura elástica. Estilo deportivo. Origen militar, ahora urbano, con volumen controlado en el torso.
B6 Biker / Motera — Cierre diagonal y solapas con broches. Estilo rebelde. Cuero o sintético, ajuste entallado, protección visual.
B7 Denim Jacket — Clásica de mezclilla. Corte slim y ajustado, resistente y casual. Costuras contrastantes, botones metálicos.
B8 Lean Jacket — Corte slim y ajustado, moderna y urbana. Silueta ceñida que sigue la línea del torso sin exceso de tejido.

**C. CHAQUETAS DE INVIERNO / TÉRMICAS**
C1 Parka — Larga y funcional, con capucha y bolsillos amplios. Diseño de origen ártico, corte amplio para aislamiento.
C2 Trench Coat — Cruzada, con cinturón y solapas anchas. Icónica y atemporal. Tejido de gabardina resistente al agua, doble botonadura.
C3 Puffer / Acolchada — Relleno térmico acolchado. Ligera, cálida y volumétrica. Compartimentos cosidos que contienen plumón o fibra sintética.
C4 Abrigo de Piel / Faux Fur — Textura esponjosa y lujosa. Aporta volumen y calidez. Pelaje denso, corte amplio, sensación táctil prominente.

**A. PANTALONES DE CORTE LARGO / ESTRUCTURADO**
A1 Straight — Corte recto. Ancho uniforme desde la cadera hasta el bajo. Silueta limpia y vertical sin estrechamiento.
A2 Pintucks — Costuras verticales al frente. Pliegues cosidos que alargan visualmente la pierna y aportan rigidez formal.
A3 Sailor — Botones decorativos en los laterales de la cintura. Corte amplio con origen náutico, caída estructurada y plana.
A4 Palazzo — Pierna muy ancha desde la cadera. Caída fluida y amplia que genera silueta de falda en movimiento.
A5 Wide Leg — Pierna ancha con caída recta y estructurada. Ancho moderado, línea vertical continua desde la cadera sin contacto con la pierna.
A6 Falda Pantalón — Apariencia de falda larga con la comodidad de un pantalón. Volumen exterior que oculta la separación de piernas.

**B. PANTALONES AJUSTADOS Y FUNCIONALES**
B1 Pegged — Volumen en muslos que se estrecha en tobillos. Silueta de trapecio invertido, corte carrot.
B2 Pocket Cargo — Bolsillos laterales con solapas. Estilo utilitario y práctico, tejido resistente, aire de campo o trabajo.
B3 Bush — Bolsillos frontales profundos. Resistente y rudo. Corte recto amplio con alforzas o pliegues funcionales.
B4 Skinny — Ajuste ceñido total desde la cintura hasta el tobillo. Silueta que sigue la anatomía de la pierna sin holgura.
B5 Boot-Cut Flared — Ajustado en muslos y se abre desde la rodilla hacia abajo. Expansión inferior que permite cubrir el calzado.
B6 Stirrup — Con estribo bajo el pie para mantener la prenda en su lugar. Ajuste ceñido con sujeción inferior activa.
B7 Cuffed — Bajo con puño o vuelta. Remate estructurado en el tobillo, estilo casual y relajado.

**C. PANTALONES DE VOLUMEN Y ESPECIALIZADOS**
C1 Balloon Harem — Volumen amplio con puños en tobillos. Cómodo y dramático. Silueta de globo que se concentra en la cadera y se cierra abajo.
C2 Zouave — Tiro muy bajo y volumen amplio. Máxima libertad de movimiento. Corte histórico-militar con acumulación de tejido en el muslo.
C3 Jodhpurs — Amplio en muslos y ceñido desde la rodilla hasta el tobillo. Diseño ecuestre, curva pronunciada en la zona superior de la pierna.
C4 Overall — Peto con tirantes. Práctico y versátil para trabajo. Cobertura de torso y piernas con unión superior de peto.

**D. FALDAS / SKIRTS**
D1 Mini — Corta, por encima del muslo. Exposición máxima de pierna, silueta juvenil.
D2 Mini Plisada — Pliegues pequeños. Estilo escolar o juvenil. Estructura de acordeón en longitud corta.
D3 Lápiz — Ajustada al cuerpo. Elegante y formal. Silueta ceñida que sigue la curva de la cadera y muslo.
D4 Midi — Largo a media pantorrilla. Clásica y versátil. Terminación entre la rodilla y el gemelo.
D5 Midi Plisada — Pliegues verticales. Movimiento y elegancia. Estructura de acordeón en longitud media.
D6 A-Line — En forma de A. Se ensancha hacia el bajo desde la cintura. Silueta triangular equilibrada.
D7 Círculo — Muy amplia. Vuelo completo y femenino. Corte circular que maximiza el volumen al girar.
D8 Envolvente — Cruzada al frente y ajustable. Abertura variable. Paneles superpuestos que se ciñen con lazo o botón.
D9 Pareo — Anudada en la cintura. Ligera y fresca. Rectángulo de tela que se envuelve y sujeta lateralmente.
D10 Tul — Capas de tul. Volumen y textura etérea. Superposición de velos transparentes que generan densidad visual.
D11 Maxi — Larga hasta el tobillo. Sofisticada. Caída continua que oculta la pierna completamente.
D12 Maxi con Abertura — Abertura alta lateral o frontal. Efecto elegante con exposición estratégica al caminar.
D13 Sirena — Ajustada en caderas y se abre en el bajo. Efecto elegante. Silueta de cola de pez que se ensancha desde la rodilla.
D14 Plisada Larga — Pliegues largos. Fluida y clásica. Estructura vertical que alarga la silueta en longitud completa.
D15 Godet — Paneles triangulares que dan vuelo al caer. Inserciones que expanden el borde inferior sin aumentar el volumen en la cadera.
D16 Tul Capas — Varias capas de tul. Volumen suave y romántico. Estratos de transparencia que crean profundidad.
D17 Cargo Skirt — Bolsillos laterales. Estilo utilitario y moderno. Aplicaciones funcionales en longitud variable.
D18 Denim Skirt — De mezclilla. Casual, resistente y atemporal. Tejido de sarga con costuras contrastantes.
D19 Asimétrica — Largos irregulares. Diseño moderno y dinámico. Borde diagonal que rompe la horizontalidad.
D20 Globo — Bajo abullonado. Volumen y originalidad. Expansión artificial en el borde inferior mediante recogido o estructura.

**A. BOTAS Y BOTINES**
1 Wedge Booties — Tacón de cuña cómodo y estable. Plataforma continua desde el talón a la punta.
2 Bondage Boots — Hebillas y correas con actitud atrevida. Arnés de sujeción múltiple en el eje del pie.
3 Gladiator Boots — Tiras múltiples que suben por la pierna. Sujeción de cinturón segmentado.
4 Timberland Boots — Resistentes, casuales y funcionales. Suela gruesa de tractor, construcción robusta.
5 Ugg Boots — Suaves, cálidas y acolchadas. Interior de borrego, exterior de ante.
6 Cowboy Boots — Punta afilada y tacón inclinado clásico. Bordados, caña media-alta.
7 Wellington Boots — Impermeables, ideales para lluvia. Caucho, caña alta, sin tacón.
8 Knee High Boots — Hasta la rodilla, elegantes y alargadas. Tacón medio-alto, ajuste en la pantorrilla.
9 Thigh High Boots — Por encima de la rodilla, seductoras. Ajuste en el muslo, tacón variable.
10 Ankle Boots — Llegan al tobillo, versátiles y chic. Caña corta, cierre lateral o trasero.
11 Slingbacks — Tira trasera que sujeta el talón. Puntera descubierta o cerrada.
12 Mules — Sin talón ni sujeción trasera. Calzado de enfiler, tacón variable.
13 Clogs — De madera o imitación, robustos y únicos. Suela rígida, tacón grueso.
14 Gladiators — Sandalias de tiras frescas y abiertas. Sujeción hasta la pantorrilla o tobillo.
15 Lita — Plataforma gruesa con cordones. Estilo gótico o alternativo, tacón bloque.
16 Crocs — Cómodos, ligeros y ventilados. Material sintético foam, orificios superiores.
17 Chelsea Boots — Elásticos laterales, sin cordones. Caña media, tacón bajo, punta redondeada.
18 Dr. Martens — Icónicos, resistentes y duraderos. Suela de aire amarilla, 8 ojetes.
19 Platform Sandal — Plataforma alta para estilar. Suela gruesa, tiras mínimas.
20 Strappy Heel — Tiras finas que delicadamente sujetan. Tacón aguja o bloque, múltiples correas.
`;

const dict = {};
const lines = rawText.split('\n');
for (const line of lines) {
  let match = line.match(/^([A-Z0-9\.]+)\s+(.*?)\s*[—\-]\s*(.*)/);
  if (match) {
    // We just want to map by the name string, e.g. "Bodycon", "Topcoat", etc.
    let name = match[2].trim();
    let desc = match[3].trim();
    dict[name] = desc;
  } else {
    let match2 = line.match(/^([A-Z0-9]+)\s*(.*?)\.\s+(.*)/); // 1. Bodycon — ... fallback?
    if (match2) {
       // already matched by previous regex if it has "—"
    }
  }
}
let out = `\nexport const WARDROBE_DESCRIPTIONS_MAP: Record<string, string> = ` + JSON.stringify(dict, null, 2) + `;\n`;
fs.appendFileSync('src/data.ts', out);
