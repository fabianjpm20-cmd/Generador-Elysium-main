const fs = require('fs');

let content = fs.readFileSync('src/data.ts', 'utf8');

// The dictionary is already in content at the end: WARDROBE_DESCRIPTIONS_MAP

const tempMatch = content.match(/export const WARDROBE_DESCRIPTIONS_MAP: Record<string, string> = (\{[\s\S]*?\});/);
if (tempMatch) {
  const mapStr = tempMatch[1];
  const map = eval('(' + mapStr + ')');
  
  // We want to replace descriptions inside WARDROBE_CATEGORIES
  content = content.replace(/\{ id: '(B[^']+)', name: '([^']+)', desc: '([^']+)' \}/g, (match, id, name, desc) => {
     let newDesc = desc;
     if (map[name]) {
         newDesc = map[name];
     } else {
         // try matching substrings
         for (let key in map) {
             if (name.includes(key) || key.includes(name)) {
                 newDesc = map[key];
                 break;
             }
         }
     }
     return `{ id: '${id}', name: '${name}', desc: ${JSON.stringify(newDesc)} }`;
  });
  
  fs.writeFileSync('src/data.ts', content);
}

