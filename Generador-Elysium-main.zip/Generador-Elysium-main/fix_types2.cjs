const fs = require('fs');
let data = fs.readFileSync('src/types.ts', 'utf8');

data = data.replace(
  /variation: string;\n  layer: string;\n\}/,
  "variation: string;\n  layer: string;\n  location: string;\n  pattern: string;\n}"
);

fs.writeFileSync('src/types.ts', data);
