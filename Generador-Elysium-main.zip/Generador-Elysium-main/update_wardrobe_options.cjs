const fs = require('fs');

let data = fs.readFileSync('src/data.ts', 'utf8');

const additionalCode = `
export function getWardrobeOptions(categoryId: string) {
  const isTop = ['B0', 'B1', 'B12-A', 'B3-D'].includes(categoryId);
  const isBottom = ['B2', 'B3-B'].includes(categoryId);
  const isShoes = categoryId === 'B4';
  const isAcc = categoryId === 'B5';
  const isBra = categoryId === 'B3-A';
  const isSocks = categoryId === 'B3-C';

  // CUT
  let cut = ['Ajustado', 'Holgado', 'Recto', 'Entallado', 'Oversize', 'Slim'];
  if (isShoes) cut = ['Punta Redonda', 'Punta Cuadrada', 'Punta Afilada', 'Abierto', 'Plataforma'];
  if (isAcc) cut = ['Fino', 'Grueso', 'Minimalista', 'Chunky', 'Estructurado'];
  if (isBra || isBottom || isSocks) cut = ['Compresión Alta', 'Compresión Media', 'Relajado', 'Sin Costuras'];

  // LENGTH
  let length = ['Cortísimo', 'Corto', 'Medio', 'Largo', 'Máximo', 'Asimétrico'];
  if (isShoes) length = ['Bajo (Tobillo)', 'Media Pierna', 'Rodilla', 'Muslo'];
  if (isBottom) length = ['Micro', 'Muslo', 'Rodilla', 'Tobillo', 'Suelo', 'Con Cola'];
  if (isAcc) length = ['Corto/Ajustado', 'Medio', 'Largo/Colgante'];
  if (isBra) length = ['Estándar', 'Longline', 'Micro'];

  // SLEEVE
  let sleeve = ['Sin mangas', 'Corta', '3/4', 'Larga', 'Abullonada', 'Kimono', 'Raglán'];
  if (!isTop) sleeve = [];

  // MATERIAL
  let material = ['Algodón', 'Lino', 'Lana', 'Seda', 'Terciopelo', 'Denim', 'Cuero', 'Encaje', 'Metal', 'PVC', 'Sintético'];
  if (isShoes || isAcc) material = ['Cuero', 'Gamuza', 'Sintético', 'Metal', 'Madera', 'Goma', 'Lona'];
  if (isBra || isSocks || categoryId === 'B3-B') material = ['Algodón', 'Encaje', 'Malla/Tul', 'Microfibra', 'Seda', 'Látex'];

  // FINISH
  let finish = ['Mate', 'Satinado', 'Brillante', 'Espejado', 'Pulido', 'Desgastado', 'Metalizado', 'Craquelado'];
  
  // DETAILS
  let details = ['Bordados', 'Hebillas', 'Costuras', 'Encajes', 'Parches', 'Cinturones', 'Pliegues'];
  if (isShoes || isAcc) details = ['Tachuelas', 'Hebillas', 'Cadenas', 'Grabados', 'Lazos', 'Minimalista'];
  if (isBra || categoryId === 'B3-B') details = ['Lazos', 'Transparencias', 'Volantes', 'Bordados', 'Cintas', 'Minimalista'];

  // VARIATION
  let variation = ['Simétrica', 'Asimétrica', 'Desgastada', 'Desmechada', 'Degradada', 'Drapeada'];
  if (isShoes) variation = ['Estándar', 'Plataforma Alta', 'Tacón Fino', 'Tacón Grueso', 'Deportivo'];
  
  // LAYER
  let layer = ['Interior', 'Base', 'Intermedia', 'Exterior', 'Accesorio sobrepuesto'];
  if (isShoes) layer = ['Calzado Base', 'Calzado Exterior'];
  if (isAcc) layer = ['Accesorio Pequeño', 'Accesorio Mediano', 'Accesorio Grande', 'Armadura/Protección'];
  if (isBra || categoryId === 'B3-B' || isSocks || categoryId === 'B3-D') layer = ['Interior Íntima', 'Base Ligera'];

  return {
    cut,
    length,
    sleeve,
    material,
    finish,
    details,
    variation,
    layer
  };
}
`;
fs.appendFileSync('src/data.ts', additionalCode);
