const fs = require('fs');
let data = fs.readFileSync('src/components/State3Wardrobe.tsx', 'utf8');

// Update useState initial state
data = data.replace(
  /patternDetail: '',\n    emblem: 'Ninguno',\n    vfx: 'Ninguno'\n  \}\);/,
  "patternDetail: '',\n    neckline: '',\n    emblem: 'Ninguno',\n    vfx: 'Ninguno'\n  });"
);

data = data.replace(
  /pattern: string;\n    patternDetail: string;\n    emblem: string;\n    vfx: string;\n  \}\>/,
  "pattern: string;\n    patternDetail: string;\n    neckline: string;\n    emblem: string;\n    vfx: string;\n  }>"
);

// Update useEffect set state
data = data.replace(
  /patternDetail: '',\n      emblem: opts\.emblem \? opts\.emblem\[0\] \|\| 'Ninguno' : 'Ninguno',\n      vfx: opts\.vfx \? opts\.vfx\[0\] \|\| 'Ninguno' : 'Ninguno'\n    \}\);/,
  "patternDetail: '',\n      neckline: opts.neckline ? opts.neckline[0] || '' : '',\n      emblem: opts.emblem ? opts.emblem[0] || 'Ninguno' : 'Ninguno',\n      vfx: opts.vfx ? opts.vfx[0] || 'Ninguno' : 'Ninguno'\n    });"
);

// Update item selection click handler
data = data.replace(
  /patternDetail: '',\n                        emblem: newOpts\.emblem\.includes\(prev\.emblem\) \? prev\.emblem : \(newOpts\.emblem\[0\] \|\| 'Ninguno'\),\n                        vfx: newOpts\.vfx\.includes\(prev\.vfx\) \? prev\.vfx : \(newOpts\.vfx\[0\] \|\| 'Ninguno'\)\n                      \}\)\);/,
  "patternDetail: '',\n                        neckline: newOpts.neckline && newOpts.neckline.includes(prev.neckline) ? prev.neckline : (newOpts.neckline ? newOpts.neckline[0] : ''),\n                        emblem: newOpts.emblem.includes(prev.emblem) ? prev.emblem : (newOpts.emblem[0] || 'Ninguno'),\n                        vfx: newOpts.vfx.includes(prev.vfx) ? prev.vfx : (newOpts.vfx[0] || 'Ninguno')\n                      }));"
);

// Inject JSX for Neckline
const necklineJSX = `
                  {activeOptions.neckline && activeOptions.neckline.length > 0 && (<div>
                    <label className="block text-xs font-mono text-[#888888] mb-1">Cuello / Escote</label>
                    <select
                      value={currentGarment.neckline || ''}
                      onChange={e => setCurrentGarment(prev => ({ ...prev, neckline: e.target.value }))}
                      className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                    >
                      {activeOptions.neckline.map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </div>)}
`;

data = data.replace(
  /                  \{activeOptions\.sleeve && activeOptions\.sleeve\.length > 0 && \(\<div\>[\s\S]*?\<\/select\>\n\s*\<\/div\>\)\}/,
  "$&" + necklineJSX
);

fs.writeFileSync('src/components/State3Wardrobe.tsx', data);
