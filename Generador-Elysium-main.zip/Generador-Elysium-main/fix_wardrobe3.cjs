const fs = require('fs');
let data = fs.readFileSync('src/components/State3Wardrobe.tsx', 'utf8');

// initial state
data = data.replace(
  /location: \[\],/,
  "location: [],\n    detailLocations: {},"
);

// useEffect
data = data.replace(
  /location: opts\.location && opts\.location\.length > 0 \? \[opts\.location\[0\]\] : \[\],/,
  "location: opts.location && opts.location.length > 0 ? [opts.location[0]] : [],\n      detailLocations: {},"
);

// onChange item
data = data.replace(
  /location: prev\.location\.filter\(l => newOpts\.location\.includes\(l\)\)\.length > 0 \? prev\.location\.filter\(l => newOpts\.location\.includes\(l\)\) : \(newOpts\.location\[0\] \? \[newOpts\.location\[0\]\] : \[\]\),/,
  "location: prev.location.filter(l => newOpts.location.includes(l)).length > 0 ? prev.location.filter(l => newOpts.location.includes(l)) : (newOpts.location[0] ? [newOpts.location[0]] : []),\n                        detailLocations: {},"
);

// JSX
const jsxRegex = /\{activeOptions\.location && activeOptions\.location\.length > 0 && !\(\(currentGarment\.details \|\| \[\]\)\.includes\('Minimalista'\)\) && \([\s\S]*?\<\/div\>\n                    \)\}/;

const newJSX = `{!(currentGarment.details || []).includes('Minimalista') && (
                      <div className="mt-4 flex flex-col gap-4">
                        {(currentGarment.details || []).map(det => {
                          const detLocs = activeOptions.locationMap && activeOptions.locationMap[det];
                          if (!detLocs || detLocs.length === 0) return null;
                          return (
                            <div key={det} className="pl-3 border-l-2 border-[#C9A050]">
                              <label className="block text-xs font-mono text-[#888888] mb-2">Posición para: <span className="text-[#C9A050] font-bold">{det}</span></label>
                              <div className="flex flex-wrap gap-2">
                                {detLocs.map(o => {
                                  const currentDetLocs = (currentGarment.detailLocations && currentGarment.detailLocations[det]) || [];
                                  const isSelected = currentDetLocs.includes(o);
                                  return (
                                    <button
                                      key={o}
                                      type="button"
                                      onClick={() => {
                                        setCurrentGarment(prev => {
                                          const prevDetLocs = (prev.detailLocations && prev.detailLocations[det]) || [];
                                          const newLocs = prevDetLocs.includes(o) ? prevDetLocs.filter(l => l !== o) : [...prevDetLocs, o];
                                          return { ...prev, detailLocations: { ...prev.detailLocations, [det]: newLocs } };
                                        });
                                      }}
                                      className={\`px-2 py-1 text-[11px] rounded transition-all \${
                                        isSelected
                                          ? 'bg-[#C9A050] text-[#0A0B0E] font-bold shadow-md'
                                          : 'bg-[#15171C] text-[#888888] border border-[#2A2D35] hover:border-[#888888]'
                                      }\`}
                                    >
                                      {o}
                                    </button>
                                  );
                                })}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}`;

data = data.replace(jsxRegex, newJSX);

fs.writeFileSync('src/components/State3Wardrobe.tsx', data);
