const fs = require('fs');
let data = fs.readFileSync('src/components/State7Compilation.tsx', 'utf8');

const getDatosCompiladosStr = `
    const getDatosCompilados = () => {
      const parts = [];
      parts.push(\`Race: \${cleanVal(state.raceName) || 'Human'}\`);
      parts.push(\`Role: \${cleanVal(state.role)}\`);
      parts.push(\`Visual Style: \${cleanVal(state.styleVisual)}\`);
      
      const anatomy = [cleanVal(state.anatomy.sexBase), cleanVal(state.anatomy.age), cleanVal(state.anatomy.complexion), \`Skin \${cleanVal(state.anatomy.skinColor)}\`, cleanVal(state.anatomy.height)].filter(Boolean).join(', ');
      if (anatomy) parts.push(anatomy);
      
      const facial = [cleanVal(state.facial.headShape), \`Eyes \${cleanVal(state.facial.eyeColor)}\`].filter(Boolean).join(', ');
      if (facial) parts.push(facial);
      
      const hair = [\`Hair \${cleanVal(state.hair.hairColor)}\`, cleanVal(state.hair.length), cleanVal(state.hair.texture)].filter(Boolean).join(', ');
      if (hair) parts.push(hair);
      
      const apps = [];
      if (cleanVal(state.appendices.hornsForm)) apps.push(\`Horns: \${cleanVal(state.appendices.hornsForm)}\`);
      if (cleanVal(state.appendices.wingsType)) apps.push(\`Wings: \${cleanVal(state.appendices.wingsType)}\`);
      if (cleanVal(state.appendices.tailsType)) apps.push(\`Tail: \${cleanVal(state.appendices.tailsType)}\`);
      if (apps.length > 0) parts.push(\`[Appendices: \${apps.join(', ')}]\`);
      
      const wardrobeParts = state.wardrobes.map(w => \`\${w.name} (\${w.material}, \${w.color})\`).join(', ');
      if (wardrobeParts) parts.push(\`[Wardrobe: \${wardrobeParts}]\`);
      
      if (state.armor.type && state.armor.type !== 'Ninguna') {
         parts.push(\`[Armor: \${cleanVal(state.armor.type)} - \${state.armor.pieces.map(p => p.substring(5)).join(', ')}]\`);
      }
      
      const eq = [];
      if (state.equipment.weapons.length > 0) eq.push(\`Weapons: \${state.equipment.weapons.map(cleanVal).join(', ')}\`);
      if (state.equipment.bags.length > 0) eq.push(\`Bags: \${state.equipment.bags.map(cleanVal).join(', ')}\`);
      if (state.equipment.items.length > 0) eq.push(\`Items: \${state.equipment.items.map(cleanVal).join(', ')}\`);
      if (eq.length > 0) parts.push(\`[Equipment: \${eq.join('; ')}]\`);
      
      return parts.join(', ');
    };
`;

data = data.replace(
  "const lines = [",
  getDatosCompiladosStr + "\n    const lines = ["
);

const newFooter = `      "",
      "### Antecedentes",
      \`Historia: \${state.background.backstory || ''}\`,
      "",
      "## Prompt de estilo:[contemporary anime digital illustration, manhwa visual novel aesthetic, otome gacha character art, fine variable linework, thicker outer silhouette contour, soft inner lines, low to moderate color saturation, muted palette, clean silhouette, 4k resolution, sharp focus.]",
      "+",
      \`[\${getDatosCompilados()}]\`,
      "+",
      "## Negative Prompt:[photorealistic, western comic style, hyperrealistic anatomy, heavy black clothing outlines, 3D render, oversaturated colors, noisy texture, blurry, low resolution, western cartoon, low quality, blurry, deformed hands, deformed feet, bad anatomy, extra limbs, watermark, logo, ugly, disfigured, poor lighting, oversaturated, grainy]"
    ];`;

data = data.replace(
  /      "",\s*"### Antecedentes",\s*`Historia: \${state\.background\.backstory \|\| ''}`\s*\];/,
  newFooter
);

fs.writeFileSync('src/components/State7Compilation.tsx', data);
