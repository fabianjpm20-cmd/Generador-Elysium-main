const fs = require('fs');
let data = fs.readFileSync('src/components/State3Wardrobe.tsx', 'utf8');

const newFields = `
                  {activeOptions.location && activeOptions.location.length > 0 && (<div>
                    <label className="block text-xs font-mono text-[#888888] mb-1">Ubicación / Posición</label>
                    <select
                      value={currentGarment.location || ''}
                      onChange={e => setCurrentGarment(prev => ({ ...prev, location: e.target.value }))}
                      className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                    >
                      {activeOptions.location.map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </div>)}

                  {activeOptions.pattern && activeOptions.pattern.length > 0 && (<div>
                    <label className="block text-xs font-mono text-[#888888] mb-1">Patrón / Estampado</label>
                    <select
                      value={currentGarment.pattern || ''}
                      onChange={e => setCurrentGarment(prev => ({ ...prev, pattern: e.target.value }))}
                      className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                    >
                      {activeOptions.pattern.map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </div>)}

                  {activeOptions.emblem && activeOptions.emblem.length > 0 && (<div>
                    <label className="block text-xs font-mono text-[#888888] mb-1">Emblema / Símbolo <InfoTooltip text="Logos, crestas, runas o marcas singulares grabadas/bordadas en la prenda." /></label>
                    <select
                      value={currentGarment.emblem || 'Ninguno'}
                      onChange={e => setCurrentGarment(prev => ({ ...prev, emblem: e.target.value }))}
                      className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                    >
                      {activeOptions.emblem.map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </div>)}

                  {activeOptions.vfx && activeOptions.vfx.length > 0 && (<div>
                    <label className="block text-xs font-mono text-[#888888] mb-1">Efectos / Condición <InfoTooltip text="Estado físico especial o efectos visuales/mágicos que emite la prenda." /></label>
                    <select
                      value={currentGarment.vfx || 'Ninguno'}
                      onChange={e => setCurrentGarment(prev => ({ ...prev, vfx: e.target.value }))}
                      className="w-full bg-[#15171C] border border-[#2A2D35] rounded-xl p-2 text-xs text-[#E0E0E0]"
                    >
                      {activeOptions.vfx.map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </div>)}
`;

data = data.replace(
  /\<select\n\s*value=\{currentGarment\.layer\}[\s\S]*?\<\/select\>\n\s*\<\/div\>/,
  "$&" + newFields
);

fs.writeFileSync('src/components/State3Wardrobe.tsx', data);
